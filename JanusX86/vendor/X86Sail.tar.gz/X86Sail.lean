-- Sail-generated model, split by JanusASL/sail/split_lean.py
import X86Sail.Part12
