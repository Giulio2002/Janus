import X86Sail.Part08

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def gpr_xor_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (Sail.BitVec.extractLsb (logxor dst src) 7 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (Sail.BitVec.extractLsb (logxor dst src) 15 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (Sail.BitVec.extractLsb (logxor dst src) 31 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (Sail.BitVec.extractLsb (logxor dst src) 63 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: operation : Nat, List.elem operation [0, 1, 2, 3, 4, 5, 6, 7, 8] -/
def gpr_arith_logic_spec_1 (operation : Nat) (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  match operation with
  | 0 => (gpr_add_spec_1 dst src input_rflags)
  | 1 => (gpr_or_spec_1 dst src input_rflags)
  | 2 => (gpr_adc_spec_1 dst src input_rflags)
  | 3 => (gpr_and_spec_1 dst src input_rflags)
  | 4 => (gpr_sub_spec_1 dst src input_rflags)
  | 5 => (gpr_xor_spec_1 dst src input_rflags)
  | 6 => (gpr_sbb_spec_1 dst src input_rflags)
  | 7 => (gpr_and_spec_1 dst src input_rflags)
  | 8 => (gpr_sub_spec_1 dst src input_rflags)
  | _ => (pure (0x00#8, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

/-- Type quantifiers: operation : Nat, List.elem operation [0, 1, 2, 3, 4, 5, 6, 7, 8] -/
def gpr_arith_logic_spec_2 (operation : Nat) (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  match operation with
  | 0 => (gpr_add_spec_2 dst src input_rflags)
  | 1 => (gpr_or_spec_2 dst src input_rflags)
  | 2 => (gpr_adc_spec_2 dst src input_rflags)
  | 3 => (gpr_and_spec_2 dst src input_rflags)
  | 4 => (gpr_sub_spec_2 dst src input_rflags)
  | 5 => (gpr_xor_spec_2 dst src input_rflags)
  | 6 => (gpr_sbb_spec_2 dst src input_rflags)
  | 7 => (gpr_and_spec_2 dst src input_rflags)
  | 8 => (gpr_sub_spec_2 dst src input_rflags)
  | _ => (pure (0x0000#16, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

/-- Type quantifiers: operation : Nat, List.elem operation [0, 1, 2, 3, 4, 5, 6, 7, 8] -/
def gpr_arith_logic_spec_4 (operation : Nat) (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  match operation with
  | 0 => (gpr_add_spec_4 dst src input_rflags)
  | 1 => (gpr_or_spec_4 dst src input_rflags)
  | 2 => (gpr_adc_spec_4 dst src input_rflags)
  | 3 => (gpr_and_spec_4 dst src input_rflags)
  | 4 => (gpr_sub_spec_4 dst src input_rflags)
  | 5 => (gpr_xor_spec_4 dst src input_rflags)
  | 6 => (gpr_sbb_spec_4 dst src input_rflags)
  | 7 => (gpr_and_spec_4 dst src input_rflags)
  | 8 => (gpr_sub_spec_4 dst src input_rflags)
  | _ => (pure (0x00000000#32, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

/-- Type quantifiers: operation : Nat, List.elem operation [0, 1, 2, 3, 4, 5, 6, 7, 8] -/
def gpr_arith_logic_spec_8 (operation : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match operation with
  | 0 => (gpr_add_spec_8 dst src input_rflags)
  | 1 => (gpr_or_spec_8 dst src input_rflags)
  | 2 => (gpr_adc_spec_8 dst src input_rflags)
  | 3 => (gpr_and_spec_8 dst src input_rflags)
  | 4 => (gpr_sub_spec_8 dst src input_rflags)
  | 5 => (gpr_xor_spec_8 dst src input_rflags)
  | 6 => (gpr_sbb_spec_8 dst src input_rflags)
  | 7 => (gpr_and_spec_8 dst src input_rflags)
  | 8 => (gpr_sub_spec_8 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

/-- Type quantifiers: operation : Nat, operand_size : Nat, List.elem operand_size [1, 2, 4, 8], List.elem operation [0, 1, 2, 3, 4, 5, 6, 7, 8] -/
def gpr_arith_logic_spec (operand_size : Nat) (operation : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match operand_size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (gpr_arith_logic_spec_1 operation (Sail.BitVec.truncate dst 8) (Sail.BitVec.truncate src 8) input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (gpr_arith_logic_spec_2 operation (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16) input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (gpr_arith_logic_spec_4 operation (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32) input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | _ => (gpr_arith_logic_spec_8 operation dst src input_rflags)

/-- Type quantifiers: seg_reg : Nat, addr_size : Nat, List.elem addr_size [2, 4, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def rme08 (proc_mode : proc_mode) (addr_size : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (r_x : String) : SailM (BitVec 8) := do
  (load_bytes_from_ea proc_mode addr_size 1 eff_addr base_reg seg_reg r_x false false)

/-- Type quantifiers: k_ex407891_ : Bool, seg_reg : Nat, addr_size : Nat, List.elem addr_size [2, 4, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def rme16 (proc_mode : proc_mode) (addr_size : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (r_x : String) (check_alignment? : Bool) : SailM (BitVec 16) := do
  (load_bytes_from_ea proc_mode addr_size 2 eff_addr base_reg seg_reg r_x check_alignment? false)

/-- Type quantifiers: k_ex407896_ : Bool, k_ex407895_ : Bool, seg_reg : Nat, nbytes : Nat, addr_size : Nat, List.elem addr_size [2, 4, 8], List.elem nbytes [1, 2, 4, 6, 8, 10, 16], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def rme_size (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (r_x : String) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM (BitVec 128) := do
  (pure (Sail.BitVec.zeroExtend (← (load_bytes_from_ea proc_mode addr_size nbytes eff_addr base_reg seg_reg r_x check_alignment? mem_ptr?)) 128))

/-- Type quantifiers: k_ex407901_ : Bool, k_ex407900_ : Bool, seg_reg : Nat, nbytes : Nat, addr_size : Nat, List.elem addr_size [2, 4, 8], List.elem nbytes [1, 2, 4, 6, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def rime_size (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (r_x : String) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM (BitVec 64) := do
  (pure (Sail.BitVec.signExtend (← (load_bytes_from_ea proc_mode addr_size nbytes eff_addr base_reg seg_reg r_x check_alignment? mem_ptr?)) 64))

/-- Type quantifiers: k_ex407905_ : Bool, k_ex407904_ : Bool, seg_reg : Nat, addr_size : Nat, nbytes : Nat, List.elem nbytes [1, 2, 4, 6, 8, 10, 16], List.elem addr_size [2, 4, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def wme_size (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (data : (BitVec 128)) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM Unit := do
  (store_bytes_to_ea proc_mode addr_size nbytes eff_addr base_reg seg_reg (Sail.BitVec.truncate data (8 *i nbytes)) check_alignment? mem_ptr?)

def read_iptr (proc_mode : proc_mode) : SailM (BitVec 48) := do
  let iptr ← (( do (read_rip ()) ) : SailM (sbits 48) )
  (if ((in_64bit_mode proc_mode) : Bool)
  then (do (pure iptr))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
              let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
              (if ((cs_d == 1#1) : Bool)
              then (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.truncate iptr 32) 48)))
              else (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.zeroExtend (Sail.BitVec.truncate iptr 16) 32) 48)))))
        else (do (pure 0x000000000000#48)))))

def add_to_iptr (proc_mode : proc_mode) (iptr : (BitVec 48)) (delta : (BitVec 48)) : SailM (BitVec 48) := do
  let iptr_plus_delta : (sbits 49) := (bits_of_int ((BitVec.toInt iptr) +i (BitVec.toInt delta)) 49)
  (if ((in_64bit_mode proc_mode) : Bool)
  then
    (do (if ((← (canonical_address_p (BitVec.toInt iptr_plus_delta))) : Bool)
        then (do (pure (Sail.BitVec.truncate iptr_plus_delta 48)))
        else (do (x86_model_error ":NON-CANONICAL-INSTRUCTION-POINTER"))))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let cs_limit ← (( do (pure (loghead_bits 32 (GetElem?.getElem! (← readReg seg_hidden_limits) 1))) ) : SailM (BitVec 32) )
              (if (((0 ≤b (BitVec.toInt iptr_plus_delta)) && (((BitVec.toInt iptr_plus_delta) ≤b (BitVec.toNatInt cs_limit)) : Bool)) : Bool)
              then (do (pure (Sail.BitVec.truncate (Sail.BitVec.zeroExtend (Sail.BitVec.truncate iptr_plus_delta 32) 49) 48)))
              else (do (x86_model_error ":OUT-OF-SEGMENT-INSTRUCTION-POINTER"))))
        else (do (x86_model_error ":UNIMPLEMENTED-PROC-MODE")))))

def write_iptr (proc_mode : proc_mode) (iptr : (BitVec 48)) : SailM Unit := do
  (if ((in_64bit_mode proc_mode) : Bool)
  then (do (write_rip iptr))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
              let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
              (if ((cs_d == 1#1) : Bool)
              then (do (write_rip (Sail.BitVec.zeroExtend (Sail.BitVec.truncate iptr 32) 48)))
              else
                (do let rip_var ← (( do (read_rip ()) ) : SailM (sbits 48) )
                    let rip_new : (sbits 48) := (changeSlice_bits rip_var 0 16 (Sail.BitVec.truncate iptr 16))
                    (write_rip rip_new))))
        else (do (pure ())))))

def read_sptr (proc_mode : proc_mode) : SailM (BitVec 64) := do
  let sptr ← (( do (rgfi 4) ) : SailM (sbits 64) )
  (if ((in_64bit_mode proc_mode) : Bool)
  then (do (pure sptr))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let ss_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 2)) ) : SailM (BitVec 16) )
              let ss_b : (BitVec 1) := (_get_data_segment_descriptor_attributesbits_d_b (Mk_data_segment_descriptor_attributesbits ss_attr))
              (if ((ss_b == 1#1) : Bool)
              then (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.truncate sptr 32) 64)))
              else (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.zeroExtend (Sail.BitVec.truncate sptr 16) 32) 64)))))
        else (do (pure 0x0000000000000000#64)))))

def add_to_sptr (proc_mode : proc_mode) (sptr : (BitVec 64)) (delta : (BitVec 64)) : SailM (BitVec 64) := do
  let sptr_plus_delta : (sbits 65) := (bits_of_int ((BitVec.toInt sptr) +i (BitVec.toInt delta)) 65)
  (if ((in_64bit_mode proc_mode) : Bool)
  then
    (do let sptr_plus_delta : (sbits 64) := (Sail.BitVec.truncate sptr_plus_delta 64)
        (if ((← (canonical_address_p (BitVec.toInt sptr_plus_delta))) : Bool)
        then (do (pure sptr_plus_delta))
        else (do (x86_model_error ":NON-CANONICAL-STACK-ADDRESS"))))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let ss_limit ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_limits) 2)) ) : SailM (BitVec 32) )
              let ss_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 2)) ) : SailM (BitVec 16) )
              let ss_b : (BitVec 1) := (_get_data_segment_descriptor_attributesbits_d_b (Mk_data_segment_descriptor_attributesbits ss_attr))
              let ss_e : (BitVec 1) := (_get_data_segment_descriptor_attributesbits_e (Mk_data_segment_descriptor_attributesbits ss_attr))
              let ss_lower : Int :=
                if ((ss_e == 1#1) : Bool)
                then (1 +i (BitVec.toNatInt ss_limit))
                else 0
              let ss_upper : (BitVec 32) :=
                if ((ss_e == 1#1) : Bool)
                then
                  (if ((ss_b == 1#1) : Bool)
                  then 0xFFFFFFFF#32
                  else 0x0000FFFF#32)
                else ss_limit
              let sptr_plus_delta : (BitVec 32) :=
                if ((ss_b == 1#1) : Bool)
                then (Sail.BitVec.truncate sptr_plus_delta 32)
                else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate sptr_plus_delta 16) 32)
              (if ((! ((ss_lower ≤b (BitVec.toNatInt sptr_plus_delta)) && (((BitVec.toNatInt sptr_plus_delta) ≤b (BitVec.toNatInt ss_upper)) : Bool))) : Bool)
              then (do (x86_model_error ":OUT-OF-SEGMENT-STACK-ADDRESS"))
              else (do (pure ())))
              (pure (Sail.BitVec.zeroExtend sptr_plus_delta 64)))
        else (do (x86_model_error ":UNIMPLEMENTED-PROC-MODE")))))

def write_sptr (proc_mode : proc_mode) (sptr : (BitVec 64)) : SailM Unit := do
  (if ((in_64bit_mode proc_mode) : Bool)
  then (do (write_rgfi 4 sptr))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let ss_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 2)) ) : SailM (BitVec 16) )
              let ss_b : (BitVec 1) := (_get_data_segment_descriptor_attributesbits_d_b (Mk_data_segment_descriptor_attributesbits ss_attr))
              (if ((ss_b == 1#1) : Bool)
              then (do (write_rgfi 4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate sptr 32) 64)))
              else
                (do let rsp_var ← (( do (rgfi 4) ) : SailM (sbits 64) )
                    let rsp_new : (sbits 64) := (changeSlice_bits rsp_var 0 16 (Sail.BitVec.truncate sptr 16))
                    (write_rgfi 4 rsp_new))))
        else (do (pure ())))))

def x86_effective_addr_from_sib (proc_mode : proc_mode) (temp_rip : (BitVec 48)) (rex_byte : (BitVec 8)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) : SailM (Int × (BitVec 64) × Int) := do
  let b : (BitVec 3) := (_get_sib_base sib)
  let check_alignment? : Bool := false
  let (base, displacement, nrip_bytes) ← (( do
    let v_34 := mod_var
    (if ((eq_bits_nat v_34 0) : Bool)
    then
      (do (if ((b == 0b101#3) : Bool)
          then
            (do let dword ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 4 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" check_alignment? false) ) : SailM (sbits 64) )
                (pure (0x0000000000000000#64, dword, 4)))
          else
            (do (pure ((← do
                    (if ((in_64bit_mode proc_mode) : Bool)
                    then (do (rgfi (BitVec.toNatInt (reg_index b rex_byte 0b00#2))))
                    else (do (pure (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend b 4))) 64))))), 0x0000000000000000#64, 0)))))
    else
      (do (if ((eq_bits_nat v_34 1) : Bool)
          then
            (do let byte ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" check_alignment? false) ) : SailM (sbits 64) )
                (pure ((← do
                    (if ((in_64bit_mode proc_mode) : Bool)
                    then (do (rgfi (BitVec.toNatInt (reg_index b rex_byte 0b00#2))))
                    else (do (pure (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend b 4))) 64))))), byte, 1)))
          else
            (do (if ((eq_bits_nat v_34 2) : Bool)
                then
                  (do let dword ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 4 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" check_alignment? false) ) : SailM (sbits 64) )
                      (pure ((← do
                          (if ((in_64bit_mode proc_mode) : Bool)
                          then (do (rgfi (BitVec.toNatInt (reg_index b rex_byte 0b00#2))))
                          else (do (pure (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend b 4))) 64))))), dword, 4)))
                else (do (x86_model_error "mod-can-not-be-anything-other-than-0-1-or-2"))))))) ) : SailM ((sbits 64) × (sbits 64) × Int) )
  let ix : (BitVec 4) := (reg_index (_get_sib_index sib) rex_byte 0b01#2)
  let index ← (( do
    let v_37 := ix
    (if ((eq_bits_nat v_37 4) : Bool)
    then (do (pure 0x0000000000000000#64))
    else
      (do (if ((in_64bit_mode proc_mode) : Bool)
          then (do (rgfi (BitVec.toNatInt ix)))
          else (do (pure (Sail.BitVec.signExtend (Sail.BitVec.truncate (← (rgfi (BitVec.toNatInt ix))) 32) 64)))))) ) : SailM (sbits 64) )
  let scale : (BitVec 2) := (_get_sib_scale sib)
  let scaled_index : Int := (ash_left_int (BitVec.toInt index) (BitVec.toNatInt scale))
  let effective_addr : Int := ((BitVec.toInt base) +i scaled_index)
  (pure (effective_addr, displacement, nrip_bytes))

def x86_effective_addr_16_disp (proc_mode : proc_mode) (temp_rip : (BitVec 48)) (mod_var : (BitVec 2)) : SailM ((BitVec 64) × Int) := do
  let v_38 := mod_var
  (if ((eq_bits_nat v_38 0) : Bool)
  then (do (pure (0x0000000000000000#64, 0)))
  else
    (do (if ((eq_bits_nat v_38 1) : Bool)
        then
          (do let byte ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
              (pure (byte, 1)))
        else
          (do (if ((eq_bits_nat v_38 2) : Bool)
              then
                (do let word ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 2 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                    (pure (word, 2)))
              else (do (x86_model_error "mod-value-wrong")))))))

def x86_effective_addr_16 (proc_mode : proc_mode) (temp_rip : (BitVec 48)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) : SailM ((BitVec 16) × Int) := do
  let v_41 := r_m
  (if ((eq_bits_nat v_41 0) : Bool)
  then
    (do let bx ← (( do (rr16 0x3#4) ) : SailM (BitVec 16) )
        let si ← (( do (rr16 0x6#4) ) : SailM (BitVec 16) )
        let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
        (pure ((bits_of_int ((BitVec.toNatInt bx) +i ((BitVec.toNatInt si) +i (BitVec.toInt disp))) 16), increment_rip_by)))
  else
    (do (if ((eq_bits_nat v_41 1) : Bool)
        then
          (do let bx ← (( do (rr16 0x3#4) ) : SailM (BitVec 16) )
              let di ← (( do (rr16 0x7#4) ) : SailM (BitVec 16) )
              let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
              (pure ((bits_of_int ((BitVec.toNatInt bx) +i ((BitVec.toNatInt di) +i (BitVec.toInt disp))) 16), increment_rip_by)))
        else
          (do (if ((eq_bits_nat v_41 2) : Bool)
              then
                (do let bp ← (( do (rr16 0x5#4) ) : SailM (BitVec 16) )
                    let si ← (( do (rr16 0x6#4) ) : SailM (BitVec 16) )
                    let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                    (pure ((bits_of_int ((BitVec.toNatInt bp) +i ((BitVec.toNatInt si) +i (BitVec.toInt disp))) 16), increment_rip_by)))
              else
                (do (if ((eq_bits_nat v_41 3) : Bool)
                    then
                      (do let bp ← (( do (rr16 0x5#4) ) : SailM (BitVec 16) )
                          let di ← (( do (rr16 0x7#4) ) : SailM (BitVec 16) )
                          let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                          (pure ((bits_of_int ((BitVec.toNatInt bp) +i ((BitVec.toNatInt di) +i (BitVec.toInt disp))) 16), increment_rip_by)))
                    else
                      (do (if ((eq_bits_nat v_41 4) : Bool)
                          then
                            (do let si ← (( do (rr16 0x6#4) ) : SailM (BitVec 16) )
                                let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                                (pure ((bits_of_int ((BitVec.toNatInt si) +i (BitVec.toInt disp)) 16), increment_rip_by)))
                          else
                            (do (if ((eq_bits_nat v_41 5) : Bool)
                                then
                                  (do let di ← (( do (rr16 0x7#4) ) : SailM (BitVec 16) )
                                      let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                                      (pure ((bits_of_int ((BitVec.toNatInt di) +i (BitVec.toInt disp)) 16), increment_rip_by)))
                                else
                                  (do (if ((eq_bits_nat v_41 6) : Bool)
                                      then
                                        (do let v_48 := mod_var
                                            (if ((eq_bits_nat v_48 0) : Bool)
                                            then
                                              (do let disp ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 2 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                                                  (pure ((Sail.BitVec.truncate disp 16), 2)))
                                            else
                                              (do let bp ← (( do (rr16 0x5#4) ) : SailM (BitVec 16) )
                                                  let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                                                  (pure ((bits_of_int ((BitVec.toNatInt bp) +i (BitVec.toInt disp)) 16), increment_rip_by)))))
                                      else
                                        (do (if ((eq_bits_nat v_41 7) : Bool)
                                            then
                                              (do let bx ← (( do (rr16 0x3#4) ) : SailM (BitVec 16) )
                                                  let (disp, increment_rip_by) ← (( do (x86_effective_addr_16_disp proc_mode temp_rip mod_var) ) : SailM ((sbits 64) × Int) )
                                                  (pure ((bits_of_int ((BitVec.toNatInt bx) +i (BitVec.toInt disp)) 16), increment_rip_by)))
                                            else (do (x86_model_error ":R/M-OUT-OF-RANGE")))))))))))))))))

/-- Type quantifiers: k_ex407906_ : Bool -/
def x86_effective_addr_32_64 (proc_mode : proc_mode) (p4 : Bool) (temp_rip : (BitVec 48)) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) (num_imm_bytes : (BitVec 3)) : SailM ((BitVec 64) × Int) := do
  let (addr, displacement, increment_rip_by) ← (( do
    let v_50 := mod_var
    (if ((eq_bits_nat v_50 0) : Bool)
    then
      (do let v_51 := r_m
          (if ((eq_bits_nat v_51 4) : Bool)
          then (do (x86_effective_addr_from_sib proc_mode temp_rip rex_byte mod_var sib))
          else
            (do (if ((eq_bits_nat v_51 5) : Bool)
                then
                  (do (if ((in_64bit_mode proc_mode) : Bool)
                      then
                        (do let dword ← (( do (rime_size Mode_64bit (← (select_address_size proc_mode none)) 4 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                            let next_rip ← (( do (add_to_iptr Mode_64bit temp_rip (bits_of_int (4 +i (BitVec.toNatInt num_imm_bytes)) 48)) ) : SailM (sbits 48) )
                            (pure ((BitVec.toInt next_rip), dword, 4)))
                      else
                        (do let dword ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 4 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                            (pure ((BitVec.toInt 0x000000000000#48), dword, 4)))))
                else
                  (do (pure ((← do
                          (if ((in_64bit_mode proc_mode) : Bool)
                          then (do (pure (BitVec.toInt (← (rgfi (BitVec.toNatInt (reg_index r_m rex_byte 0b00#2)))))))
                          else (do (pure (BitVec.toInt (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend r_m 4))) 64)))))), 0x0000000000000000#64, 0)))))))
    else
      (do (if ((eq_bits_nat v_50 1) : Bool)
          then
            (do let v_54 := r_m
                (if ((eq_bits_nat v_54 4) : Bool)
                then (do (x86_effective_addr_from_sib proc_mode temp_rip rex_byte mod_var sib))
                else
                  (do let byte2 ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                      let reg ← (( do
                        (if ((in_64bit_mode proc_mode) : Bool)
                        then (do (rgfi (BitVec.toNatInt (reg_index r_m rex_byte 0b00#2))))
                        else (do (pure (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend r_m 4))) 64)))) ) : SailM (sbits 64) )
                      (pure ((BitVec.toInt reg), byte2, 1)))))
          else
            (do (if ((eq_bits_nat v_50 2) : Bool)
                then
                  (do let v_56 := r_m
                      (if ((eq_bits_nat v_56 4) : Bool)
                      then (do (x86_effective_addr_from_sib proc_mode temp_rip rex_byte mod_var sib))
                      else
                        (do let dword ← (( do (rime_size proc_mode (← (select_address_size proc_mode none)) 4 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
                            let reg ← (( do
                              (if ((in_64bit_mode proc_mode) : Bool)
                              then (do (rgfi (BitVec.toNatInt (reg_index r_m rex_byte 0b00#2))))
                              else (do (pure (Sail.BitVec.zeroExtend (← (rr32 (Sail.BitVec.zeroExtend r_m 4))) 64)))) ) : SailM (sbits 64) )
                            (pure ((BitVec.toInt reg), dword, 4)))))
                else (do (x86_model_error "mod-value-wrong"))))))) ) : SailM (Int × (sbits 64) × Int) )
  let dst_base : Int := (addr +i (BitVec.toInt displacement))
  let dst_base : (sbits 64) :=
    if ((in_64bit_mode proc_mode) : Bool)
    then
      (if (p4 : Bool)
      then (Sail.BitVec.zeroExtend (bits_of_int dst_base 32) 64)
      else (bits_of_int dst_base 64))
    else (Sail.BitVec.zeroExtend (bits_of_int dst_base 32) 64)
  (pure (dst_base, increment_rip_by))

def x86_effective_addr (proc_mode : proc_mode) (prefixes : (BitVec 52)) (temp_rip : (BitVec 48)) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) (num_imm_bytes : (BitVec 3)) : SailM ((BitVec 64) × Int) := do
  let p4 := (0x67#8 == (_get_prefixes_adr prefixes))
  (if ((2 == (← (select_address_size proc_mode (some prefixes)))) : Bool)
  then
    (do let (elem1, elem2) ← (( do (x86_effective_addr_16 proc_mode temp_rip r_m mod_var) ) : SailM ((BitVec 16) × Int) )
        (pure ((Sail.BitVec.zeroExtend elem1 64), elem2)))
  else (do (x86_effective_addr_32_64 proc_mode p4 temp_rip rex_byte r_m mod_var sib num_imm_bytes)))

def alignment_checking_enabled_p (_ : Unit) : SailM Bool := do
  let cr0 ← (( do (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg ctrs) 0) 32)) ) : SailM (BitVec 32) )
  let am : (BitVec 1) := (_get_cr0bits_am (Mk_cr0bits cr0))
  let ac ← (( do
    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
    (pure (Sail.BitVec.zeroExtend (_get_rflagsbits_ac rflags_var) 2)) ) : SailM (BitVec 2) )
  let cpl ← (( do (pure (_get_segment_selectorbits_rpl (Mk_segment_selectorbits (GetElem?.getElem! (← readReg seg_visibles) 1)))) ) : SailM (BitVec 2) )
  (pure ((am == 1#1) && ((ac == 0b01#2) && (cpl == 0b11#2))))

/-- Type quantifiers: seg_reg : Nat, k_ex407909_ : Bool, k_ex407908_ : Bool, operand_size : Nat, List.elem operand_size [1, 2, 4, 6, 8, 10, 16], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def x86_operand_from_modr_m_and_sib_bytes (proc_mode : proc_mode) (reg_type : (BitVec 1)) (operand_size : Nat) (inst_ac? : Bool) (memory_ptr? : Bool) (seg_reg : Nat) (prefixes : (BitVec 52)) (temp_rip : (BitVec 48)) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) (num_imm_bytes : (BitVec 3)) : SailM ((BitVec 128) × Int × (BitVec 64)) := do
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib num_imm_bytes))) ) : SailM ((sbits 64) × Int) )
  let operand ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then
      (do (if ((reg_type == 0#1) : Bool)
          then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int operand_size 4) (reg_index r_m rex_byte 0b00#2) rex_byte)) 128)))
          else (do (xmmi_size (bits_of_int operand_size 5) (reg_index r_m rex_byte 0b00#2)))))
    else
      (do let check_alignment? ← (( do (pure inst_ac?) <&&> (do (alignment_checking_enabled_p ())) ) : SailM Bool )
          let addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM Int )
          let base_reg := (select_base_register proc_mode rex_byte r_m mod_var sib)
          (rme_size proc_mode addr_size operand_size addr base_reg seg_reg ":R" check_alignment? memory_ptr?))) ) : SailM (BitVec 128) )
  (pure (operand, increment_rip_by, addr))

/-- Type quantifiers: seg_reg : Nat, k_ex407913_ : Bool, k_ex407912_ : Bool, operand_size : Nat, List.elem operand_size [1, 2, 4, 6, 8, 10, 16], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def x86_operand_to_reg_mem (proc_mode : proc_mode) (operand_size : Nat) (inst_ac? : Bool) (memory_ptr? : Bool) (operand : (BitVec 128)) (seg_reg : Nat) (addr : (BitVec 64)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) : SailM Unit := do
  (if ((mod_var == 0b11#2) : Bool)
  then (do (write_rgfi_size (bits_of_int operand_size 4) (reg_index r_m rex_byte 0b00#2) (Sail.BitVec.truncate operand 64) rex_byte))
  else
    (do let check_alignment? ← (( do (pure inst_ac?) <&&> (do (alignment_checking_enabled_p ())) ) : SailM Bool )
        let addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM Int )
        let base_reg : (Option base_reg_idx) := (select_base_register proc_mode rex_byte r_m mod_var sib)
        (wme_size proc_mode addr_size operand_size addr base_reg seg_reg operand check_alignment? memory_ptr?)))

/-- Type quantifiers: seg_reg : Nat, k_ex407916_ : Bool, operand_size : Nat, List.elem operand_size [4, 8, 16], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def x86_operand_to_xmm_mem (proc_mode : proc_mode) (operand_size : Nat) (inst_ac? : Bool) (operand : (BitVec 128)) (seg_reg : Nat) (addr : (BitVec 64)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) : SailM Unit := do
  (if ((mod_var == 0b11#2) : Bool)
  then (do (write_xmmi_size (bits_of_int operand_size 5) (reg_index r_m rex_byte 0b00#2) (BitVec.toNatInt operand)))
  else
    (do let check_alignment? ← (( do (pure inst_ac?) <&&> (do (alignment_checking_enabled_p ())) ) : SailM Bool )
        let addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM Int )
        let base_reg : (Option base_reg_idx) := (select_base_register proc_mode rex_byte r_m mod_var sib)
        (wme_size proc_mode addr_size operand_size addr base_reg seg_reg operand check_alignment? false)))

/-- Type quantifiers: k_ex407922_ : Bool, k_ex407921_ : Bool, k_ex407920_ : Bool, k_ex407919_ : Bool, k_ex407918_ : Bool -/
def select_operand_size (proc_mode : proc_mode) (byte_operand? : Bool) (rex_byte : (BitVec 8)) (imm? : Bool) (prefixes : (BitVec 52)) (default64? : Bool) (ignore_rex? : Bool) (ignore_p3_64? : Bool) : SailM Int := do
  (if (byte_operand? : Bool)
  then (do (pure 1))
  else
    (do (if ((in_64bit_mode proc_mode) : Bool)
        then
          (do (if (((logbitp_bits 3 rex_byte) && (! ignore_rex?)) : Bool)
              then
                (do (if (imm? : Bool)
                    then (do (pure 4))
                    else (do (pure 8))))
              else
                (do (if (((0x66#8 == (_get_prefixes_opr prefixes)) && (! ignore_p3_64?)) : Bool)
                    then (do (pure 2))
                    else
                      (do (if (default64? : Bool)
                          then (do (pure 8))
                          else (do (pure 4))))))))
        else
          (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
              let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
              let p3? : Bool := (0x66#8 == (_get_prefixes_opr prefixes))
              (if ((cs_d == 1#1) : Bool)
              then
                (do (if (p3? : Bool)
                    then (do (pure 2))
                    else (do (pure 4))))
              else
                (do (if (p3? : Bool)
                    then (do (pure 4))
                    else (do (pure 2)))))))))

def check_instruction_length (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (delta_rip : (BitVec 3)) : (Option Int) :=
  let start_rip : Int := (BitVec.toInt start_rip)
  let temp_rip : Int := (BitVec.toInt temp_rip)
  let delta_rip : Nat := (BitVec.toNatInt delta_rip)
  let end_rip : (sbits 49) := (bits_of_int ((BitVec.toInt (bits_of_int temp_rip 48)) +i (BitVec.toNatInt (bits_of_int delta_rip 3))) 49)
  let length : (sbits 50) := (bits_of_int ((BitVec.toInt end_rip) -i (BitVec.toInt (bits_of_int start_rip 48))) 50)
  if ((15 <b (BitVec.toInt length)) : Bool)
  then (some (BitVec.toInt length))
  else none

/-- Type quantifiers: operation : Nat, 0 ≤ operation ∧ operation ≤ 8 -/
def x86_add_adc_sub_sbb_or_and_xor_cmp_test_e_g (operation : Nat) (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-ADD/ADC/SUB/SBB/OR/AND/XOR/CMP/TEST-E-G"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := (0#1 == (Sail.BitVec.truncate (0x01#8 &&& opcode) 1))
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let g ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (e, increment_rip_by, e_addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec operand_size operation (Sail.BitVec.truncate e 64) g input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (if (((operation == 8) || (operation == 7)) : Bool)
  then (do (pure ()))
  else (do (x86_operand_to_reg_mem proc_mode operand_size inst_ac? false (Sail.BitVec.zeroExtend result 128) seg_reg e_addr prefixes rex_byte r_m mod_var sib)))
  (write_user_rflags output_rflags undefined_flags)
  (write_iptr proc_mode temp_rip)

/-- Type quantifiers: operation : Nat, 0 ≤ operation ∧ operation ≤ 8 -/
def x86_add_adc_sub_sbb_or_and_xor_cmp_g_e (operation : Nat) (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-ADD/ADC/SUB/SBB/OR/AND/XOR/CMP-G-E"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := (0#1 == (Sail.BitVec.truncate (0x01#8 &&& opcode) 1))
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let g ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (e, increment_rip_by, e_addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec operand_size operation g (Sail.BitVec.truncate e 64) input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (if ((operation == 8) : Bool)
  then (do (pure ()))
  else (do (write_rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) result rex_byte)))
  (write_user_rflags output_rflags undefined_flags)
  (write_iptr proc_mode temp_rip)

/-- Type quantifiers: operation : Nat, 0 ≤ operation ∧ operation ≤ 8 -/
def x86_add_adc_sub_sbb_or_and_xor_cmp_test_e_i (operation : Nat) (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-ADD/ADC/SUB/SBB/OR/AND/XOR/CMP-TEST-E-I"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let e_byte_operand? : Bool := ((opcode == 0x80#8) || ((opcode == 0x82#8) || (opcode == 0xF6#8)))
  let e_size ← (( do (select_operand_size proc_mode e_byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let imm_byte_operand? : Bool := ((opcode == 0x80#8) || ((opcode == 0x82#8) || ((opcode == 0x83#8) || (opcode == 0xF6#8))))
  let imm_size ← (( do (check_range 1 4 (← (select_operand_size proc_mode imm_byte_operand? rex_byte true prefixes false false false))) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (e, increment_rip_by, e_addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 e_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib (bits_of_int imm_size 3)) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int increment_rip_by 48)) ) : SailM (sbits 48) )
  let imm ← (( do (pure (Sail.BitVec.truncate (← (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) imm_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false)) 32)) ) : SailM (BitVec 32) )
  let imm ← (( do (pure (loghead_int (ash_left_int e_size 3) (← (binary_logext (ash_left_int imm_size 3) (BitVec.toNatInt imm))))) ) : SailM Int )
  let temp_rip ← (( do (pure (Sail.BitVec.signExtend (← (add_to_iptr proc_mode temp_rip (bits_of_int imm_size 48))) 49)) ) : SailM (sbits 49) )
  let badlength? : (Option Int) := (check_instruction_length start_rip (Sail.BitVec.truncate temp_rip 48) 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec e_size operation (Sail.BitVec.truncate e 64) (bits_of_int imm 64) input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (if (((operation == 8) || (operation == 7)) : Bool)
  then (do (pure ()))
  else (do (x86_operand_to_reg_mem proc_mode e_size inst_ac? false (Sail.BitVec.zeroExtend result 128) seg_reg e_addr prefixes rex_byte r_m mod_var sib)))
  (write_user_rflags output_rflags undefined_flags)
  (write_iptr proc_mode (Sail.BitVec.truncate temp_rip 48))

/-- Type quantifiers: operation : Nat, 0 ≤ operation ∧ operation ≤ 8 -/
def x86_add_adc_sub_sbb_or_and_xor_cmp_test_rax_i (operation : Nat) (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-ADD/ADC/SUB/SBB/OR/AND/XOR/CMP-TEST-RAX-I"
  let byte_operand? : Bool := (0x00#8 == (0x01#8 &&& opcode))
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte true prefixes false false false) ) : SailM Int )
  let rax_size : Int :=
    if ((logbitp_bits 3 rex_byte) : Bool)
    then 8
    else operand_size
  let rax_var ← (( do (rgfi_size (bits_of_int rax_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let imm ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (BitVec 128) )
  let (final_operand_size, imm) : (Int × (BitVec 64)) :=
    if (((! byte_operand?) && (rax_size == 8)) : Bool)
    then (8, (Sail.BitVec.signExtend (Sail.BitVec.truncate imm 32) 64))
    else (operand_size, (Sail.BitVec.zeroExtend (Sail.BitVec.truncate imm 32) 64))
  let temp_rip ← (( do (pure (Sail.BitVec.signExtend (← (add_to_iptr proc_mode temp_rip (bits_of_int operand_size 48))) 49)) ) : SailM (sbits 49) )
  let badlength? : (Option Int) := (check_instruction_length start_rip (Sail.BitVec.truncate temp_rip 48) 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec rax_size operation rax_var imm input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (if (((operation == 8) || (operation == 7)) : Bool)
  then (do (pure ()))
  else (do (write_rgfi_size (bits_of_int final_operand_size 4) 0x0#4 result rex_byte)))
  (write_user_rflags output_rflags undefined_flags)
  (write_iptr proc_mode (Sail.BitVec.truncate temp_rip 48))

def x86_inc_dec_fe_ff (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-INC/DEC-FE-FF"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (0x00#8 == (0x01#8 &&& opcode))
  let r_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (r_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 r_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let (result, output_rflags, undefined_flags) ← (( do
    (gpr_arith_logic_spec r_mem_size
      (if ((reg == 0b000#3) : Bool)
      then 0
      else 4) (Sail.BitVec.truncate r_mem 64) 0x0000000000000001#64 input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  let output_rflags : rflagsbits := (_update_rflagsbits_cf output_rflags old_cf)
  (write_user_rflags output_rflags undefined_flags)
  (x86_operand_to_reg_mem proc_mode r_mem_size inst_ac? false (Sail.BitVec.zeroExtend result 128) seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def x86_not_neg_f6_f7 (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-NOT/NEG-F6-F7"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (0x00#8 == (0x01#8 &&& opcode))
  let r_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (r_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 r_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do
    let v_57 := reg
    (if ((eq_bits_nat v_57 3) : Bool)
    then (do (gpr_arith_logic_spec r_mem_size 4 0x0000000000000000#64 (Sail.BitVec.truncate r_mem 64) input_rflags))
    else (do (pure ((sail_mask 64 (trunc r_mem_size (Complement.complement r_mem))), (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32))))) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (if ((reg == 0b011#3) : Bool)
  then
    (do let cf : (BitVec 1) :=
          if ((0x00000000000000000000000000000000#128 == r_mem) : Bool)
          then 0#1
          else 1#1
        let output_rflags : rflagsbits := (_update_rflagsbits_cf output_rflags cf)
        (write_user_rflags output_rflags undefined_flags))
  else (do (pure ())))
  (x86_operand_to_reg_mem proc_mode r_mem_size inst_ac? false (Sail.BitVec.zeroExtend result 128) seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def x86_bt_0f_a3 (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-BT-0F-A3"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let bitoffset ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else
      (do let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
          (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let (bitoffset, bitbase) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure ((mod (BitVec.toNatInt bitoffset) (ash_left_int operand_size 3)), (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int operand_size 4) (reg_index r_m rex_byte 0b00#2) rex_byte)) 128))))
    else
      (do let bitoffset_int : (sbits 64) :=
            match operand_size with
            | 1 => (Sail.BitVec.signExtend (Sail.BitVec.truncate bitoffset 8) 64)
            | 2 => (Sail.BitVec.signExtend (Sail.BitVec.truncate bitoffset 16) 64)
            | 4 => (Sail.BitVec.signExtend (Sail.BitVec.truncate bitoffset 32) 64)
            | _ => bitoffset
          let bitoffset_int_abs : Int := (abs (BitVec.toInt bitoffset_int))
          let bitnumber : Int := (mod bitoffset_int_abs 8)
          let byte_addr : Int := ((BitVec.toInt addr) +i (floor2 (BitVec.toInt bitoffset_int) 8))
          let inst_ac? ← (( do (alignment_checking_enabled_p ()) ) : SailM Bool )
          let byte ← (( do
            (if ((← (signed_byte_p_int 64 byte_addr)) : Bool)
            then (do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (bits_of_int byte_addr 64) none seg_reg ":R" inst_ac? false))
            else (do (x86_model_error "EFFECTIVE-ADDRESS-ERROR"))) ) : SailM (BitVec 128) )
          (pure (bitnumber, byte)))) ) : SailM (Int × (BitVec 128)) )
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var (logbit_bits bitoffset bitbase))
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var sailval)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def x86_bt_0f_ba (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-BT-0F-BA"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (bitbase, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b001#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let bitoffset ← (( do (pure (Sail.BitVec.truncate (← (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false)) 8)) ) : SailM (BitVec 8) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip 0x000000000001#48) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let bitoffset ← (( do (check_range 0 64 (mod (BitVec.toNatInt bitoffset) (ash_left_int operand_size 3))) ) : SailM Nat )
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var (logbit_bits bitoffset bitbase))
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var sailval)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def jcc_cmovcc_setcc_spec (opcode : (BitVec 8)) : SailM Bool := do
  let low_nibble : (BitVec 4) := (Sail.BitVec.truncate (opcode &&& 0x0F#8) 4)
  let v_58 := low_nibble
  (if ((eq_bits_nat v_58 0) : Bool)
  then
    (do (pure (1#1 == (← do
              let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
              (pure (_get_rflagsbits_of rflags_var))))))
  else
    (do (if ((eq_bits_nat v_58 1) : Bool)
        then
          (do (pure (0#1 == (← do
                    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                    (pure (_get_rflagsbits_of rflags_var))))))
        else
          (do (if ((eq_bits_nat v_58 2) : Bool)
              then
                (do (pure (1#1 == (← do
                          let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                          (pure (_get_rflagsbits_cf rflags_var))))))
              else
                (do (if ((eq_bits_nat v_58 3) : Bool)
                    then
                      (do (pure (0#1 == (← do
                                let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                (pure (_get_rflagsbits_cf rflags_var))))))
                    else
                      (do (if ((eq_bits_nat v_58 4) : Bool)
                          then
                            (do (pure (1#1 == (← do
                                      let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                      (pure (_get_rflagsbits_zf rflags_var))))))
                          else
                            (do (if ((eq_bits_nat v_58 5) : Bool)
                                then
                                  (do (pure (0#1 == (← do
                                            let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                            (pure (_get_rflagsbits_zf rflags_var))))))
                                else
                                  (do (if ((eq_bits_nat v_58 6) : Bool)
                                      then
                                        (do (pure (1#1 == (← do
                                                  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                  (pure (_get_rflagsbits_cf rflags_var))))) <||> (do
                                              (pure (1#1 == (← do
                                                    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                    (pure (_get_rflagsbits_zf rflags_var)))))))
                                      else
                                        (do (if ((eq_bits_nat v_58 7) : Bool)
                                            then
                                              (do (pure (0#1 == (← do
                                                        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                        (pure (_get_rflagsbits_cf rflags_var))))) <&&> (do
                                                    (pure (0#1 == (← do
                                                          let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                          (pure (_get_rflagsbits_zf rflags_var)))))))
                                            else
                                              (do (if ((eq_bits_nat v_58 8) : Bool)
                                                  then
                                                    (do (pure (1#1 == (← do
                                                              let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                              (pure (_get_rflagsbits_sf rflags_var))))))
                                                  else
                                                    (do (if ((eq_bits_nat v_58 9) : Bool)
                                                        then
                                                          (do (pure (0#1 == (← do
                                                                    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                    (pure (_get_rflagsbits_sf rflags_var))))))
                                                        else
                                                          (do (if ((eq_bits_nat v_58 10) : Bool)
                                                              then
                                                                (do (pure (1#1 == (← do
                                                                          let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                          (pure (_get_rflagsbits_pf rflags_var))))))
                                                              else
                                                                (do (if ((eq_bits_nat v_58 11) : Bool)
                                                                    then
                                                                      (do (pure (0#1 == (← do
                                                                                let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                (pure (_get_rflagsbits_pf rflags_var))))))
                                                                    else
                                                                      (do (if ((eq_bits_nat v_58 12) : Bool)
                                                                          then
                                                                            (do (pure (! ((← do
                                                                                        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                        (pure (_get_rflagsbits_sf rflags_var))) == (← do
                                                                                        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                        (pure (_get_rflagsbits_of rflags_var)))))))
                                                                          else
                                                                            (do (if ((eq_bits_nat v_58 13) : Bool)
                                                                                then
                                                                                  (do (pure ((← do
                                                                                            let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                            (pure (_get_rflagsbits_sf rflags_var))) == (← do
                                                                                            let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                            (pure (_get_rflagsbits_of rflags_var))))))
                                                                                else
                                                                                  (do (if ((eq_bits_nat v_58 14) : Bool)
                                                                                      then
                                                                                        (do (pure (1#1 == (← do
                                                                                                  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                  (pure (_get_rflagsbits_zf rflags_var))))) <||> (do
                                                                                              (pure (! ((← do
                                                                                                      let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                      (pure (_get_rflagsbits_sf rflags_var))) == (← do
                                                                                                      let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                      (pure (_get_rflagsbits_of rflags_var))))))))
                                                                                      else
                                                                                        (do (if ((eq_bits_nat v_58 15) : Bool)
                                                                                            then
                                                                                              (do (pure (0#1 == (← do
                                                                                                        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                        (pure (_get_rflagsbits_zf rflags_var))))) <&&> (do
                                                                                                    (pure ((← do
                                                                                                          let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                          (pure (_get_rflagsbits_sf rflags_var))) == (← do
                                                                                                          let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                                                                                                          (pure (_get_rflagsbits_of rflags_var)))))))
                                                                                            else (do (pure false)))))))))))))))))))))))))))))))))

def x86_one_byte_jcc (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-ONE-BYTE-JCC"
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b001#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let branch_cond ← (( do (jcc_cmovcc_setcc_spec opcode) ) : SailM Bool )
  (if (branch_cond : Bool)
  then
    (do let rel8 ← (( do (rime_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
        let next_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int (1 +i (BitVec.toInt rel8)) 48)) ) : SailM (sbits 48) )
        (write_iptr proc_mode next_rip))
  else
    (do let next_rip ← (( do (add_to_iptr proc_mode temp_rip 0x000000000001#48) ) : SailM (sbits 48) )
        (write_iptr proc_mode next_rip)))

def x86_two_byte_jcc (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-TWO-BYTE-JCC"
  let offset_size ← (( do (check_range 0 4 (← (select_operand_size proc_mode false rex_byte false prefixes false true true))) ) : SailM Int )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip (bits_of_int offset_size 3))
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let branch_cond ← (( do (jcc_cmovcc_setcc_spec opcode) ) : SailM Bool )
  (if (branch_cond : Bool)
  then
    (do let offset ← (( do (rime_size proc_mode (← (select_address_size proc_mode (some prefixes))) offset_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (sbits 64) )
        let next_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int (offset_size +i (BitVec.toInt offset)) 48)) ) : SailM (sbits 48) )
        (write_iptr proc_mode next_rip))
  else
    (do let next_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int offset_size 48)) ) : SailM (sbits 48) )
        (write_iptr proc_mode next_rip)))

def x86_cmovcc (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-CMOVCC"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let branch_cond ← (( do (jcc_cmovcc_setcc_spec opcode) ) : SailM Bool )
  (if (branch_cond : Bool)
  then (do (write_rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate reg_mem 64) rex_byte))
  else
    (do (if (((operand_size == 4) && ((in_64bit_mode proc_mode) || (in_compatibility_mode proc_mode))) : Bool)
        then (do (wr32 (reg_index reg rex_byte 0b10#2) (← (rr32 (reg_index reg rex_byte 0b10#2)))))
        else (do (pure ())))))
  (write_iptr proc_mode temp_rip)

def x86_setcc (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-SETCC"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let branch_cond ← (( do (jcc_cmovcc_setcc_spec opcode) ) : SailM Bool )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let sailval : Int :=
    if (branch_cond : Bool)
    then 1
    else 0
  (x86_operand_to_reg_mem proc_mode 1 inst_ac? false (bits_of_int sailval 128) seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)


end X86Sail.Functions
