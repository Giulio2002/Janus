import X86Sail.Part07

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def pf_spec8 (result : (BitVec 8)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (logbitp_int 0 (logcount_int (BitVec.toNatInt result)))))))

def pf_spec16 (result : (BitVec 16)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (logbitp_int 0 (logcount_int (BitVec.toNatInt (loghead_bits 8 result))))))))

def pf_spec32 (result : (BitVec 32)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (logbitp_int 0 (logcount_int (BitVec.toNatInt (loghead_bits 8 result))))))))

def pf_spec64 (result : (BitVec 64)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (logbitp_int 0 (logcount_int (BitVec.toNatInt (loghead_bits 8 result))))))))

def sf_spec8 (result : (BitVec 8)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb result 7 7)

def sf_spec16 (result : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb result 15 15)

def sf_spec32 (result : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb result 31 31)

def sf_spec64 (result : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb result 63 63)

def add_af_spec8 (dst : (BitVec 8)) (src : (BitVec 8)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let add : (BitVec 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits (15 <b (BitVec.toNatInt add)))

def add_af_spec16 (dst : (BitVec 16)) (src : (BitVec 16)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let add : (BitVec 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits (15 <b (BitVec.toNatInt add)))

def add_af_spec32 (dst : (BitVec 32)) (src : (BitVec 32)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let add : (BitVec 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits (15 <b (BitVec.toNatInt add)))

def add_af_spec64 (dst : (BitVec 64)) (src : (BitVec 64)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let add : (BitVec 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits (15 <b (BitVec.toNatInt add)))

def sub_af_spec8 (dst : (BitVec 8)) (src : (BitVec 8)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sub : (sbits 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) -i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits ((BitVec.toInt sub) <b 0))

def sub_af_spec16 (dst : (BitVec 16)) (src : (BitVec 16)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sub : (sbits 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) -i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits ((BitVec.toInt sub) <b 0))

def sub_af_spec32 (dst : (BitVec 32)) (src : (BitVec 32)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sub : (sbits 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) -i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits ((BitVec.toInt sub) <b 0))

def sub_af_spec64 (dst : (BitVec 64)) (src : (BitVec 64)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sub : (sbits 5) := (bits_of_int ((BitVec.toNatInt dst_3_0) -i (BitVec.toNatInt src_3_0)) 5)
  (bool_to_bits ((BitVec.toInt sub) <b 0))

def adc_af_spec8 (dst : (BitVec 8)) (src : (BitVec 8)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let adc : (BitVec 6) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt cf))) 6)
  (bool_to_bits (15 <b (BitVec.toNatInt adc)))

def adc_af_spec16 (dst : (BitVec 16)) (src : (BitVec 16)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let adc : (BitVec 6) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt cf))) 6)
  (bool_to_bits (15 <b (BitVec.toNatInt adc)))

def adc_af_spec32 (dst : (BitVec 32)) (src : (BitVec 32)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let adc : (BitVec 6) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt cf))) 6)
  (bool_to_bits (15 <b (BitVec.toNatInt adc)))

def adc_af_spec64 (dst : (BitVec 64)) (src : (BitVec 64)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let adc : (BitVec 6) := (bits_of_int ((BitVec.toNatInt dst_3_0) +i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt cf))) 6)
  (bool_to_bits (15 <b (BitVec.toNatInt adc)))

def sbb_af_spec8 (dst : (BitVec 8)) (src : (BitVec 8)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sbb : Int := ((BitVec.toNatInt dst_3_0) -i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt (Sail.BitVec.zeroExtend cf 4))))
  (bool_to_bits (sbb <b 0))

def sbb_af_spec16 (dst : (BitVec 16)) (src : (BitVec 16)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sbb : Int := ((BitVec.toNatInt dst_3_0) -i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt (Sail.BitVec.zeroExtend cf 4))))
  (bool_to_bits (sbb <b 0))

def sbb_af_spec32 (dst : (BitVec 32)) (src : (BitVec 32)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sbb : Int := ((BitVec.toNatInt dst_3_0) -i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt (Sail.BitVec.zeroExtend cf 4))))
  (bool_to_bits (sbb <b 0))

def sbb_af_spec64 (dst : (BitVec 64)) (src : (BitVec 64)) (cf : (BitVec 1)) : (BitVec 1) :=
  let dst_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb dst 3 0)
  let src_3_0 : (BitVec 4) := (Sail.BitVec.extractLsb src 3 0)
  let sbb : Int := ((BitVec.toNatInt dst_3_0) -i ((BitVec.toNatInt src_3_0) +i (BitVec.toNatInt (Sail.BitVec.zeroExtend cf 4))))
  (bool_to_bits (sbb <b 0))

def gpr_add_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : (BitVec 9) := (bits_of_int ((BitVec.toNatInt dst) +i (BitVec.toNatInt src)) 9)
  let signed_raw_result : (sbits 9) := (bits_of_int ((BitVec.toInt dst) +i (BitVec.toInt src)) 9)
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let cf ← (( do (cf_spec8 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (add_af_spec8 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of ← (( do (of_spec8 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_add_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : (BitVec 17) := (bits_of_int ((BitVec.toNatInt dst) +i (BitVec.toNatInt src)) 17)
  let signed_raw_result : (sbits 17) := (bits_of_int ((BitVec.toInt dst) +i (BitVec.toInt src)) 17)
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let cf ← (( do (cf_spec16 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (add_af_spec16 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of ← (( do (of_spec16 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_add_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : (BitVec 33) := (bits_of_int ((BitVec.toNatInt dst) +i (BitVec.toNatInt src)) 33)
  let signed_raw_result : (sbits 33) := (bits_of_int ((BitVec.toInt dst) +i (BitVec.toInt src)) 33)
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let cf ← (( do (cf_spec32 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (add_af_spec32 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of ← (( do (of_spec32 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_add_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : (BitVec 65) := (bits_of_int ((BitVec.toNatInt dst) +i (BitVec.toNatInt src)) 65)
  let signed_raw_result : (sbits 65) := (bits_of_int ((BitVec.toInt dst) +i (BitVec.toInt src)) 65)
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let cf ← (( do (cf_spec64 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (add_af_spec64 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of ← (( do (of_spec64 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_adc_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let raw_result : (BitVec 9) := (bits_of_int ((BitVec.toNatInt dst) +i ((BitVec.toNatInt src) +i (BitVec.toNatInt input_cf))) 9)
  let signed_raw_result : (sbits 9) := (bits_of_int ((BitVec.toInt dst) +i ((BitVec.toInt src) +i (BitVec.toNatInt input_cf))) 9)
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let cf ← (( do (cf_spec8 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (adc_af_spec8 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of ← (( do (of_spec8 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_adc_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let raw_result : (BitVec 17) := (bits_of_int ((BitVec.toNatInt dst) +i ((BitVec.toNatInt src) +i (BitVec.toNatInt input_cf))) 17)
  let signed_raw_result : (sbits 17) := (bits_of_int ((BitVec.toInt dst) +i ((BitVec.toInt src) +i (BitVec.toNatInt input_cf))) 17)
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let cf ← (( do (cf_spec16 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (adc_af_spec16 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of ← (( do (of_spec16 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_adc_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let raw_result : (BitVec 33) := (bits_of_int ((BitVec.toNatInt dst) +i ((BitVec.toNatInt src) +i (BitVec.toNatInt input_cf))) 33)
  let signed_raw_result : (sbits 33) := (bits_of_int ((BitVec.toInt dst) +i ((BitVec.toInt src) +i (BitVec.toNatInt input_cf))) 33)
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let cf ← (( do (cf_spec32 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (adc_af_spec32 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of ← (( do (of_spec32 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_adc_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let raw_result : (BitVec 65) := (bits_of_int ((BitVec.toNatInt dst) +i ((BitVec.toNatInt src) +i (BitVec.toNatInt input_cf))) 65)
  let signed_raw_result : (sbits 65) := (bits_of_int ((BitVec.toInt dst) +i ((BitVec.toInt src) +i (BitVec.toNatInt input_cf))) 65)
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let cf ← (( do (cf_spec64 raw_result) ) : SailM (BitVec 1) )
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (adc_af_spec64 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of ← (( do (of_spec64 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sub_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let signed_raw_result : (sbits 9) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt src)) 9)
  let result : (BitVec 8) := (Sail.BitVec.truncate signed_raw_result 8)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt src)))
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sub_af_spec8 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of ← (( do (of_spec8 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sub_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let signed_raw_result : (sbits 17) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt src)) 17)
  let result : (BitVec 16) := (Sail.BitVec.truncate signed_raw_result 16)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt src)))
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sub_af_spec16 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of ← (( do (of_spec16 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sub_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let signed_raw_result : (sbits 33) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt src)) 33)
  let result : (BitVec 32) := (Sail.BitVec.truncate signed_raw_result 32)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt src)))
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sub_af_spec32 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of ← (( do (of_spec32 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sub_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let signed_raw_result : (sbits 65) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt src)) 65)
  let result : (BitVec 64) := (Sail.BitVec.truncate signed_raw_result 64)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt src)))
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sub_af_spec64 dst src)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of ← (( do (of_spec64 signed_raw_result) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sbb_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let signed_raw_result : (sbits 10) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt (bits_of_int ((BitVec.toInt src) +i (BitVec.toNatInt input_cf)) 9))) 10)
  let result : (BitVec 8) := (Sail.BitVec.truncate signed_raw_result 8)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt (bits_of_int ((BitVec.toNatInt input_cf) +i (BitVec.toNatInt src)) 9))))
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sbb_af_spec8 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of ← (( do (of_spec8 (Sail.BitVec.truncate signed_raw_result 9)) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sbb_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let signed_raw_result : (sbits 18) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt (bits_of_int ((BitVec.toInt src) +i (BitVec.toNatInt input_cf)) 17))) 18)
  let result : (BitVec 16) := (Sail.BitVec.truncate signed_raw_result 16)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt (bits_of_int ((BitVec.toNatInt input_cf) +i (BitVec.toNatInt src)) 17))))
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sbb_af_spec16 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of ← (( do (of_spec16 (Sail.BitVec.truncate signed_raw_result 17)) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sbb_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let signed_raw_result : (sbits 34) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt (bits_of_int ((BitVec.toInt src) +i (BitVec.toNatInt input_cf)) 33))) 34)
  let result : (BitVec 32) := (Sail.BitVec.truncate signed_raw_result 32)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt (bits_of_int ((BitVec.toNatInt input_cf) +i (BitVec.toNatInt src)) 33))))
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sbb_af_spec32 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of ← (( do (of_spec32 (Sail.BitVec.truncate signed_raw_result 33)) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_sbb_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let signed_raw_result : (sbits 66) := (bits_of_int ((BitVec.toInt dst) -i (BitVec.toInt (bits_of_int ((BitVec.toInt src) +i (BitVec.toNatInt input_cf)) 65))) 66)
  let result : (BitVec 64) := (Sail.BitVec.truncate signed_raw_result 64)
  let cf : (BitVec 1) := (bool_to_bits ((BitVec.toNatInt dst) <b (BitVec.toNatInt (bits_of_int ((BitVec.toNatInt input_cf) +i (BitVec.toNatInt src)) 65))))
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let af : (BitVec 1) := (sbb_af_spec64 dst src input_cf)
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of ← (( do (of_spec64 (Sail.BitVec.truncate signed_raw_result 65)) ) : SailM (BitVec 1) )
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_af (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) af) zf) sf) of)
  let undefined_flags : rflagsbits := (Mk_rflagsbits 0x00000000#32)
  (pure (result, output_rflags, undefined_flags))

def gpr_or_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (Sail.BitVec.extractLsb (dst ||| src) 7 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_or_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (Sail.BitVec.extractLsb (dst ||| src) 15 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_or_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (Sail.BitVec.extractLsb (dst ||| src) 31 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_or_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (Sail.BitVec.extractLsb (dst ||| src) 63 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_and_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (Sail.BitVec.extractLsb (dst &&& src) 7 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_and_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (Sail.BitVec.extractLsb (dst &&& src) 15 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_and_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (Sail.BitVec.extractLsb (dst &&& src) 31 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_and_spec_8 (dst : (BitVec 64)) (src : (BitVec 64)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (Sail.BitVec.extractLsb (dst &&& src) 63 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec64 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_1 (dst : (BitVec 8)) (src : (BitVec 8)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (Sail.BitVec.extractLsb (logxor dst src) 7 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec8 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_2 (dst : (BitVec 16)) (src : (BitVec 16)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (Sail.BitVec.extractLsb (logxor dst src) 15 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec16 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))

def gpr_xor_spec_4 (dst : (BitVec 32)) (src : (BitVec 32)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (Sail.BitVec.extractLsb (logxor dst src) 31 0)
  let cf : Int := 0
  let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
  let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
  let sf : (BitVec 1) := (sf_spec32 result)
  let of : Int := 0
  let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags (bits_of_int cf 1)) pf) zf) sf) (bits_of_int of 1))
  let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
  (pure (result, output_rflags, undefined_flags))


end X86Sail.Functions
