import Sail
import X86Sail.Defs
import X86Sail.SpecializationV1
import X86Sail.FakeReal
import X86Sail.JanusX86Extras

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

/-- Type quantifiers: x : Int -/
def __id (x : Int) : Int :=
  x

/-- Type quantifiers: k_ex407730_ : Bool, k_ex407729_ : Bool -/
def neq_bool (x : Bool) (y : Bool) : Bool :=
  (! (x == y))

/-- Type quantifiers: y : Nat, k_n : Nat, k_n > 0, 0 ≤ y -/
def eq_bits_nat (x : (BitVec k_n)) (y : Nat) : Bool :=
  ((BitVec.toNatInt x) == y)

/-- Type quantifiers: n : Int, m : Int -/
def _shl_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftl m n)
  else (Int.shiftr m (Neg.neg n))

/-- Type quantifiers: n : Int, m : Int -/
def _shr_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftr m n)
  else (Int.shiftl m (Neg.neg n))

/-- Type quantifiers: m : Int, n : Int -/
def fdiv_int (n : Int) (m : Int) : Int :=
  if (((n <b 0) && (m >b 0)) : Bool)
  then ((Int.tdiv (n +i 1) m) -i 1)
  else
    (if (((n >b 0) && (m <b 0)) : Bool)
    then ((Int.tdiv (n -i 1) m) -i 1)
    else (Int.tdiv n m))

/-- Type quantifiers: m : Int, n : Int -/
def fmod_int (n : Int) (m : Int) : Int :=
  (n -i (m *i (fdiv_int n m)))

/-- Type quantifiers: len : Nat, k_v : Nat, len ≥ 0 ∧ k_v ≥ 0 -/
def sail_mask (len : Nat) (v : (BitVec k_v)) : (BitVec len) :=
  if ((len ≤b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v len)
  else (Sail.BitVec.zeroExtend v len)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def sail_ones (n : Nat) : (BitVec n) :=
  (Complement.complement (BitVec.zero n))

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def slice_mask {n : _} (i : Int) (l : Int) : (BitVec n) :=
  if ((l ≥b n) : Bool)
  then ((sail_ones n) <<< i)
  else
    (let one : (BitVec n) := (sail_mask n (1#1 : (BitVec 1)))
    (((one <<< l) - one) <<< i))

/-- Type quantifiers: n : Nat, n > 0 -/
def to_bytes_le {n : _} (b : (BitVec (8 * n))) : (Vector (BitVec 8) n) := Id.run do
  let res := (vectorInit (BitVec.zero 8))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (vectorUpdate res i (Sail.BitVec.extractLsb b ((8 *i i) +i 7) (8 *i i)))
  (pure loop_vars)

/-- Type quantifiers: n : Nat, n > 0 -/
def from_bytes_le {n : _} (v : (Vector (BitVec 8) n)) : (BitVec (8 * n)) := Id.run do
  let res := (BitVec.zero (8 *i n))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (Sail.BitVec.updateSubrange res ((8 *i i) +i 7) (8 *i i) (GetElem?.getElem! v i))
  (pure loop_vars)

/-- Type quantifiers: k_a : Type -/
def is_none (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => false
  | none => true

/-- Type quantifiers: k_a : Type -/
def is_some (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => true
  | none => false

/-- Type quantifiers: k_n : Int -/
def concat_str_bits (str : String) (x : (BitVec k_n)) : String :=
  (HAppend.hAppend str (BitVec.toFormatted x))

/-- Type quantifiers: x : Int -/
def concat_str_dec (str : String) (x : Int) : String :=
  (HAppend.hAppend str (Int.repr x))

def feature_flag_fn (feature : String) : Int :=
  1

def feature_flags_fn (features : (List String)) : Int :=
  match features with
  | [] => 1
  | (x :: xs) =>
    (if (((feature_flag_fn x) == 0) : Bool)
    then 0
    else (feature_flags_fn xs))

/-- Type quantifiers: k_a : Type -/
def x86_model_error (msg : String) : SailM k_a := do
  sailThrow ((Emsg (HAppend.hAppend "Model error: " msg)))

/-- Type quantifiers: k_a : Type -/
def x86_fault (msg : String) : SailM k_a := do
  sailThrow ((Efault msg))

def undef_read_logic (_ : Unit) : SailM Nat := do
  readReg janus_undef

/-- Type quantifiers: k_ex407779_ : Bool -/
def bool_to_bits (b : Bool) : (BitVec 1) :=
  match b with
  | true => 1#1
  | false => 0#1

def bits_to_bool (b : (BitVec 1)) : Bool :=
  match b with
  | 1 => true
  | _ => false

/-- Type quantifiers: len : Nat, k_v : Nat, len ≥ 0 ∧ k_v ≥ 0 -/
def sail_mask_signed (len : Nat) (v : (BitVec k_v)) : (BitVec len) :=
  if ((len ≤b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v len)
  else (Sail.BitVec.signExtend v len)

/-- Type quantifiers: n : Nat, k_m : Nat, List.elem n [1, 2, 4, 8, 16] ∧ k_m > 0 -/
def trunc (n : Nat) (x : (BitVec k_m)) : (BitVec (8 * n)) :=
  (sail_mask (8 *i n) x)

/-- Type quantifiers: n : Nat, k_m : Nat, List.elem n [1, 2, 4, 8, 16] ∧ k_m > 0 -/
def trunc_signed (n : Nat) (x : (BitVec k_m)) : (BitVec (8 * n)) :=
  (sail_mask_signed (8 *i n) x)

/-- Type quantifiers: k_n : Int, low : Int, width : Int -/
def bitslice (x : (BitVec k_n)) (low : Int) (width : Int) : SailM (BitVec width) := do
  sail_assert (((Sail.BitVec.length x) ≥b 0) && ((low ≥b 0) && (width >b 0))) "prelude.sail:137.38-137.39"
  (if (((low +i width) ≤b (Sail.BitVec.length x)) : Bool)
  then (do (pure (Sail.BitVec.extractLsb x ((low +i width) -i 1) low)))
  else
    (do (if ((low <b ((Sail.BitVec.length x) -i 1)) : Bool)
        then (do (pure ((BitVec.zero ((low +i width) -i (Sail.BitVec.length x))) +++ (Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 1) low))))
        else (do (pure (BitVec.zero width))))))

/-- Type quantifiers: k_n : Int, low : Int, width : Int -/
def signed_bitslice (x : (BitVec k_n)) (low : Int) (width : Int) : SailM (BitVec width) := do
  sail_assert (((Sail.BitVec.length x) ≥b 0) && ((low ≥b 0) && (width >b 0))) "prelude.sail:151.38-151.39"
  (if (((low +i width) ≤b (Sail.BitVec.length x)) : Bool)
  then (do (pure (Sail.BitVec.extractLsb x ((low +i width) -i 1) low)))
  else
    (do (if ((low <b ((Sail.BitVec.length x) -i 1)) : Bool)
        then (do (pure ((BitVec.replicateBits ((BitVec.access x ((Sail.BitVec.length x) -i 1)) : BitVec 1) ((low +i width) -i (Sail.BitVec.length x))) +++ (Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 1) low))))
        else (do (pure (BitVec.zero width))))))

/-- Type quantifiers: n : Int, m : Int, i : Int, n ≤ m -/
def check_range (n : Int) (m : Int) (i : Int) : SailM Int := do
  sail_assert ((n ≤b i) && (i ≤b m)) "prelude.sail:173.23-173.24"
  (pure i)

/-- Type quantifiers: x : Int, n : Nat, n ≥ 0 -/
def bits_of_int (x : Int) (n : Nat) : (BitVec n) :=
  (get_slice_int n x 0)

/-- Type quantifiers: x : Int -/
def isEven (x : Int) : Bool :=
  if (((get_slice_int 1 x 0) == 0#1) : Bool)
  then true
  else false

/-- Type quantifiers: j : Int, i : Int -/
def b_xor (i : Int) (j : Int) : SailM Int := do
  sail_assert ((0 ≤b i) && ((i ≤b 1) && ((0 ≤b j) && (j ≤b 1)))) "prelude.sail:193.41-193.42"
  (if ((i == 0) : Bool)
  then
    (do (if ((j == 0) : Bool)
        then (do (pure 0))
        else (do (pure 1))))
  else
    (do (if ((j == 0) : Bool)
        then (do (pure 1))
        else (do (pure 0)))))

def in_list (x : String) (xs : (List String)) : Bool :=
  match xs with
  | (y :: ys) =>
    (if ((x == y) : Bool)
    then true
    else (in_list x ys))
  | [] => false

/-- Type quantifiers: x : Int, bits : Int -/
def unsigned_byte_p_int (bits : Int) (x : Int) : SailM Bool := do
  sail_assert (bits ≥b 0) "prelude.sail:214.17-214.18"
  (pure ((0 ≤b x) && (x <b (2 ^i bits))))

/-- Type quantifiers: x : Int, bits : Int -/
def signed_byte_p_int (bits : Int) (x : Int) : SailM Bool := do
  sail_assert (bits ≥b 0) "prelude.sail:228.17-228.18"
  (pure (((Neg.neg (2 ^i (bits -i 1))) ≤b x) && (x <b (2 ^i (bits -i 1)))))

/-- Type quantifiers: i : Int, size : Int -/
def loghead_int (size : Int) (i : Int) : Int :=
  if ((size == 0) : Bool)
  then 0
  else (BitVec.toNatInt (get_slice_int size i 0))

/-- Type quantifiers: size : Nat, k_m : Nat, size ≥ 0 ∧ k_m ≥ 0 -/
def loghead_bits (size : Nat) (x : (BitVec k_m)) : (BitVec size) :=
  (sail_mask size x)

/-- Type quantifiers: j : Int, i : Int -/
def logbitp_int (i : Int) (j : Int) : SailM Bool := do
  sail_assert (i ≥b 0) "prelude.sail:291.14-291.15"
  (pure (bits_to_bool (get_slice_int 1 j i)))

/-- Type quantifiers: k_n : Nat, pos : Int, k_n ≥ 0 -/
def logbitp_bits (pos : Int) (x : (BitVec k_n)) : Bool :=
  if (((0 ≤b pos) && (pos <b (Sail.BitVec.length x))) : Bool)
  then ((BitVec.access x pos) == 1#1)
  else false

/-- Type quantifiers: k_n : Nat, pos : Int, k_n ≥ 0 -/
def logbit_bits (pos : Int) (x : (BitVec k_n)) : (BitVec 1) :=
  if (((0 ≤b pos) && (pos <b (Sail.BitVec.length x))) : Bool)
  then ((BitVec.access x pos) : BitVec 1)
  else (0#1 : (BitVec 1))

/-- Type quantifiers: x : Int -/
def lognot_int (x : Int) : Int :=
  ((Neg.neg x) -i 1)

/-- Type quantifiers: x : Int -/
def logcount_int (x : Int) : Int :=
  if ((x == 0) : Bool)
  then 0
  else
    (if ((x <b 0) : Bool)
    then (logcount_int (lognot_int x))
    else
      (if ((isEven x) : Bool)
      then (logcount_int (Int.shiftr x 1))
      else ((logcount_int (Int.shiftr x 1)) +i 1)))
termination_by (let x := x
if ((x <b 0) : Bool)
then (0 -i (2 *i x))
else (2 *i x)).toNat

/-- Type quantifiers: j : Int, i : Int -/
def floor2 (i : Int) (j : Int) : Int :=
  let tdiv := (Int.tdiv i j)
  let tmod := (Int.tmod i j)
  if ((((j >b 0) && (tmod ≥b 0)) || ((j <b 0) && (tmod ≤b 0))) : Bool)
  then tdiv
  else (tdiv -i 1)

/-- Type quantifiers: j : Int, i : Int -/
def logand_int (i : Int) (j : Int) : Int :=
  if ((i == 0) : Bool)
  then 0
  else
    (if ((j == 0) : Bool)
    then 0
    else
      (if ((i == (Neg.neg 1)) : Bool)
      then j
      else
        (if ((j == (Neg.neg 1)) : Bool)
        then i
        else
          (let x := (2 *i (logand_int (floor2 i 2) (floor2 j 2)))
          (x +i (if ((isEven i) : Bool)
            then 0
            else
              (if ((isEven j) : Bool)
              then 0
              else 1)))))))
termination_by (let (i, j) := (i, j)
(Sail.Int.intAbs i)).toNat


end X86Sail.Functions
