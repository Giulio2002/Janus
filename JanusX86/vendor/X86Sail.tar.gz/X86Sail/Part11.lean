import X86Sail.Part10

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def x86_push_ev (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-PUSH-EV"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes true true false) ) : SailM Int )
  let rsp_var ← (( do (read_sptr proc_mode) ) : SailM (sbits 64) )
  let new_rsp ← (( do (add_to_sptr proc_mode rsp_var (bits_of_int (Neg.neg operand_size) 64)) ) : SailM (sbits 64) )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let (e, increment_rip_by, e_addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size true false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (wme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.signExtend (Sail.BitVec.truncate new_rsp 48) 64) none 2 e (← (alignment_checking_enabled_p ())) false)
  (write_sptr proc_mode new_rsp)
  (write_iptr proc_mode temp_rip)

def x86_push_i (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-PUSH-I"
  let byte_imm? : Bool := (opcode == 0x6A#8)
  let imm_size ← (( do (select_operand_size proc_mode byte_imm? rex_byte true prefixes false false false) ) : SailM Int )
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes true false false) ) : SailM Int )
  let rsp_var ← (( do (read_sptr proc_mode) ) : SailM (sbits 64) )
  let new_rsp ← (( do (add_to_sptr proc_mode rsp_var (bits_of_int (Neg.neg operand_size) 64)) ) : SailM (sbits 64) )
  let imm ← (( do (pure (Sail.BitVec.truncate (← (rime_size proc_mode (← (select_address_size proc_mode (some prefixes))) imm_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false)) 32)) ) : SailM (sbits 32) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int imm_size 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (wme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size new_rsp none 2 (bits_of_int (loghead_int (ash_left_int operand_size 3) (BitVec.toInt imm)) 128) (← (alignment_checking_enabled_p ())) false)
  (write_sptr proc_mode new_rsp)
  (write_iptr proc_mode temp_rip)

def x86_pop_general_register (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-POP-GENERAL-REGISTER"
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes true false false) ) : SailM Int )
  let rsp_var ← (( do (read_sptr proc_mode) ) : SailM (sbits 64) )
  let new_rsp ← (( do (add_to_sptr proc_mode rsp_var (bits_of_int operand_size 64)) ) : SailM (sbits 64) )
  let sailval ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size rsp_var none 2 ":R" (← (alignment_checking_enabled_p ())) false) ) : SailM (BitVec 128) )
  let reg : (BitVec 8) := (opcode &&& 0x07#8)
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_sptr proc_mode new_rsp)
  (write_rgfi_size (bits_of_int operand_size 4) (reg_index (Sail.BitVec.truncate reg 3) rex_byte 0b00#2) (Sail.BitVec.truncate sailval 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_pop_ev (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-POP-EV"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes true true false) ) : SailM Int )
  let rsp_var ← (( do (read_sptr proc_mode) ) : SailM (sbits 64) )
  let new_rsp ← (( do (add_to_sptr proc_mode rsp_var (bits_of_int operand_size 64)) ) : SailM (sbits 64) )
  let check_alignment? ← (( do (alignment_checking_enabled_p ()) ) : SailM Bool )
  let sailval ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size rsp_var none 2 ":R" check_alignment? false) ) : SailM (BitVec 128) )
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_sptr proc_mode new_rsp)
  (x86_operand_to_reg_mem proc_mode operand_size check_alignment? false sailval seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def sal_shl_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 8) := (bits_of_int raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_79 := src
    (if ((eq_bits_nat v_79 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_79 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 7 7)
                let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec8 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 7 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((8 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (8 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sal_shl_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 16) := (bits_of_int raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_81 := src
    (if ((eq_bits_nat v_81 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_81 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 15 15)
                let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec16 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 15 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((16 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (16 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sal_shl_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 32) := (bits_of_int raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_83 := src
    (if ((eq_bits_nat v_83 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_83 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (32 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sal_shl_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 64) := (bits_of_int raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_85 := src
    (if ((eq_bits_nat v_85 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_85 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (64 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def sal_shl_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (sal_shl_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shr_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 9) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 9)
  let raw_result : (BitVec 8) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 8)
  let result : (BitVec 8) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_87 := src
    (if ((eq_bits_nat v_87 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_87 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec8 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 7 7)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((8 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 17)
  let raw_result : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 16)
  let result : (BitVec 16) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_89 := src
    (if ((eq_bits_nat v_89 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_89 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec16 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 15 15)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((16 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 33)
  let raw_result : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 32)
  let result : (BitVec 32) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_91 := src
    (if ((eq_bits_nat v_91 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_91 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 65)
  let raw_result : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 64)
  let result : (BitVec 64) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_93 := src
    (if ((eq_bits_nat v_93 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_93 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def shr_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (shr_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def sar_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 9) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 9)
  let raw_result_not_sign_extended : (BitVec 8) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 8)
  let raw_result ← (( do
    (if (((logbit_bits 7 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 8 (ash_int (← (binary_logext 8 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 8) := (bits_of_int raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_95 := src
    (if ((eq_bits_nat v_95 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_95 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec8 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((8 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 17)
  let raw_result_not_sign_extended : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 16)
  let raw_result ← (( do
    (if (((logbit_bits 15 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 16 (ash_int (← (binary_logext 16 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 16) := (bits_of_int raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_97 := src
    (if ((eq_bits_nat v_97 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_97 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec16 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((16 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 33)
  let raw_result_not_sign_extended : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 32)
  let raw_result ← (( do
    (if (((logbit_bits 31 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 32 (ash_int (← (binary_logext 32 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 32) := (bits_of_int raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_99 := src
    (if ((eq_bits_nat v_99 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_99 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 65)
  let raw_result_not_sign_extended : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 64)
  let raw_result ← (( do
    (if (((logbit_bits 63 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 64 (ash_int (← (binary_logext 64 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 64) := (bits_of_int raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_101 := src
    (if ((eq_bits_nat v_101 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_101 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def sar_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (sar_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shld_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 32) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 16) 32) ||| (Sail.BitVec.zeroExtend src 32))
  let output_dst : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 16)) -i 16)) 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_103 := cnt
    (if ((eq_bits_nat v_103 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_103 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 15 15)
                let of : Int :=
                  if (((logbit_bits 15 dst) == (logbit_bits 15 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec16 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 16) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (16 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec16 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 16), output_rflags, undefined_flags))

def shld_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 64) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 32) 64) ||| (Sail.BitVec.zeroExtend src 64))
  let output_dst : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 32)) -i 32)) 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_105 := cnt
    (if ((eq_bits_nat v_105 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_105 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let of : Int :=
                  if (((logbit_bits 31 dst) == (logbit_bits 31 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec32 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 32) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (32 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec32 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 32), output_rflags, undefined_flags))

def shld_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 128) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 64) 128) ||| (Sail.BitVec.zeroExtend src 128))
  let output_dst : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 64)) -i 64)) 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_107 := cnt
    (if ((eq_bits_nat v_107 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_107 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let of : Int :=
                  if (((logbit_bits 63 dst) == (logbit_bits 63 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec64 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 64) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (64 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec64 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 64), output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [2, 4, 8] -/
def shld_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 2 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shld_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16) cnt input_rflags) ) : SailM ((BitVec 16) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 4 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shld_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32) cnt input_rflags) ) : SailM ((BitVec 32) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 8 => (shld_spec_64 dst src cnt input_rflags)
  | _ => (pure (0x0000000000000000#64, false, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shrd_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 32) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 16) 32) ||| (Sail.BitVec.zeroExtend dst 32))
  let neg_cnt : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 17)
  let output_dst : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_109 := cnt
    (if ((eq_bits_nat v_109 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_109 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 15 dst) == (logbit_bits 15 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec16 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 16) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec16 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 16), output_rflags, undefined_flags))

def shrd_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 64) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 32) 64) ||| (Sail.BitVec.zeroExtend dst 64))
  let neg_cnt : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 33)
  let output_dst : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_111 := cnt
    (if ((eq_bits_nat v_111 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_111 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 31 dst) == (logbit_bits 31 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec32 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 32) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec32 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 32), output_rflags, undefined_flags))

def shrd_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 128) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 64) 128) ||| (Sail.BitVec.zeroExtend dst 128))
  let neg_cnt : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 65)
  let output_dst : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_113 := cnt
    (if ((eq_bits_nat v_113 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_113 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 63 dst) == (logbit_bits 63 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec64 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 64) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec64 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 64), output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [2, 4, 8] -/
def shrd_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 2 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shrd_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16) cnt input_rflags) ) : SailM ((BitVec 16) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 4 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shrd_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32) cnt input_rflags) ) : SailM ((BitVec 32) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 8 => (shrd_spec_64 dst src cnt input_rflags)
  | _ => (pure (0x0000000000000000#64, false, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rcl_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 9) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 9) 8 1 old_cf)
  let raw_result : (BitVec 9) := (rotate_left_bits new_dst 9 (BitVec.toNatInt src))
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_115 := src
    (if ((eq_bits_nat v_115 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_115 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 7 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 17) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 17) 16 1 old_cf)
  let raw_result : (BitVec 17) := (rotate_left_bits new_dst 17 (BitVec.toNatInt src))
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_117 := src
    (if ((eq_bits_nat v_117 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_117 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 15 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 33) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 33) 32 1 old_cf)
  let raw_result : (BitVec 33) := (rotate_left_bits new_dst 33 (BitVec.toNatInt src))
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_119 := src
    (if ((eq_bits_nat v_119 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_119 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 65) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 65) 64 1 old_cf)
  let raw_result : (BitVec 65) := (rotate_left_bits new_dst 65 (BitVec.toNatInt src))
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_121 := src
    (if ((eq_bits_nat v_121 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_121 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rcl_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rcl_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rol_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (rotate_left_bits dst 8 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_123 := src
    (if ((eq_bits_nat v_123 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_123 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 7 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (rotate_left_bits dst 16 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_125 := src
    (if ((eq_bits_nat v_125 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_125 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 15 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (rotate_left_bits dst 32 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_127 := src
    (if ((eq_bits_nat v_127 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_127 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (rotate_left_bits dst 64 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_129 := src
    (if ((eq_bits_nat v_129 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_129 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rol_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rol_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rcr_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 9) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 9) 8 1 input_cf)
  let raw_result : (BitVec 9) := (rotate_right_bits new_dst 9 (BitVec.toNatInt src))
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_131 := src
    (if ((eq_bits_nat v_131 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_131 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 7 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 6 6))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 17) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 17) 16 1 input_cf)
  let raw_result : (BitVec 17) := (rotate_right_bits new_dst 17 (BitVec.toNatInt src))
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_133 := src
    (if ((eq_bits_nat v_133 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_133 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 15 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 14 14))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 33) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 33) 32 1 input_cf)
  let raw_result : (BitVec 33) := (rotate_right_bits new_dst 33 (BitVec.toNatInt src))
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_135 := src
    (if ((eq_bits_nat v_135 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_135 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 31 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 30 30))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 65) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 65) 64 1 input_cf)
  let raw_result : (BitVec 65) := (rotate_right_bits new_dst 65 (BitVec.toNatInt src))
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_137 := src
    (if ((eq_bits_nat v_137 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_137 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 63 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 62 62))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rcr_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rcr_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def ror_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (rotate_right_bits dst 8 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_139 := src
    (if ((eq_bits_nat v_139 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_139 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 7 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 7 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 6 6))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def ror_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (rotate_right_bits dst 16 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_141 := src
    (if ((eq_bits_nat v_141 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_141 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 15 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 15 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 14 14))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))


end X86Sail.Functions
