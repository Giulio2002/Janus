import X86Sail.Part10

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def sal_shl_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 32) := (bits_of_int raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_83 := src
    (if ((eq_bits_nat v_83 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_83 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (32 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sal_shl_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let raw_result : Int := (ash_left_int (BitVec.toNatInt dst) (BitVec.toNatInt src))
  let result : (BitVec 64) := (bits_of_int raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_85 := src
    (if ((eq_bits_nat v_85 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_85 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst (64 -i (BitVec.toNatInt src)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def sal_shl_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sal_shl_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (sal_shl_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shr_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 9) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 9)
  let raw_result : (BitVec 8) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 8)
  let result : (BitVec 8) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_87 := src
    (if ((eq_bits_nat v_87 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_87 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec8 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 7 7)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((8 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 17)
  let raw_result : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 16)
  let result : (BitVec 16) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_89 := src
    (if ((eq_bits_nat v_89 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_89 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec16 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 15 15)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((16 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 33)
  let raw_result : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 32)
  let result : (BitVec 32) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_91 := src
    (if ((eq_bits_nat v_91 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_91 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def shr_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 65)
  let raw_result : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 64)
  let result : (BitVec 64) := raw_result
  let (output_rflags, undefined_flags) ← (( do
    let v_93 := src
    (if ((eq_bits_nat v_93 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_93 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) of)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def shr_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (shr_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (shr_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def sar_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 9) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 9)
  let raw_result_not_sign_extended : (BitVec 8) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 8)
  let raw_result ← (( do
    (if (((logbit_bits 7 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 8 (ash_int (← (binary_logext 8 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 8) := (bits_of_int raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_95 := src
    (if ((eq_bits_nat v_95 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_95 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec8 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((8 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec8 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec8 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 17)
  let raw_result_not_sign_extended : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 16)
  let raw_result ← (( do
    (if (((logbit_bits 15 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 16 (ash_int (← (binary_logext 16 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 16) := (bits_of_int raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_97 := src
    (if ((eq_bits_nat v_97 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_97 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec16 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((16 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec16 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 33)
  let raw_result_not_sign_extended : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 32)
  let raw_result ← (( do
    (if (((logbit_bits 31 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 32 (ash_int (← (binary_logext 32 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 32) := (bits_of_int raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_99 := src
    (if ((eq_bits_nat v_99 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_99 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec32 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((32 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec32 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def sar_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let neg_src : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt src)) 65)
  let raw_result_not_sign_extended : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst) (BitVec.toInt neg_src)) 64)
  let raw_result ← (( do
    (if (((logbit_bits 63 dst) == 1#1) : Bool)
    then (do (pure (loghead_int 64 (ash_int (← (binary_logext 64 (BitVec.toNatInt dst))) (BitVec.toInt neg_src)))))
    else (do (pure (BitVec.toNatInt raw_result_not_sign_extended)))) ) : SailM Int )
  let result : (BitVec 64) := (bits_of_int raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_101 := src
    (if ((eq_bits_nat v_101 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_101 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                let sf : (BitVec 1) := (sf_spec64 result)
                let of : Int := 0
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf) (bits_of_int of 1))
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if ((64 ≤b (BitVec.toNatInt src)) : Bool)
                then
                  (do let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf input_rflags pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (_update_rflagsbits_cf (Mk_rflagsbits 0x00000000#32) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt src) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 result) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt result))
                      let sf : (BitVec 1) := (sf_spec64 result)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def sar_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (sar_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (sar_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shld_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 32) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 16) 32) ||| (Sail.BitVec.zeroExtend src 32))
  let output_dst : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 16)) -i 16)) 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_103 := cnt
    (if ((eq_bits_nat v_103 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_103 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 15 15)
                let of : Int :=
                  if (((logbit_bits 15 dst) == (logbit_bits 15 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec16 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 16) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (16 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec16 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 16), output_rflags, undefined_flags))

def shld_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 64) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 32) 64) ||| (Sail.BitVec.zeroExtend src 64))
  let output_dst : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 32)) -i 32)) 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_105 := cnt
    (if ((eq_bits_nat v_105 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_105 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 31 31)
                let of : Int :=
                  if (((logbit_bits 31 dst) == (logbit_bits 31 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec32 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 32) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (32 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec32 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 32), output_rflags, undefined_flags))

def shld_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  let dst_src : (BitVec 128) := ((bits_of_int (ash_left_int (BitVec.toNatInt dst) 64) 128) ||| (Sail.BitVec.zeroExtend src 128))
  let output_dst : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt dst_src) ((BitVec.toNatInt (Sail.BitVec.zeroExtend cnt 64)) -i 64)) 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_107 := cnt
    (if ((eq_bits_nat v_107 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_107 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 63 63)
                let of : Int :=
                  if (((logbit_bits 63 dst) == (logbit_bits 63 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec64 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 64) : Bool)
                then
                  (do let cf ← (( do (bitslice dst (64 -i (BitVec.toNatInt cnt)) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec64 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 64), output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [2, 4, 8] -/
def shld_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 2 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shld_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16) cnt input_rflags) ) : SailM ((BitVec 16) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 4 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shld_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32) cnt input_rflags) ) : SailM ((BitVec 32) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 8 => (shld_spec_64 dst src cnt input_rflags)
  | _ => (pure (0x0000000000000000#64, false, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def shrd_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 32) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 16) 32) ||| (Sail.BitVec.zeroExtend dst 32))
  let neg_cnt : (sbits 17) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 17)
  let output_dst : (BitVec 16) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_109 := cnt
    (if ((eq_bits_nat v_109 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_109 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 15 dst) == (logbit_bits 15 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec16 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 16) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec16 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec16 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 16), output_rflags, undefined_flags))

def shrd_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 64) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 32) 64) ||| (Sail.BitVec.zeroExtend dst 64))
  let neg_cnt : (sbits 33) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 33)
  let output_dst : (BitVec 32) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_111 := cnt
    (if ((eq_bits_nat v_111 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_111 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 31 dst) == (logbit_bits 31 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec32 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 32) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec32 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec32 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 32), output_rflags, undefined_flags))

def shrd_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  let src_dst : (BitVec 128) := ((bits_of_int (ash_left_int (BitVec.toNatInt src) 64) 128) ||| (Sail.BitVec.zeroExtend dst 128))
  let neg_cnt : (sbits 65) := (bits_of_int (Neg.neg (BitVec.toNatInt cnt)) 65)
  let output_dst : (BitVec 64) := (bits_of_int (ash_int (BitVec.toNatInt src_dst) (BitVec.toInt neg_cnt)) 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_113 := cnt
    (if ((eq_bits_nat v_113 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_113 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb dst 0 0)
                let of : Int :=
                  if (((logbit_bits 63 dst) == (logbit_bits 63 output_dst)) : Bool)
                  then 0
                  else 1
                let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                let sf : (BitVec 1) := (sf_spec64 output_dst)
                let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1)) pf) zf) sf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))
          else
            (do (if (((BitVec.toNatInt cnt) ≤b 64) : Bool)
                then
                  (do let cf ← (( do (bitslice dst ((BitVec.toNatInt cnt) -i 1) 1) ) : SailM (BitVec 1) )
                      let pf ← (( do (pf_spec64 output_dst) ) : SailM (BitVec 1) )
                      let zf : (BitVec 1) := (zf_spec (BitVec.toNatInt output_dst))
                      let sf : (BitVec 1) := (sf_spec64 output_dst)
                      let output_rflags : rflagsbits := (_update_rflagsbits_sf (_update_rflagsbits_zf (_update_rflagsbits_pf (_update_rflagsbits_cf input_rflags cf) pf) zf) sf)
                      let undefined_flags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_af (Mk_rflagsbits 0x00000000#32) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))
                else
                  (do let output_rflags : rflagsbits := input_rflags
                      let undefined_flags : rflagsbits := (_update_rflagsbits_cf (_update_rflagsbits_of (_update_rflagsbits_pf (_update_rflagsbits_zf (_update_rflagsbits_sf (_update_rflagsbits_af input_rflags 1#1) 1#1) 1#1) 1#1) 1#1) 1#1)
                      (pure (output_rflags, undefined_flags)))))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (output_dst, ((BitVec.toNatInt cnt) >b 64), output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [2, 4, 8] -/
def shrd_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) (cnt : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × Bool × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 2 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shrd_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16) cnt input_rflags) ) : SailM ((BitVec 16) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 4 =>
    (do
      let (elem0, elem1, elem2, elem3) ← (( do (shrd_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32) cnt input_rflags) ) : SailM ((BitVec 32) × Bool × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2, elem3)))
  | 8 => (shrd_spec_64 dst src cnt input_rflags)
  | _ => (pure (0x0000000000000000#64, false, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rcl_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 9) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 9) 8 1 old_cf)
  let raw_result : (BitVec 9) := (rotate_left_bits new_dst 9 (BitVec.toNatInt src))
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_115 := src
    (if ((eq_bits_nat v_115 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_115 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 7 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 17) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 17) 16 1 old_cf)
  let raw_result : (BitVec 17) := (rotate_left_bits new_dst 17 (BitVec.toNatInt src))
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_117 := src
    (if ((eq_bits_nat v_117 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_117 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 15 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 33) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 33) 32 1 old_cf)
  let raw_result : (BitVec 33) := (rotate_left_bits new_dst 33 (BitVec.toNatInt src))
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_119 := src
    (if ((eq_bits_nat v_119 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_119 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcl_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let old_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 65) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 65) 64 1 old_cf)
  let raw_result : (BitVec 65) := (rotate_left_bits new_dst 65 (BitVec.toNatInt src))
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_121 := src
    (if ((eq_bits_nat v_121 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_121 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rcl_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcl_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rcl_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rol_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (rotate_left_bits dst 8 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_123 := src
    (if ((eq_bits_nat v_123 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_123 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 7 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (rotate_left_bits dst 16 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_125 := src
    (if ((eq_bits_nat v_125 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_125 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 15 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (rotate_left_bits dst 32 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_127 := src
    (if ((eq_bits_nat v_127 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_127 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 31 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rol_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (rotate_left_bits dst 64 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_129 := src
    (if ((eq_bits_nat v_129 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_129 1) : Bool)
          then
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let of ← (( do (b_xor (BitVec.toNatInt cf) (BitVec.toNatInt (logbit_bits 63 result))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rol_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rol_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rol_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def rcr_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 9) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 9) 8 1 input_cf)
  let raw_result : (BitVec 9) := (rotate_right_bits new_dst 9 (BitVec.toNatInt src))
  let result : (BitVec 8) := (Sail.BitVec.truncate raw_result 8)
  let (output_rflags, undefined_flags) ← (( do
    let v_131 := src
    (if ((eq_bits_nat v_131 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_131 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 7 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 6 6))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 8 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 17) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 17) 16 1 input_cf)
  let raw_result : (BitVec 17) := (rotate_right_bits new_dst 17 (BitVec.toNatInt src))
  let result : (BitVec 16) := (Sail.BitVec.truncate raw_result 16)
  let (output_rflags, undefined_flags) ← (( do
    let v_133 := src
    (if ((eq_bits_nat v_133 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_133 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 15 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 14 14))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 16 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 33) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 33) 32 1 input_cf)
  let raw_result : (BitVec 33) := (rotate_right_bits new_dst 33 (BitVec.toNatInt src))
  let result : (BitVec 32) := (Sail.BitVec.truncate raw_result 32)
  let (output_rflags, undefined_flags) ← (( do
    let v_135 := src
    (if ((eq_bits_nat v_135 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_135 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 31 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 30 30))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 32 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def rcr_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let input_cf : (BitVec 1) := (_get_rflagsbits_cf input_rflags)
  let new_dst : (BitVec 65) := (changeSlice_bits (Sail.BitVec.zeroExtend dst 65) 64 1 input_cf)
  let raw_result : (BitVec 65) := (rotate_right_bits new_dst 65 (BitVec.toNatInt src))
  let result : (BitVec 64) := (Sail.BitVec.truncate raw_result 64)
  let (output_rflags, undefined_flags) ← (( do
    let v_137 := src
    (if ((eq_bits_nat v_137 0) : Bool)
    then (do (pure (input_rflags, (Mk_rflagsbits 0x00000000#32))))
    else
      (do (if ((eq_bits_nat v_137 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 63 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 62 62))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (logbit_bits 64 raw_result)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def rcr_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (rcr_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (rcr_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def ror_spec_8 (dst : (BitVec 8)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 8) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 8) := (rotate_right_bits dst 8 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_139 := src
    (if ((eq_bits_nat v_139 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_139 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 7 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 7 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 6 6))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def ror_spec_16 (dst : (BitVec 16)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 16) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 16) := (rotate_right_bits dst 16 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_141 := src
    (if ((eq_bits_nat v_141 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_141 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 15 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 15 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 14 14))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def ror_spec_32 (dst : (BitVec 32)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 32) := (rotate_right_bits dst 32 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_143 := src
    (if ((eq_bits_nat v_143 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_143 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 31 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 31 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 30 30))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

def ror_spec_64 (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  let result : (BitVec 64) := (rotate_right_bits dst 64 (BitVec.toNatInt src))
  let (output_rflags, undefined_flags) ← (( do
    let v_145 := src
    (if ((eq_bits_nat v_145 0) : Bool)
    then
      (do let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
          (pure (input_rflags, undefined_flags)))
    else
      (do (if ((eq_bits_nat v_145 1) : Bool)
          then
            (do let cf : (BitVec 1) := (logbit_bits 63 result)
                let of ← (( do (b_xor (BitVec.toNatInt (logbit_bits 63 result)) (BitVec.toNatInt (Sail.BitVec.extractLsb result 62 62))) ) : SailM Int )
                let output_rflags : rflagsbits := (_update_rflagsbits_of (_update_rflagsbits_cf input_rflags cf) (bits_of_int of 1))
                (pure (output_rflags, (Mk_rflagsbits 0x00000000#32))))
          else
            (do let cf : (BitVec 1) := (Sail.BitVec.extractLsb result 0 0)
                let output_rflags : rflagsbits := (_update_rflagsbits_cf input_rflags cf)
                let undefined_flags : rflagsbits := (_update_rflagsbits_of (Mk_rflagsbits 0x00000000#32) 1#1)
                (pure (output_rflags, undefined_flags)))))) ) : SailM (rflagsbits × rflagsbits) )
  (pure (result, output_rflags, undefined_flags))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def ror_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 6)) (input_rflags : (BitVec 32)) : SailM ((BitVec 64) × (BitVec 32) × (BitVec 32)) := do
  match size with
  | 1 =>
    (do
      let (elem0, elem1, elem2) ← (( do (ror_spec_8 (Sail.BitVec.truncate dst 8) src input_rflags) ) : SailM ((BitVec 8) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 2 =>
    (do
      let (elem0, elem1, elem2) ← (( do (ror_spec_16 (Sail.BitVec.truncate dst 16) src input_rflags) ) : SailM ((BitVec 16) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 4 =>
    (do
      let (elem0, elem1, elem2) ← (( do (ror_spec_32 (Sail.BitVec.truncate dst 32) src input_rflags) ) : SailM ((BitVec 32) × rflagsbits × rflagsbits) )
      (pure ((Sail.BitVec.zeroExtend elem0 64), elem1, elem2)))
  | 8 => (ror_spec_64 dst src input_rflags)
  | _ => (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32)))

def x86_sal_sar_shl_shr_rcl_rcr_rol_ror (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-SAL/SAR/SHL/SHR/RCL/RCR/ROL/ROR"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := ((opcode == 0xC0#8) || ((opcode == 0xD0#8) || (opcode == 0xD2#8)))
  let reg_mem_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do
    (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib
      (if (((opcode == 0xC0#8) || (opcode == 0xC1#8)) : Bool)
      then 0b001#3
      else 0b000#3)) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let shift_rotate_by ← (( do
    let v_147 := opcode
    (if ((eq_bits_nat v_147 208) : Bool)
    then (do (pure 0x00000000000000000000000000000001#128))
    else
      (do (if ((eq_bits_nat v_147 209) : Bool)
          then (do (pure 0x00000000000000000000000000000001#128))
          else
            (do (if ((eq_bits_nat v_147 210) : Bool)
                then (do (pure (Sail.BitVec.zeroExtend (← (rr08 0x1#4 rex_byte)) 128)))
                else
                  (do (if ((eq_bits_nat v_147 211) : Bool)
                      then (do (pure (Sail.BitVec.zeroExtend (← (rr08 0x1#4 rex_byte)) 128)))
                      else
                        (do (if ((eq_bits_nat v_147 192) : Bool)
                            then (do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false))
                            else
                              (do (if ((eq_bits_nat v_147 193) : Bool)
                                  then (do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false))
                                  else (do (pure 0x00000000000000000000000000000000#128))))))))))))) ) : SailM (BitVec 128) )
  let countmask : Int :=
    if (((logbitp_bits 3 rex_byte) && (! byte_operand?)) : Bool)
    then 63
    else 31
  let shift_rotate_by : (BitVec 128) := ((bits_of_int countmask 128) &&& shift_rotate_by)
  let temp_rip ← (( do
    (if (((opcode == 0xC0#8) || (opcode == 0xC1#8)) : Bool)
    then (do (pure (Sail.BitVec.signExtend (← (add_to_iptr proc_mode temp_rip 0x000000000001#48)) 49)))
    else (do (pure (Sail.BitVec.signExtend temp_rip 49)))) ) : SailM (sbits 49) )
  let badlength? : (Option Int) := (check_instruction_length start_rip (Sail.BitVec.truncate temp_rip 48) 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do
    let v_153 := reg
    (if ((eq_bits_nat v_153 0) : Bool)
    then (do (rol_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
    else
      (do (if ((eq_bits_nat v_153 1) : Bool)
          then (do (ror_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
          else
            (do (if ((eq_bits_nat v_153 2) : Bool)
                then (do (rcl_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
                else
                  (do (if ((eq_bits_nat v_153 3) : Bool)
                      then (do (rcr_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
                      else
                        (do (if ((eq_bits_nat v_153 4) : Bool)
                            then (do (sal_shl_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
                            else
                              (do (if ((eq_bits_nat v_153 5) : Bool)
                                  then (do (shr_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
                                  else
                                    (do (if ((eq_bits_nat v_153 7) : Bool)
                                        then (do (sar_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.truncate shift_rotate_by 6) input_rflags))
                                        else (do (pure (0x0000000000000000#64, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32))))))))))))))))) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (write_user_rflags output_rflags undefined_flags)
  (x86_operand_to_reg_mem proc_mode reg_mem_size inst_ac? false (Sail.BitVec.zeroExtend (sail_mask 64 (trunc reg_mem_size result)) 128) seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode (Sail.BitVec.truncate temp_rip 48))

def x86_shld_shrd (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-SHLD/SHRD"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size ← (( do (check_range 2 8 (← (select_operand_size proc_mode false rex_byte false prefixes false false false))) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (dst_value, increment_rip_by, dst_addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b001#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int increment_rip_by 48)) ) : SailM (sbits 48) )
  let src_value ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let count ← (( do
    let v_160 := opcode
    (if ((eq_bits_nat v_160 164) : Bool)
    then (do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false))
    else
      (do (if ((eq_bits_nat v_160 172) : Bool)
          then (do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) 1 (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false))
          else
            (do (if ((eq_bits_nat v_160 165) : Bool)
                then (do (pure (Sail.BitVec.zeroExtend (← (rr08 0x1#4 rex_byte)) 128)))
                else
                  (do (if ((eq_bits_nat v_160 173) : Bool)
                      then (do (pure (Sail.BitVec.zeroExtend (← (rr08 0x1#4 rex_byte)) 128)))
                      else (do (pure 0x00000000000000000000000000000000#128))))))))) ) : SailM (BitVec 128) )
  let temp_rip ← (( do
    let v_164 := opcode
    (if ((eq_bits_nat v_164 164) : Bool)
    then (do (add_to_iptr proc_mode temp_rip 0x000000000001#48))
    else
      (do (if ((eq_bits_nat v_164 172) : Bool)
          then (do (add_to_iptr proc_mode temp_rip 0x000000000001#48))
          else
            (do (if ((eq_bits_nat v_164 165) : Bool)
                then (do (pure temp_rip))
                else
                  (do (if ((eq_bits_nat v_164 173) : Bool)
                      then (do (pure temp_rip))
                      else (do (pure 0x000000000000#48))))))))) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let count_mask : Int :=
    if ((logbitp_bits 3 rex_byte) : Bool)
    then 63
    else 31
  let count : (BitVec 128) := ((bits_of_int count_mask 128) &&& count)
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, result_undefined?, output_rflags, undefined_flags) ← (( do
    let v_168 := opcode
    (if ((eq_bits_nat v_168 164) : Bool)
    then (do (shld_spec operand_size (Sail.BitVec.truncate dst_value 64) src_value (Sail.BitVec.truncate count 6) input_rflags))
    else
      (do (if ((eq_bits_nat v_168 165) : Bool)
          then (do (shld_spec operand_size (Sail.BitVec.truncate dst_value 64) src_value (Sail.BitVec.truncate count 6) input_rflags))
          else
            (do (if ((eq_bits_nat v_168 172) : Bool)
                then (do (shrd_spec operand_size (Sail.BitVec.truncate dst_value 64) src_value (Sail.BitVec.truncate count 6) input_rflags))
                else
                  (do (if ((eq_bits_nat v_168 173) : Bool)
                      then (do (shrd_spec operand_size (Sail.BitVec.truncate dst_value 64) src_value (Sail.BitVec.truncate count 6) input_rflags))
                      else (do (pure (0x0000000000000000#64, false, (Mk_rflagsbits 0x00000000#32), (Mk_rflagsbits 0x00000000#32))))))))))) ) : SailM ((BitVec 64) × Bool × rflagsbits × rflagsbits) )
  let result ← (( do
    (if (result_undefined? : Bool)
    then (do (undef_read ()))
    else (do (pure (BitVec.toNatInt result)))) ) : SailM Int )
  (write_user_rflags output_rflags undefined_flags)
  (x86_operand_to_reg_mem proc_mode operand_size inst_ac? false (Sail.BitVec.zeroExtend (sail_mask 64 (trunc operand_size (bits_of_int result 64))) 128) seg_reg dst_addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def x86_lgdt (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-LGDT"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  (if ((← readReg app_view) : Bool)
  then (do (x86_model_error ":LGDT-UNIMPLEMENTED-IN-APP-VIEW"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let base_size ← (( do
    (if ((← (n64_bit_modep ())) : Bool)
    then (do (pure 8))
    else (do (pure 4))) ) : SailM Int )
  let base_size_plus_2 : Int := (2 +i base_size)
  let inst_ac? : Bool := false
  let (mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 base_size_plus_2 inst_ac? true seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let p3? : Bool := (0x66#8 == (_get_prefixes_opr prefixes))
  let operand_size ← (( do
    (if ((base_size == 8) : Bool)
    then (do (pure 8))
    else
      (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
          let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
          (if ((cs_d == 1#1) : Bool)
          then
            (do (if (p3? : Bool)
                then (do (pure 2))
                else (do (pure 4))))
          else
            (do (if (p3? : Bool)
                then (do (pure 4))
                else (do (pure 2))))))) ) : SailM Int )
  let base_bits : Int :=
    match operand_size with
    | 8 => 64
    | 4 => 32
    | _ => 24
  let gdtr_limit : gdtr_idtrbits := (_update_gdtr_idtrbits_limit (Mk_gdtr_idtrbits 0x00000000000000000000#80) (Sail.BitVec.extractLsb mem 15 0))
  let gdtr ← (( do (pure (_update_gdtr_idtrbits_base_addr gdtr_limit (sail_mask 64 (← (bitslice mem 16 base_bits))))) ) : SailM gdtr_idtrbits )
  writeReg strs (vectorUpdate (← readReg strs) 0 gdtr)
  (write_iptr proc_mode temp_rip)

def x86_lidt (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-LIDT"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  (if ((← readReg app_view) : Bool)
  then (do (x86_model_error ":LIDT-UNIMPLEMENTED"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let base_size ← (( do
    (if ((← (n64_bit_modep ())) : Bool)
    then (do (pure 8))
    else (do (pure 4))) ) : SailM Int )
  let base_size_plus_2 : Int := (2 +i base_size)
  let inst_ac? : Bool := false
  let (mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 base_size_plus_2 inst_ac? true seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let p3? : Bool := (0x66#8 == (_get_prefixes_opr prefixes))
  let operand_size ← (( do
    (if ((base_size == 8) : Bool)
    then (do (pure 8))
    else
      (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
          let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
          (if ((cs_d == 1#1) : Bool)
          then
            (do (if (p3? : Bool)
                then (do (pure 2))
                else (do (pure 4))))
          else
            (do (if (p3? : Bool)
                then (do (pure 4))
                else (do (pure 2))))))) ) : SailM Int )
  let base_bits : Int :=
    match operand_size with
    | 8 => 64
    | 4 => 32
    | _ => 24
  let idtr_limit : gdtr_idtrbits := (_update_gdtr_idtrbits_limit (Mk_gdtr_idtrbits 0x00000000000000000000#80) (Sail.BitVec.extractLsb mem 15 0))
  let idtr ← (( do (pure (_update_gdtr_idtrbits_base_addr idtr_limit (sail_mask 64 (← (bitslice mem 16 base_bits))))) ) : SailM gdtr_idtrbits )
  writeReg strs (vectorUpdate (← readReg strs) 1 idtr)
  (write_iptr proc_mode temp_rip)

def x86_lldt (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-LLDT"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  (if ((← readReg app_view) : Bool)
  then (do (x86_model_error ":LLDT-UNIMPLEMENTED"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := false
  let (selector, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 2 inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let sel_index : (BitVec 13) := (_get_segment_selectorbits_index (Mk_segment_selectorbits (Sail.BitVec.truncate selector 16)))
  let sel_ti : (BitVec 1) := (_get_segment_selectorbits_ti (Mk_segment_selectorbits (Sail.BitVec.truncate selector 16)))
  let sel_rpl : (BitVec 2) := (_get_segment_selectorbits_rpl (Mk_segment_selectorbits (Sail.BitVec.truncate selector 16)))
  (if ((sel_ti == 1#1) : Bool)
  then (do (x86_model_error ":GP-SELECTOR-DOES-NOT-POINT-TO-GDT"))
  else (do (pure ())))
  let gdtr ← (( do (pure (GetElem?.getElem! (← readReg strs) 0)) ) : SailM (BitVec 80) )
  let gdtr_base : (BitVec 64) :=
    if ((in_64bit_mode proc_mode) : Bool)
    then (_get_gdtr_idtrbits_base_addr (Mk_gdtr_idtrbits gdtr))
    else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate (_get_gdtr_idtrbits_base_addr (Mk_gdtr_idtrbits gdtr)) 32) 64)
  let gdtr_limit : (BitVec 16) := (_get_gdtr_idtrbits_limit (Mk_gdtr_idtrbits gdtr))
  let largest_address : Int :=
    ((ash_left_int (BitVec.toNatInt sel_index) 3) +i (if ((in_64bit_mode proc_mode) : Bool)
      then 15
      else 7))
  (if (((BitVec.toNatInt gdtr_limit) <b largest_address) : Bool)
  then (do (x86_model_error ":GP-SELECTOR-LIMIT-CHECK-FAILED"))
  else (do (pure ())))
  (if ((sel_index == 0b0000000000000#13) : Bool)
  then (do writeReg ssr_visibles (vectorUpdate (← readReg ssr_visibles) 0 (Sail.BitVec.truncate selector 16)))
  else
    (do let descriptor_addr : Int := ((BitVec.toNatInt gdtr_base) +i (BitVec.toNatInt (bits_of_int (ash_left_int (BitVec.toNatInt sel_index) 3) 16)))
        (if ((! (← (canonical_address_p descriptor_addr))) : Bool)
        then (do (x86_model_error ":DESCRIPTOR-ADDR-VIRTUAL-MEMORY-ERROR"))
        else (do (pure ())))
        let descriptor_size : Int :=
          if ((in_64bit_mode proc_mode) : Bool)
          then 16
          else 8
        let descriptor ← (( do (rml_size descriptor_size (bits_of_int descriptor_addr 48) ":X") ) : SailM (BitVec 128) )
        let (descriptor_valid?, reason) : (Bool × (String × (BitVec 128))) := (ia32e_valid_ldt_segment_descriptor_p descriptor)
        (if ((! descriptor_valid?) : Bool)
        then (do (x86_model_error ":INVALID-SEGMENT-DESCRIPTOR"))
        else (do (pure ())))
        let ldtr_base15_0 : (BitVec 16) := (_get_system_segment_descriptorbits_base15_0 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_base23_16 : (BitVec 8) := (_get_system_segment_descriptorbits_base23_16 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_base31_24 : (BitVec 8) := (_get_system_segment_descriptorbits_base31_24 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_base63_32 : (BitVec 32) := (_get_system_segment_descriptorbits_base63_32 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_base63_24 : (BitVec 40) := (bits_of_int (changeSlice_int (ash_left_int (BitVec.toNatInt ldtr_base63_32) 8) 0 8 (BitVec.toNatInt ldtr_base31_24)) 40)
        let ldtr_base23_0 : (BitVec 24) := (bits_of_int (changeSlice_int (ash_left_int (BitVec.toNatInt ldtr_base23_16) 16) 0 16 (BitVec.toNatInt ldtr_base15_0)) 24)
        let ldtr_base : (BitVec 64) := (bits_of_int (changeSlice_int (ash_left_int (BitVec.toNatInt ldtr_base63_24) 24) 0 24 (BitVec.toNatInt ldtr_base23_0)) 64)
        let ldtr_limit15_0 : (BitVec 16) := (_get_system_segment_descriptorbits_limit15_0 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_limit19_16 : (BitVec 4) := (_get_system_segment_descriptorbits_limit19_16 (Mk_system_segment_descriptorbits descriptor))
        let ldtr_limit : (BitVec 32) := (bits_of_int (changeSlice_int (ash_left_int (BitVec.toNatInt ldtr_limit19_16) 16) 0 16 (BitVec.toNatInt ldtr_limit15_0)) 32)
        let ldtr_attr : system_segment_descriptor_attributesbits := (make_system_segment_attr_field descriptor)
        writeReg ssr_visibles (vectorUpdate (← readReg ssr_visibles) 0 (Sail.BitVec.truncate selector 16))
        writeReg ssr_hidden_bases (vectorUpdate (← readReg ssr_hidden_bases) 0 ldtr_base)
        writeReg ssr_hidden_limits (vectorUpdate (← readReg ssr_hidden_limits) 0 ldtr_limit)
        writeReg ssr_hidden_attrs (vectorUpdate (← readReg ssr_hidden_attrs) 0 ldtr_attr)
        (write_iptr proc_mode temp_rip)))

def x86_cbw_cwd_cdqe (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-CBW/CWD/CDQE"
  let register_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let src_size ← (( do (check_range 1 4 (ash_int register_size (Neg.neg 1))) ) : SailM Nat )
  let src ← (( do (pure (Sail.BitVec.truncate (← (rgfi_size (bits_of_int src_size 4) 0x0#4 rex_byte)) 32)) ) : SailM (BitVec 32) )
  let dst ← (( do
    (if ((logbitp_bits (← (check_range 0 32 ((← (check_range 0 32 (ash_left_int src_size 3))) -i 1))) src) : Bool)
    then
      (do (pure (sail_mask 64
              (trunc_signed register_size
                (match src_size with
                | 1 => (Sail.BitVec.signExtend (Sail.BitVec.truncate src 8) 32)
                | 2 => (Sail.BitVec.signExtend (Sail.BitVec.truncate src 16) 32)
                | _ => src : (sbits 32))))))
    else (do (pure (Sail.BitVec.zeroExtend src 64)))) ) : SailM (BitVec 64) )
  (write_rgfi_size (bits_of_int register_size 4) 0x0#4 dst rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_cwd_cdq_cqo (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-CWD/CDQ/CQO"
  let src_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let src ← (( do (rgfi_size (bits_of_int src_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let rdx_var : (BitVec 64) :=
    if ((logbitp_bits ((ash_left_int src_size 3) -i 1) src) : Bool)
    then (sail_mask 64 (trunc src_size 0xFFFFFFFFFFFFFFFF#64))
    else 0x0000000000000000#64
  (write_rgfi_size (bits_of_int src_size 4) 0x2#4 rdx_var rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_movs (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVS"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let group_1_prefix : (BitVec 8) := (_get_prefixes_rep prefixes)
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let df ← (( do
    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
    (pure (_get_rflagsbits_df rflags_var)) ) : SailM (BitVec 1) )
  let counter_addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM address_size )
  let select_byte_operand : Bool := (0xA4#8 == opcode)
  let operand_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let counter_addr_size_2_4? : Bool := ((counter_addr_size == 2) || (counter_addr_size == 4))
  let src_addr ← (( do
    (if (counter_addr_size_2_4? : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int counter_addr_size 4) 0x6#4 rex_byte)) 65)))
    else (do (pure (Sail.BitVec.signExtend (← (rgfi 6)) 65)))) ) : SailM (sbits 65) )
  (if ((←((pure (! counter_addr_size_2_4?)) <&&> (do
       (pure (! (← (canonical_address_p (BitVec.toInt src_addr)))))))) : Bool)
  then (do (x86_model_error ":SRC-ADDR-NOT-CANONICAL"))
  else (do (pure ())))
  let inst_ac? ← (( do (alignment_checking_enabled_p ()) ) : SailM Bool )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let src ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.truncate src_addr 64) none seg_reg ":R" inst_ac? false) ) : SailM (BitVec 128) )
  let dst_addr ← (( do
    (if (counter_addr_size_2_4? : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int counter_addr_size 4) 0x7#4 rex_byte)) 65)))
    else (do (pure (Sail.BitVec.signExtend (← (rgfi 7)) 65)))) ) : SailM (sbits 65) )
  (if ((←((pure (! counter_addr_size_2_4?)) <&&> (do
       (pure (! (← (canonical_address_p (BitVec.toInt dst_addr)))))))) : Bool)
  then (do (x86_model_error ":DST-ADDR-NOT-CANONICAL"))
  else (do (pure ())))
  let original_dst_addr : (sbits 48) := (Sail.BitVec.truncate dst_addr 48)
  let (src_addr, dst_addr) : (Int × Int) :=
    match operand_size with
    | 1 =>
      (if ((df == 0#1) : Bool)
      then ((1 +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), (1 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))))
      else (((Neg.neg 1) +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), ((Neg.neg 1) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48)))))
    | 2 =>
      (if ((df == 0#1) : Bool)
      then ((2 +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), (2 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))))
      else (((Neg.neg 2) +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), ((Neg.neg 2) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48)))))
    | 4 =>
      (if ((df == 0#1) : Bool)
      then ((4 +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), (4 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))))
      else (((Neg.neg 4) +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), ((Neg.neg 4) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48)))))
    | _ =>
      (if ((df == 0#1) : Bool)
      then ((8 +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), (8 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))))
      else (((Neg.neg 8) +i (BitVec.toInt (Sail.BitVec.truncate src_addr 48))), ((Neg.neg 8) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48)))))
  let src_addr : (sbits 49) := (bits_of_int src_addr 49)
  let dst_addr : (sbits 49) := (bits_of_int dst_addr 49)
  (wme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.signExtend original_dst_addr 64) none 0 src inst_ac? false)
  let v_172 := group_1_prefix
  (if ((eq_bits_nat v_172 243) : Bool)
  then
    (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
        let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
        (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
             (pure ((← do
                   let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                   (pure (_get_rflagsbits_zf rflags_var))) == 0#1))))) : Bool)
        then (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))
        else
          (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
              (write_iptr proc_mode temp_rip))))
  else
    (do (if ((eq_bits_nat v_172 242) : Bool)
        then
          (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
              let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
              (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
                   (pure ((← do
                         let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                         (pure (_get_rflagsbits_zf rflags_var))) == 1#1))))) : Bool)
              then
                (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
                    (write_iptr proc_mode temp_rip))
              else (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))))
        else (do (write_iptr proc_mode temp_rip)))))
  match counter_addr_size with
  | 2 => (write_rgfi_size 0x2#4 0x6#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate src_addr 16) 64) rex_byte)
  | 4 => (write_rgfi_size 0x4#4 0x6#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate src_addr 32) 64) rex_byte)
  | _ => (write_rgfi 6 (Sail.BitVec.signExtend src_addr 64))
  match counter_addr_size with
  | 2 => (write_rgfi_size 0x2#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 16) 64) rex_byte)
  | 4 => (write_rgfi_size 0x4#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 32) 64) rex_byte)
  | _ => (write_rgfi 7 (Sail.BitVec.signExtend dst_addr 64))

def x86_cmps (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-CMPS"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let group_1_prefix : (BitVec 8) := (_get_prefixes_rep prefixes)
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let df ← (( do
    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
    (pure (_get_rflagsbits_df rflags_var)) ) : SailM (BitVec 1) )
  let counter_addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM address_size )
  let select_byte_operand : Bool := (0xA6#8 == opcode)
  let operand_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let counter_addr_size_2_4? : Bool := ((counter_addr_size == 2) || (counter_addr_size == 4))
  let src_addr ← (( do
    (if (counter_addr_size_2_4? : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int counter_addr_size 4) 0x6#4 rex_byte)) 65)))
    else (do (pure (Sail.BitVec.signExtend (← (rgfi 6)) 65)))) ) : SailM (sbits 65) )
  (if ((←((pure (! counter_addr_size_2_4?)) <&&> (do
       (pure (! (← (canonical_address_p (BitVec.toInt src_addr)))))))) : Bool)
  then (do (x86_model_error ":SRC-ADDR-NOT-CANONICAL"))
  else (do (pure ())))
  let inst_ac? ← (( do (alignment_checking_enabled_p ()) ) : SailM Bool )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let src ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.truncate src_addr 64) none seg_reg ":R" inst_ac? false) ) : SailM (BitVec 128) )
  let dst_addr ← (( do
    (if (counter_addr_size_2_4? : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int counter_addr_size 4) 0x7#4 rex_byte)) 65)))
    else (do (pure (Sail.BitVec.signExtend (← (rgfi 7)) 65)))) ) : SailM (sbits 65) )
  (if ((←((pure (! counter_addr_size_2_4?)) <&&> (do
       (pure (! (← (canonical_address_p (BitVec.toInt dst_addr)))))))) : Bool)
  then (do (x86_model_error ":DST-ADDR-NOT-CANONICAL"))
  else (do (pure ())))
  let dst ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.truncate dst_addr 64) none 0 ":R" inst_ac? false) ) : SailM (BitVec 128) )
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec operand_size 4 (Sail.BitVec.truncate dst 64) (Sail.BitVec.truncate src 64) input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (write_user_rflags output_rflags undefined_flags)
  let (src_addr, dst_addr) : (Int × Int) :=
    match operand_size with
    | 1 =>
      (if ((df == 0#1) : Bool)
      then (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) +i 1), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) +i 1))
      else (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) -i 1), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) -i 1)))
    | 2 =>
      (if ((df == 0#1) : Bool)
      then (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) +i 2), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) +i 2))
      else (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) -i 2), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) -i 2)))
    | 4 =>
      (if ((df == 0#1) : Bool)
      then (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) +i 4), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) +i 4))
      else (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) -i 4), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) -i 4)))
    | _ =>
      (if ((df == 0#1) : Bool)
      then (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) +i 8), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) +i 8))
      else (((BitVec.toInt (Sail.BitVec.truncate src_addr 48)) -i 8), ((BitVec.toInt (Sail.BitVec.truncate dst_addr 48)) -i 8)))
  let src_addr : (sbits 49) := (bits_of_int src_addr 49)
  let dst_addr : (sbits 49) := (bits_of_int dst_addr 49)
  let v_174 := group_1_prefix
  (if ((eq_bits_nat v_174 243) : Bool)
  then
    (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
        let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
        (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
             (pure ((← do
                   let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                   (pure (_get_rflagsbits_zf rflags_var))) == 0#1))))) : Bool)
        then (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))
        else
          (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
              (write_iptr proc_mode temp_rip))))
  else
    (do (if ((eq_bits_nat v_174 242) : Bool)
        then
          (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
              let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
              (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
                   (pure ((← do
                         let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                         (pure (_get_rflagsbits_zf rflags_var))) == 1#1))))) : Bool)
              then
                (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
                    (write_iptr proc_mode temp_rip))
              else (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))))
        else (do (write_iptr proc_mode temp_rip)))))
  match counter_addr_size with
  | 2 => (write_rgfi_size 0x2#4 0x6#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate src_addr 16) 64) rex_byte)
  | 4 => (write_rgfi_size 0x4#4 0x6#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate src_addr 32) 64) rex_byte)
  | _ => (write_rgfi 6 (Sail.BitVec.signExtend src_addr 64))
  match counter_addr_size with
  | 2 => (write_rgfi_size 0x2#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 16) 64) rex_byte)
  | 4 => (write_rgfi_size 0x4#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 32) 64) rex_byte)
  | _ => (write_rgfi 7 (Sail.BitVec.signExtend dst_addr 64))

def x86_stos (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-STOS"
  let group_1_prefix : (BitVec 8) := (_get_prefixes_seg prefixes)
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let df ← (( do
    let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
    (pure (_get_rflagsbits_df rflags_var)) ) : SailM (BitVec 1) )
  let counter_addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM address_size )
  let counter_addr_size_2_4? : Bool := ((counter_addr_size == 2) || (counter_addr_size == 4))
  let dst_addr ← (( do
    (if (counter_addr_size_2_4? : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int counter_addr_size 4) 0x7#4 rex_byte)) 65)))
    else (do (pure (Sail.BitVec.signExtend (← (rgfi 7)) 65)))) ) : SailM (sbits 65) )
  (if ((←((pure (! counter_addr_size_2_4?)) <&&> (do
       (pure (! (← (canonical_address_p (BitVec.toInt dst_addr)))))))) : Bool)
  then (do (x86_model_error ":DST-ADDR-NOT-CANONICAL"))
  else (do (pure ())))
  let select_byte_operand : Bool := (0xAA#8 == opcode)
  let operand_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let rax_var ← (( do (rgfi_size (bits_of_int operand_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let inst_ac? ← (( do (alignment_checking_enabled_p ()) ) : SailM Bool )
  (wme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.truncate dst_addr 64) none 0 (Sail.BitVec.zeroExtend rax_var 128) inst_ac? false)
  let dst_addr : (sbits 49) :=
    match operand_size with
    | 1 =>
      (if ((df == 0#1) : Bool)
      then (bits_of_int (1 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49)
      else (bits_of_int ((Neg.neg 1) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49))
    | 2 =>
      (if ((df == 0#1) : Bool)
      then (bits_of_int (2 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49)
      else (bits_of_int ((Neg.neg 2) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49))
    | 4 =>
      (if ((df == 0#1) : Bool)
      then (bits_of_int (4 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49)
      else (bits_of_int ((Neg.neg 4) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49))
    | _ =>
      (if ((df == 0#1) : Bool)
      then (bits_of_int (8 +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49)
      else (bits_of_int ((Neg.neg 8) +i (BitVec.toInt (Sail.BitVec.truncate dst_addr 48))) 49))
  let v_176 := group_1_prefix
  (if ((eq_bits_nat v_176 243) : Bool)
  then
    (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
        let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
        (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
             (pure ((← do
                   let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                   (pure (_get_rflagsbits_zf rflags_var))) == 0#1))))) : Bool)
        then (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))
        else
          (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
              (write_iptr proc_mode temp_rip))))
  else
    (do (if ((eq_bits_nat v_176 242) : Bool)
        then
          (do let counter ← (( do (rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 rex_byte) ) : SailM (BitVec 64) )
              let counter : (BitVec 64) := (sail_mask 64 (trunc counter_addr_size (bits_of_int ((BitVec.toNatInt counter) -i 1) 64)))
              (if ((←((pure (counter == 0x0000000000000000#64)) <||> (do
                   (pure ((← do
                         let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
                         (pure (_get_rflagsbits_zf rflags_var))) == 1#1))))) : Bool)
              then
                (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte)
                    (write_iptr proc_mode temp_rip))
              else (do (write_rgfi_size (bits_of_int counter_addr_size 4) 0x1#4 counter rex_byte))))
        else (do (write_iptr proc_mode temp_rip)))))
  match counter_addr_size with
  | 2 => (write_rgfi_size 0x2#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 16) 64) rex_byte)
  | 4 => (write_rgfi_size 0x4#4 0x7#4 (Sail.BitVec.zeroExtend (Sail.BitVec.truncate dst_addr 32) 64) rex_byte)
  | _ => (write_rgfi 7 (Sail.BitVec.signExtend dst_addr 64))


end X86Sail.Functions
