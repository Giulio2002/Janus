import X86Sail.Part03

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def _get_rflagsbits_of (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _update_rflagsbits_of (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _get_rflagsbits_pf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_rflagsbits_pf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_rflagsbits_res1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_rflagsbits_res2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_rflagsbits_res3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_rflagsbits_rf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _update_rflagsbits_rf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _get_rflagsbits_sf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_rflagsbits_sf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_rflagsbits_vif (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _update_rflagsbits_vip (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _get_rflagsbits_vm (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _update_rflagsbits_vm (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _get_rflagsbits_zf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _update_rflagsbits_zf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_cr0bits_am (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_cr0bits_em (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_cr0bits_pe (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_cr0bits_ts (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_cr4bits_de (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_cr4bits_osfxsr (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_cr4bits_osxsave (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_cr4bits_pce (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_cr4bits_umip (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_ia32_eferbits_lma (v : (BitVec 12)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_ia32_eferbits_lma (v : (BitVec 12)) (x : (BitVec 1)) : (BitVec 12) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_ia32_eferbits_sce (v : (BitVec 12)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def read_gpr (idx : Nat) : SailM (BitVec 64) := do
  match idx with
  | 0 => readReg rax
  | 1 => readReg rcx
  | 2 => readReg rdx
  | 3 => readReg rbx
  | 4 => readReg rsp
  | 5 => readReg rbp
  | 6 => readReg rsi
  | 7 => readReg rdi
  | 8 => readReg r8
  | 9 => readReg r9
  | 10 => readReg r10
  | 11 => readReg r11
  | 12 => readReg r12
  | 13 => readReg r13
  | 14 => readReg r14
  | _ => readReg r15

/-- Type quantifiers: regNum : Int -/
def rgfi (regNum : Int) : SailM (BitVec 64) := do
  sail_assert ((0 ≤b regNum) && (regNum <b 16)) "register_accessors.sail:6.36-6.37"
  (pure (regval_from_reg (← (read_gpr regNum))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def log_gpr_write (idx : Nat) : SailM Unit := do
  match idx with
  | 0 => (pure (print_bits "rax = " (← (rgfi 0))))
  | 1 => (pure (print_bits "rcx = " (← (rgfi 1))))
  | 2 => (pure (print_bits "rdx = " (← (rgfi 2))))
  | 3 => (pure (print_bits "rbx = " (← (rgfi 3))))
  | 4 => (pure (print_bits "rsp = " (← (rgfi 4))))
  | 5 => (pure (print_bits "rbp = " (← (rgfi 5))))
  | 6 => (pure (print_bits "rsi = " (← (rgfi 6))))
  | 7 => (pure (print_bits "rdi = " (← (rgfi 7))))
  | 8 => (pure (print_bits "r8 = " (← (rgfi 8))))
  | 9 => (pure (print_bits "r9 = " (← (rgfi 9))))
  | 10 => (pure (print_bits "r10 = " (← (rgfi 10))))
  | 11 => (pure (print_bits "r11 = " (← (rgfi 11))))
  | 12 => (pure (print_bits "r12 = " (← (rgfi 12))))
  | 13 => (pure (print_bits "r13 = " (← (rgfi 13))))
  | 14 => (pure (print_bits "r14 = " (← (rgfi 14))))
  | _ => (pure (print_bits "r15 = " (← (rgfi 15))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def write_gpr (idx : Nat) (value : (BitVec 64)) : SailM Unit := do
  match idx with
  | 0 => writeReg rax value
  | 1 => writeReg rcx value
  | 2 => writeReg rdx value
  | 3 => writeReg rbx value
  | 4 => writeReg rsp value
  | 5 => writeReg rbp value
  | 6 => writeReg rsi value
  | 7 => writeReg rdi value
  | 8 => writeReg r8 value
  | 9 => writeReg r9 value
  | 10 => writeReg r10 value
  | 11 => writeReg r11 value
  | 12 => writeReg r12 value
  | 13 => writeReg r13 value
  | 14 => writeReg r14 value
  | _ => writeReg r15 value
  (if ((← readReg log_register_writes) : Bool)
  then (do (log_gpr_write idx))
  else (do (pure ())))

/-- Type quantifiers: regNum : Int -/
def write_rgfi (regNum : Int) (regval_to_write : (BitVec 64)) : SailM Unit := do
  sail_assert ((0 ≤b regNum) && (regNum <b 16)) "register_accessors.sail:12.36-12.37"
  (write_gpr regNum (regval_into_reg regval_to_write))

def log_rip_write (_ : Unit) : SailM Unit := do
  (pure (print_bits "rip = " (← (read_rip ()))))

def write_rip (value : (BitVec 48)) : SailM Unit := do
  writeReg rip (regval_into_reg (Sail.BitVec.signExtend value 64))
  (if ((← readReg log_register_writes) : Bool)
  then (do (log_rip_write ()))
  else (do (pure ())))

def in_64bit_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_64bit => true
  | _ => false

def in_compatibility_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_Compatibility => true
  | _ => false

def in_protected_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_Protected => true
  | _ => false

def Mk_code_segment_descriptor_attributesbits (v : (BitVec 16)) : (BitVec 16) :=
  v

def _get_code_segment_descriptor_attributesbits_l (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def n64_bit_modep (_ : Unit) : SailM Bool := do
  let ia32_efer ← (( do (pure (Sail.BitVec.truncate (← (read_msr 0)) 12)) ) : SailM (BitVec 12) )
  let ia32_efer_lma : (BitVec 1) := (_get_ia32_eferbits_lma (Mk_ia32_eferbits ia32_efer))
  let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
  let cs_l : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_l (Mk_code_segment_descriptor_attributesbits cs_attr))
  (pure ((ia32_efer_lma == 1#1) && (cs_l == 1#1)))

def x86_operation_mode (_ : Unit) : SailM proc_mode := do
  (if ((← (n64_bit_modep ())) : Bool)
  then (do (pure Mode_64bit))
  else (do (pure Mode_Compatibility)))

def Mk_prefixes (v : (BitVec 52)) : (BitVec 52) :=
  v

def _get_prefixes_adr (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 43 36)

def _update_prefixes_adr (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 43 36 x)

def _get_prefixes_lck (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 11 4)

def _update_prefixes_lck (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 11 4 x)

def _get_prefixes_num (v : (BitVec 52)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _update_prefixes_num (v : (BitVec 52)) (x : (BitVec 4)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _get_prefixes_nxt (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 51 44)


end X86Sail.Functions
