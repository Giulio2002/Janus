import X86Sail.Part03

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def _update_vex_prefixes_byte1 (v : (BitVec 24)) (x : (BitVec 8)) : (BitVec 24) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def _update_evex_prefixes_byte1 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def Mk_evex_prefixes (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_modr_m (v : (BitVec 8)) : (BitVec 8) :=
  v

def _get_modr_m_mod (v : (BitVec 8)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_modr_m_r_m (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_modr_m_reg (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 5 3)

def Mk_sib (v : (BitVec 8)) : (BitVec 8) :=
  v

def _get_sib_base (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_sib_index (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 5 3)

def _get_segment_selectorbits_index (v : (BitVec 16)) : (BitVec 13) :=
  (Sail.BitVec.extractLsb v 15 3)

def _get_sib_scale (v : (BitVec 8)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def undefined_rflagsbits (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_rflagsbits (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_rflagsbits_af (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _update_rflagsbits_af (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _get_rflagsbits_cf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_rflagsbits_cf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_rflagsbits_df (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_rflagsbits_df (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_rflagsbits_of (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _update_rflagsbits_of (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _get_rflagsbits_pf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_rflagsbits_pf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _get_rflagsbits_sf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_rflagsbits_sf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_rflagsbits_zf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _update_rflagsbits_zf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_cr0bits_am (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_cr0bits_em (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_cr0bits_ts (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_cr4bits_osfxsr (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_ia32_eferbits_lma (v : (BitVec 12)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_ia32_eferbits_lma (v : (BitVec 12)) (x : (BitVec 1)) : (BitVec 12) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def read_gpr (idx : Nat) : SailM (BitVec 64) := do
  match idx with
  | 0 => readReg rax
  | 1 => readReg rcx
  | 2 => readReg rdx
  | 3 => readReg rbx
  | 4 => readReg rsp
  | 5 => readReg rbp
  | 6 => readReg rsi
  | 7 => readReg rdi
  | 8 => readReg r8
  | 9 => readReg r9
  | 10 => readReg r10
  | 11 => readReg r11
  | 12 => readReg r12
  | 13 => readReg r13
  | 14 => readReg r14
  | _ => readReg r15

/-- Type quantifiers: regNum : Int -/
def rgfi (regNum : Int) : SailM (BitVec 64) := do
  sail_assert ((0 ≤b regNum) && (regNum <b 16)) "register_accessors.sail:6.36-6.37"
  (pure (regval_from_reg (← (read_gpr regNum))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def log_gpr_write (idx : Nat) : SailM Unit := do
  match idx with
  | 0 => (pure (print_bits "rax = " (← (rgfi 0))))
  | 1 => (pure (print_bits "rcx = " (← (rgfi 1))))
  | 2 => (pure (print_bits "rdx = " (← (rgfi 2))))
  | 3 => (pure (print_bits "rbx = " (← (rgfi 3))))
  | 4 => (pure (print_bits "rsp = " (← (rgfi 4))))
  | 5 => (pure (print_bits "rbp = " (← (rgfi 5))))
  | 6 => (pure (print_bits "rsi = " (← (rgfi 6))))
  | 7 => (pure (print_bits "rdi = " (← (rgfi 7))))
  | 8 => (pure (print_bits "r8 = " (← (rgfi 8))))
  | 9 => (pure (print_bits "r9 = " (← (rgfi 9))))
  | 10 => (pure (print_bits "r10 = " (← (rgfi 10))))
  | 11 => (pure (print_bits "r11 = " (← (rgfi 11))))
  | 12 => (pure (print_bits "r12 = " (← (rgfi 12))))
  | 13 => (pure (print_bits "r13 = " (← (rgfi 13))))
  | 14 => (pure (print_bits "r14 = " (← (rgfi 14))))
  | _ => (pure (print_bits "r15 = " (← (rgfi 15))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 15 -/
def write_gpr (idx : Nat) (value : (BitVec 64)) : SailM Unit := do
  match idx with
  | 0 => writeReg rax value
  | 1 => writeReg rcx value
  | 2 => writeReg rdx value
  | 3 => writeReg rbx value
  | 4 => writeReg rsp value
  | 5 => writeReg rbp value
  | 6 => writeReg rsi value
  | 7 => writeReg rdi value
  | 8 => writeReg r8 value
  | 9 => writeReg r9 value
  | 10 => writeReg r10 value
  | 11 => writeReg r11 value
  | 12 => writeReg r12 value
  | 13 => writeReg r13 value
  | 14 => writeReg r14 value
  | _ => writeReg r15 value
  (if ((← readReg log_register_writes) : Bool)
  then (do (log_gpr_write idx))
  else (do (pure ())))

/-- Type quantifiers: regNum : Int -/
def write_rgfi (regNum : Int) (regval_to_write : (BitVec 64)) : SailM Unit := do
  sail_assert ((0 ≤b regNum) && (regNum <b 16)) "register_accessors.sail:12.36-12.37"
  (write_gpr regNum (regval_into_reg regval_to_write))

def log_rip_write (_ : Unit) : SailM Unit := do
  (pure (print_bits "rip = " (← (read_rip ()))))

def write_rip (value : (BitVec 48)) : SailM Unit := do
  writeReg rip (regval_into_reg (Sail.BitVec.signExtend value 64))
  (if ((← readReg log_register_writes) : Bool)
  then (do (log_rip_write ()))
  else (do (pure ())))

def in_64bit_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_64bit => true
  | _ => false

def in_compatibility_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_Compatibility => true
  | _ => false

def in_protected_mode (proc_mode : proc_mode) : Bool :=
  match proc_mode with
  | .Mode_Protected => true
  | _ => false


end X86Sail.Functions
