import X86Sail.Part05

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def _get_code_segment_descriptor_attributesbits_r (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_code_segment_descriptorbits_s (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_call_gate_descriptorbits_s (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _update_code_segment_descriptor_attributesbits_a (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_code_segment_descriptor_attributesbits_avl (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_code_segment_descriptor_attributesbits_c (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_code_segment_descriptor_attributesbits_dpl (v : (BitVec 16)) (x : (BitVec 2)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 6 5 x)

def _update_code_segment_descriptor_attributesbits_g (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_code_segment_descriptor_attributesbits_l (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_code_segment_descriptor_attributesbits_msb_of_type (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_code_segment_descriptor_attributesbits_p (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_code_segment_descriptor_attributesbits_r (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_code_segment_descriptor_attributesbits_s (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def Mk_data_segment_descriptor_attributesbits (v : (BitVec 16)) : (BitVec 16) :=
  v

def _get_data_segment_descriptor_attributesbits_d_b (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_data_segment_descriptor_attributesbits_e (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_data_segment_descriptor_attributesbits_w (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def Mk_call_gate_descriptorbits (v : (BitVec 128)) : (BitVec 128) :=
  v

def _get_call_gate_descriptorbits_all_zeroes? (v : (BitVec 128)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 108 104)

def _get_call_gate_descriptorbits_offset15_0 (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_call_gate_descriptorbits_offset31_16 (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_call_gate_descriptorbits_offset63_32 (v : (BitVec 128)) : (BitVec 32) :=
  (Sail.BitVec.extractLsb v 95 64)

def _get_call_gate_descriptorbits_sailtype (v : (BitVec 128)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 43 40)

def _get_call_gate_descriptorbits_selector (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def reg_index (reg : (BitVec 3)) (rex_byte : (BitVec 8)) (index : (BitVec 2)) : (BitVec 4) :=
  if ((logbitp_bits (BitVec.toNatInt index) rex_byte) : Bool)
  then (0x8#4 ||| (Sail.BitVec.zeroExtend reg 4))
  else (Sail.BitVec.zeroExtend reg 4)

def rr08 (reg : (BitVec 4)) (rex : (BitVec 8)) : SailM (BitVec 8) := do
  let reg : Nat := (BitVec.toNatInt reg)
  (if (((! (rex == 0x00#8)) || (reg <b 4)) : Bool)
  then
    (do let qword ← (( do (rgfi reg) ) : SailM (sbits 64) )
        (pure (Sail.BitVec.truncate qword 8)))
  else
    (do let qword ← (( do (rgfi (BitVec.toNatInt (bits_of_int (reg -i 4) 4))) ) : SailM (sbits 64) )
        (pure (Sail.BitVec.extractLsb qword 15 8))))

def wr08 (reg : (BitVec 4)) (rex : (BitVec 8)) (byte : (BitVec 8)) : SailM Unit := do
  let reg : Nat := (BitVec.toNatInt reg)
  (if (((! (rex == 0x00#8)) || (reg <b 4)) : Bool)
  then
    (do let qword ← (( do (rgfi reg) ) : SailM (sbits 64) )
        (write_rgfi reg (changeSlice_bits (Sail.BitVec.extractLsb qword 63 0) 0 8 byte)))
  else
    (do let index : (BitVec 4) := (bits_of_int ((BitVec.toNatInt (bits_of_int reg 4)) -i 4) 4)
        let qword ← (( do (rgfi (BitVec.toNatInt index)) ) : SailM (sbits 64) )
        (write_rgfi (BitVec.toNatInt index) (changeSlice_bits (Sail.BitVec.extractLsb qword 63 0) 8 8 byte))))

def rr16 (reg : (BitVec 4)) : SailM (BitVec 16) := do
  (pure (Sail.BitVec.truncate (← (rgfi (BitVec.toNatInt reg))) 16))

def wr16 (reg : (BitVec 4)) (sailval : (BitVec 16)) : SailM Unit := do
  let qword ← (( do (rgfi (BitVec.toNatInt reg)) ) : SailM (sbits 64) )
  (write_rgfi (BitVec.toNatInt reg) (changeSlice_bits (Sail.BitVec.extractLsb qword 63 0) 0 16 sailval))

def rr32 (reg : (BitVec 4)) : SailM (BitVec 32) := do
  (pure (Sail.BitVec.truncate (← (rgfi (BitVec.toNatInt reg))) 32))

def wr32 (reg : (BitVec 4)) (sailval : (BitVec 32)) : SailM Unit := do
  (write_rgfi (BitVec.toNatInt reg) (Sail.BitVec.zeroExtend sailval 64))

def rr64 (reg : (BitVec 4)) : SailM (BitVec 64) := do
  (rgfi (BitVec.toNatInt reg))

def wr64 (reg : (BitVec 4)) (sailval : (BitVec 64)) : SailM Unit := do
  (write_rgfi (BitVec.toNatInt reg) sailval)

def rgfi_size (nbytes : (BitVec 4)) (index : (BitVec 4)) (rex : (BitVec 8)) : SailM (BitVec 64) := do
  let v_8 := nbytes
  (if ((eq_bits_nat v_8 1) : Bool)
  then (do (pure (Sail.BitVec.zeroExtend (← (rr08 index rex)) 64)))
  else
    (do (if ((eq_bits_nat v_8 2) : Bool)
        then (do (pure (Sail.BitVec.zeroExtend (← (rr16 index)) 64)))
        else
          (do (if ((eq_bits_nat v_8 4) : Bool)
              then (do (pure (Sail.BitVec.zeroExtend (← (rr32 index)) 64)))
              else
                (do (if ((eq_bits_nat v_8 8) : Bool)
                    then (do (rr64 index))
                    else (do (pure 0x0000000000000000#64)))))))))

def write_rgfi_size (nbytes : (BitVec 4)) (index : (BitVec 4)) (sailval : (BitVec 64)) (rex : (BitVec 8)) : SailM Unit := do
  let v_12 := nbytes
  (if ((eq_bits_nat v_12 1) : Bool)
  then (do (wr08 index rex (Sail.BitVec.truncate sailval 8)))
  else
    (do (if ((eq_bits_nat v_12 2) : Bool)
        then (do (wr16 index (Sail.BitVec.truncate sailval 16)))
        else
          (do (if ((eq_bits_nat v_12 4) : Bool)
              then (do (wr32 index (Sail.BitVec.truncate sailval 32)))
              else
                (do (if ((eq_bits_nat v_12 8) : Bool)
                    then (do (wr64 index sailval))
                    else (do (pure ())))))))))

def rz32 (reg : (BitVec 5)) : SailM (BitVec 32) := do
  (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg)) 32))

def rz64 (reg : (BitVec 5)) : SailM (BitVec 64) := do
  (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg)) 64))

def rz128 (reg : (BitVec 5)) : SailM (BitVec 128) := do
  (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg)) 128))

def wz32 (reg : (BitVec 5)) (sailval : (BitVec 32)) (keywords : struct_wz32) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_16 := regtype
    if ((eq_bits_nat v_16 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_16 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 32 sailval))

def wz64 (reg : (BitVec 5)) (sailval : (BitVec 64)) (keywords : struct_wz64) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_18 := regtype
    if ((eq_bits_nat v_18 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_18 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 64 sailval))

def wz128 (reg : (BitVec 5)) (sailval : (BitVec 128)) (keywords : struct_wz128) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_20 := regtype
    if ((eq_bits_nat v_20 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_20 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 128 sailval))

def rx32 (reg : (BitVec 4)) : SailM (BitVec 32) := do
  (rz32 (Sail.BitVec.zeroExtend reg 5))

def rx64 (reg : (BitVec 4)) : SailM (BitVec 64) := do
  (rz64 (Sail.BitVec.zeroExtend reg 5))

def rx128 (reg : (BitVec 4)) : SailM (BitVec 128) := do
  (rz128 (Sail.BitVec.zeroExtend reg 5))


end X86Sail.Functions
