import X86Sail.Part06

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def rz64 (reg : (BitVec 5)) : SailM (BitVec 64) := do
  (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg)) 64))

def rz128 (reg : (BitVec 5)) : SailM (BitVec 128) := do
  (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg)) 128))

def wz32 (reg : (BitVec 5)) (sailval : (BitVec 32)) (keywords : struct_wz32) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_16 := regtype
    if ((eq_bits_nat v_16 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_16 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 32 sailval))

def wz64 (reg : (BitVec 5)) (sailval : (BitVec 64)) (keywords : struct_wz64) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_18 := regtype
    if ((eq_bits_nat v_18 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_18 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 64 sailval))

def wz128 (reg : (BitVec 5)) (sailval : (BitVec 128)) (keywords : struct_wz128) : SailM Unit := do
  let data ← (( do (pure (GetElem?.getElem! (← readReg zmms) (BitVec.toNatInt reg))) ) : SailM (BitVec 512) )
  let regtype : (BitVec 3) := (bits_of_int keywords.regtype 3)
  let data : (BitVec 512) :=
    let v_20 := regtype
    if ((eq_bits_nat v_20 2) : Bool)
    then (Sail.BitVec.zeroExtend (loghead_bits 128 data) 512)
    else
      (if ((eq_bits_nat v_20 3) : Bool)
      then (Sail.BitVec.zeroExtend (loghead_bits 256 data) 512)
      else data)
  writeReg zmms (vectorUpdate (← readReg zmms) (BitVec.toNatInt reg) (changeSlice_bits data 0 128 sailval))

def rx32 (reg : (BitVec 4)) : SailM (BitVec 32) := do
  (rz32 (Sail.BitVec.zeroExtend reg 5))

def rx64 (reg : (BitVec 4)) : SailM (BitVec 64) := do
  (rz64 (Sail.BitVec.zeroExtend reg 5))

def rx128 (reg : (BitVec 4)) : SailM (BitVec 128) := do
  (rz128 (Sail.BitVec.zeroExtend reg 5))

def wx32 (reg : (BitVec 4)) (sailval : (BitVec 32)) : SailM Unit := do
  (wz32 (Sail.BitVec.zeroExtend reg 5) sailval { regtype := 1 })

def wx64 (reg : (BitVec 4)) (sailval : (BitVec 64)) : SailM Unit := do
  (wz64 (Sail.BitVec.zeroExtend reg 5) sailval { regtype := 1 })

def wx128 (reg : (BitVec 4)) (sailval : (BitVec 128)) : SailM Unit := do
  (wz128 (Sail.BitVec.zeroExtend reg 5) sailval { regtype := 1 })

def xmmi_size (nbytes : (BitVec 5)) (index : (BitVec 4)) : SailM (BitVec 128) := do
  let v_22 := nbytes
  (if ((eq_bits_nat v_22 4) : Bool)
  then (do (pure (Sail.BitVec.zeroExtend (← (rx32 index)) 128)))
  else
    (do (if ((eq_bits_nat v_22 8) : Bool)
        then (do (pure (Sail.BitVec.zeroExtend (← (rx64 index)) 128)))
        else
          (do (if ((eq_bits_nat v_22 16) : Bool)
              then (do (rx128 index))
              else (do (pure 0x00000000000000000000000000000000#128)))))))

/-- Type quantifiers: sailval : Int -/
def write_xmmi_size (nbytes : (BitVec 5)) (index : (BitVec 4)) (sailval : Int) : SailM Unit := do
  let v_25 := nbytes
  (if ((eq_bits_nat v_25 4) : Bool)
  then (do (wx32 index (bits_of_int sailval 32)))
  else
    (do (if ((eq_bits_nat v_25 8) : Bool)
        then (do (wx64 index (bits_of_int sailval 64)))
        else
          (do (if ((eq_bits_nat v_25 16) : Bool)
              then (do (wx128 index (bits_of_int sailval 128)))
              else (do (pure ())))))))

def undef_read (_ : Unit) : SailM Nat := do
  (undef_read_logic ())

def undef_flg_logic (_ : Unit) : SailM Nat := do
  (undef_read ())

def undef_flg (_ : Unit) : SailM (BitVec 1) := do
  let sailval ← (( do (undef_flg_logic ()) ) : SailM Nat )
  (pure (bits_of_int sailval 1))

def log_rflags_write (_ : Unit) : SailM Unit := do
  (pure (print_bits "rflags = " (← readReg rflags)))

def write_user_rflags (user_flags_vector : (BitVec 32)) (undefined_mask : (BitVec 32)) : SailM Unit := do
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  (if (((_get_rflagsbits_cf undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var (_get_rflagsbits_cf user_flags_vector))
        writeReg rflags new_rflags))
  (if (((_get_rflagsbits_pf undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var (_get_rflagsbits_pf user_flags_vector))
        writeReg rflags new_rflags))
  (if (((_get_rflagsbits_af undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var (_get_rflagsbits_af user_flags_vector))
        writeReg rflags new_rflags))
  (if (((_get_rflagsbits_zf undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var (_get_rflagsbits_zf user_flags_vector))
        writeReg rflags new_rflags))
  (if (((_get_rflagsbits_sf undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var (_get_rflagsbits_sf user_flags_vector))
        writeReg rflags new_rflags))
  (if (((_get_rflagsbits_of undefined_mask) == 1#1) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var sailval)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var (_get_rflagsbits_of user_flags_vector))
        writeReg rflags new_rflags))
  (if ((← readReg log_register_writes) : Bool)
  then (do (log_rflags_write ()))
  else (do (pure ())))

def la_to_pa (lin_addr : (BitVec 48)) (r_w_x : String) : SailM (BitVec 52) := do
  sail_assert (←((canonical_address_p (BitVec.toInt lin_addr)) <&&> (do
    (pure (! (← readReg app_view)))))) "././paging.sail:421.69-421.70"
  (ia32e_la_to_pa lin_addr r_w_x)

def rml08 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 8) := do
  (rb 1 lin_addr r_x)

def rml16 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 16) := do
  let one__plus_lin_addr : (sbits 49) := (bits_of_int (1 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt one__plus_lin_addr))) : Bool)
  then (do (rb 2 lin_addr r_x))
  else (do (x86_model_error "rml16")))

def rml32 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 32) := do
  sail_assert (← (canonical_address_p (BitVec.toInt lin_addr))) "./linear_memory.sail:73.48-73.49"
  let three__plus_lin_addr : (sbits 49) := (bits_of_int (3 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt three__plus_lin_addr))) : Bool)
  then (do (rb 4 lin_addr r_x))
  else (do (x86_model_error "rml32")))

def rml48 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 48) := do
  sail_assert (← (canonical_address_p (BitVec.toInt lin_addr))) "./linear_memory.sail:110.48-110.49"
  let five__plus_lin_addr : (sbits 49) := (bits_of_int (5 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt five__plus_lin_addr))) : Bool)
  then (do (rb 6 lin_addr r_x))
  else (do (x86_model_error "rml48")))

def rml64 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 64) := do
  sail_assert (← (canonical_address_p (BitVec.toInt lin_addr))) "./linear_memory.sail:134.48-134.49"
  let seven__plus_lin_addr : (sbits 49) := (bits_of_int (7 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt seven__plus_lin_addr))) : Bool)
  then (do (rb 8 lin_addr r_x))
  else (do (x86_model_error "rml64")))

def rml80 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 80) := do
  sail_assert (← (canonical_address_p (BitVec.toInt lin_addr))) "./linear_memory.sail:171.48-171.49"
  let nine__plus_lin_addr : (sbits 49) := (bits_of_int (9 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt nine__plus_lin_addr))) : Bool)
  then (do (rb 10 lin_addr r_x))
  else (do (x86_model_error "rml80")))

def rml128 (lin_addr : (BitVec 48)) (r_x : String) : SailM (BitVec 128) := do
  sail_assert (← (canonical_address_p (BitVec.toInt lin_addr))) "./linear_memory.sail:195.48-195.49"
  let one_5_plus_lin_addr : (sbits 49) := (bits_of_int (15 +i (BitVec.toInt lin_addr)) 49)
  (if ((← (canonical_address_p (BitVec.toInt one_5_plus_lin_addr))) : Bool)
  then
    (do (if ((← readReg app_view) : Bool)
        then (do (rb 16 lin_addr r_x))
        else
          (do let p_addr0 ← (( do (la_to_pa lin_addr r_x) ) : SailM (BitVec 52) )
              let one__plus_lin_addr : (sbits 49) := (bits_of_int (1 +i (BitVec.toInt lin_addr)) 49)
              let p_addr1 ← (( do (la_to_pa (Sail.BitVec.truncate one__plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let _2_plus_lin_addr : (sbits 50) := (bits_of_int (2 +i (BitVec.toInt lin_addr)) 50)
              let p_addr2 ← (( do (la_to_pa (Sail.BitVec.truncate _2_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let three__plus_lin_addr : (sbits 51) := (bits_of_int (3 +i (BitVec.toInt lin_addr)) 51)
              let p_addr3 ← (( do (la_to_pa (Sail.BitVec.truncate three__plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let _4_plus_lin_addr : (sbits 52) := (bits_of_int (4 +i (BitVec.toInt lin_addr)) 52)
              let p_addr4 ← (( do (la_to_pa (Sail.BitVec.truncate _4_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let five__plus_lin_addr : (sbits 53) := (bits_of_int (5 +i (BitVec.toInt lin_addr)) 53)
              let p_addr5 ← (( do (la_to_pa (Sail.BitVec.truncate five__plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let _6_plus_lin_addr : (sbits 54) := (bits_of_int (6 +i (BitVec.toInt lin_addr)) 54)
              let p_addr6 ← (( do (la_to_pa (Sail.BitVec.truncate _6_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let seven__plus_lin_addr : (sbits 55) := (bits_of_int (7 +i (BitVec.toInt lin_addr)) 55)
              let p_addr7 ← (( do (la_to_pa (Sail.BitVec.truncate seven__plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let _8_plus_lin_addr : (sbits 56) := (bits_of_int (8 +i (BitVec.toInt lin_addr)) 56)
              let p_addr8 ← (( do (la_to_pa (Sail.BitVec.truncate _8_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let nine__plus_lin_addr : (sbits 57) := (bits_of_int (9 +i (BitVec.toInt lin_addr)) 57)
              let p_addr9 ← (( do (la_to_pa (Sail.BitVec.truncate nine__plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_0_plus_lin_addr : (sbits 58) := (bits_of_int (10 +i (BitVec.toInt lin_addr)) 58)
              let p_addr10 ← (( do (la_to_pa (Sail.BitVec.truncate one_0_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_1_plus_lin_addr : (sbits 59) := (bits_of_int (11 +i (BitVec.toInt lin_addr)) 59)
              let p_addr11 ← (( do (la_to_pa (Sail.BitVec.truncate one_1_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_2_plus_lin_addr : (sbits 60) := (bits_of_int (12 +i (BitVec.toInt lin_addr)) 60)
              let p_addr12 ← (( do (la_to_pa (Sail.BitVec.truncate one_2_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_3_plus_lin_addr : (sbits 61) := (bits_of_int (13 +i (BitVec.toInt lin_addr)) 61)
              let p_addr13 ← (( do (la_to_pa (Sail.BitVec.truncate one_3_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_4_plus_lin_addr : (sbits 62) := (bits_of_int (14 +i (BitVec.toInt lin_addr)) 62)
              let p_addr14 ← (( do (la_to_pa (Sail.BitVec.truncate one_4_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let one_5_plus_lin_addr : (sbits 63) := (bits_of_int (15 +i (BitVec.toInt lin_addr)) 63)
              let p_addr15 ← (( do (la_to_pa (Sail.BitVec.truncate one_5_plus_lin_addr 48) r_x) ) : SailM (BitVec 52) )
              let byte0 ← (( do (memi (Sail.BitVec.zeroExtend p_addr0 64)) ) : SailM (BitVec 8) )
              let byte1 ← (( do (memi (Sail.BitVec.zeroExtend p_addr1 64)) ) : SailM (BitVec 8) )
              let byte2 ← (( do (memi (Sail.BitVec.zeroExtend p_addr2 64)) ) : SailM (BitVec 8) )
              let byte3 ← (( do (memi (Sail.BitVec.zeroExtend p_addr3 64)) ) : SailM (BitVec 8) )
              let byte4 ← (( do (memi (Sail.BitVec.zeroExtend p_addr4 64)) ) : SailM (BitVec 8) )
              let byte5 ← (( do (memi (Sail.BitVec.zeroExtend p_addr5 64)) ) : SailM (BitVec 8) )
              let byte6 ← (( do (memi (Sail.BitVec.zeroExtend p_addr6 64)) ) : SailM (BitVec 8) )
              let byte7 ← (( do (memi (Sail.BitVec.zeroExtend p_addr7 64)) ) : SailM (BitVec 8) )
              let byte8 ← (( do (memi (Sail.BitVec.zeroExtend p_addr8 64)) ) : SailM (BitVec 8) )
              let byte9 ← (( do (memi (Sail.BitVec.zeroExtend p_addr9 64)) ) : SailM (BitVec 8) )
              let byte10 ← (( do (memi (Sail.BitVec.zeroExtend p_addr10 64)) ) : SailM (BitVec 8) )
              let byte11 ← (( do (memi (Sail.BitVec.zeroExtend p_addr11 64)) ) : SailM (BitVec 8) )
              let byte12 ← (( do (memi (Sail.BitVec.zeroExtend p_addr12 64)) ) : SailM (BitVec 8) )
              let byte13 ← (( do (memi (Sail.BitVec.zeroExtend p_addr13 64)) ) : SailM (BitVec 8) )
              let byte14 ← (( do (memi (Sail.BitVec.zeroExtend p_addr14 64)) ) : SailM (BitVec 8) )
              let byte15 ← (( do (memi (Sail.BitVec.zeroExtend p_addr15 64)) ) : SailM (BitVec 8) )
              (pure (byte15 +++ (byte14 +++ (byte13 +++ (byte12 +++ (byte11 +++ (byte10 +++ (byte9 +++ (byte8 +++ (byte7 +++ (byte6 +++ (byte5 +++ (byte4 +++ (byte3 +++ (byte2 +++ (byte1 +++ byte0)))))))))))))))))))
  else (do (x86_model_error "rml128")))

/-- Type quantifiers: nbytes : Nat, List.elem nbytes [1, 2, 4, 6, 8, 10, 16] -/
def rml_size (nbytes : Nat) (addr : (BitVec 48)) (r_x : String) : SailM (BitVec 128) := do
  match nbytes with
  | 1 => (pure (Sail.BitVec.zeroExtend (← (rml08 addr r_x)) 128))
  | 2 => (pure (Sail.BitVec.zeroExtend (← (rml16 addr r_x)) 128))
  | 4 => (pure (Sail.BitVec.zeroExtend (← (rml32 addr r_x)) 128))
  | 6 => (pure (Sail.BitVec.zeroExtend (← (rml48 addr r_x)) 128))
  | 8 => (pure (Sail.BitVec.zeroExtend (← (rml64 addr r_x)) 128))
  | 10 => (pure (Sail.BitVec.zeroExtend (← (rml80 addr r_x)) 128))
  | 16 => (rml128 addr r_x)
  | _ =>
    (do
      (if ((← (canonical_address_p ((Neg.neg 1) +i (nbytes +i (BitVec.toInt addr))))) : Bool)
      then (do (pure (sail_mask 128 (← (rb nbytes addr r_x)))))
      else (do (x86_model_error "rml-size"))))

/-- Type quantifiers: seg_reg : Nat, 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def segment_base_and_bounds (proc_mode : proc_mode) (seg_reg : Nat) : SailM ((BitVec 64) × Int × (BitVec 32)) := do
  (if ((in_64bit_mode proc_mode) : Bool)
  then
    (do (if ((seg_reg == 4) : Bool)
        then (do (pure ((← (read_msr 1)), 0, 0x00000000#32)))
        else
          (do (if ((seg_reg == 5) : Bool)
              then (do (pure ((← (read_msr 2)), 0, 0x00000000#32)))
              else (do (pure (0x0000000000000000#64, 0, 0x00000000#32)))))))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do let base ← (( do (pure (loghead_bits 64 (GetElem?.getElem! (← readReg seg_hidden_bases) seg_reg))) ) : SailM (BitVec 64) )
              let limit ← (( do (pure (loghead_bits 32 (GetElem?.getElem! (← readReg seg_hidden_limits) seg_reg))) ) : SailM (BitVec 32) )
              let attr ← (( do (pure (loghead_bits 16 (GetElem?.getElem! (← readReg seg_hidden_attrs) seg_reg))) ) : SailM (BitVec 16) )
              let d_b : (BitVec 1) :=
                if ((seg_reg == 1) : Bool)
                then (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits attr))
                else (_get_data_segment_descriptor_attributesbits_d_b (Mk_data_segment_descriptor_attributesbits attr))
              let e : (BitVec 1) :=
                if ((seg_reg == 1) : Bool)
                then 0#1
                else (_get_data_segment_descriptor_attributesbits_e (Mk_data_segment_descriptor_attributesbits attr))
              let lower : Int :=
                if ((e == 1#1) : Bool)
                then (1 +i (BitVec.toNatInt limit))
                else 0
              let upper : (BitVec 32) :=
                if ((e == 1#1) : Bool)
                then
                  (if ((d_b == 1#1) : Bool)
                  then 0xFFFFFFFF#32
                  else 0x0000FFFF#32)
                else limit
              (pure ((Sail.BitVec.zeroExtend (Sail.BitVec.truncate base 32) 64), lower, upper)))
        else (do (pure (0x0000000000000000#64, 0, 0x00000000#32))))))

/-- Type quantifiers: nbytes : Nat, seg_reg : Nat, 0 ≤ seg_reg ∧ seg_reg ≤ 5, List.elem nbytes [1, 2, 4, 6, 8, 10, 16, 32, 64] -/
def ea_to_la (proc_mode : proc_mode) (eff_addr : (BitVec 64)) (seg_reg : Nat) (nbytes : Nat) : SailM (BitVec 64) := do
  (if ((in_64bit_mode proc_mode) : Bool)
  then
    (do let lin_addr ← (( do
          (if (((seg_reg == 4) || (seg_reg == 5)) : Bool)
          then
            (do let (base, _, _) ← (( do (segment_base_and_bounds Mode_64bit seg_reg) ) : SailM ((BitVec 64) × Int × (BitVec 32)) )
                (pure (bits_of_int ((BitVec.toNatInt base) +i (BitVec.toNatInt eff_addr)) 64)))
          else (do (pure eff_addr))) ) : SailM (sbits 64) )
        (if ((! (← (canonical_address_p (BitVec.toInt lin_addr)))) : Bool)
        then (do (x86_model_error ":NON-CANONICAL-ADDRESS"))
        else (do (pure ())))
        (pure lin_addr))
  else
    (do (if ((in_compatibility_mode proc_mode) : Bool)
        then
          (do (if ((←((pure (! (seg_reg == 1))) <&&> (do
                   (pure (! (seg_reg == 2))) <&&> (do
                     (pure ((BitVec.toNatInt (GetElem?.getElem! (← readReg seg_visibles) seg_reg)) <b 4)))))) : Bool)
              then (do (x86_model_error ":NULL-SEGMENT-SELECTOR"))
              else (do (pure ())))
              let (base, lower_bound, upper_bound) ← (( do (segment_base_and_bounds proc_mode seg_reg) ) : SailM ((BitVec 64) × Int × (BitVec 32)) )
              let base : (BitVec 32) := (Sail.BitVec.truncate base 32)
              let lower_bound : (BitVec 33) := (bits_of_int lower_bound 33)
              let first_addr : (sbits 64) := eff_addr
              let last_addr : Int := ((BitVec.toInt eff_addr) +i (nbytes +i (Neg.neg 1)))
              (if ((! (((BitVec.toNatInt lower_bound) ≤b (BitVec.toInt first_addr)) && ((last_addr ≤b (BitVec.toNatInt upper_bound)) : Bool))) : Bool)
              then (do (x86_model_error ":SEGMENT-LIMIT-FAIL"))
              else (do (pure ())))
              let lin_addr : (BitVec 32) := (bits_of_int ((BitVec.toNatInt base) +i (BitVec.toNatInt (Sail.BitVec.truncate eff_addr 32))) 32)
              (pure (Sail.BitVec.zeroExtend lin_addr 64)))
        else (do (x86_model_error ":UNIMPLEMENTED-PROC-MODE")))))

def ia32e_valid_code_segment_descriptor_p (descriptor : (BitVec 64)) : (Bool × (String × (BitVec 64))) :=
  if ((! ((_get_code_segment_descriptorbits_msb_of_type (Mk_code_segment_descriptorbits descriptor)) == 1#1)) : Bool)
  then (false, (":INVALID-SEGMENT-TYPE", descriptor))
  else
    (if ((! ((_get_code_segment_descriptorbits_s (Mk_code_segment_descriptorbits descriptor)) == 1#1)) : Bool)
    then (false, (":INVALID-SEGMENT-TYPE", descriptor))
    else
      (if ((! ((_get_code_segment_descriptorbits_p (Mk_code_segment_descriptorbits descriptor)) == 1#1)) : Bool)
      then (false, (":SEGMENT-NOT-PRESENT", descriptor))
      else
        (if ((! ((_get_code_segment_descriptorbits_l (Mk_code_segment_descriptorbits descriptor)) == 1#1)) : Bool)
        then (false, (":IA32E-MODE-OFF", descriptor))
        else
          (if ((! ((_get_code_segment_descriptorbits_d (Mk_code_segment_descriptorbits descriptor)) == 0#1)) : Bool)
          then (false, (":IA32E-DEFAULT-OPERAND-SIZE-INCORRECT", descriptor))
          else (true, ("", 0x0000000000000000#64))))))

def ia32e_valid_ldt_segment_descriptor_p (descriptor : (BitVec 128)) : (Bool × (String × (BitVec 128))) :=
  let sailtype : (BitVec 4) := (_get_system_segment_descriptorbits_sailtype (Mk_system_segment_descriptorbits descriptor))
  if ((! (sailtype == 0x2#4)) : Bool)
  then (false, (":INVALID-TYPE", descriptor))
  else
    (if ((! ((_get_system_segment_descriptorbits_s (Mk_system_segment_descriptorbits descriptor)) == 0#1)) : Bool)
    then (false, (":INVALID-SEGMENT-TYPE", descriptor))
    else
      (if ((! ((_get_system_segment_descriptorbits_p (Mk_system_segment_descriptorbits descriptor)) == 1#1)) : Bool)
      then (false, (":SEGMENT-NOT-PRESENT", descriptor))
      else
        (if ((! ((_get_system_segment_descriptorbits_all_zeroes? (Mk_system_segment_descriptorbits descriptor)) == 0b00000#5)) : Bool)
        then (false, (":ALL-ZEROES-ABSENT", descriptor))
        else (true, ("", 0x00000000000000000000000000000000#128)))))

def ia32e_valid_call_gate_segment_descriptor_p (descriptor : (BitVec 128)) : (Bool × (String × (BitVec 128))) :=
  let sailtype : (BitVec 4) := (_get_call_gate_descriptorbits_sailtype (Mk_call_gate_descriptorbits descriptor))
  if ((! (sailtype == 0xC#4)) : Bool)
  then (false, (":INVALID-TYPE", descriptor))
  else
    (if ((! ((_get_call_gate_descriptorbits_s (Mk_call_gate_descriptorbits descriptor)) == 0#1)) : Bool)
    then (false, (":INVALID-SEGMENT-TYPE", descriptor))
    else
      (if ((! ((_get_call_gate_descriptorbits_p (Mk_call_gate_descriptorbits descriptor)) == 1#1)) : Bool)
      then (false, (":SEGMENT-NOT-PRESENT", descriptor))
      else
        (if ((! ((_get_call_gate_descriptorbits_all_zeroes? (Mk_call_gate_descriptorbits descriptor)) == 0b00000#5)) : Bool)
        then (false, (":ALL-ZEROES-ABSENT", descriptor))
        else (true, ("", 0x00000000000000000000000000000000#128)))))

def make_code_segment_attr_field (descriptor : (BitVec 64)) : (BitVec 16) :=
  let a : (BitVec 1) := (_get_code_segment_descriptorbits_a (Mk_code_segment_descriptorbits descriptor))
  let r : (BitVec 1) := (_get_code_segment_descriptorbits_r (Mk_code_segment_descriptorbits descriptor))
  let c : (BitVec 1) := (_get_code_segment_descriptorbits_c (Mk_code_segment_descriptorbits descriptor))
  let msb_of_type : (BitVec 1) := (_get_code_segment_descriptorbits_msb_of_type (Mk_code_segment_descriptorbits descriptor))
  let s : (BitVec 1) := (_get_code_segment_descriptorbits_s (Mk_code_segment_descriptorbits descriptor))
  let dpl : (BitVec 2) := (_get_code_segment_descriptorbits_dpl (Mk_code_segment_descriptorbits descriptor))
  let p : (BitVec 1) := (_get_code_segment_descriptorbits_p (Mk_code_segment_descriptorbits descriptor))
  let avl : (BitVec 1) := (_get_code_segment_descriptorbits_avl (Mk_code_segment_descriptorbits descriptor))
  let l : (BitVec 1) := (_get_code_segment_descriptorbits_l (Mk_code_segment_descriptorbits descriptor))
  let g : (BitVec 1) := (_get_code_segment_descriptorbits_g (Mk_code_segment_descriptorbits descriptor))
  (_update_code_segment_descriptor_attributesbits_g (_update_code_segment_descriptor_attributesbits_l (_update_code_segment_descriptor_attributesbits_avl (_update_code_segment_descriptor_attributesbits_p (_update_code_segment_descriptor_attributesbits_dpl (_update_code_segment_descriptor_attributesbits_s (_update_code_segment_descriptor_attributesbits_msb_of_type (_update_code_segment_descriptor_attributesbits_c (_update_code_segment_descriptor_attributesbits_r (_update_code_segment_descriptor_attributesbits_a (Mk_code_segment_descriptor_attributesbits 0x0000#16) a) r) c) msb_of_type) s) dpl) p) avl) l) g)

def make_system_segment_attr_field (descriptor : (BitVec 128)) : (BitVec 16) :=
  let sailtype : (BitVec 4) := (_get_system_segment_descriptorbits_sailtype (Mk_system_segment_descriptorbits descriptor))
  let s : (BitVec 1) := (_get_system_segment_descriptorbits_s (Mk_system_segment_descriptorbits descriptor))
  let dpl : (BitVec 2) := (_get_system_segment_descriptorbits_dpl (Mk_system_segment_descriptorbits descriptor))
  let p : (BitVec 1) := (_get_system_segment_descriptorbits_p (Mk_system_segment_descriptorbits descriptor))
  let avl : (BitVec 1) := (_get_system_segment_descriptorbits_avl (Mk_system_segment_descriptorbits descriptor))
  let g : (BitVec 1) := (_get_system_segment_descriptorbits_g (Mk_system_segment_descriptorbits descriptor))
  (_update_system_segment_descriptor_attributesbits_g (_update_system_segment_descriptor_attributesbits_avl (_update_system_segment_descriptor_attributesbits_p (_update_system_segment_descriptor_attributesbits_dpl (_update_system_segment_descriptor_attributesbits_s (_update_system_segment_descriptor_attributesbits_sailtype (Mk_system_segment_descriptor_attributesbits 0x0000#16) sailtype) s) dpl) p) avl) g)

/-- Type quantifiers: k_ex494343_ : Bool, operand_size : Nat, List.elem operand_size [1, 2, 4, 6, 8, 10, 16, 32, 64] -/
def address_aligned_p (addr : (BitVec 48)) (operand_size : Nat) (memory_ptr? : Bool) : SailM Bool := do
  match operand_size with
  | 1 => (pure true)
  | 6 => (pure ((addr &&& 0x000000000003#48) == 0x000000000000#48))
  | 10 => (pure ((addr &&& 0x000000000007#48) == 0x000000000000#48))
  | _ =>
    (do
      (if ((memory_ptr? && (operand_size == 4)) : Bool)
      then (do (pure ((addr &&& 0x000000000001#48) == 0x000000000000#48)))
      else (do (pure ((addr &&& (bits_of_int (← (check_range 0 65 (operand_size -i 1))) 48)) == 0x000000000000#48)))))

/-- Type quantifiers: k_ex494348_ : Bool, k_ex494347_ : Bool, seg_reg : Nat, nbytes : Nat, addr_size : Nat, List.elem addr_size [2, 4, 8], List.elem nbytes [1, 2, 4, 6, 8, 10, 16], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def check_linear_memory_access (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (lin_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (access_kind : String) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM Unit := do
  (if ((! (←((pure (! check_alignment?)) <||> (do
         (address_aligned_p (Sail.BitVec.truncate lin_addr 48) nbytes mem_ptr?))))) : Bool)
  then (do (x86_fault ":UNALIGNED-LINEAR-ADDRESS"))
  else (do (pure ())))

def select_base_register (proc_mode : proc_mode) (rex_byte : (BitVec 8)) (r_m : (BitVec 3)) (mod_var : (BitVec 2)) (sib : (BitVec 8)) : (Option Nat) :=
  none

def select_address_size (proc_mode : proc_mode) (prefixes : (Option (BitVec 52))) : SailM Int := do
  let p4? : Bool :=
    match prefixes with
    | .some prefixes => (0x67#8 == (_get_prefixes_adr prefixes))
    | none => false
  (if ((in_64bit_mode proc_mode) : Bool)
  then
    (do (if (p4? : Bool)
        then (do (pure 4))
        else (do (pure 8))))
  else
    (do let cs_attr ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)) ) : SailM (BitVec 16) )
        let cs_d : (BitVec 1) := (_get_code_segment_descriptor_attributesbits_d (Mk_code_segment_descriptor_attributesbits cs_attr))
        (if ((cs_d == 1#1) : Bool)
        then
          (do (if (p4? : Bool)
              then (do (pure 2))
              else (do (pure 4))))
        else
          (do (if (p4? : Bool)
              then (do (pure 4))
              else (do (pure 2)))))))

def select_moffset_size (proc_mode : proc_mode) (prefixes : (Option (BitVec 52))) : SailM Int := do
  (select_address_size proc_mode prefixes)

def select_segment_register (proc_mode : proc_mode) (prefixes : (BitVec 52)) (mod_var : (BitVec 2)) (r_m : (BitVec 3)) (sib : (BitVec 8)) : SailM Nat := do
  let v_28 := (_get_prefixes_seg prefixes)
  (if ((eq_bits_nat v_28 46) : Bool)
  then (do (pure 1))
  else
    (do (if ((eq_bits_nat v_28 54) : Bool)
        then (do (pure 2))
        else
          (do (if ((eq_bits_nat v_28 62) : Bool)
              then (do (pure 3))
              else
                (do (if ((eq_bits_nat v_28 38) : Bool)
                    then (do (pure 0))
                    else
                      (do (if ((eq_bits_nat v_28 100) : Bool)
                          then (do (pure 4))
                          else
                            (do (if ((eq_bits_nat v_28 101) : Bool)
                                then (do (pure 5))
                                else
                                  (do let addr_size ← (( do (select_address_size proc_mode (some prefixes)) ) : SailM Int )
                                      (if ((addr_size == 2) : Bool)
                                      then
                                        (do (if (((! (mod_var == 0b11#2)) && ((r_m == 0b010#3) || (r_m == 0b011#3))) : Bool)
                                            then (do (pure 2))
                                            else (do (pure 3))))
                                      else
                                        (do (if (((((mod_var == 0b01#2) || (mod_var == 0b10#2)) && (r_m == 0b101#3)) || ((! (mod_var == 0b11#2)) && ((r_m == 0b100#3) && ((_get_sib_base sib) == 0b100#3)))) : Bool)
                                            then (do (pure 2))
                                            else (do (pure 3)))))))))))))))))

/-- Type quantifiers: k_ex494352_ : Bool, k_ex494351_ : Bool, seg_reg : Nat, addr_size : Nat, nbytes : Nat, List.elem nbytes [1, 2, 4, 6, 8, 10, 16], List.elem addr_size [2, 4, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def load_bytes_from_ea (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (r_x : String) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM (BitVec (8 * nbytes)) := do
  let cs_attrs ← do (pure (Mk_code_segment_descriptor_attributesbits (GetElem?.getElem! (← readReg seg_hidden_attrs) 1)))
  (if (((! (in_64bit_mode proc_mode)) && ((seg_reg == 1) && ((r_x == ":R") && ((_get_code_segment_descriptor_attributesbits_r cs_attrs) == 0#1)))) : Bool)
  then (do (x86_fault ":EXECUTE-ONLY-CODE-SEGMENT"))
  else
    (do let lin_addr ← (( do (ea_to_la proc_mode eff_addr seg_reg nbytes) ) : SailM (sbits 64) )
        (check_linear_memory_access proc_mode addr_size nbytes lin_addr base_reg seg_reg r_x check_alignment? mem_ptr?)
        (rb nbytes lin_addr r_x)))

/-- Type quantifiers: k_ex494356_ : Bool, k_ex494355_ : Bool, seg_reg : Nat, addr_size : Nat, nbytes : Nat, List.elem nbytes [1, 2, 4, 6, 8, 10, 16], List.elem addr_size [2, 4, 8], 0 ≤ seg_reg ∧ seg_reg ≤ 5 -/
def store_bytes_to_ea (proc_mode : proc_mode) (addr_size : Nat) (nbytes : Nat) (eff_addr : (BitVec 64)) (base_reg : (Option Nat)) (seg_reg : Nat) (data : (BitVec (8 * nbytes))) (check_alignment? : Bool) (mem_ptr? : Bool) : SailM Unit := do
  let seg_attrs ← do (pure (Mk_data_segment_descriptor_attributesbits (GetElem?.getElem! (← readReg seg_hidden_attrs) seg_reg)))
  (if (((! (in_64bit_mode proc_mode)) && ((seg_reg == 1) || ((_get_data_segment_descriptor_attributesbits_w seg_attrs) == 0#1))) : Bool)
  then (do (x86_fault ":NON-WRITABLE-SEGMENT"))
  else
    (do let lin_addr ← (( do (ea_to_la proc_mode eff_addr seg_reg nbytes) ) : SailM (sbits 64) )
        (check_linear_memory_access proc_mode addr_size nbytes lin_addr base_reg seg_reg ":W" check_alignment? mem_ptr?)
        (wb nbytes lin_addr ":W" data)))

def cf_spec8 (raw_result : (BitVec 9)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (unsigned_byte_p_int 8 (BitVec.toNatInt raw_result))))))

def cf_spec16 (raw_result : (BitVec 17)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (unsigned_byte_p_int 16 (BitVec.toNatInt raw_result))))))

def cf_spec32 (raw_result : (BitVec 33)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (unsigned_byte_p_int 32 (BitVec.toNatInt raw_result))))))

def cf_spec64 (raw_result : (BitVec 65)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (unsigned_byte_p_int 64 (BitVec.toNatInt raw_result))))))

def of_spec8 (signed_raw_result : (BitVec 9)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (signed_byte_p_int 8 (BitVec.toInt signed_raw_result))))))

def of_spec16 (signed_raw_result : (BitVec 17)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (signed_byte_p_int 16 (BitVec.toInt signed_raw_result))))))

def of_spec32 (signed_raw_result : (BitVec 33)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (signed_byte_p_int 32 (BitVec.toInt signed_raw_result))))))

def of_spec64 (signed_raw_result : (BitVec 65)) : SailM (BitVec 1) := do
  (pure (bool_to_bits (! (← (signed_byte_p_int 64 (BitVec.toInt signed_raw_result))))))

/-- Type quantifiers: result : Nat, 0 ≤ result -/
def zf_spec (result : Nat) : (BitVec 1) :=
  if ((result == 0) : Bool)
  then 1#1
  else 0#1


end X86Sail.Functions
