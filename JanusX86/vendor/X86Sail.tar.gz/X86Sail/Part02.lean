import X86Sail.Part01

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

/-- Type quantifiers: j : Int, i : Int -/
def logior_int (i : Int) (j : Int) : Int :=
  (lognot_int (logand_int (lognot_int i) (lognot_int j)))

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def logxor (x : (BitVec k_n)) (y : (BitVec k_n)) : (BitVec k_n) :=
  (x ^^^ y)

/-- Type quantifiers: j : Int, i : Int, size : Int -/
def binary_logapp (size : Int) (i : Int) (j : Int) : Int :=
  ((loghead_int size i) +i (j *i (2 ^i size)))

/-- Type quantifiers: i : Int, size : Int -/
def binary_logext (size : Int) (i : Int) : SailM Int := do
  sail_assert (0 <b size) "prelude.sail:442.16-442.17"
  (pure (binary_logapp (size -i 1) i
      (← do
        (if ((← (logbitp_int (size -i 1) i)) : Bool)
        then (do (pure (Neg.neg 1)))
        else (do (pure 0))))))

/-- Type quantifiers: x : Int, n : Nat, n ≥ 0 -/
def ash_left_int (x : Int) (n : Nat) : Int :=
  (x *i (2 ^i n))

/-- Type quantifiers: c : Int, i : Int -/
def ash_int (i : Int) (c : Int) : Int :=
  if ((c == 0) : Bool)
  then i
  else
    (if ((c >b 0) : Bool)
    then (Int.shiftl i c)
    else (Int.shiftr i (Neg.neg c)))

/-- Type quantifiers: x : Int -/
def abs (x : Int) : Int :=
  if ((x <b 0) : Bool)
  then (Neg.neg x)
  else x

/-- Type quantifiers: y : Int, x : Int -/
def mod (x : Int) (y : Int) : Int :=
  (x -i ((floor2 x y) *i y))

/-- Type quantifiers: places : Int, width : Int, k_n : Int -/
def rotate_left_bits (x : (BitVec k_n)) (width : Int) (places : Int) : (BitVec k_n) :=
  let high := (x <<< places)
  let low := (x >>> (width -i places))
  (high ||| low)

/-- Type quantifiers: places : Int, width : Int, k_n : Int -/
def rotate_right_bits (x : (BitVec k_n)) (width : Int) (places : Int) : (BitVec k_n) :=
  let low := (x >>> places)
  let high := (x <<< (width -i places))
  (high ||| low)

/-- Type quantifiers: v : Int, width : Int, low : Int, x : Int -/
def changeSlice_int (x : Int) (low : Int) (width : Int) (v : Int) : Int :=
  (set_slice_int width x low (get_slice_int width v 0))

/-- Type quantifiers: k_n : Nat, low : Nat, width : Nat, low ≥ 0 ∧ width > 0 ∧ (low + width) ≤ k_n -/
def changeSlice_bits (x : (BitVec k_n)) (low : Nat) (width : Nat) (v : (BitVec width)) : (BitVec k_n) :=
  (Sail.BitVec.updateSubrange x ((low +i width) -i 1) low v)

def regval_from_reg (r : (BitVec 64)) : (BitVec 64) :=
  r

def read_rip (_ : Unit) : SailM (BitVec 48) := do
  (pure (Sail.BitVec.truncate (regval_from_reg (← readReg rip)) 48))

/-- Type quantifiers: k_addr_width : Nat, len : Nat, k_addr_width > 0 ∧ len > 0 -/
def log_memory_read (addr : (BitVec k_addr_width)) (len : Nat) (value : (BitVec (8 * len))) : SailM Unit := do
  (pure (print_endline (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (BitVec.toFormatted (← (read_rip ()))) ": R ") (BitVec.toFormatted addr)) " ") (Int.repr len)) " ") (BitVec.toFormatted value))))

/-- Type quantifiers: k_addr_width : Nat, k_addr_width > 0 -/
def memi (addr : (BitVec k_addr_width)) : SailM (BitVec 8) := do
  let result ← do (read_mem Read_plain 64 (sail_mask 64 addr) 1)
  (log_memory_read addr 1 result)
  (pure result)

/-- Type quantifiers: k_addr_width : Nat, len : Nat, k_addr_width > 0 ∧ len > 0 -/
def log_memory_write (addr : (BitVec k_addr_width)) (len : Nat) (value : (BitVec (8 * len))) : SailM Unit := do
  (pure (print_endline (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (HAppend.hAppend (BitVec.toFormatted (← (read_rip ()))) ": W ") (BitVec.toFormatted addr)) " ") (Int.repr len)) " ") (BitVec.toFormatted value))))

/-- Type quantifiers: k_addr_width : Nat, k_addr_width > 0 -/
def bang_memi (addr : (BitVec k_addr_width)) (valToWrite : (BitVec 8)) : SailM Unit := do
  let dummy ← do (write_mem_ea Write_plain 64 (sail_mask 64 addr) 1)
  let dummy2 ← do (write_mem Write_plain 64 (sail_mask 64 addr) 1 valToWrite)
  (log_memory_write addr 1 valToWrite)

def ms (_ : Unit) : SailM Bool := do
  readReg ms_reg

def fault (_ : Unit) : SailM Bool := do
  readReg fault_reg

/-- Type quantifiers: lin_addr : Int -/
def canonical_address_p (lin_addr : Int) : SailM Bool := do
  (signed_byte_p_int 48 lin_addr)

def Mk_cr0bits (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_cr3bits (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_cr4bits (v : (BitVec 22)) : (BitVec 22) :=
  v

def Mk_ia32_eferbits (v : (BitVec 12)) : (BitVec 12) :=
  v

def Mk_segment_selectorbits (v : (BitVec 16)) : (BitVec 16) :=
  v

def _get_cr0bits_wp (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_cr3bits_pdb (v : (BitVec 64)) : (BitVec 40) :=
  (Sail.BitVec.extractLsb v 51 12)

def _get_cr4bits_smap (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_cr4bits_smep (v : (BitVec 22)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_ia32_eferbits_nxe (v : (BitVec 12)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_rflagsbits_ac (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_segment_selectorbits_rpl (v : (BitVec 16)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 1 0)

def Mk_ia32e_page_tablesbits (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ia32e_pml4ebits (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ia32e_pml4ebits_pdpt (v : (BitVec 64)) : (BitVec 40) :=
  (Sail.BitVec.extractLsb v 51 12)

def _get_ia32e_page_tablesbits_a (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def accessed_bit (entry : (BitVec 64)) : (BitVec 1) :=
  (_get_ia32e_page_tablesbits_a (Mk_ia32e_page_tablesbits entry))

def Mk_ia32e_pdpte_1gb_pagebits (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ia32e_pdpte_pg_dirbits (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ia32e_pdpte_1gb_pagebits_page (v : (BitVec 64)) : (BitVec 22) :=
  (Sail.BitVec.extractLsb v 51 30)

def _get_ia32e_pdpte_pg_dirbits_pd (v : (BitVec 64)) : (BitVec 40) :=
  (Sail.BitVec.extractLsb v 51 12)

def _get_ia32e_page_tablesbits_d (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def dirty_bit (entry : (BitVec 64)) : (BitVec 1) :=
  (_get_ia32e_page_tablesbits_d (Mk_ia32e_page_tablesbits entry))


end X86Sail.Functions
