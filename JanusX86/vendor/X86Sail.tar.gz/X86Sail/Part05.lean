import X86Sail.Part04

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def _update_prefixes_nxt (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 51 44 x)

def _get_prefixes_opr (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 35 28)

def _update_prefixes_opr (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 35 28 x)

def _get_prefixes_rep (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 19 12)

def _update_prefixes_rep (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 19 12 x)

def _get_prefixes_seg (v : (BitVec 52)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 27 20)

def _update_prefixes_seg (v : (BitVec 52)) (x : (BitVec 8)) : (BitVec 52) :=
  (Sail.BitVec.updateSubrange v 27 20 x)

/-- Type quantifiers: cnt : Nat, 0 ≤ cnt ∧ cnt ≤ 15 -/
def is_ext_prefix_byte (proc_mode : proc_mode) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (cnt : Nat) (byte : (BitVec 8)) : Bool :=
  false

/-- Type quantifiers: cnt : Nat, 0 ≤ cnt ∧ cnt ≤ 15 -/
def process_ext_prefix_byte (proc_mode : proc_mode) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (cnt : Nat) (byte : (BitVec 8)) : ((BitVec 52) × (BitVec 8) × Bool) :=
  (prefixes, rex_byte, false)

def ext_one_byte_opcode_execute (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : Bool :=
  false

def ext_two_byte_opcode_execute (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (mandatory_prefix : (BitVec 8)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : Bool :=
  false

def unimplemented_x86_syscall_app_view (x_0 : proc_mode) (x_1 : (BitVec 48)) (x_2 : (BitVec 48)) (x_3 : (BitVec 52)) (x_4 : (BitVec 8)) (x_5 : (BitVec 8)) (x_6 : (BitVec 8)) (x_7 : (BitVec 8)) : SailM Unit := do
  sailThrow ((Syscall ()))

def _update_segment_selectorbits_rpl (v : (BitVec 16)) (x : (BitVec 2)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 1 0 x)

def _get_segment_selectorbits_ti (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def Mk_gdtr_idtrbits (v : (BitVec 80)) : (BitVec 80) :=
  v

def _get_gdtr_idtrbits_base_addr (v : (BitVec 80)) : (BitVec 64) :=
  (Sail.BitVec.extractLsb v 63 0)

def _update_gdtr_idtrbits_base_addr (v : (BitVec 80)) (x : (BitVec 64)) : (BitVec 80) :=
  (Sail.BitVec.updateSubrange v 63 0 x)

def _get_gdtr_idtrbits_limit (v : (BitVec 80)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 79 64)

def _update_gdtr_idtrbits_limit (v : (BitVec 80)) (x : (BitVec 16)) : (BitVec 80) :=
  (Sail.BitVec.updateSubrange v 79 64 x)

def Mk_code_segment_descriptorbits (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_code_segment_descriptorbits_a (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 40 40)

def _get_code_segment_descriptorbits_avl (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_system_segment_descriptorbits_avl (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_code_segment_descriptorbits_c (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_code_segment_descriptorbits_d (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_code_segment_descriptor_attributesbits_d (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_code_segment_descriptorbits_dpl (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 46 45)

def _get_call_gate_descriptorbits_dpl (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 46 45)

def _get_system_segment_descriptorbits_dpl (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 46 45)

def _get_code_segment_descriptorbits_g (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_system_segment_descriptorbits_g (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_code_segment_descriptorbits_l (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_code_segment_descriptorbits_limit15_0 (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_system_segment_descriptorbits_limit15_0 (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_code_segment_descriptorbits_limit19_16 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 51 48)

def _get_system_segment_descriptorbits_limit19_16 (v : (BitVec 128)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 51 48)

def _get_code_segment_descriptorbits_msb_of_type (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_code_segment_descriptorbits_p (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 47 47)

def _get_call_gate_descriptorbits_p (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 47 47)

def _get_system_segment_descriptorbits_p (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 47 47)

def _get_code_segment_descriptorbits_r (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_code_segment_descriptor_attributesbits_r (v : (BitVec 16)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_code_segment_descriptorbits_s (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_call_gate_descriptorbits_s (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_system_segment_descriptorbits_s (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _update_code_segment_descriptor_attributesbits_a (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_data_segment_descriptor_attributesbits_a (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_code_segment_descriptor_attributesbits_avl (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_system_segment_descriptor_attributesbits_avl (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_code_segment_descriptor_attributesbits_c (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_code_segment_descriptor_attributesbits_d (v : (BitVec 16)) (x : (BitVec 1)) : (BitVec 16) :=
  (Sail.BitVec.updateSubrange v 10 10 x)


end X86Sail.Functions
