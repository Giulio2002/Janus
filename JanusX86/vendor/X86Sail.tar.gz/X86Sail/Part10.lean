import X86Sail.Part09

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def div_spec_8 (dst : (BitVec 16)) (src : (BitVec 8)) : (Bool × (BitVec 16) × (BitVec 8)) :=
  let quotient : (BitVec 16) := (bits_of_int (floor2 (BitVec.toNatInt dst) (BitVec.toNatInt src)) 16)
  let remainder : (BitVec 8) := (bits_of_int (mod (BitVec.toNatInt dst) (BitVec.toNatInt src)) 8)
  let overflow? : Bool := (255 <b (BitVec.toNatInt quotient))
  if (overflow? : Bool)
  then (true, 0x0000#16, 0x00#8)
  else (overflow?, quotient, remainder)

def div_spec_16 (dst : (BitVec 32)) (src : (BitVec 16)) : (Bool × (BitVec 32) × (BitVec 16)) :=
  let quotient : (BitVec 32) := (bits_of_int (floor2 (BitVec.toNatInt dst) (BitVec.toNatInt src)) 32)
  let remainder : (BitVec 16) := (bits_of_int (mod (BitVec.toNatInt dst) (BitVec.toNatInt src)) 16)
  let overflow? : Bool := (65535 <b (BitVec.toNatInt quotient))
  if (overflow? : Bool)
  then (true, 0x00000000#32, 0x0000#16)
  else (overflow?, quotient, remainder)

def div_spec_32 (dst : (BitVec 64)) (src : (BitVec 32)) : (Bool × (BitVec 64) × (BitVec 32)) :=
  let quotient : (BitVec 64) := (bits_of_int (floor2 (BitVec.toNatInt dst) (BitVec.toNatInt src)) 64)
  let remainder : (BitVec 32) := (bits_of_int (mod (BitVec.toNatInt dst) (BitVec.toNatInt src)) 32)
  let overflow? : Bool := (4294967295 <b (BitVec.toNatInt quotient))
  if (overflow? : Bool)
  then (true, 0x0000000000000000#64, 0x00000000#32)
  else (overflow?, quotient, remainder)

def div_spec_64 (dst : (BitVec 128)) (src : (BitVec 64)) : (Bool × (BitVec 128) × (BitVec 64)) :=
  let quotient : (BitVec 128) := (bits_of_int (floor2 (BitVec.toNatInt dst) (BitVec.toNatInt src)) 128)
  let remainder : (BitVec 64) := (bits_of_int (mod (BitVec.toNatInt dst) (BitVec.toNatInt src)) 64)
  let overflow? : Bool := (18446744073709551615 <b (BitVec.toNatInt quotient))
  if (overflow? : Bool)
  then (true, 0x00000000000000000000000000000000#128, 0x0000000000000000#64)
  else (overflow?, quotient, remainder)

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def div_spec (size : Nat) (dst : (BitVec 128)) (src : (BitVec 64)) : (Bool × (BitVec 128) × (BitVec 64)) :=
  (match size with
  | 1 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 16) × (BitVec 8)) := (div_spec_8 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 8))
    (elem0, (Sail.BitVec.zeroExtend elem1 128), (Sail.BitVec.zeroExtend elem2 64)))
  | 2 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 32) × (BitVec 16)) := (div_spec_16 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 16))
    (elem0, (Sail.BitVec.zeroExtend elem1 128), (Sail.BitVec.zeroExtend elem2 64)))
  | 4 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 64) × (BitVec 32)) := (div_spec_32 (Sail.BitVec.truncate dst 64) (Sail.BitVec.truncate src 32))
    (elem0, (Sail.BitVec.zeroExtend elem1 128), (Sail.BitVec.zeroExtend elem2 64)))
  | 8 => (div_spec_64 dst src)
  | _ => (false, 0x00000000000000000000000000000000#128, 0x0000000000000000#64) : (Bool × (BitVec 128) × (BitVec 64)))

def idiv_spec_8 (dst : (BitVec 16)) (src : (BitVec 8)) : (Bool × (BitVec 8) × (BitVec 8)) :=
  let dst_int : (sbits 16) := dst
  let src_int : (sbits 8) := src
  let quotient_int : (sbits 17) := (bits_of_int (Int.tdiv (BitVec.toInt dst_int) (BitVec.toInt src_int)) 17)
  let remainder_int : (sbits 8) := (bits_of_int (Int.tmod (BitVec.toInt dst_int) (BitVec.toInt src_int)) 8)
  let overflow? : Bool := (((BitVec.toInt quotient_int) <b (Neg.neg 128)) || ((127 <b (BitVec.toInt quotient_int)) : Bool))
  if (overflow? : Bool)
  then (true, 0x00#8, 0x00#8)
  else
    (let quotient : (BitVec 8) := (Sail.BitVec.truncate quotient_int 8)
    let remainder : (BitVec 8) := remainder_int
    (overflow?, quotient, remainder))

def idiv_spec_16 (dst : (BitVec 32)) (src : (BitVec 16)) : (Bool × (BitVec 16) × (BitVec 16)) :=
  let dst_int : (sbits 32) := dst
  let src_int : (sbits 16) := src
  let quotient_int : (sbits 33) := (bits_of_int (Int.tdiv (BitVec.toInt dst_int) (BitVec.toInt src_int)) 33)
  let remainder_int : (sbits 16) := (bits_of_int (Int.tmod (BitVec.toInt dst_int) (BitVec.toInt src_int)) 16)
  let overflow? : Bool := (((BitVec.toInt quotient_int) <b (Neg.neg 32768)) || ((32767 <b (BitVec.toInt quotient_int)) : Bool))
  if (overflow? : Bool)
  then (true, 0x0000#16, 0x0000#16)
  else
    (let quotient : (BitVec 16) := (Sail.BitVec.truncate quotient_int 16)
    let remainder : (BitVec 16) := remainder_int
    (overflow?, quotient, remainder))

def idiv_spec_32 (dst : (BitVec 64)) (src : (BitVec 32)) : (Bool × (BitVec 32) × (BitVec 32)) :=
  let dst_int : (sbits 64) := dst
  let src_int : (sbits 32) := src
  let quotient_int : (sbits 65) := (bits_of_int (Int.tdiv (BitVec.toInt dst_int) (BitVec.toInt src_int)) 65)
  let remainder_int : (sbits 32) := (bits_of_int (Int.tmod (BitVec.toInt dst_int) (BitVec.toInt src_int)) 32)
  let overflow? : Bool := (((BitVec.toInt quotient_int) <b (Neg.neg 2147483648)) || ((2147483647 <b (BitVec.toInt quotient_int)) : Bool))
  if (overflow? : Bool)
  then (true, 0x00000000#32, 0x00000000#32)
  else
    (let quotient : (BitVec 32) := (Sail.BitVec.truncate quotient_int 32)
    let remainder : (BitVec 32) := remainder_int
    (overflow?, quotient, remainder))

def idiv_spec_64 (dst : (BitVec 128)) (src : (BitVec 64)) : (Bool × (BitVec 64) × (BitVec 64)) :=
  let dst_int : (sbits 128) := dst
  let src_int : (sbits 64) := src
  let quotient_int : (sbits 129) := (bits_of_int (Int.tdiv (BitVec.toInt dst_int) (BitVec.toInt src_int)) 129)
  let remainder_int : (sbits 64) := (bits_of_int (Int.tmod (BitVec.toInt dst_int) (BitVec.toInt src_int)) 64)
  let overflow? : Bool := (((BitVec.toInt quotient_int) <b (Neg.neg 9223372036854775808)) || ((9223372036854775807 <b (BitVec.toInt quotient_int)) : Bool))
  if (overflow? : Bool)
  then (true, 0x0000000000000000#64, 0x0000000000000000#64)
  else
    (let quotient : (BitVec 64) := (Sail.BitVec.truncate quotient_int 64)
    let remainder : (BitVec 64) := remainder_int
    (overflow?, quotient, remainder))

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def idiv_spec (size : Nat) (dst : (BitVec 128)) (src : (BitVec 64)) : (Bool × (BitVec 64) × (BitVec 64)) :=
  (match size with
  | 1 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 8) × (BitVec 8)) := (idiv_spec_8 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 8))
    (elem0, (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 64)))
  | 2 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 16) × (BitVec 16)) := (idiv_spec_16 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 16))
    (elem0, (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 64)))
  | 4 =>
    (let (elem0, elem1, elem2) : (Bool × (BitVec 32) × (BitVec 32)) := (idiv_spec_32 (Sail.BitVec.truncate dst 64) (Sail.BitVec.truncate src 32))
    (elem0, (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 64)))
  | 8 => (idiv_spec_64 dst src)
  | _ => (false, 0x0000000000000000#64, 0x0000000000000000#64) : (Bool × (BitVec 64) × (BitVec 64)))

def x86_div (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-DIV"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0xF6#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  (if ((reg_mem == 0x00000000000000000000000000000000#128) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :DE NIL :DE-EXCEPTION-SOURCE-OPERAND-ZERO REG/MEM)"))
  else (do (pure ())))
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let rax_var ← (( do
    (rgfi_size
      (if (select_byte_operand : Bool)
      then 0x2#4
      else (bits_of_int reg_mem_size 4)) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let rdx_var ← (( do
    (if (select_byte_operand : Bool)
    then (do (pure 0x0000000000000000#64))
    else (do (rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 rex_byte))) ) : SailM (BitVec 64) )
  let dividend : Int :=
    if (select_byte_operand : Bool)
    then (BitVec.toNatInt rax_var)
    else (changeSlice_int (BitVec.toNatInt rax_var) (ash_left_int reg_mem_size 3) (ash_left_int reg_mem_size 4) (BitVec.toNatInt rdx_var))
  let (overflow?, quotient, remainder) : (Bool × (BitVec 128) × (BitVec 64)) := (div_spec reg_mem_size (bits_of_int dividend 128) (Sail.BitVec.truncate reg_mem 64))
  (if (overflow? : Bool)
  then (do (x86_model_error ":UNSIGNED-DIVIDE-ERROR-OVERFLOW"))
  else (do (pure ())))
  match reg_mem_size with
  | 1 =>
    (do
      let result : (BitVec 128) := (changeSlice_bits quotient 8 8 (Sail.BitVec.truncate remainder 8))
      (write_rgfi_size 0x2#4 0x0#4 (Sail.BitVec.truncate result 64) rex_byte))
  | _ =>
    (do
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 (Sail.BitVec.truncate quotient 64) rex_byte)
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 remainder rex_byte))
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var sailval)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def x86_idiv (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-IDIV"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0xF6#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  (if ((reg_mem == 0x00000000000000000000000000000000#128) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :DE NIL :DE-EXCEPTION-SOURCE-OPERAND-ZERO REG/MEM)"))
  else (do (pure ())))
  let temp_rip ← (( do (pure (Sail.BitVec.signExtend (← (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48))) 49)) ) : SailM (sbits 49) )
  let badlength? : (Option Int) := (check_instruction_length start_rip (Sail.BitVec.truncate temp_rip 48) 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let rax_var ← (( do
    (rgfi_size
      (if (select_byte_operand : Bool)
      then 0x2#4
      else (bits_of_int reg_mem_size 4)) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let rdx_var ← (( do
    (if (select_byte_operand : Bool)
    then (do (pure 0x0000000000000000#64))
    else (do (rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 rex_byte))) ) : SailM (BitVec 64) )
  let dividend : Int :=
    if (select_byte_operand : Bool)
    then (BitVec.toNatInt rax_var)
    else (changeSlice_int (BitVec.toNatInt rax_var) (ash_left_int reg_mem_size 3) (ash_left_int reg_mem_size 4) (BitVec.toNatInt rdx_var))
  let (overflow?, quotient, remainder) : (Bool × (BitVec 64) × (BitVec 64)) := (idiv_spec reg_mem_size (bits_of_int dividend 128) (Sail.BitVec.truncate reg_mem 64))
  (if (overflow? : Bool)
  then (do (x86_model_error ":UNSIGNED-DIVIDE-ERROR-OVERFLOW"))
  else (do (pure ())))
  match reg_mem_size with
  | 1 =>
    (do
      let result : (BitVec 64) := (changeSlice_bits quotient 8 8 (Sail.BitVec.truncate remainder 8))
      (write_rgfi_size 0x2#4 0x0#4 result rex_byte))
  | _ =>
    (do
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 quotient rex_byte)
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 remainder rex_byte))
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var sailval)
  writeReg rflags new_rflags
  (write_iptr proc_mode (Sail.BitVec.truncate temp_rip 48))

def x86_xchg (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-XCHG"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0x86#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (val1, increment_rip_by, addr) ← (( do
    (if (((ash_int (BitVec.toNatInt opcode) (Neg.neg 4)) == 9) : Bool)
    then (do (pure ((Sail.BitVec.zeroExtend (← (rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 rex_byte)) 128), 0, 0x0000000000000000#64)))
    else (do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let rw_rd : (BitVec 3) := (Sail.BitVec.truncate (0x07#8 &&& opcode) 3)
  let val2 ← (( do
    (if (((ash_int (BitVec.toNatInt opcode) (Neg.neg 4)) == 9) : Bool)
    then (do (rgfi_size (bits_of_int reg_mem_size 4) (reg_index rw_rd rex_byte 0b00#2) rex_byte))
    else (do (rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) rex_byte))) ) : SailM (BitVec 64) )
  (if (((ash_int (BitVec.toNatInt opcode) (Neg.neg 4)) == 9) : Bool)
  then (do (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 val2 rex_byte))
  else (do (x86_operand_to_reg_mem proc_mode reg_mem_size inst_ac? false (Sail.BitVec.zeroExtend val2 128) seg_reg addr prefixes rex_byte r_m mod_var sib)))
  (if (((bits_of_int (ash_int (BitVec.toNatInt opcode) (Neg.neg 4)) 4) == 0x9#4) : Bool)
  then (do (write_rgfi_size (bits_of_int reg_mem_size 4) (reg_index rw_rd rex_byte 0b00#2) (Sail.BitVec.truncate val1 64) rex_byte))
  else (do (write_rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate val1 64) rex_byte)))
  (write_iptr proc_mode temp_rip)

def x86_cmpxchg (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-CMPXCHG"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0xB0#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let rax_var ← (( do (rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let input_rflags ← (( do readReg rflags ) : SailM rflagsbits )
  let (result, output_rflags, undefined_flags) ← (( do (gpr_arith_logic_spec reg_mem_size 8 (Sail.BitVec.truncate reg_mem 64) rax_var input_rflags) ) : SailM ((BitVec 64) × rflagsbits × rflagsbits) )
  (write_user_rflags output_rflags undefined_flags)
  (if ((result == 0x0000000000000000#64) : Bool)
  then
    (do let register_var ← (( do (rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
        (x86_operand_to_reg_mem proc_mode reg_mem_size inst_ac? false (Sail.BitVec.zeroExtend register_var 128) seg_reg addr prefixes rex_byte r_m mod_var sib))
  else (do (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 (Sail.BitVec.truncate reg_mem 64) rex_byte)))
  (write_iptr proc_mode temp_rip)

def x86_one_byte_nop (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_iptr proc_mode temp_rip)

def x86_two_byte_nop (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-TWO-BYTE-NOP"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_iptr proc_mode temp_rip)

def x86_near_jmp_op_en_d (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-NEAR-JMP-OP/EN-D"
  let byte_operand? : Bool := (opcode == 0xEB#8)
  let offset_size ← (( do (check_range 0 4 (← (select_operand_size proc_mode byte_operand? rex_byte false prefixes false true true))) ) : SailM Int )
  let offset ← (( do (pure (Sail.BitVec.truncate (← (rime_size proc_mode (← (select_address_size proc_mode (some prefixes))) offset_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false)) 32)) ) : SailM (sbits 32) )
  let next_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int offset_size 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip next_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let temp_rip ← (( do (add_to_iptr proc_mode next_rip (Sail.BitVec.signExtend offset 48)) ) : SailM (sbits 48) )
  let temp_rip : (sbits 48) :=
    if ((offset_size == 2) : Bool)
    then (0x00000000FFFF#48 &&& temp_rip)
    else temp_rip
  (write_iptr proc_mode temp_rip)

def x86_near_jmp_op_en_m (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-NEAR-JMP-OP/EN-M"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size ← (( do (check_range 2 8 (← (select_operand_size proc_mode false rex_byte false prefixes true true true))) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (jmp_addr, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let jmp_addr : (sbits 64) := (Sail.BitVec.truncate jmp_addr 64)
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let jmp_addr : (sbits 64) :=
    if ((in_64bit_mode proc_mode) : Bool)
    then jmp_addr
    else jmp_addr
  (if ((! (← do
         (if ((in_64bit_mode proc_mode) : Bool)
         then (do (canonical_address_p (BitVec.toInt jmp_addr)))
         else
           (do let cs_limit ← (( do (pure (GetElem?.getElem! (← readReg seg_hidden_limits) 1)) ) : SailM (BitVec 32) )
               (pure ((0 ≤b (BitVec.toInt jmp_addr)) && (((BitVec.toInt jmp_addr) ≤b (BitVec.toNatInt cs_limit)) : Bool))))))) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :BAD-RETURN-ADDRESS JMP-ADDR)"))
  else (do (pure ())))
  (write_iptr proc_mode (Sail.BitVec.truncate jmp_addr 48))

def x86_far_jmp_op_en_d (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-FAR-JMP-OP/EN-D"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  (if ((mod_var == 0b11#2) : Bool)
  then (do (x86_model_error ":SOURCE-OPERAND-NOT-MEMORY-LOCATION"))
  else (do (pure ())))
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let offset_size ← (( do (check_range 2 8 (← (select_operand_size proc_mode false rex_byte false prefixes false false false))) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 (2 +i offset_size) inst_ac? true seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip increment_rip_by)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let selector : (BitVec 16) := (Sail.BitVec.truncate mem 16)
  let offset ← (( do (pure (sail_mask 64 (← (bitslice mem 16 (ash_left_int offset_size 3))))) ) : SailM (BitVec 64) )
  let sel_index : (BitVec 13) := (_get_segment_selectorbits_index (Mk_segment_selectorbits selector))
  let sel_ti : (BitVec 1) := (_get_segment_selectorbits_ti (Mk_segment_selectorbits selector))
  let sel_rpl : (BitVec 2) := (_get_segment_selectorbits_rpl (Mk_segment_selectorbits selector))
  (if (((sel_ti == 0#1) && (sel_index == 0b0000000000000#13)) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :GP-NULLSELECTOR 0)"))
  else (do (pure ())))
  let (dt_base_addr, dt_limit) ← (( do
    (if ((sel_ti == 0#1) : Bool)
    then
      (do let gdtr ← (( do (pure (GetElem?.getElem! (← readReg strs) 0)) ) : SailM (BitVec 80) )
          let gdtr_base : (BitVec 64) :=
            if ((in_64bit_mode proc_mode) : Bool)
            then (_get_gdtr_idtrbits_base_addr (Mk_gdtr_idtrbits gdtr))
            else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate (_get_gdtr_idtrbits_base_addr (Mk_gdtr_idtrbits gdtr)) 32) 64)
          let gdtr_limit : (BitVec 16) := (_get_gdtr_idtrbits_limit (Mk_gdtr_idtrbits gdtr))
          (pure (gdtr_base, (Sail.BitVec.zeroExtend gdtr_limit 32))))
    else
      (do let ldtr_base ← (( do (pure (GetElem?.getElem! (← readReg ssr_hidden_bases) 0)) ) : SailM (BitVec 64) )
          let ldtr_base : (BitVec 64) :=
            if ((in_64bit_mode proc_mode) : Bool)
            then ldtr_base
            else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate ldtr_base 32) 64)
          let ldtr_limit ← (( do (pure (GetElem?.getElem! (← readReg ssr_hidden_limits) 0)) ) : SailM (BitVec 32) )
          (pure (ldtr_base, ldtr_limit)))) ) : SailM ((BitVec 64) × (BitVec 32)) )
  let largest_address : Int := ((ash_left_int (BitVec.toNatInt sel_index) 3) +i 7)
  (if (((BitVec.toNatInt dt_limit) <b largest_address) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :GP-SELECTOR-LIMIT-CHECK-FAILED (LIST SELECTOR DT-BASE-ADDR DT-LIMIT))"))
  else (do (pure ())))
  let descriptor_addr : Int := ((BitVec.toNatInt dt_base_addr) +i (BitVec.toNatInt (bits_of_int (ash_left_int (BitVec.toNatInt sel_index) 3) 16)))
  (if ((! (← (canonical_address_p descriptor_addr))) : Bool)
  then (do (x86_model_error ":DESCRIPTOR-ADDR-VIRTUAL-MEMORY-ERROR"))
  else (do (pure ())))
  let descriptor ← (( do (pure (Sail.BitVec.truncate (← (rml_size 8 (bits_of_int descriptor_addr 48) ":X")) 64)) ) : SailM (BitVec 64) )
  let s : (BitVec 1) := (_get_code_segment_descriptorbits_s (Mk_code_segment_descriptorbits descriptor))
  (if ((s == 1#1) : Bool)
  then
    (do let msb_of_type : (BitVec 1) := (_get_code_segment_descriptorbits_msb_of_type (Mk_code_segment_descriptorbits descriptor))
        (if ((! (msb_of_type == 1#1)) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :JMP-FAR-DATA-SEGMENT SEL-INDEX)"))
        else (do (pure ())))
        let d : (BitVec 1) := (_get_code_segment_descriptorbits_d (Mk_code_segment_descriptorbits descriptor))
        (if (((in_64bit_mode proc_mode) && (d == 1#1)) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :CS.D=1-IN-64-BIT-MODE SEL-INDEX)"))
        else (do (pure ())))
        let cpl ← (( do (pure (_get_segment_selectorbits_rpl (Mk_segment_selectorbits (GetElem?.getElem! (← readReg seg_visibles) 1)))) ) : SailM (BitVec 2) )
        let dpl : (BitVec 2) := (_get_code_segment_descriptorbits_dpl (Mk_code_segment_descriptorbits descriptor))
        let c : (BitVec 1) := (_get_code_segment_descriptorbits_c (Mk_code_segment_descriptorbits descriptor))
        let allowed : Bool :=
          if ((c == 1#1) : Bool)
          then ((BitVec.toNatInt dpl) ≤b (BitVec.toNatInt cpl))
          else (((BitVec.toNatInt sel_rpl) ≤b (BitVec.toNatInt cpl)) && (cpl == dpl))
        (if ((! allowed) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :PRIVILEGE-CHECK-FAIL (ACONS :DPL DPL (ACONS :CPL CPL (ACONS :RPL SEL-RPL NIL))))"))
        else (do (pure ())))
        let p : (BitVec 1) := (_get_code_segment_descriptorbits_p (Mk_code_segment_descriptorbits descriptor))
        (if ((! (p == 1#1)) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :NP SEL-INDEX :CODE-SEGMENT-NOT-PRESENT SEL-INDEX)"))
        else (do (pure ())))
        let jmp_addr : (sbits 64) :=
          match offset_size with
          | 2 => (Sail.BitVec.zeroExtend (Sail.BitVec.truncate offset 16) 64)
          | 4 => (Sail.BitVec.zeroExtend (Sail.BitVec.truncate offset 32) 64)
          | _ => offset
        let jmp_addr_ok ← (( do
          (if ((in_64bit_mode proc_mode) : Bool)
          then (do (canonical_address_p (BitVec.toInt jmp_addr)))
          else
            (do let limit15_0 : (BitVec 16) := (_get_code_segment_descriptorbits_limit15_0 (Mk_code_segment_descriptorbits descriptor))
                let limit19_16 : (BitVec 4) := (_get_code_segment_descriptorbits_limit19_16 (Mk_code_segment_descriptorbits descriptor))
                let limit : Int := (changeSlice_int (ash_left_int (BitVec.toNatInt limit19_16) 16) 0 16 (BitVec.toNatInt limit15_0))
                let g : (BitVec 1) := (_get_code_segment_descriptorbits_g (Mk_code_segment_descriptorbits descriptor))
                let max_offset : Int :=
                  if ((g == 1#1) : Bool)
                  then ((ash_left_int limit 12) -i 1)
                  else limit
                (pure ((BitVec.toInt jmp_addr) <b (max_offset : Int))))) ) : SailM Bool )
        (if ((! jmp_addr_ok) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :GP 0 :NONCANONICAL-OR-OUTSIDE-SEGMENT-LIMIT JMP-ADDR)"))
        else (do (pure ())))
        let new_cs_visible : segment_selectorbits := (_update_segment_selectorbits_rpl (Mk_segment_selectorbits selector) cpl)
        writeReg seg_visibles (vectorUpdate (← readReg seg_visibles) 1 new_cs_visible)
        writeReg seg_hidden_bases (vectorUpdate (← readReg seg_hidden_bases) 1 dt_base_addr)
        writeReg seg_hidden_limits (vectorUpdate (← readReg seg_hidden_limits) 1 dt_limit)
        writeReg seg_hidden_attrs (vectorUpdate (← readReg seg_hidden_attrs) 1 (make_code_segment_attr_field descriptor))
        (write_iptr proc_mode (Sail.BitVec.truncate jmp_addr 48)))
  else
    (do (if ((! (in_64bit_mode proc_mode)) : Bool)
        then (do (x86_model_error ":FAR-JMP-SYSTEM-UNIMPLEMENTED-IN-32-BIT-MODE"))
        else (do (pure ())))
        let largest_address : Int := ((ash_left_int (BitVec.toNatInt sel_index) 3) +i 15)
        (if (((BitVec.toNatInt dt_limit) <b largest_address) : Bool)
        then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :GP-SELECTOR-LIMIT-CHECK-FAILED (LIST SELECTOR DT-BASE-ADDR DT-LIMIT))"))
        else (do (pure ())))
        let descriptor ← (( do (rml_size 16 (bits_of_int descriptor_addr 48) ":X") ) : SailM (BitVec 128) )
        let (call_gate_desc?, reason2) : (Bool × (String × (BitVec 128))) := (ia32e_valid_call_gate_segment_descriptor_p descriptor)
        (if (call_gate_desc? : Bool)
        then
          (do let cpl ← (( do (pure (_get_segment_selectorbits_rpl (Mk_segment_selectorbits (GetElem?.getElem! (← readReg seg_visibles) 1)))) ) : SailM (BitVec 2) )
              let dpl : (BitVec 2) := (_get_call_gate_descriptorbits_dpl (Mk_call_gate_descriptorbits descriptor))
              (if ((! (((BitVec.toNatInt cpl) ≤b (BitVec.toNatInt dpl)) && (((BitVec.toNatInt sel_rpl) ≤b (BitVec.toNatInt dpl)) : Bool))) : Bool)
              then (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :PRIVILEGE-CHECK-FAIL (ACONS :DPL DPL (ACONS :CPL CPL (ACONS :RPL SEL-RPL NIL))))"))
              else (do (pure ())))
              let cs_selector : (BitVec 16) := (_get_call_gate_descriptorbits_selector (Mk_call_gate_descriptorbits descriptor))
              let cs_sel_index : (BitVec 13) := (_get_segment_selectorbits_index (Mk_segment_selectorbits cs_selector))
              let cs_sel_ti : (BitVec 1) := (_get_segment_selectorbits_ti (Mk_segment_selectorbits cs_selector))
              let cs_sel_rpl : (BitVec 2) := (_get_segment_selectorbits_rpl (Mk_segment_selectorbits cs_selector))
              (if (((cs_sel_ti == 0#1) && (cs_sel_index == 0b0000000000000#13)) : Bool)
              then (do (x86_fault "(!!FAULT-FRESH :GP 0 :CALL-GATE-CODE-SEGMENT-NULLSELECTOR 0)"))
              else (do (pure ())))
              let (cs_dt_base_addr, cs_dt_limit) ← (( do
                (if ((sel_ti == 0#1) : Bool)
                then
                  (do let gdtr ← (( do (pure (GetElem?.getElem! (← readReg strs) 0)) ) : SailM (BitVec 80) )
                      let gdtr_base : (BitVec 64) := (_get_gdtr_idtrbits_base_addr (Mk_gdtr_idtrbits gdtr))
                      let gdtr_base : (BitVec 64) :=
                        if ((in_64bit_mode proc_mode) : Bool)
                        then gdtr_base
                        else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate gdtr_base 32) 64)
                      let gdtr_limit : (BitVec 16) := (_get_gdtr_idtrbits_limit (Mk_gdtr_idtrbits gdtr))
                      (pure (gdtr_base, (Sail.BitVec.zeroExtend gdtr_limit 32))))
                else
                  (do let ldtr_base ← (( do (pure (GetElem?.getElem! (← readReg ssr_hidden_bases) 0)) ) : SailM (BitVec 64) )
                      let ldtr_base : (BitVec 64) :=
                        if ((in_64bit_mode proc_mode) : Bool)
                        then ldtr_base
                        else (Sail.BitVec.zeroExtend (Sail.BitVec.truncate ldtr_base 32) 64)
                      let ldtr_limit ← (( do (pure (GetElem?.getElem! (← readReg ssr_hidden_limits) 0)) ) : SailM (BitVec 32) )
                      (pure (ldtr_base, ldtr_limit)))) ) : SailM ((BitVec 64) × (BitVec 32)) )
              let largest_address : Int := ((ash_left_int (BitVec.toNatInt cs_sel_index) 3) +i 7)
              (if (((BitVec.toNatInt cs_dt_limit) <b largest_address) : Bool)
              then (do (x86_fault "(!!FAULT-FRESH :GP CS-SEL-INDEX :GP-SELECTOR-LIMIT-CHECK-FAILED (LIST CS-SELECTOR CS-DT-BASE-ADDR CS-DT-LIMIT))"))
              else (do (pure ())))
              let cs_descriptor_addr : Int := ((BitVec.toNatInt cs_dt_base_addr) +i (BitVec.toNatInt (bits_of_int (ash_left_int (BitVec.toNatInt cs_sel_index) 3) 16)))
              (if ((! (← (canonical_address_p cs_descriptor_addr))) : Bool)
              then (do (x86_model_error ":CS-DESCRIPTOR-ADDR-VIRTUAL-MEMORY-ERROR"))
              else (do (pure ())))
              let cs_descriptor ← (( do (pure (Sail.BitVec.truncate (← (rml_size 8 (bits_of_int cs_descriptor_addr 48) ":X")) 64)) ) : SailM (BitVec 64) )
              let (valid?, reason) : (Bool × (String × (BitVec 64))) := (ia32e_valid_code_segment_descriptor_p cs_descriptor)
              (if ((! valid?) : Bool)
              then (do (x86_fault "(!!FAULT-FRESH :GP CS-SEL-INDEX :CALL-GATE-CODE-SEGMENT-DESCRIPTOR-INVALID (CONS REASON CS-DESCRIPTOR))"))
              else (do (pure ())))
              let cs_dpl : (BitVec 2) := (_get_code_segment_descriptorbits_dpl (Mk_code_segment_descriptorbits cs_descriptor))
              let c_bit : (BitVec 1) := (_get_code_segment_descriptorbits_c (Mk_code_segment_descriptorbits cs_descriptor))
              (if ((((c_bit == 1#1) && ((! ((BitVec.toNatInt cs_dpl) ≤b (BitVec.toNatInt cpl))) : Bool)) || ((c_bit == 0#1) && (! (cs_dpl == cpl)))) : Bool)
              then (do (x86_fault "(!!FAULT-FRESH :GP CS-SEL-INDEX :PRIVILEGE-CHECK-FAIL (ACONS :C-BIT C-BIT (ACONS :CPL CPL (ACONS :CS-DPL CS-DPL NIL))))"))
              else (do (pure ())))
              let call_gate_offset15_0 : (BitVec 16) := (_get_call_gate_descriptorbits_offset15_0 (Mk_call_gate_descriptorbits descriptor))
              let call_gate_offset31_16 : (BitVec 16) := (_get_call_gate_descriptorbits_offset31_16 (Mk_call_gate_descriptorbits descriptor))
              let call_gate_offset63_32 : (BitVec 32) := (_get_call_gate_descriptorbits_offset63_32 (Mk_call_gate_descriptorbits descriptor))
              let call_gate_offset31_0 : Int := (changeSlice_int (ash_left_int (BitVec.toNatInt call_gate_offset31_16) 16) 0 16 (BitVec.toNatInt call_gate_offset15_0))
              let call_gate_offset : Int := (changeSlice_int (ash_left_int (BitVec.toNatInt call_gate_offset63_32) 32) 0 32 call_gate_offset31_0)
              let jmp_addr : (sbits 64) :=
                match offset_size with
                | 2 => (Sail.BitVec.zeroExtend (bits_of_int call_gate_offset 16) 64)
                | 4 => (Sail.BitVec.zeroExtend (bits_of_int call_gate_offset 32) 64)
                | _ => (bits_of_int call_gate_offset 64)
              (if ((! (← (canonical_address_p (BitVec.toInt jmp_addr)))) : Bool)
              then (do (x86_model_error ":TARGET-OFFSET-VIRTUAL-MEMORY-ERROR"))
              else (do (pure ())))
              let new_cs_visible : segment_selectorbits := (_update_segment_selectorbits_rpl (Mk_segment_selectorbits cs_selector) cpl)
              writeReg seg_visibles (vectorUpdate (← readReg seg_visibles) 1 new_cs_visible)
              writeReg seg_hidden_bases (vectorUpdate (← readReg seg_hidden_bases) 1 cs_dt_base_addr)
              writeReg seg_hidden_limits (vectorUpdate (← readReg seg_hidden_limits) 1 cs_dt_limit)
              writeReg seg_hidden_attrs (vectorUpdate (← readReg seg_hidden_attrs) 1 (make_code_segment_attr_field cs_descriptor))
              (write_iptr proc_mode (Sail.BitVec.truncate jmp_addr 48)))
        else (do (x86_fault "(!!FAULT-FRESH :GP SEL-INDEX :EITHER-BOTH-CODE-SEGMENT-OR-CALL-GATE-ARE-ABSENT-OR-SOME-OTHER-DESCRIPTOR-IS-PRESENT (CONS REASON2 DESCRIPTOR))")))))

def x86_mov_op_en_mr (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOV-OP/EN-MR"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := (opcode == 0x88#8)
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let register_var ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let inst_ac? : Bool := true
  (x86_operand_to_reg_mem proc_mode operand_size inst_ac? false (Sail.BitVec.zeroExtend register_var 128) seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def x86_mov_op_en_rm (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOV-OP/EN-RM"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := (opcode == 0x8A#8)
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate reg_mem 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_mov_op_en_oi (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOV-OP/EN-OI"
  let byte_operand? : Bool := ((176 ≤b (BitVec.toNatInt opcode)) && (((BitVec.toNatInt opcode) ≤b 183) : Bool))
  let operand_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte false prefixes false false false) ) : SailM Int )
  let imm ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (BitVec 128) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int operand_size 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let reg : (BitVec 3) := (Sail.BitVec.truncate (0x07#8 &&& opcode) 3)
  (write_rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b00#2) (Sail.BitVec.truncate imm 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_mov_op_en_mi (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOV-OP/EN-MI"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let byte_operand? : Bool := (opcode == 0xC6#8)
  let imm_size ← (( do (select_operand_size proc_mode byte_operand? rex_byte true prefixes false false false) ) : SailM Int )
  let reg_mem_size : Int :=
    if (((opcode == 0xC7#8) && (logbitp_bits 3 rex_byte)) : Bool)
    then 8
    else imm_size
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib (bits_of_int imm_size 3)))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let imm ← (( do (rme_size proc_mode (← (select_address_size proc_mode (some prefixes))) imm_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false) ) : SailM (BitVec 128) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int imm_size 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let imm : (BitVec 128) :=
    if ((reg_mem_size == 8) : Bool)
    then (Sail.BitVec.zeroExtend (Sail.BitVec.signExtend (Sail.BitVec.truncate imm 32) 64) 128)
    else imm
  let inst_ac? : Bool := true
  (x86_operand_to_reg_mem proc_mode reg_mem_size inst_ac? false imm seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def x86_lea (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-LEA"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let register_size ← (( do (check_range 2 8 (← (select_operand_size proc_mode false rex_byte false prefixes false false false))) ) : SailM Int )
  let (m, increment_rip_by) ← (( do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let m : (BitVec 64) := (sail_mask 64 (trunc_signed register_size m))
  (write_rgfi_size (bits_of_int register_size 4) (reg_index reg rex_byte 0b10#2) m rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_movsx (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVSX"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let reg_mem_size ← (( do (select_operand_size proc_mode false rex_byte true prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let register_size : Int :=
    if ((logbitp_bits 3 rex_byte) : Bool)
    then 8
    else reg_mem_size
  let reg_mem : (BitVec 128) :=
    if ((register_size == 8) : Bool)
    then (Sail.BitVec.zeroExtend (Sail.BitVec.signExtend (Sail.BitVec.truncate reg_mem 32) 64) 128)
    else reg_mem
  (write_rgfi_size (bits_of_int register_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate reg_mem 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_movsxd (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVSXD"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let reg_mem_size : Int :=
    if ((opcode == 0xBE#8) : Bool)
    then 1
    else 2
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let register_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let reg_mem ← (( do
    match reg_mem_size with
    | 1 => (pure (Sail.BitVec.zeroExtend (sail_mask 64 (← (signed_bitslice (Sail.BitVec.truncate reg_mem 8) 0 (ash_left_int register_size 3)))) 128))
    | _ =>
      (do
        match register_size with
        | 2 => (pure reg_mem)
        | _ => (pure (Sail.BitVec.zeroExtend (sail_mask 64 (← (signed_bitslice (Sail.BitVec.truncate reg_mem 16) 0 (ash_left_int register_size 3)))) 128))) ) : SailM (BitVec 128) )
  (write_rgfi_size (bits_of_int register_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate reg_mem 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_movzx (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVZX"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let reg_mem_size : Int :=
    if ((opcode == 0xB6#8) : Bool)
    then 1
    else 2
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let register_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  (write_rgfi_size (bits_of_int register_size 4) (reg_index reg rex_byte 0b10#2) (Sail.BitVec.truncate reg_mem 64) rex_byte)
  (write_iptr proc_mode temp_rip)

def x86_movd_movq_to_xmm (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVD/MOVQ-TO-XMM"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size : Int :=
    if ((logbitp_bits 3 rex_byte) : Bool)
    then 8
    else 4
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 operand_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (write_xmmi_size (bits_of_int operand_size 5) (reg_index reg rex_byte 0b10#2) (BitVec.toNatInt reg_mem))
  (write_iptr proc_mode temp_rip)

def x86_movd_movq_from_xmm (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MOVD/MOVQ-FROM-XMM"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let operand_size : Int :=
    if ((logbitp_bits 3 rex_byte) : Bool)
    then 8
    else 4
  let register_var ← (( do (xmmi_size (bits_of_int operand_size 5) (reg_index reg rex_byte 0b10#2)) ) : SailM (BitVec 128) )
  let (addr, increment_rip_by) ← (( do
    (if ((mod_var == 0b11#2) : Bool)
    then (do (pure (0x0000000000000000#64, 0)))
    else (do (x86_effective_addr proc_mode prefixes temp_rip rex_byte r_m mod_var sib 0b000#3))) ) : SailM ((sbits 64) × Int) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let inst_ac? : Bool := true
  (x86_operand_to_reg_mem proc_mode operand_size inst_ac? false register_var seg_reg addr prefixes rex_byte r_m mod_var sib)
  (write_iptr proc_mode temp_rip)

def mul_spec_8 (dst : (BitVec 8)) (src : (BitVec 8)) : ((BitVec 8) × (BitVec 8) × (BitVec 16)) :=
  let product : (BitVec 16) := (bits_of_int ((BitVec.toNatInt dst) *i (BitVec.toNatInt src)) 16)
  let product_high : (BitVec 8) := (Sail.BitVec.extractLsb product 15 8)
  let product_low : (BitVec 8) := (Sail.BitVec.extractLsb product 7 0)
  (product_high, product_low, product)

def mul_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) : ((BitVec 16) × (BitVec 16) × (BitVec 32)) :=
  let product : (BitVec 32) := (bits_of_int ((BitVec.toNatInt dst) *i (BitVec.toNatInt src)) 32)
  let product_high : (BitVec 16) := (Sail.BitVec.extractLsb product 31 16)
  let product_low : (BitVec 16) := (Sail.BitVec.extractLsb product 15 0)
  (product_high, product_low, product)

def mul_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) : ((BitVec 32) × (BitVec 32) × (BitVec 64)) :=
  let product : (BitVec 64) := (bits_of_int ((BitVec.toNatInt dst) *i (BitVec.toNatInt src)) 64)
  let product_high : (BitVec 32) := (Sail.BitVec.extractLsb product 63 32)
  let product_low : (BitVec 32) := (Sail.BitVec.extractLsb product 31 0)
  (product_high, product_low, product)

def mul_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) : ((BitVec 64) × (BitVec 64) × (BitVec 128)) :=
  let product : (BitVec 128) := (bits_of_int ((BitVec.toNatInt dst) *i (BitVec.toNatInt src)) 128)
  let product_high : (BitVec 64) := (Sail.BitVec.extractLsb product 127 64)
  let product_low : (BitVec 64) := (Sail.BitVec.extractLsb product 63 0)
  (product_high, product_low, product)

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def mul_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) : ((BitVec 64) × (BitVec 64) × (BitVec 128)) :=
  (match size with
  | 1 =>
    (let (elem0, elem1, elem2) : ((BitVec 8) × (BitVec 8) × (BitVec 16)) := (mul_spec_8 (Sail.BitVec.truncate dst 8) (Sail.BitVec.truncate src 8))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128)))
  | 2 =>
    (let (elem0, elem1, elem2) : ((BitVec 16) × (BitVec 16) × (BitVec 32)) := (mul_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128)))
  | 4 =>
    (let (elem0, elem1, elem2) : ((BitVec 32) × (BitVec 32) × (BitVec 64)) := (mul_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128)))
  | 8 => (mul_spec_64 dst src)
  | _ => (0x0000000000000000#64, 0x0000000000000000#64, 0x00000000000000000000000000000000#128) : ((BitVec 64) × (BitVec 64) × (BitVec 128)))

def imul_spec_8 (dst : (BitVec 8)) (src : (BitVec 8)) : ((BitVec 8) × (BitVec 8) × (BitVec 16) × (BitVec 1)) :=
  let dst_int : (sbits 8) := dst
  let src_int : (sbits 8) := src
  let product_int : (sbits 16) := (bits_of_int ((BitVec.toInt dst_int) *i (BitVec.toInt src_int)) 16)
  let product : (BitVec 16) := product_int
  let product_high : (BitVec 8) := (Sail.BitVec.extractLsb product 15 8)
  let product_low : (BitVec 8) := (Sail.BitVec.extractLsb product 7 0)
  let product_low_int : (sbits 8) := product_low
  let cf_and_of : (BitVec 1) := (bool_to_bits (! ((Sail.BitVec.signExtend product_low_int 16) == product_int)))
  (product_high, product_low, product, cf_and_of)

def imul_spec_16 (dst : (BitVec 16)) (src : (BitVec 16)) : ((BitVec 16) × (BitVec 16) × (BitVec 32) × (BitVec 1)) :=
  let dst_int : (sbits 16) := dst
  let src_int : (sbits 16) := src
  let product_int : (sbits 32) := (bits_of_int ((BitVec.toInt dst_int) *i (BitVec.toInt src_int)) 32)
  let product : (BitVec 32) := product_int
  let product_high : (BitVec 16) := (Sail.BitVec.extractLsb product 31 16)
  let product_low : (BitVec 16) := (Sail.BitVec.extractLsb product 15 0)
  let product_low_int : (sbits 16) := product_low
  let cf_and_of : (BitVec 1) := (bool_to_bits (! ((Sail.BitVec.signExtend product_low_int 32) == product_int)))
  (product_high, product_low, product, cf_and_of)

def imul_spec_32 (dst : (BitVec 32)) (src : (BitVec 32)) : ((BitVec 32) × (BitVec 32) × (BitVec 64) × (BitVec 1)) :=
  let dst_int : (sbits 32) := dst
  let src_int : (sbits 32) := src
  let product_int : (sbits 64) := (bits_of_int ((BitVec.toInt dst_int) *i (BitVec.toInt src_int)) 64)
  let product : (BitVec 64) := product_int
  let product_high : (BitVec 32) := (Sail.BitVec.extractLsb product 63 32)
  let product_low : (BitVec 32) := (Sail.BitVec.extractLsb product 31 0)
  let product_low_int : (sbits 32) := product_low
  let cf_and_of : (BitVec 1) := (bool_to_bits (! ((Sail.BitVec.signExtend product_low_int 64) == product_int)))
  (product_high, product_low, product, cf_and_of)

def imul_spec_64 (dst : (BitVec 64)) (src : (BitVec 64)) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)) :=
  let dst_int : (sbits 64) := dst
  let src_int : (sbits 64) := src
  let product_int : (sbits 128) := (bits_of_int ((BitVec.toInt dst_int) *i (BitVec.toInt src_int)) 128)
  let product : (BitVec 128) := product_int
  let product_high : (BitVec 64) := (Sail.BitVec.extractLsb product 127 64)
  let product_low : (BitVec 64) := (Sail.BitVec.extractLsb product 63 0)
  let product_low_int : (sbits 64) := product_low
  let cf_and_of : (BitVec 1) := (bool_to_bits (! ((Sail.BitVec.signExtend product_low_int 128) == product_int)))
  (product_high, product_low, product, cf_and_of)

/-- Type quantifiers: size : Nat, List.elem size [1, 2, 4, 8] -/
def imul_spec (size : Nat) (dst : (BitVec 64)) (src : (BitVec 64)) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)) :=
  (match size with
  | 1 =>
    (let (elem0, elem1, elem2, elem3) : ((BitVec 8) × (BitVec 8) × (BitVec 16) × (BitVec 1)) := (imul_spec_8 (Sail.BitVec.truncate dst 8) (Sail.BitVec.truncate src 8))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128), elem3))
  | 2 =>
    (let (elem0, elem1, elem2, elem3) : ((BitVec 16) × (BitVec 16) × (BitVec 32) × (BitVec 1)) := (imul_spec_16 (Sail.BitVec.truncate dst 16) (Sail.BitVec.truncate src 16))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128), elem3))
  | 4 =>
    (let (elem0, elem1, elem2, elem3) : ((BitVec 32) × (BitVec 32) × (BitVec 64) × (BitVec 1)) := (imul_spec_32 (Sail.BitVec.truncate dst 32) (Sail.BitVec.truncate src 32))
    ((Sail.BitVec.zeroExtend elem0 64), (Sail.BitVec.zeroExtend elem1 64), (Sail.BitVec.zeroExtend elem2 128), elem3))
  | 8 => (imul_spec_64 dst src)
  | _ => (0x0000000000000000#64, 0x0000000000000000#64, 0x00000000000000000000000000000000#128, 0#1) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)))

def x86_mul (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-MUL"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0xF6#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let rax_var ← (( do (rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let (product_high, product_low, product) : ((BitVec 64) × (BitVec 64) × (BitVec 128)) := (mul_spec reg_mem_size rax_var (Sail.BitVec.truncate reg_mem 64))
  match reg_mem_size with
  | 1 => (write_rgfi_size 0x2#4 0x0#4 (Sail.BitVec.truncate product 64) rex_byte)
  | _ =>
    (do
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 product_low rex_byte)
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 product_high rex_byte))
  (if ((product_high == 0x0000000000000000#64) : Bool)
  then
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var 0#1)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var 0#1)
        writeReg rflags new_rflags)
  else
    (do let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var 1#1)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
        let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
        writeReg rflags new_rflags
        let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
        let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var 1#1)
        writeReg rflags new_rflags))
  (write_iptr proc_mode temp_rip)

def x86_imul_op_en_m (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-IMUL-OP/EN-M"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let select_byte_operand : Bool := (opcode == 0xF6#8)
  let reg_mem_size ← (( do (select_operand_size proc_mode select_byte_operand rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let rax_var ← (( do (rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 rex_byte) ) : SailM (BitVec 64) )
  let (product_high, product_low, product, cf_and_of) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)) := (imul_spec reg_mem_size rax_var (Sail.BitVec.truncate reg_mem 64))
  match reg_mem_size with
  | 1 => (write_rgfi_size 0x2#4 0x0#4 (Sail.BitVec.truncate product 64) rex_byte)
  | _ =>
    (do
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x0#4 product_low rex_byte)
      (write_rgfi_size (bits_of_int reg_mem_size 4) 0x2#4 product_high rex_byte))
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var cf_and_of)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var cf_and_of)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def x86_imul_op_en_rm (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-IMUL-OP/EN-RM"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let reg_mem_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib 0b000#3) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let register_var ← (( do (rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) rex_byte) ) : SailM (BitVec 64) )
  let (product_high, product_low, product, cf_and_of) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)) := (imul_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) register_var)
  (write_rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) product_low rex_byte)
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var cf_and_of)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var cf_and_of)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def x86_imul_op_en_rmi (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-IMUL-OP/EN-RMI"
  let r_m : (BitVec 3) := (_get_modr_m_r_m modr_m)
  let mod_var : (BitVec 2) := (_get_modr_m_mod modr_m)
  let reg : (BitVec 3) := (_get_modr_m_reg modr_m)
  let p2 : (BitVec 8) := (_get_prefixes_seg prefixes)
  let p4? : Bool := (0x67#8 == (_get_prefixes_adr prefixes))
  let reg_mem_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes false false false) ) : SailM Int )
  let imm_size : Int :=
    if ((opcode == 0x6B#8) : Bool)
    then 1
    else
      (if ((reg_mem_size == 2) : Bool)
      then 2
      else 4)
  let seg_reg ← (( do (select_segment_register proc_mode prefixes mod_var r_m sib) ) : SailM seg_reg_idx )
  let inst_ac? : Bool := true
  let (reg_mem, increment_rip_by, addr) ← (( do (x86_operand_from_modr_m_and_sib_bytes proc_mode 0#1 reg_mem_size inst_ac? false seg_reg prefixes temp_rip rex_byte r_m mod_var sib (bits_of_int imm_size 3)) ) : SailM ((BitVec 128) × Int × (sbits 64)) )
  let increment_rip_by : (BitVec 3) := (bits_of_int increment_rip_by 3)
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (Sail.BitVec.zeroExtend increment_rip_by 48)) ) : SailM (sbits 48) )
  let imm ← (( do (pure (Sail.BitVec.truncate (← (rime_size proc_mode (← (select_address_size proc_mode (some prefixes))) imm_size (Sail.BitVec.signExtend temp_rip 64) none 1 ":X" false false)) 32)) ) : SailM (BitVec 32) )
  let temp_rip ← (( do (add_to_iptr proc_mode temp_rip (bits_of_int imm_size 48)) ) : SailM (sbits 48) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  let (product_high, product_low, product, cf_and_of) : ((BitVec 64) × (BitVec 64) × (BitVec 128) × (BitVec 1)) := (imul_spec reg_mem_size (Sail.BitVec.truncate reg_mem 64) (Sail.BitVec.signExtend imm 64))
  (write_rgfi_size (bits_of_int reg_mem_size 4) (reg_index reg rex_byte 0b10#2) product_low rex_byte)
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_cf rflags_var cf_and_of)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_pf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_af rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_zf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let sailval ← (( do (undef_flg ()) ) : SailM (BitVec 1) )
  let new_rflags : rflagsbits := (_update_rflagsbits_sf rflags_var sailval)
  writeReg rflags new_rflags
  let rflags_var ← (( do readReg rflags ) : SailM rflagsbits )
  let new_rflags : rflagsbits := (_update_rflagsbits_of rflags_var cf_and_of)
  writeReg rflags new_rflags
  (write_iptr proc_mode temp_rip)

def x86_push_general_register (proc_mode : proc_mode) (start_rip : (BitVec 48)) (temp_rip : (BitVec 48)) (prefixes : (BitVec 52)) (rex_byte : (BitVec 8)) (opcode : (BitVec 8)) (modr_m : (BitVec 8)) (sib : (BitVec 8)) : SailM Unit := do
  let ctx : String := "X86-PUSH-GENERAL-REGISTER"
  let operand_size ← (( do (select_operand_size proc_mode false rex_byte false prefixes true false false) ) : SailM Int )
  let rsp_var ← (( do (read_sptr proc_mode) ) : SailM (sbits 64) )
  let new_rsp ← (( do (add_to_sptr proc_mode rsp_var (bits_of_int (Neg.neg operand_size) 64)) ) : SailM (sbits 64) )
  let reg : (BitVec 3) := (loghead_bits 3 opcode)
  let sailval ← (( do (rgfi_size (bits_of_int operand_size 4) (reg_index reg rex_byte 0b00#2) rex_byte) ) : SailM (BitVec 64) )
  let badlength? : (Option Int) := (check_instruction_length start_rip temp_rip 0b000#3)
  (if ((is_some badlength?) : Bool)
  then (do (x86_fault "(!!FAULT-FRESH :GP 0 :INSTRUCTION-LENGTH BADLENGTH?)"))
  else (do (pure ())))
  (wme_size proc_mode (← (select_address_size proc_mode (some prefixes))) operand_size (Sail.BitVec.signExtend (Sail.BitVec.truncate new_rsp 48) 64) none 2 (Sail.BitVec.zeroExtend sailval 128) (← (alignment_checking_enabled_p ())) false)
  (write_sptr proc_mode new_rsp)
  (write_iptr proc_mode temp_rip)


end X86Sail.Functions
