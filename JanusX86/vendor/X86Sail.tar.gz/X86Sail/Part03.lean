import X86Sail.Part02

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace X86Sail

open ConcurrencyInterfaceV1

namespace Functions

open write_kind
open trans_kind
open regfp
open read_kind
open proc_mode
open option
open niafp
open instruction_kind
open exception
open diafp
open cache_op_kind
open barrier_kind
open a64_barrier_type
open a64_barrier_domain
open Register
open JanusOutcome

def _get_ia32e_page_tablesbits_r_w (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def page_read_write (entry : (BitVec 64)) : (BitVec 1) :=
  (_get_ia32e_page_tablesbits_r_w (Mk_ia32e_page_tablesbits entry))

def _get_ia32e_page_tablesbits_ps (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def page_size (entry : (BitVec 64)) : (BitVec 1) :=
  (_get_ia32e_page_tablesbits_ps (Mk_ia32e_page_tablesbits entry))

def _get_ia32e_page_tablesbits_u_s (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def page_user_supervisor (entry : (BitVec 64)) : (BitVec 1) :=
  (_get_ia32e_page_tablesbits_u_s (Mk_ia32e_page_tablesbits entry))

def paging_entry_no_page_fault_p (structure_type : (BitVec 2)) (lin_addr : (BitVec 48)) (entry : (BitVec 64)) (u_s_acc : (BitVec 1)) (r_w_acc : (BitVec 1)) (x_d_acc : (BitVec 1)) (wp : (BitVec 1)) (smep : (BitVec 1)) (smap : (BitVec 1)) (ac : (BitVec 1)) (nxe : (BitVec 1)) (r_w_x : String) (cpl : (BitVec 2)) (keywords : struct_paging_entry_no_page_fault_p) : SailM (Bool × Int) := do
  let entry : (BitVec 64) := (loghead_bits 64 entry)
  let page_present_var : (BitVec 1) := (page_present entry)
  (if ((page_present_var == 0#1) : Bool)
  then
    (do let err_no : Int := (page_fault_err_no page_present_var r_w_x cpl 0#1 smep 1#1 nxe)
        (page_fault_exception lin_addr err_no))
  else
    (do let read_write : (BitVec 1) := (page_read_write entry)
        let r_w_all : (BitVec 1) := (read_write &&& r_w_acc)
        let user_supervisor : (BitVec 1) := (page_user_supervisor entry)
        let u_s_all : (BitVec 1) := (user_supervisor &&& u_s_acc)
        let execute_disable : (BitVec 1) := (page_execute_disable entry)
        let x_d_all : (BitVec 1) := (execute_disable &&& x_d_acc)
        let page_size_var : (BitVec 1) := (page_size entry)
        let rsvd : Int :=
          if ((((structure_type == 0b11#2) && (page_size_var == 1#1)) || (((! (structure_type == 0b00#2)) && ((! (structure_type == 0b11#2)) && ((page_size_var == 1#1) && (if ((structure_type == 0b01#2) : Bool)
                       then (! ((Sail.BitVec.extractLsb entry 20 13) == 0x00#8))
                       else (! ((Sail.BitVec.extractLsb entry 29 13) == 0b00000000000000000#17)))))) || ((nxe == 0#1) && (! (execute_disable == 0#1))))) : Bool)
          then 1
          else 0
        (if ((rsvd == 1) : Bool)
        then
          (do let err_no : Int := (page_fault_err_no page_present_var r_w_x cpl (bits_of_int rsvd 1) smep 1#1 nxe)
              (page_fault_exception lin_addr err_no))
        else
          (do (if ((((r_w_x == ":R") && (if (((BitVec.toNatInt cpl) <b 3) : Bool)
                     then
                       (if ((u_s_all == 0#1) : Bool)
                       then false
                       else
                         (if ((smap == 0#1) : Bool)
                         then false
                         else ((keywords.supervisor_mode_access_type == 1) || (ac == 0#1))))
                     else (u_s_all == 0#1))) || (((r_w_x == ":W") && (if (((BitVec.toNatInt cpl) <b 3) : Bool)
                       then
                         (if ((u_s_all == 0#1) : Bool)
                         then ((wp == 1#1) && (r_w_all == 0#1))
                         else
                           (if ((wp == 0#1) : Bool)
                           then
                             (if ((smap == 0#1) : Bool)
                             then false
                             else ((keywords.supervisor_mode_access_type == 1) || (ac == 0#1)))
                           else
                             (if ((smap == 0#1) : Bool)
                             then (r_w_all == 0#1)
                             else
                               (if (((keywords.supervisor_mode_access_type == 0) && (ac == 1#1)) : Bool)
                               then (r_w_all == 0#1)
                               else true))))
                       else ((u_s_all == 0#1) || (r_w_all == 0#1)))) || ((r_w_x == ":X") && (if (((BitVec.toNatInt cpl) <b 3) : Bool)
                       then
                         (if ((u_s_all == 0#1) : Bool)
                         then
                           (if ((nxe == 0#1) : Bool)
                           then false
                           else (x_d_all == 1#1))
                         else
                           (if ((smep == 0#1) : Bool)
                           then
                             (if ((nxe == 0#1) : Bool)
                             then false
                             else (x_d_all == 1#1))
                           else true))
                       else ((u_s_all == 0#1) || ((nxe == 1#1) && (x_d_all == 1#1))))))) : Bool)
              then
                (do let err_no : Int := (page_fault_err_no page_present_var r_w_x cpl (bits_of_int rsvd 1) smep 1#1 nxe)
                    (page_fault_exception lin_addr err_no))
              else (do (pure (false, 0))))))))

/-- Type quantifiers: addr : Int -/
def rm_low_32 (addr : Int) : SailM (BitVec 32) := do
  sail_assert (! (← readReg app_view)) "./././physical_memory.sail:12.29-12.30"
  let byte0 ← (( do (pure (loghead_bits 8 (← (memi (bits_of_int addr 64))))) ) : SailM (BitVec 8) )
  let byte1 ← (( do (pure (loghead_bits 8 (← (memi (bits_of_int (1 +i addr) 64))))) ) : SailM (BitVec 8) )
  let word0 : (BitVec 16) := ((bits_of_int (ash_left_int (BitVec.toNatInt byte1) 8) 16) ||| (Sail.BitVec.zeroExtend byte0 16))
  let byte2 ← (( do (pure (loghead_bits 8 (← (memi (bits_of_int (2 +i addr) 64))))) ) : SailM (BitVec 8) )
  let byte3 ← (( do (pure (loghead_bits 8 (← (memi (bits_of_int (3 +i addr) 64))))) ) : SailM (BitVec 8) )
  let word1 : (BitVec 16) := ((bits_of_int (ash_left_int (BitVec.toNatInt byte3) 8) 16) ||| (Sail.BitVec.zeroExtend byte2 16))
  (pure ((bits_of_int (ash_left_int (BitVec.toNatInt word1) 16) 32) ||| (Sail.BitVec.zeroExtend word0 32)))

/-- Type quantifiers: addr : Int -/
def rm_low_64 (addr : Int) : SailM (BitVec 64) := do
  sail_assert (! (← readReg app_view)) "./././physical_memory.sail:41.29-41.30"
  let dword0 ← (( do (rm_low_32 addr) ) : SailM (BitVec 32) )
  let dword1 ← (( do (rm_low_32 (4 +i addr)) ) : SailM (BitVec 32) )
  (pure ((bits_of_int (ash_left_int (BitVec.toNatInt dword1) 32) 64) ||| (Sail.BitVec.zeroExtend dword0 64)))

def _update_ia32e_page_tablesbits_a (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def set_accessed_bit (entry : (BitVec 64)) : (BitVec 64) :=
  (_update_ia32e_page_tablesbits_a (Mk_ia32e_page_tablesbits entry) 1#1)

def _update_ia32e_page_tablesbits_d (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def set_dirty_bit (entry : (BitVec 64)) : (BitVec 64) :=
  (_update_ia32e_page_tablesbits_d (Mk_ia32e_page_tablesbits entry) 1#1)

def wm_low_32 (addr : (BitVec 52)) (sailval : (BitVec 32)) : SailM Unit := do
  sail_assert (! (← readReg app_view)) "./././physical_memory.sail:26.29-26.30"
  let addr : Int := (BitVec.toNatInt addr)
  let byte0 : (BitVec 8) := (Sail.BitVec.extractLsb sailval 7 0)
  let byte1 : (BitVec 8) := (Sail.BitVec.extractLsb sailval 15 8)
  let byte2 : (BitVec 8) := (Sail.BitVec.extractLsb sailval 23 16)
  let byte3 : (BitVec 8) := (Sail.BitVec.extractLsb sailval 31 24)
  (bang_memi (bits_of_int addr 64) byte0)
  (bang_memi (bits_of_int (1 +i addr) 64) byte1)
  (bang_memi (bits_of_int (2 +i addr) 64) byte2)
  (bang_memi (bits_of_int (3 +i addr) 64) byte3)

def wm_low_64 (addr : (BitVec 52)) (sailval : (BitVec 64)) : SailM Unit := do
  sail_assert (! (← readReg app_view)) "./././physical_memory.sail:51.29-51.30"
  let addr : Int := (BitVec.toNatInt addr)
  let dword0 : (BitVec 32) := (Sail.BitVec.extractLsb sailval 31 0)
  let dword1 : (BitVec 32) := (Sail.BitVec.extractLsb sailval 63 32)
  (wm_low_32 (bits_of_int addr 52) dword0)
  (wm_low_32 (bits_of_int (4 +i addr) 52) dword1)

def ia32e_la_to_pa_page_table (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) (u_s_acc : (BitVec 1)) (r_w_acc : (BitVec 1)) (x_d_acc : (BitVec 1)) (wp : (BitVec 1)) (smep : (BitVec 1)) (smap : (BitVec 1)) (ac : (BitVec 1)) (nxe : (BitVec 1)) (r_w_x : String) (cpl : (BitVec 2)) : SailM Int := do
  sail_assert (! (← readReg app_view)) "././paging.sail:217.29-217.30"
  let lin_addr ← (( do (binary_logext 48 (BitVec.toNatInt (loghead_bits 48 lin_addr))) ) : SailM Int )
  let base_addr : (BitVec 52) := (changeSlice_bits (loghead_bits 52 base_addr) 0 12 0x000#12)
  let p_entry_addr ← (( do (page_table_entry_addr (bits_of_int lin_addr 48) base_addr) ) : SailM (BitVec 52) )
  let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
  let (fault_flg, sailval) ← (( do (paging_entry_no_page_fault_p 0b00#2 (bits_of_int lin_addr 48) entry u_s_acc r_w_acc x_d_acc wp smep smap ac nxe r_w_x cpl { supervisor_mode_access_type := 0 }) ) : SailM (Bool × Int) )
  (if (fault_flg : Bool)
  then (do (x86_model_error "Page-Fault"))
  else (do (pure ())))
  (if ((← readReg marking_view) : Bool)
  then
    (do let accessed : (BitVec 1) := (accessed_bit entry)
        let dirty : (BitVec 1) := (dirty_bit entry)
        let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
          if ((accessed == 0#1) : Bool)
          then (true, (set_accessed_bit entry))
          else (false, (Mk_ia32e_page_tablesbits entry))
        let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
          if (((dirty == 0#1) && (r_w_x == ":W")) : Bool)
          then (true, (set_dirty_bit entry))
          else (updated?, entry)
        (if (updated? : Bool)
        then (do (wm_low_64 p_entry_addr entry))
        else (do (pure ()))))
  else (do (pure ())))
  (pure (changeSlice_int (ash_left_int (BitVec.toNatInt (_get_ia32e_pte_4k_pagebits_page (Mk_ia32e_pte_4k_pagebits entry))) 12) 0 12 (BitVec.toNatInt (get_slice_int 12 lin_addr 0))))

def page_directory_entry_addr (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) : SailM (BitVec 52) := do
  sail_assert ((← (unsigned_byte_p_int 52 (BitVec.toNatInt base_addr))) && ((loghead_bits 12 base_addr) == 0x000#12)) "././paging.sail:83.85-83.86"
  (pure (changeSlice_bits base_addr 3 9 (Sail.BitVec.extractLsb lin_addr 29 21)))

def ia32e_la_to_pa_page_directory (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) (u_s_acc : (BitVec 1)) (r_w_acc : (BitVec 1)) (x_d_acc : (BitVec 1)) (wp : (BitVec 1)) (smep : (BitVec 1)) (smap : (BitVec 1)) (ac : (BitVec 1)) (nxe : (BitVec 1)) (r_w_x : String) (cpl : (BitVec 2)) : SailM Int := do
  sail_assert (! (← readReg app_view)) "././paging.sail:252.29-252.30"
  let lin_addr ← (( do (binary_logext 48 (BitVec.toNatInt (loghead_bits 48 lin_addr))) ) : SailM Int )
  let base_addr : (BitVec 52) := (changeSlice_bits (loghead_bits 52 base_addr) 0 12 0x000#12)
  let p_entry_addr ← (( do (page_directory_entry_addr (bits_of_int lin_addr 48) base_addr) ) : SailM (BitVec 52) )
  let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
  let u_s_all : (BitVec 1) := (u_s_acc &&& (page_user_supervisor entry))
  let r_w_all : (BitVec 1) := (r_w_acc &&& (page_read_write entry))
  let x_d_all : (BitVec 1) := (x_d_acc &&& (page_execute_disable entry))
  let (fault_flg, sailval) ← (( do (paging_entry_no_page_fault_p 0b01#2 (bits_of_int lin_addr 48) entry u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl { supervisor_mode_access_type := 0 }) ) : SailM (Bool × Int) )
  (if (fault_flg : Bool)
  then (do (x86_model_error "Page-Fault"))
  else (do (pure ())))
  (if (((page_size entry) == 1#1) : Bool)
  then
    (do (if ((← readReg marking_view) : Bool)
        then
          (do let accessed : (BitVec 1) := (accessed_bit entry)
              let dirty : (BitVec 1) := (dirty_bit entry)
              let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
                if ((accessed == 0#1) : Bool)
                then (true, (set_accessed_bit entry))
                else (false, (Mk_ia32e_page_tablesbits entry))
              let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
                if (((dirty == 0#1) && (r_w_x == ":W")) : Bool)
                then (true, (set_dirty_bit entry))
                else (updated?, entry)
              (if (updated? : Bool)
              then (do (wm_low_64 p_entry_addr entry))
              else (do (pure ()))))
        else (do (pure ())))
        (pure (changeSlice_int (ash_left_int (BitVec.toNatInt (_get_ia32e_pde_2mb_pagebits_page (Mk_ia32e_pde_2mb_pagebits entry))) 21) 0 21 (BitVec.toNatInt (get_slice_int 21 lin_addr 0)))))
  else
    (do let page_table_base_addr : Int := (ash_left_int (BitVec.toNatInt (_get_ia32e_pde_pg_tablebits_pt (Mk_ia32e_pde_pg_tablebits entry))) 12)
        let p_addr ← (( do (pure (bits_of_int (← (ia32e_la_to_pa_page_table (bits_of_int lin_addr 48) (bits_of_int page_table_base_addr 52) u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl)) 52)) ) : SailM (BitVec 52) )
        (if ((← readReg marking_view) : Bool)
        then
          (do let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
              let accessed : (BitVec 1) := (accessed_bit entry)
              let entry : ia32e_page_tablesbits :=
                if ((accessed == 0#1) : Bool)
                then (set_accessed_bit entry)
                else (Mk_ia32e_page_tablesbits entry)
              (if ((accessed == 0#1) : Bool)
              then (do (wm_low_64 p_entry_addr entry))
              else (do (pure ()))))
        else (do (pure ())))
        (pure (BitVec.toNatInt p_addr))))

def page_dir_ptr_table_entry_addr (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) : SailM (BitVec 52) := do
  sail_assert ((← (unsigned_byte_p_int 52 (BitVec.toNatInt base_addr))) && ((loghead_bits 12 base_addr) == 0x000#12)) "././paging.sail:90.85-90.86"
  (pure (changeSlice_bits base_addr 3 9 (Sail.BitVec.extractLsb lin_addr 38 30)))

def ia32e_la_to_pa_page_dir_ptr_table (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) (u_s_acc : (BitVec 1)) (r_w_acc : (BitVec 1)) (x_d_acc : (BitVec 1)) (wp : (BitVec 1)) (smep : (BitVec 1)) (smap : (BitVec 1)) (ac : (BitVec 1)) (nxe : (BitVec 1)) (r_w_x : String) (cpl : (BitVec 2)) : SailM Int := do
  sail_assert (! (← readReg app_view)) "././paging.sail:311.29-311.30"
  let lin_addr ← (( do (binary_logext 48 (BitVec.toNatInt (loghead_bits 48 lin_addr))) ) : SailM Int )
  let base_addr : (BitVec 52) := (changeSlice_bits (loghead_bits 52 base_addr) 0 12 0x000#12)
  let p_entry_addr ← (( do (page_dir_ptr_table_entry_addr (bits_of_int lin_addr 48) base_addr) ) : SailM (BitVec 52) )
  let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
  let u_s_all : (BitVec 1) := (u_s_acc &&& (page_user_supervisor entry))
  let r_w_all : (BitVec 1) := (r_w_acc &&& (page_read_write entry))
  let x_d_all : (BitVec 1) := (x_d_acc &&& (page_execute_disable entry))
  let (fault_flg, sailval) ← (( do (paging_entry_no_page_fault_p 0b10#2 (bits_of_int lin_addr 48) entry u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl { supervisor_mode_access_type := 0 }) ) : SailM (Bool × Int) )
  (if (fault_flg : Bool)
  then (do (x86_model_error "Page-Fault"))
  else (do (pure ())))
  (if (((page_size entry) == 1#1) : Bool)
  then
    (do (if ((← readReg marking_view) : Bool)
        then
          (do let accessed : (BitVec 1) := (accessed_bit entry)
              let dirty : (BitVec 1) := (dirty_bit entry)
              let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
                if ((accessed == 0#1) : Bool)
                then (true, (set_accessed_bit entry))
                else (false, (Mk_ia32e_page_tablesbits entry))
              let (updated?, entry) : (Bool × ia32e_page_tablesbits) :=
                if (((dirty == 0#1) && (r_w_x == ":W")) : Bool)
                then (true, (set_dirty_bit entry))
                else (updated?, entry)
              (if (updated? : Bool)
              then (do (wm_low_64 p_entry_addr entry))
              else (do (pure ()))))
        else (do (pure ())))
        (pure (changeSlice_int (ash_left_int (BitVec.toNatInt (_get_ia32e_pdpte_1gb_pagebits_page (Mk_ia32e_pdpte_1gb_pagebits entry))) 30) 0 30 (BitVec.toNatInt (get_slice_int 30 lin_addr 0)))))
  else
    (do let page_directory_base_addr : Int := (ash_left_int (BitVec.toNatInt (_get_ia32e_pdpte_pg_dirbits_pd (Mk_ia32e_pdpte_pg_dirbits entry))) 12)
        let p_addr ← (( do (pure (bits_of_int (← (ia32e_la_to_pa_page_directory (bits_of_int lin_addr 48) (bits_of_int page_directory_base_addr 52) u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl)) 52)) ) : SailM (BitVec 52) )
        (if ((← readReg marking_view) : Bool)
        then
          (do let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
              let accessed : (BitVec 1) := (accessed_bit entry)
              let entry : ia32e_page_tablesbits :=
                if ((accessed == 0#1) : Bool)
                then (set_accessed_bit entry)
                else (Mk_ia32e_page_tablesbits entry)
              (if ((accessed == 0#1) : Bool)
              then (do (wm_low_64 p_entry_addr entry))
              else (do (pure ()))))
        else (do (pure ())))
        (pure (BitVec.toNatInt p_addr))))

def pml4_table_entry_addr (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) : SailM (BitVec 52) := do
  sail_assert ((← (unsigned_byte_p_int 52 (BitVec.toNatInt base_addr))) && ((loghead_bits 12 base_addr) == 0x000#12)) "././paging.sail:97.85-97.86"
  (pure (changeSlice_bits base_addr 3 9 (Sail.BitVec.extractLsb lin_addr 47 39)))

def ia32e_la_to_pa_pml4_table (lin_addr : (BitVec 48)) (base_addr : (BitVec 52)) (wp : (BitVec 1)) (smep : (BitVec 1)) (smap : (BitVec 1)) (ac : (BitVec 1)) (nxe : (BitVec 1)) (r_w_x : String) (cpl : (BitVec 2)) : SailM (BitVec 52) := do
  sail_assert (! (← readReg app_view)) "././paging.sail:370.29-370.30"
  let lin_addr ← (( do (binary_logext 48 (BitVec.toNatInt (loghead_bits 48 lin_addr))) ) : SailM Int )
  let base_addr : (BitVec 52) := (changeSlice_bits (loghead_bits 52 base_addr) 0 12 0x000#12)
  let p_entry_addr ← (( do (pml4_table_entry_addr (bits_of_int lin_addr 48) base_addr) ) : SailM (BitVec 52) )
  let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
  let u_s_all : (BitVec 1) := (page_user_supervisor entry)
  let r_w_all : (BitVec 1) := (page_read_write entry)
  let x_d_all : (BitVec 1) := (page_execute_disable entry)
  let (fault_flg, sailval) ← (( do (paging_entry_no_page_fault_p 0b11#2 (bits_of_int lin_addr 48) entry u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl { supervisor_mode_access_type := 0 }) ) : SailM (Bool × Int) )
  (if (fault_flg : Bool)
  then (do (x86_model_error "Page-Fault"))
  else (do (pure ())))
  let page_dir_ptr_table_base_addr : Int := (ash_left_int (BitVec.toNatInt (_get_ia32e_pml4ebits_pdpt (Mk_ia32e_pml4ebits entry))) 12)
  let p_addr ← (( do (pure (bits_of_int (← (ia32e_la_to_pa_page_dir_ptr_table (bits_of_int lin_addr 48) (bits_of_int page_dir_ptr_table_base_addr 52) u_s_all r_w_all x_d_all wp smep smap ac nxe r_w_x cpl)) 52)) ) : SailM (BitVec 52) )
  (if ((← readReg marking_view) : Bool)
  then
    (do let entry ← (( do (rm_low_64 (BitVec.toNatInt p_entry_addr)) ) : SailM (BitVec 64) )
        let accessed : (BitVec 1) := (accessed_bit entry)
        let entry : ia32e_page_tablesbits :=
          if ((accessed == 0#1) : Bool)
          then (set_accessed_bit entry)
          else (Mk_ia32e_page_tablesbits entry)
        (if ((accessed == 0#1) : Bool)
        then (do (wm_low_64 p_entry_addr entry))
        else (do (pure ()))))
  else (do (pure ())))
  (pure p_addr)

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 6 -/
def read_msr (idx : Nat) : SailM (BitVec 64) := do
  (pure (GetElem?.getElem! (← readReg msrs) idx))

def ia32e_la_to_pa (lin_addr : (BitVec 48)) (r_w_x : String) : SailM (BitVec 52) := do
  sail_assert (! (← readReg app_view)) "././paging.sail:401.29-401.30"
  let lin_addr ← (( do (binary_logext 48 (BitVec.toNatInt (loghead_bits 48 lin_addr))) ) : SailM Int )
  let cr0 ← (( do (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg ctrs) 0) 32)) ) : SailM (BitVec 32) )
  let cr4 ← (( do (pure (Sail.BitVec.truncate (GetElem?.getElem! (← readReg ctrs) 4) 22)) ) : SailM (BitVec 22) )
  let cpl ← (( do (pure (_get_segment_selectorbits_rpl (Mk_segment_selectorbits (GetElem?.getElem! (← readReg seg_visibles) 1)))) ) : SailM (BitVec 2) )
  let ia32_efer ← (( do (pure (Sail.BitVec.truncate (← (read_msr 0)) 12)) ) : SailM (BitVec 12) )
  let wp : (BitVec 1) := (_get_cr0bits_wp (Mk_cr0bits cr0))
  let smep : (BitVec 1) := (_get_cr4bits_smep (Mk_cr4bits cr4))
  let smap : (BitVec 1) := (_get_cr4bits_smap (Mk_cr4bits cr4))
  let ac ← (( do (pure (_get_rflagsbits_ac (← readReg rflags))) ) : SailM (BitVec 1) )
  let nxe : (BitVec 1) := (_get_ia32_eferbits_nxe (Mk_ia32_eferbits ia32_efer))
  let cr3 ← (( do (pure (GetElem?.getElem! (← readReg ctrs) 3)) ) : SailM (BitVec 64) )
  let pml4_table_base_addr : Int := (ash_left_int (BitVec.toNatInt (_get_cr3bits_pdb (Mk_cr3bits cr3))) 12)
  (ia32e_la_to_pa_pml4_table (bits_of_int lin_addr 48) (bits_of_int pml4_table_base_addr 52) wp smep smap ac nxe r_w_x cpl)

/-- Type quantifiers: k_addr_width : Nat, n : Nat, k_addr_width > 0 ∧ n > 0 -/
def rb (n : Nat) (addr : (BitVec k_addr_width)) (access_kind : String) : SailM (BitVec (8 * n)) := do
  let result : (BitVec (8 * n)) := (BitVec.zero (8 *i n))
  let loop_offset_lower := 0
  let loop_offset_upper := (n -i 1)
  let mut loop_vars := result
  for offset in [loop_offset_lower:loop_offset_upper:1]i do
    let result := loop_vars
    loop_vars ← do
      (if ((! (← (canonical_address_p ((BitVec.toInt addr) +i offset)))) : Bool)
      then (do (x86_model_error "rb: non-canonical address"))
      else (do (pure ())))
      let lin_addr : (BitVec 48) := (BitVec.addInt (sail_mask_signed 48 addr) offset)
      let phys_addr ← (( do
        (if ((← readReg app_view) : Bool)
        then (do (pure (sail_mask_signed 52 lin_addr)))
        else (do (ia32e_la_to_pa lin_addr access_kind))) ) : SailM (BitVec 52) )
      (pure (Sail.BitVec.updateSubrange result ((8 *i offset) +i 7) (8 *i offset) (← (memi phys_addr))))
  (pure loop_vars)

/-- Type quantifiers: len : Int -/
def observe_mem_write (addr : (BitVec 48)) (len : Int) : Unit :=
  ()

/-- Type quantifiers: k_addr_width : Nat, n : Nat, k_addr_width > 0 ∧ n > 0 -/
def wb (n : Nat) (addr : (BitVec k_addr_width)) (access_kind : String) (value : (BitVec (8 * n))) : SailM Unit := do
  let loop_offset_lower := 0
  let loop_offset_upper := (n -i 1)
  let mut loop_vars := ()
  for offset in [loop_offset_lower:loop_offset_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((! (← (canonical_address_p ((BitVec.toInt addr) +i offset)))) : Bool)
      then
        (do let _ : Unit :=
              if ((offset != 0) : Bool)
              then (observe_mem_write (sail_mask_signed 48 addr) (offset -i 1))
              else ()
            (x86_model_error "wb: non-canonical address"))
      else (do (pure ())))
      let lin_addr : (BitVec 48) := (BitVec.addInt (sail_mask_signed 48 addr) offset)
      let phys_addr ← (( do
        (if ((← readReg app_view) : Bool)
        then (do (pure (sail_mask_signed 52 lin_addr)))
        else (do (ia32e_la_to_pa lin_addr access_kind))) ) : SailM (BitVec 52) )
      (bang_memi phys_addr (Sail.BitVec.extractLsb value ((8 *i offset) +i 7) (8 *i offset)))
  (pure loop_vars)
  let dummy := (observe_mem_write (sail_mask_signed 48 addr) n)
  (pure ())

def regval_into_reg (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_vex_prefixes (v : (BitVec 24)) : (BitVec 24) :=
  v

def _update_vex_prefixes_byte0 (v : (BitVec 24)) (x : (BitVec 8)) : (BitVec 24) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_evex_prefixes_byte0 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_vex_prefixes_byte1 (v : (BitVec 24)) (x : (BitVec 8)) : (BitVec 24) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def _update_evex_prefixes_byte1 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def Mk_evex_prefixes (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_modr_m (v : (BitVec 8)) : (BitVec 8) :=
  v

def _get_modr_m_mod (v : (BitVec 8)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_modr_m_r_m (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_modr_m_reg (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 5 3)

def Mk_sib (v : (BitVec 8)) : (BitVec 8) :=
  v

def _get_sib_base (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_sib_index (v : (BitVec 8)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 5 3)

def _get_segment_selectorbits_index (v : (BitVec 16)) : (BitVec 13) :=
  (Sail.BitVec.extractLsb v 15 3)

def _get_sib_scale (v : (BitVec 8)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def undefined_rflagsbits (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_rflagsbits (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_rflagsbits_af (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _update_rflagsbits_af (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _get_rflagsbits_cf (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_rflagsbits_cf (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_rflagsbits_df (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_rflagsbits_df (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)


end X86Sail.Functions
