-- Sail-generated model, split by JanusASL/sail/split_lean.py
import ArmASL.Part36
