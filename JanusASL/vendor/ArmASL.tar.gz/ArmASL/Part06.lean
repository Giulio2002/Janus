import ArmASL.Part05

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_is_ase : Bool -/
def AArch64_FPTrappedException (is_ase : Bool) (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_FPTrappedException) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (is_ase : Bool)
    then
      (do (if ((← (__IMPDEF_boolean "vector instructions set TFV to 1")) : Bool)
          then (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))
          else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 0#1)) }))))
    else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 10 8 (← (__UNKNOWN_bits 3))))) })
  let except ← (( do
    (if ((((BitVec.access except.syndrome 23) : BitVec 1) == 1#1) : Bool)
    then
      (do let split_vec := (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0))
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))
    else
      (do let split_vec ← do (__UNKNOWN_bits 6)
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))) ) : SailM ExceptionRecord )
  let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def undefined_FPEXC32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_FPEXC_Type_DEX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_FPEXC_Type_EN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_PMUSERENR_EL0_Type_EN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_FPEXC_Type_EX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_FPEXC_Type_FP2V (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_FPEXC_Type_TFV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _update_FPEXC_Type_VECITR (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 8 x)

def _update_FPEXC_Type_VV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def undefined_FPEXC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_FPEXC_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def FPEXC_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _FPEXC ) : SailM FPEXC_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FPEXC32_EL2) 0 32)))

def FPEXC_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPEXC_Type := value_name
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _FPEXC r

def AArch32_FPTrappedException (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (AArch32_GeneralExceptionsToAArch64 ())) : Bool)
  then
    (do let is_ase : Bool := false
        let element : Int := 0
        (AArch64_FPTrappedException is_ase accumulated_exceptions))
  else (do (pure ())))
  (FPEXC_write (_update_FPEXC_Type_DEX (← (FPEXC_read ())) 1#1))
  (FPEXC_write (_update_FPEXC_Type_TFV (← (FPEXC_read ())) 1#1))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 7 7 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 5 1))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 4 0 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 0 5))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 10 8 0b111#3)))
  (AArch32_TakeUndefInstrException ())

def FPSCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPSCR_Type := value_name
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 31 27 (BitVec.slice r 27 5))
  writeReg FPSR (BitVec.update (← readReg FPSR) 7 (Bit (BitVec.slice r 7 1)))
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 4 0 (BitVec.slice r 0 5))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 26 15 (BitVec.slice r 15 12))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 12 8 (BitVec.slice r 8 5))

def HaveSMEFullA64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME_FA64)

def IsFullA64Enabled (_ : Unit) : SailM Bool := SailME.run do
  (if ((! (← (HaveSMEFullA64 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
             (pure (! (← (IsInHost ()))))))) : Bool)
        then
          (do (if (((_get_SMCR_EL1_Type_FA64 (← readReg SMCR_EL1)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1)) <||> (do
               (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if (((_get_SMCR_EL2_Type_FA64 (← readReg SMCR_EL2)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_SMCR_EL3_Type_FA64 (← readReg SMCR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def GetAccumulatedFPExceptions (_ : Unit) : SailM (BitVec 8) := do
  (__UNKNOWN_bits 8)

def IsASEInstruction (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def SetAccumulatedFPExceptions (accumulated_exceptions : (BitVec 8)) : Unit :=
  ()

def FPProcessException (except : FPExc) (fpcr : (BitVec 64)) : SailM Unit := do
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  let cumul : Int := 0
  let cumul : Int :=
    match except with
    | .FPExc_InvalidOp => 0
    | .FPExc_DivideByZero => 1
    | .FPExc_Overflow => 2
    | .FPExc_Underflow => 3
    | .FPExc_Inexact => 4
    | .FPExc_InputDenorm => 7
  let cumul := cumul
  let enable := (cumul +i 8)
  (if ((←((pure (((BitVec.access fpcr enable) : BitVec 1) == 1#1)) <&&> (do
       (pure (! (← (HaveSME ())))) <||> (do
         (pure ((← readReg PSTATE).SM == 0#1))) <||> (do
         (IsFullA64Enabled ()))))) : Bool)
  then
    (do let accumulated_exceptions ← (( do (GetAccumulatedFPExceptions ()) ) : SailM (BitVec 8) )
        let accumulated_exceptions : (BitVec 8) := (BitVec.update accumulated_exceptions cumul (Bit 1#1))
        (if ((← (__IMPDEF_boolean "Support trapping of floating-point exceptions")) : Bool)
        then
          (do (if ((← (UsingAArch32 ())) : Bool)
              then (do (AArch32_FPTrappedException accumulated_exceptions))
              else
                (do let is_ase ← (( do (IsASEInstruction ()) ) : SailM Bool )
                    (AArch64_FPTrappedException is_ase accumulated_exceptions))))
        else (do (pure (SetAccumulatedFPExceptions accumulated_exceptions)))))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (Mk_FPSCR_Type (Sail.BitVec.updateSubrange (← (FPSCR_read__1 ())) cumul cumul 1#1))))
        else (do writeReg FPSR (BitVec.update (← readReg FPSR) cumul (Bit 1#1))))))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPZero (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15627.38-15627.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Zeros (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

def HaveAltFP (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AFP)

/-- Type quantifiers: N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem N [16, 32, 64] -/
def FPRoundBase__1 (op : real) (fpcr : (BitVec 64)) (rounding : FPRounding) (isbfloat16 : Bool) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := SailME.run do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15647.38-15647.39"
  sail_assert (bne op (0)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15648.20-15648.21"
  sail_assert (bne rounding FPRounding_TIEAWAY) "sail-arm/arm-v9.4-a/src/v8_base.sail:15649.41-15649.42"
  let result ← (( do (undefined_bitvector N) ) : SailME (BitVec N) (BitVec N) )
  let minimum_exp ← (( do (undefined_int ()) ) : SailME (BitVec N) Int )
  let F : Int := 7
  let E : Int := 5
  let (E, F, minimum_exp) : (Int × Int × Int) :=
    if ((N == 16) : Bool)
    then
      (let minimum_exp : Int := (Neg.neg 14)
      let E : Int := 5
      let F : Int := 10
      (E, F, minimum_exp))
    else
      (let (E, F, minimum_exp) : (Int × Int × Int) :=
        if (((N == 32) && isbfloat16) : Bool)
        then
          (let minimum_exp : Int := (Neg.neg 126)
          let E : Int := 8
          let F : Int := 7
          (E, F, minimum_exp))
        else
          (let (E, F, minimum_exp) : (Int × Int × Int) :=
            if ((N == 32) : Bool)
            then
              (let minimum_exp : Int := (Neg.neg 126)
              let E : Int := 8
              let F : Int := 23
              (E, F, minimum_exp))
            else
              (let minimum_exp : Int := (Neg.neg 1022)
              let E : Int := 11
              let F : Int := 52
              (E, F, minimum_exp))
          (E, F, minimum_exp))
      (E, F, minimum_exp))
  let minimum_exp := minimum_exp
  let F := F
  let E := E
  let sign ← (( do (undefined_bitvector 1) ) : SailME (BitVec N) (BitVec 1) )
  let mantissa ← (( do (undefined_real ()) ) : SailME (BitVec N) real )
  let (mantissa, sign) : (real × (BitVec 1)) :=
    if ((lt_real op (0)) : Bool)
    then
      (let sign : (BitVec 1) := 1#1
      let mantissa : real := (neg_real op)
      (mantissa, sign))
    else
      (let sign : (BitVec 1) := 0#1
      let mantissa : real := op
      (mantissa, sign))
  let exponent : Int := 0
  let (exponent, mantissa) ← (( do
    let mut loop_vars := (exponent, mantissa)
    while (λ (exponent, mantissa) => (lt_real mantissa (1))) loop_vars do
      let (exponent, mantissa) := loop_vars
      loop_vars :=
        (let mantissa : real := (mult_real mantissa (2))
        let exponent : Int := (exponent -i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars) ) : SailME (BitVec N) (Int × real) )
  let (exponent, mantissa) ← (( do
    let mut loop_vars_1 := (exponent, mantissa)
    while (λ (exponent, mantissa) => (gteq_real mantissa (2))) loop_vars_1 do
      let (exponent, mantissa) := loop_vars_1
      loop_vars_1 :=
        (let mantissa : real := (div_real mantissa (2))
        let exponent : Int := (exponent +i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars_1) ) : SailME (BitVec N) (Int × real) )
  let exponent := exponent
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailME (BitVec N) Bool )
  (if ((((! altfp) && ((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16)))) && (exponent <b minimum_exp)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (_update_FPSCR_Type_UFC (← (FPSCR_read__1 ())) 1#1)))
        else
          (do (if (fpexc : Bool)
              then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1))
              else (do (pure ())))))
        (FPZero sign N))
  else
    (do let biased_exp_unconstrained : Int := ((exponent -i minimum_exp) +i 1)
        let int_mant_unconstrained : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error_unconstrained : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant_unconstrained))
        let biased_exp : Int := (Max.max ((exponent -i minimum_exp) +i 1) 0)
        let mantissa : real :=
          if ((biased_exp == 0) : Bool)
          then (div_real mantissa (real_power (2) (minimum_exp -i exponent)))
          else mantissa
        let mantissa := mantissa
        let int_mant : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant))
        let trapped_UF ← (( do (pure ((_get_FPCRType_UFE fpcr) == 1#1)) <&&> (do (pure (! (← (InStreamingMode ())))) <||> (do (IsFullA64Enabled ()))) ) : SailME (BitVec N) Bool )
        (if ((((! altfp) && (biased_exp == 0)) && ((bne error (0)) || trapped_UF)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Underflow fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        let round_up_unconstrained ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let round_up ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let overflow_to_inf ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let (overflow_to_inf, round_up) ← (( do
          (if (altfp : Bool)
          then
            (do let (overflow_to_inf, round_up, round_up_unconstrained) : (Bool × Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up_unconstrained : Bool := ((gt_real error_unconstrained (1/2)) || ((eq_real error_unconstrained (1/2)) && (((integer_access int_mant_unconstrained 0) : BitVec 1) == 1#1)))
                    let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_POSINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 0#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_NEGINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 1#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ZERO =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ODD =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | _ => (overflow_to_inf, round_up, round_up_unconstrained)
                let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                  if (round_up_unconstrained : Bool)
                  then
                    (let int_mant_unconstrained : Int := (int_mant_unconstrained +i 1)
                    let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                      if ((int_mant_unconstrained == (2 ^i (F +i 1))) : Bool)
                      then
                        (let biased_exp_unconstrained : Int := (biased_exp_unconstrained +i 1)
                        let int_mant_unconstrained : Int := (fdiv_int int_mant_unconstrained 2)
                        (biased_exp_unconstrained, int_mant_unconstrained))
                      else (biased_exp_unconstrained, int_mant_unconstrained)
                    (biased_exp_unconstrained, int_mant_unconstrained))
                  else (biased_exp_unconstrained, int_mant_unconstrained)
                let int_mant_unconstrained := int_mant_unconstrained
                let biased_exp_unconstrained := biased_exp_unconstrained
                (if (((biased_exp_unconstrained <b 1) && (int_mant_unconstrained != 0)) : Bool)
                then
                  (do (if (((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16))) : Bool)
                      then
                        (do SailME.throw (← do
                                (if (fpexc : Bool)
                                then
                                  (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1)
                                      (FPProcessException FPExc_Inexact fpcr))
                                else (do (pure ())))
                                (FPZero sign N)))
                      else
                        (do (if (((bne error (0)) || trapped_UF) : Bool)
                            then
                              (do (if (fpexc : Bool)
                                  then (do (FPProcessException FPExc_Underflow fpcr))
                                  else (do (pure ()))))
                            else (do (pure ()))))))
                else (do (pure ())))
                (pure (overflow_to_inf, round_up)))
          else
            (do let (overflow_to_inf, round_up) : (Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up))
                  | .FPRounding_POSINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_NEGINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_ZERO =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | .FPRounding_ODD =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | _ => (overflow_to_inf, round_up)
                (pure (overflow_to_inf, round_up)))) ) : SailME (BitVec N) (Bool × Bool) )
        let (biased_exp, int_mant) : (Int × Int) :=
          if (round_up : Bool)
          then
            (let int_mant : Int := (int_mant +i 1)
            let biased_exp : Int :=
              if ((int_mant == (2 ^i F)) : Bool)
              then 1
              else biased_exp
            let (biased_exp, int_mant) : (Int × Int) :=
              if ((int_mant == (2 ^i (F +i 1))) : Bool)
              then
                (let biased_exp : Int := (biased_exp +i 1)
                let int_mant : Int := (fdiv_int int_mant 2)
                (biased_exp, int_mant))
              else (biased_exp, int_mant)
            (biased_exp, int_mant))
          else (biased_exp, int_mant)
        let biased_exp := biased_exp
        let int_mant : Int :=
          if (((bne error (0)) && (BEq.beq rounding FPRounding_ODD)) : Bool)
          then (integer_update_subrange int_mant 0 0 1#1)
          else int_mant
        let int_mant := int_mant
        let (error, result) ← (( do
          (if (((N != 16) || ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
          then
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b ((2 ^i E) -i 1)) : Bool)
                  then
                    (do let result ←
                          (if (overflow_to_inf : Bool)
                          then (do (FPInfinity sign N))
                          else (do (FPMaxNormal sign N)))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_Overflow fpcr))
                        else (do (pure ())))
                        let error : real := (1)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15829.54-15829.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))
          else
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b (2 ^i E)) : Bool)
                  then
                    (do let result : (BitVec N) := (sign +++ (Ones (n := (N -i 1))))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_InvalidOp fpcr))
                        else (do (pure ())))
                        let error : real := (0)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15840.54-15840.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
        (if ((bne error (0)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Inexact fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        (pure result)))

def FPDecodeRounding (rmode : (BitVec 2)) : SailM FPRounding := do
  match rmode with
  | 0b00 => (pure FPRounding_TIEEVEN)
  | 0b01 => (pure FPRounding_POSINF)
  | 0b10 => (pure FPRounding_NEGINF)
  | 0b11 => (pure FPRounding_ZERO)
  | _ => (do (undefined_FPRounding ()))

def FPRoundingMode (fpcr : (BitVec 64)) : SailM FPRounding := do
  (FPDecodeRounding (_get_FPCRType_RMode fpcr))

/-- Type quantifiers: N : Nat, k_fpexc : Bool, List.elem N [16, 32, 64] -/
def FPRound__2 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := do
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let isbfloat16 : Bool := false
  (FPRoundBase__1 op fpcr rounding isbfloat16 fpexc N)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRound__1 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  let fpexc : Bool := true
  (FPRound__2 op fpcr_in rounding fpexc N)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRound (op : real) (fpcr : (BitVec 64)) (N : Nat) : SailM (BitVec N) := do
  (FPRound__1 op fpcr (← (FPRoundingMode fpcr)) N)

/-- Type quantifiers: k_M : Nat, N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem N [16, 32, 64] ∧ List.elem k_M [16, 32, 64] -/
def FixedToFP (op : (BitVec k_M)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15912.38-15912.39"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15913.41-15913.42"
  let result ← (( do (undefined_bitvector N) ) : SailM (BitVec N) )
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15915.21-15915.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:15916.37-15916.38"
  let int_operand ← (( do (asl_Int op is_unsigned) ) : SailM Int )
  let real_operand : real := (div_real (to_real int_operand) (real_power (2) fbits))
  (if ((eq_real real_operand (0)) : Bool)
  then (do (FPZero 0#1 N))
  else (do (FPRound__1 real_operand fpcr rounding N)))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) (isbfloat16 : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let exp16 ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  let exp64 ← (( do (undefined_bitvector 11) ) : SailM (BitVec 11) )
  let frac16 ← (( do (undefined_bitvector 10) ) : SailM (BitVec 10) )
  let frac64 ← (( do (undefined_bitvector 52) ) : SailM (BitVec 52) )
  sail_assert (((Sail.BitVec.length fpval) == 16) || (((Sail.BitVec.length fpval) == 32) || ((Sail.BitVec.length fpval) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15949.41-15949.42"
  let fpcr : FPCRType := fpcr_in
  let altfp ← (( do (HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))) ) : SailM Bool )
  let fiz : Bool := (altfp && ((_get_FPCRType_FIZ fpcr) == 1#1))
  let fz : Bool := (((_get_FPCRType_FZ fpcr) == 1#1) && (! (altfp && ((_get_FPCRType_AH fpcr) == 1#1))))
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let (fptype, sign, value_name) ← (( do
    (if ((((Sail.BitVec.length fpval) == 16) && (! isbfloat16)) : Bool)
    then
      (do let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
          let exp16 : (BitVec 5) := (Sail.BitVec.extractLsb fpval 14 10)
          let frac16 : (BitVec 10) := (Sail.BitVec.extractLsb fpval 9 0)
          let (fptype, value_name) : (FPType × real) :=
            if ((IsZero exp16) : Bool)
            then
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsZero frac16) || ((_get_FPCRType_FZ16 fpcr) == 1#1)) : Bool)
                then
                  (let fptype : FPType := FPType_Zero
                  let value_name : real := (0)
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Denormal
                  let value_name : real := (mult_real (real_power (2) (Neg.neg 14)) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10))))
                  (fptype, value_name))
              (fptype, value_name))
            else
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsOnes exp16) && ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
                then
                  (let (fptype, value_name) : (FPType × real) :=
                    if ((IsZero frac16) : Bool)
                    then
                      (let fptype : FPType := FPType_Infinity
                      let value_name : real := (real_power (2) 1000000)
                      (fptype, value_name))
                    else
                      (let fptype : FPType :=
                        if ((((BitVec.access frac16 9) : BitVec 1) == 1#1) : Bool)
                        then FPType_QNaN
                        else FPType_SNaN
                      let value_name : real := (0)
                      (fptype, value_name))
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Nonzero
                  let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp16) -i 15)) (add_real (1) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10)))))
                  (fptype, value_name))
              (fptype, value_name))
          (pure (fptype, sign, value_name)))
    else
      (do let (fptype, sign, value_name) ← (( do
            (if ((((Sail.BitVec.length fpval) == 32) || isbfloat16) : Bool)
            then
              (do let exp32 ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
                  let frac32 ← (( do (undefined_bitvector 23) ) : SailM (BitVec 23) )
                  let (exp32, frac32, sign) : ((BitVec 8) × (BitVec 23) × (BitVec 1)) :=
                    if (isbfloat16 : Bool)
                    then
                      (let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 14 7)
                      let frac32 : (BitVec 23) := ((Sail.BitVec.extractLsb fpval 6 0) +++ (Zeros (n := 16)))
                      (exp32, frac32, sign))
                    else
                      (let sign : (BitVec 1) := ((BitVec.access fpval 31) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 30 23)
                      let frac32 : (BitVec 23) := (Sail.BitVec.extractLsb fpval 22 0)
                      (exp32, frac32, sign))
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp32) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac32) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 126)) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp32) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac32) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac32 22) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp32) -i 127)) (add_real (1) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))
            else
              (do let sign : (BitVec 1) := ((BitVec.access fpval 63) : BitVec 1)
                  let exp64 : (BitVec 11) := (Sail.BitVec.extractLsb fpval 62 52)
                  let frac64 : (BitVec 52) := (Sail.BitVec.extractLsb fpval 51 0)
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp64) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac64) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 1022)) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp64) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac64) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac64 51) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp64) -i 1023)) (add_real (1) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
          (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
  let value_name : real :=
    if ((sign == 1#1) : Bool)
    then (neg_real value_name)
    else value_name
  let value_name := value_name
  (pure (fptype, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase (fpval : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let isbfloat16 : Bool := false
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase__1 fpval fpcr fpexc isbfloat16)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPUnpack (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let fpexc : Bool := true
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpack__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPAbs (op : (BitVec k_N)) : SailM (BitVec k_N) := SailME.run do
  let fptype ← (( do (undefined_FPType ()) ) : SailME (BitVec k_N) FPType )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16099.41-16099.42"
  (if ((←((pure (! (← (UsingAArch32 ())))) <&&> (do
       (HaveAltFP ())))) : Bool)
  then
    (do let fpcr ← (( do (FPCR_read ()) ) : SailME (BitVec k_N) FPCRType )
        (if (((_get_FPCRType_AH fpcr) == 1#1) : Bool)
        then
          (do let fptype ← (( do
                let (__tup_0, _, _) ← do (FPUnpack__1 op fpcr false)
                (pure __tup_0) ) : SailME (BitVec k_N) FPType )
              (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
              then (do SailME.throw (op : (BitVec k_N)))
              else (do (pure ()))))
        else (do (pure ()))))
  else (do (pure ())))
  (pure (0#1 +++ (Sail.BitVec.extractLsb op ((Sail.BitVec.length op) -i 2) 0)))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPDefaultNaN__1 (fpcr : (BitVec 64)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16128.38-16128.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let sign ← (( do
    (if ((←((HaveAltFP ()) <&&> (do
         (pure (! (← (UsingAArch32 ()))))))) : Bool)
    then (do (pure (_get_FPCRType_AH fpcr)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (1#1 +++ (Zeros (n := (F -i 1))))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Int -/
def FPProcessDenorms (type1 : FPType) (type2 : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && ((BEq.beq type1 FPType_Denormal) || (BEq.beq type2 FPType_Denormal))) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaN__1 (fptype : FPType) (op : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16162.41-16162.42"
  sail_assert ((BEq.beq fptype FPType_QNaN) || (BEq.beq fptype FPType_SNaN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:16163.56-16163.57"
  let topfrac : Int := 9
  let topfrac : Int :=
    match (Sail.BitVec.length op) with
    | 16 => 9
    | 32 => 22
    | 64 => 51
    | _ => topfrac
  let topfrac := topfrac
  let result : (BitVec k_N) := op
  let result ← (( do
    (if ((BEq.beq fptype FPType_SNaN) : Bool)
    then
      (do sail_assert ((0 ≤b topfrac) && (topfrac <b (Sail.BitVec.length result))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16180.58-16180.59"
          let result : (BitVec k_N) := (BitVec.update result topfrac (Bit 1#1))
          (if (fpexc : Bool)
          then (do (FPProcessException FPExc_InvalidOp fpcr))
          else (do (pure ())))
          (pure result))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if (((_get_FPCRType_DN fpcr) == 1#1) : Bool)
  then (do (FPDefaultNaN__1 fpcr (Sail.BitVec.length result)))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPProcessNaN (fptype : FPType) (op : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPProcessNaN__1 fptype op fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs__1 (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16206.41-16206.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let any_snan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN))
  let type_nan : FPType :=
    if (any_snan : Bool)
    then FPType_SNaN
    else FPType_QNaN
  let (done, result) ← (( do
    (if (((altfp && op1_nan) && op2_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPProcessNaN__1 type_nan op1 fpcr fpexc)
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if ((BEq.beq type1 FPType_SNaN) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_QNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                          (pure (done, result)))
                                    else
                                      (do let done : Bool := false
                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (Bool × (BitVec k_N)) := do
  let fpexc : Bool := true
  (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPAdd__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16263.41-16263.42"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) && (sign1 == (Complement.complement sign2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((inf1 && (sign1 == 0#1)) || (inf2 && (sign2 == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((inf1 && (sign1 == 1#1)) || (inf2 && (sign2 == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zero1 && zero2) && (sign1 == sign2)) : Bool)
                            then (do (FPZero sign1 (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real value1_name value2_name)
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (fpexc : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPAdd (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPAdd__1 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_signal_nans : Bool, List.elem k_N [16, 32, 64] -/
def FPCompare (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (signal_nans : Bool) (fpcr : (BitVec 64)) : SailM (BitVec 4) := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16326.41-16326.42"
  let (type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (type1, value1_name)) ) : SailM (FPType × real) )
  let (type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (type2, value2_name)) ) : SailM (FPType × real) )
  let result ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))) : Bool)
  then
    (do let result : (BitVec 4) := 0b0011#4
        (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) || signal_nans) : Bool)
        then (do (FPProcessException FPExc_InvalidOp fpcr))
        else (do (pure ())))
        (pure result))
  else
    (do let result : (BitVec 4) :=
          if ((eq_real value1_name value2_name) : Bool)
          then 0b0110#4
          else
            (if ((lt_real value1_name value2_name) : Bool)
            then 0b1000#4
            else 0b0010#4)
        (FPProcessDenorms type1 type2 (Sail.BitVec.length op2) fpcr)
        (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPCompareEQ (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM Bool := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16359.41-16359.42"
  let (type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (type1, value1_name)) ) : SailM (FPType × real) )
  let (type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (type2, value2_name)) ) : SailM (FPType × real) )
  let result ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))) : Bool)
  then
    (do let result : Bool := false
        (if (((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) : Bool)
        then (do (FPProcessException FPExc_InvalidOp fpcr))
        else (do (pure ())))
        (pure result))
  else
    (do let result : Bool := (eq_real value1_name value2_name)
        (FPProcessDenorms type1 type2 (Sail.BitVec.length op2) fpcr)
        (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPCompareGE (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM Bool := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16386.41-16386.42"
  let (type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (type1, value1_name)) ) : SailM (FPType × real) )
  let (type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (type2, value2_name)) ) : SailM (FPType × real) )
  let result ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))) : Bool)
  then
    (do let result : Bool := false
        (FPProcessException FPExc_InvalidOp fpcr)
        (pure result))
  else
    (do let result : Bool := (gteq_real value1_name value2_name)
        (FPProcessDenorms type1 type2 (Sail.BitVec.length op2) fpcr)
        (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPCompareGT (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM Bool := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16410.41-16410.42"
  let (type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (type1, value1_name)) ) : SailM (FPType × real) )
  let (type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (type2, value2_name)) ) : SailM (FPType × real) )
  let result ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))) : Bool)
  then
    (do let result : Bool := false
        (FPProcessException FPExc_InvalidOp fpcr)
        (pure result))
  else
    (do let result : Bool := (gt_real value1_name value2_name)
        (FPProcessDenorms type1 type2 (Sail.BitVec.length op2) fpcr)
        (pure result)))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem k_N [16, 32, 64] ∧ List.elem M [16, 32, 64] -/
def FPConvertNaN (op : (BitVec k_N)) (M : Nat) : SailM (BitVec M) := do
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16429.41-16429.42"
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16430.38-16430.39"
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let frac ← (( do (undefined_bitvector 51) ) : SailM (BitVec 51) )
  let sign : (BitVec 1) := ((BitVec.access op ((Sail.BitVec.length op) -i 1)) : BitVec 1)
  let frac : (BitVec 51) :=
    match (Sail.BitVec.length op) with
    | 64 => (Sail.BitVec.extractLsb op 50 0)
    | 32 => ((Sail.BitVec.extractLsb op 21 0) +++ (Zeros (n := 29)))
    | 16 => ((Sail.BitVec.extractLsb op 8 0) +++ (Zeros (n := 42)))
    | _ => frac
  match M with
  | 64 => (pure ((sign +++ (Ones (n := (M -i 52)))) +++ frac))
  | 32 => (pure ((sign +++ (Ones (n := (M -i 23)))) +++ (Sail.BitVec.extractLsb frac 50 29)))
  | 16 => (pure ((sign +++ (Ones (n := (M -i 10)))) +++ (Sail.BitVec.extractLsb frac 50 42)))
  | _ => (pure result)

/-- Type quantifiers: N : Int -/
def FPProcessDenorm (fptype : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && (BEq.beq fptype FPType_Denormal)) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRoundCV (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 19 19 0#1)
  let fpexc : Bool := true
  let isbfloat16 : Bool := false
  (FPRoundBase__1 op fpcr rounding isbfloat16 fpexc N)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPUnpackCV (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 19 19 0#1)
  let fpexc : Bool := true
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem M [16, 32, 64] ∧ List.elem k_N [16, 32, 64] -/
def FPConvert (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (M : Nat) : SailM (BitVec M) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16508.38-16508.39"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16509.41-16509.42"
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackCV op fpcr)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let alt_hp : Bool := ((M == 16) && ((_get_FPCRType_AHP fpcr) == 1#1))
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then
    (do let result ← (( do
          (if (alt_hp : Bool)
          then (do (FPZero sign M))
          else
            (do (if (((_get_FPCRType_DN fpcr) == 1#1) : Bool)
                then (do (FPDefaultNaN__1 fpcr M))
                else (do (FPConvertNaN op M))))) ) : SailM (BitVec M) )
        (if (((BEq.beq fptype FPType_SNaN) || alt_hp) : Bool)
        then (do (FPProcessException FPExc_InvalidOp fpcr))
        else (do (pure ())))
        (pure result))
  else
    (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
        then
          (do (if (alt_hp : Bool)
              then
                (do let result : (BitVec M) := (sign +++ (Ones (n := (M -i 1))))
                    (FPProcessException FPExc_InvalidOp fpcr)
                    (pure result))
              else (do (FPInfinity sign M))))
        else
          (do (if ((BEq.beq fptype FPType_Zero) : Bool)
              then (do (FPZero sign M))
              else
                (do let result ← (FPRoundCV value_name fpcr rounding M)
                    (FPProcessDenorm fptype (Sail.BitVec.length op) fpcr)
                    (pure result)))))))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem M [16, 32, 64] ∧ List.elem k_N [16, 32, 64] -/
def FPConvert__1 (op : (BitVec k_N)) (fpcr : (BitVec 64)) (M : Nat) : SailM (BitVec M) := do
  (FPConvert op fpcr (← (FPRoundingMode fpcr)) M)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPDiv (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16583.41-16583.42"
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) || (zero1 && zero2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (FPProcessException FPExc_InvalidOp fpcr)
                (pure result))
          else
            (do (if ((inf1 || zero2) : Bool)
                then
                  (do let result ← (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result))
                      (if ((! inf1) : Bool)
                      then (do (FPProcessException FPExc_DivideByZero fpcr))
                      else (do (pure ())))
                      (pure result))
                else
                  (do (if ((zero1 || inf2) : Bool)
                      then (do (FPZero (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                      else (do (FPRound (div_real value1_name value2_name) fpcr (Sail.BitVec.length result)))))))) ) : SailM (BitVec k_N) )
        (if ((! zero2) : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMax__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16634.41-16634.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((gt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 &&& sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMax (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (FPMax__1 op1 op2 fpcr altfp)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMaxNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16680.41-16680.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 1#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 1#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMax__1 op1 op2 fpcr altfmaxfmin)

def IsMerging (fpcr : (BitVec 64)) : SailM Bool := do
  let nep ← (( do
    (if ((←((HaveSME ()) <&&> (do
         (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do
         (pure (! (← (IsFullA64Enabled ()))))))) : Bool)
    then (do (pure 0#1))
    else (do (pure (_get_FPCRType_NEP fpcr)))) ) : SailM (BitVec 1) )
  (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && (nep == 1#1)))

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMin__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16735.41-16735.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((lt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 ||| sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMin (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (FPMin__1 op1 op2 fpcr altfp)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMinNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16782.41-16782.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 0#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 0#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMin__1 op1 op2 fpcr altfmaxfmin)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMul (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16824.41-16824.42"
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && zero2) || (zero1 && inf2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (FPProcessException FPExc_InvalidOp fpcr)
                (pure result))
          else
            (do (if ((inf1 || inf2) : Bool)
                then (do (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                else
                  (do (if ((zero1 || zero2) : Bool)
                      then (do (FPZero (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                      else (do (FPRound (mult_real value1_name value2_name) fpcr (Sail.BitVec.length result)))))))) ) : SailM (BitVec k_N) )
        (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: N : Int -/
def FPProcessDenorms3 (type1 : FPType) (type2 : FPType) (type3 : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && (((BEq.beq type1 FPType_Denormal) || (BEq.beq type2 FPType_Denormal)) || (BEq.beq type3 FPType_Denormal))) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs3__1 (type1 : FPType) (type2 : FPType) (type3 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (op3 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op3) == 16) || (((Sail.BitVec.length op3) == 32) || ((Sail.BitVec.length op3) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16864.41-16864.42"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op3)) ) : SailM (BitVec k_N) )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let op3_nan : Bool := ((BEq.beq type3 FPType_SNaN) || (BEq.beq type3 FPType_QNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let type_nan ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type_nan : FPType :=
    if (altfp : Bool)
    then
      (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) || (BEq.beq type3 FPType_SNaN)) : Bool)
      then FPType_SNaN
      else FPType_QNaN)
    else type_nan
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let (done, result) ← (( do
    (if ((((altfp && op1_nan) && op2_nan) && op3_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPProcessNaN__1 type_nan op2 fpcr fpexc)
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if (((altfp && op2_nan) && (op1_nan || op3_nan)) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPProcessNaN__1 type_nan op2 fpcr fpexc)
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if (((altfp && op3_nan) && op1_nan) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPProcessNaN__1 type_nan op3 fpcr fpexc)
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_SNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                          (pure (done, result)))
                                    else
                                      (do let (done, result) ← (( do
                                            (if ((BEq.beq type3 FPType_SNaN) : Bool)
                                            then
                                              (do let done : Bool := true
                                                  let result ← (FPProcessNaN__1 type3 op3 fpcr fpexc)
                                                  (pure (done, result)))
                                            else
                                              (do let (done, result) ← (( do
                                                    (if ((BEq.beq type1 FPType_QNaN) : Bool)
                                                    then
                                                      (do let done : Bool := true
                                                          let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                                          (pure (done, result)))
                                                    else
                                                      (do let (done, result) ← (( do
                                                            (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                                            then
                                                              (do let done : Bool := true
                                                                  let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                                                  (pure (done, result)))
                                                            else
                                                              (do let (done, result) ← (( do
                                                                    (if ((BEq.beq type3 FPType_QNaN) : Bool)
                                                                    then
                                                                      (do let done : Bool := true
                                                                          let result ← (FPProcessNaN__1 type3 op3 fpcr fpexc)
                                                                          (pure (done, result)))
                                                                    else
                                                                      (do let done : Bool := false
                                                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPMulAdd__1 (addend : (BitVec k_N)) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let infA ← (( do (undefined_bool ()) ) : SailM Bool )
  let infP ← (( do (undefined_bool ()) ) : SailM Bool )
  let invalidop ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signA ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signP ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let typeA ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let valueA_name ← (( do (undefined_real ()) ) : SailM real )
  let zeroA ← (( do (undefined_bool ()) ) : SailM Bool )
  let zeroP ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16945.41-16945.42"
  let (signA, typeA, valueA_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 addend fpcr fpexc)
    let typeA : FPType := tup__0
    let signA : (BitVec 1) := tup__1
    let valueA_name : real := tup__2
    (pure (signA, typeA, valueA_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
  let zero1 : Bool := (BEq.beq type1 FPType_Zero)
  let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
  let zero2 : Bool := (BEq.beq type2 FPType_Zero)
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs3__1 typeA type1 type2 addend op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  let result ← (( do
    (if ((! ((←((HaveAltFP ()) <&&> (do
             (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) : Bool)
    then
      (do (if (((BEq.beq typeA FPType_QNaN) && ((inf1 && zero2) || (zero1 && inf2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else (do (pure result))))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if ((! done) : Bool)
  then
    (do let infA : Bool := (BEq.beq typeA FPType_Infinity)
        let zeroA : Bool := (BEq.beq typeA FPType_Zero)
        let signP : (BitVec 1) := (sign1 ^^^ sign2)
        let infP : Bool := (inf1 || inf2)
        let zeroP : Bool := (zero1 || zero2)
        let invalidop : Bool := (((inf1 && zero2) || (zero1 && inf2)) || ((infA && infP) && (signA != signP)))
        let result ← (( do
          (if (invalidop : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((infA && (signA == 0#1)) || (infP && (signP == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((infA && (signA == 1#1)) || (infP && (signP == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zeroA && zeroP) && (signA == signP)) : Bool)
                            then (do (FPZero signA (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real valueA_name (mult_real value1_name value2_name))
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (((! invalidop) && fpexc) : Bool)
        then (do (FPProcessDenorms3 typeA type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMulAdd (addend : (BitVec k_N)) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPMulAdd__1 addend op1 op2 fpcr fpexc)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPTwo (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17017.38-17017.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec (1 + (E - 1))) := (1#1 +++ (Zeros (n := (E -i 1))))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMulX (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17040.41-17040.42"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && zero2) || (zero1 && inf2)) : Bool)
          then (do (FPTwo (sign1 ^^^ sign2) (Sail.BitVec.length result)))
          else
            (do (if ((inf1 || inf2) : Bool)
                then (do (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                else
                  (do (if ((zero1 || zero2) : Bool)
                      then (do (FPZero (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                      else (do (FPRound (mult_real value1_name value2_name) fpcr (Sail.BitVec.length result)))))))) ) : SailM (BitVec k_N) )
        (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [32, 64] -/
def FPProcessNaNs3H (type1 : FPType) (type2 : FPType) (type3 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec (k_N / 2))) (op3 : (BitVec (k_N / 2))) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op1) == 32) || ((Sail.BitVec.length op1) == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17069.30-17069.31"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op1)) ) : SailM (BitVec k_N) )
  let type_nan ← (( do (undefined_FPType ()) ) : SailM FPType )
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let op3_nan : Bool := ((BEq.beq type3 FPType_SNaN) || (BEq.beq type3 FPType_QNaN))
  let type_nan : FPType :=
    if (altfp : Bool)
    then
      (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) || (BEq.beq type3 FPType_SNaN)) : Bool)
      then FPType_SNaN
      else FPType_QNaN)
    else type_nan
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let (done, result) ← (( do
    (if ((((altfp && op1_nan) && op2_nan) && op3_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPConvertNaN (← (FPProcessNaN__1 type_nan op2 fpcr fpexc)) (Sail.BitVec.length result))
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if (((altfp && op2_nan) && (op1_nan || op3_nan)) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPConvertNaN (← (FPProcessNaN__1 type_nan op2 fpcr fpexc)) (Sail.BitVec.length result))
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if (((altfp && op3_nan) && op1_nan) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPConvertNaN (← (FPProcessNaN__1 type_nan op3 fpcr fpexc)) (Sail.BitVec.length result))
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_SNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPConvertNaN (← (FPProcessNaN__1 type2 op2 fpcr fpexc)) (Sail.BitVec.length result))
                                          (pure (done, result)))
                                    else
                                      (do let (done, result) ← (( do
                                            (if ((BEq.beq type3 FPType_SNaN) : Bool)
                                            then
                                              (do let done : Bool := true
                                                  let result ← (FPConvertNaN (← (FPProcessNaN__1 type3 op3 fpcr fpexc)) (Sail.BitVec.length result))
                                                  (pure (done, result)))
                                            else
                                              (do let (done, result) ← (( do
                                                    (if ((BEq.beq type1 FPType_QNaN) : Bool)
                                                    then
                                                      (do let done : Bool := true
                                                          let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                                          (pure (done, result)))
                                                    else
                                                      (do let (done, result) ← (( do
                                                            (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                                            then
                                                              (do let done : Bool := true
                                                                  let result ← (FPConvertNaN (← (FPProcessNaN__1 type2 op2 fpcr fpexc)) (Sail.BitVec.length result))
                                                                  (pure (done, result)))
                                                            else
                                                              (do let (done, result) ← (( do
                                                                    (if ((BEq.beq type3 FPType_QNaN) : Bool)
                                                                    then
                                                                      (do let done : Bool := true
                                                                          let result ← (FPConvertNaN (← (FPProcessNaN__1 type3 op3 fpcr fpexc)) (Sail.BitVec.length result))
                                                                          (pure (done, result)))
                                                                    else
                                                                      (do let done : Bool := false
                                                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, k_N = 32 -/
def FPMulAddH__1 (addend : (BitVec k_N)) (op1 : (BitVec (k_N / 2))) (op2 : (BitVec (k_N / 2))) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let infA ← (( do (undefined_bool ()) ) : SailM Bool )
  let infP ← (( do (undefined_bool ()) ) : SailM Bool )
  let invalidop ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length addend)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signA ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signP ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let typeA ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let valueA_name ← (( do (undefined_real ()) ) : SailM real )
  let zeroA ← (( do (undefined_bool ()) ) : SailM Bool )
  let zeroP ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert ((Sail.BitVec.length result) == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:17149.19-17149.20"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (signA, typeA, valueA_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 addend fpcr fpexc)
    let typeA : FPType := tup__0
    let signA : (BitVec 1) := tup__1
    let valueA_name : real := tup__2
    (pure (signA, typeA, valueA_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
  let zero1 : Bool := (BEq.beq type1 FPType_Zero)
  let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
  let zero2 : Bool := (BEq.beq type2 FPType_Zero)
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs3H typeA type1 type2 addend op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  let result ← (( do
    (if ((! ((←((HaveAltFP ()) <&&> (do
             (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) : Bool)
    then
      (do (if (((BEq.beq typeA FPType_QNaN) && ((inf1 && zero2) || (zero1 && inf2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else (do (pure result))))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if ((! done) : Bool)
  then
    (do let infA : Bool := (BEq.beq typeA FPType_Infinity)
        let zeroA : Bool := (BEq.beq typeA FPType_Zero)
        let signP : (BitVec 1) := (sign1 ^^^ sign2)
        let infP : Bool := (inf1 || inf2)
        let zeroP : Bool := (zero1 || zero2)
        let invalidop : Bool := (((inf1 && zero2) || (zero1 && inf2)) || ((infA && infP) && (signA != signP)))
        let result ← (( do
          (if (invalidop : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((infA && (signA == 0#1)) || (infP && (signP == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((infA && (signA == 1#1)) || (infP && (signP == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zeroA && zeroP) && (signA == signP)) : Bool)
                            then (do (FPZero signA (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real valueA_name (mult_real value1_name value2_name))
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (((! invalidop) && fpexc) : Bool)
        then (do (FPProcessDenorm typeA (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, k_N = 32 -/
def FPMulAddH (addend : (BitVec k_N)) (op1 : (BitVec (k_N / 2))) (op2 : (BitVec (k_N / 2))) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPMulAddH__1 addend op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPNeg (op : (BitVec k_N)) : SailM (BitVec k_N) := SailME.run do
  let fptype ← (( do (undefined_FPType ()) ) : SailME (BitVec k_N) FPType )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17222.41-17222.42"
  (if ((←((pure (! (← (UsingAArch32 ())))) <&&> (do
       (HaveAltFP ())))) : Bool)
  then
    (do let fpcr ← (( do (FPCR_read ()) ) : SailME (BitVec k_N) FPCRType )
        (if (((_get_FPCRType_AH fpcr) == 1#1) : Bool)
        then
          (do let fptype ← (( do
                let (__tup_0, _, _) ← do (FPUnpack__1 op fpcr false)
                (pure __tup_0) ) : SailME (BitVec k_N) FPType )
              (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
              then (do SailME.throw (op : (BitVec k_N)))
              else (do (pure ()))))
        else (do (pure ()))))
  else (do (pure ())))
  (pure ((Complement.complement ((BitVec.access op ((Sail.BitVec.length op) -i 1)) : BitVec 1)) +++ (Sail.BitVec.extractLsb op ((Sail.BitVec.length op) -i 2) 0)))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPOnePointFive (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17244.38-17244.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec (1 + (E - 1))) := (0#1 +++ (Ones (n := (E -i 1))))
  let frac : (BitVec (1 + (F - 1))) := (1#1 +++ (Zeros (n := (F -i 1))))
  (pure ((sign +++ exp) +++ frac))

def HaveFeatRPRES (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RPRES)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPRecipEstimate (operand : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (BitVec k_N) := do
  let estimate ← (( do (undefined_int ()) ) : SailM Int )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length operand) == 16) || (((Sail.BitVec.length operand) == 32) || ((Sail.BitVec.length operand) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17267.41-17267.42"
  let fpcr : FPCRType := fpcr_in
  let result ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_N) )
  let overflow_to_inf ← (( do (undefined_bool ()) ) : SailM Bool )
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then
      (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 0 0 (Sail.BitVec.extractLsb 0b11#2 1 1))
      (Sail.BitVec.updateSubrange fpcr 24 24 (Sail.BitVec.extractLsb 0b11#2 0 0)))
    else fpcr
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then (Sail.BitVec.updateSubrange fpcr 23 22 0b00#2)
    else fpcr
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 operand fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN__1 fptype operand fpcr fpexc))
  else
    (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
        then (do (FPZero sign (Sail.BitVec.length result)))
        else
          (do (if ((BEq.beq fptype FPType_Zero) : Bool)
              then
                (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                    (if (fpexc : Bool)
                    then (do (FPProcessException FPExc_DivideByZero fpcr))
                    else (do (pure ())))
                    (pure result))
              else
                (do (if ((((((Sail.BitVec.length result) == 16) && (lt_real (abs_real value_name) (real_power (2) (Neg.neg 16)))) || (((Sail.BitVec.length result) == 32) && (lt_real (abs_real value_name) (real_power (2) (Neg.neg 128))))) || (((Sail.BitVec.length result) == 64) && (lt_real (abs_real value_name) (real_power (2) (Neg.neg 1024))))) : Bool)
                    then
                      (do let overflow_to_inf : Bool :=
                            match rounding with
                            | .FPRounding_TIEEVEN => true
                            | .FPRounding_POSINF => (sign == 0#1)
                            | .FPRounding_NEGINF => (sign == 1#1)
                            | .FPRounding_ZERO => false
                            | _ => overflow_to_inf
                          let result ←
                            (if (overflow_to_inf : Bool)
                            then (do (FPInfinity sign (Sail.BitVec.length result)))
                            else (do (FPMaxNormal sign (Sail.BitVec.length result))))
                          (if (fpexc : Bool)
                          then
                            (do (FPProcessException FPExc_Overflow fpcr)
                                (FPProcessException FPExc_Inexact fpcr))
                          else (do (pure ())))
                          (pure result))
                    else
                      (do (if ((((((_get_FPCRType_FZ fpcr) == 1#1) && ((Sail.BitVec.length result) != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && ((Sail.BitVec.length result) == 16))) && (((((Sail.BitVec.length result) == 16) && (gteq_real (abs_real value_name) (real_power (2) 14))) || (((Sail.BitVec.length result) == 32) && (gteq_real (abs_real value_name) (real_power (2) 126)))) || (((Sail.BitVec.length result) == 64) && (gteq_real (abs_real value_name) (real_power (2) 1022))))) : Bool)
                          then
                            (do let result ← (FPZero sign (Sail.BitVec.length result))
                                (if ((← (UsingAArch32 ())) : Bool)
                                then (do (FPSCR_write (_update_FPSCR_Type_UFC (← (FPSCR_read__1 ())) 1#1)))
                                else
                                  (do (if (fpexc : Bool)
                                      then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1))
                                      else (do (pure ())))))
                                (pure result))
                          else
                            (do let fraction ← (( do (undefined_bitvector 52) ) : SailM (BitVec 52) )
                                let exp ← (( do (undefined_int ()) ) : SailM Int )
                                let (exp, fraction) : (Int × (BitVec 52)) :=
                                  match (Sail.BitVec.length result) with
                                  | 16 =>
                                    (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb operand 9 0) +++ (Zeros (n := 42)))
                                    let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 14 10))
                                    (exp, fraction))
                                  | 32 =>
                                    (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb operand 22 0) +++ (Zeros (n := 29)))
                                    let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 30 23))
                                    (exp, fraction))
                                  | 64 =>
                                    (let fraction : (BitVec 52) := (Sail.BitVec.extractLsb operand 51 0)
                                    let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 62 52))
                                    (exp, fraction))
                                  | _ => (exp, fraction)
                                let (exp, fraction) : (Int × (BitVec 52)) :=
                                  if ((exp == 0) : Bool)
                                  then
                                    (let (exp, fraction) : (Int × (BitVec 52)) :=
                                      if ((((BitVec.access fraction 51) : BitVec 1) == 0#1) : Bool)
                                      then
                                        (let exp : Int := (Neg.neg 1)
                                        let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb fraction 49 0) +++ 0b00#2)
                                        (exp, fraction))
                                      else
                                        (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb fraction 50 0) +++ 0#1)
                                        (exp, fraction))
                                    (exp, fraction))
                                  else (exp, fraction)
                                let exp := exp
                                let scaled ← (( do (undefined_range 0 4095) ) : SailM Nat )
                                let increasedprecision_name ← (( do (pure ((←((pure ((Sail.BitVec.length result) == 32)) <&&> (do (HaveFeatRPRES ())))) && altfp)) ) : SailM Bool )
                                let scaled : Nat :=
                                  if ((! increasedprecision_name) : Bool)
                                  then (BitVec.toNat (1#1 +++ (Sail.BitVec.extractLsb fraction 51 44)))
                                  else (BitVec.toNat (1#1 +++ (Sail.BitVec.extractLsb fraction 51 41)))
                                let scaled := scaled
                                let result_exp ← (( do (undefined_int ()) ) : SailM Int )
                                let result_exp : Int :=
                                  match (Sail.BitVec.length result) with
                                  | 16 => (29 -i exp)
                                  | 32 => (253 -i exp)
                                  | 64 => (2045 -i exp)
                                  | _ => result_exp
                                let estimate ← (( do (RecipEstimate scaled increasedprecision_name) ) : SailM Int )
                                let fraction : (BitVec 52) :=
                                  if ((! increasedprecision_name) : Bool)
                                  then ((integer_subrange estimate 7 0) +++ (Zeros (n := 44)))
                                  else ((integer_subrange estimate 11 0) +++ (Zeros (n := 40)))
                                let (fraction, result_exp) : ((BitVec 52) × Int) :=
                                  if ((result_exp == 0) : Bool)
                                  then
                                    (let fraction : (BitVec 52) := (1#1 +++ (Sail.BitVec.extractLsb fraction 51 1))
                                    (fraction, result_exp))
                                  else
                                    (let (fraction, result_exp) : ((BitVec 52) × Int) :=
                                      if ((result_exp == (Neg.neg 1)) : Bool)
                                      then
                                        (let fraction : (BitVec 52) := (0b01#2 +++ (Sail.BitVec.extractLsb fraction 51 2))
                                        let result_exp : Int := 0
                                        (fraction, result_exp))
                                      else (fraction, result_exp)
                                    (fraction, result_exp))
                                let result_exp := result_exp
                                match (Sail.BitVec.length result) with
                                | 16 => (pure ((sign +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 12) 0)) +++ (Sail.BitVec.extractLsb fraction 51 42)))
                                | 32 => (pure ((sign +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 25) 0)) +++ (Sail.BitVec.extractLsb fraction 51 29)))
                                | 64 => (pure ((sign +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 54) 0)) +++ (Sail.BitVec.extractLsb fraction 51 0)))
                                | _ => (pure result)))))))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPRecpX (op : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (BitVec k_N) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17407.41-17407.42"
  let fpcr : FPCRType := fpcr_in
  let esize : Int := 5
  let esize : Int :=
    match (Sail.BitVec.length op) with
    | 16 => 5
    | 32 => 8
    | 64 => 11
    | _ => esize
  let esize := esize
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  let exp ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let frac : (BitVec (k_N - (esize + 1))) := (Zeros (n := ((Sail.BitVec.length result) -i (esize +i 1))))
  let altfp ← (( do (pure ((← (HaveAltFP ())) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then
      (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 0 0 (Sail.BitVec.extractLsb 0b11#2 1 1))
      (Sail.BitVec.updateSubrange fpcr 24 24 (Sail.BitVec.extractLsb 0b11#2 0 0)))
    else fpcr
  let (fptype, sign) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign)) ) : SailM (FPType × (BitVec 1)) )
  let exp ← (( do
    match (Sail.BitVec.length result) with
    | 16 =>
      (do
        sail_assert ((10 ≤b ((10 +i esize) -i 1)) && (((10 +i esize) -i 1) <b (Sail.BitVec.length result))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17434.75-17434.76"
        (pure (Sail.BitVec.extractLsb op ((10 +i esize) -i 1) 10)))
    | 32 =>
      (do
        sail_assert ((23 ≤b ((23 +i esize) -i 1)) && (((23 +i esize) -i 1) <b (Sail.BitVec.length result))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17438.75-17438.76"
        (pure (Sail.BitVec.extractLsb op ((23 +i esize) -i 1) 23)))
    | 64 => (pure (Sail.BitVec.extractLsb op ((52 +i esize) -i 1) 52))
    | _ => (pure exp) ) : SailM (BitVec esize) )
  let max_exp : (BitVec esize) := (BitVec.subInt (Ones (n := esize)) 1)
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN__1 fptype op fpcr fpexc))
  else
    (do (if ((IsZero exp) : Bool)
        then (do (pure ((sign +++ max_exp) +++ frac)))
        else (do (pure ((sign +++ (Complement.complement exp)) +++ frac))))))

/-- Type quantifiers: k_N : Nat, k_exact : Bool, List.elem k_N [16, 32, 64] -/
def FPRoundInt (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (exact : Bool) : SailM (BitVec k_N) := do
  let error ← (( do (undefined_real ()) ) : SailM real )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let int_result ← (( do (undefined_int ()) ) : SailM Int )
  let real_result ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17470.37-17470.38"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17471.41-17471.42"
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN fptype op fpcr))
  else
    (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
        then (do (FPInfinity sign (Sail.BitVec.length result)))
        else
          (do (if ((BEq.beq fptype FPType_Zero) : Bool)
              then (do (FPZero sign (Sail.BitVec.length result)))
              else
                (do let int_result : Int := (round_down value_name)
                    let error : real := (sub_real value_name (to_real int_result))
                    let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
                    let round_up : Bool :=
                      match rounding with
                      | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
                      | .FPRounding_POSINF => (bne error (0))
                      | .FPRounding_NEGINF => false
                      | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
                      | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
                      | _ => round_up
                    let int_result : Int :=
                      if (round_up : Bool)
                      then (int_result +i 1)
                      else int_result
                    let int_result := int_result
                    let real_result : real := (to_real int_result)
                    let result ← (( do
                      (if ((eq_real real_result (0)) : Bool)
                      then (do (FPZero sign (Sail.BitVec.length result)))
                      else (do (FPRound__1 real_result fpcr FPRounding_ZERO (Sail.BitVec.length result)))) ) : SailM (BitVec k_N) )
                    (if (((bne error (0)) && exact) : Bool)
                    then (do (FPProcessException FPExc_Inexact fpcr))
                    else (do (pure ())))
                    (pure result)))))))

/-- Type quantifiers: k_N : Nat, intsize : Int, List.elem k_N [32, 64] -/
def FPRoundIntN (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (intsize : Int) : SailM (BitVec k_N) := do
  let error ← (( do (undefined_real ()) ) : SailM real )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let int_result ← (( do (undefined_int ()) ) : SailM Int )
  let overflow ← (( do (undefined_bool ()) ) : SailM Bool )
  let real_result ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17533.37-17533.38"
  sail_assert (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17534.30-17534.31"
  sail_assert ((intsize == 32) || (intsize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17535.40-17535.41"
  let exp ← (( do (undefined_int ()) ) : SailM Int )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let E :=
    if (((Sail.BitVec.length result) == 32) : Bool)
    then 8
    else 11
  let F := ((Sail.BitVec.length result) -i (E +i 1))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (if (((BEq.beq fptype FPType_SNaN) || ((BEq.beq fptype FPType_QNaN) || (BEq.beq fptype FPType_Infinity))) : Bool)
  then
    (do let result : (BitVec k_N) :=
          if (((Sail.BitVec.length result) == 32) : Bool)
          then
            (let exp := (126 +i intsize)
            ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
          else
            (let exp := (1022 +i intsize)
            ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
        (FPProcessException FPExc_InvalidOp fpcr)
        (pure result))
  else
    (do (if ((BEq.beq fptype FPType_Zero) : Bool)
        then (do (FPZero sign (Sail.BitVec.length result)))
        else
          (do let int_result : Int := (round_down value_name)
              let error : real := (sub_real value_name (to_real int_result))
              let round_up : Bool :=
                match rounding with
                | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
                | .FPRounding_POSINF => (bne error (0))
                | .FPRounding_NEGINF => false
                | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
                | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
                | _ => round_up
              let int_result : Int :=
                if (round_up : Bool)
                then (int_result +i 1)
                else int_result
              let int_result := int_result
              let overflow : Bool := ((int_result >b ((2 ^i (intsize -i 1)) -i 1)) || (int_result <b ((Neg.neg 1) *i (2 ^i (intsize -i 1)))))
              let (error, result) ← (( do
                (if (overflow : Bool)
                then
                  (do let result : (BitVec k_N) :=
                        if (((Sail.BitVec.length result) == 32) : Bool)
                        then
                          (let exp := (126 +i intsize)
                          ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
                        else
                          (let exp := (1022 +i intsize)
                          ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
                      (FPProcessException FPExc_InvalidOp fpcr)
                      let error : real := (0)
                      (pure (error, result)))
                else
                  (do let real_result : real := (to_real int_result)
                      let result ← (( do
                        (if ((eq_real real_result (0)) : Bool)
                        then (do (FPZero sign (Sail.BitVec.length result)))
                        else (do (FPRound__1 real_result fpcr FPRounding_ZERO (Sail.BitVec.length result)))) ) : SailM (BitVec k_N) )
                      (pure (error, result)))) ) : SailM (real × (BitVec k_N)) )
              (if ((bne error (0)) : Bool)
              then (do (FPProcessException FPExc_Inexact fpcr))
              else (do (pure ())))
              (pure result)))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPRSqrtEstimate (operand : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (BitVec k_N) := do
  let estimate ← (( do (undefined_int ()) ) : SailM Int )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length operand) == 16) || (((Sail.BitVec.length operand) == 32) || ((Sail.BitVec.length operand) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17615.41-17615.42"
  let fpcr : FPCRType := fpcr_in
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then
      (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 0 0 (Sail.BitVec.extractLsb 0b11#2 1 1))
      (Sail.BitVec.updateSubrange fpcr 24 24 (Sail.BitVec.extractLsb 0b11#2 0 0)))
    else fpcr
  let (fptype, sign) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 operand fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign)) ) : SailM (FPType × (BitVec 1)) )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_N) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN__1 fptype operand fpcr fpexc))
  else
    (do (if ((BEq.beq fptype FPType_Zero) : Bool)
        then
          (do let result ← (FPInfinity sign (Sail.BitVec.length result))
              (if (fpexc : Bool)
              then (do (FPProcessException FPExc_DivideByZero fpcr))
              else (do (pure ())))
              (pure result))
        else
          (do (if ((sign == 1#1) : Bool)
              then
                (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                    (if (fpexc : Bool)
                    then (do (FPProcessException FPExc_InvalidOp fpcr))
                    else (do (pure ())))
                    (pure result))
              else
                (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
                    then (do (FPZero 0#1 (Sail.BitVec.length result)))
                    else
                      (do let fraction ← (( do (undefined_bitvector 52) ) : SailM (BitVec 52) )
                          let exp ← (( do (undefined_int ()) ) : SailM Int )
                          let (exp, fraction) : (Int × (BitVec 52)) :=
                            match (Sail.BitVec.length result) with
                            | 16 =>
                              (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb operand 9 0) +++ (Zeros (n := 42)))
                              let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 14 10))
                              (exp, fraction))
                            | 32 =>
                              (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb operand 22 0) +++ (Zeros (n := 29)))
                              let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 30 23))
                              (exp, fraction))
                            | 64 =>
                              (let fraction : (BitVec 52) := (Sail.BitVec.extractLsb operand 51 0)
                              let exp : Int := (BitVec.toNat (Sail.BitVec.extractLsb operand 62 52))
                              (exp, fraction))
                            | _ => (exp, fraction)
                          let (exp, fraction) ← (( do
                            (if ((exp == 0) : Bool)
                            then
                              (do let (exp, fraction) ← (( do
                                    let mut loop_vars := (exp, fraction)
                                    while (λ (exp, fraction) => (((BitVec.access fraction 51) : BitVec 1) == 0#1)) loop_vars do
                                      let (exp, fraction) := loop_vars
                                      loop_vars :=
                                        (let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb fraction 50 0) +++ 0#1)
                                        let exp : Int := (exp -i 1)
                                        (exp, fraction) : (Int × (BitVec 52)))
                                    (pure loop_vars) ) : SailM (Int × (BitVec 52)) )
                                  let fraction : (BitVec 52) := ((Sail.BitVec.extractLsb fraction 50 0) +++ 0#1)
                                  (pure (exp, fraction)))
                            else (do (pure (exp, fraction)))) ) : SailM (Int × (BitVec 52)) )
                          let fraction := fraction
                          let exp := exp
                          let scaled ← (( do (undefined_range 0 4095) ) : SailM Nat )
                          let increasedprecision_name ← (( do (pure ((←((pure ((Sail.BitVec.length result) == 32)) <&&> (do (HaveFeatRPRES ())))) && altfp)) ) : SailM Bool )
                          let scaled : Nat :=
                            if ((! increasedprecision_name) : Bool)
                            then
                              (if ((((integer_access exp 0) : BitVec 1) == 0#1) : Bool)
                              then (BitVec.toNat (1#1 +++ (Sail.BitVec.extractLsb fraction 51 44)))
                              else (BitVec.toNat (0b01#2 +++ (Sail.BitVec.extractLsb fraction 51 45))))
                            else
                              (if ((((integer_access exp 0) : BitVec 1) == 0#1) : Bool)
                              then (BitVec.toNat (1#1 +++ (Sail.BitVec.extractLsb fraction 51 41)))
                              else (BitVec.toNat (0b01#2 +++ (Sail.BitVec.extractLsb fraction 51 42))))
                          let scaled := scaled
                          let result_exp ← (( do (undefined_int ()) ) : SailM Int )
                          let result_exp : Int :=
                            match (Sail.BitVec.length result) with
                            | 16 => (fdiv_int (44 -i exp) 2)
                            | 32 => (fdiv_int (380 -i exp) 2)
                            | 64 => (fdiv_int (3068 -i exp) 2)
                            | _ => result_exp
                          let result_exp := result_exp
                          let estimate ← (( do (RecipSqrtEstimate scaled increasedprecision_name) ) : SailM Int )
                          match (Sail.BitVec.length result) with
                          | 16 => (pure (((0#1 +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 12) 0)) +++ (integer_subrange estimate 7 0)) +++ (Zeros (n := 2))))
                          | 32 =>
                            ((if ((! increasedprecision_name) : Bool)
                            then (do (pure (((0#1 +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 25) 0)) +++ (integer_subrange estimate 7 0)) +++ (Zeros (n := 15)))))
                            else (do (pure (((0#1 +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 25) 0)) +++ (integer_subrange estimate 11 0)) +++ (Zeros (n := 11)))))))
                          | 64 => (pure (((0#1 +++ (integer_subrange result_exp ((Sail.BitVec.length result) -i 54) 0)) +++ (integer_subrange estimate 7 0)) +++ (Zeros (n := 44))))
                          | _ => (pure result)))))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPSqrt (op : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17724.41-17724.42"
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op fpcr)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN fptype op fpcr))
  else
    (do (if ((BEq.beq fptype FPType_Zero) : Bool)
        then (do (FPZero sign (Sail.BitVec.length result)))
        else
          (do (if (((BEq.beq fptype FPType_Infinity) && (sign == 0#1)) : Bool)
              then (do (FPInfinity sign (Sail.BitVec.length result)))
              else
                (do (if ((sign == 1#1) : Bool)
                    then
                      (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                          (FPProcessException FPExc_InvalidOp fpcr)
                          (pure result))
                    else
                      (do let result ← (FPRound (sqrt_real value_name) fpcr (Sail.BitVec.length result))
                          (FPProcessDenorm fptype (Sail.BitVec.length result) fpcr)
                          (pure result)))))))))


end ArmASL.Functions
