import ArmASL.Part05

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def FirstBranchAfterProhibited (_ : Unit) : SailM Bool := do
  (pure (! (← readReg __last_branch_valid)))

def BranchEncCycleCount (_ : Unit) : SailM ((BitVec 1) × (BitVec 14)) := do
  let cc ← (( do (BranchRawCycleCount ()) ) : SailM Int )
  (if ((←((pure (! (← (BRBCycleCountingEnabled ())))) <||> (do
       (FirstBranchAfterProhibited ())))) : Bool)
  then (do (pure (1#1, (Zeros (n := 14)))))
  else
    (do let E ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
        let M ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
        let (E, M) ← (( do
          (if ((cc <b (2 ^i 8)) : Bool)
          then
            (do let E : (BitVec 6) := (Zeros (n := 6))
                let M : (BitVec 8) := (integer_subrange cc 7 0)
                (pure (E, M)))
          else
            (do let (E, M) ← (( do
                  (if ((cc ≥b (2 ^i 20)) : Bool)
                  then
                    (do let E : (BitVec 6) := (Ones (n := 6))
                        let M : (BitVec 8) := (Ones (n := 8))
                        (pure (E, M)))
                  else
                    (do let E : (BitVec 6) := (integer_subrange 1 5 0)
                        let (E, cc) ← (( do
                          let mut loop_vars := (E, cc)
                          while (λ (E, cc) => (cc ≥b (2 ^i 9))) loop_vars do
                            let (E, cc) := loop_vars
                            loop_vars :=
                              (let E : (BitVec 6) := (BitVec.addInt E 1)
                              let cc : Int := (fdiv_int cc 2)
                              (E, cc) : ((BitVec 6) × Int))
                          (pure loop_vars) ) : SailM ((BitVec 6) × Int) )
                        let cc := cc
                        let M : (BitVec 8) := (integer_subrange cc 7 0)
                        (pure (E, M)))) ) : SailM ((BitVec 6) × (BitVec 8)) )
                (pure (E, M)))) ) : SailM ((BitVec 6) × (BitVec 8)) )
        (pure (0#1, (E +++ M)))))

def BranchMispredict (_ : Unit) : Bool :=
  false

/-- Type quantifiers: k_cond : Bool -/
def FilterBranchRecord (br : BranchType) (cond : Bool) : SailM Bool := SailME.run do
  match br with
  | .BranchType_DIRCALL => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_DIRCALL (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_INDCALL => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_INDCALL (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_RET => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_RTN (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_DIR =>
    SailME.throw (← do
        (if (cond : Bool)
        then (do (pure ((_get_BRBFCR_EL1_Type_CONDDIR (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
        else (do (pure ((_get_BRBFCR_EL1_Type_DIRECT (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))))
  | .BranchType_INDIR => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_INDIRECT (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | _ => (Unreachable ())
  (pure false)

def HaveTME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TME)

def CurrentInstrSet (_ : Unit) : SailM InstrSet := do
  let result ← (( do (undefined_InstrSet ()) ) : SailM InstrSet )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do (if (((← readReg PSTATE).T == 0#1) : Bool)
        then (do (pure InstrSet_A32))
        else (do (pure InstrSet_T32))))
  else (do (pure InstrSet_A64)))

def BadMode (mode : (BitVec 5)) : SailM Bool := do
  let valid_name ← (( do (undefined_bool ()) ) : SailM Bool )
  let valid_name : Bool :=
    let questionMark := mode
    if ((questionMark == M32_Monitor) : Bool)
    then (HaveAArch32EL EL3)
    else
      (if ((questionMark == M32_Hyp) : Bool)
      then (HaveAArch32EL EL2)
      else
        (if ((questionMark == M32_FIQ) : Bool)
        then (HaveAArch32EL EL1)
        else
          (if ((questionMark == M32_IRQ) : Bool)
          then (HaveAArch32EL EL1)
          else
            (if ((questionMark == M32_Svc) : Bool)
            then (HaveAArch32EL EL1)
            else
              (if ((questionMark == M32_Abort) : Bool)
              then (HaveAArch32EL EL1)
              else
                (if ((questionMark == M32_Undef) : Bool)
                then (HaveAArch32EL EL1)
                else
                  (if ((questionMark == M32_System) : Bool)
                  then (HaveAArch32EL EL1)
                  else
                    (if ((questionMark == M32_User) : Bool)
                    then (HaveAArch32EL EL0)
                    else false))))))))
  let valid_name := valid_name
  (pure (! valid_name))

/-- Type quantifiers: usr : Int, fiq : Int, irq : Int, svc : Int, abt : Int, und : Int, hyp : Int -/
def RBankSelect (mode : (BitVec 5)) (usr : Int) (fiq : Int) (irq : Int) (svc : Int) (abt : Int) (und : Int) (hyp : Int) : SailM Int := do
  let questionMark := mode
  (if ((questionMark == M32_User) : Bool)
  then (do (pure usr))
  else
    (do (if ((questionMark == M32_FIQ) : Bool)
        then (do (pure fiq))
        else
          (do (if ((questionMark == M32_IRQ) : Bool)
              then (do (pure irq))
              else
                (do (if ((questionMark == M32_Svc) : Bool)
                    then (do (pure svc))
                    else
                      (do (if ((questionMark == M32_Abort) : Bool)
                          then (do (pure abt))
                          else
                            (do (if ((questionMark == M32_Hyp) : Bool)
                                then (do (pure hyp))
                                else
                                  (do (if ((questionMark == M32_Undef) : Bool)
                                      then (do (pure und))
                                      else
                                        (do (if ((questionMark == M32_System) : Bool)
                                            then (do (pure usr))
                                            else
                                              (do sail_assert false "Pattern match failure at sail-arm/arm-v9.4-a/src/v8_base.sail:6328.4-6337.5"
                                                  throw Error.Exit))))))))))))))))

/-- Type quantifiers: n : Nat, n ≥ 0 ∧ n ≤ 15 -/
def LookUpRIndex (n : Nat) (mode : (BitVec 5)) : SailM Int := do
  sail_assert ((n ≥b 0) && (n ≤b 14)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6344.27-6344.28"
  match n with
  | 8 => (RBankSelect mode 8 24 8 8 8 8 8)
  | 9 => (RBankSelect mode 9 25 9 9 9 9 9)
  | 10 => (RBankSelect mode 10 26 10 10 10 10 10)
  | 11 => (RBankSelect mode 11 27 11 11 11 11 11)
  | 12 => (RBankSelect mode 12 28 12 12 12 12 12)
  | 13 => (RBankSelect mode 13 29 17 19 21 23 15)
  | 14 => (RBankSelect mode 14 30 16 18 20 22 14)
  | _ => (pure n)

def PC_read (_ : Unit) : SailM (BitVec 64) := do
  readReg _PC

def undefined_BRBIDR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_BRBIDR0_EL1_Type_NUMREC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def GetBRBENumRecords (_ : Unit) : SailM Int := do
  sail_assert (←((pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x08#8))) <||> (do
    (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x10#8))) <||> (do
      (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x20#8))) <||> (do
        (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x40#8)))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6426.176-6426.177"
  (__IMPDEF_integer "Number of BRB records")

def UpdateBranchRecordBuffer (ccu : (BitVec 1)) (cc : (BitVec 14)) (lastfailed : (BitVec 1)) (transactional : (BitVec 1)) (branch_type : (BitVec 6)) (el : (BitVec 2)) (mispredict : (BitVec 1)) (valid_name : (BitVec 2)) (source_address : (BitVec 64)) (target_address : (BitVec 64)) : SailM Unit := do
  let loop_i_lower := 1
  let loop_i_upper ← (( do (pure ((← (GetBRBENumRecords ())) -i 1)) ) : SailM Int )
  let mut loop_vars := ()
  for i in [loop_i_upper:loop_i_lower:-1]i do
    let () := loop_vars
    loop_vars ← do
      sail_assert (i <b 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:6440.39-6440.40"
      writeReg Records_SRC (vectorUpdate (← readReg Records_SRC) i (GetElem?.getElem! (← readReg Records_SRC) (i -i 1)))
      writeReg Records_TGT (vectorUpdate (← readReg Records_TGT) i (GetElem?.getElem! (← readReg Records_TGT) (i -i 1)))
      writeReg Records_INF (vectorUpdate (← readReg Records_INF) i (GetElem?.getElem! (← readReg Records_INF) (i -i 1)))
  (pure loop_vars)
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 46 46 ccu))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 45 32 cc))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 7 6 el))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 1 0 valid_name))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 16 16 transactional))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 17 17 lastfailed))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 5 5 mispredict))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 13 8 branch_type))
  writeReg Records_SRC (vectorUpdate (← readReg Records_SRC) 0 (Mk_BRBSRCType source_address))
  writeReg Records_TGT (vectorUpdate (← readReg Records_TGT) 0 (Mk_BRBTGTType target_address))

/-- Type quantifiers: k_cond : Bool -/
def BRBEBranch (br_type : BranchType) (cond : Bool) (target_address : (BitVec 64)) : SailM Unit := do
  let branch_valid ← (( do (BranchRecordAllowed (← readReg PSTATE).EL) ) : SailM Bool )
  (if ((←((pure branch_valid) <&&> (do
       (FilterBranchRecord br_type cond)))) : Bool)
  then
    (do let branch_type ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
        let branch_type ← (( do
          match br_type with
          | .BranchType_DIR =>
            ((if (cond : Bool)
            then (do (pure 0b001000#6))
            else (do (pure 0b000000#6))))
          | .BranchType_INDIR => (pure 0b000001#6)
          | .BranchType_DIRCALL => (pure 0b000010#6)
          | .BranchType_INDCALL => (pure 0b000011#6)
          | .BranchType_RET => (pure 0b000101#6)
          | _ =>
            (do
              (Unreachable ())
              (pure branch_type)) ) : SailM (BitVec 6) )
        let ccu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let cc ← (( do (undefined_bitvector 14) ) : SailM (BitVec 14) )
        let (cc, ccu) ← (( do
          let (tup__0, tup__1) ← do (BranchEncCycleCount ())
          let ccu : (BitVec 1) := tup__0
          let cc : (BitVec 14) := tup__1
          (pure (cc, ccu)) ) : SailM ((BitVec 14) × (BitVec 1)) )
        let lastfailed ← (( do
          (if ((← (HaveTME ())) : Bool)
          then (do (pure (_get_BRBFCR_EL1_Type_LASTFAILED (← readReg BRBFCR_EL1))))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        let transactional ← (( do
          (if ((←((HaveTME ()) <&&> (do
               (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        let el ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
        let mispredict ← (( do
          (if (((← (BRBEMispredictAllowed ())) && (BranchMispredict ())) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        (UpdateBranchRecordBuffer ccu cc lastfailed transactional branch_type el mispredict 0b11#2 (← (PC_read ())) target_address)
        writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 0#1)
        (PMUEvent PMU_EVENT_BRB_FILTRATE))
  else (do (pure ())))
  writeReg __last_branch_valid branch_valid

def HaveBRBExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BRBE)

def HaveStatisticalProfiling (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPE)

def undefined_PMSIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_PMSIDR_EL1_Type_PBT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def undefined_PMSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_HTRFCR_Type_CX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_PMSCR_EL1_Type_E0SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSCR_EL1_Type_E1SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_PMSCR_EL1_Type_PA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_PMSCR_EL2_Type_PA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def undefined_PMSCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSCR_EL2_Type_E0HSPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSCR_EL2_Type_E2SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_PMBLIMITR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBLIMITR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMBSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTCR_EL2_Type_AssuredOnly (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_PMBSR_EL1_Type_S (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def ProfilingBufferOwner (_ : Unit) : SailM (SecurityState × (BitVec 2)) := do
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  let owning_ss ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do let state_bits ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
          let state_bits ← (( do
            (if ((← (HaveRME ())) : Bool)
            then
              (do let state_bits ← (pure ((_get_MDCR_EL3_Type_NSPBE (← readReg MDCR_EL3)) +++ (_get_MDCR_EL3_Type_NSPB (← readReg MDCR_EL3))))
                  (if ((←((pure (let b__0 := state_bits
                       if (((Sail.BitVec.extractLsb b__0 2 1) == (0b10#2 : (BitVec 2))) : Bool)
                       then true
                       else false : Bool)) <||> (do
                       (pure ((! (← (HaveSecureEL2Ext ()))) && (let b__1 := state_bits
                           if (((Sail.BitVec.extractLsb b__1 2 1) == (0b00#2 : (BitVec 2))) : Bool)
                           then true
                           else false : Bool)))))) : Bool)
                  then
                    (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESERVEDNSxB 3)
                        (pure __tup_1))
                  else (do (pure state_bits))))
            else (do (pure (0#1 +++ (_get_MDCR_EL3_Type_NSPB (← readReg MDCR_EL3)))))) ) : SailM (BitVec 3) )
          let b__2 := state_bits
          (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b00#2 : (BitVec 2))) : Bool)
          then (do (pure SS_Secure))
          else
            (do (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure SS_NonSecure))
                else
                  (do (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b11#2 : (BitVec 2))) : Bool)
                      then (do (pure SS_Realm))
                      else (do (pure owning_ss))))))))
    else
      (do (if ((← (SecureOnlyImplementation ())) : Bool)
          then (do (pure SS_Secure))
          else (do (pure SS_NonSecure))))) ) : SailM SecurityState )
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_el ← (( do
    (if ((←((pure (HaveEL EL2)) <&&> (do
         (pure (bne owning_ss SS_Secure)) <||> (do
           (IsSecureEL2Enabled ()))))) : Bool)
    then
      (do (if (((_get_MDCR_EL2_Type_E2PB (← readReg MDCR_EL2)) == 0b00#2) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  (pure (owning_ss, owning_el))

def ProfilingBufferEnabled (_ : Unit) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
  then (do (pure false))
  else
    (do let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        let state_bits ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
        let state_bits ← (( do
          (if ((← (HaveRME ())) : Bool)
          then (do (pure ((_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)) +++ (← (EffectiveSCR_EL3_NS ())))))
          else (do (pure (0#1 +++ (_get_SCR_EL3_Type_NS (← readReg SCR_EL3)))))) ) : SailM (BitVec 2) )
        let state_match ← (( do (undefined_bool ()) ) : SailM Bool )
        let state_match : Bool :=
          match owning_ss with
          | .SS_Secure => (state_bits == 0b00#2)
          | .SS_NonSecure => (state_bits == 0b01#2)
          | .SS_Realm => (state_bits == 0b11#2)
          | _ => state_match
        (pure ((! (← (ELUsingAArch32 owning_el))) && state_match)) <&&> (do
          (pure ((_get_PMBLIMITR_EL1_Type_E (← readReg PMBLIMITR_EL1)) == 1#1))) <&&> (do
          (pure ((_get_PMBSR_EL1_Type_S (← readReg PMBSR_EL1)) == 0#1)))))

def StatisticalProfilingEnabled__1 (el : (BitVec 2)) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((←((pure (! (← (HaveStatisticalProfiling ())))) <||> (do
       (UsingAArch32 ())) <||> (do
       (pure (! (← (ProfilingBufferEnabled ()))))))) : Bool)
  then (do (pure false))
  else
    (do let tge_set ← (( do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
        let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        (if ((←((pure (((BitVec.toNat owning_el) <b (BitVec.toNat el)) || (tge_set && (owning_el == EL1)))) <||> (do
             (pure (bne owning_ss (← (SecurityStateAtEL el))))))) : Bool)
        then (do (pure false))
        else
          (do let spe_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
              let spe_bit ← (( do
                let questionMark := el
                (if ((questionMark == EL3) : Bool)
                then
                  (do (Unreachable ())
                      (pure spe_bit))
                else
                  (do (if ((questionMark == EL2) : Bool)
                      then (do (pure (_get_PMSCR_EL2_Type_E2SPE (← readReg PMSCR_EL2))))
                      else
                        (do (if ((questionMark == EL1) : Bool)
                            then (do (pure (_get_PMSCR_EL1_Type_E1SPE (← readReg PMSCR_EL1))))
                            else
                              (do (if ((questionMark == EL0) : Bool)
                                  then
                                    (do (if (tge_set : Bool)
                                        then (do (pure (_get_PMSCR_EL2_Type_E0HSPE (← readReg PMSCR_EL2))))
                                        else (do (pure (_get_PMSCR_EL1_Type_E0SPE (← readReg PMSCR_EL1))))))
                                  else (do (pure spe_bit))))))))) ) : SailM (BitVec 1) )
              (pure (spe_bit == 1#1))))))

def StatisticalProfilingEnabled (_ : Unit) : SailM Bool := do
  (StatisticalProfilingEnabled__1 (← readReg PSTATE).EL)

/-- Type quantifiers: k_N : Nat, k_conditional : Bool, k_is_isb : Bool, k_taken_flag : Bool, k_N ≥ 0 -/
def SPEBranch__1 (target : (BitVec k_N)) (branch_type : BranchType) (conditional : Bool) (taken_flag : Bool) (is_isb : Bool) : SailM Unit := do
  let is_direct ← (( do (undefined_bool ()) ) : SailM Bool )
  let collect_prev_br ← (( do (undefined_bool ()) ) : SailM Bool )
  let collect_prev_br_eret ← (( do (__IMPDEF_boolean "SPE prev br on eret") ) : SailM Bool )
  let collect_prev_br_exception ← (( do (__IMPDEF_boolean "SPE prev br on exception") ) : SailM Bool )
  let collect_prev_br_isb ← (( do (__IMPDEF_boolean "SPE prev br on isb") ) : SailM Bool )
  let collect_prev_br : Bool :=
    match branch_type with
    | .BranchType_EXCEPTION => collect_prev_br_exception
    | .BranchType_ERET => collect_prev_br_eret
    | _ => ((! is_isb) || collect_prev_br_isb)
  let collect_prev_br := collect_prev_br
  (if (((←((pure taken_flag) <&&> (do
         (pure (! (IsZero (_get_PMSIDR_EL1_Type_PBT (← readReg PMSIDR_EL1)))))) <&&> (do
         (StatisticalProfilingEnabled ())))) && collect_prev_br) : Bool)
  then
    (do (if ((← readReg SPESampleInFlight) : Bool)
        then
          (do let previous_target ← (( do readReg SPESamplePreviousBranchAddress ) : SailM (BitVec 64) )
              writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosPrevBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosPrevBranchTarget) 63 0 (Sail.BitVec.extractLsb previous_target 63 0)))
              let previous_branch_valid ← (( do readReg SPESamplePreviousBranchAddressValid ) : SailM Bool )
              writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosPrevBranchTarget previous_branch_valid))
        else (do (pure ())))
        sail_assert (55 <b (Sail.BitVec.length target)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6728.34-6728.35"
        writeReg SPESamplePreviousBranchAddress (Sail.BitVec.updateSubrange (← readReg SPESamplePreviousBranchAddress) 55 0 (Sail.BitVec.extractLsb target 55 0))
        let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let (ns, nse) ← (( do
          match (← (CurrentSecurityState ())) with
          | .SS_Secure =>
            (let ns : (BitVec 1) := 0#1
            let nse : (BitVec 1) := 0#1
            (pure (ns, nse)))
          | .SS_NonSecure =>
            (let ns : (BitVec 1) := 1#1
            let nse : (BitVec 1) := 0#1
            (pure (ns, nse)))
          | .SS_Realm =>
            (let ns : (BitVec 1) := 1#1
            let nse : (BitVec 1) := 1#1
            (pure (ns, nse)))
          | _ =>
            (do
              (Unreachable ())
              (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
        writeReg SPESamplePreviousBranchAddress (BitVec.update (← readReg SPESamplePreviousBranchAddress) 63 (Bit ns))
        writeReg SPESamplePreviousBranchAddress (BitVec.update (← readReg SPESamplePreviousBranchAddress) 60 (Bit nse))
        writeReg SPESamplePreviousBranchAddress (Sail.BitVec.updateSubrange (← readReg SPESamplePreviousBranchAddress) 62 61 (← readReg PSTATE).EL)
        writeReg SPESamplePreviousBranchAddressValid true)
  else (do (pure ())))
  (if ((! (← (StatisticalProfilingEnabled ()))) : Bool)
  then
    (do (if (taken_flag : Bool)
        then (do writeReg SPESamplePreviousBranchAddressValid false)
        else (do (pure ()))))
  else
    (do (if ((← readReg SPESampleInFlight) : Bool)
        then
          (do let is_direct : Bool := ((BEq.beq branch_type BranchType_DIR) || (BEq.beq branch_type BranchType_DIRCALL))
              writeReg SPESampleClass 0b10#2
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 1
                (Bit
                  (if (is_direct : Bool)
                  then 0#1
                  else 1#1)))
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
                (Bit
                  (if (conditional : Bool)
                  then 1#1
                  else 0#1)))
              writeReg SPESampleOpType OpType_Branch
              (if (taken_flag : Bool)
              then
                (do sail_assert (55 <b (Sail.BitVec.length target)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6767.38-6767.39"
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 55 0 (Sail.BitVec.extractLsb target 55 0)))
                    let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let (ns, nse) ← (( do
                      match (← (CurrentSecurityState ())) with
                      | .SS_Secure =>
                        (let ns : (BitVec 1) := 0#1
                        let nse : (BitVec 1) := 0#1
                        (pure (ns, nse)))
                      | .SS_NonSecure =>
                        (let ns : (BitVec 1) := 1#1
                        let nse : (BitVec 1) := 0#1
                        (pure (ns, nse)))
                      | .SS_Realm =>
                        (let ns : (BitVec 1) := 1#1
                        let nse : (BitVec 1) := 1#1
                        (pure (ns, nse)))
                      | _ =>
                        (do
                          (Unreachable ())
                          (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 63 (Bit ns)))
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 60 (Bit nse)))
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 62 61 (← readReg PSTATE).EL))
                    writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosBranchTarget true))
              else (do (pure ())))
              writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 6
                (Bit
                  (if ((! taken_flag) : Bool)
                  then 1#1
                  else 0#1))))
        else (do (pure ())))))

/-- Type quantifiers: k_N : Nat, k_conditional : Bool, k_taken_flag : Bool, k_N ≥ 0 -/
def SPEBranch (target : (BitVec k_N)) (branch_type : BranchType) (conditional : Bool) (taken_flag : Bool) : SailM Unit := do
  let is_isb : Bool := false
  (SPEBranch__1 target branch_type conditional taken_flag is_isb)

def Hint_Branch (hint : BranchType) : SailM Unit := do
  writeReg Branchtypetaken hint

/-- Type quantifiers: k_N : Nat, k_branch_conditional : Bool, k_N ≥ 0 -/
def BranchTo (target : (BitVec k_N)) (branch_type : BranchType) (branch_conditional : Bool) : SailM Unit := do
  (Hint_Branch branch_type)
  (if (((Sail.BitVec.length target) == 32) : Bool)
  then
    (do sail_assert (← (UsingAArch32 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:6804.29-6804.30"
        writeReg _PC (Sail.BitVec.zeroExtend target 64))
  else
    (do sail_assert (←((pure ((Sail.BitVec.length target) == 64)) <&&> (do
          (pure (! (← (UsingAArch32 ()))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6807.50-6807.51"
        let target_vaddress ← (( do (AArch64_BranchAddr (Sail.BitVec.extractLsb target 63 0) (← readReg PSTATE).EL) ) : SailM (BitVec 64) )
        (if (((← (HaveBRBExt ())) && ((BEq.beq branch_type BranchType_DIR) || ((BEq.beq branch_type BranchType_INDIR) || ((BEq.beq branch_type BranchType_DIRCALL) || ((BEq.beq branch_type BranchType_INDCALL) || (BEq.beq branch_type BranchType_RET)))))) : Bool)
        then (do (BRBEBranch branch_type branch_conditional target_vaddress))
        else (do (pure ())))
        let branch_taken : Bool := true
        (if ((← (HaveStatisticalProfiling ())) : Bool)
        then (do (SPEBranch target branch_type branch_conditional branch_taken))
        else (do (pure ())))
        let _ : Unit := (sail_branch_announce 64 target_vaddress)
        writeReg _PC target_vaddress))
  writeReg __BranchTaken true

/-- Type quantifiers: x : Int -/
def FloorPow2 (x : Int) : SailM Nat := do
  sail_assert (x ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:6832.17-6832.18"
  let n : Int := 1
  (if ((x == 0) : Bool)
  then (do (pure 0))
  else
    (do let n ← (( do
          let mut loop_vars := n
          while (λ n => (x ≥b (2 ^i n))) loop_vars do
            let n := loop_vars
            loop_vars := ((n +i 1) : Int)
          (pure loop_vars) ) : SailM Int )
        let n := n
        let r := (2 ^i (n -i 1))
        sail_assert (r ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:6842.17-6842.18"
        (pure r)))

/-- Type quantifiers: x : Int -/
def CeilPow2 (x : Int) : SailM Nat := do
  (if ((x == 0) : Bool)
  then (do (pure 0))
  else
    (do (if ((x == 1) : Bool)
        then (do (pure 2))
        else (do (pure ((← (FloorPow2 (x -i 1))) *i 2))))))

/-- Type quantifiers: x : Int -/
def IsPow2 (x : Int) : SailM Bool := do
  (if ((x ≤b 0) : Bool)
  then (do (pure false))
  else (do (pure ((← (FloorPow2 x)) == (← (CeilPow2 x))))))

def MaxImplementedVL (_ : Unit) : Int :=
  MAX_VL

/-- Type quantifiers: nbits_in : Int -/
def ImplementedSVEVectorLength (nbits_in : Int) : SailM Int := SailME.run do
  let maxbits := (MaxImplementedVL ())
  sail_assert (←((pure ((128 ≤b maxbits) && (maxbits ≤b 2048))) <&&> (do
    (IsPow2 maxbits)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6873.63-6873.64"
  let nbits : Int := (Min.min nbits_in maxbits)
  sail_assert (((128 ≤b nbits) && (nbits ≤b 2048)) && ((Align_int nbits 128) == nbits)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6875.70-6875.71"
  let nbits ← (( do
    let mut loop_vars := nbits
    while (λ nbits => (nbits >b 128)) loop_vars do
      let nbits := loop_vars
      loop_vars ← do
        (if ((← (IsPow2 nbits)) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6879.44-6879.45"
                  (pure nbits)))
        else (do (pure (nbits -i 128))))
    (pure loop_vars) ) : SailME Int Int )
  let nbits := nbits
  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6885.36-6885.37"
  (pure nbits)

def undefined_ZCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ZCR_EL1_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL1_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL2_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL3_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ZCR_EL2_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ZCR_EL3_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def undefined_ZCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ZCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CurrentNSVL_read (_ : Unit) : SailM Int := do
  let vl ← (( do (undefined_int ()) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (pure (! (← (IsInHost ())))))))) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL1_Type_LEN (← readReg ZCR_EL1)))))
    else (do (pure vl))) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (IsInHost ()))))) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL2_Type_LEN (← readReg ZCR_EL2)))))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_ZCR_EL2_Type_LEN (← readReg ZCR_EL2))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl ← (( do
    (if (((← readReg PSTATE).EL == EL3) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL3_Type_LEN (← readReg ZCR_EL3)))))
    else
      (do (if ((HaveEL EL3) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_ZCR_EL3_Type_LEN (← readReg ZCR_EL3))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl : Int := ((vl +i 1) *i 128)
  let vl ← (( do (ImplementedSVEVectorLength vl) ) : SailM Int )
  (pure vl)

def MaxImplementedSVL (_ : Unit) : SailM Int := do
  readReg __max_implemented_smeveclen

/-- Type quantifiers: nbits : Int -/
def SupportedPowerTwoSVL (nbits : Int) : Bool :=
  true

/-- Type quantifiers: nbits_in : Int -/
def ImplementedSMEVectorLength (nbits_in : Int) : SailM Int := SailME.run do
  let maxbits ← (( do (MaxImplementedSVL ()) ) : SailME Int Int )
  sail_assert (((((maxbits == 128) || (maxbits == 256)) || (maxbits == 512)) || (maxbits == 1024)) || (maxbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6932.38-6932.39"
  let nbits : Int := (Min.min nbits_in maxbits)
  sail_assert (((128 ≤b nbits) && (nbits ≤b 2048)) && ((Align_int nbits 128) == nbits)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6934.70-6934.71"
  let nbits ← (( do
    let mut loop_vars := nbits
    while (λ nbits => (nbits >b 128)) loop_vars do
      let nbits := loop_vars
      loop_vars ← do
        (if (((← (IsPow2 nbits)) && (SupportedPowerTwoSVL nbits)) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6938.44-6938.45"
                  (pure nbits)))
        else (do (pure (nbits -i 128))))
    (pure loop_vars) ) : SailME Int Int )
  let nbits : Int := 128
  let nbits ← (( do
    let mut loop_vars_1 := nbits
    while (λ nbits => (nbits <b maxbits)) loop_vars_1 do
      let nbits := loop_vars_1
      loop_vars_1 ← do
        (if ((SupportedPowerTwoSVL nbits) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6947.44-6947.45"
                  (pure nbits)))
        else (do (pure (nbits *i 2))))
    (pure loop_vars_1) ) : SailME Int Int )
  (pure maxbits)

def undefined_SMCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SMCR_EL1_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SMCR_EL2_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SMCR_EL3_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def undefined_SMCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SMCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CurrentSVL_read (_ : Unit) : SailM Int := do
  let vl ← (( do (undefined_int ()) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (pure (! (← (IsInHost ())))))))) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL1_Type_LEN (← readReg SMCR_EL1)))))
    else (do (pure vl))) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (IsInHost ()))))) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL2_Type_LEN (← readReg SMCR_EL2)))))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_SMCR_EL2_Type_LEN (← readReg SMCR_EL2))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl ← (( do
    (if (((← readReg PSTATE).EL == EL3) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL3_Type_LEN (← readReg SMCR_EL3)))))
    else
      (do (if ((HaveEL EL3) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_SMCR_EL3_Type_LEN (← readReg SMCR_EL3))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl : Int := ((vl +i 1) *i 128)
  let vl ← (( do (ImplementedSMEVectorLength vl) ) : SailM Int )
  (pure vl)

def HaveSME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME)

def CurrentVL_read (_ : Unit) : SailM Int := do
  let SVL ← (( do (CurrentSVL_read ()) ) : SailM Int )
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))))) : Bool)
  then (do (pure SVL))
  else (do (CurrentNSVL_read ())))

/-- Type quantifiers: width : Nat, width ≥ 0 -/
def FFR_set (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert (width == (Int.ediv VL 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7006.30-7006.31"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _FFR (Sail.BitVec.zeroExtend value_name MAX_PL))
  else (do writeReg _FFR (Sail.BitVec.updateSubrange (← readReg _FFR) (width -i 1) 0 value_name)))

def undefined_GCSPR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GCSPR_EL0_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL1_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL2_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL3_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def undefined_GCSPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSPR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSPR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveGCS (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_GCS)

def undefined_CPACR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPACR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPACR_EL1_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_CPTR_EL2_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR2_EL1_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_TCR2_EL2_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_CPACR_EL1_Type_FPEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_CPTR_EL2_Type_FPEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_CPACR_EL1_Type_SMEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _get_CPTR_EL2_Type_SMEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _update_HCPTR_Type_TTA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _get_CPACR_EL1_Type_ZEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 17 16)

def _get_CPTR_EL2_Type_ZEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 17 16)

def undefined_CPTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPTR_EL2_Type_TAM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _update_HCPTR_Type_TAM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_CPTR_EL3_Type_TAM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_CPTR_EL2_Type_TCPAC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_HCPTR_Type_TCPAC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_CPTR_EL3_Type_TCPAC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_CPTR_EL2_Type_TFP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_CPTR_EL3_Type_TFP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_CPTR_EL2_Type_TSM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CPTR_EL2_Type_TZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def undefined_CPTR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPTR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPTR_EL3_Type_ESM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CPTR_EL3_Type_EZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def AArch64_IsFPEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
       (pure (! (← (IsInHost ()))))))) : Bool)
  then
    (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
        let disabled ← (( do
          let b__0 ← do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1)))
          (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
          then (do (pure true))
          else
            (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure (el == EL0)))
                else (do (pure false))))) ) : SailME Bool Bool )
        let disabled := disabled
        (if (disabled : Bool)
        then (do SailME.throw (false : Bool))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
       (EL2Enabled ())))) : Bool)
  then
    (do (if ((←((HaveVirtHostExt ()) <&&> (do
             (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
              let disabled ← (( do
                let b__2 ← do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2)))
                (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                      then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                      else (do (pure false))))) ) : SailME Bool Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else
          (do (if (((_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2)) == 1#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
        then (do SailME.throw (false : Bool))
        else (do (pure ()))))
  else (do (pure ())))
  (pure true)

def undefined_CPACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CPACR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_CPACR_Type_ASEDIS (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_CPACR_Type_cp10 (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _update_CPACR_Type_cp10 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 20 x)

def _get_NSACR_Type_cp10 (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_CPACR_Type_cp11 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 22 x)

def CPACR_read__1 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CPACR ) : SailM CPACR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CPACR_EL1) 0 32)))

def undefined_HCPTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCPTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HCPTR_Type_TASE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _get_HCPTR_Type_TCP10 (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_HCPTR_Type_TCP10 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_HCPTR_Type_TCP11 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def HCPTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCPTR ) : SailM HCPTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CPTR_EL2) 0 32)))

def undefined_NSACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AArch32_IsFPEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  (if ((←((pure (el == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_IsFPEnabled el))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (ELUsingAArch32 EL3)) <&&> (do
             (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))))) : Bool)
        then
          (do (if (((_get_NSACR_Type_cp10 (← readReg NSACR)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if (((el == EL0) || (el == EL1)) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
              let disabled ← (( do
                match (_get_CPACR_Type_cp10 (← (CPACR_read__1 ()))) with
                | 0b00 => (pure true)
                | 0b01 => (pure (el == EL0))
                | 0b10 => (do (ConstrainUnpredictableBool Unpredictable_RESCPACR))
                | _ => (pure false) ) : SailME Bool Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((! (← (ELUsingAArch32 EL2))) : Bool)
              then (do SailME.throw (← do (AArch64_IsFPEnabled EL2)))
              else
                (do (if (((_get_HCPTR_Type_TCP10 (← (HCPTR_read ()))) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsFPEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (AArch32_IsFPEnabled el))
  else (do (AArch64_IsFPEnabled el)))

def HaveSVE (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SVE)

def IsOriginalSVEEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do let disabled ← (( do
          (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
               (pure (! (← (IsInHost ()))))))) : Bool)
          then
            (do let disabled ← (( do
                  let b__0 ← do (pure (_get_CPACR_EL1_Type_ZEN (← readReg CPACR_EL1)))
                  (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                  then (do (pure true))
                  else
                    (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                        then (do (pure (el == EL0)))
                        else (do (pure false))))) ) : SailME Bool Bool )
                (if (disabled : Bool)
                then (do SailME.throw (false : Bool))
                else (do (pure ())))
                (pure disabled))
          else (do (pure disabled))) ) : SailME Bool Bool )
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then
                (do let disabled ← (( do
                      let b__2 ← do (pure (_get_CPTR_EL2_Type_ZEN (← readReg CPTR_EL2)))
                      (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                            then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                            else (do (pure false))))) ) : SailME Bool Bool )
                    (if (disabled : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))
              else
                (do (if (((_get_CPTR_EL2_Type_TZ (← readReg CPTR_EL2)) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsSMEEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do let disabled ← (( do
          (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
               (pure (! (← (IsInHost ()))))))) : Bool)
          then
            (do let disabled ← (( do
                  let b__0 ← do (pure (_get_CPACR_EL1_Type_SMEN (← readReg CPACR_EL1)))
                  (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                  then (do (pure true))
                  else
                    (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                        then (do (pure (el == EL0)))
                        else (do (pure false))))) ) : SailME Bool Bool )
                (if (disabled : Bool)
                then (do SailME.throw (false : Bool))
                else (do (pure ())))
                (pure disabled))
          else (do (pure disabled))) ) : SailME Bool Bool )
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then
                (do let disabled ← (( do
                      let b__2 ← do (pure (_get_CPTR_EL2_Type_SMEN (← readReg CPTR_EL2)))
                      (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                            then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                            else (do (pure false))))) ) : SailME Bool Bool )
                    (if (disabled : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))
              else
                (do (if (((_get_CPTR_EL2_Type_TSM (← readReg CPTR_EL2)) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_ESM (← readReg CPTR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsSVEEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))))) : Bool)
  then (do (IsSMEEnabled el))
  else
    (do (if ((← (HaveSVE ())) : Bool)
        then (do (IsOriginalSVEEnabled el))
        else (do (pure false)))))

/-- Type quantifiers: n : Int, width : Nat, width ≥ 0 -/
def P_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7362.27-7362.28"
  sail_assert (width == (Int.ediv VL 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7363.30-7363.31"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then
    (do sail_assert ((0 ≤b n) && (n <b 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7365.46-7365.47"
        writeReg _P (vectorUpdate (← readReg _P) n (Sail.BitVec.zeroExtend value_name MAX_PL)))
  else
    (do sail_assert ((0 ≤b n) && (n <b 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7368.46-7368.47"
        writeReg _P (vectorUpdate (← readReg _P) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _P) n) (width -i 1) 0 value_name))))

def SP_set (value_name : (BitVec 64)) : SailM Unit := do
  (if (((← readReg PSTATE).SP == 0#1) : Bool)
  then (do writeReg SP_EL0 value_name)
  else
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do writeReg SP_EL0 value_name)
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do writeReg SP_EL1 value_name)
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do writeReg SP_EL2 value_name)
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do writeReg SP_EL3 value_name)
                          else (do (pure ())))))))))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64, 128] -/
def V_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7420.27-7420.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || ((width == 64) || (width == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:7421.78-7421.79"
  let vlen ← (( do
    (if ((← (IsSVEEnabled (← readReg PSTATE).EL)) : Bool)
    then (do (pure VL))
    else (do (pure 128))) ) : SailM Int )
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.zeroExtend value_name MAX_VL)))
  else (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _Z) n) (vlen -i 1) 0 (Sail.BitVec.zeroExtend value_name vlen)))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [32, 64] -/
def X_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7435.27-7435.28"
  sail_assert ((width == 32) || (width == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7436.36-7436.37"
  (if ((n != 31) : Bool)
  then (do (set_R n (Sail.BitVec.zeroExtend value_name 64)))
  else (do (pure ())))

/-- Type quantifiers: n : Int, width : Nat, width ≥ 0 -/
def Z_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7448.27-7448.28"
  sail_assert (width == VL) "sail-arm/arm-v9.4-a/src/v8_base.sail:7449.22-7449.23"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.zeroExtend value_name MAX_VL)))
  else (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _Z) n) (width -i 1) 0 value_name))))

/-- Type quantifiers: pl : Nat, vl : Nat, (is_VL vl) ∧ (is_PL pl) -/
def RestoreTransactionCheckpointParameterised (vl : Nat) (pl : Nat) : SailM Unit := do
  sail_assert ((((((((((((((((vl == 128) || (vl == 256)) || (vl == 384)) || (vl == 512)) || (vl == 640)) || (vl == 768)) || (vl == 896)) || (vl == 1024)) || (vl == 1152)) || (vl == 1280)) || (vl == 1408)) || (vl == 1536)) || (vl == 1664)) || (vl == 1792)) || (vl == 1920)) || (vl == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7461.237-7461.238"
  (SP_set (← readReg TSTATE).SP)
  writeReg ICC_PMR_EL1 (Mk_ICC_PMR_EL1_Type (← readReg TSTATE).ICC_PMR_EL1)
  let split_vec ← do (pure (← readReg TSTATE).nzcv)
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) }
  let split_vec ← do (pure ((← readReg TSTATE).D +++ ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F))))
  writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  let loop_n_lower := 0
  let loop_n_upper := 30
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do (X_set n 64 (GetElem?.getElem! (← readReg TSTATE).X n))
  (pure loop_vars)
  (if ((← (IsFPEnabled (← readReg PSTATE).EL)) : Bool)
  then
    (do (if ((← (IsSVEEnabled (← readReg PSTATE).EL)) : Bool)
        then
          (do let loop_n_lower := 0
              let loop_n_upper := 31
              let mut loop_vars_2 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_2
                loop_vars_2 ← do (Z_set n vl (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).Z n) (vl -i 1) 0))
              (pure loop_vars_2)
              let loop_n_lower := 0
              let loop_n_upper := 15
              let mut loop_vars_3 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_3
                loop_vars_3 ← do (P_set n pl (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).P n) (pl -i 1) 0))
              (pure loop_vars_3)
              (FFR_set pl (Sail.BitVec.extractLsb (← readReg TSTATE).FFR (pl -i 1) 0)))
        else
          (do let loop_n_lower := 0
              let loop_n_upper := 31
              let mut loop_vars_1 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_1
                loop_vars_1 ← do (V_set n 128 (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).Z n) 127 0))
              (pure loop_vars_1)))
        writeReg FPCR (Mk_FPCR_Type (← readReg TSTATE).FPCR)
        writeReg FPSR (Mk_FPSR_Type (← readReg TSTATE).FPSR))
  else (do (pure ())))
  (if ((← (HaveGCS ())) : Bool)
  then
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do writeReg GCSPR_EL0 (Mk_GCSPR_EL0_Type (← readReg TSTATE).GCSPR_ELx))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do writeReg GCSPR_EL1 (Mk_GCSPR_EL1_Type (← readReg TSTATE).GCSPR_ELx))
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do writeReg GCSPR_EL2 (Mk_GCSPR_EL2_Type (← readReg TSTATE).GCSPR_ELx))
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do writeReg GCSPR_EL3 (Mk_GCSPR_EL3_Type (← readReg TSTATE).GCSPR_ELx))
                          else (do (pure ()))))))))))
  else (do (pure ())))

def RestoreTransactionCheckpoint (_ : Unit) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  let VL := VL
  match VL with
  | 128 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 256 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 512 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 1024 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 2048 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:7561.22-7561.23"

/-- Type quantifiers: processorid : Int -/
def ClearExclusiveLocal (processorid : Int) : Unit :=
  ()

def DiscardTransactionalWrites (_ : Unit) : Unit :=
  ()

def ProcessorID (_ : Unit) : Int :=
  0

/-- Type quantifiers: k_interrupt : Bool, k_retry : Bool -/
def FailTransaction__1 (cause : TMFailure) (retry : Bool) (interrupt : Bool) (reason : (BitVec 15)) : SailM Unit := do
  sail_assert ((! retry) || (! interrupt)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7577.48-7577.49"
  (if ((←((HaveBRBExt ()) <&&> (do
       (BranchRecordAllowed (← readReg PSTATE).EL)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 1#1))
  else (do (pure ())))
  let _ : Unit := (DiscardTransactionalWrites ())
  (if ((bne cause TMFailure_TRIVIAL) : Bool)
  then (do (RestoreTransactionCheckpoint ()))
  else (do (pure ())))
  let _ : Unit := (ClearExclusiveLocal (ProcessorID ()))
  let result : (BitVec 64) := (Zeros (n := 64))
  let result : (BitVec 64) :=
    (BitVec.update result 23
      (Bit
        (if (interrupt : Bool)
        then 1#1
        else 0#1)))
  let result : (BitVec 64) :=
    (BitVec.update result 15
      (Bit
        (if ((retry && (! interrupt)) : Bool)
        then 1#1
        else 0#1)))
  let result : (BitVec 64) :=
    match cause with
    | .TMFailure_TRIVIAL => (BitVec.update result 24 (Bit 1#1))
    | .TMFailure_DBG => (BitVec.update result 22 (Bit 1#1))
    | .TMFailure_NEST => (BitVec.update result 21 (Bit 1#1))
    | .TMFailure_SIZE => (BitVec.update result 20 (Bit 1#1))
    | .TMFailure_ERR => (BitVec.update result 19 (Bit 1#1))
    | .TMFailure_IMP => (BitVec.update result 18 (Bit 1#1))
    | .TMFailure_MEM => (BitVec.update result 17 (Bit 1#1))
    | .TMFailure_CNCL =>
      (let result : (BitVec 64) := (BitVec.update result 16 (Bit 1#1))
      (Sail.BitVec.updateSubrange result 14 0 reason))
  writeReg TSTATE { (← readReg TSTATE) with depth := 0 }
  (X_set (← readReg TSTATE).Rt 64 result)
  let branch_conditional : Bool := false
  (BranchTo (← readReg TSTATE).nPC BranchType_TMFAIL branch_conditional)
  (EndOfInstruction ())

/-- Type quantifiers: k_retry : Bool -/
def FailTransaction (cause : TMFailure) (retry : Bool) : SailM Unit := do
  (FailTransaction__1 cause retry false (Zeros (n := 15)))

def HaveBTIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BTI)

def HaveDITExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DIT)

def HaveFeatNMI (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NMI)

def HaveMTEExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE)

def HavePANExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAN)

def HaveSSBSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SSBS)

def HaveUAOExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_UAO)

/-- Type quantifiers: N : Nat, List.elem N [32, 64] -/
def GetPSRFromPSTATE (targetELState : ExceptionalOccurrenceTargetState) (N : Nat) : SailM (BitVec N) := do
  (if (((← (UsingAArch32 ())) && (BEq.beq targetELState AArch32_NonDebugState)) : Bool)
  then (do sail_assert (N == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:7671.22-7671.23")
  else (do sail_assert (N == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:7673.22-7673.23"))
  let spsr : (BitVec N) := (Zeros (n := N))
  let spsr ← (pure (Sail.BitVec.updateSubrange spsr 31 28 ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))))
  let spsr ← (( do
    (if ((← (HavePANExt ())) : Bool)
    then (do (pure (BitVec.update spsr 22 (Bit (← readReg PSTATE).PAN))))
    else (do (pure spsr))) ) : SailM (BitVec N) )
  let spsr ← (pure (BitVec.update spsr 20 (Bit (← readReg PSTATE).IL)))
  (if (((← readReg PSTATE).nRW == 1#1) : Bool)
  then
    (do let spsr ← (pure (BitVec.update spsr 27 (Bit (← readReg PSTATE).Q)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 26 25 (Sail.BitVec.extractLsb (← readReg PSTATE).IT 1 0)))
        let spsr ← (( do
          (if ((← (HaveSSBSExt ())) : Bool)
          then (do (pure (BitVec.update spsr 23 (Bit (← readReg PSTATE).SSBS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveDITExt ())) : Bool)
          then
            (do (if ((BEq.beq targetELState AArch32_NonDebugState) : Bool)
                then (do (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).DIT))))
                else (do (pure (BitVec.update spsr 24 (Bit (← readReg PSTATE).DIT))))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if (((BEq.beq targetELState AArch64_NonDebugState) || (BEq.beq targetELState DebugState)) : Bool)
          then (do (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).SS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 19 16 (← readReg PSTATE).GE))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 15 10 (Sail.BitVec.extractLsb (← readReg PSTATE).IT 7 2)))
        let spsr ← (pure (BitVec.update spsr 9 (Bit (← readReg PSTATE).E)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 8 6 ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
        let spsr ← (pure (BitVec.update spsr 5 (Bit (← readReg PSTATE).T)))
        sail_assert (((BitVec.access (← readReg PSTATE).M 4) : BitVec 1) == (← readReg PSTATE).nRW) "sail-arm/arm-v9.4-a/src/v8_base.sail:7702.42-7702.43"
        (pure (Sail.BitVec.updateSubrange spsr 4 0 (← readReg PSTATE).M)))
  else
    (do let spsr ← (( do
          (if ((← (HaveMTEExt ())) : Bool)
          then (do (pure (BitVec.update spsr 25 (Bit (← readReg PSTATE).TCO))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveGCS ())) : Bool)
          then
            (do sail_assert (34 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:7709.38-7709.39"
                (pure (BitVec.update spsr 34 (Bit (← readReg PSTATE).EXLOCK))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveDITExt ())) : Bool)
          then (do (pure (BitVec.update spsr 24 (Bit (← readReg PSTATE).DIT))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveUAOExt ())) : Bool)
          then (do (pure (BitVec.update spsr 23 (Bit (← readReg PSTATE).UAO))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).SS)))
        let spsr ← (( do
          (if ((← (HaveFeatNMI ())) : Bool)
          then (do (pure (BitVec.update spsr 13 (Bit (← readReg PSTATE).ALLINT))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveSSBSExt ())) : Bool)
          then (do (pure (BitVec.update spsr 12 (Bit (← readReg PSTATE).SSBS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveBTIExt ())) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange spsr 11 10 (← readReg PSTATE).BTYPE)))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 9 6 ((← readReg PSTATE).D +++ ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))))
        let spsr ← (pure (BitVec.update spsr 4 (Bit (← readReg PSTATE).nRW)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 3 2 (← readReg PSTATE).EL))
        (pure (BitVec.update spsr 0 (Bit (← readReg PSTATE).SP)))))

def Havev8p9Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p9)

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def ThisInstrAddr (N : Nat) : SailM (BitVec N) := do
  sail_assert (←((pure (N == 64)) <||> (do
    (pure (N == 32)) <&&> (do
      (UsingAArch32 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:7747.45-7747.46"
  (pure (Sail.BitVec.extractLsb (← readReg _PC) (N -i 1) 0))

def UpdateEDSCRFields (_ : Unit) : SailM Unit := do
  let ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (Halted ()))) : Bool)
  then
    (do (EDSCR_write (_update_EDSCR_Type_EL (← (EDSCR_read ())) 0b00#2))
        (if ((← (HaveRME ())) : Bool)
        then
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalRootInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1))))))
              let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
              let __tmp ← (( do
                let split_vec ← do (__UNKNOWN_bits 2)
                let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb split_vec 1 1))
                (pure (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb split_vec 0 0))) ) : SailM (BitVec 32) )
              (EDSCR_write __tmp))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalSecureInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1))))))
              (EDSCR_write (_update_EDSCR_Type_NS (← (EDSCR_read ())) (← (__UNKNOWN_bit ()))))))
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) 0b1111#4)))
  else
    (do (EDSCR_write (_update_EDSCR_Type_EL (← (EDSCR_read ())) (← readReg PSTATE).EL))
        let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
        (if ((← (HaveRME ())) : Bool)
        then
          (do match ss with
              | .SS_Secure =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b00#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b00#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_NonSecure =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b01#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b01#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_Root =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b10#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b10#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_Realm =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b11#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b11#2 0 0))
                  (EDSCR_write __tmp)))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_NS (← (EDSCR_read ()))
                  (if ((BEq.beq ss SS_Secure) : Bool)
                  then 0#1
                  else 1#1)))))
        let RW ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
        let RW ←
          (pure (BitVec.update RW 1
              (Bit
                (← do
                  (if ((← (ELUsingAArch32 EL1)) : Bool)
                  then (do (pure 0#1))
                  else (do (pure 1#1)))))))
        let RW ← (( do
          (if (((← readReg PSTATE).EL != EL0) : Bool)
          then (do (pure (BitVec.update RW 0 (Bit ((BitVec.access RW 1) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 0
                    (Bit
                      (← do
                        (if ((← (UsingAArch32 ())) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((←((pure (! (HaveEL EL2))) <||> (do
               (pure (HaveEL EL3)) <&&> (do
                 (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 0#1))) <&&> (do
                 (pure (! (← (IsSecureEL2Enabled ())))))))) : Bool)
          then (do (pure (BitVec.update RW 2 (Bit ((BitVec.access RW 1) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 2
                    (Bit
                      (← do
                        (if ((← (ELUsingAArch32 EL2)) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((! (HaveEL EL3)) : Bool)
          then (do (pure (BitVec.update RW 3 (Bit ((BitVec.access RW 2) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 3
                    (Bit
                      (← do
                        (if ((← (ELUsingAArch32 EL3)) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((((BitVec.access RW 3) : BitVec 1) == 0#1) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange RW 2 0 (← (__UNKNOWN_bits 3)))))
          else
            (do (if ((((BitVec.access RW 2) : BitVec 1) == 0#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange RW 1 0 (← (__UNKNOWN_bits 2)))))
                else
                  (do (if ((((BitVec.access RW 1) : BitVec 1) == 0#1) : Bool)
                      then (do (pure (BitVec.update RW 0 (Bit (← (__UNKNOWN_bit ()))))))
                      else (do (pure RW))))))) ) : SailM (BitVec 4) )
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) RW))))

def CTI_SignalEvent (id : CrossTriggerIn) : Unit :=
  ()

def StopInstructionPrefetchAndEnableITR (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_is_async : Bool -/
def Halt__1 (reason : (BitVec 6)) (is_async : Bool) : SailM Unit := do
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
  then (do (FailTransaction TMFailure_DBG false))
  else (do (pure ())))
  let _ : Unit := (CTI_SignalEvent CrossTriggerIn_CrossHalt)
  let preferred_restart_address ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let spsr ← (( do (GetPSRFromPSTATE DebugState 64) ) : SailM (BitVec 64) )
  let spsr ← (( do
    (if ((←((pure (((← (HaveBTIExt ())) && (! is_async)) && (! ((reason == DebugHalt_Step_Normal) || ((reason == DebugHalt_Step_Exclusive) || ((reason == DebugHalt_Step_NoSyndrome) || ((reason == DebugHalt_Breakpoint) || (reason == DebugHalt_HaltInstruction)))))))) <&&> (do
         (ConstrainUnpredictableBool Unpredictable_ZEROBTYPE)))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange spsr 11 10 0b00#2)))
    else (do (pure spsr))) ) : SailM (BitVec 64) )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do (DLR_write (Sail.BitVec.extractLsb preferred_restart_address 31 0))
        (DSPSR_write (Mk_DSPSR_Type (Sail.BitVec.extractLsb spsr 31 0)))
        (if ((← (Havev8p9Debug ())) : Bool)
        then (do (DSPSR2_write (Mk_DSPSR2_Type (Sail.BitVec.extractLsb spsr 63 32))))
        else (do (pure ()))))
  else
    (do writeReg DLR_EL0 preferred_restart_address
        writeReg DSPSR_EL0 (Mk_DSPSR_EL0_Type spsr)))
  (EDSCR_write (_update_EDSCR_Type_ITE (← (EDSCR_read ())) 1#1))
  (EDSCR_write (_update_EDSCR_Type_ITO (← (EDSCR_read ())) 0#1))
  (if ((← (HaveRME ())) : Bool)
  then
    (do (if (((← readReg PSTATE).EL == EL3) : Bool)
        then (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 0#1)))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalRootInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1)))))))))
  else
    (do (if ((BEq.beq (← (CurrentSecurityState ())) SS_Secure) : Bool)
        then (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 0#1)))
        else
          (do (if ((HaveEL EL3) : Bool)
              then
                (do (EDSCR_write
                      (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                        (← do
                          (if ((← (ExternalSecureInvasiveDebugEnabled ())) : Bool)
                          then (do (pure 0#1))
                          else (do (pure 1#1)))))))
              else (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 1#1))))))))
  (EDSCR_write (_update_EDSCR_Type_MA (← (EDSCR_read ())) 0#1))
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let split_vec ← do (__UNKNOWN_bits 14)
        writeReg PSTATE { (← readReg PSTATE) with IT := (Sail.BitVec.extractLsb split_vec 13 6) }
        writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 5 5) }
        writeReg PSTATE { (← readReg PSTATE) with SSBS := (Sail.BitVec.extractLsb split_vec 4 4) }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with T := (Sail.BitVec.extractLsb split_vec 0 0) })
  else
    (do let split_vec ← do (__UNKNOWN_bits 6)
        writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 5 5) }
        writeReg PSTATE { (← readReg PSTATE) with SSBS := (Sail.BitVec.extractLsb split_vec 4 4) }
        writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
        writeReg PSTATE { (← readReg PSTATE) with TCO := 1#1 }
        writeReg PSTATE { (← readReg PSTATE) with BTYPE := 0b00#2 }))
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  let _ : Unit := (StopInstructionPrefetchAndEnableITR ())
  (EDSCR_write (_update_EDSCR_Type_STATUS (← (EDSCR_read ())) reason))
  (UpdateEDSCRFields ())
  (if ((! is_async) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))

def Halt (reason : (BitVec 6)) : SailM Unit := do
  let is_async : Bool := false
  (Halt__1 reason is_async)

def undefined_DBGOSDLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGOSDLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_DBGOSDLR_Type_DLK (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_DBGOSDLR_Type_DLK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_OSDLR_EL1_Type_DLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_OSDLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_OSDLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def DBGOSDLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGOSDLR ) : SailM DBGOSDLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSDLR_EL1) 0 32)))

def undefined_DBGPRCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGPRCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DBGPRCR_EL1_Type_CORENPDRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_DBGPRCR_Type_CORENPDRQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_DBGPRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGPRCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGPRCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGPRCR ) : SailM DBGPRCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGPRCR_EL1) 0 32)))

def HaveDoubleLock (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleLock)

def DoubleLockStatus (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveDoubleLock ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((← (ELUsingAArch32 EL1)) : Bool)
        then (do (pure ((_get_DBGOSDLR_Type_DLK (← (DBGOSDLR_read ()))) == 1#1)) <&&> (do (pure ((_get_DBGPRCR_Type_CORENPDRQ (← (DBGPRCR_read ()))) == 0#1))) <&&> (do (pure (! (← (Halted ()))))))
        else (do (pure ((_get_OSDLR_EL1_Type_DLK (← readReg OSDLR_EL1)) == 1#1)) <&&> (do (pure ((_get_DBGPRCR_EL1_Type_CORENPDRQ (← readReg DBGPRCR_EL1)) == 0#1))) <&&> (do (pure (! (← (Halted ())))))))))

def HaltingAllowed (_ : Unit) : SailM Bool := do
  (if ((←((Halted ()) <||> (do
       (DoubleLockStatus ())))) : Bool)
  then (do (pure false))
  else
    (do let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
        match ss with
        | .SS_NonSecure => (ExternalInvasiveDebugEnabled ())
        | .SS_Secure => (ExternalSecureInvasiveDebugEnabled ())
        | .SS_Root => (ExternalRootInvasiveDebugEnabled ())
        | .SS_Realm => (ExternalRealmInvasiveDebugEnabled ())))

/-- Type quantifiers: k_N : Nat, y : Int, k_N ≥ 0 -/
def IsAligned__1 (x : (BitVec k_N)) (y : Int) : Bool :=
  (x == (Align_bits x y))

/-- Type quantifiers: k_round : Bool, shift : Int, value_name : Int -/
def RShr (value_name : Int) (shift : Int) (round : Bool) : SailM Int := do
  sail_assert (shift >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:8066.20-8066.21"
  (if (round : Bool)
  then (do (pure (Int.shiftr (value_name +i (Int.shiftl 1 (shift -i 1))) shift)))
  else (do (pure (Int.shiftr value_name shift))))

def IsHighestEL (el : (BitVec 2)) : Bool :=
  ((HighestEL ()) == el)

def EffectiveSCR_EL3_NSE (_ : Unit) : SailM (BitVec 1) := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure 0#1))
  else (do (pure (_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)))))

def ELFromM32 (mode : (BitVec 5)) : SailM (Bool × (BitVec 2)) := do
  let el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let valid_name ← (( do (pure (! (← (BadMode mode)))) ) : SailM Bool )
  let effective_nse_ns ← (( do (pure ((← (EffectiveSCR_EL3_NSE ())) +++ (← (EffectiveSCR_EL3_NS ())))) ) : SailM (BitVec 2) )
  let (el, valid_name) ← (( do
    let questionMark := mode
    let (el, valid_name) ← (( do
      (if ((questionMark == M32_Monitor) : Bool)
      then
        (do let el : (BitVec 2) := EL3
            (pure (el, valid_name)))
      else
        (do let (el, valid_name) ← (( do
              (if ((questionMark == M32_Hyp) : Bool)
              then
                (do let el : (BitVec 2) := EL2
                    (pure (el, valid_name)))
              else
                (do let (el, valid_name) ← (( do
                      (if ((questionMark == M32_FIQ) : Bool)
                      then
                        (do let el ←
                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                              then (do (pure EL3))
                              else (do (pure EL1)))
                            (pure (el, valid_name)))
                      else
                        (do let (el, valid_name) ← (( do
                              (if ((questionMark == M32_IRQ) : Bool)
                              then
                                (do let el ←
                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                      then (do (pure EL3))
                                      else (do (pure EL1)))
                                    (pure (el, valid_name)))
                              else
                                (do let (el, valid_name) ← (( do
                                      (if ((questionMark == M32_Svc) : Bool)
                                      then
                                        (do let el ←
                                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                              then (do (pure EL3))
                                              else (do (pure EL1)))
                                            (pure (el, valid_name)))
                                      else
                                        (do let (el, valid_name) ← (( do
                                              (if ((questionMark == M32_Abort) : Bool)
                                              then
                                                (do let el ←
                                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                      then (do (pure EL3))
                                                      else (do (pure EL1)))
                                                    (pure (el, valid_name)))
                                              else
                                                (do let (el, valid_name) ← (( do
                                                      (if ((questionMark == M32_Undef) : Bool)
                                                      then
                                                        (do let el ←
                                                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                              then (do (pure EL3))
                                                              else (do (pure EL1)))
                                                            (pure (el, valid_name)))
                                                      else
                                                        (do let (el, valid_name) ← (( do
                                                              (if ((questionMark == M32_System) : Bool)
                                                              then
                                                                (do let el ←
                                                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                                      then (do (pure EL3))
                                                                      else (do (pure EL1)))
                                                                    (pure (el, valid_name)))
                                                              else
                                                                (do let (el, valid_name) : ((BitVec 2) × Bool) :=
                                                                      if ((questionMark == M32_User) : Bool)
                                                                      then
                                                                        (let el : (BitVec 2) := EL0
                                                                        (el, valid_name))
                                                                      else
                                                                        (let valid_name : Bool := false
                                                                        (el, valid_name))
                                                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
    (pure (el, valid_name)) ) : SailM ((BitVec 2) × Bool) )
  let valid_name ← (( do
    (if ((←((pure ((valid_name && (el == EL2)) && (HaveEL EL3))) <&&> (do
         (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
    then (do (pure false))
    else
      (do (if (((←((pure valid_name) <&&> (do
                 (HaveRME ())))) && (effective_nse_ns == 0b10#2)) : Bool)
          then (do (pure false))
          else (do (pure valid_name))))) ) : SailM Bool )
  let el ← (( do
    (if ((! valid_name) : Bool)
    then (do (__UNKNOWN_bits 2))
    else (do (pure el))) ) : SailM (BitVec 2) )
  let el := el
  (pure (valid_name, el))

def undefined_GCSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GCSCR_EL1_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL2_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL3_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL1_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCRE0_EL1_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL2_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL3_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL1_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCRE0_EL1_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCR_EL2_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCR_EL3_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def undefined_GCSCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def GetCurrentEXLOCKEN (_ : Unit) : SailM Bool := do
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then
    (do (Unreachable ())
        (undefined_bool ()))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do (pure ((_get_GCSCR_EL1_Type_EXLOCKEN (← readReg GCSCR_EL1)) == 1#1)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (pure ((_get_GCSCR_EL2_Type_EXLOCKEN (← readReg GCSCR_EL2)) == 1#1)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure ((_get_GCSCR_EL3_Type_EXLOCKEN (← readReg GCSCR_EL3)) == 1#1)))
                    else (do (undefined_bool ())))))))))

def AArch32_WriteMode (mode : (BitVec 5)) : SailM Unit := do
  let el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let valid_name ← (( do (undefined_bool ()) ) : SailM Bool )
  let (el, valid_name) ← (( do
    let (tup__0, tup__1) ← do (ELFromM32 mode)
    let valid_name : Bool := tup__0
    let el : (BitVec 2) := tup__1
    (pure (el, valid_name)) ) : SailM ((BitVec 2) × Bool) )
  sail_assert valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:8277.21-8277.22"
  writeReg PSTATE { (← readReg PSTATE) with M := mode }
  writeReg PSTATE { (← readReg PSTATE) with EL := el }
  writeReg PSTATE { (← readReg PSTATE) with nRW := 1#1 }
  writeReg PSTATE { (← readReg PSTATE) with SP := if (((mode == M32_User) || (mode == M32_System)) : Bool)
    then 0#1
    else 1#1 }

def undefined_MDSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDSCR_EL1_Type_EHBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _update_EDSCR2_Type_EHBWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)


end ArmASL.Functions
