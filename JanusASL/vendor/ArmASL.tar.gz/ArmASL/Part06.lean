import ArmASL.Part05

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def HandleExternalAbort (memretstatus : PhysMemRetStatus) (iswrite : Bool) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  sail_assert (←((pure ((BEq.beq memretstatus.statuscode Fault_SyncExternal) || (BEq.beq memretstatus.statuscode Fault_AsyncExternal))) <||> (do
    (pure ((! (← (HaveRASExt ()))) && ((BEq.beq memretstatus.statuscode Fault_SyncParity) || (BEq.beq memretstatus.statuscode Fault_AsyncParity))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15300.227-15300.228"
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := memretstatus.statuscode }
  let fault : FaultRecord := { fault with write := iswrite }
  let fault : FaultRecord := { fault with extflag := memretstatus.extflag }
  let fault ← (( do
    (if ((←((IsExternalSyncAbort__1 fault) <&&> (do
         (pure (! (← (IsExternalAbortTakenSynchronously memretstatus iswrite memaddrdesc size accdesc))))))) : Bool)
    then
      (do (if ((BEq.beq fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { fault with statuscode := Fault_AsyncParity }))
          else (do (pure { fault with statuscode := Fault_AsyncExternal }))))
    else (do (pure fault))) ) : SailM FaultRecord )
  let fault ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure { fault with merrorstate := memretstatus.merrorstate }))
    else (do (pure fault))) ) : SailM FaultRecord )
  (if ((← (IsExternalSyncAbort__1 fault)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (AArch32_Abort (Sail.BitVec.extractLsb memaddrdesc.vaddress 31 0) fault))
        else (do (AArch64_Abort memaddrdesc.vaddress fault))))
  else (do (pure (PendSErrorInterrupt fault))))

/-- Type quantifiers: size : Int -/
def HandleExternalReadAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := false
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

/-- Type quantifiers: size : Int -/
def HandleExternalWriteAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := true
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

def HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCR r

def ClearPendingVirtualSError (_ : Unit) : SailM Unit := do
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do (HCR_write (_update_HCR_Type_VA (← (HCR_read ())) 0#1)))
  else (do writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1)))

def IsSErrorEdgeTriggered (_ : Unit) : SailM Bool := do
  (if ((← (HaveDoubleFaultExt ())) : Bool)
  then (do (pure true))
  else (do (__IMPDEF_boolean "Edge-triggered SError")))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPInfinity (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15378.38-15378.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPMaxNormal (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15389.38-15389.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := ((Ones (n := (E -i 1))) +++ 0#1)
  let frac : (BitVec F) := (Ones (n := F))
  (pure ((sign +++ exp) +++ frac))

def AArch32_GeneralExceptionsToAArch64 (_ : Unit) : SailM Bool := do
  (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
    (pure (! (← (ELUsingAArch32 EL1))))) <||> (do
    (EL2Enabled ()) <&&> (do
      (pure (! (← (ELUsingAArch32 EL2))))) <&&> (do
      (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))

def AArch32_TakeUndefInstrException__1 (except : ExceptionRecord) : SailM Unit := do
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x04#8)
  let lr_offset ← (( do
    (if ((BEq.beq (← (CurrentInstrSet ())) InstrSet_A32) : Bool)
    then (do (pure 4))
    else (do (pure 2))) ) : SailM Int )
  (if (((← readReg PSTATE).EL == EL2) : Bool)
  then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
  else
    (do (if (route_to_hyp : Bool)
        then (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))
        else (do (AArch32_EnterMode M32_Undef preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeUndefInstrException (_ : Unit) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_Uncategorized) ) : SailM ExceptionRecord )
  (AArch32_TakeUndefInstrException__1 except)

/-- Type quantifiers: k_is_ase : Bool -/
def AArch64_FPTrappedException (is_ase : Bool) (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_FPTrappedException) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (is_ase : Bool)
    then
      (do (if ((← (__IMPDEF_boolean "vector instructions set TFV to 1")) : Bool)
          then (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))
          else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 0#1)) }))))
    else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 10 8 (← (__UNKNOWN_bits 3))))) })
  let except ← (( do
    (if ((((BitVec.access except.syndrome 23) : BitVec 1) == 1#1) : Bool)
    then
      (do let split_vec := (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0))
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))
    else
      (do let split_vec ← do (__UNKNOWN_bits 6)
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))) ) : SailM ExceptionRecord )
  let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def undefined_FPEXC32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPEXC32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_FPEXC_Type_DEX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_FPEXC32_EL2_Type_DZF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_FPEXC_Type_EN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_PMUSERENR_EL0_Type_EN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_FPEXC_Type_EX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_FPEXC_Type_FP2V (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_FPEXC32_EL2_Type_IDF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_FPEXC32_EL2_Type_IOF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_FPEXC32_EL2_Type_IXF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_FPEXC32_EL2_Type_OFF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_FPEXC_Type_TFV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _get_FPEXC32_EL2_Type_UFF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_FPEXC_Type_VECITR (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 8 x)

def _update_FPEXC_Type_VV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def undefined_FPEXC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_FPEXC_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def FPEXC_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _FPEXC ) : SailM FPEXC_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FPEXC32_EL2) 0 32)))

def FPEXC_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPEXC_Type := value_name
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _FPEXC r

def AArch32_FPTrappedException (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (AArch32_GeneralExceptionsToAArch64 ())) : Bool)
  then
    (do let is_ase : Bool := false
        let element : Int := 0
        (AArch64_FPTrappedException is_ase accumulated_exceptions))
  else (do (pure ())))
  (FPEXC_write (_update_FPEXC_Type_DEX (← (FPEXC_read ())) 1#1))
  (FPEXC_write (_update_FPEXC_Type_TFV (← (FPEXC_read ())) 1#1))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 7 7 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 5 1))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 4 0 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 0 5))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 10 8 0b111#3)))
  (AArch32_TakeUndefInstrException ())

def FPSCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPSCR_Type := value_name
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 31 27 (BitVec.slice r 27 5))
  writeReg FPSR (BitVec.update (← readReg FPSR) 7 (Bit (BitVec.slice r 7 1)))
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 4 0 (BitVec.slice r 0 5))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 26 15 (BitVec.slice r 15 12))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 12 8 (BitVec.slice r 8 5))

def HaveSMEFullA64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME_FA64)

def IsFullA64Enabled (_ : Unit) : SailM Bool := SailME.run do
  (if ((! (← (HaveSMEFullA64 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
             (pure (! (← (IsInHost ()))))))) : Bool)
        then
          (do (if (((_get_SMCR_EL1_Type_FA64 (← readReg SMCR_EL1)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1)) <||> (do
               (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if (((_get_SMCR_EL2_Type_FA64 (← readReg SMCR_EL2)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_SMCR_EL3_Type_FA64 (← readReg SMCR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def GetAccumulatedFPExceptions (_ : Unit) : SailM (BitVec 8) := do
  (__UNKNOWN_bits 8)

def IsASEInstruction (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def SetAccumulatedFPExceptions (accumulated_exceptions : (BitVec 8)) : Unit :=
  ()

def FPProcessException (except : FPExc) (fpcr : (BitVec 64)) : SailM Unit := do
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  let cumul : Int := 0
  let cumul : Int :=
    match except with
    | .FPExc_InvalidOp => 0
    | .FPExc_DivideByZero => 1
    | .FPExc_Overflow => 2
    | .FPExc_Underflow => 3
    | .FPExc_Inexact => 4
    | .FPExc_InputDenorm => 7
  let cumul := cumul
  let enable := (cumul +i 8)
  (if ((←((pure (((BitVec.access fpcr enable) : BitVec 1) == 1#1)) <&&> (do
       (pure (! (← (HaveSME ())))) <||> (do
         (pure ((← readReg PSTATE).SM == 0#1))) <||> (do
         (IsFullA64Enabled ()))))) : Bool)
  then
    (do let accumulated_exceptions ← (( do (GetAccumulatedFPExceptions ()) ) : SailM (BitVec 8) )
        let accumulated_exceptions : (BitVec 8) := (BitVec.update accumulated_exceptions cumul (Bit 1#1))
        (if ((← (__IMPDEF_boolean "Support trapping of floating-point exceptions")) : Bool)
        then
          (do (if ((← (UsingAArch32 ())) : Bool)
              then (do (AArch32_FPTrappedException accumulated_exceptions))
              else
                (do let is_ase ← (( do (IsASEInstruction ()) ) : SailM Bool )
                    (AArch64_FPTrappedException is_ase accumulated_exceptions))))
        else (do (pure (SetAccumulatedFPExceptions accumulated_exceptions)))))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (Mk_FPSCR_Type (Sail.BitVec.updateSubrange (← (FPSCR_read__1 ())) cumul cumul 1#1))))
        else (do writeReg FPSR (BitVec.update (← readReg FPSR) cumul (Bit 1#1))))))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPZero (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15627.38-15627.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Zeros (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

def HaveAltFP (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AFP)

/-- Type quantifiers: N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem N [16, 32, 64] -/
def FPRoundBase__1 (op : real) (fpcr : (BitVec 64)) (rounding : FPRounding) (isbfloat16 : Bool) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := SailME.run do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15647.38-15647.39"
  sail_assert (bne op (0)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15648.20-15648.21"
  sail_assert (bne rounding FPRounding_TIEAWAY) "sail-arm/arm-v9.4-a/src/v8_base.sail:15649.41-15649.42"
  let result ← (( do (undefined_bitvector N) ) : SailME (BitVec N) (BitVec N) )
  let minimum_exp ← (( do (undefined_int ()) ) : SailME (BitVec N) Int )
  let F : Int := 7
  let E : Int := 5
  let (E, F, minimum_exp) : (Int × Int × Int) :=
    if ((N == 16) : Bool)
    then
      (let minimum_exp : Int := (Neg.neg 14)
      let E : Int := 5
      let F : Int := 10
      (E, F, minimum_exp))
    else
      (let (E, F, minimum_exp) : (Int × Int × Int) :=
        if (((N == 32) && isbfloat16) : Bool)
        then
          (let minimum_exp : Int := (Neg.neg 126)
          let E : Int := 8
          let F : Int := 7
          (E, F, minimum_exp))
        else
          (let (E, F, minimum_exp) : (Int × Int × Int) :=
            if ((N == 32) : Bool)
            then
              (let minimum_exp : Int := (Neg.neg 126)
              let E : Int := 8
              let F : Int := 23
              (E, F, minimum_exp))
            else
              (let minimum_exp : Int := (Neg.neg 1022)
              let E : Int := 11
              let F : Int := 52
              (E, F, minimum_exp))
          (E, F, minimum_exp))
      (E, F, minimum_exp))
  let minimum_exp := minimum_exp
  let F := F
  let E := E
  let sign ← (( do (undefined_bitvector 1) ) : SailME (BitVec N) (BitVec 1) )
  let mantissa ← (( do (undefined_real ()) ) : SailME (BitVec N) real )
  let (mantissa, sign) : (real × (BitVec 1)) :=
    if ((lt_real op (0)) : Bool)
    then
      (let sign : (BitVec 1) := 1#1
      let mantissa : real := (neg_real op)
      (mantissa, sign))
    else
      (let sign : (BitVec 1) := 0#1
      let mantissa : real := op
      (mantissa, sign))
  let exponent : Int := 0
  let (exponent, mantissa) ← (( do
    let mut loop_vars := (exponent, mantissa)
    while (λ (exponent, mantissa) => (lt_real mantissa (1))) loop_vars do
      let (exponent, mantissa) := loop_vars
      loop_vars :=
        (let mantissa : real := (mult_real mantissa (2))
        let exponent : Int := (exponent -i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars) ) : SailME (BitVec N) (Int × real) )
  let (exponent, mantissa) ← (( do
    let mut loop_vars_1 := (exponent, mantissa)
    while (λ (exponent, mantissa) => (gteq_real mantissa (2))) loop_vars_1 do
      let (exponent, mantissa) := loop_vars_1
      loop_vars_1 :=
        (let mantissa : real := (div_real mantissa (2))
        let exponent : Int := (exponent +i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars_1) ) : SailME (BitVec N) (Int × real) )
  let exponent := exponent
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailME (BitVec N) Bool )
  (if ((((! altfp) && ((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16)))) && (exponent <b minimum_exp)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (_update_FPSCR_Type_UFC (← (FPSCR_read__1 ())) 1#1)))
        else
          (do (if (fpexc : Bool)
              then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1))
              else (do (pure ())))))
        (FPZero sign N))
  else
    (do let biased_exp_unconstrained : Int := ((exponent -i minimum_exp) +i 1)
        let int_mant_unconstrained : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error_unconstrained : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant_unconstrained))
        let biased_exp : Int := (Max.max ((exponent -i minimum_exp) +i 1) 0)
        let mantissa : real :=
          if ((biased_exp == 0) : Bool)
          then (div_real mantissa (real_power (2) (minimum_exp -i exponent)))
          else mantissa
        let mantissa := mantissa
        let int_mant : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant))
        let trapped_UF ← (( do (pure ((_get_FPCRType_UFE fpcr) == 1#1)) <&&> (do (pure (! (← (InStreamingMode ())))) <||> (do (IsFullA64Enabled ()))) ) : SailME (BitVec N) Bool )
        (if ((((! altfp) && (biased_exp == 0)) && ((bne error (0)) || trapped_UF)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Underflow fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        let round_up_unconstrained ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let round_up ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let overflow_to_inf ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let (overflow_to_inf, round_up) ← (( do
          (if (altfp : Bool)
          then
            (do let (overflow_to_inf, round_up, round_up_unconstrained) : (Bool × Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up_unconstrained : Bool := ((gt_real error_unconstrained (1/2)) || ((eq_real error_unconstrained (1/2)) && (((integer_access int_mant_unconstrained 0) : BitVec 1) == 1#1)))
                    let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_POSINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 0#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_NEGINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 1#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ZERO =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ODD =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | _ => (overflow_to_inf, round_up, round_up_unconstrained)
                let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                  if (round_up_unconstrained : Bool)
                  then
                    (let int_mant_unconstrained : Int := (int_mant_unconstrained +i 1)
                    let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                      if ((int_mant_unconstrained == (2 ^i (F +i 1))) : Bool)
                      then
                        (let biased_exp_unconstrained : Int := (biased_exp_unconstrained +i 1)
                        let int_mant_unconstrained : Int := (fdiv_int int_mant_unconstrained 2)
                        (biased_exp_unconstrained, int_mant_unconstrained))
                      else (biased_exp_unconstrained, int_mant_unconstrained)
                    (biased_exp_unconstrained, int_mant_unconstrained))
                  else (biased_exp_unconstrained, int_mant_unconstrained)
                let int_mant_unconstrained := int_mant_unconstrained
                let biased_exp_unconstrained := biased_exp_unconstrained
                (if (((biased_exp_unconstrained <b 1) && (int_mant_unconstrained != 0)) : Bool)
                then
                  (do (if (((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16))) : Bool)
                      then
                        (do SailME.throw (← do
                                (if (fpexc : Bool)
                                then
                                  (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1)
                                      (FPProcessException FPExc_Inexact fpcr))
                                else (do (pure ())))
                                (FPZero sign N)))
                      else
                        (do (if (((bne error (0)) || trapped_UF) : Bool)
                            then
                              (do (if (fpexc : Bool)
                                  then (do (FPProcessException FPExc_Underflow fpcr))
                                  else (do (pure ()))))
                            else (do (pure ()))))))
                else (do (pure ())))
                (pure (overflow_to_inf, round_up)))
          else
            (do let (overflow_to_inf, round_up) : (Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up))
                  | .FPRounding_POSINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_NEGINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_ZERO =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | .FPRounding_ODD =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | _ => (overflow_to_inf, round_up)
                (pure (overflow_to_inf, round_up)))) ) : SailME (BitVec N) (Bool × Bool) )
        let (biased_exp, int_mant) : (Int × Int) :=
          if (round_up : Bool)
          then
            (let int_mant : Int := (int_mant +i 1)
            let biased_exp : Int :=
              if ((int_mant == (2 ^i F)) : Bool)
              then 1
              else biased_exp
            let (biased_exp, int_mant) : (Int × Int) :=
              if ((int_mant == (2 ^i (F +i 1))) : Bool)
              then
                (let biased_exp : Int := (biased_exp +i 1)
                let int_mant : Int := (fdiv_int int_mant 2)
                (biased_exp, int_mant))
              else (biased_exp, int_mant)
            (biased_exp, int_mant))
          else (biased_exp, int_mant)
        let biased_exp := biased_exp
        let int_mant : Int :=
          if (((bne error (0)) && (BEq.beq rounding FPRounding_ODD)) : Bool)
          then (integer_update_subrange int_mant 0 0 1#1)
          else int_mant
        let int_mant := int_mant
        let (error, result) ← (( do
          (if (((N != 16) || ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
          then
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b ((2 ^i E) -i 1)) : Bool)
                  then
                    (do let result ←
                          (if (overflow_to_inf : Bool)
                          then (do (FPInfinity sign N))
                          else (do (FPMaxNormal sign N)))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_Overflow fpcr))
                        else (do (pure ())))
                        let error : real := (1)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15829.54-15829.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))
          else
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b (2 ^i E)) : Bool)
                  then
                    (do let result : (BitVec N) := (sign +++ (Ones (n := (N -i 1))))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_InvalidOp fpcr))
                        else (do (pure ())))
                        let error : real := (0)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15840.54-15840.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
        (if ((bne error (0)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Inexact fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        (pure result)))

def FPDecodeRounding (rmode : (BitVec 2)) : SailM FPRounding := do
  match rmode with
  | 0b00 => (pure FPRounding_TIEEVEN)
  | 0b01 => (pure FPRounding_POSINF)
  | 0b10 => (pure FPRounding_NEGINF)
  | 0b11 => (pure FPRounding_ZERO)
  | _ => (do (undefined_FPRounding ()))

def FPRoundingMode (fpcr : (BitVec 64)) : SailM FPRounding := do
  (FPDecodeRounding (_get_FPCRType_RMode fpcr))

/-- Type quantifiers: N : Nat, k_fpexc : Bool, List.elem N [16, 32, 64] -/
def FPRound__2 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := do
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let isbfloat16 : Bool := false
  (FPRoundBase__1 op fpcr rounding isbfloat16 fpexc N)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRound__1 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  let fpexc : Bool := true
  (FPRound__2 op fpcr_in rounding fpexc N)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRound (op : real) (fpcr : (BitVec 64)) (N : Nat) : SailM (BitVec N) := do
  (FPRound__1 op fpcr (← (FPRoundingMode fpcr)) N)

/-- Type quantifiers: k_M : Nat, N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem N [16, 32, 64] ∧ List.elem k_M [16, 32, 64] -/
def FixedToFP (op : (BitVec k_M)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15912.38-15912.39"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15913.41-15913.42"
  let result ← (( do (undefined_bitvector N) ) : SailM (BitVec N) )
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15915.21-15915.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:15916.37-15916.38"
  let int_operand ← (( do (asl_Int op is_unsigned) ) : SailM Int )
  let real_operand : real := (div_real (to_real int_operand) (real_power (2) fbits))
  (if ((eq_real real_operand (0)) : Bool)
  then (do (FPZero 0#1 N))
  else (do (FPRound__1 real_operand fpcr rounding N)))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) (isbfloat16 : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let exp16 ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  let exp64 ← (( do (undefined_bitvector 11) ) : SailM (BitVec 11) )
  let frac16 ← (( do (undefined_bitvector 10) ) : SailM (BitVec 10) )
  let frac64 ← (( do (undefined_bitvector 52) ) : SailM (BitVec 52) )
  sail_assert (((Sail.BitVec.length fpval) == 16) || (((Sail.BitVec.length fpval) == 32) || ((Sail.BitVec.length fpval) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15949.41-15949.42"
  let fpcr : FPCRType := fpcr_in
  let altfp ← (( do (HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))) ) : SailM Bool )
  let fiz : Bool := (altfp && ((_get_FPCRType_FIZ fpcr) == 1#1))
  let fz : Bool := (((_get_FPCRType_FZ fpcr) == 1#1) && (! (altfp && ((_get_FPCRType_AH fpcr) == 1#1))))
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let (fptype, sign, value_name) ← (( do
    (if ((((Sail.BitVec.length fpval) == 16) && (! isbfloat16)) : Bool)
    then
      (do let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
          let exp16 : (BitVec 5) := (Sail.BitVec.extractLsb fpval 14 10)
          let frac16 : (BitVec 10) := (Sail.BitVec.extractLsb fpval 9 0)
          let (fptype, value_name) : (FPType × real) :=
            if ((IsZero exp16) : Bool)
            then
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsZero frac16) || ((_get_FPCRType_FZ16 fpcr) == 1#1)) : Bool)
                then
                  (let fptype : FPType := FPType_Zero
                  let value_name : real := (0)
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Denormal
                  let value_name : real := (mult_real (real_power (2) (Neg.neg 14)) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10))))
                  (fptype, value_name))
              (fptype, value_name))
            else
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsOnes exp16) && ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
                then
                  (let (fptype, value_name) : (FPType × real) :=
                    if ((IsZero frac16) : Bool)
                    then
                      (let fptype : FPType := FPType_Infinity
                      let value_name : real := (real_power (2) 1000000)
                      (fptype, value_name))
                    else
                      (let fptype : FPType :=
                        if ((((BitVec.access frac16 9) : BitVec 1) == 1#1) : Bool)
                        then FPType_QNaN
                        else FPType_SNaN
                      let value_name : real := (0)
                      (fptype, value_name))
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Nonzero
                  let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp16) -i 15)) (add_real (1) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10)))))
                  (fptype, value_name))
              (fptype, value_name))
          (pure (fptype, sign, value_name)))
    else
      (do let (fptype, sign, value_name) ← (( do
            (if ((((Sail.BitVec.length fpval) == 32) || isbfloat16) : Bool)
            then
              (do let exp32 ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
                  let frac32 ← (( do (undefined_bitvector 23) ) : SailM (BitVec 23) )
                  let (exp32, frac32, sign) : ((BitVec 8) × (BitVec 23) × (BitVec 1)) :=
                    if (isbfloat16 : Bool)
                    then
                      (let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 14 7)
                      let frac32 : (BitVec 23) := ((Sail.BitVec.extractLsb fpval 6 0) +++ (Zeros (n := 16)))
                      (exp32, frac32, sign))
                    else
                      (let sign : (BitVec 1) := ((BitVec.access fpval 31) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 30 23)
                      let frac32 : (BitVec 23) := (Sail.BitVec.extractLsb fpval 22 0)
                      (exp32, frac32, sign))
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp32) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac32) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 126)) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp32) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac32) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac32 22) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp32) -i 127)) (add_real (1) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))
            else
              (do let sign : (BitVec 1) := ((BitVec.access fpval 63) : BitVec 1)
                  let exp64 : (BitVec 11) := (Sail.BitVec.extractLsb fpval 62 52)
                  let frac64 : (BitVec 52) := (Sail.BitVec.extractLsb fpval 51 0)
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp64) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac64) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 1022)) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp64) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac64) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac64 51) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp64) -i 1023)) (add_real (1) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
          (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
  let value_name : real :=
    if ((sign == 1#1) : Bool)
    then (neg_real value_name)
    else value_name
  let value_name := value_name
  (pure (fptype, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase (fpval : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let isbfloat16 : Bool := false
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase__1 fpval fpcr fpexc isbfloat16)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPUnpack (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let fpexc : Bool := true
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpack__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPAbs (op : (BitVec k_N)) : SailM (BitVec k_N) := SailME.run do
  let fptype ← (( do (undefined_FPType ()) ) : SailME (BitVec k_N) FPType )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16099.41-16099.42"
  (if ((←((pure (! (← (UsingAArch32 ())))) <&&> (do
       (HaveAltFP ())))) : Bool)
  then
    (do let fpcr ← (( do (FPCR_read ()) ) : SailME (BitVec k_N) FPCRType )
        (if (((_get_FPCRType_AH fpcr) == 1#1) : Bool)
        then
          (do let fptype ← (( do
                let (__tup_0, _, _) ← do (FPUnpack__1 op fpcr false)
                (pure __tup_0) ) : SailME (BitVec k_N) FPType )
              (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
              then (do SailME.throw (op : (BitVec k_N)))
              else (do (pure ()))))
        else (do (pure ()))))
  else (do (pure ())))
  (pure (0#1 +++ (Sail.BitVec.extractLsb op ((Sail.BitVec.length op) -i 2) 0)))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPDefaultNaN__1 (fpcr : (BitVec 64)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16128.38-16128.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let sign ← (( do
    (if ((←((HaveAltFP ()) <&&> (do
         (pure (! (← (UsingAArch32 ()))))))) : Bool)
    then (do (pure (_get_FPCRType_AH fpcr)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (1#1 +++ (Zeros (n := (F -i 1))))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Int -/
def FPProcessDenorms (type1 : FPType) (type2 : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && ((BEq.beq type1 FPType_Denormal) || (BEq.beq type2 FPType_Denormal))) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaN__1 (fptype : FPType) (op : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16162.41-16162.42"
  sail_assert ((BEq.beq fptype FPType_QNaN) || (BEq.beq fptype FPType_SNaN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:16163.56-16163.57"
  let topfrac : Int := 9
  let topfrac : Int :=
    match (Sail.BitVec.length op) with
    | 16 => 9
    | 32 => 22
    | 64 => 51
    | _ => topfrac
  let topfrac := topfrac
  let result : (BitVec k_N) := op
  let result ← (( do
    (if ((BEq.beq fptype FPType_SNaN) : Bool)
    then
      (do sail_assert ((0 ≤b topfrac) && (topfrac <b (Sail.BitVec.length result))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16180.58-16180.59"
          let result : (BitVec k_N) := (BitVec.update result topfrac (Bit 1#1))
          (if (fpexc : Bool)
          then (do (FPProcessException FPExc_InvalidOp fpcr))
          else (do (pure ())))
          (pure result))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if (((_get_FPCRType_DN fpcr) == 1#1) : Bool)
  then (do (FPDefaultNaN__1 fpcr (Sail.BitVec.length result)))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPProcessNaN (fptype : FPType) (op : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPProcessNaN__1 fptype op fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs__1 (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16206.41-16206.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let any_snan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN))
  let type_nan : FPType :=
    if (any_snan : Bool)
    then FPType_SNaN
    else FPType_QNaN
  let (done, result) ← (( do
    (if (((altfp && op1_nan) && op2_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPProcessNaN__1 type_nan op1 fpcr fpexc)
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if ((BEq.beq type1 FPType_SNaN) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_QNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                          (pure (done, result)))
                                    else
                                      (do let done : Bool := false
                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (Bool × (BitVec k_N)) := do
  let fpexc : Bool := true
  (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPAdd__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16263.41-16263.42"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) && (sign1 == (Complement.complement sign2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((inf1 && (sign1 == 0#1)) || (inf2 && (sign2 == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((inf1 && (sign1 == 1#1)) || (inf2 && (sign2 == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zero1 && zero2) && (sign1 == sign2)) : Bool)
                            then (do (FPZero sign1 (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real value1_name value2_name)
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (fpexc : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPAdd (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPAdd__1 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_signal_nans : Bool, List.elem k_N [16, 32, 64] -/
def FPCompare (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (signal_nans : Bool) (fpcr : (BitVec 64)) : SailM (BitVec 4) := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16326.41-16326.42"
  let (type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (type1, value1_name)) ) : SailM (FPType × real) )
  let (type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (type2, value2_name)) ) : SailM (FPType × real) )
  let result ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))) : Bool)
  then
    (do let result : (BitVec 4) := 0b0011#4
        (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) || signal_nans) : Bool)
        then (do (FPProcessException FPExc_InvalidOp fpcr))
        else (do (pure ())))
        (pure result))
  else
    (do let result : (BitVec 4) :=
          if ((eq_real value1_name value2_name) : Bool)
          then 0b0110#4
          else
            (if ((lt_real value1_name value2_name) : Bool)
            then 0b1000#4
            else 0b0010#4)
        (FPProcessDenorms type1 type2 (Sail.BitVec.length op2) fpcr)
        (pure result)))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem k_N [16, 32, 64] ∧ List.elem M [16, 32, 64] -/
def FPConvertNaN (op : (BitVec k_N)) (M : Nat) : SailM (BitVec M) := do
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16429.41-16429.42"
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16430.38-16430.39"
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let frac ← (( do (undefined_bitvector 51) ) : SailM (BitVec 51) )
  let sign : (BitVec 1) := ((BitVec.access op ((Sail.BitVec.length op) -i 1)) : BitVec 1)
  let frac : (BitVec 51) :=
    match (Sail.BitVec.length op) with
    | 64 => (Sail.BitVec.extractLsb op 50 0)
    | 32 => ((Sail.BitVec.extractLsb op 21 0) +++ (Zeros (n := 29)))
    | 16 => ((Sail.BitVec.extractLsb op 8 0) +++ (Zeros (n := 42)))
    | _ => frac
  match M with
  | 64 => (pure ((sign +++ (Ones (n := (M -i 52)))) +++ frac))
  | 32 => (pure ((sign +++ (Ones (n := (M -i 23)))) +++ (Sail.BitVec.extractLsb frac 50 29)))
  | 16 => (pure ((sign +++ (Ones (n := (M -i 10)))) +++ (Sail.BitVec.extractLsb frac 50 42)))
  | _ => (pure result)

/-- Type quantifiers: N : Int -/
def FPProcessDenorm (fptype : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && (BEq.beq fptype FPType_Denormal)) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRoundCV (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 19 19 0#1)
  let fpexc : Bool := true
  let isbfloat16 : Bool := false
  (FPRoundBase__1 op fpcr rounding isbfloat16 fpexc N)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPUnpackCV (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 19 19 0#1)
  let fpexc : Bool := true
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem M [16, 32, 64] ∧ List.elem k_N [16, 32, 64] -/
def FPConvert (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (M : Nat) : SailM (BitVec M) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16508.38-16508.39"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16509.41-16509.42"
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackCV op fpcr)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let alt_hp : Bool := ((M == 16) && ((_get_FPCRType_AHP fpcr) == 1#1))
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then
    (do let result ← (( do
          (if (alt_hp : Bool)
          then (do (FPZero sign M))
          else
            (do (if (((_get_FPCRType_DN fpcr) == 1#1) : Bool)
                then (do (FPDefaultNaN__1 fpcr M))
                else (do (FPConvertNaN op M))))) ) : SailM (BitVec M) )
        (if (((BEq.beq fptype FPType_SNaN) || alt_hp) : Bool)
        then (do (FPProcessException FPExc_InvalidOp fpcr))
        else (do (pure ())))
        (pure result))
  else
    (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
        then
          (do (if (alt_hp : Bool)
              then
                (do let result : (BitVec M) := (sign +++ (Ones (n := (M -i 1))))
                    (FPProcessException FPExc_InvalidOp fpcr)
                    (pure result))
              else (do (FPInfinity sign M))))
        else
          (do (if ((BEq.beq fptype FPType_Zero) : Bool)
              then (do (FPZero sign M))
              else
                (do let result ← (FPRoundCV value_name fpcr rounding M)
                    (FPProcessDenorm fptype (Sail.BitVec.length op) fpcr)
                    (pure result)))))))

/-- Type quantifiers: M : Nat, k_N : Nat, List.elem M [16, 32, 64] ∧ List.elem k_N [16, 32, 64] -/
def FPConvert__1 (op : (BitVec k_N)) (fpcr : (BitVec 64)) (M : Nat) : SailM (BitVec M) := do
  (FPConvert op fpcr (← (FPRoundingMode fpcr)) M)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPDiv (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16583.41-16583.42"
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) || (zero1 && zero2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (FPProcessException FPExc_InvalidOp fpcr)
                (pure result))
          else
            (do (if ((inf1 || zero2) : Bool)
                then
                  (do let result ← (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result))
                      (if ((! inf1) : Bool)
                      then (do (FPProcessException FPExc_DivideByZero fpcr))
                      else (do (pure ())))
                      (pure result))
                else
                  (do (if ((zero1 || inf2) : Bool)
                      then (do (FPZero (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                      else (do (FPRound (div_real value1_name value2_name) fpcr (Sail.BitVec.length result)))))))) ) : SailM (BitVec k_N) )
        (if ((! zero2) : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMax__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16634.41-16634.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((gt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 &&& sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMax (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (FPMax__1 op1 op2 fpcr altfp)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMaxNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16680.41-16680.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 1#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 1#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMax__1 op1 op2 fpcr altfmaxfmin)

def IsMerging (fpcr : (BitVec 64)) : SailM Bool := do
  let nep ← (( do
    (if ((←((HaveSME ()) <&&> (do
         (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do
         (pure (! (← (IsFullA64Enabled ()))))))) : Bool)
    then (do (pure 0#1))
    else (do (pure (_get_FPCRType_NEP fpcr)))) ) : SailM (BitVec 1) )
  (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && (nep == 1#1)))

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMin__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16735.41-16735.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((lt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 ||| sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMin (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (FPMin__1 op1 op2 fpcr altfp)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMinNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16782.41-16782.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 0#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 0#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMin__1 op1 op2 fpcr altfmaxfmin)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMul (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16824.41-16824.42"
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && zero2) || (zero1 && inf2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (FPProcessException FPExc_InvalidOp fpcr)
                (pure result))
          else
            (do (if ((inf1 || inf2) : Bool)
                then (do (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                else
                  (do (if ((zero1 || zero2) : Bool)
                      then (do (FPZero (sign1 ^^^ sign2) (Sail.BitVec.length result)))
                      else (do (FPRound (mult_real value1_name value2_name) fpcr (Sail.BitVec.length result)))))))) ) : SailM (BitVec k_N) )
        (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: N : Int -/
def FPProcessDenorms3 (type1 : FPType) (type2 : FPType) (type3 : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && (((BEq.beq type1 FPType_Denormal) || (BEq.beq type2 FPType_Denormal)) || (BEq.beq type3 FPType_Denormal))) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs3__1 (type1 : FPType) (type2 : FPType) (type3 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (op3 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op3) == 16) || (((Sail.BitVec.length op3) == 32) || ((Sail.BitVec.length op3) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16864.41-16864.42"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op3)) ) : SailM (BitVec k_N) )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let op3_nan : Bool := ((BEq.beq type3 FPType_SNaN) || (BEq.beq type3 FPType_QNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let type_nan ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type_nan : FPType :=
    if (altfp : Bool)
    then
      (if ((((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN)) || (BEq.beq type3 FPType_SNaN)) : Bool)
      then FPType_SNaN
      else FPType_QNaN)
    else type_nan
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let (done, result) ← (( do
    (if ((((altfp && op1_nan) && op2_nan) && op3_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPProcessNaN__1 type_nan op2 fpcr fpexc)
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if (((altfp && op2_nan) && (op1_nan || op3_nan)) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPProcessNaN__1 type_nan op2 fpcr fpexc)
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if (((altfp && op3_nan) && op1_nan) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPProcessNaN__1 type_nan op3 fpcr fpexc)
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_SNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                          (pure (done, result)))
                                    else
                                      (do let (done, result) ← (( do
                                            (if ((BEq.beq type3 FPType_SNaN) : Bool)
                                            then
                                              (do let done : Bool := true
                                                  let result ← (FPProcessNaN__1 type3 op3 fpcr fpexc)
                                                  (pure (done, result)))
                                            else
                                              (do let (done, result) ← (( do
                                                    (if ((BEq.beq type1 FPType_QNaN) : Bool)
                                                    then
                                                      (do let done : Bool := true
                                                          let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                                          (pure (done, result)))
                                                    else
                                                      (do let (done, result) ← (( do
                                                            (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                                            then
                                                              (do let done : Bool := true
                                                                  let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                                                  (pure (done, result)))
                                                            else
                                                              (do let (done, result) ← (( do
                                                                    (if ((BEq.beq type3 FPType_QNaN) : Bool)
                                                                    then
                                                                      (do let done : Bool := true
                                                                          let result ← (FPProcessNaN__1 type3 op3 fpcr fpexc)
                                                                          (pure (done, result)))
                                                                    else
                                                                      (do let done : Bool := false
                                                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPMulAdd__1 (addend : (BitVec k_N)) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let infA ← (( do (undefined_bool ()) ) : SailM Bool )
  let infP ← (( do (undefined_bool ()) ) : SailM Bool )
  let invalidop ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signA ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let signP ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let typeA ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let valueA_name ← (( do (undefined_real ()) ) : SailM real )
  let zeroA ← (( do (undefined_bool ()) ) : SailM Bool )
  let zeroP ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16945.41-16945.42"
  let (signA, typeA, valueA_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 addend fpcr fpexc)
    let typeA : FPType := tup__0
    let signA : (BitVec 1) := tup__1
    let valueA_name : real := tup__2
    (pure (signA, typeA, valueA_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
  let zero1 : Bool := (BEq.beq type1 FPType_Zero)
  let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
  let zero2 : Bool := (BEq.beq type2 FPType_Zero)
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs3__1 typeA type1 type2 addend op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  let result ← (( do
    (if ((! ((←((HaveAltFP ()) <&&> (do
             (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) : Bool)
    then
      (do (if (((BEq.beq typeA FPType_QNaN) && ((inf1 && zero2) || (zero1 && inf2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else (do (pure result))))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if ((! done) : Bool)
  then
    (do let infA : Bool := (BEq.beq typeA FPType_Infinity)
        let zeroA : Bool := (BEq.beq typeA FPType_Zero)
        let signP : (BitVec 1) := (sign1 ^^^ sign2)
        let infP : Bool := (inf1 || inf2)
        let zeroP : Bool := (zero1 || zero2)
        let invalidop : Bool := (((inf1 && zero2) || (zero1 && inf2)) || ((infA && infP) && (signA != signP)))
        let result ← (( do
          (if (invalidop : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((infA && (signA == 0#1)) || (infP && (signP == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((infA && (signA == 1#1)) || (infP && (signP == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zeroA && zeroP) && (signA == signP)) : Bool)
                            then (do (FPZero signA (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real valueA_name (mult_real value1_name value2_name))
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (((! invalidop) && fpexc) : Bool)
        then (do (FPProcessDenorms3 typeA type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMulAdd (addend : (BitVec k_N)) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPMulAdd__1 addend op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPNeg (op : (BitVec k_N)) : SailM (BitVec k_N) := SailME.run do
  let fptype ← (( do (undefined_FPType ()) ) : SailME (BitVec k_N) FPType )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17222.41-17222.42"
  (if ((←((pure (! (← (UsingAArch32 ())))) <&&> (do
       (HaveAltFP ())))) : Bool)
  then
    (do let fpcr ← (( do (FPCR_read ()) ) : SailME (BitVec k_N) FPCRType )
        (if (((_get_FPCRType_AH fpcr) == 1#1) : Bool)
        then
          (do let fptype ← (( do
                let (__tup_0, _, _) ← do (FPUnpack__1 op fpcr false)
                (pure __tup_0) ) : SailME (BitVec k_N) FPType )
              (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
              then (do SailME.throw (op : (BitVec k_N)))
              else (do (pure ()))))
        else (do (pure ()))))
  else (do (pure ())))
  (pure ((Complement.complement ((BitVec.access op ((Sail.BitVec.length op) -i 1)) : BitVec 1)) +++ (Sail.BitVec.extractLsb op ((Sail.BitVec.length op) -i 2) 0)))

/-- Type quantifiers: k_N : Nat, k_exact : Bool, List.elem k_N [16, 32, 64] -/
def FPRoundInt (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (exact : Bool) : SailM (BitVec k_N) := do
  let error ← (( do (undefined_real ()) ) : SailM real )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let int_result ← (( do (undefined_int ()) ) : SailM Int )
  let real_result ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17470.37-17470.38"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17471.41-17471.42"
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN fptype op fpcr))
  else
    (do (if ((BEq.beq fptype FPType_Infinity) : Bool)
        then (do (FPInfinity sign (Sail.BitVec.length result)))
        else
          (do (if ((BEq.beq fptype FPType_Zero) : Bool)
              then (do (FPZero sign (Sail.BitVec.length result)))
              else
                (do let int_result : Int := (round_down value_name)
                    let error : real := (sub_real value_name (to_real int_result))
                    let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
                    let round_up : Bool :=
                      match rounding with
                      | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
                      | .FPRounding_POSINF => (bne error (0))
                      | .FPRounding_NEGINF => false
                      | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
                      | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
                      | _ => round_up
                    let int_result : Int :=
                      if (round_up : Bool)
                      then (int_result +i 1)
                      else int_result
                    let int_result := int_result
                    let real_result : real := (to_real int_result)
                    let result ← (( do
                      (if ((eq_real real_result (0)) : Bool)
                      then (do (FPZero sign (Sail.BitVec.length result)))
                      else (do (FPRound__1 real_result fpcr FPRounding_ZERO (Sail.BitVec.length result)))) ) : SailM (BitVec k_N) )
                    (if (((bne error (0)) && exact) : Bool)
                    then (do (FPProcessException FPExc_Inexact fpcr))
                    else (do (pure ())))
                    (pure result)))))))

/-- Type quantifiers: k_N : Nat, intsize : Int, List.elem k_N [32, 64] -/
def FPRoundIntN (op : (BitVec k_N)) (fpcr : (BitVec 64)) (rounding : FPRounding) (intsize : Int) : SailM (BitVec k_N) := do
  let error ← (( do (undefined_real ()) ) : SailM real )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let int_result ← (( do (undefined_int ()) ) : SailM Int )
  let overflow ← (( do (undefined_bool ()) ) : SailM Bool )
  let real_result ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17533.37-17533.38"
  sail_assert (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17534.30-17534.31"
  sail_assert ((intsize == 32) || (intsize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17535.40-17535.41"
  let exp ← (( do (undefined_int ()) ) : SailM Int )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let E :=
    if (((Sail.BitVec.length result) == 32) : Bool)
    then 8
    else 11
  let F := ((Sail.BitVec.length result) -i (E +i 1))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (if (((BEq.beq fptype FPType_SNaN) || ((BEq.beq fptype FPType_QNaN) || (BEq.beq fptype FPType_Infinity))) : Bool)
  then
    (do let result : (BitVec k_N) :=
          if (((Sail.BitVec.length result) == 32) : Bool)
          then
            (let exp := (126 +i intsize)
            ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
          else
            (let exp := (1022 +i intsize)
            ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
        (FPProcessException FPExc_InvalidOp fpcr)
        (pure result))
  else
    (do (if ((BEq.beq fptype FPType_Zero) : Bool)
        then (do (FPZero sign (Sail.BitVec.length result)))
        else
          (do let int_result : Int := (round_down value_name)
              let error : real := (sub_real value_name (to_real int_result))
              let round_up : Bool :=
                match rounding with
                | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
                | .FPRounding_POSINF => (bne error (0))
                | .FPRounding_NEGINF => false
                | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
                | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
                | _ => round_up
              let int_result : Int :=
                if (round_up : Bool)
                then (int_result +i 1)
                else int_result
              let int_result := int_result
              let overflow : Bool := ((int_result >b ((2 ^i (intsize -i 1)) -i 1)) || (int_result <b ((Neg.neg 1) *i (2 ^i (intsize -i 1)))))
              let (error, result) ← (( do
                (if (overflow : Bool)
                then
                  (do let result : (BitVec k_N) :=
                        if (((Sail.BitVec.length result) == 32) : Bool)
                        then
                          (let exp := (126 +i intsize)
                          ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
                        else
                          (let exp := (1022 +i intsize)
                          ((1#1 +++ (integer_subrange exp (E -i 1) 0)) +++ (Zeros (n := F))))
                      (FPProcessException FPExc_InvalidOp fpcr)
                      let error : real := (0)
                      (pure (error, result)))
                else
                  (do let real_result : real := (to_real int_result)
                      let result ← (( do
                        (if ((eq_real real_result (0)) : Bool)
                        then (do (FPZero sign (Sail.BitVec.length result)))
                        else (do (FPRound__1 real_result fpcr FPRounding_ZERO (Sail.BitVec.length result)))) ) : SailM (BitVec k_N) )
                      (pure (error, result)))) ) : SailM (real × (BitVec k_N)) )
              (if ((bne error (0)) : Bool)
              then (do (FPProcessException FPExc_Inexact fpcr))
              else (do (pure ())))
              (pure result)))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPSqrt (op : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17724.41-17724.42"
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op fpcr)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op)) ) : SailM (BitVec k_N) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessNaN fptype op fpcr))
  else
    (do (if ((BEq.beq fptype FPType_Zero) : Bool)
        then (do (FPZero sign (Sail.BitVec.length result)))
        else
          (do (if (((BEq.beq fptype FPType_Infinity) && (sign == 0#1)) : Bool)
              then (do (FPInfinity sign (Sail.BitVec.length result)))
              else
                (do (if ((sign == 1#1) : Bool)
                    then
                      (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                          (FPProcessException FPExc_InvalidOp fpcr)
                          (pure result))
                    else
                      (do let result ← (FPRound (sqrt_real value_name) fpcr (Sail.BitVec.length result))
                          (FPProcessDenorm fptype (Sail.BitVec.length result) fpcr)
                          (pure result)))))))))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPSub__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17770.41-17770.42"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) && (sign1 == sign2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((inf1 && (sign1 == 0#1)) || (inf2 && (sign2 == 1#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((inf1 && (sign1 == 1#1)) || (inf2 && (sign2 == 0#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zero1 && zero2) && (sign1 == (Complement.complement sign2))) : Bool)
                            then (do (FPZero sign1 (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (sub_real value1_name value2_name)
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (fpexc : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPSub (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPSub__1 op1 op2 fpcr fpexc)

/-- Type quantifiers: M : Nat, k_N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem k_N [16, 32, 64] ∧ List.elem M [16, 32, 64] -/
def FPToFixed (op : (BitVec k_N)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (M : Nat) : SailM (BitVec M) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let overflow ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17844.41-17844.42"
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17845.38-17845.39"
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:17846.21-17846.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17847.37-17847.38"
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, value_name)) ) : SailM (FPType × real) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else (do (pure ())))
  let value_name : real := (mult_real value_name (real_power (2) fbits))
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let round_up : Bool :=
    match rounding with
    | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
    | .FPRounding_POSINF => (bne error (0))
    | .FPRounding_NEGINF => false
    | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
    | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
    | _ => round_up
  let int_result : Int :=
    if (round_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let (overflow, result) ← (( do
    let (tup__0, tup__1) ← do (SatQ int_result M is_unsigned)
    let result : (BitVec M) := tup__0
    let overflow : Bool := tup__1
    (pure (overflow, result)) ) : SailM (Bool × (BitVec M)) )
  (if (overflow : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else
    (do (if ((bne error (0)) : Bool)
        then (do (FPProcessException FPExc_Inexact fpcr))
        else (do (pure ())))))
  (pure result)

/-- Type quantifiers: k_Is64 : Bool, k_M : Nat, N : Nat, k_M = 64 ∧ N = 32 -/
def FPToFixedJS (op : (BitVec k_M)) (fpcr : (BitVec 64)) (Is64 : Bool) (N : Nat) : SailM ((BitVec N) × (BitVec 1)) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 64) && (N == 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17897.29-17897.30"
  let fpexc_idenorm ← (( do (pure (! ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1)))) ) : SailM Bool )
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc_idenorm)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let z : (BitVec 1) := 1#1
  let z ← (( do
    (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else (do (pure z))) ) : SailM (BitVec 1) )
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_it_up : Bool := ((bne error (0)) && (int_result <b 0))
  let int_result : Int :=
    if (round_it_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result : Int :=
    if ((int_result <b 0) : Bool)
    then (int_result -i ((2 ^i 32) *i (round_up (div_real (to_real int_result) (to_real (2 ^i 32))))))
    else (int_result -i ((2 ^i 32) *i (round_down (div_real (to_real int_result) (to_real (2 ^i 32))))))
  let z ← (( do
    (if (((int_result <b (Neg.neg (2 ^i 31))) || (int_result >b ((2 ^i 31) -i 1))) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else
      (do (if ((bne error (0)) : Bool)
          then
            (do (FPProcessException FPExc_Inexact fpcr)
                (pure 0#1))
          else
            (do (if (((sign == 1#1) && (eq_real value_name (0))) : Bool)
                then (do (pure 0#1))
                else
                  (do (if ((((sign == 0#1) && (eq_real value_name (0))) && (! (IsZero (Sail.BitVec.extractLsb op 51 0)))) : Bool)
                      then (do (pure 0#1))
                      else (do (pure z))))))))) ) : SailM (BitVec 1) )
  let result : Int :=
    if ((BEq.beq fptype FPType_Infinity) : Bool)
    then 0
    else result
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), z))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def VFPExpandImm (imm8 : (BitVec 8)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17939.38-17939.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := ((N -i E) -i 1)
  let sign : (BitVec 1) := ((BitVec.access imm8 7) : BitVec 1)
  let exp : (BitVec (1 + (E - 3) + 2)) := (((Complement.complement ((BitVec.access imm8 6) : BitVec 1)) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) (E -i 3))) +++ (Sail.BitVec.extractLsb imm8 5 4))
  let frac : (BitVec (4 + (F - 4))) := ((Sail.BitVec.extractLsb imm8 3 0) +++ (Zeros (n := (F -i 4))))
  (pure ((sign +++ exp) +++ frac))

def IsFault (addrdesc : AddressDescriptor) : Bool :=
  (bne addrdesc.fault.statuscode Fault_None)

def IsFault__1 (fault : Fault) : Bool :=
  (bne fault Fault_None)

def IsFault__2 (retstatus : PhysMemRetStatus) : Bool :=
  (bne retstatus.statuscode Fault_None)

def undefined_CNTHP_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHP_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_CNTHP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTV_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def undefined_CNTHP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTHP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTHP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHP_CTL ) : SailM CNTHP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHP_CTL_EL2) 0 32)))

def CNTHP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHP_CTL_Type := value_name
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHP_CTL r

def undefined_CNTHP_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHP_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTP_CTL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTP_CTL_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTP_CTL_NS ) : SailM CNTP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTP_CTL_EL0) 0 32)))

def CNTP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CNTP_CTL_Type ()) ) : SailM CNTP_CTL_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CNTP_CTL_S)
  else (do (CNTP_CTL_NS_read ())))

def CNTP_CTL_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTP_CTL_NS r

def CNTP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CNTP_CTL_S r)
  else (do (CNTP_CTL_NS_write r)))

def undefined_CNTP_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTP_CVAL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTV_CTL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTV_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTV_CVAL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHPS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHPS_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHPS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHPS_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHVS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHVS_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHVS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHVS_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHV_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHV_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHV_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHV_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTPS_CTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTPS_CTL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTPS_CVAL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTPS_CVAL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HaveCNTSCExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CNTSC)

def undefined_CNTKCTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTKCTL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveMPAMExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAM)

def Have16bitVMID (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_VMID16)

def AArch64_HaveHPDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HPDS)

def HaveCommonNotPrivateTransExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TTCNP)

def HaveExtendedExecuteNeverExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_XNX)

def Have52BitVAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LVA)

def Have52BitPAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LPA)

def HaveV82Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def HaveTrapLoadStoreMultipleDeviceExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSMAOC)

def HaveFJCVTZSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_JSCVT)

def HaveSmallTranslationTableExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TTST)

def HaveLSE2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE2)

def HaveSelfHostedTrace (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TRF)

def HaveBlockBBM (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BBM)

def Havev8p4Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p4)

def HaveStage2MemAttrControl (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2FWB)

def HaveIDSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_IDST)

def HaveFrintExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FRINTTS)

def HaveE0PDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_E0PD)

def HaveGTGExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_GTG)

def HaveMTEAsyncExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

def HaveMTEPermExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE_PERM)

def HaveDGHExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DGH)

def HaveFGTExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FGT)

def HavePMUv3p4 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p4)

def HaveDoPD (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoPD)

def Have56BitVAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LVA3)

def Have128BitDescriptorExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_D128)

def HaveAIEExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AIE)

def HaveFeatTCR2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TCR2)

def HavePAN3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAN3)

def HaveMTEAsymFaultExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

def HaveFeatLS64_V (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64_V)

def HaveFeatLS64_ACCDATA (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64_ACCDATA)

def HaveFeatXS (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_XS)

def HaveFeatEBEP (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_EBEP)

def HaveFeatTIDCP1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TIDCP1)

def HaveFeatCMOW (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CMOW)

def HaveLRCPC3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LRCPC3)

def HaveMTEStoreOnlyExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE_STORE_ONLY)

def HaveS1PIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S1PIE)

def HaveS1POExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S1POE)

def HaveS2PIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2PIE)

def HaveS2POExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2POE)

def HaveFeatCLRBHB (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CLRBHB)

def HaveTHExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_THE)

def HaveLSE128 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE128)

def HaveRASv2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RASv2)

def HaveFeatMEC (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MEC)

def HaveAccessFlagUpdateForTableExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFT)

def HaveFeatABLE (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_ABLE)

def ConstrainUnpredictable (which : Unpredictable) : SailM Constraint := do
  (__UNKNOWN_Constraint ())

def DecodeShareability (sh : (BitVec 2)) : SailM Shareability := do
  match sh with
  | 0b10 => (pure Shareability_OSH)
  | 0b11 => (pure Shareability_ISH)
  | 0b00 => (pure Shareability_NSH)
  | _ =>
    (do
      match (← (ConstrainUnpredictable Unpredictable_Shareability)) with
      | .Constraint_OSH => (pure Shareability_OSH)
      | .Constraint_ISH => (pure Shareability_ISH)
      | .Constraint_NSH => (pure Shareability_NSH)
      | _ => (do (undefined_Shareability ())))

def S2CombineS1Shareability (s1_shareability : Shareability) (s2_shareability : Shareability) : Shareability :=
  if (((BEq.beq s1_shareability Shareability_OSH) || (BEq.beq s2_shareability Shareability_OSH)) : Bool)
  then Shareability_OSH
  else
    (if (((BEq.beq s1_shareability Shareability_ISH) || (BEq.beq s2_shareability Shareability_ISH)) : Bool)
    then Shareability_ISH
    else Shareability_NSH)

def EffectiveShareability (memattrs : MemoryAttributes) : Shareability :=
  if (((BEq.beq memattrs.memtype MemType_Device) || ((memattrs.inner.attrs == MemAttr_NC) && (memattrs.outer.attrs == MemAttr_NC))) : Bool)
  then Shareability_OSH
  else memattrs.shareability

def DecodeDevice (device : (BitVec 2)) : SailM DeviceType := do
  match device with
  | 0b00 => (pure DeviceType_nGnRnE)
  | 0b01 => (pure DeviceType_nGnRE)
  | 0b10 => (pure DeviceType_nGRE)
  | 0b11 => (pure DeviceType_GRE)
  | _ => (do (undefined_DeviceType ()))

def S2CombineS1Device (s1_device : DeviceType) (s2_device : DeviceType) : DeviceType :=
  if (((BEq.beq s1_device DeviceType_nGnRnE) || (BEq.beq s2_device DeviceType_nGnRnE)) : Bool)
  then DeviceType_nGnRnE
  else
    (if (((BEq.beq s1_device DeviceType_nGnRE) || (BEq.beq s2_device DeviceType_nGnRE)) : Bool)
    then DeviceType_nGnRE
    else
      (if (((BEq.beq s1_device DeviceType_nGRE) || (BEq.beq s2_device DeviceType_nGRE)) : Bool)
      then DeviceType_nGRE
      else DeviceType_GRE))

def DecodeSDFAttr (rgn : (BitVec 2)) : SailM MemAttrHints := do
  let sdfattr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let sdfattr : MemAttrHints :=
    match rgn with
    | 0b00 => { sdfattr with attrs := MemAttr_NC }
    | 0b01 =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WB }
      { sdfattr with hints := MemHint_RWA })
    | 0b10 =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WT }
      { sdfattr with hints := MemHint_RA })
    | _ =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WB }
      { sdfattr with hints := MemHint_RA })
  (pure { sdfattr with transient := false })

def DecodeLDFAttr (attr : (BitVec 4)) : SailM MemAttrHints := do
  let ldfattr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let ldfattr ← (( do
    (if ((let b__1 := attr
       if (((Sail.BitVec.extractLsb b__1 2 2) == (0#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then (do (pure { ldfattr with attrs := MemAttr_WT }))
    else
      (do (if ((attr == 0b0100#4) : Bool)
          then (do (pure { ldfattr with attrs := MemAttr_NC }))
          else
            (do (if ((let b__0 := attr
                   if (((Sail.BitVec.extractLsb b__0 2 2) == (1#1 : (BitVec 1))) : Bool)
                   then true
                   else false : Bool) : Bool)
                then (do (pure { ldfattr with attrs := MemAttr_WB }))
                else
                  (do (Unreachable ())
                      (pure ldfattr))))))) ) : SailM MemAttrHints )
  let ldfattr : MemAttrHints :=
    if ((ldfattr.attrs != MemAttr_NC) : Bool)
    then
      (match (Sail.BitVec.extractLsb attr 1 0) with
      | 0b00 => { ldfattr with hints := MemHint_No }
      | 0b01 => { ldfattr with hints := MemHint_WA }
      | 0b10 => { ldfattr with hints := MemHint_RA }
      | _ => { ldfattr with hints := MemHint_RWA })
    else ldfattr
  (if (((ldfattr.attrs != MemAttr_NC) && (ldfattr.hints != MemHint_No)) : Bool)
  then (do (pure { ldfattr with transient := (((BitVec.access attr 3) : BitVec 1) == 0#1) }))
  else (do (pure ldfattr)))

def S2DecodeCacheability (attr : (BitVec 2)) : SailM MemAttrHints := do
  let s2attr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let s2attr ← (( do
    match attr with
    | 0b01 => (pure { s2attr with attrs := MemAttr_NC })
    | 0b10 => (pure { s2attr with attrs := MemAttr_WT })
    | 0b11 => (pure { s2attr with attrs := MemAttr_WB })
    | _ =>
      (do
        match (← (ConstrainUnpredictable Unpredictable_S2RESMEMATTR)) with
        | .Constraint_NC => (pure { s2attr with attrs := MemAttr_NC })
        | .Constraint_WT => (pure { s2attr with attrs := MemAttr_WT })
        | .Constraint_WB => (pure { s2attr with attrs := MemAttr_WB })
        | _ => (pure s2attr)) ) : SailM MemAttrHints )
  let s2attr ← (pure { s2attr with hints := (← do (__UNKNOWN_bits 2)) })
  (pure { s2attr with transient := (← do (__UNKNOWN_boolean ())) })

def S2CombineS1AttrHints (s1_attrhints : MemAttrHints) (s2_attrhints : MemAttrHints) : SailM MemAttrHints := do
  let attrhints ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let attrhints : MemAttrHints :=
    if (((s1_attrhints.attrs == MemAttr_NC) || (s2_attrhints.attrs == MemAttr_NC)) : Bool)
    then { attrhints with attrs := MemAttr_NC }
    else
      (if (((s1_attrhints.attrs == MemAttr_WT) || (s2_attrhints.attrs == MemAttr_WT)) : Bool)
      then { attrhints with attrs := MemAttr_WT }
      else { attrhints with attrs := MemAttr_WB })
  (if ((attrhints.attrs != MemAttr_NC) : Bool)
  then
    (do let attrhints : MemAttrHints := { attrhints with hints := s1_attrhints.hints }
        (pure { attrhints with transient := s1_attrhints.transient }))
  else (do (pure attrhints)))

def WalkMemAttrs (sh : (BitVec 2)) (irgn : (BitVec 2)) (orgn : (BitVec 2)) : SailM MemoryAttributes := do
  let walkmemattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let walkmemattrs : MemoryAttributes := { walkmemattrs with memtype := MemType_Normal }
  let walkmemattrs ← (pure { walkmemattrs with shareability := (← do (DecodeShareability sh)) })
  let walkmemattrs ← (pure { walkmemattrs with inner := (← do (DecodeSDFAttr irgn)) })
  let walkmemattrs ← (pure { walkmemattrs with outer := (← do (DecodeSDFAttr orgn)) })
  let walkmemattrs : MemoryAttributes := { walkmemattrs with tags := MemTag_Untagged }
  let walkmemattrs : MemoryAttributes :=
    if (((walkmemattrs.inner.attrs == MemAttr_WB) && (walkmemattrs.outer.attrs == MemAttr_WB)) : Bool)
    then { walkmemattrs with xs := 0#1 }
    else { walkmemattrs with xs := 1#1 }
  (pure { walkmemattrs with notagaccess := false })

def NormalNCMemAttr (_ : Unit) : SailM MemoryAttributes := do
  let non_cacheable ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let non_cacheable : MemAttrHints := { non_cacheable with attrs := MemAttr_NC }
  let nc_memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let nc_memattrs : MemoryAttributes := { nc_memattrs with memtype := MemType_Normal }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with outer := non_cacheable }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with inner := non_cacheable }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with shareability := Shareability_OSH }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with tags := MemTag_Untagged }
  (pure { nc_memattrs with notagaccess := false })

/-- Type quantifiers: k_s1aarch64 : Bool -/
def S1ConstrainUnpredictableRESMAIR (attr : (BitVec 8)) (s1aarch64 : Bool) : SailM Bool := do
  let b__0 := attr
  (if ((((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
  then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
  else
    (do (if (((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) : Bool)
        then (do (pure ((Sail.BitVec.extractLsb attr 1 0) != 0b00#2)))
        else
          (do (if ((b__0 == (0x40#8 : (BitVec 8))) : Bool)
              then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
              else
                (do (if ((b__0 == (0xA0#8 : (BitVec 8))) : Bool)
                    then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
                    else
                      (do (if ((b__0 == (0xF0#8 : (BitVec 8))) : Bool)
                          then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveMTE2Ext ())))))))
                          else
                            (do (if (((Sail.BitVec.extractLsb b__0 3 0) == (0x0#4 : (BitVec 4))) : Bool)
                                then (do (pure true))
                                else (do (pure false)))))))))))))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def S1DecodeMemAttrs (attr_in : (BitVec 8)) (sh : (BitVec 2)) (s1aarch64 : Bool) (walkparams : S1TTWParams) : SailM MemoryAttributes := do
  let attr : (BitVec 8) := attr_in
  let attr ← (( do
    (if ((← (S1ConstrainUnpredictableRESMAIR attr s1aarch64)) : Bool)
    then
      (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESMAIR 8)
          (pure __tup_1))
    else (do (pure attr))) ) : SailM (BitVec 8) )
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    let b__0 := attr
    (if (((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          let memattrs ← (pure { memattrs with device := (← do (DecodeDevice (Sail.BitVec.extractLsb attr 3 2))) })
          (pure { memattrs with xs := if (s1aarch64 : Bool)
              then (Complement.complement ((BitVec.access attr 0) : BitVec 1))
              else 1#1 }))
    else
      (do (if ((b__0 == (0x40#8 : (BitVec 8))) : Bool)
          then
            (do sail_assert (←((pure s1aarch64) <&&> (do
                  (HaveFeatXS ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19262.41-19262.42"
                let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_NC } }
                let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_NC } }
                (pure { memattrs with xs := 0#1 }))
          else
            (do (if ((b__0 == (0xA0#8 : (BitVec 8))) : Bool)
                then
                  (do sail_assert (←((pure s1aarch64) <&&> (do
                        (HaveFeatXS ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19269.41-19269.42"
                      let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WT } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RA } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with transient := false } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WT } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RA } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with transient := false } }
                      (pure { memattrs with xs := 0#1 }))
                else
                  (do (if ((b__0 == (0xF0#8 : (BitVec 8))) : Bool)
                      then
                        (do sail_assert (←((pure s1aarch64) <&&> (do
                              (HaveMTE2Ext ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19280.42-19280.43"
                            let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WB } }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RWA } }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with transient := false } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WB } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RWA } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with transient := false } }
                            (pure { memattrs with xs := 0#1 }))
                      else
                        (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs ← (pure { memattrs with outer := (← do (DecodeLDFAttr (Sail.BitVec.extractLsb attr 7 4))) })
                            let memattrs ← (pure { memattrs with inner := (← do (DecodeLDFAttr (Sail.BitVec.extractLsb attr 3 0))) })
                            (if (((memattrs.inner.attrs == MemAttr_WB) && (memattrs.outer.attrs == MemAttr_WB)) : Bool)
                            then (do (pure { memattrs with xs := 0#1 }))
                            else (do (pure { memattrs with xs := 1#1 }))))))))))) ) : SailM MemoryAttributes )
  let memattrs : MemoryAttributes :=
    if ((s1aarch64 && (attr == 0b11110000#8)) : Bool)
    then { memattrs with tags := MemTag_AllocationTagged }
    else
      (if ((s1aarch64 && (walkparams.mtx == 1#1)) : Bool)
      then { memattrs with tags := MemTag_CanonicallyTagged }
      else { memattrs with tags := MemTag_Untagged })
  let memattrs : MemoryAttributes := { memattrs with notagaccess := false }
  (pure { memattrs with shareability := (← do (DecodeShareability sh)) })

def S2MemTagType (s2_memattrs : MemoryAttributes) (s1_tagtype : MemTagType) : SailM MemTagType := do
  (if ((! (← (HaveMTE2Ext ()))) : Bool)
  then (do (pure MemTag_Untagged))
  else
    (do (if (((((((((BEq.beq s1_tagtype MemTag_AllocationTagged) && (BEq.beq s2_memattrs.memtype MemType_Normal)) && (s2_memattrs.inner.attrs == MemAttr_WB)) && (s2_memattrs.inner.hints == MemHint_RWA)) && (! s2_memattrs.inner.transient)) && (s2_memattrs.outer.attrs == MemAttr_WB)) && (s2_memattrs.outer.hints == MemHint_RWA)) && (! s2_memattrs.outer.transient)) : Bool)
        then (do (pure MemTag_AllocationTagged))
        else
          (do (if ((bne s1_tagtype MemTag_AllocationTagged) : Bool)
              then (do (pure s1_tagtype))
              else (do (pure MemTag_Untagged)))))))


end ArmASL.Functions
