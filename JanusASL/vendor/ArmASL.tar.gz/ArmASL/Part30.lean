import ArmASL.Part29

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_sqdmlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let accum ← (( do (undefined_int ()) ) : SailM Int )
  let sat1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let sat2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (accum, element1, element2, product, result, sat1, sat2) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, element2, product, result, sat1, sat2)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, element2, product, result, sat1, sat2) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let (product, sat1) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat1 : Bool := tup__1
          (pure (product, sat1)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let accum ← (( do
          (if (sub_op : Bool)
          then (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) -i (BitVec.toInt product))))
          else (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) +i (BitVec.toInt product))))) ) : SailM Int )
        let (result, sat2) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ accum (2 *i esize))
          let result ← (Elem_set result e (2 *i esize) __tup_0)
          let sat2 : Bool := __tup_1
          (pure (result, sat2)) ) : SailM ((BitVec (2 * datasize)) × Bool) )
        (if ((sat1 || sat2) : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (accum, element1, element2, product, result, sat1, sat2))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_rounding : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rounding : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let product : Int := ((2 *i element1) *i element2)
        let product ← (( (RShr product esize rounding) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ product esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, element2, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqrdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqrdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, k_round : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (round : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let product : Int := ((2 *i element1) *i element2)
        let product ← (( (RShr product esize round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ product esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqrdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqrdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let (product, sat) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat : Bool := tup__1
          (pure (product, sat)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let result ← (Elem_set result e (2 *i esize) product)
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, element2, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd d datasize elements esize m n part)

def decode_sqdmull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd d datasize elements esize m n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let (product, sat) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat : Bool := tup__1
          (pure (product, sat)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let result ← (Elem_set result e (2 *i esize) product)
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, product, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd d datasize elements esize idxdsize index m n part)

def decode_sqdmull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd d datasize elements esize idxdsize index m n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_rounding : Bool, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rounding : Bool) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let element3 ← (( do (undefined_int ()) ) : SailM Int )
  let accum ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (accum, element1, element2, element3, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, element2, element3, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, element2, element3, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let element3 ← (( (pure (BitVec.toInt (← (Elem_read operand3 e esize)))) ) : SailM Int )
        let accum : Int :=
          if (sub_op : Bool)
          then ((Int.shiftl element3 esize) -i (2 *i (element1 *i element2)))
          else ((Int.shiftl element3 esize) +i (2 *i (element1 *i element2)))
        let accum ← (( (RShr accum esize rounding) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ accum esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (accum, element1, element2, element3, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqrdmlah_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd d datasize elements esize m n rounding sub_op)

def decode_sqrdmlah_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd d datasize elements esize m n rounding sub_op)

def decode_sqrdmlsh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd d datasize elements esize m n rounding sub_op)

def decode_sqrdmlsh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd d datasize elements esize m n rounding sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, k_rounding : Bool, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (rounding : Bool) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element3 ← (( do (undefined_int ()) ) : SailM Int )
  let accum ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (accum, element1, element3, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, element3, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, element3, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element3 ← (( (pure (BitVec.toInt (← (Elem_read operand3 e esize)))) ) : SailM Int )
        let accum : Int :=
          if (sub_op : Bool)
          then ((Int.shiftl element3 esize) -i (2 *i (element1 *i element2)))
          else ((Int.shiftl element3 esize) +i (2 *i (element1 *i element2)))
        let accum ← (( (RShr accum esize rounding) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ accum esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (accum, element1, element3, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqrdmlah_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (S : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd d datasize elements esize idxdsize index m n rounding sub_op)

def decode_sqrdmlah_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (S : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd d datasize elements esize idxdsize index m n rounding sub_op)

def decode_sqrdmlsh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (S : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd d datasize elements esize idxdsize index m n rounding sub_op)

def decode_sqrdmlsh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (S : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveQRDMLAHExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := true
  let sub_op : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_high_sisd d datasize elements esize idxdsize index m n rounding sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, k_rounding : Bool, k_saturating : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rounding : Bool) (saturating : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (result, sat) := loop_vars
      loop_vars ← do
        let element ← (( do (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let shift ← (( do (pure (BitVec.toInt (Sail.BitVec.extractLsb (← (Elem_read operand2 e esize)) 7 0))) ) : SailM Int )
        let element ← (( do
          (if ((shift ≥b 0) : Bool)
          then (do (pure (_shl_int_general element shift)))
          else
            (do let shift := (Neg.neg shift)
                (RShr element shift rounding))) ) : SailM Int )
        let element := element
        let (result, sat) ← (( do
          (if (saturating : Bool)
          then
            (do let (result, sat) ← (( do
                  let (__tup_0, __tup_1) ← do (SatQ element esize is_unsigned)
                  let result ← (Elem_set result e esize __tup_0)
                  let sat : Bool := __tup_1
                  (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
                (if (sat : Bool)
                then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
                else (do (pure ())))
                (pure (result, sat)))
          else
            (do let result ← (Elem_set result e esize (integer_subrange element (esize -i 1) 0))
                (pure (result, sat)))) ) : SailM ((BitVec datasize) × Bool) )
        (pure (result, sat))
    (pure loop_vars) ) : SailM ((BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_srshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_srshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_urshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_urshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_ushl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_ushl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (← (asl_Int (← (Elem_read operand e (2 *i esize))) is_unsigned)) shift round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ element esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47316.87-47316.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47349.51-47349.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47383.87-47383.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47416.51-47416.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47450.87-47450.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47483.51-47483.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47517.87-47517.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47550.51-47550.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (BitVec.toInt (← (Elem_read operand e (2 *i esize)))) shift round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (UnsignedSatQ element esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqrshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47610.87-47610.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqrshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47641.51-47641.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47673.87-47673.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47704.51-47704.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

/-- Type quantifiers: d : Nat, datasize : Nat, k_dst_unsigned : Bool, elements : Int, esize : Nat, n : Nat, shift : Int, k_src_unsigned : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_sat_sisd (d : Nat) (datasize : Nat) (dst_unsigned : Bool) (elements : Int) (esize : Nat) (n : Nat) (shift : Int) (src_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47725.56-47725.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (pure (_shl_int_general (← (asl_Int (← (Elem_read operand e esize)) src_unsigned)) shift)) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ element esize dst_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47780.92-47780.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47831.51-47831.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshlu_advsimd_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47880.92-47880.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshlu_advsimd_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47931.51-47931.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_uqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47980.92-47980.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_uqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48031.51-48031.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let diff ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (diff, element1, element2, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (diff, element1, element2, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (diff, element1, element2, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let diff : Int := (element1 -i element2)
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ diff esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (diff, element1, element2, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_sqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ (← (asl_Int element is_unsigned)) esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_sqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_uqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_uqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (UnsignedSatQ (BitVec.toInt element) esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqxtun_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd d datasize elements esize n part)

def decode_sqxtun_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int := (Int.shiftr ((element1 +i element2) +i 1) 1)
        let result ← (Elem_set result e esize (integer_subrange sum (esize -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Int) )
  (V_set d datasize result)

def decode_srhadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding d datasize elements esize m n is_unsigned)

def decode_urhadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Int, elements : Int, esize : Int, n : Nat, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_insert_sisd (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48463.56-48463.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:48467.34-48467.35"
  let mask : (BitVec esize) := ((Ones (n := esize)) >>> shift)
  let shifted ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (result, shifted) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (result, shifted)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (result, shifted) := loop_vars
      loop_vars ← do
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || ((! (esize ≥b 0)) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:48471.198-48471.199"
        let shifted ← (pure ((← (Elem_read operand e esize)) >>> shift))
        let result ← (Elem_set result e esize (((← (Elem_read operand2 e esize)) &&& (Complement.complement mask)) ||| shifted))
        (pure (result, shifted))
    (pure loop_vars) ) : SailM ((BitVec datasize) × (BitVec esize)) )
  (V_set d datasize result)

def decode_sri_advsimd_aarch64_instrs_vector_shift_right_insert_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  (execute_aarch64_instrs_vector_shift_right_insert_sisd d datasize elements esize n shift)

def decode_sri_advsimd_aarch64_instrs_vector_shift_right_insert_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  (execute_aarch64_instrs_vector_shift_right_insert_sisd d datasize elements esize n shift)

/-- Type quantifiers: k_accumulate : Bool, d : Nat, datasize : Int, elements : Int, esize : Int, k_is_unsigned : Bool, n : Nat, k_round : Bool, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_sisd (accumulate : Bool) (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (round : Bool) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48536.56-48536.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let operand2 ← (( do
    (if (accumulate : Bool)
    then (do (V_read d datasize))
    else (do (pure (Zeros (n := datasize))))) ) : SailM (BitVec datasize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:48543.38-48543.39"
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:48544.179-48544.180"
        let element ← (( (RShr (← (asl_Int (← (Elem_read operand e esize)) is_unsigned)) shift round) ) : SailM Int )
        let result ← (Elem_set result e esize ((← (Elem_read operand2 e esize)) + (integer_subrange element (esize -i 1) 0)))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_srshr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_srshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_srsra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_srsra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_sshr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_sshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ssra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ssra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_urshr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_urshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ursra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ursra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ushr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ushr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_usra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_usra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (pure (_shl_int_general (← (asl_Int (← (Elem_read operand e esize)) is_unsigned)) shift)) ) : SailM Int )
        let result ← (Elem_set result e (2 *i esize) (integer_subrange element ((2 *i esize) -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec (datasize * 2))) )
  (V_set d (datasize *i 2) result)

def decode_sshll_advsimd_aarch64_instrs_vector_shift_left_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:49096.51-49096.52"
  (execute_aarch64_instrs_vector_shift_left_long d datasize elements esize n part shift is_unsigned)

def decode_ushll_advsimd_aarch64_instrs_vector_shift_left_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:49128.51-49128.52"
  (execute_aarch64_instrs_vector_shift_left_long d datasize elements esize n part shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, i : Nat, m : Nat, n : Nat, k_op1_unsigned : Bool, k_op2_unsigned : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem i [0, 1, 2, 3] ∧ List.elem elements [2, 4] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mat_mul_int_dotp (d : Nat) (datasize : Nat) (elements : Nat) (i : Nat) (m : Nat) (n : Nat) (op1_unsigned : Bool) (op2_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let res ← (( do (Elem_read operand3 e 32) ) : SailM (BitVec 32) )
        let res ← (( do
          let loop_b_lower := 0
          let loop_b_upper := 3
          let mut loop_vars_1 := res
          for b in [loop_b_lower:loop_b_upper:1]i do
            let res := loop_vars_1
            loop_vars_1 ← do
              let element1 ← (( do (asl_Int (← (Elem_read operand1 ((4 *i e) +i b) 8)) op1_unsigned) ) : SailM Int )
              let element2 ← (( do (asl_Int (← (Elem_read operand2 ((4 *i i) +i b) 8)) op2_unsigned) ) : SailM Int )
              (pure (BitVec.addInt res (element1 *i element2)))
          (pure loop_vars_1) ) : SailM (BitVec 32) )
        (Elem_set result e 32 res)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_sudot_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mat_mul_int_dotp (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (US : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveInt8MatMulExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let op1_unsigned : Bool := (US == 1#1)
  let op2_unsigned : Bool := (US == 0#1)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (M +++ Rm))
  let d := (BitVec.toNat Rd)
  let i := (BitVec.toNat (H +++ L))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 32)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mat_mul_int_dotp d datasize elements i m n op1_unsigned op2_unsigned)

def decode_usdot_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mat_mul_int_dotp (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (US : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveInt8MatMulExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let op1_unsigned : Bool := (US == 1#1)
  let op2_unsigned : Bool := (US == 0#1)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (M +++ Rm))
  let d := (BitVec.toNat Rd)
  let i := (BitVec.toNat (H +++ L))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 32)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mat_mul_int_dotp d datasize elements i m n op1_unsigned op2_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let op1 ← (( do (undefined_int ()) ) : SailM Int )
  let op2 ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (op1, op2, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (op1, op2, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (op1, op2, result, sat) := loop_vars
      loop_vars ← do
        let op1 ← (( (asl_Int (← (Elem_read operand e esize)) (! is_unsigned)) ) : SailM Int )
        let op2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ (op1 +i op2) esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (op1, op2, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_suqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_suqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_usqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_usqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def execute_aarch64_instrs_system_exceptions_runtime_svc (imm : (BitVec 16)) : SailM Unit := do
  (AArch64_CheckForSVCTrap imm)
  (AArch64_CallSupervisor imm)

def decode_svc_aarch64_instrs_system_exceptions_runtime_svc (imm16 : (BitVec 16)) : SailM Unit := do
  let imm : (BitVec 16) := imm16
  (execute_aarch64_instrs_system_exceptions_runtime_svc imm)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_swp (acquire : Bool) (datasize : Nat) (n : Nat) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_SWP acquire release tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let store_value ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let comparevalue ← (( do (__UNKNOWN_bits datasize) ) : SailM (BitVec datasize) )
  let data ← (( do (MemAtomic address comparevalue store_value accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:50450.44-50450.45"
  (X_set t regsize (Sail.BitVec.zeroExtend data regsize))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_swp_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

def decode_swpb_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

def decode_swph_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

/-- Type quantifiers: k_has_result : Bool, sys_crm : Nat, sys_crn : Nat, sys_op0 : Nat, sys_op1 : Nat, sys_op2 : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem sys_op2 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op1 [0, 1, 2, 3, 4, 5, 6, 7] ∧ sys_op0 = 1 ∧ 0 ≤ sys_crn ∧ sys_crn ≤ 15 ∧ 0 ≤ sys_crm ∧ sys_crm ≤ 15 -/
def execute_aarch64_instrs_system_sysops (has_result : Bool) (sys_crm : Nat) (sys_crn : Nat) (sys_op0 : Nat) (sys_op1 : Nat) (sys_op2 : Nat) (t : Nat) : SailM Unit := do
  (if (has_result : Bool)
  then (do (AArch64_SysInstrWithResult sys_op0 sys_op1 sys_crn sys_crm sys_op2 t))
  else (do (AArch64_SysInstr sys_op0 sys_op1 sys_crn sys_crm sys_op2 t)))

def decode_sys_aarch64_instrs_system_sysops (Rt : (BitVec 5)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (CRn : (BitVec 4)) (op1 : (BitVec 3)) (L : (BitVec 1)) : SailM Unit := do
  (AArch64_CheckSystemAccess 0b01#2 op1 CRn CRm op2 Rt L)
  let t := (BitVec.toNat Rt)
  let sys_op0 := 1
  let sys_op1 := (BitVec.toNat op1)
  let sys_op2 := (BitVec.toNat op2)
  let sys_crn := (BitVec.toNat CRn)
  let sys_crm := (BitVec.toNat CRm)
  let has_result : Bool := (L == 1#1)
  (execute_aarch64_instrs_system_sysops has_result sys_crm sys_crn sys_op0 sys_op1 sys_op2 t)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, k_is_tbl : Bool, m : Nat, n__arg : Nat, regs : Nat, List.elem regs [1, 2, 3, 4] ∧ 0 ≤ n__arg ∧ n__arg ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_table (d : Nat) (datasize : Nat) (elements : Nat) (is_tbl : Bool) (m : Nat) (n__arg : Nat) (regs : Nat) : SailM Unit := do
  let n : Int := n__arg
  (CheckFPAdvSIMDEnabled64 ())
  let indices ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let table : (BitVec (128 * regs)) := (Zeros (n := (128 *i regs)))
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (n, table) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (regs -i 1)
    let mut loop_vars := (n, table)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (n, table) := loop_vars
      loop_vars ← do
        let table ← (pure (Sail.BitVec.updateSubrange table ((128 *i i) +i 127) (128 *i i) (← (V_read n 128))))
        let n : Int := (fmod_int (n +i 1) 32)
        (pure (n, table))
    (pure loop_vars) ) : SailM (Int × (BitVec (128 * regs))) )
  let result ← (( do
    (if (is_tbl : Bool)
    then (do (pure (Zeros (n := datasize))))
    else (do (V_read d datasize))) ) : SailM (BitVec datasize) )
  let (index, result) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (elements -i 1)
    let mut loop_vars_1 := (index, result)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (index, result) := loop_vars_1
      loop_vars_1 ← do
        let index ← (( (pure (BitVec.toNat (← (Elem_read indices i 8)))) ) : SailM Int )
        let index := index
        let result ← (( do
          (if ((index <b (16 *i regs)) : Bool)
          then (do (Elem_set result i 8 (← (Elem_read table index 8))))
          else (do (pure result))) ) : SailM (BitVec datasize) )
        (pure (index, result))
    (pure loop_vars_1) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_tbl_advsimd_aarch64_instrs_vector_transfer_vector_table (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (len : (BitVec 2)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  let regs := ((BitVec.toNat len) +i 1)
  let is_tbl : Bool := (op == 0#1)
  (execute_aarch64_instrs_vector_transfer_vector_table d datasize elements is_tbl m n regs)

def decode_tbx_advsimd_aarch64_instrs_vector_transfer_vector_table (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (len : (BitVec 2)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  let regs := ((BitVec.toNat len) +i 1)
  let is_tbl : Bool := (op == 0#1)
  (execute_aarch64_instrs_vector_transfer_vector_table d datasize elements is_tbl m n regs)

/-- Type quantifiers: bit_pos : Nat, datasize : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ bit_pos ∧ bit_pos ≤ 63 -/
def execute_aarch64_instrs_branch_conditional_test (bit_pos : Nat) (bit_val : (BitVec 1)) (datasize : Nat) (offset : (BitVec 64)) (t : Nat) : SailM Unit := do
  let operand ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let branch_conditional : Bool := true
  sail_assert (bit_pos <b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:50773.43-50773.44"
  (if ((((BitVec.access operand bit_pos) : BitVec 1) == bit_val) : Bool)
  then (do (BranchTo ((← (PC_read ())) + offset) BranchType_DIR branch_conditional))
  else (do (BranchNotTaken BranchType_DIR branch_conditional)))

def decode_tbnz_aarch64_instrs_branch_conditional_test (Rt : (BitVec 5)) (imm14 : (BitVec 14)) (b40 : (BitVec 5)) (op : (BitVec 1)) (b5 : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((b5 == 1#1) : Bool)
    then 64
    else 32
  let bit_pos := (BitVec.toNat (b5 +++ b40))
  let bit_val : (BitVec 1) := op
  let offset : (BitVec 64) := (sign_extend (imm14 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_test bit_pos bit_val datasize offset t)

def decode_tbz_aarch64_instrs_branch_conditional_test (Rt : (BitVec 5)) (imm14 : (BitVec 14)) (b40 : (BitVec 5)) (op : (BitVec 1)) (b5 : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((b5 == 1#1) : Bool)
    then 64
    else 32
  let bit_pos := (BitVec.toNat (b5 +++ b40))
  let bit_val : (BitVec 1) := op
  let offset : (BitVec 64) := (sign_extend (imm14 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_test bit_pos bit_val datasize offset t)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, m : Nat, n : Nat, pairs : Int, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_transpose (d : Nat) (datasize : Nat) (esize : Nat) (m : Nat) (n : Nat) (pairs : Int) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_p_lower := 0
    let loop_p_upper := (pairs -i 1)
    let mut loop_vars := result
    for p in [loop_p_lower:loop_p_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let result ← (Elem_set result ((2 *i p) +i 0) esize (← (Elem_read operand1 ((2 *i p) +i part) esize)))
        (Elem_set result ((2 *i p) +i 1) esize (← (Elem_read operand2 ((2 *i p) +i part) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_trn1_advsimd_aarch64_instrs_vector_transfer_vector_permute_transpose (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_transpose d datasize esize m n pairs part)

def decode_trn2_advsimd_aarch64_instrs_vector_transfer_vector_permute_transpose (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_transpose d datasize esize m n pairs part)

def execute_aarch64_instrs_udf (_ : Unit) : Unit :=
  ()

def decode_udf_perm_undef_aarch64_instrs_udf (imm16 : (BitVec 16)) : SailM Unit := do
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, idxdsize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_move_unsigned (d : Nat) (datasize : Nat) (esize : Nat) (idxdsize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (if ((index == 0) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  sail_assert (datasize ≥b esize) "sail-arm/arm-v9.4-a/src/instrs64.sail:51217.42-51217.43"
  (X_set d datasize (Sail.BitVec.zeroExtend (← (Elem_read operand index esize)) datasize))


end ArmASL.Functions
