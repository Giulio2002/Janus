import ArmASL.Part29

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_srhadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding d datasize elements esize m n is_unsigned)

def decode_urhadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Int, elements : Int, esize : Int, n : Nat, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_insert_sisd (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48106.56-48106.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:48110.34-48110.35"
  let mask : (BitVec esize) := ((Ones (n := esize)) >>> shift)
  let shifted ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (result, shifted) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (result, shifted)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (result, shifted) := loop_vars
      loop_vars ← do
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || ((! (esize ≥b 0)) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:48114.198-48114.199"
        let shifted ← (pure ((← (Elem_read operand e esize)) >>> shift))
        let result ← (Elem_set result e esize (((← (Elem_read operand2 e esize)) &&& (Complement.complement mask)) ||| shifted))
        (pure (result, shifted))
    (pure loop_vars) ) : SailM ((BitVec datasize) × (BitVec esize)) )
  (V_set d datasize result)

def decode_sri_advsimd_aarch64_instrs_vector_shift_right_insert_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  (execute_aarch64_instrs_vector_shift_right_insert_sisd d datasize elements esize n shift)

/-- Type quantifiers: k_accumulate : Bool, d : Nat, datasize : Int, elements : Int, esize : Int, k_is_unsigned : Bool, n : Nat, k_round : Bool, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_sisd (accumulate : Bool) (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (round : Bool) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48175.56-48175.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let operand2 ← (( do
    (if (accumulate : Bool)
    then (do (V_read d datasize))
    else (do (pure (Zeros (n := datasize))))) ) : SailM (BitVec datasize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:48182.38-48182.39"
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:48183.179-48183.180"
        let element ← (( (RShr (← (asl_Int (← (Elem_read operand e esize)) is_unsigned)) shift round) ) : SailM Int )
        let result ← (Elem_set result e esize ((← (Elem_read operand2 e esize)) + (integer_subrange element (esize -i 1) 0)))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_srshr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_srshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_srsra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_sshr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_sshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ssra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_urshr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ursra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ursra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ushr_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_ushr_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_usra_advsimd_aarch64_instrs_vector_shift_right_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

def decode_usra_advsimd_aarch64_instrs_vector_shift_right_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (o1 : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let round : Bool := (o1 == 1#1)
  let accumulate : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_vector_shift_right_sisd accumulate d datasize elements esize n round shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (pure (_shl_int_general (← (asl_Int (← (Elem_read operand e esize)) is_unsigned)) shift)) ) : SailM Int )
        let result ← (Elem_set result e (2 *i esize) (integer_subrange element ((2 *i esize) -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec (datasize * 2))) )
  (V_set d (datasize *i 2) result)

def decode_sshll_advsimd_aarch64_instrs_vector_shift_left_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48714.51-48714.52"
  (execute_aarch64_instrs_vector_shift_left_long d datasize elements esize n part shift is_unsigned)

def decode_ushll_advsimd_aarch64_instrs_vector_shift_left_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:48746.51-48746.52"
  (execute_aarch64_instrs_vector_shift_left_long d datasize elements esize n part shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let op1 ← (( do (undefined_int ()) ) : SailM Int )
  let op2 ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (op1, op2, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (op1, op2, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (op1, op2, result, sat) := loop_vars
      loop_vars ← do
        let op1 ← (( (asl_Int (← (Elem_read operand e esize)) (! is_unsigned)) ) : SailM Int )
        let op2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ (op1 +i op2) esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (op1, op2, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_suqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_suqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_usqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def decode_usqadd_advsimd_aarch64_instrs_vector_arithmetic_unary_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_saturating_sisd d datasize elements esize n is_unsigned)

def execute_aarch64_instrs_system_exceptions_runtime_svc (imm : (BitVec 16)) : SailM Unit := do
  (AArch64_CheckForSVCTrap imm)
  (AArch64_CallSupervisor imm)

def decode_svc_aarch64_instrs_system_exceptions_runtime_svc (imm16 : (BitVec 16)) : SailM Unit := do
  let imm : (BitVec 16) := imm16
  (execute_aarch64_instrs_system_exceptions_runtime_svc imm)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_swp (acquire : Bool) (datasize : Nat) (n : Nat) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_SWP acquire release tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let store_value ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let comparevalue ← (( do (__UNKNOWN_bits datasize) ) : SailM (BitVec datasize) )
  let data ← (( do (MemAtomic address comparevalue store_value accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:50052.44-50052.45"
  (X_set t regsize (Sail.BitVec.zeroExtend data regsize))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_swp_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

def decode_swpb_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

def decode_swph_aarch64_instrs_memory_atomicops_swp (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let release : Bool := (R == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_swp acquire datasize n regsize release s t tagchecked)

/-- Type quantifiers: k_has_result : Bool, sys_crm : Nat, sys_crn : Nat, sys_op0 : Nat, sys_op1 : Nat, sys_op2 : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem sys_op2 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op1 [0, 1, 2, 3, 4, 5, 6, 7] ∧ sys_op0 = 1 ∧ 0 ≤ sys_crn ∧ sys_crn ≤ 15 ∧ 0 ≤ sys_crm ∧ sys_crm ≤ 15 -/
def execute_aarch64_instrs_system_sysops (has_result : Bool) (sys_crm : Nat) (sys_crn : Nat) (sys_op0 : Nat) (sys_op1 : Nat) (sys_op2 : Nat) (t : Nat) : SailM Unit := do
  (if (has_result : Bool)
  then (do (AArch64_SysInstrWithResult sys_op0 sys_op1 sys_crn sys_crm sys_op2 t))
  else (do (AArch64_SysInstr sys_op0 sys_op1 sys_crn sys_crm sys_op2 t)))

def decode_sys_aarch64_instrs_system_sysops (Rt : (BitVec 5)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (CRn : (BitVec 4)) (op1 : (BitVec 3)) (L : (BitVec 1)) : SailM Unit := do
  (AArch64_CheckSystemAccess 0b01#2 op1 CRn CRm op2 Rt L)
  let t := (BitVec.toNat Rt)
  let sys_op0 := 1
  let sys_op1 := (BitVec.toNat op1)
  let sys_op2 := (BitVec.toNat op2)
  let sys_crn := (BitVec.toNat CRn)
  let sys_crm := (BitVec.toNat CRm)
  let has_result : Bool := (L == 1#1)
  (execute_aarch64_instrs_system_sysops has_result sys_crm sys_crn sys_op0 sys_op1 sys_op2 t)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, k_is_tbl : Bool, m : Nat, n__arg : Nat, regs : Nat, List.elem regs [1, 2, 3, 4] ∧ 0 ≤ n__arg ∧ n__arg ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_table (d : Nat) (datasize : Nat) (elements : Nat) (is_tbl : Bool) (m : Nat) (n__arg : Nat) (regs : Nat) : SailM Unit := do
  let n : Int := n__arg
  (CheckFPAdvSIMDEnabled64 ())
  let indices ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let table : (BitVec (128 * regs)) := (Zeros (n := (128 *i regs)))
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (n, table) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (regs -i 1)
    let mut loop_vars := (n, table)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (n, table) := loop_vars
      loop_vars ← do
        let table ← (pure (Sail.BitVec.updateSubrange table ((128 *i i) +i 127) (128 *i i) (← (V_read n 128))))
        let n : Int := (fmod_int (n +i 1) 32)
        (pure (n, table))
    (pure loop_vars) ) : SailM (Int × (BitVec (128 * regs))) )
  let result ← (( do
    (if (is_tbl : Bool)
    then (do (pure (Zeros (n := datasize))))
    else (do (V_read d datasize))) ) : SailM (BitVec datasize) )
  let (index, result) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (elements -i 1)
    let mut loop_vars_1 := (index, result)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (index, result) := loop_vars_1
      loop_vars_1 ← do
        let index ← (( (pure (BitVec.toNat (← (Elem_read indices i 8)))) ) : SailM Int )
        let index := index
        let result ← (( do
          (if ((index <b (16 *i regs)) : Bool)
          then (do (Elem_set result i 8 (← (Elem_read table index 8))))
          else (do (pure result))) ) : SailM (BitVec datasize) )
        (pure (index, result))
    (pure loop_vars_1) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_tbl_advsimd_aarch64_instrs_vector_transfer_vector_table (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (len : (BitVec 2)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  let regs := ((BitVec.toNat len) +i 1)
  let is_tbl : Bool := (op == 0#1)
  (execute_aarch64_instrs_vector_transfer_vector_table d datasize elements is_tbl m n regs)

def decode_tbx_advsimd_aarch64_instrs_vector_transfer_vector_table (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (len : (BitVec 2)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  let regs := ((BitVec.toNat len) +i 1)
  let is_tbl : Bool := (op == 0#1)
  (execute_aarch64_instrs_vector_transfer_vector_table d datasize elements is_tbl m n regs)

/-- Type quantifiers: bit_pos : Nat, datasize : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ bit_pos ∧ bit_pos ≤ 63 -/
def execute_aarch64_instrs_branch_conditional_test (bit_pos : Nat) (bit_val : (BitVec 1)) (datasize : Nat) (offset : (BitVec 64)) (t : Nat) : SailM Unit := do
  let operand ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let branch_conditional : Bool := true
  sail_assert (bit_pos <b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:50375.43-50375.44"
  (if ((((BitVec.access operand bit_pos) : BitVec 1) == bit_val) : Bool)
  then (do (BranchTo ((← (PC_read ())) + offset) BranchType_DIR branch_conditional))
  else (do (BranchNotTaken BranchType_DIR branch_conditional)))

def decode_tbnz_aarch64_instrs_branch_conditional_test (Rt : (BitVec 5)) (imm14 : (BitVec 14)) (b40 : (BitVec 5)) (op : (BitVec 1)) (b5 : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((b5 == 1#1) : Bool)
    then 64
    else 32
  let bit_pos := (BitVec.toNat (b5 +++ b40))
  let bit_val : (BitVec 1) := op
  let offset : (BitVec 64) := (sign_extend (imm14 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_test bit_pos bit_val datasize offset t)

def decode_tbz_aarch64_instrs_branch_conditional_test (Rt : (BitVec 5)) (imm14 : (BitVec 14)) (b40 : (BitVec 5)) (op : (BitVec 1)) (b5 : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((b5 == 1#1) : Bool)
    then 64
    else 32
  let bit_pos := (BitVec.toNat (b5 +++ b40))
  let bit_val : (BitVec 1) := op
  let offset : (BitVec 64) := (sign_extend (imm14 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_test bit_pos bit_val datasize offset t)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, m : Nat, n : Nat, pairs : Int, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_transpose (d : Nat) (datasize : Nat) (esize : Nat) (m : Nat) (n : Nat) (pairs : Int) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_p_lower := 0
    let loop_p_upper := (pairs -i 1)
    let mut loop_vars := result
    for p in [loop_p_lower:loop_p_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let result ← (Elem_set result ((2 *i p) +i 0) esize (← (Elem_read operand1 ((2 *i p) +i part) esize)))
        (Elem_set result ((2 *i p) +i 1) esize (← (Elem_read operand2 ((2 *i p) +i part) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_trn1_advsimd_aarch64_instrs_vector_transfer_vector_permute_transpose (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_transpose d datasize esize m n pairs part)

def decode_trn2_advsimd_aarch64_instrs_vector_transfer_vector_permute_transpose (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_transpose d datasize esize m n pairs part)

def execute_aarch64_instrs_udf (_ : Unit) : Unit :=
  ()

def decode_udf_perm_undef_aarch64_instrs_udf (imm16 : (BitVec 16)) : SailM Unit := do
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, idxdsize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_move_unsigned (d : Nat) (datasize : Nat) (esize : Nat) (idxdsize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (if ((index == 0) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  sail_assert (datasize ≥b esize) "sail-arm/arm-v9.4-a/src/instrs64.sail:50819.42-50819.43"
  (X_set d datasize (Sail.BitVec.zeroExtend (← (Elem_read operand index esize)) datasize))

def decode_umov_advsimd_aarch64_instrs_vector_transfer_integer_move_unsigned (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size : Int := 0
  let size ← (( do
    let b__0 := (Q +++ imm5)
    (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
    then (do (pure 0))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
          then (do (pure 1))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 2 0) == (0b100#3 : (BitVec 3)))) : Bool)
                then (do (pure 2))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 3 0) == (0x8#4 : (BitVec 4)))) : Bool)
                      then (do (pure 3))
                      else (do sailThrow ((Error_Undefined ())))))))))) ) : SailM Int )
  let size := size
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let esize := (Int.shiftl 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 64
    else 32
  (execute_aarch64_instrs_vector_transfer_integer_move_unsigned d datasize esize idxdsize index n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_recip_int (d : Nat) (datasize : Nat) (elements : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e 32)
        let result ← (Elem_set result e 32 (← (UnsignedRecipEstimate element)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_urecpe_advsimd_aarch64_instrs_vector_arithmetic_unary_special_recip_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_recip_int d datasize elements n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int (d : Nat) (datasize : Nat) (elements : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e 32)
        let result ← (Elem_set result e 32 (← (UnsignedRSqrtEstimate element)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_ursqrte_advsimd_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int d datasize elements n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_unzip (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operandl ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operandh ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let zipped : (BitVec (datasize * 2)) := (operandh +++ operandl)
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize (← (Elem_read zipped ((2 *i e) +i part) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_uzp1_advsimd_aarch64_instrs_vector_transfer_vector_permute_unzip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  (execute_aarch64_instrs_vector_transfer_vector_permute_unzip d datasize elements esize m n part)

def decode_uzp2_advsimd_aarch64_instrs_vector_transfer_vector_permute_unzip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  (execute_aarch64_instrs_vector_transfer_vector_permute_unzip d datasize elements esize m n part)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3_xar (d : Nat) (imm6 : (BitVec 6)) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vm ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let Vn ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let tmp : (BitVec 128) := (Vn ^^^ Vm)
  (V_set d 128 ((ROR (Sail.BitVec.extractLsb tmp 127 64) (BitVec.toNat imm6)) +++ (ROR (Sail.BitVec.extractLsb tmp 63 0) (BitVec.toNat imm6))))

def decode_xar_advsimd_aarch64_instrs_vector_crypto_sha3_xar (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA3Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha3_xar d imm6 m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_nosat (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let result ← (Elem_set result e esize (Sail.BitVec.extractLsb element (esize -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize)) )
  (Vpart_set d part datasize result)

def decode_xtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_nosat (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_nosat d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, m : Nat, n : Nat, pairs : Int, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_zip (d : Nat) (datasize : Nat) (esize : Nat) (m : Nat) (n : Nat) (pairs : Int) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let base := (part *i pairs)
  let result ← (( do
    let loop_p_lower := 0
    let loop_p_upper := (pairs -i 1)
    let mut loop_vars := result
    for p in [loop_p_lower:loop_p_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let result ← (Elem_set result ((2 *i p) +i 0) esize (← (Elem_read operand1 (base +i p) esize)))
        (Elem_set result ((2 *i p) +i 1) esize (← (Elem_read operand2 (base +i p) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_zip1_advsimd_aarch64_instrs_vector_transfer_vector_permute_zip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_zip d datasize esize m n pairs part)

def decode_zip2_advsimd_aarch64_instrs_vector_transfer_vector_permute_zip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_zip d datasize esize m n pairs part)

/-- Type quantifiers: pc : Int -/
def __DecodeA64_Reserved (pc : Int) (__opcode : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((Sail.BitVec.extractLsb __opcode 31 16) == (0x0000#16 : (BitVec 16)))) <&&> (do
       (pure ((← readReg SEE) <b 1017))))) : Bool)
  then
    (do writeReg SEE 1017
        let imm16 := (BitVec.slice __opcode 0 16)
        (decode_udf_perm_undef_aarch64_instrs_udf imm16))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_SME (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_SME"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_Unallocated1 (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_Unallocated1"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_SVE (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_SVE"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_Unallocated2 (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_Unallocated2"))

/-- Type quantifiers: pc : Int -/
def __DecodeA64_DataProcImm (pc : Int) (__opcode : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x22#8 : (BitVec 8)))) <&&> (do
       (pure ((← readReg SEE) <b 18))))) : Bool)
  then
    (do writeReg SEE 18
        let Rd := (BitVec.slice __opcode 0 5)
        let Rn := (BitVec.slice __opcode 5 5)
        let imm12 := (BitVec.slice __opcode 10 12)
        let sh := (BitVec.slice __opcode 22 1)
        let S := (BitVec.slice __opcode 29 1)
        let op := (BitVec.slice __opcode 30 1)
        let sf := (BitVec.slice __opcode 31 1)
        (decode_add_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
  else
    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x62#8 : (BitVec 8)))) <&&> (do
             (pure ((← readReg SEE) <b 19))))) : Bool)
        then
          (do writeReg SEE 19
              let Rd := (BitVec.slice __opcode 0 5)
              let Rn := (BitVec.slice __opcode 5 5)
              let imm12 := (BitVec.slice __opcode 10 12)
              let sh := (BitVec.slice __opcode 22 1)
              let S := (BitVec.slice __opcode 29 1)
              let op := (BitVec.slice __opcode 30 1)
              let sf := (BitVec.slice __opcode 31 1)
              (decode_adds_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
        else
          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA2#8 : (BitVec 8)))) <&&> (do
                   (pure ((← readReg SEE) <b 20))))) : Bool)
              then
                (do writeReg SEE 20
                    let Rd := (BitVec.slice __opcode 0 5)
                    let Rn := (BitVec.slice __opcode 5 5)
                    let imm12 := (BitVec.slice __opcode 10 12)
                    let sh := (BitVec.slice __opcode 22 1)
                    let S := (BitVec.slice __opcode 29 1)
                    let op := (BitVec.slice __opcode 30 1)
                    let sf := (BitVec.slice __opcode 31 1)
                    (decode_sub_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
              else
                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE2#8 : (BitVec 8)))) <&&> (do
                         (pure ((← readReg SEE) <b 21))))) : Bool)
                    then
                      (do writeReg SEE 21
                          let Rd := (BitVec.slice __opcode 0 5)
                          let Rn := (BitVec.slice __opcode 5 5)
                          let imm12 := (BitVec.slice __opcode 10 12)
                          let sh := (BitVec.slice __opcode 22 1)
                          let S := (BitVec.slice __opcode 29 1)
                          let op := (BitVec.slice __opcode 30 1)
                          let sf := (BitVec.slice __opcode 31 1)
                          (decode_subs_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
                    else
                      (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 22) == (0b1001000110#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb __opcode 15 14) == (0b00#2 : (BitVec 2))))) <&&> (do
                               (pure ((← readReg SEE) <b 26))))) : Bool)
                          then
                            (do writeReg SEE 26
                                sailThrow ((Error_ImplementationDefined "janus-excluded decode_addg_aarch64_instrs_integer_tags_mcaddtag")))
                          else
                            (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 31) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb __opcode 28 24) == (0b10000#5 : (BitVec 5))))) <&&> (do
                                     (pure ((← readReg SEE) <b 34))))) : Bool)
                                then
                                  (do writeReg SEE 34
                                      let Rd := (BitVec.slice __opcode 0 5)
                                      let immhi := (BitVec.slice __opcode 5 19)
                                      let immlo := (BitVec.slice __opcode 29 2)
                                      let op := (BitVec.slice __opcode 31 1)
                                      (decode_adr_aarch64_instrs_integer_arithmetic_address_pc_rel Rd immhi immlo op))
                                else
                                  (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 31) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb __opcode 28 24) == (0b10000#5 : (BitVec 5))))) <&&> (do
                                           (pure ((← readReg SEE) <b 35))))) : Bool)
                                      then
                                        (do writeReg SEE 35
                                            let Rd := (BitVec.slice __opcode 0 5)
                                            let immhi := (BitVec.slice __opcode 5 19)
                                            let immlo := (BitVec.slice __opcode 29 2)
                                            let op := (BitVec.slice __opcode 31 1)
                                            (decode_adrp_aarch64_instrs_integer_arithmetic_address_pc_rel Rd immhi immlo op))
                                      else
                                        (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x24#8 : (BitVec 8)))) <&&> (do
                                                 (pure ((← readReg SEE) <b 40))))) : Bool)
                                            then
                                              (do writeReg SEE 40
                                                  let Rd := (BitVec.slice __opcode 0 5)
                                                  let Rn := (BitVec.slice __opcode 5 5)
                                                  let imms := (BitVec.slice __opcode 10 6)
                                                  let immr := (BitVec.slice __opcode 16 6)
                                                  let N := (BitVec.slice __opcode 22 1)
                                                  let opc := (BitVec.slice __opcode 29 2)
                                                  let sf := (BitVec.slice __opcode 31 1)
                                                  (decode_and_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                            else
                                              (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE4#8 : (BitVec 8)))) <&&> (do
                                                       (pure ((← readReg SEE) <b 41))))) : Bool)
                                                  then
                                                    (do writeReg SEE 41
                                                        let Rd := (BitVec.slice __opcode 0 5)
                                                        let Rn := (BitVec.slice __opcode 5 5)
                                                        let imms := (BitVec.slice __opcode 10 6)
                                                        let immr := (BitVec.slice __opcode 16 6)
                                                        let N := (BitVec.slice __opcode 22 1)
                                                        let opc := (BitVec.slice __opcode 29 2)
                                                        let sf := (BitVec.slice __opcode 31 1)
                                                        (decode_ands_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                  else
                                                    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA4#8 : (BitVec 8)))) <&&> (do
                                                             (pure ((← readReg SEE) <b 42))))) : Bool)
                                                        then
                                                          (do writeReg SEE 42
                                                              let Rd := (BitVec.slice __opcode 0 5)
                                                              let Rn := (BitVec.slice __opcode 5 5)
                                                              let imms := (BitVec.slice __opcode 10 6)
                                                              let immr := (BitVec.slice __opcode 16 6)
                                                              let N := (BitVec.slice __opcode 22 1)
                                                              let opc := (BitVec.slice __opcode 29 2)
                                                              let sf := (BitVec.slice __opcode 31 1)
                                                              (decode_eor_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                        else
                                                          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x64#8 : (BitVec 8)))) <&&> (do
                                                                   (pure ((← readReg SEE) <b 43))))) : Bool)
                                                              then
                                                                (do writeReg SEE 43
                                                                    let Rd := (BitVec.slice __opcode 0 5)
                                                                    let Rn := (BitVec.slice __opcode 5 5)
                                                                    let imms := (BitVec.slice __opcode 10 6)
                                                                    let immr := (BitVec.slice __opcode 16 6)
                                                                    let N := (BitVec.slice __opcode 22 1)
                                                                    let opc := (BitVec.slice __opcode 29 2)
                                                                    let sf := (BitVec.slice __opcode 31 1)
                                                                    (decode_orr_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                              else
                                                                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x66#8 : (BitVec 8)))) <&&> (do
                                                                         (pure ((← readReg SEE) <b 76))))) : Bool)
                                                                    then
                                                                      (do writeReg SEE 76
                                                                          let Rd := (BitVec.slice __opcode 0 5)
                                                                          let Rn := (BitVec.slice __opcode 5 5)
                                                                          let imms := (BitVec.slice __opcode 10 6)
                                                                          let immr := (BitVec.slice __opcode 16 6)
                                                                          let N := (BitVec.slice __opcode 22 1)
                                                                          let opc := (BitVec.slice __opcode 29 2)
                                                                          let sf := (BitVec.slice __opcode 31 1)
                                                                          (decode_bfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                    else
                                                                      (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x26#8 : (BitVec 8)))) <&&> (do
                                                                               (pure ((← readReg SEE) <b 77))))) : Bool)
                                                                          then
                                                                            (do writeReg SEE 77
                                                                                let Rd := (BitVec.slice __opcode 0 5)
                                                                                let Rn := (BitVec.slice __opcode 5 5)
                                                                                let imms := (BitVec.slice __opcode 10 6)
                                                                                let immr := (BitVec.slice __opcode 16 6)
                                                                                let N := (BitVec.slice __opcode 22 1)
                                                                                let opc := (BitVec.slice __opcode 29 2)
                                                                                let sf := (BitVec.slice __opcode 31 1)
                                                                                (decode_sbfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                          else
                                                                            (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA6#8 : (BitVec 8)))) <&&> (do
                                                                                     (pure ((← readReg SEE) <b 78))))) : Bool)
                                                                                then
                                                                                  (do writeReg SEE 78
                                                                                      let Rd := (BitVec.slice __opcode 0 5)
                                                                                      let Rn := (BitVec.slice __opcode 5 5)
                                                                                      let imms := (BitVec.slice __opcode 10 6)
                                                                                      let immr := (BitVec.slice __opcode 16 6)
                                                                                      let N := (BitVec.slice __opcode 22 1)
                                                                                      let opc := (BitVec.slice __opcode 29 2)
                                                                                      let sf := (BitVec.slice __opcode 31 1)
                                                                                      (decode_ubfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                                else
                                                                                  (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 30 23) == (0x27#8 : (BitVec 8))) && ((Sail.BitVec.extractLsb __opcode 21 21) == (0#1 : (BitVec 1))))) <&&> (do
                                                                                           (pure ((← readReg SEE) <b 206))))) : Bool)
                                                                                      then
                                                                                        (do writeReg SEE 206
                                                                                            let Rd := (BitVec.slice __opcode 0 5)
                                                                                            let Rn := (BitVec.slice __opcode 5 5)
                                                                                            let imms := (BitVec.slice __opcode 10 6)
                                                                                            let Rm := (BitVec.slice __opcode 16 5)
                                                                                            let N := (BitVec.slice __opcode 22 1)
                                                                                            let sf := (BitVec.slice __opcode 31 1)
                                                                                            (decode_extr_aarch64_instrs_integer_ins_ext_extract_immediate Rd Rn imms Rm N sf))
                                                                                      else
                                                                                        (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE5#8 : (BitVec 8)))) <&&> (do
                                                                                                 (pure ((← readReg SEE) <b 696))))) : Bool)
                                                                                            then
                                                                                              (do writeReg SEE 696
                                                                                                  let Rd := (BitVec.slice __opcode 0 5)
                                                                                                  let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                  let hw := (BitVec.slice __opcode 21 2)
                                                                                                  let opc := (BitVec.slice __opcode 29 2)
                                                                                                  let sf := (BitVec.slice __opcode 31 1)
                                                                                                  (decode_movk_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                            else
                                                                                              (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x25#8 : (BitVec 8)))) <&&> (do
                                                                                                       (pure ((← readReg SEE) <b 697))))) : Bool)
                                                                                                  then
                                                                                                    (do writeReg SEE 697
                                                                                                        let Rd := (BitVec.slice __opcode 0 5)
                                                                                                        let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                        let hw := (BitVec.slice __opcode 21 2)
                                                                                                        let opc := (BitVec.slice __opcode 29 2)
                                                                                                        let sf := (BitVec.slice __opcode 31 1)
                                                                                                        (decode_movn_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                                  else
                                                                                                    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA5#8 : (BitVec 8)))) <&&> (do
                                                                                                             (pure ((← readReg SEE) <b 698))))) : Bool)
                                                                                                        then
                                                                                                          (do writeReg SEE 698
                                                                                                              let Rd := (BitVec.slice __opcode 0 5)
                                                                                                              let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                              let hw := (BitVec.slice __opcode 21 2)
                                                                                                              let opc := (BitVec.slice __opcode 29 2)
                                                                                                              let sf := (BitVec.slice __opcode 31 1)
                                                                                                              (decode_movz_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                                        else
                                                                                                          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110000#13 : (BitVec 13)))) <&&> (do
                                                                                                                   (pure ((← readReg SEE) <b 832))))) : Bool)
                                                                                                              then
                                                                                                                (do writeReg SEE 832
                                                                                                                    sailThrow ((Error_ImplementationDefined "janus-excluded decode_smax_imm_aarch64_instrs_integer_arithmetic_max_min_smax_imm")))
                                                                                                              else
                                                                                                                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110010#13 : (BitVec 13)))) <&&> (do
                                                                                                                         (pure ((← readReg SEE) <b 847))))) : Bool)
                                                                                                                    then
                                                                                                                      (do writeReg SEE 847
                                                                                                                          sailThrow ((Error_ImplementationDefined "janus-excluded decode_smin_imm_aarch64_instrs_integer_arithmetic_max_min_smin_imm")))
                                                                                                                    else
                                                                                                                      (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 22) == (0b1101000110#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb __opcode 15 14) == (0b00#2 : (BitVec 2))))) <&&> (do
                                                                                                                               (pure ((← readReg SEE) <b 990))))) : Bool)
                                                                                                                          then
                                                                                                                            (do writeReg SEE 990
                                                                                                                                sailThrow ((Error_ImplementationDefined "janus-excluded decode_subg_aarch64_instrs_integer_tags_mcsubtag")))
                                                                                                                          else
                                                                                                                            (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110001#13 : (BitVec 13)))) <&&> (do
                                                                                                                                     (pure ((← readReg SEE) <b 1018))))) : Bool)
                                                                                                                                then
                                                                                                                                  (do writeReg SEE 1018
                                                                                                                                      sailThrow ((Error_ImplementationDefined "janus-excluded decode_umax_imm_aarch64_instrs_integer_arithmetic_max_min_umax_imm")))
                                                                                                                                else
                                                                                                                                  (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110011#13 : (BitVec 13)))) <&&> (do
                                                                                                                                           (pure ((← readReg SEE) <b 1021))))) : Bool)
                                                                                                                                      then
                                                                                                                                        (do writeReg SEE 1021
                                                                                                                                            sailThrow ((Error_ImplementationDefined "janus-excluded decode_umin_imm_aarch64_instrs_integer_arithmetic_max_min_umin_imm")))
                                                                                                                                      else (do sailThrow ((Error_Undefined ()))))))))))))))))))))))))))))))))))))))))))))))))


end ArmASL.Functions
