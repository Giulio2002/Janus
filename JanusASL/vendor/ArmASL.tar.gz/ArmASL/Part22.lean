import ArmASL.Part21

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_sev_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_sevl_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_yield_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_cas_single (acquire : Bool) (datasize : Nat) (n : Nat) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_CAS acquire release tagchecked) ) : SailM AccessDescriptor )
  let comparevalue ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let newvalue ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (MemAtomic address comparevalue newvalue accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:6299.44-6299.45"
  (X_set s regsize (Sail.BitVec.zeroExtend data regsize))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_cas_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

def decode_casb_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

def decode_cash_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_memory_atomicops_cas_pair (acquire : Bool) (datasize : Nat) (n : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let s1 ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let s2 ← (( do (X_read (s +i 1) datasize) ) : SailM (BitVec datasize) )
  let t1 ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let t2 ← (( do (X_read (t +i 1) datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_CAS acquire release tagchecked) ) : SailM AccessDescriptor )
  let comparevalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (s1 +++ s2)))
    else (do (pure (s2 +++ s1)))) ) : SailM (BitVec (2 * datasize)) )
  let newvalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (t1 +++ t2)))
    else (do (pure (t2 +++ t1)))) ) : SailM (BitVec (2 * datasize)) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (MemAtomic address comparevalue newvalue accdesc) ) : SailM (BitVec (2 * datasize)) )
  (if ((← (BigEndian accdesc.acctype)) : Bool)
  then
    (do (X_set s datasize (Sail.BitVec.extractLsb data ((2 *i datasize) -i 1) datasize))
        (X_set (s +i 1) datasize (Sail.BitVec.extractLsb data (datasize -i 1) 0)))
  else
    (do (X_set s datasize (Sail.BitVec.extractLsb data (datasize -i 1) 0))
        (X_set (s +i 1) datasize (Sail.BitVec.extractLsb data ((2 *i datasize) -i 1) datasize))))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_casp_aarch64_instrs_memory_atomicops_cas_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access Rs 0) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access Rt 0) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize := datasize
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_pair acquire datasize n release s t tagchecked)

/-- Type quantifiers: datasize : Nat, k_iszero : Bool, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_branch_conditional_compare (datasize : Nat) (iszero : Bool) (offset : (BitVec 64)) (t : Nat) : SailM Unit := do
  let operand1 ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let branch_conditional : Bool := true
  (if (((IsZero operand1) == iszero) : Bool)
  then (do (BranchTo ((← (PC_read ())) + offset) BranchType_DIR branch_conditional))
  else (do (BranchNotTaken BranchType_DIR branch_conditional)))

def decode_cbnz_aarch64_instrs_branch_conditional_compare (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let iszero : Bool := (op == 0#1)
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_compare datasize iszero offset t)

def decode_cbz_aarch64_instrs_branch_conditional_compare (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let iszero : Bool := (op == 0#1)
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_compare datasize iszero offset t)

/-- Type quantifiers: datasize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_integer_conditional_compare_register (condition : (BitVec 4)) (datasize : Nat) (flags__arg : (BitVec 4)) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let flags : (BitVec 4) := flags__arg
  let taken : Bool := false
  let (flags, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
          let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
          let carry_in : (BitVec 1) := 0#1
          let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
            if (sub_op : Bool)
            then
              (let operand2 : (BitVec datasize) := (Complement.complement operand2)
              let carry_in : (BitVec 1) := 1#1
              (carry_in, operand2))
            else (carry_in, operand2)
          let flags : (BitVec 4) :=
            let (_, __tup_1) := (AddWithCarry operand1 operand2 carry_in)
            __tup_1
          let taken : Bool := true
          (pure (flags, taken)))
    else (do (pure (flags, taken)))) ) : SailM ((BitVec 4) × Bool) )
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb flags 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb flags 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb flags 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb flags 0 0) }
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_ccmn_reg_aarch64_instrs_integer_conditional_compare_register (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_integer_conditional_compare_register condition datasize flags m n sub_op)

def decode_ccmp_reg_aarch64_instrs_integer_conditional_compare_register (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_integer_conditional_compare_register condition datasize flags m n sub_op)

/-- Type quantifiers: datasize : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_integer_conditional_compare_immediate (condition : (BitVec 4)) (datasize : Nat) (flags__arg : (BitVec 4)) (imm : (BitVec datasize)) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let flags : (BitVec 4) := flags__arg
  let taken : Bool := false
  let (flags, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
          let operand2 : (BitVec datasize) := imm
          let carry_in : (BitVec 1) := 0#1
          let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
            if (sub_op : Bool)
            then
              (let operand2 : (BitVec datasize) := (Complement.complement operand2)
              let carry_in : (BitVec 1) := 1#1
              (carry_in, operand2))
            else (carry_in, operand2)
          let flags : (BitVec 4) :=
            let (_, __tup_1) := (AddWithCarry operand1 operand2 carry_in)
            __tup_1
          let taken : Bool := true
          (pure (flags, taken)))
    else (do (pure (flags, taken)))) ) : SailM ((BitVec 4) × Bool) )
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb flags 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb flags 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb flags 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb flags 0 0) }
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_ccmn_imm_aarch64_instrs_integer_conditional_compare_immediate (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (imm5 : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  let imm : (BitVec datasize) := (Sail.BitVec.zeroExtend imm5 datasize)
  (execute_aarch64_instrs_integer_conditional_compare_immediate condition datasize flags imm n sub_op)

def decode_ccmp_imm_aarch64_instrs_integer_conditional_compare_immediate (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (imm5 : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  let imm : (BitVec datasize) := (Sail.BitVec.zeroExtend imm5 datasize)
  (execute_aarch64_instrs_integer_conditional_compare_immediate condition datasize flags imm n sub_op)

def execute_aarch64_instrs_system_monitors (_ : Unit) : SailM Unit := do
  (ClearExclusiveLocal (ProcessorID ()))

def decode_clrex_aarch64_instrs_system_monitors (CRm : (BitVec 4)) : SailM Unit := do
  (execute_aarch64_instrs_system_monitors ())

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_clsz (countop : CountOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let count ← (( do (undefined_int ()) ) : SailM Int )
  let (count, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (count, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (count, result) := loop_vars
      loop_vars ← do
        let count ← (( do
          (if ((BEq.beq countop CountOp_CLS) : Bool)
          then (do (pure (CountLeadingSignBits (← (Elem_read operand e esize)))))
          else (do (pure (CountLeadingZeroBits (← (Elem_read operand e esize)))))) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange count (esize -i 1) 0))
        (pure (count, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_cls_advsimd_aarch64_instrs_vector_arithmetic_unary_clsz (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let countop : CountOp :=
    if ((U == 1#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_vector_arithmetic_unary_clsz countop d datasize elements esize n)

def decode_clz_advsimd_aarch64_instrs_vector_arithmetic_unary_clsz (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let countop : CountOp :=
    if ((U == 1#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_vector_arithmetic_unary_clsz countop d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_cnt (d : Nat) (datasize : Nat) (n : Nat) (opcode : CountOp) : SailM Unit := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result : Int :=
    if ((BEq.beq opcode CountOp_CLZ) : Bool)
    then (CountLeadingZeroBits operand1)
    else (CountLeadingSignBits operand1)
  let result := result
  (X_set d datasize (integer_subrange result (datasize -i 1) 0))

def decode_cls_int_aarch64_instrs_integer_arithmetic_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let opcode : CountOp :=
    if ((op == 0#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_integer_arithmetic_cnt d datasize n opcode)

def decode_clz_int_aarch64_instrs_integer_arithmetic_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let opcode : CountOp :=
    if ((op == 0#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_integer_arithmetic_cnt d datasize n opcode)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (comparison : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, test_passed) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let test_passed : Bool :=
          match comparison with
          | .CompareOp_GT => (element >b 0)
          | .CompareOp_GE => (element ≥b 0)
          | .CompareOp_EQ => (element == 0)
          | .CompareOp_LE => (element ≤b 0)
          | .CompareOp_LT => (element <b 0)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element, result, test_passed))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmeq_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmeq_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmge_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmge_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmgt_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmgt_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmle_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmle_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

/-- Type quantifiers: k_and_test : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (and_test : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, test_passed) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let test_passed : Bool :=
          if (and_test : Bool)
          then (! (IsZero (element1 &&& element2)))
          else (element1 == element2)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element1, element2, result, test_passed))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmtst_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmtst_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

/-- Type quantifiers: k_cmp_eq : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (cmp_eq : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, test_passed) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let test_passed : Bool :=
          if (cmp_eq : Bool)
          then (element1 ≥b element2)
          else (element1 >b element2)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element1, element2, result, test_passed))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhi_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhi_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhs_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhs_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd (comparison : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, test_passed) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let test_passed : Bool :=
          match comparison with
          | .CompareOp_GT => (element >b 0)
          | .CompareOp_GE => (element ≥b 0)
          | .CompareOp_EQ => (element == 0)
          | .CompareOp_LE => (element ≤b 0)
          | .CompareOp_LT => (element <b 0)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element, result, test_passed))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmlt_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let comparison : CompareOp := CompareOp_LT
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd comparison d datasize elements esize n)

def decode_cmlt_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison : CompareOp := CompareOp_LT
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd comparison d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cnt (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let count ← (( do (undefined_int ()) ) : SailM Int )
  let (count, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (count, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (count, result) := loop_vars
      loop_vars ← do
        let count ← (( (pure (BitCount (← (Elem_read operand e esize)))) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange count (esize -i 1) 0))
        (pure (count, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_cnt_advsimd_aarch64_instrs_vector_arithmetic_unary_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b00#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_cnt d datasize elements esize n)

/-- Type quantifiers: k_crc32c : Bool, d : Nat, m : Nat, n : Nat, size : Nat, List.elem size [8, 16, 32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_crc (crc32c : Bool) (d : Nat) (m : Nat) (n : Nat) (size : Nat) : SailM Unit := do
  let acc ← (( do (X_read n 32) ) : SailM (BitVec 32) )
  let val_name ← (( do (X_read m size) ) : SailM (BitVec size) )
  let poly : (BitVec 32) :=
    (integer_subrange
      (if (crc32c : Bool)
      then (BitVec.toNat 0x1EDC6F41#32)
      else (BitVec.toNat 0x04C11DB7#32)) 31 0)
  let tempacc ← (( do (pure ((← (BitReverse acc)) +++ (Zeros (n := size)))) ) : SailM (BitVec (32 + size)) )
  let tempval ← (( do (pure ((← (BitReverse val_name)) +++ (Zeros (n := 32)))) ) : SailM (BitVec (size + 32)) )
  (X_set d 32 (← (BitReverse (← (Poly32Mod2 (tempacc ^^^ tempval) poly)))))

def decode_crc32_aarch64_instrs_integer_crc (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 2)) (C : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveCRCExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sf == 1#1) && (sz != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (sz == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let size := (Int.shiftl 8 (BitVec.toNat sz))
  let crc32c : Bool := (C == 1#1)
  (execute_aarch64_instrs_integer_crc crc32c d m n size)

def decode_crc32c_aarch64_instrs_integer_crc (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 2)) (C : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveCRCExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sf == 1#1) && (sz != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (sz == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let size := (Int.shiftl 8 (BitVec.toNat sz))
  let crc32c : Bool := (C == 1#1)
  (execute_aarch64_instrs_integer_crc crc32c d m n size)

/-- Type quantifiers: d : Nat, datasize : Nat, k_else_inc : Bool, k_else_inv : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_conditional_select (condition : (BitVec 4)) (d : Nat) (datasize : Nat) (else_inc : Bool) (else_inv : Bool) (m : Nat) (n : Nat) : SailM Unit := do
  let taken : Bool := false
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (result, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let result ← (X_read n datasize)
          let taken : Bool := true
          (pure (result, taken)))
    else
      (do let result ← (X_read m datasize)
          let result : (BitVec datasize) :=
            if (else_inv : Bool)
            then (Complement.complement result)
            else result
          let result : (BitVec datasize) :=
            if (else_inc : Bool)
            then (BitVec.addInt result 1)
            else result
          (pure (result, taken)))) ) : SailM ((BitVec datasize) × Bool) )
  (X_set d datasize result)
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_csel_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csinc_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csinv_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csneg_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def execute_aarch64_instrs_system_barriers_dmb (domain : MBReqDomain) (types : MBReqTypes) : SailM Unit := do
  (DataMemoryBarrier domain types)

def decode_dmb_aarch64_instrs_system_barriers_dmb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  let domain ← (( do (undefined_MBReqDomain ()) ) : SailM MBReqDomain )
  let types ← (( do (undefined_MBReqTypes ()) ) : SailM MBReqTypes )
  let domain : MBReqDomain :=
    match (Sail.BitVec.extractLsb CRm 3 2) with
    | 0b00 => MBReqDomain_OuterShareable
    | 0b01 => MBReqDomain_Nonshareable
    | 0b10 => MBReqDomain_InnerShareable
    | _ => MBReqDomain_FullSystem
  let (domain, types) : (MBReqDomain × MBReqTypes) :=
    match (Sail.BitVec.extractLsb CRm 1 0) with
    | 0b00 =>
      (let types : MBReqTypes := MBReqTypes_All
      let domain : MBReqDomain := MBReqDomain_FullSystem
      (domain, types))
    | 0b01 =>
      (let types : MBReqTypes := MBReqTypes_Reads
      (domain, types))
    | 0b10 =>
      (let types : MBReqTypes := MBReqTypes_Writes
      (domain, types))
    | _ =>
      (let types : MBReqTypes := MBReqTypes_All
      (domain, types))
  let types := types
  (execute_aarch64_instrs_system_barriers_dmb domain types)

/-- Type quantifiers: k_nXS : Bool -/
def execute_aarch64_instrs_system_barriers_dsb (alias' : DSBAlias) (domain : MBReqDomain) (nXS__arg : Bool) (types : MBReqTypes) : SailM Unit := do
  let nXS : Bool := nXS__arg
  match alias' with
  | .DSBAlias_SSBB => (pure (SpeculativeStoreBypassBarrierToVA ()))
  | .DSBAlias_PSSBB => (pure (SpeculativeStoreBypassBarrierToPA ()))
  | .DSBAlias_DSB =>
    (do
      (if ((←((HaveTME ()) <&&> (do
           (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
      then (do (FailTransaction TMFailure_ERR false))
      else (do (pure ())))
      let nXS ← (( do
        (if ((←((pure (! nXS)) <&&> (do
             (HaveFeatXS ())))) : Bool)
        then (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_FnXS (← readReg HCRX_EL2)) == 1#1))))
        else (do (pure nXS))) ) : SailM Bool )
      (DataSynchronizationBarrier domain types nXS))

def decode_dsb_aarch64_instrs_system_barriers_dsb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  let nXS : Bool := false
  let alias' ← (( do (undefined_DSBAlias ()) ) : SailM DSBAlias )
  let alias' : DSBAlias :=
    match CRm with
    | 0b0000 => DSBAlias_SSBB
    | 0b0100 => DSBAlias_PSSBB
    | _ => DSBAlias_DSB
  let alias' := alias'
  let domain ← (( do (undefined_MBReqDomain ()) ) : SailM MBReqDomain )
  let domain : MBReqDomain :=
    match (Sail.BitVec.extractLsb CRm 3 2) with
    | 0b00 => MBReqDomain_OuterShareable
    | 0b01 => MBReqDomain_Nonshareable
    | 0b10 => MBReqDomain_InnerShareable
    | _ => MBReqDomain_FullSystem
  let types ← (( do (undefined_MBReqTypes ()) ) : SailM MBReqTypes )
  let (domain, types) : (MBReqDomain × MBReqTypes) :=
    match (Sail.BitVec.extractLsb CRm 1 0) with
    | 0b00 =>
      (let types : MBReqTypes := MBReqTypes_All
      let domain : MBReqDomain := MBReqDomain_FullSystem
      (domain, types))
    | 0b01 =>
      (let types : MBReqTypes := MBReqTypes_Reads
      (domain, types))
    | 0b10 =>
      (let types : MBReqTypes := MBReqTypes_Writes
      (domain, types))
    | _ =>
      (let types : MBReqTypes := MBReqTypes_All
      (domain, types))
  (execute_aarch64_instrs_system_barriers_dsb alias' domain nXS types)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ List.elem datasize [8, 16, 32, 64, 128, 256] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (Elem_read operand index esize) ) : SailM (BitVec esize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize element)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10164.56-10164.57"
  (V_set d datasize result)

def decode_dup_advsimd_elt_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10177.37-10177.38"
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 size)
  let datasize := esize
  let elements := 1
  sail_assert (((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) && ((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256))) "sail-arm/arm-v9.4-a/src/instrs64.sail:10183.101-10183.102"
  (execute_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd d datasize elements esize idxdsize index n)

def decode_dup_advsimd_elt_aarch64_instrs_vector_transfer_vector_cpy_dup_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10204.37-10204.38"
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  (if (((size == 3) && (Q == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10213.58-10213.59"
  (execute_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd d datasize elements esize idxdsize index n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_dup (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10232.48-10232.49"
  let element ← (( do (X_read n esize) ) : SailM (BitVec esize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize element)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_dup_advsimd_gen_aarch64_instrs_vector_transfer_integer_dup (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((size == 3) && (Q == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10256.58-10256.59"
  (execute_aarch64_instrs_vector_transfer_integer_dup d datasize elements esize n)

/-- Type quantifiers: a : Nat, d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3_eor3 (a : Nat) (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vm ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let Vn ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let Va ← (( do (V_read a 128) ) : SailM (BitVec 128) )
  (V_set d 128 ((Vn ^^^ Vm) ^^^ Va))

def decode_eor3_advsimd_aarch64_instrs_vector_crypto_sha3_eor3 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA3Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  (execute_aarch64_instrs_vector_crypto_sha3_eor3 a d m n)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, position : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_extract (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (position : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let hi ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let lo ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (datasize * 2)) := (hi +++ lo)
  sail_assert ((0 ≤b position) && (((position +i datasize) -i 1) <b (datasize *i 2))) "sail-arm/arm-v9.4-a/src/instrs64.sail:10379.83-10379.84"
  (V_set d datasize (Sail.BitVec.extractLsb concat ((position +i datasize) -i 1) position))

def decode_ext_advsimd_aarch64_instrs_vector_transfer_vector_extract (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm4 : (BitVec 4)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((Q == 0#1) && (((BitVec.access imm4 3) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let position := (Int.shiftl (BitVec.toNat imm4) 3)
  (execute_aarch64_instrs_vector_transfer_vector_extract d datasize m n position)

/-- Type quantifiers: d : Nat, datasize : Nat, lsb : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ lsb ∧ lsb ≤ 63 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_ins_ext_extract_immediate (d : Nat) (datasize : Nat) (lsb : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand1 +++ operand2)
  sail_assert (((lsb +i datasize) -i 1) <b (2 *i datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10415.59-10415.60"
  let result : (BitVec datasize) := (Sail.BitVec.extractLsb concat ((lsb +i datasize) -i 1) lsb)
  (X_set d datasize result)

def decode_extr_aarch64_instrs_integer_ins_ext_extract_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  (if ((N != sf) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imms 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let lsb := (BitVec.toNat imms)
  (execute_aarch64_instrs_integer_ins_ext_extract_immediate d datasize lsb m n)

/-- Type quantifiers: k_abs : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp16_sisd (abs : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let diff ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (diff, element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (diff, element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (diff, element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let diff ← (FPSub element1 element2 fpcr)
        let result ←
          (Elem_set result e esize
            (← do
              (if (abs : Bool)
              then (do (FPAbs diff))
              else (do (pure diff)))))
        (pure (diff, element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fabd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let abs : Bool := true
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp16_sisd abs d datasize elements esize m n)

def decode_fabd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let abs : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp16_sisd abs d datasize elements esize m n)

/-- Type quantifiers: d : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_unary (d : Nat) (esize : Nat) (fpop : FPUnaryOp) (n : Nat) : SailM Unit := do
  (CheckFPEnabled64 ())
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (bne fpop FPUnaryOp_MOV)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (integer_subrange 0 127 0)))) ) : SailM (BitVec 128) )
  let operand ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let result ← (( do
    match fpop with
    | .FPUnaryOp_MOV => (do (Elem_set result 0 esize operand))
    | .FPUnaryOp_ABS => (do (Elem_set result 0 esize (← (FPAbs operand))))
    | .FPUnaryOp_NEG => (do (Elem_set result 0 esize (← (FPNeg operand))))
    | .FPUnaryOp_SQRT => (do (Elem_set result 0 esize (← (FPSqrt operand fpcr)))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_fabs_float_aarch64_instrs_float_arithmetic_unary (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let fpop ← (( do (undefined_FPUnaryOp ()) ) : SailM FPUnaryOp )
  let fpop : FPUnaryOp :=
    match opc with
    | 0b00 => FPUnaryOp_MOV
    | 0b01 => FPUnaryOp_ABS
    | 0b10 => FPUnaryOp_NEG
    | _ => FPUnaryOp_SQRT
  let fpop := fpop
  (execute_aarch64_instrs_float_arithmetic_unary d esize fpop n)

def decode_fmov_float_aarch64_instrs_float_arithmetic_unary (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let fpop ← (( do (undefined_FPUnaryOp ()) ) : SailM FPUnaryOp )
  let fpop : FPUnaryOp :=
    match opc with
    | 0b00 => FPUnaryOp_MOV
    | 0b01 => FPUnaryOp_ABS
    | 0b10 => FPUnaryOp_NEG
    | _ => FPUnaryOp_SQRT
  let fpop := fpop
  (execute_aarch64_instrs_float_arithmetic_unary d esize fpop n)

def decode_fneg_float_aarch64_instrs_float_arithmetic_unary (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let fpop ← (( do (undefined_FPUnaryOp ()) ) : SailM FPUnaryOp )
  let fpop : FPUnaryOp :=
    match opc with
    | 0b00 => FPUnaryOp_MOV
    | 0b01 => FPUnaryOp_ABS
    | 0b10 => FPUnaryOp_NEG
    | _ => FPUnaryOp_SQRT
  let fpop := fpop
  (execute_aarch64_instrs_float_arithmetic_unary d esize fpop n)

def decode_fsqrt_float_aarch64_instrs_float_arithmetic_unary (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let fpop ← (( do (undefined_FPUnaryOp ()) ) : SailM FPUnaryOp )
  let fpop : FPUnaryOp :=
    match opc with
    | 0b00 => FPUnaryOp_MOV
    | 0b01 => FPUnaryOp_ABS
    | 0b10 => FPUnaryOp_NEG
    | _ => FPUnaryOp_SQRT
  let fpop := fpop
  (execute_aarch64_instrs_float_arithmetic_unary d esize fpop n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, k_neg : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_fp16 (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (neg : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let element ← (( do
          (if (neg : Bool)
          then (do (FPNeg element))
          else (do (FPAbs element))) ) : SailM (BitVec esize) )
        let result ← (Elem_set result e esize element)
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fabs_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_float (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_fp16 d datasize elements esize n neg)

def decode_fneg_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_float (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_fp16 d datasize elements esize n neg)

/-- Type quantifiers: k_abs : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd (abs : Bool) (cmp : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read m 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, element2, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, test_passed) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let (element1, element2) ← (( do
          (if (abs : Bool)
          then
            (do let element1 ← (FPAbs element1)
                let element2 ← (FPAbs element2)
                (pure (element1, element2)))
          else (do (pure (element1, element2)))) ) : SailM ((BitVec esize) × (BitVec esize)) )
        let test_passed ← (( do
          match cmp with
          | .CompareOp_EQ => (do (FPCompareEQ element1 element2 fpcr))
          | .CompareOp_GE => (do (FPCompareGE element1 element2 fpcr))
          | .CompareOp_GT => (do (FPCompareGT element1 element2 fpcr))
          | _ => (pure test_passed) ) : SailM Bool )
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element1, element2, result, test_passed))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec 128) × Bool) )
  (V_set d 128 result)

def decode_facge_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_facge_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_facgt_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_facgt_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

def decode_fcmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (E : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let cmp ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let abs ← (( do (undefined_bool ()) ) : SailM Bool )
  let (abs, cmp) ← (( do
    match ((E +++ U) +++ ac) with
    | 0b000 =>
      (let cmp : CompareOp := CompareOp_EQ
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b010 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b011 =>
      (let cmp : CompareOp := CompareOp_GE
      let abs : Bool := true
      (pure (abs, cmp)))
    | 0b110 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := false
      (pure (abs, cmp)))
    | 0b111 =>
      (let cmp : CompareOp := CompareOp_GT
      let abs : Bool := true
      (pure (abs, cmp)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × CompareOp) )
  let abs := abs
  let cmp := cmp
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_fp16_sisd abs cmp d datasize elements esize m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_pair : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp16 (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (pair : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand2 +++ operand1)
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let (element1, element2) ← (( do
          (if (pair : Bool)
          then
            (do let element1 ← (Elem_read concat (2 *i e) esize)
                let element2 ← (Elem_read concat ((2 *i e) +i 1) esize)
                (pure (element1, element2)))
          else
            (do let element1 ← (Elem_read operand1 e esize)
                let element2 ← (Elem_read operand2 e esize)
                (pure (element1, element2)))) ) : SailM ((BitVec esize) × (BitVec esize)) )
        let result ← (Elem_set result e esize (← (FPAdd element1 element2 (← (FPCR_read ())))))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp16 d datasize elements esize m n pair)

def decode_faddp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp16 d datasize elements esize m n pair)

/-- Type quantifiers: d : Nat, esize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_add_sub (d : Nat) (esize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let operand1 ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let operand2 ← (( do (V_read m esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let result ← (( do
    (if (sub_op : Bool)
    then (do (Elem_set result 0 esize (← (FPSub operand1 operand2 fpcr))))
    else (do (Elem_set result 0 esize (← (FPAdd operand1 operand2 fpcr))))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_fadd_float_aarch64_instrs_float_arithmetic_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let sub_op : Bool := (op == 1#1)
  (execute_aarch64_instrs_float_arithmetic_add_sub d esize m n sub_op)

def decode_fsub_float_aarch64_instrs_float_arithmetic_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let sub_op : Bool := (op == 1#1)
  (execute_aarch64_instrs_float_arithmetic_add_sub d esize m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_fp16_add_sisd (d : Nat) (datasize : Nat) (esize : Nat) (n : Nat) (op : ReduceOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  sail_assert (datasize ≥b esize) "sail-arm/arm-v9.4-a/src/instrs64.sail:12218.42-12218.43"
  (V_set d esize (← (Reduce op operand esize)))

def decode_faddp_advsimd_pair_aarch64_instrs_vector_reduce_fp_add_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := (esize *i 2)
  let elements := 2
  let op : ReduceOp := ReduceOp_FADD
  (execute_aarch64_instrs_vector_reduce_fp16_add_sisd d datasize esize n op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp_complex (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rot : (BitVec 1)) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element3 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element3, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := ((fdiv_int elements 2) -i 1)
    let mut loop_vars := (element1, element3, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element3, result) := loop_vars
      loop_vars ← do
        let (element1, element3) ← (( do
          match rot with
          | 0 =>
            (do
              sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:12279.55-12279.56"
              let element1 ← (FPNeg (← (Elem_read operand2 ((e *i 2) +i 1) esize)))
              let element3 ← (Elem_read operand2 (e *i 2) esize)
              (pure (element1, element3)))
          | _ =>
            (do
              let element1 ← (Elem_read operand2 ((e *i 2) +i 1) esize)
              sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:12285.55-12285.56"
              let element3 ← (FPNeg (← (Elem_read operand2 (e *i 2) esize)))
              (pure (element1, element3))) ) : SailM ((BitVec esize) × (BitVec esize)) )
        sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:12289.49-12289.50"
        let result ← (Elem_set result (e *i 2) esize (← (FPAdd (← (Elem_read operand1 (e *i 2) esize)) element1 (← (FPCR_read ())))))
        let result ← (Elem_set result ((e *i 2) +i 1) esize (← (FPAdd (← (Elem_read operand1 ((e *i 2) +i 1) esize)) element3 (← (FPCR_read ())))))
        (pure (element1, element3, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fcadd_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp_complex (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rot : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveFCADDExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b00#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((Q == 0#1) && (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  (if (((! (HaveFP16Ext ())) && (esize == 16)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_fp_complex d datasize elements esize m n rot)

/-- Type quantifiers: datasize : Nat, m : Nat, n : Nat, k_signal_all_nans : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [16, 32, 64] -/
def execute_aarch64_instrs_float_compare_cond (condition : (BitVec 4)) (datasize : Nat) (flags__arg : (BitVec 4)) (m : Nat) (n : Nat) (signal_all_nans : Bool) : SailM Unit := do
  let flags : (BitVec 4) := flags__arg
  (CheckFPEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let taken : Bool := false
  let (flags, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let flags ← (FPCompare operand1 operand2 signal_all_nans (← (FPCR_read ())))
          let taken : Bool := true
          (pure (flags, taken)))
    else (do (pure (flags, taken)))) ) : SailM ((BitVec 4) × Bool) )
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb flags 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb flags 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb flags 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb flags 0 0) }
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_fccmp_float_aarch64_instrs_float_compare_cond (nzcv : (BitVec 4)) (op : (BitVec 1)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize : Int := 16
  let datasize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let datasize := datasize
  let signal_all_nans : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_float_compare_cond condition datasize flags m n signal_all_nans)

def decode_fccmpe_float_aarch64_instrs_float_compare_cond (nzcv : (BitVec 4)) (op : (BitVec 1)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize : Int := 16
  let datasize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let datasize := datasize
  let signal_all_nans : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_float_compare_cond condition datasize flags m n signal_all_nans)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd (comparison : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let zero ← (( do (FPZero 0#1 esize) ) : SailM (BitVec esize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, test_passed) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let test_passed ← (( do
          match comparison with
          | .CompareOp_GT => (do (FPCompareGT element zero (← (FPCR_read ()))))
          | .CompareOp_GE => (do (FPCompareGE element zero (← (FPCR_read ()))))
          | .CompareOp_EQ => (do (FPCompareEQ element zero (← (FPCR_read ()))))
          | .CompareOp_LE => (do (FPCompareGE zero element (← (FPCR_read ()))))
          | .CompareOp_LT => (do (FPCompareGT zero element (← (FPCR_read ())))) ) : SailM Bool )
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element, result, test_passed))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_fcmeq_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmeq_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmge_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmge_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmgt_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmgt_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmle_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

def decode_fcmle_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_fp16_bulk_sisd comparison d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_complex (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rot : (BitVec 2)) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element3 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element4 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let (element1, element2, element3, element4, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := ((fdiv_int elements 2) -i 1)
    let mut loop_vars := (element1, element2, element3, element4, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, element3, element4, result) := loop_vars
      loop_vars ← do
        let (element1, element2, element3, element4) ← (( do
          match rot with
          | 0b00 =>
            (do
              let element1 ← (Elem_read operand2 (e *i 2) esize)
              let element2 ← (Elem_read operand1 (e *i 2) esize)
              let element3 ← (Elem_read operand2 ((e *i 2) +i 1) esize)
              let element4 ← (Elem_read operand1 (e *i 2) esize)
              (pure (element1, element2, element3, element4)))
          | 0b01 =>
            (do
              sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13089.55-13089.56"
              let element1 ← (FPNeg (← (Elem_read operand2 ((e *i 2) +i 1) esize)))
              let element2 ← (Elem_read operand1 ((e *i 2) +i 1) esize)
              let element3 ← (Elem_read operand2 (e *i 2) esize)
              let element4 ← (Elem_read operand1 ((e *i 2) +i 1) esize)
              (pure (element1, element2, element3, element4)))
          | 0b10 =>
            (do
              sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13096.55-13096.56"
              let element1 ← (FPNeg (← (Elem_read operand2 (e *i 2) esize)))
              let element2 ← (Elem_read operand1 (e *i 2) esize)
              let element3 ← (FPNeg (← (Elem_read operand2 ((e *i 2) +i 1) esize)))
              let element4 ← (Elem_read operand1 (e *i 2) esize)
              (pure (element1, element2, element3, element4)))
          | _ =>
            (do
              let element1 ← (Elem_read operand2 ((e *i 2) +i 1) esize)
              let element2 ← (Elem_read operand1 ((e *i 2) +i 1) esize)
              sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13105.55-13105.56"
              let element3 ← (FPNeg (← (Elem_read operand2 (e *i 2) esize)))
              let element4 ← (Elem_read operand1 ((e *i 2) +i 1) esize)
              (pure (element1, element2, element3, element4))) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec esize)) )
        sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13110.49-13110.50"
        let result ← (Elem_set result (e *i 2) esize (← (FPMulAdd (← (Elem_read operand3 (e *i 2) esize)) element2 element1 fpcr)))
        let result ← (Elem_set result ((e *i 2) +i 1) esize (← (FPMulAdd (← (Elem_read operand3 ((e *i 2) +i 1) esize)) element4 element3 fpcr)))
        (pure (element1, element2, element3, element4, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fcmla_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_complex (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rot : (BitVec 2)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveFCADDExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b00#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((Q == 0#1) && (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  (if (((! (HaveFP16Ext ())) && (esize == 16)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_complex d datasize elements esize m n rot)


end ArmASL.Functions
