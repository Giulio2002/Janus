import ArmASL.Part21

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_3fb61300ed3d0b2e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (12 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((12 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 12 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 12 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 12 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_5874322f7df6e594 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (2 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((2 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 2 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 2 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 2 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_6b9bd001fa5472bf (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (4 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((4 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 4 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 4 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 4 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_8596ad7b1510b4d0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (10 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((10 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 10 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 10 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 10 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_99531412fe248a70 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (11 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((11 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 11 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 11 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 11 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_9a01e4eef27687e1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (6 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((6 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 6 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 6 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 6 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_b844eaa7818871c4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (13 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((13 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 13 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 13 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 13 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_bbc38f4d76601b93 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (8 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((8 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 8 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 8 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 8 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_f25a750222e0315f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (1 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((1 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 1 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 1 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 1 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_0e74b22895679043 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (9 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((9 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 9 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 9 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 9 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_11bcd12fdb930549 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (6 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((6 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 6 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 6 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 6 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_1e44505a2360dca7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (7 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((7 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 7 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 7 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 7 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_1fb1fea2e690a0e3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (0 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((0 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 0 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 0 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 0 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_23079da74592c125 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (4 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((4 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 4 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 4 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 4 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_4c12a1266354ed31 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (3 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((3 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 3 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 3 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 3 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_5c185ce0c31c928c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (14 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((14 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 14 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 14 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 14 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_7c615d5af77d3ffb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (10 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((10 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 10 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 10 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 10 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_91254f0a6285bce0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (12 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((12 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 12 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 12 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 12 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_9a9c86f74847526f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (8 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((8 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 8 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 8 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 8 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_b09d023fdf3ab695 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (1 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((1 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 1 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 1 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 1 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_c2a564a92621de17 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (11 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((11 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 11 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 11 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 11 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_c31d1fb9ddb2a17a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (2 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((2 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 2 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 2 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 2 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWVR_EL1_SysRegWrite_e3e0a8c119a9f320 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (13 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((13 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 13 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 13 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWVR_EL1 (vectorUpdate (← readReg DBGWVR_EL1) 13 (Mk_DBGWVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))


end ArmASL.Functions
