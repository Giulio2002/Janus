import ArmASL.Part40

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_sevl_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_yield_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_cas_single (acquire : Bool) (datasize : Nat) (n : Nat) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_CAS acquire release tagchecked) ) : SailM AccessDescriptor )
  let comparevalue ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let newvalue ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (MemAtomic address comparevalue newvalue accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:6255.44-6255.45"
  (X_set s regsize (Sail.BitVec.zeroExtend data regsize))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_cas_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

def decode_casb_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

def decode_cash_aarch64_instrs_memory_atomicops_cas_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_single acquire datasize n regsize release s t tagchecked)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, n : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_memory_atomicops_cas_pair (acquire : Bool) (datasize : Nat) (n : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let s1 ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let s2 ← (( do (X_read (s +i 1) datasize) ) : SailM (BitVec datasize) )
  let t1 ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let t2 ← (( do (X_read (t +i 1) datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescAtomicOp MemAtomicOp_CAS acquire release tagchecked) ) : SailM AccessDescriptor )
  let comparevalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (s1 +++ s2)))
    else (do (pure (s2 +++ s1)))) ) : SailM (BitVec (2 * datasize)) )
  let newvalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (t1 +++ t2)))
    else (do (pure (t2 +++ t1)))) ) : SailM (BitVec (2 * datasize)) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (MemAtomic address comparevalue newvalue accdesc) ) : SailM (BitVec (2 * datasize)) )
  (if ((← (BigEndian accdesc.acctype)) : Bool)
  then
    (do (X_set s datasize (Sail.BitVec.extractLsb data ((2 *i datasize) -i 1) datasize))
        (X_set (s +i 1) datasize (Sail.BitVec.extractLsb data (datasize -i 1) 0)))
  else
    (do (X_set s datasize (Sail.BitVec.extractLsb data (datasize -i 1) 0))
        (X_set (s +i 1) datasize (Sail.BitVec.extractLsb data ((2 *i datasize) -i 1) datasize))))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_casp_aarch64_instrs_memory_atomicops_cas_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access Rs 0) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access Rt 0) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize := datasize
  let acquire : Bool := (L == 1#1)
  let release : Bool := (o0 == 1#1)
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_cas_pair acquire datasize n release s t tagchecked)

/-- Type quantifiers: datasize : Nat, k_iszero : Bool, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_branch_conditional_compare (datasize : Nat) (iszero : Bool) (offset : (BitVec 64)) (t : Nat) : SailM Unit := do
  let operand1 ← (( do (X_read t datasize) ) : SailM (BitVec datasize) )
  let branch_conditional : Bool := true
  (if (((IsZero operand1) == iszero) : Bool)
  then (do (BranchTo ((← (PC_read ())) + offset) BranchType_DIR branch_conditional))
  else (do (BranchNotTaken BranchType_DIR branch_conditional)))

def decode_cbnz_aarch64_instrs_branch_conditional_compare (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let iszero : Bool := (op == 0#1)
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_compare datasize iszero offset t)

def decode_cbz_aarch64_instrs_branch_conditional_compare (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let iszero : Bool := (op == 0#1)
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_conditional_compare datasize iszero offset t)

/-- Type quantifiers: datasize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_integer_conditional_compare_register (condition : (BitVec 4)) (datasize : Nat) (flags__arg : (BitVec 4)) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let flags : (BitVec 4) := flags__arg
  let taken : Bool := false
  let (flags, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
          let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
          let carry_in : (BitVec 1) := 0#1
          let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
            if (sub_op : Bool)
            then
              (let operand2 : (BitVec datasize) := (Complement.complement operand2)
              let carry_in : (BitVec 1) := 1#1
              (carry_in, operand2))
            else (carry_in, operand2)
          let flags : (BitVec 4) :=
            let (_, __tup_1) := (AddWithCarry operand1 operand2 carry_in)
            __tup_1
          let taken : Bool := true
          (pure (flags, taken)))
    else (do (pure (flags, taken)))) ) : SailM ((BitVec 4) × Bool) )
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb flags 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb flags 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb flags 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb flags 0 0) }
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_ccmn_reg_aarch64_instrs_integer_conditional_compare_register (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_integer_conditional_compare_register condition datasize flags m n sub_op)

def decode_ccmp_reg_aarch64_instrs_integer_conditional_compare_register (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  (execute_aarch64_instrs_integer_conditional_compare_register condition datasize flags m n sub_op)

/-- Type quantifiers: datasize : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_integer_conditional_compare_immediate (condition : (BitVec 4)) (datasize : Nat) (flags__arg : (BitVec 4)) (imm : (BitVec datasize)) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let flags : (BitVec 4) := flags__arg
  let taken : Bool := false
  let (flags, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
          let operand2 : (BitVec datasize) := imm
          let carry_in : (BitVec 1) := 0#1
          let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
            if (sub_op : Bool)
            then
              (let operand2 : (BitVec datasize) := (Complement.complement operand2)
              let carry_in : (BitVec 1) := 1#1
              (carry_in, operand2))
            else (carry_in, operand2)
          let flags : (BitVec 4) :=
            let (_, __tup_1) := (AddWithCarry operand1 operand2 carry_in)
            __tup_1
          let taken : Bool := true
          (pure (flags, taken)))
    else (do (pure (flags, taken)))) ) : SailM ((BitVec 4) × Bool) )
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb flags 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb flags 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb flags 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb flags 0 0) }
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_ccmn_imm_aarch64_instrs_integer_conditional_compare_immediate (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (imm5 : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  let imm : (BitVec datasize) := (Sail.BitVec.zeroExtend imm5 datasize)
  (execute_aarch64_instrs_integer_conditional_compare_immediate condition datasize flags imm n sub_op)

def decode_ccmp_imm_aarch64_instrs_integer_conditional_compare_immediate (nzcv : (BitVec 4)) (Rn : (BitVec 5)) (cond : (BitVec 4)) (imm5 : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let condition : (BitVec 4) := cond
  let flags : (BitVec 4) := nzcv
  let imm : (BitVec datasize) := (Sail.BitVec.zeroExtend imm5 datasize)
  (execute_aarch64_instrs_integer_conditional_compare_immediate condition datasize flags imm n sub_op)

def execute_aarch64_instrs_system_monitors (_ : Unit) : Unit :=
  (ClearExclusiveLocal (ProcessorID ()))

def decode_clrex_aarch64_instrs_system_monitors (CRm : (BitVec 4)) : Unit :=
  (execute_aarch64_instrs_system_monitors ())

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_cnt (d : Nat) (datasize : Nat) (n : Nat) (opcode : CountOp) : SailM Unit := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result : Int :=
    if ((BEq.beq opcode CountOp_CLZ) : Bool)
    then (CountLeadingZeroBits operand1)
    else (CountLeadingSignBits operand1)
  let result := result
  (X_set d datasize (integer_subrange result (datasize -i 1) 0))

def decode_cls_int_aarch64_instrs_integer_arithmetic_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let opcode : CountOp :=
    if ((op == 0#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_integer_arithmetic_cnt d datasize n opcode)

def decode_clz_int_aarch64_instrs_integer_arithmetic_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let opcode : CountOp :=
    if ((op == 0#1) : Bool)
    then CountOp_CLZ
    else CountOp_CLS
  (execute_aarch64_instrs_integer_arithmetic_cnt d datasize n opcode)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd (comparison : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, test_passed) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let test_passed : Bool :=
          match comparison with
          | .CompareOp_GT => (element >b 0)
          | .CompareOp_GE => (element ≥b 0)
          | .CompareOp_EQ => (element == 0)
          | .CompareOp_LE => (element ≤b 0)
          | .CompareOp_LT => (element <b 0)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element, result, test_passed))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmeq_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmge_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmgt_advsimd_zero_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

def decode_cmle_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison ← (( do (undefined_CompareOp ()) ) : SailM CompareOp )
  let comparison : CompareOp :=
    match (op +++ U) with
    | 0b00 => CompareOp_GT
    | 0b01 => CompareOp_GE
    | 0b10 => CompareOp_EQ
    | _ => CompareOp_LE
  let comparison := comparison
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_bulk_sisd comparison d datasize elements esize n)

/-- Type quantifiers: k_and_test : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (and_test : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, test_passed) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let test_passed : Bool :=
          if (and_test : Bool)
          then (! (IsZero (element1 &&& element2)))
          else (element1 == element2)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element1, element2, result, test_passed))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmeq_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmtst_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

def decode_cmtst_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let and_test : Bool := (U == 0#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_bitwise_sisd and_test d datasize elements esize m n)

/-- Type quantifiers: k_cmp_eq : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (cmp_eq : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, test_passed) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let test_passed : Bool :=
          if (cmp_eq : Bool)
          then (element1 ≥b element2)
          else (element1 >b element2)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element1, element2, result, test_passed))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmge_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmgt_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhi_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhi_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhs_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

def decode_cmhs_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (eq : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let cmp_eq : Bool := (eq == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_cmp_int_sisd cmp_eq d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd (comparison : CompareOp) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let test_passed ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, test_passed) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, test_passed)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, test_passed) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let test_passed : Bool :=
          match comparison with
          | .CompareOp_GT => (element >b 0)
          | .CompareOp_GE => (element ≥b 0)
          | .CompareOp_EQ => (element == 0)
          | .CompareOp_LE => (element ≤b 0)
          | .CompareOp_LT => (element <b 0)
        let result ←
          (Elem_set result e esize
            (if (test_passed : Bool)
            then (Ones (n := esize))
            else (Zeros (n := esize))))
        (pure (element, result, test_passed))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_cmlt_advsimd_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let comparison : CompareOp := CompareOp_LT
  (execute_aarch64_instrs_vector_arithmetic_unary_cmp_int_lessthan_sisd comparison d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_cnt (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let count ← (( do (undefined_int ()) ) : SailM Int )
  let (count, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (count, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (count, result) := loop_vars
      loop_vars ← do
        let count ← (( (pure (BitCount (← (Elem_read operand e esize)))) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange count (esize -i 1) 0))
        (pure (count, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_cnt_advsimd_aarch64_instrs_vector_arithmetic_unary_cnt (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size != 0b00#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_cnt d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, k_else_inc : Bool, k_else_inv : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_conditional_select (condition : (BitVec 4)) (d : Nat) (datasize : Nat) (else_inc : Bool) (else_inv : Bool) (m : Nat) (n : Nat) : SailM Unit := do
  let taken : Bool := false
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (result, taken) ← (( do
    (if ((← (ConditionHolds condition)) : Bool)
    then
      (do let result ← (X_read n datasize)
          let taken : Bool := true
          (pure (result, taken)))
    else
      (do let result ← (X_read m datasize)
          let result : (BitVec datasize) :=
            if (else_inv : Bool)
            then (Complement.complement result)
            else result
          let result : (BitVec datasize) :=
            if (else_inc : Bool)
            then (BitVec.addInt result 1)
            else result
          (pure (result, taken)))) ) : SailM ((BitVec datasize) × Bool) )
  (X_set d datasize result)
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let conditional : Bool := true
        (SPESampleAddOpOther conditional taken))
  else (do (pure ())))

def decode_csel_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csinc_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csinv_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def decode_csneg_aarch64_instrs_integer_conditional_select (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o2 : (BitVec 1)) (cond : (BitVec 4)) (Rm : (BitVec 5)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let condition : (BitVec 4) := cond
  let else_inv : Bool := (op == 1#1)
  let else_inc : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_integer_conditional_select condition d datasize else_inc else_inv m n)

def execute_aarch64_instrs_system_barriers_dmb (domain : MBReqDomain) (types : MBReqTypes) : SailM Unit := do
  (DataMemoryBarrier domain types)

def decode_dmb_aarch64_instrs_system_barriers_dmb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  let domain ← (( do (undefined_MBReqDomain ()) ) : SailM MBReqDomain )
  let types ← (( do (undefined_MBReqTypes ()) ) : SailM MBReqTypes )
  let domain : MBReqDomain :=
    match (Sail.BitVec.extractLsb CRm 3 2) with
    | 0b00 => MBReqDomain_OuterShareable
    | 0b01 => MBReqDomain_Nonshareable
    | 0b10 => MBReqDomain_InnerShareable
    | _ => MBReqDomain_FullSystem
  let (domain, types) : (MBReqDomain × MBReqTypes) :=
    match (Sail.BitVec.extractLsb CRm 1 0) with
    | 0b00 =>
      (let types : MBReqTypes := MBReqTypes_All
      let domain : MBReqDomain := MBReqDomain_FullSystem
      (domain, types))
    | 0b01 =>
      (let types : MBReqTypes := MBReqTypes_Reads
      (domain, types))
    | 0b10 =>
      (let types : MBReqTypes := MBReqTypes_Writes
      (domain, types))
    | _ =>
      (let types : MBReqTypes := MBReqTypes_All
      (domain, types))
  let types := types
  (execute_aarch64_instrs_system_barriers_dmb domain types)

/-- Type quantifiers: k_nXS : Bool -/
def execute_aarch64_instrs_system_barriers_dsb (alias' : DSBAlias) (domain : MBReqDomain) (nXS__arg : Bool) (types : MBReqTypes) : SailM Unit := do
  let nXS : Bool := nXS__arg
  match alias' with
  | .DSBAlias_SSBB => (pure (SpeculativeStoreBypassBarrierToVA ()))
  | .DSBAlias_PSSBB => (pure (SpeculativeStoreBypassBarrierToPA ()))
  | .DSBAlias_DSB =>
    (do
      (if ((←((HaveTME ()) <&&> (do
           (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
      then (do (FailTransaction TMFailure_ERR false))
      else (do (pure ())))
      let nXS ← (( do
        (if ((←((pure (! nXS)) <&&> (do
             (HaveFeatXS ())))) : Bool)
        then (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_FnXS (← readReg HCRX_EL2)) == 1#1))))
        else (do (pure nXS))) ) : SailM Bool )
      (DataSynchronizationBarrier domain types nXS))

def decode_dsb_aarch64_instrs_system_barriers_dsb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  let nXS : Bool := false
  let alias' ← (( do (undefined_DSBAlias ()) ) : SailM DSBAlias )
  let alias' : DSBAlias :=
    match CRm with
    | 0b0000 => DSBAlias_SSBB
    | 0b0100 => DSBAlias_PSSBB
    | _ => DSBAlias_DSB
  let alias' := alias'
  let domain ← (( do (undefined_MBReqDomain ()) ) : SailM MBReqDomain )
  let domain : MBReqDomain :=
    match (Sail.BitVec.extractLsb CRm 3 2) with
    | 0b00 => MBReqDomain_OuterShareable
    | 0b01 => MBReqDomain_Nonshareable
    | 0b10 => MBReqDomain_InnerShareable
    | _ => MBReqDomain_FullSystem
  let types ← (( do (undefined_MBReqTypes ()) ) : SailM MBReqTypes )
  let (domain, types) : (MBReqDomain × MBReqTypes) :=
    match (Sail.BitVec.extractLsb CRm 1 0) with
    | 0b00 =>
      (let types : MBReqTypes := MBReqTypes_All
      let domain : MBReqDomain := MBReqDomain_FullSystem
      (domain, types))
    | 0b01 =>
      (let types : MBReqTypes := MBReqTypes_Reads
      (domain, types))
    | 0b10 =>
      (let types : MBReqTypes := MBReqTypes_Writes
      (domain, types))
    | _ =>
      (let types : MBReqTypes := MBReqTypes_All
      (domain, types))
  (execute_aarch64_instrs_system_barriers_dsb alias' domain nXS types)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ List.elem datasize [8, 16, 32, 64, 128, 256] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (Elem_read operand index esize) ) : SailM (BitVec esize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize element)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10075.56-10075.57"
  (V_set d datasize result)

def decode_dup_advsimd_elt_aarch64_instrs_vector_transfer_vector_cpy_dup_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10112.37-10112.38"
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  (if (((size == 3) && (Q == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10121.58-10121.59"
  (execute_aarch64_instrs_vector_transfer_vector_cpy_dup_sisd d datasize elements esize idxdsize index n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_dup (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10140.48-10140.49"
  let element ← (( do (X_read n esize) ) : SailM (BitVec esize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize element)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_dup_advsimd_gen_aarch64_instrs_vector_transfer_integer_dup (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((size == 3) && (Q == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10164.58-10164.59"
  (execute_aarch64_instrs_vector_transfer_integer_dup d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, position : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_extract (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (position : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let hi ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let lo ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (datasize * 2)) := (hi +++ lo)
  sail_assert ((0 ≤b position) && (((position +i datasize) -i 1) <b (datasize *i 2))) "sail-arm/arm-v9.4-a/src/instrs64.sail:10283.83-10283.84"
  (V_set d datasize (Sail.BitVec.extractLsb concat ((position +i datasize) -i 1) position))

def decode_ext_advsimd_aarch64_instrs_vector_transfer_vector_extract (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm4 : (BitVec 4)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((Q == 0#1) && (((BitVec.access imm4 3) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let position := (Int.shiftl (BitVec.toNat imm4) 3)
  (execute_aarch64_instrs_vector_transfer_vector_extract d datasize m n position)

/-- Type quantifiers: d : Nat, datasize : Nat, lsb : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ lsb ∧ lsb ≤ 63 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_ins_ext_extract_immediate (d : Nat) (datasize : Nat) (lsb : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand1 +++ operand2)
  sail_assert (((lsb +i datasize) -i 1) <b (2 *i datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:10319.59-10319.60"
  let result : (BitVec datasize) := (Sail.BitVec.extractLsb concat ((lsb +i datasize) -i 1) lsb)
  (X_set d datasize result)

def decode_extr_aarch64_instrs_integer_ins_ext_extract_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  (if ((N != sf) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imms 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let lsb := (BitVec.toNat imms)
  (execute_aarch64_instrs_integer_ins_ext_extract_immediate d datasize lsb m n)

/-- Type quantifiers: d : Nat, fltsize : Nat, intsize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem intsize [32, 64] ∧ List.elem fltsize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_convert_int (d : Nat) (fltsize : Nat) (intsize : Nat) (n : Nat) (op : FPConvOp) (part : Nat) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (if ((BEq.beq op FPConvOp_CVT_FtoI_JS) : Bool)
  then (do (CheckFPAdvSIMDEnabled64 ()))
  else (do (CheckFPEnabled64 ())))
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let fsize :=
    if (((BEq.beq op FPConvOp_CVT_ItoF) && merge) : Bool)
    then 128
    else fltsize
  let fltval ← (( do (undefined_bitvector fsize) ) : SailM (BitVec fsize) )
  let intval ← (( do (undefined_bitvector intsize) ) : SailM (BitVec intsize) )
  match op with
  | .FPConvOp_CVT_FtoI =>
    (do
      let fltval ← (( do (V_read n fsize) ) : SailM (BitVec fsize) )
      sail_assert ((((fsize == 16) || (fsize == 32)) || (fsize == 64)) && (((intsize == 16) || (intsize == 32)) || (intsize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:13453.80-13453.81"
      let intval ← (( do (FPToFixed fltval 0 is_unsigned fpcr rounding intsize) ) : SailM (BitVec intsize) )
      (X_set d intsize intval))
  | .FPConvOp_CVT_ItoF =>
    (do
      let intval ← (( do (X_read n intsize) ) : SailM (BitVec intsize) )
      let fltval ← ((
        (if (merge : Bool)
        then (do (V_read d fsize))
        else (do (pure (Zeros (n := fsize))))) ) : SailM (BitVec fsize) )
      sail_assert ((((fltsize == 16) || (fltsize == 32)) || (fltsize == 64)) && (((intsize == 16) || (intsize == 32)) || (intsize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:13461.82-13461.83"
      let fltval ← (Elem_set fltval 0 fltsize (← (FixedToFP intval 0 is_unsigned fpcr rounding fltsize)))
      (V_set d fsize fltval))
  | .FPConvOp_MOV_FtoI =>
    (do
      let fltval ← (( do (Vpart_read n part fsize) ) : SailM (BitVec fsize) )
      sail_assert ((fsize ≥b 0) && (intsize ≥b fsize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13467.63-13467.64"
      let intval : (BitVec intsize) := (Sail.BitVec.zeroExtend fltval intsize)
      (X_set d intsize intval))
  | .FPConvOp_MOV_ItoF =>
    (do
      let intval ← (( do (X_read n intsize) ) : SailM (BitVec intsize) )
      sail_assert ((0 ≤b (fsize -i 1)) && ((fsize -i 1) <b intsize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13473.70-13473.71"
      let fltval : (BitVec fsize) := (Sail.BitVec.extractLsb intval (fsize -i 1) 0)
      (Vpart_set d part fsize fltval))
  | .FPConvOp_CVT_FtoI_JS =>
    (do
      let z ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
      let fltval ← (( do (V_read n fsize) ) : SailM (BitVec fsize) )
      sail_assert (fsize == 64) "sail-arm/arm-v9.4-a/src/instrs64.sail:13480.41-13480.42"
      sail_assert (intsize == 32) "sail-arm/arm-v9.4-a/src/instrs64.sail:13481.43-13481.44"
      let (intval, z) ← (( do
        let (tup__0, tup__1) ← do (FPToFixedJS fltval fpcr true intsize)
        let intval : (BitVec intsize) := tup__0
        let z : (BitVec 1) := tup__1
        (pure (intval, z)) ) : SailM ((BitVec intsize) × (BitVec 1)) )
      let split_vec := ((0#1 +++ z) +++ 0b00#2)
      writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
      writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
      writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
      writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) }
      (X_set d intsize intval))

def decode_fmov_float_gen_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14727.22-14727.23"

/-- Type quantifiers: datasize : Nat, rd : Nat, 0 ≤ rd ∧ rd ≤ 31 ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_vector_fp16_movi (datasize : Nat) (imm : (BitVec datasize)) (rd : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  (V_set rd datasize imm)

def decode_fmov_advsimd_aarch64_instrs_vector_fp16_movi (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (HaveFP16Ext ())) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let imm8 : (BitVec 8) := (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)
  let imm16 : (BitVec 16) := ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 2)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 6)))
  let imm : (BitVec datasize) := (BitVec.replicateBits imm16 (Int.ediv datasize 16))
  (execute_aarch64_instrs_vector_fp16_movi datasize imm rd)

def decode_fmov_advsimd_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_fp16_movi datasize imm rd)

/-- Type quantifiers: d : Nat, datasize : Nat, List.elem datasize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_move_fp_imm (d : Nat) (datasize : Nat) (imm : (BitVec datasize)) : SailM Unit := do
  (CheckFPEnabled64 ())
  (V_set d datasize imm)

def decode_fmov_float_imm_aarch64_instrs_float_move_fp_imm (Rd : (BitVec 5)) (imm8 : (BitVec 8)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize : Int := 16
  let datasize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let datasize := datasize
  let imm ← (( do (VFPExpandImm imm8 datasize) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_float_move_fp_imm d datasize imm)

/-- Type quantifiers: d : Nat, dst_index : Int, esize : Nat, idxdsize : Nat, n : Nat, src_index : Int, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_insert (d : Nat) (dst_index : Int) (esize : Nat) (idxdsize : Nat) (n : Nat) (src_index : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let result ← (Elem_set result dst_index esize (← (Elem_read operand src_index esize)))
  (V_set d 128 result)

def decode_ins_advsimd_elt_aarch64_instrs_vector_transfer_vector_insert (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm4 : (BitVec 4)) (imm5 : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:20676.37-20676.38"
  let dst_index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  sail_assert (0 ≤b size) "sail-arm/arm-v9.4-a/src/instrs64.sail:20678.33-20678.34"
  let src_index := (BitVec.toNat (Sail.BitVec.extractLsb imm4 3 size))
  let idxdsize :=
    if ((((BitVec.access imm4 3) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 size)
  match esize with
  | 8 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 8 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 8 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:20692.28-20692.29")
  | 16 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 16 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 16 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:20705.28-20705.29")
  | 32 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 32 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 32 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:20718.28-20718.29")
  | 64 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 64 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 64 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:20731.28-20731.29")
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:20762.22-20762.23"

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ datasize = 128 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_insert (d : Nat) (datasize : Nat) (esize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:20782.48-20782.49"
  let element ← (( do (X_read n esize) ) : SailM (BitVec esize) )
  let result ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (Elem_set result index esize element)
  (V_set d datasize result)

def decode_ins_advsimd_gen_aarch64_instrs_vector_transfer_integer_insert (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:20798.37-20798.38"
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let esize := (_shl_int_general 8 size)
  let datasize := 128
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:20802.58-20802.59"
  (execute_aarch64_instrs_vector_transfer_integer_insert d datasize esize index n)

def execute_aarch64_instrs_system_barriers_isb (_ : Unit) : SailM Unit := do
  (InstructionSynchronizationBarrier ())
  (if ((←((HaveBRBExt ()) <&&> (do
       (BRBEBranchOnISB ())))) : Bool)
  then (do (BRBEISB ()))
  else (do (pure ())))
  (if ((← (HaveStatisticalProfiling ())) : Bool)
  then (do (SPEISB ()))
  else (do (pure ())))

def decode_isb_aarch64_instrs_system_barriers_isb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  (execute_aarch64_instrs_system_barriers_isb ())

/-- Type quantifiers: datasize : Nat, esize : Nat, index : Int, m : Int, n : Nat, k_nontemporal : Bool, k_replicate : Bool, selem : Nat, t__arg : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t__arg ∧ t__arg ≤ 31 ∧ List.elem selem [1, 2, 3, 4] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_memory_vector_single_no_wb (datasize : Nat) (esize : Nat) (index : Int) (m : Int) (memop : MemOp) (n : Nat) (nontemporal : Bool) (replicate : Bool) (selem : Nat) (t__arg : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let t : Int := t__arg
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rval ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let ebytes := (Int.ediv esize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let offs : (BitVec 64) := (Zeros (n := 64))
  let offs ← (( do
    (if (replicate : Bool)
    then
      (do let (element, offs, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars_1 := (element, offs, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (element, offs, t) := loop_vars_1
              loop_vars_1 ← do
                let element ← (Mem_read (address + offs) ebytes accdesc)
                (V_set t datasize (BitVec.replicateBits element (Int.ediv datasize esize)))
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (element, offs, t))
            (pure loop_vars_1) ) : SailM ((BitVec esize) × (BitVec 64) × Int) )
          (pure offs))
    else
      (do let (offs, rval, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars := (offs, rval, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (offs, rval, t) := loop_vars
              loop_vars ← do
                let rval ← (V_read t 128)
                let rval ← (( do
                  (if ((BEq.beq memop MemOp_LOAD) : Bool)
                  then
                    (do let rval ← (Elem_set rval index esize (← (Mem_read (address + offs) ebytes accdesc)))
                        (V_set t 128 rval)
                        (pure rval))
                  else
                    (do (Mem_set (address + offs) ebytes accdesc (← (Elem_read rval index esize)))
                        (pure rval))) ) : SailM (BitVec 128) )
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (offs, rval, t))
            (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 128) × Int) )
          (pure offs))) ) : SailM (BitVec 64) )
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))
  (if (wback : Bool)
  then
    (do let offs ← (( do
          (if ((m != 31) : Bool)
          then (do (X_read m 64))
          else (do (pure offs))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set (address + offs)))
        else (do (X_set n 64 (address + offs)))))
  else (do (pure ())))

def decode_ld1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:20997.48-20997.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21067.48-21067.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21137.48-21137.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21207.48-21207.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21277.48-21277.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21347.48-21347.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21417.48-21417.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21487.48-21487.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21557.48-21557.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21627.48-21627.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21697.48-21697.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21767.48-21767.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21837.48-21837.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21907.48-21907.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21977.48-21977.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22047.48-22047.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22117.48-22117.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st1_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22187.48-22187.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)


end ArmASL.Functions
