import ArmASL.Part43

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32899.113-32899.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32918.107-32918.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32985.113-32985.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33004.107-33004.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, m : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, shift : Nat, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem shift [0, 1, 2, 3] ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_register (datasize : Nat) (extend_type : ExtendType) (m : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (shift : Nat) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let offset ← (( do (ExtendReg m extend_type shift 64) ) : SailM (BitVec 64) )
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:33073.72-33073.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:33076.73-33076.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_reg_gen_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33148.113-33148.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33167.107-33167.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33245.113-33245.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33264.107-33264.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33342.113-33342.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33361.107-33361.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33439.113-33439.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33458.107-33458.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33536.113-33536.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33555.107-33555.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33633.113-33633.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33652.107-33652.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_prfm_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  sail_assert (! (let b__0 := Rt
    if (((Sail.BitVec.extractLsb b__0 4 3) == (0b11#2 : (BitVec 2))) : Bool)
    then true
    else false : Bool)) "sail-arm/arm-v9.4-a/src/instrs64.sail:33690.14-33690.15"
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33734.113-33734.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33753.107-33753.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_str_reg_gen_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33834.113-33834.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33853.107-33853.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_strb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33931.113-33931.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33950.107-33950.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_strh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34028.113-34028.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34047.107-34047.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, m : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, shift : Nat, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem shift [0, 1, 2, 3, 4, 5, 6, 7] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_register (datasize : Nat) (extend_type : ExtendType) (m : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (postindex : Bool) (shift : Nat) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let offset ← (( do (ExtendReg m extend_type shift 64) ) : SailM (BitVec 64) )
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34100.62-34100.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34106.62-34106.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_reg_fpsimd_aarch64_instrs_memory_single_simdfp_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34148.72-34148.73"
  (execute_aarch64_instrs_memory_single_simdfp_register datasize extend_type m memop n nontemporal postindex shift t tagchecked wback)

def decode_str_reg_fpsimd_aarch64_instrs_memory_single_simdfp_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34185.72-34185.73"
  (execute_aarch64_instrs_memory_single_simdfp_register datasize extend_type m memop n nontemporal postindex shift t tagchecked wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35172.62-35172.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35178.62-35178.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35215.72-35215.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_stur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35245.72-35245.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal datasize memop n nontemporal offset postindex t tagchecked wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35297.72-35297.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35300.73-35300.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldur_gen_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35367.113-35367.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35386.107-35386.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldurb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35457.113-35457.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35476.107-35476.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldurh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35547.113-35547.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35566.107-35566.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldursb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35637.113-35637.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35656.107-35656.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldursh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35727.113-35727.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35746.107-35746.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldursw_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35817.113-35817.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35836.107-35836.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_prfum_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35907.113-35907.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35926.107-35926.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_stur_gen_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35997.113-35997.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36016.107-36016.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_sturb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36087.113-36087.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36106.107-36106.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_sturh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36177.113-36177.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36196.107-36196.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: a : Nat, d : Nat, datasize : Nat, destsize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem destsize [32, 64] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (a : Nat) (d : Nat) (datasize : Nat) (destsize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (X_read a destsize) ) : SailM (BitVec destsize) )
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result : Int :=
    if (sub_op : Bool)
    then ((BitVec.toNat operand3) -i ((BitVec.toNat operand1) *i (BitVec.toNat operand2)))
    else ((BitVec.toNat operand3) +i ((BitVec.toNat operand1) *i (BitVec.toNat operand2)))
  let result := result
  (X_set d destsize (integer_subrange result (destsize -i 1) 0))

def decode_madd_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let datasize := destsize
  let sub_op : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub a d datasize destsize m n sub_op)

def decode_msub_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let datasize := destsize
  let sub_op : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub a d datasize destsize m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, pos : Nat, 0 ≤ pos ∧ pos ≤ 63 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_ins_ext_insert_movewide (d : Nat) (datasize : Nat) (imm : (BitVec 16)) (opcode : MoveWideOp) (pos : Nat) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    (if ((BEq.beq opcode MoveWideOp_K) : Bool)
    then (do (X_read d datasize))
    else (do (pure (Zeros (n := datasize))))) ) : SailM (BitVec datasize) )
  sail_assert ((pos +i 15) <b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:36468.44-36468.45"
  let result : (BitVec datasize) := (Sail.BitVec.updateSubrange result (pos +i 15) pos imm)
  let result : (BitVec datasize) :=
    if ((BEq.beq opcode MoveWideOp_N) : Bool)
    then (Complement.complement result)
    else result
  let result := result
  (X_set d datasize result)

def decode_movk_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

def decode_movn_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

def decode_movz_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

/-- Type quantifiers: k_read : Bool, sys_crm : Nat, sys_crn : Nat, sys_op0 : Nat, sys_op1 : Nat, sys_op2 : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem sys_op2 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op1 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op0 [2, 3] ∧ 0 ≤ sys_crn ∧ sys_crn ≤ 15 ∧ 0 ≤ sys_crm ∧ sys_crm ≤ 15 -/
def execute_aarch64_instrs_system_register_system (read : Bool) (sys_crm : Nat) (sys_crn : Nat) (sys_op0 : Nat) (sys_op1 : Nat) (sys_op2 : Nat) (t : Nat) : SailM Unit := do
  (if (read : Bool)
  then (do (AArch64_SysRegRead sys_op0 sys_op1 sys_crn sys_crm sys_op2 t))
  else (do (AArch64_SysRegWrite sys_op0 sys_op1 sys_crn sys_crm sys_op2 t)))

def decode_mrs_aarch64_instrs_system_register_system (Rt : (BitVec 5)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (CRn : (BitVec 4)) (op1 : (BitVec 3)) (o0 : (BitVec 1)) (L : (BitVec 1)) : SailM Unit := do
  (AArch64_CheckSystemAccess (1#1 +++ o0) op1 CRn CRm op2 Rt L)
  let t := (BitVec.toNat Rt)
  let sys_op0 := (2 +i (BitVec.toNat o0))
  let sys_op1 := (BitVec.toNat op1)
  let sys_op2 := (BitVec.toNat op2)
  let sys_crn := (BitVec.toNat CRn)
  let sys_crm := (BitVec.toNat CRm)
  let read : Bool := (L == 1#1)
  (execute_aarch64_instrs_system_register_system read sys_crm sys_crn sys_op0 sys_op1 sys_op2 t)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_not (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (Complement.complement element))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_not_advsimd_aarch64_instrs_vector_arithmetic_unary_not (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_not d datasize elements esize n)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_unsigned (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:37489.72-37489.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:37492.73-37492.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_prfm_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37559.113-37559.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37578.107-37578.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_unsigned datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_rbit (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let rev ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result, rev) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, rev)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, rev) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let rev ← (( do
          let loop_i_lower := 0
          let loop_i_upper := (esize -i 1)
          let mut loop_vars_1 := rev
          for i in [loop_i_lower:loop_i_upper:1]i do
            let rev := loop_vars_1
            loop_vars_1 := (BitVec.update rev ((esize -i 1) -i i) (Bit ((BitVec.access element i) : BitVec 1)))
          (pure loop_vars_1) ) : SailM (BitVec esize) )
        let result ← (Elem_set result e esize rev)
        (pure (element, result, rev))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize) × (BitVec esize)) )
  (V_set d datasize result)

def decode_rbit_advsimd_aarch64_instrs_vector_arithmetic_unary_rbit (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_rbit d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_rbit (d : Nat) (datasize : Nat) (n : Nat) : SailM Unit := do
  let operand ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (datasize -i 1)
    let mut loop_vars := result
    for i in [loop_i_lower:loop_i_upper:1]i do
      let result := loop_vars
      loop_vars := (BitVec.update result ((datasize -i 1) -i i) (Bit ((BitVec.access operand i) : BitVec 1)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (X_set d datasize result)

def decode_rbit_int_aarch64_instrs_integer_arithmetic_rbit (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  (execute_aarch64_instrs_integer_arithmetic_rbit d datasize n)

/-- Type quantifiers: container_size : Nat, d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 ∧ List.elem container_size [16, 32, 64] -/
def execute_aarch64_instrs_integer_arithmetic_rev (container_size : Nat) (d : Nat) (datasize : Nat) (n : Nat) : SailM Unit := do
  let operand ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size 8)
  let index : Int := 0
  let rev_index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, result, rev_index) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := (containers -i 1)
    let mut loop_vars := (index, result, rev_index)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (index, result, rev_index) := loop_vars
      loop_vars ← do
        let rev_index : Int := (index +i ((elements_per_container -i 1) *i 8))
        let (index, result, rev_index) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements_per_container -i 1)
          let mut loop_vars_1 := (index, result, rev_index)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (index, result, rev_index) := loop_vars_1
            loop_vars_1 ← do
              let result ← (( do
                let rev_index := rev_index
                let index := index
                sail_assert ((0 ≤b rev_index) && ((rev_index +i 7) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:38612.83-38612.84"
                sail_assert ((0 ≤b index) && ((index +i 7) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:38613.75-38613.76"
                (pure (Sail.BitVec.updateSubrange result (rev_index +i 7) rev_index (Sail.BitVec.extractLsb operand (index +i 7) index))) ) : SailM (BitVec datasize) )
              let index : Int := (index +i 8)
              let rev_index : Int := (rev_index -i 8)
              (pure (index, result, rev_index))
          (pure loop_vars_1) ) : SailM (Int × (BitVec datasize) × Int) )
        (pure (index, result, rev_index))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Int) )
  (X_set d datasize result)

def decode_rev_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

def decode_rev16_int_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

def decode_rev32_int_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

/-- Type quantifiers: containers : Int, d : Nat, datasize : Nat, elements_per_container : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_rev (containers : Int) (d : Nat) (datasize : Nat) (elements_per_container : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element : Int := 0
  let rev_element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result, rev_element) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := (containers -i 1)
    let mut loop_vars := (element, result, rev_element)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (element, result, rev_element) := loop_vars
      loop_vars ← do
        let rev_element : Int := ((element +i elements_per_container) -i 1)
        let (element, result, rev_element) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements_per_container -i 1)
          let mut loop_vars_1 := (element, result, rev_element)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (element, result, rev_element) := loop_vars_1
            loop_vars_1 ← do
              let result ← (( do
                let rev_element := rev_element
                let element := element
                (Elem_set result rev_element esize (← (Elem_read operand element esize))) ) : SailM (BitVec datasize) )
              let element : Int := (element +i 1)
              let rev_element : Int := (rev_element -i 1)
              (pure (element, result, rev_element))
          (pure loop_vars_1) ) : SailM (Int × (BitVec datasize) × Int) )
        (pure (element, result, rev_element))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Int) )
  (V_set d datasize result)

def decode_rev16_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

def decode_rev32_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

def decode_rev64_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

/-- Type quantifiers: m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 -/
def execute_aarch64_instrs_memory_single_general_range (m : Nat) (n : Nat) (operation : (BitVec 6)) : SailM Unit := do
  let address ← (( do
    (if ((n == 31) : Bool)
    then (do (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let metadata ← (( do (X_read m 64) ) : SailM (BitVec 64) )
  let stride := (BitVec.toInt (Sail.BitVec.extractLsb metadata 59 38))
  let count := ((BitVec.toNat (Sail.BitVec.extractLsb metadata 37 22)) +i 1)
  let length := (BitVec.toInt (Sail.BitVec.extractLsb metadata 21 0))
  let reuse ← (( do (undefined_int ()) ) : SailM Int )
  let reuse : Int :=
    if (((Sail.BitVec.extractLsb metadata 63 60) == 0b0000#4) : Bool)
    then (Neg.neg 1)
    else (Int.shiftl 32768 (15 -i (BitVec.toNat (Sail.BitVec.extractLsb metadata 63 60))))
  let reuse := reuse
  (pure (Hint_RangePrefetch address length stride count reuse operation))

def decode_rprfm_reg_aarch64_instrs_memory_single_general_range (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let operation : (BitVec 6) := (((((BitVec.access option_name 2) : BitVec 1) +++ ((BitVec.access option_name 0) : BitVec 1)) +++ S) +++ (Sail.BitVec.extractLsb Rt 2 0))
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_memory_single_general_range m n operation)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_logical (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (BitVec.toNat (← (Elem_read operand e (2 *i esize)))) shift round) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange element (esize -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (Vpart_set d part datasize result)

def decode_rshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_logical (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:38994.51-38994.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_logical d datasize elements esize n part round shift)


end ArmASL.Functions
