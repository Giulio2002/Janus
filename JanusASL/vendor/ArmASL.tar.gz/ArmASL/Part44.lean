import ArmASL.Part43

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_ldpsw_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30152.113-30152.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30171.107-30171.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30190.84-30190.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30204.44-30204.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30241.113-30241.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30260.107-30260.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30279.84-30279.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30293.44-30293.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30330.113-30330.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30349.107-30349.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30368.84-30368.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30382.44-30382.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30419.113-30419.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30438.107-30438.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30457.84-30457.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30471.44-30471.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30506.62-30506.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30512.62-30512.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30549.72-30549.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30579.72-30579.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30609.72-30609.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30639.72-30639.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30669.72-30669.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30699.72-30699.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

/-- Type quantifiers: k_is_signed : Bool, k_nontemporal : Bool, size : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem size [4, 8] -/
def execute_aarch64_instrs_memory_literal_general (memop : MemOp) (nontemporal : Bool) (offset : (BitVec 64)) (is_signed : Bool) (size : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (pure ((← (PC_read ())) + offset)) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  match memop with
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address size accdesc) ) : SailM (BitVec (size * 8)) )
      (if (is_signed : Bool)
      then (do (X_set t 64 (sign_extend data 64)))
      else (do (X_set t (size *i 8) data))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_lit_gen_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

def decode_ldrsw_lit_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

def decode_prfm_lit_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

/-- Type quantifiers: k_nontemporal : Bool, size : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem size [4, 8, 16] -/
def execute_aarch64_instrs_memory_literal_simdfp (nontemporal : Bool) (offset : (BitVec 64)) (size : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (pure ((← (PC_read ())) + offset)) ) : SailM (BitVec 64) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  (CheckFPEnabled64 ())
  let accdesc ← (( do (CreateAccDescASIMD MemOp_LOAD nontemporal tagchecked) ) : SailM AccessDescriptor )
  let data ← (( do (Mem_read address size accdesc) ) : SailM (BitVec (size * 8)) )
  (V_set t (size *i 8) data)
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_lit_fpsimd_aarch64_instrs_memory_literal_simdfp (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let size : Int := 4
  let size ← (( do
    match opc with
    | 0b00 => (pure 4)
    | 0b01 => (pure 8)
    | 0b10 => (pure 16)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM Int )
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_simdfp nontemporal offset size t tagchecked)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30942.72-30942.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30945.73-30945.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31008.113-31008.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31027.107-31027.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31094.113-31094.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31113.107-31113.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31180.113-31180.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31199.107-31199.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31266.113-31266.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31285.107-31285.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31352.113-31352.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31371.107-31371.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31438.113-31438.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31457.107-31457.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31524.113-31524.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31543.107-31543.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31610.113-31610.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31629.107-31629.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31696.113-31696.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31715.107-31715.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31782.113-31782.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31801.107-31801.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31868.113-31868.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31887.107-31887.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31954.113-31954.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31973.107-31973.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32040.113-32040.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32059.107-32059.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32126.113-32126.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32145.107-32145.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32212.113-32212.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32231.107-32231.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32298.113-32298.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32317.107-32317.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32384.113-32384.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32403.107-32403.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32470.113-32470.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32489.107-32489.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32556.113-32556.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32575.107-32575.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32642.113-32642.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32661.107-32661.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32728.113-32728.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32747.107-32747.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32814.113-32814.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32833.107-32833.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32900.113-32900.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32919.107-32919.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32986.113-32986.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33005.107-33005.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33072.113-33072.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33091.107-33091.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33158.113-33158.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33177.107-33177.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33244.113-33244.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33263.107-33263.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)


end ArmASL.Functions
