import ArmASL.Part20

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_adds_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

def decode_sub_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

def decode_subs_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, k_setflags : Bool, shift : Nat, k_sub_op : Bool, List.elem shift [0, 1, 2, 3, 4, 5, 6, 7] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (d : Nat) (datasize : Nat) (extend_type : ExtendType) (m : Nat) (n : Nat) (setflags : Bool) (shift : Nat) (sub_op : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do
    (if ((n == 31) : Bool)
    then (do (pure (Sail.BitVec.extractLsb (← (SP_read ())) (datasize -i 1) 0)))
    else (do (X_read n datasize))) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (ExtendReg m extend_type shift datasize) ) : SailM (BitVec datasize) )
  let nzcv ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let carry_in ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
    if (sub_op : Bool)
    then
      (let operand2 : (BitVec datasize) := (Complement.complement operand2)
      let carry_in : (BitVec 1) := 1#1
      (carry_in, operand2))
    else
      (let carry_in : (BitVec 1) := 0#1
      (carry_in, operand2))
  let (nzcv, result) : ((BitVec 4) × (BitVec datasize)) :=
    let (tup__0, tup__1) := ((AddWithCarry operand1 operand2 carry_in) : ((BitVec datasize) × (BitVec 4)))
    let result : (BitVec datasize) := tup__0
    let nzcv : (BitVec 4) := tup__1
    (nzcv, result)
  (if (setflags : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb nzcv 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb nzcv 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb nzcv 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb nzcv 0 0) })
  else (do (pure ())))
  (if (((d == 31) && (! setflags)) : Bool)
  then (do (SP_set (Sail.BitVec.zeroExtend result 64)))
  else (do (X_set d datasize result)))

def decode_add_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_adds_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_sub_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_subs_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, k_round : Bool, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (round : Bool) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let operand2 ← (( do (V_read m (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toNat (← (Elem_read operand1 e (2 *i esize))))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toNat (← (Elem_read operand2 e (2 *i esize))))) ) : SailM Int )
        let sum : Int :=
          if (sub_op : Bool)
          then (element1 -i element2)
          else (element1 +i element2)
        let sum ← (( (RShr sum esize round) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange sum (esize -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Int) )
  (Vpart_set d part datasize result)

def decode_addhn_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let round : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow d datasize elements esize m n part round sub_op)

def decode_raddhn_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let round : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow d datasize elements esize m n part round sub_op)

def decode_rsubhn_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let round : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow d datasize elements esize m n part round sub_op)

def decode_subhn_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let round : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_narrow d datasize elements esize m n part round sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_pair (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand2 +++ operand1)
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read concat (2 *i e) esize)
        let element2 ← (Elem_read concat ((2 *i e) +i 1) esize)
        let result ← (Elem_set result e esize (element1 + element2))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_addp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_pair (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_pair d datasize elements esize m n)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_add_simd (d : Nat) (datasize : Nat) (esize : Nat) (n : Nat) (op : ReduceOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  (V_set d esize (← (Reduce op operand esize)))

def decode_addv_advsimd_aarch64_instrs_vector_reduce_add_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let op : ReduceOp := ReduceOp_ADD
  (execute_aarch64_instrs_vector_reduce_add_simd d datasize esize n op)

/-- Type quantifiers: d : Nat, k_page : Bool, 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_address_pc_rel (d : Nat) (imm : (BitVec 64)) (page : Bool) : SailM Unit := do
  let base ← (( do (PC_read ()) ) : SailM (BitVec 64) )
  let base : (BitVec 64) :=
    if (page : Bool)
    then (Sail.BitVec.updateSubrange base 11 0 (Zeros (n := 12)))
    else base
  (X_set d 64 (base + imm))

def decode_adr_aarch64_instrs_integer_arithmetic_address_pc_rel (Rd : (BitVec 5)) (immhi : (BitVec 19)) (immlo : (BitVec 2)) (op : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let page : Bool := (op == 1#1)
  let imm ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let imm : (BitVec 64) :=
    if (page : Bool)
    then (sign_extend ((immhi +++ immlo) +++ (Zeros (n := 12))) 64)
    else (sign_extend (immhi +++ immlo) 64)
  (execute_aarch64_instrs_integer_arithmetic_address_pc_rel d imm page)

def decode_adrp_aarch64_instrs_integer_arithmetic_address_pc_rel (Rd : (BitVec 5)) (immhi : (BitVec 19)) (immlo : (BitVec 2)) (op : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let page : Bool := (op == 1#1)
  let imm ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let imm : (BitVec 64) :=
    if (page : Bool)
    then (sign_extend ((immhi +++ immlo) +++ (Zeros (n := 12))) 64)
    else (sign_extend (immhi +++ immlo) 64)
  (execute_aarch64_instrs_integer_arithmetic_address_pc_rel d imm page)

/-- Type quantifiers: d : Nat, k_decrypt : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_aes_round (d : Nat) (decrypt : Bool) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand1 ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let operand2 ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let result : (BitVec 128) := (operand1 ^^^ operand2)
  let result ← (( do
    (if (decrypt : Bool)
    then (do (AESInvSubBytes (AESInvShiftRows result)))
    else (do (AESSubBytes (AESShiftRows result)))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_aesd_advsimd_aarch64_instrs_vector_crypto_aes_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (D : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveAESExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let decrypt : Bool := (D == 1#1)
  (execute_aarch64_instrs_vector_crypto_aes_round d decrypt n)

def decode_aese_advsimd_aarch64_instrs_vector_crypto_aes_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (D : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveAESExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let decrypt : Bool := (D == 1#1)
  (execute_aarch64_instrs_vector_crypto_aes_round d decrypt n)

/-- Type quantifiers: d : Nat, k_decrypt : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_aes_mix (d : Nat) (decrypt : Bool) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let result ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let result ← (( do
    (if (decrypt : Bool)
    then (do (AESInvMixColumns operand))
    else (do (AESMixColumns operand))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_aesimc_advsimd_aarch64_instrs_vector_crypto_aes_mix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (D : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveAESExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let decrypt : Bool := (D == 1#1)
  (execute_aarch64_instrs_vector_crypto_aes_mix d decrypt n)

def decode_aesmc_advsimd_aarch64_instrs_vector_crypto_aes_mix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (D : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveAESExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let decrypt : Bool := (D == 1#1)
  (execute_aarch64_instrs_vector_crypto_aes_mix d decrypt n)

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, k_setflags : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_logical_immediate (d : Nat) (datasize : Nat) (imm : (BitVec datasize)) (n : Nat) (op : LogicalOp) (setflags : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 : (BitVec datasize) := imm
  let result : (BitVec datasize) :=
    match op with
    | .LogicalOp_AND => (operand1 &&& operand2)
    | .LogicalOp_ORR => (operand1 ||| operand2)
    | .LogicalOp_EOR => (operand1 ^^^ operand2)
  let result := result
  (if (setflags : Bool)
  then
    (do let split_vec := ((((BitVec.access result (datasize -i 1)) : BitVec 1) +++ (IsZeroBit result)) +++ 0b00#2)
        writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
  else (do (pure ())))
  (if (((d == 31) && (! setflags)) : Bool)
  then (do (SP_set (Sail.BitVec.zeroExtend result 64)))
  else (do (X_set d datasize result)))

def decode_and_log_imm_aarch64_instrs_integer_logical_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  (if (((sf == 0#1) && (N != 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let imm ← (( do
    let (__tup_0, _) ← do (DecodeBitMasks N imms immr true datasize)
    (pure __tup_0) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_integer_logical_immediate d datasize imm n op setflags)

def decode_ands_log_imm_aarch64_instrs_integer_logical_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  (if (((sf == 0#1) && (N != 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let imm ← (( do
    let (__tup_0, _) ← do (DecodeBitMasks N imms immr true datasize)
    (pure __tup_0) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_integer_logical_immediate d datasize imm n op setflags)

def decode_eor_log_imm_aarch64_instrs_integer_logical_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  (if (((sf == 0#1) && (N != 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let imm ← (( do
    let (__tup_0, _) ← do (DecodeBitMasks N imms immr true datasize)
    (pure __tup_0) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_integer_logical_immediate d datasize imm n op setflags)

def decode_orr_log_imm_aarch64_instrs_integer_logical_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  (if (((sf == 0#1) && (N != 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let imm ← (( do
    let (__tup_0, _) ← do (DecodeBitMasks N imms immr true datasize)
    (pure __tup_0) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_integer_logical_immediate d datasize imm n op setflags)

/-- Type quantifiers: d : Nat, datasize : Nat, k_invert : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr (d : Nat) (datasize : Nat) (invert : Bool) (m : Nat) (n : Nat) (op : LogicalOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand2 : (BitVec datasize) :=
    if (invert : Bool)
    then (Complement.complement operand2)
    else operand2
  let result : (BitVec datasize) :=
    match op with
    | .LogicalOp_AND => (operand1 &&& operand2)
    | .LogicalOp_ORR => (operand1 ||| operand2)
    | _ => result
  (V_set d datasize result)

def decode_and_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let invert : Bool := (((BitVec.access size 0) : BitVec 1) == 1#1)
  let op : LogicalOp :=
    if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
    then LogicalOp_ORR
    else LogicalOp_AND
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr d datasize invert m n op)

def decode_bic_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let invert : Bool := (((BitVec.access size 0) : BitVec 1) == 1#1)
  let op : LogicalOp :=
    if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
    then LogicalOp_ORR
    else LogicalOp_AND
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr d datasize invert m n op)

def decode_orn_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let invert : Bool := (((BitVec.access size 0) : BitVec 1) == 1#1)
  let op : LogicalOp :=
    if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
    then LogicalOp_ORR
    else LogicalOp_AND
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr d datasize invert m n op)

def decode_orr_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let invert : Bool := (((BitVec.access size 0) : BitVec 1) == 1#1)
  let op : LogicalOp :=
    if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
    then LogicalOp_ORR
    else LogicalOp_AND
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_and_orr d datasize invert m n op)

/-- Type quantifiers: d : Nat, datasize : Nat, k_invert : Bool, m : Nat, n : Nat, k_setflags : Bool, shift_amount : Nat, 0 ≤ shift_amount ∧ shift_amount ≤ 63 ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_logical_shiftedreg (d : Nat) (datasize : Nat) (invert : Bool) (m : Nat) (n : Nat) (op : LogicalOp) (setflags : Bool) (shift_amount : Nat) (shift_type : ShiftType) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (ShiftReg m shift_type shift_amount datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand2 : (BitVec datasize) :=
    if (invert : Bool)
    then (Complement.complement operand2)
    else operand2
  let result : (BitVec datasize) :=
    match op with
    | .LogicalOp_AND => (operand1 &&& operand2)
    | .LogicalOp_ORR => (operand1 ||| operand2)
    | .LogicalOp_EOR => (operand1 ^^^ operand2)
  let result := result
  (if (setflags : Bool)
  then
    (do let split_vec := ((((BitVec.access result (datasize -i 1)) : BitVec 1) +++ (IsZeroBit result)) +++ 0b00#2)
        writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
  else (do (pure ())))
  (X_set d datasize result)

def decode_and_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_ands_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_bic_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_bics_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_eon_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_eor_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_orn_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

def decode_orr_log_shift_aarch64_instrs_integer_logical_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (N : (BitVec 1)) (shift : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let setflags ← (( do (undefined_bool ()) ) : SailM Bool )
  let op ← (( do (undefined_LogicalOp ()) ) : SailM LogicalOp )
  let (op, setflags) : (LogicalOp × Bool) :=
    match opc with
    | 0b00 =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := false
      (op, setflags))
    | 0b01 =>
      (let op : LogicalOp := LogicalOp_ORR
      let setflags : Bool := false
      (op, setflags))
    | 0b10 =>
      (let op : LogicalOp := LogicalOp_EOR
      let setflags : Bool := false
      (op, setflags))
    | _ =>
      (let op : LogicalOp := LogicalOp_AND
      let setflags : Bool := true
      (op, setflags))
  let op := op
  let setflags := setflags
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  let invert : Bool := (N == 1#1)
  (execute_aarch64_instrs_integer_logical_shiftedreg d datasize invert m n op setflags shift_amount shift_type)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_shift_variable (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (shift_type : ShiftType) : SailM Unit := do
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (ShiftReg n shift_type (Nat.mod (BitVec.toNat operand2) datasize) datasize) ) : SailM (BitVec datasize) )
  (X_set d datasize result)

def decode_asrv_aarch64_instrs_integer_shift_variable (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op2 : (BitVec 2)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let shift_type ← (( do (DecodeShift op2) ) : SailM ShiftType )
  (execute_aarch64_instrs_integer_shift_variable d datasize m n shift_type)

def decode_lslv_aarch64_instrs_integer_shift_variable (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op2 : (BitVec 2)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let shift_type ← (( do (DecodeShift op2) ) : SailM ShiftType )
  (execute_aarch64_instrs_integer_shift_variable d datasize m n shift_type)

def decode_lsrv_aarch64_instrs_integer_shift_variable (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op2 : (BitVec 2)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let shift_type ← (( do (DecodeShift op2) ) : SailM ShiftType )
  (execute_aarch64_instrs_integer_shift_variable d datasize m n shift_type)

def decode_rorv_aarch64_instrs_integer_shift_variable (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op2 : (BitVec 2)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let shift_type ← (( do (DecodeShift op2) ) : SailM ShiftType )
  (execute_aarch64_instrs_integer_shift_variable d datasize m n shift_type)

def execute_aarch64_instrs_branch_unconditional_immediate (branch_type : BranchType) (offset : (BitVec 64)) : SailM Unit := do
  (if ((BEq.beq branch_type BranchType_DIRCALL) : Bool)
  then
    (do (if ((←((HaveGCS ()) <&&> (do
             (GCSPCREnabled (← readReg PSTATE).EL)))) : Bool)
        then (do (AddGCSRecord (BitVec.addInt (← (PC_read ())) 4)))
        else (do (pure ())))
        (X_set 30 64 (BitVec.addInt (← (PC_read ())) 4)))
  else (do (pure ())))
  let branch_conditional : Bool := false
  (BranchTo ((← (PC_read ())) + offset) branch_type branch_conditional)

def decode_b_uncond_aarch64_instrs_branch_unconditional_immediate (imm26 : (BitVec 26)) (op : (BitVec 1)) : SailM Unit := do
  let branch_type : BranchType :=
    if ((op == 1#1) : Bool)
    then BranchType_DIRCALL
    else BranchType_DIR
  let offset : (BitVec 64) := (sign_extend (imm26 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_unconditional_immediate branch_type offset)

def decode_bl_aarch64_instrs_branch_unconditional_immediate (imm26 : (BitVec 26)) (op : (BitVec 1)) : SailM Unit := do
  let branch_type : BranchType :=
    if ((op == 1#1) : Bool)
    then BranchType_DIRCALL
    else BranchType_DIR
  let offset : (BitVec 64) := (sign_extend (imm26 +++ 0b00#2) 64)
  (execute_aarch64_instrs_branch_unconditional_immediate branch_type offset)

def execute_aarch64_instrs_branch_conditional_cond (condition : (BitVec 4)) (offset : (BitVec 64)) : SailM Unit := do
  let branch_conditional : Bool := true
  (if ((← (ConditionHolds condition)) : Bool)
  then (do (BranchTo ((← (PC_read ())) + offset) BranchType_DIR branch_conditional))
  else (do (BranchNotTaken BranchType_DIR branch_conditional)))

def decode_b_cond_aarch64_instrs_branch_conditional_cond (cond : (BitVec 4)) (imm19 : (BitVec 19)) : SailM Unit := do
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let condition : (BitVec 4) := cond
  (execute_aarch64_instrs_branch_conditional_cond condition offset)

/-- Type quantifiers: a : Nat, d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3_bcax (a : Nat) (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vm ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let Vn ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let Va ← (( do (V_read a 128) ) : SailM (BitVec 128) )
  (V_set d 128 (Vn ^^^ (Vm &&& (Complement.complement Va))))

def decode_bcax_advsimd_aarch64_instrs_vector_crypto_sha3_bcax (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA3Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  (execute_aarch64_instrs_vector_crypto_sha3_bcax a d m n)

/-- Type quantifiers: d : Nat, datasize : Nat, k_extend : Bool, k_inzero : Bool, n : Nat, r : Nat, s : Nat, 0 ≤ s ∧ s ≤ 63 ∧ 0 ≤ r ∧ r ≤ 63 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_bitfield (d : Nat) (datasize : Nat) (extend : Bool) (inzero : Bool) (n : Nat) (r : Nat) (s : Nat) (tmask : (BitVec datasize)) (wmask : (BitVec datasize)) : SailM Unit := do
  let dst ← (( do
    (if (inzero : Bool)
    then (do (pure (Zeros (n := datasize))))
    else (do (X_read d datasize))) ) : SailM (BitVec datasize) )
  let src ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let bot : (BitVec datasize) := ((dst &&& (Complement.complement wmask)) ||| ((ROR src r) &&& wmask))
  let top ← (( do
    (if (extend : Bool)
    then
      (do sail_assert ((0 ≤b s) && (s <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:2861.53-2861.54"
          (pure (BitVec.replicateBits ((BitVec.access src s) : BitVec 1) datasize)))
    else (do (pure dst))) ) : SailM (BitVec datasize) )
  (X_set d datasize ((top &&& (Complement.complement tmask)) ||| (bot &&& tmask)))

def decode_bfm_aarch64_instrs_integer_bitfield (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let inzero ← (( do (undefined_bool ()) ) : SailM Bool )
  let extend ← (( do (undefined_bool ()) ) : SailM Bool )
  let wmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let tmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (extend, inzero) ← (( do
    match opc with
    | 0b00 =>
      (let inzero : Bool := true
      let extend : Bool := true
      (pure (extend, inzero)))
    | 0b01 =>
      (let inzero : Bool := false
      let extend : Bool := false
      (pure (extend, inzero)))
    | 0b10 =>
      (let inzero : Bool := true
      let extend : Bool := false
      (pure (extend, inzero)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × Bool) )
  let extend := extend
  let inzero := inzero
  (if (((sf == 1#1) && (N != 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((N != 0#1) || (((BitVec.access immr 5) : BitVec 1) != 0#1)) || (((BitVec.access imms 5) : BitVec 1) != 0#1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let r := (BitVec.toNat immr)
  let s := (BitVec.toNat imms)
  let (tmask, wmask) ← (( do
    let (tup__0, tup__1) ← do (DecodeBitMasks N imms immr false datasize)
    let wmask : (BitVec datasize) := tup__0
    let tmask : (BitVec datasize) := tup__1
    (pure (tmask, wmask)) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
  (execute_aarch64_instrs_integer_bitfield d datasize extend inzero n r s tmask wmask)

def decode_sbfm_aarch64_instrs_integer_bitfield (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let inzero ← (( do (undefined_bool ()) ) : SailM Bool )
  let extend ← (( do (undefined_bool ()) ) : SailM Bool )
  let wmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let tmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (extend, inzero) ← (( do
    match opc with
    | 0b00 =>
      (let inzero : Bool := true
      let extend : Bool := true
      (pure (extend, inzero)))
    | 0b01 =>
      (let inzero : Bool := false
      let extend : Bool := false
      (pure (extend, inzero)))
    | 0b10 =>
      (let inzero : Bool := true
      let extend : Bool := false
      (pure (extend, inzero)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × Bool) )
  let extend := extend
  let inzero := inzero
  (if (((sf == 1#1) && (N != 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((N != 0#1) || (((BitVec.access immr 5) : BitVec 1) != 0#1)) || (((BitVec.access imms 5) : BitVec 1) != 0#1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let r := (BitVec.toNat immr)
  let s := (BitVec.toNat imms)
  let (tmask, wmask) ← (( do
    let (tup__0, tup__1) ← do (DecodeBitMasks N imms immr false datasize)
    let wmask : (BitVec datasize) := tup__0
    let tmask : (BitVec datasize) := tup__1
    (pure (tmask, wmask)) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
  (execute_aarch64_instrs_integer_bitfield d datasize extend inzero n r s tmask wmask)

def decode_ubfm_aarch64_instrs_integer_bitfield (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imms : (BitVec 6)) (immr : (BitVec 6)) (N : (BitVec 1)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let inzero ← (( do (undefined_bool ()) ) : SailM Bool )
  let extend ← (( do (undefined_bool ()) ) : SailM Bool )
  let wmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let tmask ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (extend, inzero) ← (( do
    match opc with
    | 0b00 =>
      (let inzero : Bool := true
      let extend : Bool := true
      (pure (extend, inzero)))
    | 0b01 =>
      (let inzero : Bool := false
      let extend : Bool := false
      (pure (extend, inzero)))
    | 0b10 =>
      (let inzero : Bool := true
      let extend : Bool := false
      (pure (extend, inzero)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × Bool) )
  let extend := extend
  let inzero := inzero
  (if (((sf == 1#1) && (N != 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((N != 0#1) || (((BitVec.access immr 5) : BitVec 1) != 0#1)) || (((BitVec.access imms 5) : BitVec 1) != 0#1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let r := (BitVec.toNat immr)
  let s := (BitVec.toNat imms)
  let (tmask, wmask) ← (( do
    let (tup__0, tup__1) ← do (DecodeBitMasks N imms immr false datasize)
    let wmask : (BitVec datasize) := tup__0
    let tmask : (BitVec datasize) := tup__1
    (pure (tmask, wmask)) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
  (execute_aarch64_instrs_integer_bitfield d datasize extend inzero n r s tmask wmask)

/-- Type quantifiers: datasize : Nat, rd : Nat, 0 ≤ rd ∧ rd ≤ 31 ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_vector_logical (datasize : Nat) (imm : (BitVec datasize)) (operation : ImmediateOp) (rd : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    match operation with
    | .ImmediateOp_MOVI => (pure imm)
    | .ImmediateOp_MVNI => (pure (Complement.complement imm))
    | .ImmediateOp_ORR =>
      (do
        let operand ← (( do (V_read rd datasize) ) : SailM (BitVec datasize) )
        (pure (operand ||| imm)))
    | .ImmediateOp_BIC =>
      (do
        let operand ← (( do (V_read rd datasize) ) : SailM (BitVec datasize) )
        (pure (operand &&& (Complement.complement imm)))) ) : SailM (BitVec datasize) )
  (V_set rd datasize result)

def decode_bic_advsimd_imm_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_logical datasize imm operation rd)

def decode_movi_advsimd_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_logical datasize imm operation rd)

def decode_mvni_advsimd_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_logical datasize imm operation rd)

def decode_orr_advsimd_imm_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_logical datasize imm operation rd)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (op : VBitOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand4 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let (operand1, operand2, operand3) ← (( do
    match op with
    | .VBitOp_VEOR =>
      (do
        let operand1 ← (V_read m datasize)
        let operand2 : (BitVec datasize) := (Zeros (n := datasize))
        let operand3 : (BitVec datasize) := (Ones (n := datasize))
        (pure (operand1, operand2, operand3)))
    | .VBitOp_VBSL =>
      (do
        let operand1 ← (V_read m datasize)
        let operand2 : (BitVec datasize) := operand1
        let operand3 ← (V_read d datasize)
        (pure (operand1, operand2, operand3)))
    | .VBitOp_VBIT =>
      (do
        let operand1 ← (V_read d datasize)
        let operand2 : (BitVec datasize) := operand1
        let operand3 ← (V_read m datasize)
        (pure (operand1, operand2, operand3)))
    | .VBitOp_VBIF =>
      (do
        let operand1 ← (V_read d datasize)
        let operand2 : (BitVec datasize) := operand1
        let operand3 ← (pure (Complement.complement (← (V_read m datasize))))
        (pure (operand1, operand2, operand3))) ) : SailM ((BitVec datasize) × (BitVec datasize) × (BitVec datasize)) )
  let operand3 := operand3
  let operand2 := operand2
  let operand1 := operand1
  (V_set d datasize (operand1 ^^^ ((operand2 ^^^ operand4) &&& operand3)))

def decode_bif_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (opc2 : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let op ← (( do (undefined_VBitOp ()) ) : SailM VBitOp )
  let op : VBitOp :=
    match opc2 with
    | 0b00 => VBitOp_VEOR
    | 0b01 => VBitOp_VBSL
    | 0b10 => VBitOp_VBIT
    | _ => VBitOp_VBIF
  let op := op
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor d datasize m n op)

def decode_bit_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (opc2 : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let op ← (( do (undefined_VBitOp ()) ) : SailM VBitOp )
  let op : VBitOp :=
    match opc2 with
    | 0b00 => VBitOp_VEOR
    | 0b01 => VBitOp_VBSL
    | 0b10 => VBitOp_VBIT
    | _ => VBitOp_VBIF
  let op := op
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor d datasize m n op)

def decode_bsl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (opc2 : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let op ← (( do (undefined_VBitOp ()) ) : SailM VBitOp )
  let op : VBitOp :=
    match opc2 with
    | 0b00 => VBitOp_VEOR
    | 0b01 => VBitOp_VBSL
    | 0b10 => VBitOp_VBIT
    | _ => VBitOp_VBIF
  let op := op
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor d datasize m n op)

def decode_eor_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (opc2 : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let op ← (( do (undefined_VBitOp ()) ) : SailM VBitOp )
  let op : VBitOp :=
    match opc2 with
    | 0b00 => VBitOp_VEOR
    | 0b01 => VBitOp_VBSL
    | 0b10 => VBitOp_VBIT
    | _ => VBitOp_VBIF
  let op := op
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_logical_bsl_eor d datasize m n op)

/-- Type quantifiers: m : Nat, n : Nat, k_pac : Bool, k_source_is_sp : Bool, k_use_key_a : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 -/
def execute_aarch64_instrs_branch_unconditional_register (branch_type : BranchType) (m : Nat) (n : Nat) (pac : Bool) (source_is_sp : Bool) (use_key_a : Bool) : SailM Unit := do
  let inst_type ← (( do (undefined_GCSInstruction ()) ) : SailM GCSInstruction )
  let target ← (( do (X_read n 64) ) : SailM (BitVec 64) )
  let auth_then_branch : Bool := true
  let target ← (( do
    (if (pac : Bool)
    then
      (do let modifier ← (( do
            (if (source_is_sp : Bool)
            then (do (SP_read ()))
            else (do (X_read m 64))) ) : SailM (BitVec 64) )
          (if (use_key_a : Bool)
          then (do (AuthIA target modifier auth_then_branch))
          else (do (AuthIB target modifier auth_then_branch))))
    else (do (pure target))) ) : SailM (BitVec 64) )
  let target ← (( do
    (if ((←((pure (BEq.beq branch_type BranchType_RET)) <&&> (do
         (HaveGCS ())) <&&> (do
         (GCSPCREnabled (← readReg PSTATE).EL)))) : Bool)
    then
      (do let inst_type : GCSInstruction :=
            if ((! pac) : Bool)
            then GCSInstType_PRET
            else
              (if (use_key_a : Bool)
              then GCSInstType_PRETAA
              else GCSInstType_PRETAB)
          let target ← (LoadCheckGCSRecord target inst_type)
          (SetCurrentGCSPointer (BitVec.addInt (← (GetCurrentGCSPointer ())) 8))
          (pure target))
    else (do (pure target))) ) : SailM (BitVec 64) )
  (if ((BEq.beq branch_type BranchType_INDCALL) : Bool)
  then
    (do (if ((←((HaveGCS ()) <&&> (do
             (GCSPCREnabled (← readReg PSTATE).EL)))) : Bool)
        then (do (AddGCSRecord (BitVec.addInt (← (PC_read ())) 4)))
        else (do (pure ())))
        (X_set 30 64 (BitVec.addInt (← (PC_read ())) 4)))
  else (do (pure ())))
  match branch_type with
  | .BranchType_INDIR =>
    (do
      (if ((← readReg InGuardedPage) : Bool)
      then
        (do (if (((n == 16) || (n == 17)) : Bool)
            then (do writeReg BTypeNext 0b01#2)
            else (do writeReg BTypeNext 0b11#2)))
      else (do writeReg BTypeNext 0b01#2)))
  | .BranchType_INDCALL => writeReg BTypeNext 0b10#2
  | .BranchType_RET => writeReg BTypeNext 0b00#2
  | _ => (pure ())
  let branch_conditional : Bool := false
  (BranchTo target branch_type branch_conditional)

def decode_blr_aarch64_instrs_branch_unconditional_register (Rm : (BitVec 5)) (Rn : (BitVec 5)) (M : (BitVec 1)) (A : (BitVec 1)) (op : (BitVec 2)) (Z : (BitVec 1)) : SailM Unit := do
  let n : Nat := (BitVec.toNat Rn)
  let branch_type ← (( do (undefined_BranchType ()) ) : SailM BranchType )
  let m := (BitVec.toNat Rm)
  let pac : Bool := (A == 1#1)
  let use_key_a : Bool := (M == 0#1)
  let source_is_sp : Bool := ((Z == 1#1) && (m == 31))
  (if (((! pac) && (m != 0)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure pac) <&&> (do
             (pure (! (← (HavePACExt ()))))))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))))
  let branch_type ← (( do
    match op with
    | 0b00 => (pure BranchType_INDIR)
    | 0b01 => (pure BranchType_INDCALL)
    | 0b10 => (pure BranchType_RET)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM BranchType )
  let branch_type := branch_type
  let (n, source_is_sp) ← (( do
    (if (pac : Bool)
    then
      (do (if (((Z == 0#1) && (m != 31)) : Bool)
          then (do sailThrow ((Error_Undefined ())))
          else (do (pure ())))
          let (n, source_is_sp) ← (( do
            (if ((BEq.beq branch_type BranchType_RET) : Bool)
            then
              (do (if ((n != 31) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let n : Nat := 30
                  let source_is_sp : Bool := true
                  (pure (n, source_is_sp)))
            else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
          (pure (n, source_is_sp)))
    else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
  let n := n
  (execute_aarch64_instrs_branch_unconditional_register branch_type m n pac source_is_sp use_key_a)

def decode_br_aarch64_instrs_branch_unconditional_register (Rm : (BitVec 5)) (Rn : (BitVec 5)) (M : (BitVec 1)) (A : (BitVec 1)) (op : (BitVec 2)) (Z : (BitVec 1)) : SailM Unit := do
  let n : Nat := (BitVec.toNat Rn)
  let branch_type ← (( do (undefined_BranchType ()) ) : SailM BranchType )
  let m := (BitVec.toNat Rm)
  let pac : Bool := (A == 1#1)
  let use_key_a : Bool := (M == 0#1)
  let source_is_sp : Bool := ((Z == 1#1) && (m == 31))
  (if (((! pac) && (m != 0)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure pac) <&&> (do
             (pure (! (← (HavePACExt ()))))))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))))
  let branch_type ← (( do
    match op with
    | 0b00 => (pure BranchType_INDIR)
    | 0b01 => (pure BranchType_INDCALL)
    | 0b10 => (pure BranchType_RET)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM BranchType )
  let branch_type := branch_type
  let (n, source_is_sp) ← (( do
    (if (pac : Bool)
    then
      (do (if (((Z == 0#1) && (m != 31)) : Bool)
          then (do sailThrow ((Error_Undefined ())))
          else (do (pure ())))
          let (n, source_is_sp) ← (( do
            (if ((BEq.beq branch_type BranchType_RET) : Bool)
            then
              (do (if ((n != 31) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let n : Nat := 30
                  let source_is_sp : Bool := true
                  (pure (n, source_is_sp)))
            else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
          (pure (n, source_is_sp)))
    else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
  let n := n
  (execute_aarch64_instrs_branch_unconditional_register branch_type m n pac source_is_sp use_key_a)

def decode_ret_aarch64_instrs_branch_unconditional_register (Rm : (BitVec 5)) (Rn : (BitVec 5)) (M : (BitVec 1)) (A : (BitVec 1)) (op : (BitVec 2)) (Z : (BitVec 1)) : SailM Unit := do
  let n : Nat := (BitVec.toNat Rn)
  let branch_type ← (( do (undefined_BranchType ()) ) : SailM BranchType )
  let m := (BitVec.toNat Rm)
  let pac : Bool := (A == 1#1)
  let use_key_a : Bool := (M == 0#1)
  let source_is_sp : Bool := ((Z == 1#1) && (m == 31))
  (if (((! pac) && (m != 0)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure pac) <&&> (do
             (pure (! (← (HavePACExt ()))))))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))))
  let branch_type ← (( do
    match op with
    | 0b00 => (pure BranchType_INDIR)
    | 0b01 => (pure BranchType_INDCALL)
    | 0b10 => (pure BranchType_RET)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM BranchType )
  let branch_type := branch_type
  let (n, source_is_sp) ← (( do
    (if (pac : Bool)
    then
      (do (if (((Z == 0#1) && (m != 31)) : Bool)
          then (do sailThrow ((Error_Undefined ())))
          else (do (pure ())))
          let (n, source_is_sp) ← (( do
            (if ((BEq.beq branch_type BranchType_RET) : Bool)
            then
              (do (if ((n != 31) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let n : Nat := 30
                  let source_is_sp : Bool := true
                  (pure (n, source_is_sp)))
            else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
          (pure (n, source_is_sp)))
    else (do (pure (n, source_is_sp)))) ) : SailM (Nat × Bool) )
  let n := n
  (execute_aarch64_instrs_branch_unconditional_register branch_type m n pac source_is_sp use_key_a)

def execute_aarch64_instrs_system_exceptions_debug_breakpoint (comment : (BitVec 16)) : SailM Unit := do
  (AArch64_SoftwareBreakpoint comment)

def decode_brk_aarch64_instrs_system_exceptions_debug_breakpoint (imm16 : (BitVec 16)) : SailM Unit := do
  let comment : (BitVec 16) := imm16
  (if ((← (HaveBTIExt ())) : Bool)
  then (do (SetBTypeCompatible true))
  else (do (pure ())))
  (execute_aarch64_instrs_system_exceptions_debug_breakpoint comment)

def execute_aarch64_instrs_system_hints (op : SystemHintOp) : SailM Unit := do
  match op with
  | .SystemHintOp_YIELD => (pure (Hint_Yield ()))
  | .SystemHintOp_DGH => (pure (Hint_DGH ()))
  | .SystemHintOp_WFE =>
    (do
      let localtimeout := (Int.shiftl 1 64)
      (Hint_WFE localtimeout WFxType_WFE))
  | .SystemHintOp_WFI =>
    (do
      let localtimeout := (Int.shiftl 1 64)
      (Hint_WFI localtimeout WFxType_WFI))
  | .SystemHintOp_SEV => (pure (SendEvent ()))
  | .SystemHintOp_SEVL => (SendEventLocal ())
  | .SystemHintOp_ESB =>
    (do
      (if ((←((HaveTME ()) <&&> (do
           (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
      then (do (FailTransaction TMFailure_ERR false))
      else (do (pure ())))
      let _ : Unit := (SynchronizeErrors ())
      (AArch64_ESBOperation ())
      (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
           (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
           (EL2Enabled ())))) : Bool)
      then (do (AArch64_vESBOperation ()))
      else (do (pure ())))
      (TakeUnmaskedSErrorInterrupts ()))
  | .SystemHintOp_PSB => (pure (ProfilingSynchronizationBarrier ()))
  | .SystemHintOp_TSB => (pure (TraceSynchronizationBarrier ()))
  | .SystemHintOp_GCSB => (pure (GCSSynchronizationBarrier ()))
  | .SystemHintOp_CHKFEAT => (X_set 16 64 (← (AArch64_ChkFeat (← (X_read 16 64)))))
  | .SystemHintOp_CSDB => (pure (ConsumptionOfSpeculativeDataBarrier ()))
  | .SystemHintOp_CLRBHB => (pure (Hint_CLRBHB ()))
  | .SystemHintOp_BTI => (SetBTypeNext 0b00#2)
  | .SystemHintOp_NOP => (pure ())
  | _ => (Unreachable ())

def decode_bti_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_csdb_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_dgh_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_hint_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)

def decode_nop_aarch64_instrs_system_hints (op2 : (BitVec 3)) (CRm : (BitVec 4)) : SailM Unit := do
  let op ← (( do (undefined_SystemHintOp ()) ) : SailM SystemHintOp )
  let op ← (( do
    let b__0 := (CRm +++ op2)
    (if ((b__0 == (0b0000000#7 : (BitVec 7))) : Bool)
    then (do (pure SystemHintOp_NOP))
    else
      (do (if ((b__0 == (0b0000001#7 : (BitVec 7))) : Bool)
          then (do (pure SystemHintOp_YIELD))
          else
            (do (if ((b__0 == (0b0000010#7 : (BitVec 7))) : Bool)
                then (do (pure SystemHintOp_WFE))
                else
                  (do (if ((b__0 == (0b0000011#7 : (BitVec 7))) : Bool)
                      then (do (pure SystemHintOp_WFI))
                      else
                        (do (if ((b__0 == (0b0000100#7 : (BitVec 7))) : Bool)
                            then (do (pure SystemHintOp_SEV))
                            else
                              (do (if ((b__0 == (0b0000101#7 : (BitVec 7))) : Bool)
                                  then (do (pure SystemHintOp_SEVL))
                                  else
                                    (do (if ((b__0 == (0b0000110#7 : (BitVec 7))) : Bool)
                                        then
                                          (do (if ((! (← (HaveDGHExt ()))) : Bool)
                                              then (do (EndOfInstruction ()))
                                              else (do (pure ())))
                                              (pure SystemHintOp_DGH))
                                        else
                                          (do (if ((b__0 == (0b0000111#7 : (BitVec 7))) : Bool)
                                              then (do sailThrow ((Error_See "XPACLRI")))
                                              else
                                                (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x1#4 : (BitVec 4))) : Bool)
                                                    then
                                                      (do match op2 with
                                                          | 0b000 => sailThrow ((Error_See "PACIA1716"))
                                                          | 0b010 => sailThrow ((Error_See "PACIB1716"))
                                                          | 0b100 => sailThrow ((Error_See "AUTIA1716"))
                                                          | 0b110 => sailThrow ((Error_See "AUTIB1716"))
                                                          | _ => (EndOfInstruction ())
                                                          (pure op))
                                                    else
                                                      (do (if ((b__0 == (0b0010000#7 : (BitVec 7))) : Bool)
                                                          then
                                                            (do (if ((! (← (HaveRASExt ()))) : Bool)
                                                                then (do (EndOfInstruction ()))
                                                                else (do (pure ())))
                                                                (pure SystemHintOp_ESB))
                                                          else
                                                            (do (if ((b__0 == (0b0010001#7 : (BitVec 7))) : Bool)
                                                                then
                                                                  (do (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
                                                                      then (do (EndOfInstruction ()))
                                                                      else (do (pure ())))
                                                                      (pure SystemHintOp_PSB))
                                                                else
                                                                  (do (if ((b__0 == (0b0010010#7 : (BitVec 7))) : Bool)
                                                                      then
                                                                        (do (if ((! (← (HaveSelfHostedTrace ()))) : Bool)
                                                                            then (do (EndOfInstruction ()))
                                                                            else (do (pure ())))
                                                                            (pure SystemHintOp_TSB))
                                                                      else
                                                                        (do (if ((b__0 == (0b0010011#7 : (BitVec 7))) : Bool)
                                                                            then
                                                                              (do (if ((! (← (IsFeatureImplemented FEAT_GCS))) : Bool)
                                                                                  then (do (EndOfInstruction ()))
                                                                                  else (do (pure ())))
                                                                                  (pure SystemHintOp_GCSB))
                                                                            else
                                                                              (do (if ((b__0 == (0b0010100#7 : (BitVec 7))) : Bool)
                                                                                  then (do (pure SystemHintOp_CSDB))
                                                                                  else
                                                                                    (do (if ((b__0 == (0b0010110#7 : (BitVec 7))) : Bool)
                                                                                        then
                                                                                          (do (if ((! (← (HaveFeatCLRBHB ()))) : Bool)
                                                                                              then (do (EndOfInstruction ()))
                                                                                              else (do (pure ())))
                                                                                              (pure SystemHintOp_CLRBHB))
                                                                                        else
                                                                                          (do (if (((Sail.BitVec.extractLsb b__0 6 3) == (0x3#4 : (BitVec 4))) : Bool)
                                                                                              then
                                                                                                (do match op2 with
                                                                                                    | 0b000 => sailThrow ((Error_See "PACIAZ"))
                                                                                                    | 0b001 => sailThrow ((Error_See "PACIASP"))
                                                                                                    | 0b010 => sailThrow ((Error_See "PACIBZ"))
                                                                                                    | 0b011 => sailThrow ((Error_See "PACIBSP"))
                                                                                                    | 0b100 => sailThrow ((Error_See "AUTIAZ"))
                                                                                                    | 0b101 => sailThrow ((Error_See "AUTIASP"))
                                                                                                    | 0b110 => sailThrow ((Error_See "AUTIBZ"))
                                                                                                    | _ => sailThrow ((Error_See "AUTIBSP"))
                                                                                                    (pure op))
                                                                                              else
                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 6 3) == (0x4#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                    then
                                                                                                      (do let op : SystemHintOp := SystemHintOp_BTI
                                                                                                          (SetBTypeCompatible (← (BTypeCompatible_BTI (Sail.BitVec.extractLsb op2 2 1))))
                                                                                                          (pure op))
                                                                                                    else
                                                                                                      (do (if ((b__0 == (0b0101000#7 : (BitVec 7))) : Bool)
                                                                                                          then
                                                                                                            (do (if ((! (← (IsFeatureImplemented FEAT_CHK))) : Bool)
                                                                                                                then (do (EndOfInstruction ()))
                                                                                                                else (do (pure ())))
                                                                                                                (pure SystemHintOp_CHKFEAT))
                                                                                                          else
                                                                                                            (do (EndOfInstruction ())
                                                                                                                (pure op))))))))))))))))))))))))))))))))))))) ) : SailM SystemHintOp )
  (execute_aarch64_instrs_system_hints op)


end ArmASL.Functions
