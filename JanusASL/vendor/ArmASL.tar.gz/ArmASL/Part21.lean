import ArmASL.Part20

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_55cdacc69a298806 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (6 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 6 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 6 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 6 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_5c1b36bf1cfddcd3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (3 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 3 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 3 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 3 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_852dfd64d8177f24 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (8 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 8 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 8 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 8 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_937d9c663e9c5fac (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (9 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 9 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 9 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 9 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_b07af68aa09a25a4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (14 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 14 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 14 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 14 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_b6b7620b2590b0ed (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (13 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 13 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 13 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 13 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_bdc011d5eec3120d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (5 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 5 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 5 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 5 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_bfd9ab96b75f8397 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (2 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 2 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 2 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 2 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_d66d369f6bf3258b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (12 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 12 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 12 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 12 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_d9115397654925c1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (1 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 1 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 1 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 1 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_de9cae5804e73d5d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (10 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 10 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 10 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 10 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_fd95b8925256c672 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (0 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 0 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 0 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 0 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_ff943c25599ed8a6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (4 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 4 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 4 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 4 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGCLAIMCLR_EL1_SysRegWrite_9e17f03f8d2d5748 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGCLAIM ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGCLAIM (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGCLAIM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg DBGCLAIMCLR_EL1 (Mk_DBGCLAIMCLR_EL1_Type (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg DBGCLAIMCLR_EL1 (Mk_DBGCLAIMCLR_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg DBGCLAIMCLR_EL1 (Mk_DBGCLAIMCLR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DBGCLAIMSET_EL1_SysRegWrite_ebe44f0b96496255 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGCLAIM ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGCLAIM (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGCLAIM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg DBGCLAIMSET_EL1 (Mk_DBGCLAIMSET_EL1_Type (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg DBGCLAIMSET_EL1 (Mk_DBGCLAIMSET_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg DBGCLAIMSET_EL1 (Mk_DBGCLAIMSET_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DBGDTRTX_EL0_SysRegWrite_b44ad1253b524254 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDSCR_EL1_TDCC ← (( do (pure (_get_MDSCR_EL1_Type_TDCC (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDCC ← (( do (pure (_get_MDCR_EL2_Type_TDCC (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDCC ← (( do (pure (_get_MDCR_EL3_Type_TDCC (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((← (Halted ())) : Bool)
  then (do writeReg DBGDTRTX_EL0 (← (X_read t 64)))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then
          (do (if ((__MDSCR_EL1_TDCC == 1#1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do
                                 (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2)))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                      else (do writeReg DBGDTRTX_EL0 (← (X_read t 64)))))))))))))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                      else (do writeReg DBGDTRTX_EL0 (← (X_read t 64)))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else (do writeReg DBGDTRTX_EL0 (← (X_read t 64)))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg DBGDTRTX_EL0 (← (X_read t 64)))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGDTR_EL0_SysRegWrite_a660c15660434176 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDSCR_EL1_TDCC ← (( do (pure (_get_MDSCR_EL1_Type_TDCC (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDCC ← (( do (pure (_get_MDCR_EL2_Type_TDCC (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDCC ← (( do (pure (_get_MDCR_EL3_Type_TDCC (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((← (Halted ())) : Bool)
  then (do (DBGDTR_EL0_write (Mk_DBGDTR_EL0_Type (← (X_read t 64)))))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then
          (do (if ((__MDSCR_EL1_TDCC == 1#1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do
                                 (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2)))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                      else (do (DBGDTR_EL0_write (Mk_DBGDTR_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                      else (do (DBGDTR_EL0_write (Mk_DBGDTR_EL0_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                                else (do (DBGDTR_EL0_write (Mk_DBGDTR_EL0_Type (← (X_read t 64)))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do (DBGDTR_EL0_write (Mk_DBGDTR_EL0_Type (← (X_read t 64)))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGPRCR_EL1_SysRegWrite_61b4445159bc717f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDOSA ← (( do (pure (_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGPRCR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGPRCR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGPRCR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDOSA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg DBGPRCR_EL1 (Mk_DBGPRCR_EL1_Type (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg DBGPRCR_EL1 (Mk_DBGPRCR_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg DBGPRCR_EL1 (Mk_DBGPRCR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DBGVCR32_EL2_SysRegWrite_2027ba18d0bb0f7c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (HaveAArch32EL EL1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg DBGVCR32_EL2 (Mk_DBGVCR32_EL2_Type (← (X_read t 64))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg DBGVCR32_EL2 (Mk_DBGVCR32_EL2_Type (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_0d601db72f451078 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (15 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((15 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 15 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 15 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 15 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_18462f760618e8fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (7 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((7 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 7 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 7 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 7 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_1c79cf637de59bc4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (0 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((0 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 0 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 0 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 0 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_26c799c330f26506 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (9 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((9 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 9 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 9 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 9 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_2c96fce13ad4bca3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (5 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((5 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 5 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 5 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 5 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_3550aa3a97d9acb5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (14 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((14 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 14 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 14 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 14 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGWCR_EL1_SysRegWrite_3d5a9e41f298edee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGWCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (3 ≥b (← readReg NUM_WATCHPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((3 +i ((BitVec.toNat (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) *i 16)) ≥b (← readReg NUM_WATCHPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGWCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 3 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 3 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGWCR_EL1 (vectorUpdate (← readReg DBGWCR_EL1) 3 (Mk_DBGWCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))


end ArmASL.Functions
