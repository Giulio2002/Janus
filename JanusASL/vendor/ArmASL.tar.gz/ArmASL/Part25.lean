import ArmASL.Part24

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_ld1_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22140.48-22140.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22210.48-22210.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22280.48-22280.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22350.48-22350.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22420.48-22420.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22490.48-22490.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22560.48-22560.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22630.48-22630.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22700.48-22700.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22770.48-22770.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22840.48-22840.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22910.48-22910.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22980.48-22980.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23050.48-23050.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23120.48-23120.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23190.48-23190.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st1_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23260.48-23260.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st2_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23330.48-23330.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st2_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23400.48-23400.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st3_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23470.48-23470.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st3_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23540.48-23540.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st4_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23610.48-23610.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st4_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:23680.48-23680.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

/-- Type quantifiers: datasize : Nat, elements : Int, esize : Nat, m : Int, n : Nat, k_nontemporal : Bool, rpt : Nat, selem : Nat, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem selem [1, 2, 3, 4] ∧ List.elem rpt [1, 2, 3, 4] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_memory_vector_multiple_no_wb (datasize : Nat) (elements : Int) (esize : Nat) (m : Int) (memop : MemOp) (n : Nat) (nontemporal : Bool) (rpt : Nat) (selem : Nat) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rval ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let tt ← (( do (undefined_int ()) ) : SailM Int )
  let ebytes := (Int.ediv esize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let offs : (BitVec 64) := (Zeros (n := 64))
  let (offs, rval, tt) ← (( do
    let loop_r_lower := 0
    let loop_r_upper := (rpt -i 1)
    let mut loop_vars := (offs, rval, tt)
    for r in [loop_r_lower:loop_r_upper:1]i do
      let (offs, rval, tt) := loop_vars
      loop_vars ← do
        let (offs, rval, tt) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements -i 1)
          let mut loop_vars_1 := (offs, rval, tt)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (offs, rval, tt) := loop_vars_1
            loop_vars_1 ← do
              let tt : Int := (Nat.mod (t +i r) 32)
              let (offs, rval, tt) ← (( do
                let loop_s_lower := 0
                let loop_s_upper := (selem -i 1)
                let mut loop_vars_2 := (offs, rval, tt)
                for s in [loop_s_lower:loop_s_upper:1]i do
                  let (offs, rval, tt) := loop_vars_2
                  loop_vars_2 ← do
                    let rval ← (( do
                      let tt := tt
                      (V_read tt datasize) ) : SailM (BitVec datasize) )
                    let rval ← (( do
                      let tt := tt
                      (if ((BEq.beq memop MemOp_LOAD) : Bool)
                      then
                        (do let rval ← (Elem_set rval e esize (← (Mem_read (address + offs) ebytes accdesc)))
                            (V_set tt datasize rval)
                            (pure rval))
                      else
                        (do (Mem_set (address + offs) ebytes accdesc (← (Elem_read rval e esize)))
                            (pure rval))) ) : SailM (BitVec datasize) )
                    let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                    let tt : Int := (fmod_int (tt +i 1) 32)
                    (pure (offs, rval, tt))
                (pure loop_vars_2) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
              (pure (offs, rval, tt))
          (pure loop_vars_1) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
        (pure (offs, rval, tt))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))
  (if (wback : Bool)
  then
    (do let offs ← (( do
          (if ((m != 31) : Bool)
          then (do (X_read m 64))
          else (do (pure offs))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set (address + offs)))
        else (do (X_set n 64 (address + offs)))))
  else (do (pure ())))

def decode_ld1_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld1_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld2_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld2_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld3_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld3_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld4_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld4_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st1_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st1_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st2_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st2_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st3_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st3_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st4_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st4_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, k_is_load : Bool, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_ld (acquire : Bool) (datasize : Nat) (is_load : Bool) (n : Nat) (op : MemAtomicOp) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp op acquire release tagchecked) ) : SailM AccessDescriptor )
  let value_name ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let comparevalue ← (( do (__UNKNOWN_bits datasize) ) : SailM (BitVec datasize) )
  let data ← (( do (MemAtomic address comparevalue value_name accdesc) ) : SailM (BitVec datasize) )
  (if ((t != 31) : Bool)
  then
    (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:24904.67-24904.68"
        (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldadd_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldaddb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldaddh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclr_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclrb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclrh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeor_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeorb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeorh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldset_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsetb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldseth_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmax_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmaxb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmaxh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmin_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsminb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsminh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumax_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumaxb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumaxh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumin_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_lduminb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_lduminh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

/-- Type quantifiers: datasize : Nat, esize : Nat, index : Int, m : Int, n : Nat, k_replicate : Bool, selem : Nat, t__arg : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t__arg ∧ t__arg ≤ 31 ∧ List.elem selem [1, 2, 3, 4] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_memory_vector_single_no_wb_ordered (datasize : Nat) (esize : Nat) (index : Int) (m : Int) (memop : MemOp) (n : Nat) (replicate : Bool) (selem : Nat) (t__arg : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let t : Int := t__arg
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rval ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let ebytes := (Int.ediv esize 8)
  let accdesc ← (( do (CreateAccDescASIMDAcqRel memop tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let offs : (BitVec 64) := (Zeros (n := 64))
  let offs ← (( do
    (if (replicate : Bool)
    then
      (do let (element, offs, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars_1 := (element, offs, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (element, offs, t) := loop_vars_1
              loop_vars_1 ← do
                let element ← (Mem_read (address + offs) ebytes accdesc)
                (V_set t datasize (BitVec.replicateBits element (Int.ediv datasize esize)))
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (element, offs, t))
            (pure loop_vars_1) ) : SailM ((BitVec esize) × (BitVec 64) × Int) )
          (pure offs))
    else
      (do let (offs, rval, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars := (offs, rval, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (offs, rval, t) := loop_vars
              loop_vars ← do
                let rval ← (V_read t 128)
                let rval ← (( do
                  (if ((BEq.beq memop MemOp_LOAD) : Bool)
                  then
                    (do let rval ← (Elem_set rval index esize (← (Mem_read (address + offs) ebytes accdesc)))
                        (V_set t 128 rval)
                        (pure rval))
                  else
                    (do (Mem_set (address + offs) ebytes accdesc (← (Elem_read rval index esize)))
                        (pure rval))) ) : SailM (BitVec 128) )
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (offs, rval, t))
            (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 128) × Int) )
          (pure offs))) ) : SailM (BitVec 64) )
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))
  (if (wback : Bool)
  then
    (do let offs ← (( do
          (if ((m != 31) : Bool)
          then (do (X_read m 64))
          else (do (pure offs))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set (address + offs)))
        else (do (X_set n 64 (address + offs)))))
  else (do (pure ())))

def decode_ldap1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:26415.48-26415.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb_ordered datasize esize index m memop n replicate selem t tagchecked wback)

def decode_stl1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:26484.48-26484.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb_ordered datasize esize index m memop n replicate selem t tagchecked wback)

/-- Type quantifiers: datasize : Nat, n : Nat, offset : Nat, regsize : Nat, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ List.elem offset [0, 1, 2, 4, 8] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_ordered_rcpc (datasize : Nat) (n : Nat) (offset : Nat) (regsize : Nat) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescLDAcqPC tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:26516.44-26516.45"
  (X_set t regsize (Sail.BitVec.zeroExtend data regsize))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else (do (pure (BitVec.addInt address offset)))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) := 1#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldapr_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

def decode_ldaprb_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

def decode_ldaprh_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_postindex : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_ordered (datasize : Nat) (memop : MemOp) (n : Nat) (offset : (BitVec 64)) (postindex : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMDAcqRel memop tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27476.62-27476.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27482.62-27482.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldapur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27519.72-27519.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_ordered datasize memop n offset postindex t tagchecked wback)

def decode_stlur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27549.72-27549.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_ordered datasize memop n offset postindex t tagchecked wback)

/-- Type quantifiers: datasize : Nat, k_limitedordered : Bool, n : Nat, offset : Int, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_ordered (datasize : Nat) (limitedordered : Bool) (memop : MemOp) (n : Nat) (offset : Int) (regsize : Nat) (rt_unknown : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (undefined_AccessDescriptor ()) ) : SailM AccessDescriptor )
  let accdesc ← (( do
    (if (limitedordered : Bool)
    then (do (CreateAccDescLOR memop tagchecked))
    else (do (CreateAccDescAcqRel memop tagchecked))) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  match memop with
  | .MemOp_STORE =>
    (do
      let address : (BitVec 64) := (BitVec.addInt address offset)
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit := (AArch64_SetLSInstructionSyndrome dbytes false t (regsize == 64) true)
      (Mem_set address dbytes accdesc data)
      (if (wback : Bool)
      then
        (do (if ((n == 31) : Bool)
            then (do (SP_set address))
            else (do (X_set n 64 address))))
      else (do (pure ()))))
  | .MemOp_LOAD =>
    (do
      let _ : Unit := (AArch64_SetLSInstructionSyndrome dbytes false t (regsize == 64) true)
      let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
      sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27605.69-27605.70"
      (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) := 1#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := (BEq.beq memop MemOp_LOAD)
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldar_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_ldarb_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_ldarh_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)


end ArmASL.Functions
