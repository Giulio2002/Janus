import ArmASL.Part24

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def IFSR32_EL2_SysRegWrite_a0242d47ef5c27a4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((! (HaveAArch32EL EL1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then (do writeReg IFSR32_EL2 (Mk_IFSR32_EL2_Type (← (X_read t 64))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg IFSR32_EL2 (Mk_IFSR32_EL2_Type (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def LORC_EL1_SysRegWrite_266317162c3d113d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_TLOR ← (( do (pure (_get_SCR_EL3_Type_TLOR (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TLOR ← (( do (pure (_get_HCR_EL2_Type_TLOR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_LORC_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_LORC_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TLOR == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_LORC_EL1 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg LORC_EL1 (Mk_LORC_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg LORC_EL1 (Mk_LORC_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg LORC_EL1 (Mk_LORC_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def LOREA_EL1_SysRegWrite_12823f1415052a0d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_TLOR ← (( do (pure (_get_SCR_EL3_Type_TLOR (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TLOR ← (( do (pure (_get_HCR_EL2_Type_TLOR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_LOREA_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_LOREA_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TLOR == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_LOREA_EL1 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg LOREA_EL1 (Mk_LOREA_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg LOREA_EL1 (Mk_LOREA_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg LOREA_EL1 (Mk_LOREA_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def LORN_EL1_SysRegWrite_8a9df4ed50885fe4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_TLOR ← (( do (pure (_get_SCR_EL3_Type_TLOR (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TLOR ← (( do (pure (_get_HCR_EL2_Type_TLOR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_LORN_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_LORN_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TLOR == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_LORN_EL1 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg LORN_EL1 (Mk_LORN_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg LORN_EL1 (Mk_LORN_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg LORN_EL1 (Mk_LORN_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def LORSA_EL1_SysRegWrite_8563a4250c047bc4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_TLOR ← (( do (pure (_get_SCR_EL3_Type_TLOR (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TLOR ← (( do (pure (_get_HCR_EL2_Type_TLOR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_LORSA_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_LORSA_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TLOR == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_LORSA_EL1 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg LORSA_EL1 (Mk_LORSA_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_TLOR == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg LORSA_EL1 (Mk_LORSA_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg LORSA_EL1 (Mk_LORSA_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR2_EL1_SysRegWrite_e1a1cf3df97e5908 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x280#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg MAIR2_EL1 (Mk_MAIR2_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg MAIR2_EL1 (Mk_MAIR2_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR2_EL2_SysRegWrite_947c3848493bf9b8 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nMAIR2_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nMAIR2_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nMAIR2_EL1 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x280#12) (← (X_read t 64))))
                                      else (do writeReg MAIR2_EL1 (Mk_MAIR2_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg MAIR2_EL2 (Mk_MAIR2_EL2_Type (← (X_read t 64))))
                                else (do writeReg MAIR2_EL1 (Mk_MAIR2_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR2_EL1 (Mk_MAIR2_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR2_EL2_SysRegWrite_e772542d41ef21f4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg MAIR2_EL2 (Mk_MAIR2_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR2_EL2 (Mk_MAIR2_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR2_EL3_SysRegWrite_47b59b09cadb288b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR2_EL3 (Mk_MAIR2_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR_EL1_SysRegWrite_544016ebf1c83382 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_MAIR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_MAIR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_MAIR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x140#12) (← (X_read t 64))))
                          else (do writeReg MAIR_EL1 (Mk_MAIR_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg MAIR_EL2 (Mk_MAIR_EL2_Type (← (X_read t 64))))
                    else (do writeReg MAIR_EL1 (Mk_MAIR_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR_EL1 (Mk_MAIR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR_EL1_SysRegWrite_853552cc3b84fd15 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x140#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg MAIR_EL1 (Mk_MAIR_EL1_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg MAIR_EL1 (Mk_MAIR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR_EL2_SysRegWrite_c3f5f844df66ccc8 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg MAIR_EL2 (Mk_MAIR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR_EL2 (Mk_MAIR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MAIR_EL3_SysRegWrite_77100e09b4275a77 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MAIR_EL3 (Mk_MAIR_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MDCCINT_EL1_SysRegWrite_fbfdab04982e8c96 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDCC ← (( do (pure (_get_MDCR_EL3_Type_TDCC (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDCC ← (( do (pure (_get_MDCR_EL2_Type_TDCC (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((Halted ()) <&&> (do
             (ConstrainUnpredictableBool Unpredictable_IGNORETRAPINDEBUG)))) : Bool)
        then (do writeReg MDCCINT_EL1 (Mk_MDCCINT_EL1_Type (← (X_read t 64))))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                                  then
                                                    (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else (do writeReg MDCCINT_EL1 (Mk_MDCCINT_EL1_Type (← (X_read t 64))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg MDCCINT_EL1 (Mk_MDCCINT_EL1_Type (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg MDCCINT_EL1 (Mk_MDCCINT_EL1_Type (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def MDCR_EL2_SysRegWrite_b68bb751a2e2a82d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg MDCR_EL2 (Mk_MDCR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MDCR_EL2 (Mk_MDCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MDCR_EL3_SysRegWrite_83616ee112453f2c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MDCR_EL3 (Mk_MDCR_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MDSCR_EL1_SysRegWrite_77b35d79c41eeb78 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_MDSCR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_MDSCR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_MDSCR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x158#12) (← (X_read t 64))))
                                      else (do (__set_MDSCR_EL1 (Mk_MDSCR_EL1_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (__set_MDSCR_EL1 (Mk_MDSCR_EL1_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_MDSCR_EL1 (Mk_MDSCR_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MDSELR_EL1_SysRegWrite_96ef452973a846b6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EBWE ← (( do (pure (_get_MDCR_EL3_Type_EBWE (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nMDSELR_EL1 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nMDSELR_EL1 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EBWE == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nMDSELR_EL1 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_EBWE == 0#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                                  then
                                                    (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else (do (__set_MDSELR_EL1 (Mk_MDSELR_EL1_Type (← (X_read t 64)))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EBWE == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EBWE == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_MDSELR_EL1 (Mk_MDSELR_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_MDSELR_EL1 (Mk_MDSELR_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MECID_A0_EL2_SysRegWrite_c9ecd55f732bd0ad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg MECID_A0_EL2 (Mk_MECID_A0_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MECID_A0_EL2 (Mk_MECID_A0_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MECID_A1_EL2_SysRegWrite_bc98456a1287bbce (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg MECID_A1_EL2 (Mk_MECID_A1_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MECID_A1_EL2 (Mk_MECID_A1_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MECID_P0_EL2_SysRegWrite_e612f6294b4993e5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg MECID_P0_EL2 (Mk_MECID_P0_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MECID_P0_EL2 (Mk_MECID_P0_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MECID_P1_EL2_SysRegWrite_3807276157365bf3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg MECID_P1_EL2 (Mk_MECID_P1_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MECID_P1_EL2 (Mk_MECID_P1_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MECID_RL_A_EL3_SysRegWrite_be910360ddec275a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MECID_RL_A_EL3 (Mk_MECID_RL_A_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MFAR_EL3_SysRegWrite_036c1c3c4a295873 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MFAR_EL3 (Mk_MFAR_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAM0_EL1_SysRegWrite_20837bf9c61cd88e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MPAM2_EL2_TRAPMPAM0EL1 ← (( do (pure (_get_MPAM2_EL2_Type_TRAPMPAM0EL1 (← readReg MPAM2_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
              then
                (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((← (EL2Enabled ())) && (__MPAM2_EL2_TRAPMPAM0EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg MPAM0_EL1 (Mk_MPAM0_EL1_Type (← (X_read t 64))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAM0_EL1 (Mk_MPAM0_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAM0_EL1 (Mk_MPAM0_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAM1_EL1_SysRegWrite_6fc49ea36a62b2f9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x900#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (__set_MPAM1_EL1 (Mk_MPAM1_EL1_Type (← (X_read t 64)))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do (__set_MPAM1_EL1 (Mk_MPAM1_EL1_Type (← (X_read t 64)))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAM2_EL2_SysRegWrite_00c9bb10273a16c2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MPAM2_EL2_TRAPMPAM1EL1 ← (( do (pure (_get_MPAM2_EL2_Type_TRAPMPAM1EL1 (← readReg MPAM2_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
              then
                (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((← (EL2Enabled ())) && (__MPAM2_EL2_TRAPMPAM1EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x900#12) (← (X_read t 64))))
                          else (do (__set_MPAM1_EL1 (Mk_MPAM1_EL1_Type (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                          then (do (__set_MPAM2_EL2 (Mk_MPAM2_EL2_Type (← (X_read t 64)))))
                          else (do (__set_MPAM1_EL1 (Mk_MPAM1_EL1_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_MPAM1_EL1 (Mk_MPAM1_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAM2_EL2_SysRegWrite_50b38ada04e4d75f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do (__set_MPAM2_EL2 (Mk_MPAM2_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_MPAM2_EL2 (Mk_MPAM2_EL2_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAM3_EL3_SysRegWrite_350da3ad09fd23ed (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_MPAM3_EL3 (Mk_MPAM3_EL3_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMHCR_EL2_SysRegWrite_f33f1b3939841d4d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x930#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMHCR_EL2 (Mk_MPAMHCR_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMHCR_EL2 (Mk_MPAMHCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMSM_EL1_SysRegWrite_2a763b1f04834a78 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MPAM2_EL2_EnMPAMSM ← (( do (pure (_get_MPAM2_EL2_Type_EnMPAMSM (← readReg MPAM2_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
              then
                (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((← (EL2Enabled ())) && (__MPAM2_EL2_EnMPAMSM == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg MPAMSM_EL1 (Mk_MPAMSM_EL1_Type (← (X_read t 64))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMSM_EL1 (Mk_MPAMSM_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMSM_EL1 (Mk_MPAMSM_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM0_EL2_SysRegWrite_207148c31e856fe4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x940#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM0_EL2 (Mk_MPAMVPM0_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM0_EL2 (Mk_MPAMVPM0_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM1_EL2_SysRegWrite_b3375ea335a1385f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x948#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM1_EL2 (Mk_MPAMVPM1_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM1_EL2 (Mk_MPAMVPM1_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM2_EL2_SysRegWrite_8d820331d39fc415 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x950#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM2_EL2 (Mk_MPAMVPM2_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM2_EL2 (Mk_MPAMVPM2_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM3_EL2_SysRegWrite_021494dfdc0c0bfb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x958#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM3_EL2 (Mk_MPAMVPM3_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM3_EL2 (Mk_MPAMVPM3_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM4_EL2_SysRegWrite_b24395e23de9de27 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x960#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM4_EL2 (Mk_MPAMVPM4_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM4_EL2 (Mk_MPAMVPM4_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM5_EL2_SysRegWrite_6fb2fa1ed08eede5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x968#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM5_EL2 (Mk_MPAMVPM5_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM5_EL2 (Mk_MPAMVPM5_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM6_EL2_SysRegWrite_f9f217fcedaa8488 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x970#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM6_EL2 (Mk_MPAMVPM6_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM6_EL2 (Mk_MPAMVPM6_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPM7_EL2_SysRegWrite_4cef9a0deb73daae (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x978#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPM7_EL2 (Mk_MPAMVPM7_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPM7_EL2 (Mk_MPAMVPM7_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MPAMVPMV_EL2_SysRegWrite_b8922db9c7895ed5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __MPAM3_EL3_TRAPLOWER ← (( do (pure (_get_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x938#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then
                      (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((HaveEL EL3) && (__MPAM3_EL3_TRAPLOWER == 1#1)) : Bool)
                    then
                      (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                    else (do writeReg MPAMVPMV_EL2 (Mk_MPAMVPMV_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg MPAMVPMV_EL2 (Mk_MPAMVPMV_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def NZCV_SysRegWrite_a24ec14709a57410 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
        writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
              writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
              writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
                    writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
                    writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
                    writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
                    writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
                          writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
                          writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
                          writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
                          writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def OSDLR_EL1_SysRegWrite_3d852917a7f252a5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HDFGWTR_EL2_OSDLR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_OSDLR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDOSA ← (( do (pure (_get_MDCR_EL2_Type_TDOSA (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3)) == 1#1))) <&&> (do
                   (IsFeatureImplemented FEAT_DoubleLock) <||> (do
                     (__IMPDEF_boolean "Trapped by MDCR_EL3.TDOSA"))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (IsFeatureImplemented FEAT_FGT)) <&&> (do
                           (pure (! (HaveEL EL3))) <||> (do
                             (pure ((_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3)) == 1#1)))) <&&> (do
                           (IsFeatureImplemented FEAT_DoubleLock)))) && (__HDFGWTR_EL2_OSDLR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDOSA (← readReg MDCR_EL2))) != 0b00#2))) <&&> (do
                               (IsFeatureImplemented FEAT_DoubleLock) <||> (do
                                 (__IMPDEF_boolean "Trapped by MDCR_EL2.TDOSA"))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure ((_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3)) == 1#1))) <&&> (do
                                     (IsFeatureImplemented FEAT_DoubleLock) <||> (do
                                       (__IMPDEF_boolean "Trapped by MDCR_EL3.TDOSA"))))) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg OSDLR_EL1 (Mk_OSDLR_EL1_Type (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3)) == 1#1))) <&&> (do
                         (IsFeatureImplemented FEAT_DoubleLock) <||> (do
                           (__IMPDEF_boolean "Trapped by MDCR_EL3.TDOSA"))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure (HaveEL EL3)) <&&> (do
                               (pure ((_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3)) == 1#1))) <&&> (do
                               (IsFeatureImplemented FEAT_DoubleLock) <||> (do
                                 (__IMPDEF_boolean "Trapped by MDCR_EL3.TDOSA"))))) : Bool)
                          then
                            (do (if ((←((Halted ()) <&&> (do
                                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg OSDLR_EL1 (Mk_OSDLR_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg OSDLR_EL1 (Mk_OSDLR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def OSDTRRX_EL1_SysRegWrite_8dcacb00f53cccfe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDCC ← (( do (pure (_get_MDCR_EL3_Type_TDCC (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDCC ← (( do (pure (_get_MDCR_EL2_Type_TDCC (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((Halted ()) <&&> (do
             (ConstrainUnpredictableBool Unpredictable_IGNORETRAPINDEBUG)))) : Bool)
        then (do writeReg OSDTRRX_EL1 (← (X_read t 64)))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                                  then
                                                    (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else (do writeReg OSDTRRX_EL1 (← (X_read t 64)))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg OSDTRRX_EL1 (← (X_read t 64)))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg OSDTRRX_EL1 (← (X_read t 64)))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def OSDTRTX_EL1_SysRegWrite_a6594f8c79e7c726 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDCC ← (( do (pure (_get_MDCR_EL3_Type_TDCC (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TDCC ← (( do (pure (_get_MDCR_EL2_Type_TDCC (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((Halted ()) <&&> (do
             (ConstrainUnpredictableBool Unpredictable_IGNORETRAPINDEBUG)))) : Bool)
        then (do writeReg OSDTRTX_EL1 (← (X_read t 64)))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TDCC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                                  then
                                                    (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else (do writeReg OSDTRTX_EL1 (← (X_read t 64)))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDCC == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg OSDTRTX_EL1 (← (X_read t 64)))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg OSDTRTX_EL1 (← (X_read t 64)))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def OSECCR_EL1_SysRegWrite_e6c17a3df51100b5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_OSECCR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_OSECCR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __OSLSR_EL1_OSLK ← (( do (pure (_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_OSECCR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((__OSLSR_EL1_OSLK == 0#1) : Bool)
                                      then (do (pure ()))
                                      else (do writeReg OSECCR_EL1 (Mk_OSECCR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__OSLSR_EL1_OSLK == 0#1) : Bool)
                                then (do (pure ()))
                                else (do writeReg OSECCR_EL1 (Mk_OSECCR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__OSLSR_EL1_OSLK == 0#1) : Bool)
                          then (do (pure ()))
                          else (do writeReg OSECCR_EL1 (Mk_OSECCR_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def OSLAR_EL1_SysRegWrite_749a6107662da2a0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDOSA ← (( do (pure (_get_MDCR_EL3_Type_TDOSA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_OSLAR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_OSLAR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_OSLAR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDOSA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg OSLAR_EL1 (Mk_OSLAR_EL1_Type (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TDOSA == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg OSLAR_EL1 (Mk_OSLAR_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg OSLAR_EL1 (Mk_OSLAR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PAN_SysRegWrite_2264c0f921011765 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with PAN := (← do (pure ((BitVec.access (← (X_read t 64)) 22) : BitVec 1))) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with PAN := (← do (pure ((BitVec.access (← (X_read t 64)) 22) : BitVec 1))) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with PAN := (← do (pure ((BitVec.access (← (X_read t 64)) 22) : BitVec 1))) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PAR_EL1_SysRegWrite_0aa8c34fdfcc39e2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_PAR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_PAR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_PAR_EL1 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (PAR_EL1_write (Mk_PAR_EL1_Type (Sail.BitVec.updateSubrange (← (PAR_EL1_read ())) 63 0 (← (X_read t 64))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (PAR_EL1_write (Mk_PAR_EL1_Type (Sail.BitVec.updateSubrange (← (PAR_EL1_read ())) 63 0 (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (PAR_EL1_write (Mk_PAR_EL1_Type (Sail.BitVec.updateSubrange (← (PAR_EL1_read ())) 63 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PFAR_EL1_SysRegWrite_8a0314eb99395480 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x2D0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg PFAR_EL1 (Mk_PFAR_EL1_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg PFAR_EL1 (Mk_PFAR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PFAR_EL1_SysRegWrite_c90f2cb9855a6dbf (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR2_EL2_nPFAR_EL1 ← (( do (pure (_get_HFGWTR2_EL2_Type_nPFAR_EL1 (← readReg HFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (IsFeatureImplemented FEAT_FGT2)))) && (__HFGWTR2_EL2_nPFAR_EL1 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x2D0#12) (← (X_read t 64))))
                          else (do writeReg PFAR_EL1 (Mk_PFAR_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg PFAR_EL2 (Mk_PFAR_EL2_Type (← (X_read t 64))))
                    else (do writeReg PFAR_EL1 (Mk_PFAR_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PFAR_EL1 (Mk_PFAR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PFAR_EL2_SysRegWrite_eb19d14238ffe508 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PFAR_EL2 (Mk_PFAR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PFAR_EL2 (Mk_PFAR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PIRE0_EL1_SysRegWrite_40d0f1452720482a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_PIEn ← (( do (pure (_get_SCR_EL3_Type_PIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x290#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg PIRE0_EL1 (Mk_PIRE0_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg PIRE0_EL1 (Mk_PIRE0_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PIRE0_EL2_SysRegWrite_13593dc3e37a5186 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_PIEn ← (( do (pure (_get_SCR_EL3_Type_PIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x298#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PIRE0_EL2 (Mk_PIRE0_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PIRE0_EL2 (Mk_PIRE0_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PIRE0_EL2_SysRegWrite_8aee2c676081a490 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_PIEn ← (( do (pure (_get_SCR_EL3_Type_PIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nPIRE0_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nPIRE0_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nPIRE0_EL1 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x290#12) (← (X_read t 64))))
                                      else (do writeReg PIRE0_EL1 (Mk_PIRE0_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg PIRE0_EL2 (Mk_PIRE0_EL2_Type (← (X_read t 64))))
                                else (do writeReg PIRE0_EL1 (Mk_PIRE0_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PIRE0_EL1 (Mk_PIRE0_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PIR_EL1_SysRegWrite_1431f0a180293b57 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_PIEn ← (( do (pure (_get_SCR_EL3_Type_PIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nPIR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nPIR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nPIR_EL1 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x2A0#12) (← (X_read t 64))))
                                      else (do writeReg PIR_EL1 (Mk_PIR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg PIR_EL2 (Mk_PIR_EL2_Type (← (X_read t 64))))
                                else (do writeReg PIR_EL1 (Mk_PIR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PIR_EL1 (Mk_PIR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PIR_EL1_SysRegWrite_da3aa8710c2ede05 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_PIEn ← (( do (pure (_get_SCR_EL3_Type_PIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x2A0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_PIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg PIR_EL1 (Mk_PIR_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg PIR_EL1 (Mk_PIR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))


end ArmASL.Functions
