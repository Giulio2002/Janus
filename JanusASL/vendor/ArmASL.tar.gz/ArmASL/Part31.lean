import ArmASL.Part30

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_umov_advsimd_aarch64_instrs_vector_transfer_integer_move_unsigned (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size : Int := 0
  let size ← (( do
    let b__0 := (Q +++ imm5)
    (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
    then (do (pure 0))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
          then (do (pure 1))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 2 0) == (0b100#3 : (BitVec 3)))) : Bool)
                then (do (pure 2))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 3 0) == (0x8#4 : (BitVec 4)))) : Bool)
                      then (do (pure 3))
                      else (do sailThrow ((Error_Undefined ())))))))))) ) : SailM Int )
  let size := size
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let esize := (Int.shiftl 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 64
    else 32
  (execute_aarch64_instrs_vector_transfer_integer_move_unsigned d datasize esize idxdsize index n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_recip_int (d : Nat) (datasize : Nat) (elements : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e 32)
        let result ← (Elem_set result e 32 (← (UnsignedRecipEstimate element)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_urecpe_advsimd_aarch64_instrs_vector_arithmetic_unary_special_recip_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_recip_int d datasize elements n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int (d : Nat) (datasize : Nat) (elements : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e 32)
        let result ← (Elem_set result e 32 (← (UnsignedRSqrtEstimate element)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_ursqrte_advsimd_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_int d datasize elements n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem elements [2, 4] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mat_mul_int_usdot (d : Nat) (datasize : Nat) (elements : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let res ← (( do (Elem_read operand3 e 32) ) : SailM (BitVec 32) )
        let res ← (( do
          let loop_b_lower := 0
          let loop_b_upper := 3
          let mut loop_vars_1 := res
          for b in [loop_b_lower:loop_b_upper:1]i do
            let res := loop_vars_1
            loop_vars_1 ← do
              let element1 ← (( do (pure (BitVec.toNat (← (Elem_read operand1 ((4 *i e) +i b) 8)))) ) : SailM Int )
              let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 ((4 *i e) +i b) 8)))) ) : SailM Int )
              (pure (BitVec.addInt res (element1 *i element2)))
          (pure loop_vars_1) ) : SailM (BitVec 32) )
        (Elem_set result e 32 res)
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_usdot_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mat_mul_int_usdot (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (← (HaveInt8MatMulExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 32)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mat_mul_int_usdot d datasize elements m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_unzip (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operandl ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operandh ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let zipped : (BitVec (datasize * 2)) := (operandh +++ operandl)
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize (← (Elem_read zipped ((2 *i e) +i part) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_uzp1_advsimd_aarch64_instrs_vector_transfer_vector_permute_unzip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  (execute_aarch64_instrs_vector_transfer_vector_permute_unzip d datasize elements esize m n part)

def decode_uzp2_advsimd_aarch64_instrs_vector_transfer_vector_permute_unzip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  (execute_aarch64_instrs_vector_transfer_vector_permute_unzip d datasize elements esize m n part)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3_xar (d : Nat) (imm6 : (BitVec 6)) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vm ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let Vn ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let tmp : (BitVec 128) := (Vn ^^^ Vm)
  (V_set d 128 ((ROR (Sail.BitVec.extractLsb tmp 127 64) (BitVec.toNat imm6)) +++ (ROR (Sail.BitVec.extractLsb tmp 63 0) (BitVec.toNat imm6))))

def decode_xar_advsimd_aarch64_instrs_vector_crypto_sha3_xar (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA3Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha3_xar d imm6 m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_nosat (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let result ← (Elem_set result e esize (Sail.BitVec.extractLsb element (esize -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize)) )
  (Vpart_set d part datasize result)

def decode_xtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_nosat (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_nosat d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, m : Nat, n : Nat, pairs : Int, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_permute_zip (d : Nat) (datasize : Nat) (esize : Nat) (m : Nat) (n : Nat) (pairs : Int) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let base := (part *i pairs)
  let result ← (( do
    let loop_p_lower := 0
    let loop_p_upper := (pairs -i 1)
    let mut loop_vars := result
    for p in [loop_p_lower:loop_p_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        let result ← (Elem_set result ((2 *i p) +i 0) esize (← (Elem_read operand1 (base +i p) esize)))
        (Elem_set result ((2 *i p) +i 1) esize (← (Elem_read operand2 (base +i p) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)

def decode_zip1_advsimd_aarch64_instrs_vector_transfer_vector_permute_zip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_zip d datasize esize m n pairs part)

def decode_zip2_advsimd_aarch64_instrs_vector_transfer_vector_permute_zip (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let part := (BitVec.toNat op)
  let pairs := (Int.ediv elements 2)
  (execute_aarch64_instrs_vector_transfer_vector_permute_zip d datasize esize m n pairs part)

/-- Type quantifiers: pc : Int -/
def __DecodeA64_Reserved (pc : Int) (__opcode : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((Sail.BitVec.extractLsb __opcode 31 16) == (0x0000#16 : (BitVec 16)))) <&&> (do
       (pure ((← readReg SEE) <b 1017))))) : Bool)
  then
    (do writeReg SEE 1017
        let imm16 := (BitVec.slice __opcode 0 16)
        (decode_udf_perm_undef_aarch64_instrs_udf imm16))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_SME (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_SME"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_Unallocated1 (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_Unallocated1"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_SVE (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_SVE"))

/-- Type quantifiers: x_0 : Int -/
def __DecodeA64_Unallocated2 (x_0 : Int) (x_1 : (BitVec 32)) : SailM Unit := do
  sailThrow ((Error_ImplementationDefined "janus-excluded __DecodeA64_Unallocated2"))

/-- Type quantifiers: pc : Int -/
def __DecodeA64_DataProcImm (pc : Int) (__opcode : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x22#8 : (BitVec 8)))) <&&> (do
       (pure ((← readReg SEE) <b 18))))) : Bool)
  then
    (do writeReg SEE 18
        let Rd := (BitVec.slice __opcode 0 5)
        let Rn := (BitVec.slice __opcode 5 5)
        let imm12 := (BitVec.slice __opcode 10 12)
        let sh := (BitVec.slice __opcode 22 1)
        let S := (BitVec.slice __opcode 29 1)
        let op := (BitVec.slice __opcode 30 1)
        let sf := (BitVec.slice __opcode 31 1)
        (decode_add_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
  else
    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x62#8 : (BitVec 8)))) <&&> (do
             (pure ((← readReg SEE) <b 19))))) : Bool)
        then
          (do writeReg SEE 19
              let Rd := (BitVec.slice __opcode 0 5)
              let Rn := (BitVec.slice __opcode 5 5)
              let imm12 := (BitVec.slice __opcode 10 12)
              let sh := (BitVec.slice __opcode 22 1)
              let S := (BitVec.slice __opcode 29 1)
              let op := (BitVec.slice __opcode 30 1)
              let sf := (BitVec.slice __opcode 31 1)
              (decode_adds_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
        else
          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA2#8 : (BitVec 8)))) <&&> (do
                   (pure ((← readReg SEE) <b 20))))) : Bool)
              then
                (do writeReg SEE 20
                    let Rd := (BitVec.slice __opcode 0 5)
                    let Rn := (BitVec.slice __opcode 5 5)
                    let imm12 := (BitVec.slice __opcode 10 12)
                    let sh := (BitVec.slice __opcode 22 1)
                    let S := (BitVec.slice __opcode 29 1)
                    let op := (BitVec.slice __opcode 30 1)
                    let sf := (BitVec.slice __opcode 31 1)
                    (decode_sub_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
              else
                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE2#8 : (BitVec 8)))) <&&> (do
                         (pure ((← readReg SEE) <b 21))))) : Bool)
                    then
                      (do writeReg SEE 21
                          let Rd := (BitVec.slice __opcode 0 5)
                          let Rn := (BitVec.slice __opcode 5 5)
                          let imm12 := (BitVec.slice __opcode 10 12)
                          let sh := (BitVec.slice __opcode 22 1)
                          let S := (BitVec.slice __opcode 29 1)
                          let op := (BitVec.slice __opcode 30 1)
                          let sf := (BitVec.slice __opcode 31 1)
                          (decode_subs_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate Rd Rn imm12 sh S op sf))
                    else
                      (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 22) == (0b1001000110#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb __opcode 15 14) == (0b00#2 : (BitVec 2))))) <&&> (do
                               (pure ((← readReg SEE) <b 26))))) : Bool)
                          then
                            (do writeReg SEE 26
                                sailThrow ((Error_ImplementationDefined "janus-excluded decode_addg_aarch64_instrs_integer_tags_mcaddtag")))
                          else
                            (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 31) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb __opcode 28 24) == (0b10000#5 : (BitVec 5))))) <&&> (do
                                     (pure ((← readReg SEE) <b 34))))) : Bool)
                                then
                                  (do writeReg SEE 34
                                      let Rd := (BitVec.slice __opcode 0 5)
                                      let immhi := (BitVec.slice __opcode 5 19)
                                      let immlo := (BitVec.slice __opcode 29 2)
                                      let op := (BitVec.slice __opcode 31 1)
                                      (decode_adr_aarch64_instrs_integer_arithmetic_address_pc_rel Rd immhi immlo op))
                                else
                                  (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 31) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb __opcode 28 24) == (0b10000#5 : (BitVec 5))))) <&&> (do
                                           (pure ((← readReg SEE) <b 35))))) : Bool)
                                      then
                                        (do writeReg SEE 35
                                            let Rd := (BitVec.slice __opcode 0 5)
                                            let immhi := (BitVec.slice __opcode 5 19)
                                            let immlo := (BitVec.slice __opcode 29 2)
                                            let op := (BitVec.slice __opcode 31 1)
                                            (decode_adrp_aarch64_instrs_integer_arithmetic_address_pc_rel Rd immhi immlo op))
                                      else
                                        (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x24#8 : (BitVec 8)))) <&&> (do
                                                 (pure ((← readReg SEE) <b 40))))) : Bool)
                                            then
                                              (do writeReg SEE 40
                                                  let Rd := (BitVec.slice __opcode 0 5)
                                                  let Rn := (BitVec.slice __opcode 5 5)
                                                  let imms := (BitVec.slice __opcode 10 6)
                                                  let immr := (BitVec.slice __opcode 16 6)
                                                  let N := (BitVec.slice __opcode 22 1)
                                                  let opc := (BitVec.slice __opcode 29 2)
                                                  let sf := (BitVec.slice __opcode 31 1)
                                                  (decode_and_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                            else
                                              (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE4#8 : (BitVec 8)))) <&&> (do
                                                       (pure ((← readReg SEE) <b 41))))) : Bool)
                                                  then
                                                    (do writeReg SEE 41
                                                        let Rd := (BitVec.slice __opcode 0 5)
                                                        let Rn := (BitVec.slice __opcode 5 5)
                                                        let imms := (BitVec.slice __opcode 10 6)
                                                        let immr := (BitVec.slice __opcode 16 6)
                                                        let N := (BitVec.slice __opcode 22 1)
                                                        let opc := (BitVec.slice __opcode 29 2)
                                                        let sf := (BitVec.slice __opcode 31 1)
                                                        (decode_ands_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                  else
                                                    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA4#8 : (BitVec 8)))) <&&> (do
                                                             (pure ((← readReg SEE) <b 42))))) : Bool)
                                                        then
                                                          (do writeReg SEE 42
                                                              let Rd := (BitVec.slice __opcode 0 5)
                                                              let Rn := (BitVec.slice __opcode 5 5)
                                                              let imms := (BitVec.slice __opcode 10 6)
                                                              let immr := (BitVec.slice __opcode 16 6)
                                                              let N := (BitVec.slice __opcode 22 1)
                                                              let opc := (BitVec.slice __opcode 29 2)
                                                              let sf := (BitVec.slice __opcode 31 1)
                                                              (decode_eor_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                        else
                                                          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x64#8 : (BitVec 8)))) <&&> (do
                                                                   (pure ((← readReg SEE) <b 43))))) : Bool)
                                                              then
                                                                (do writeReg SEE 43
                                                                    let Rd := (BitVec.slice __opcode 0 5)
                                                                    let Rn := (BitVec.slice __opcode 5 5)
                                                                    let imms := (BitVec.slice __opcode 10 6)
                                                                    let immr := (BitVec.slice __opcode 16 6)
                                                                    let N := (BitVec.slice __opcode 22 1)
                                                                    let opc := (BitVec.slice __opcode 29 2)
                                                                    let sf := (BitVec.slice __opcode 31 1)
                                                                    (decode_orr_log_imm_aarch64_instrs_integer_logical_immediate Rd Rn imms immr N opc sf))
                                                              else
                                                                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x66#8 : (BitVec 8)))) <&&> (do
                                                                         (pure ((← readReg SEE) <b 76))))) : Bool)
                                                                    then
                                                                      (do writeReg SEE 76
                                                                          let Rd := (BitVec.slice __opcode 0 5)
                                                                          let Rn := (BitVec.slice __opcode 5 5)
                                                                          let imms := (BitVec.slice __opcode 10 6)
                                                                          let immr := (BitVec.slice __opcode 16 6)
                                                                          let N := (BitVec.slice __opcode 22 1)
                                                                          let opc := (BitVec.slice __opcode 29 2)
                                                                          let sf := (BitVec.slice __opcode 31 1)
                                                                          (decode_bfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                    else
                                                                      (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x26#8 : (BitVec 8)))) <&&> (do
                                                                               (pure ((← readReg SEE) <b 77))))) : Bool)
                                                                          then
                                                                            (do writeReg SEE 77
                                                                                let Rd := (BitVec.slice __opcode 0 5)
                                                                                let Rn := (BitVec.slice __opcode 5 5)
                                                                                let imms := (BitVec.slice __opcode 10 6)
                                                                                let immr := (BitVec.slice __opcode 16 6)
                                                                                let N := (BitVec.slice __opcode 22 1)
                                                                                let opc := (BitVec.slice __opcode 29 2)
                                                                                let sf := (BitVec.slice __opcode 31 1)
                                                                                (decode_sbfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                          else
                                                                            (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA6#8 : (BitVec 8)))) <&&> (do
                                                                                     (pure ((← readReg SEE) <b 78))))) : Bool)
                                                                                then
                                                                                  (do writeReg SEE 78
                                                                                      let Rd := (BitVec.slice __opcode 0 5)
                                                                                      let Rn := (BitVec.slice __opcode 5 5)
                                                                                      let imms := (BitVec.slice __opcode 10 6)
                                                                                      let immr := (BitVec.slice __opcode 16 6)
                                                                                      let N := (BitVec.slice __opcode 22 1)
                                                                                      let opc := (BitVec.slice __opcode 29 2)
                                                                                      let sf := (BitVec.slice __opcode 31 1)
                                                                                      (decode_ubfm_aarch64_instrs_integer_bitfield Rd Rn imms immr N opc sf))
                                                                                else
                                                                                  (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 30 23) == (0x27#8 : (BitVec 8))) && ((Sail.BitVec.extractLsb __opcode 21 21) == (0#1 : (BitVec 1))))) <&&> (do
                                                                                           (pure ((← readReg SEE) <b 206))))) : Bool)
                                                                                      then
                                                                                        (do writeReg SEE 206
                                                                                            let Rd := (BitVec.slice __opcode 0 5)
                                                                                            let Rn := (BitVec.slice __opcode 5 5)
                                                                                            let imms := (BitVec.slice __opcode 10 6)
                                                                                            let Rm := (BitVec.slice __opcode 16 5)
                                                                                            let N := (BitVec.slice __opcode 22 1)
                                                                                            let sf := (BitVec.slice __opcode 31 1)
                                                                                            (decode_extr_aarch64_instrs_integer_ins_ext_extract_immediate Rd Rn imms Rm N sf))
                                                                                      else
                                                                                        (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xE5#8 : (BitVec 8)))) <&&> (do
                                                                                                 (pure ((← readReg SEE) <b 696))))) : Bool)
                                                                                            then
                                                                                              (do writeReg SEE 696
                                                                                                  let Rd := (BitVec.slice __opcode 0 5)
                                                                                                  let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                  let hw := (BitVec.slice __opcode 21 2)
                                                                                                  let opc := (BitVec.slice __opcode 29 2)
                                                                                                  let sf := (BitVec.slice __opcode 31 1)
                                                                                                  (decode_movk_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                            else
                                                                                              (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0x25#8 : (BitVec 8)))) <&&> (do
                                                                                                       (pure ((← readReg SEE) <b 697))))) : Bool)
                                                                                                  then
                                                                                                    (do writeReg SEE 697
                                                                                                        let Rd := (BitVec.slice __opcode 0 5)
                                                                                                        let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                        let hw := (BitVec.slice __opcode 21 2)
                                                                                                        let opc := (BitVec.slice __opcode 29 2)
                                                                                                        let sf := (BitVec.slice __opcode 31 1)
                                                                                                        (decode_movn_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                                  else
                                                                                                    (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 23) == (0xA5#8 : (BitVec 8)))) <&&> (do
                                                                                                             (pure ((← readReg SEE) <b 698))))) : Bool)
                                                                                                        then
                                                                                                          (do writeReg SEE 698
                                                                                                              let Rd := (BitVec.slice __opcode 0 5)
                                                                                                              let imm16 := (BitVec.slice __opcode 5 16)
                                                                                                              let hw := (BitVec.slice __opcode 21 2)
                                                                                                              let opc := (BitVec.slice __opcode 29 2)
                                                                                                              let sf := (BitVec.slice __opcode 31 1)
                                                                                                              (decode_movz_aarch64_instrs_integer_ins_ext_insert_movewide Rd imm16 hw opc sf))
                                                                                                        else
                                                                                                          (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110000#13 : (BitVec 13)))) <&&> (do
                                                                                                                   (pure ((← readReg SEE) <b 832))))) : Bool)
                                                                                                              then
                                                                                                                (do writeReg SEE 832
                                                                                                                    sailThrow ((Error_ImplementationDefined "janus-excluded decode_smax_imm_aarch64_instrs_integer_arithmetic_max_min_smax_imm")))
                                                                                                              else
                                                                                                                (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110010#13 : (BitVec 13)))) <&&> (do
                                                                                                                         (pure ((← readReg SEE) <b 847))))) : Bool)
                                                                                                                    then
                                                                                                                      (do writeReg SEE 847
                                                                                                                          sailThrow ((Error_ImplementationDefined "janus-excluded decode_smin_imm_aarch64_instrs_integer_arithmetic_max_min_smin_imm")))
                                                                                                                    else
                                                                                                                      (do (if ((←((pure (((Sail.BitVec.extractLsb __opcode 31 22) == (0b1101000110#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb __opcode 15 14) == (0b00#2 : (BitVec 2))))) <&&> (do
                                                                                                                               (pure ((← readReg SEE) <b 990))))) : Bool)
                                                                                                                          then
                                                                                                                            (do writeReg SEE 990
                                                                                                                                sailThrow ((Error_ImplementationDefined "janus-excluded decode_subg_aarch64_instrs_integer_tags_mcsubtag")))
                                                                                                                          else
                                                                                                                            (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110001#13 : (BitVec 13)))) <&&> (do
                                                                                                                                     (pure ((← readReg SEE) <b 1018))))) : Bool)
                                                                                                                                then
                                                                                                                                  (do writeReg SEE 1018
                                                                                                                                      sailThrow ((Error_ImplementationDefined "janus-excluded decode_umax_imm_aarch64_instrs_integer_arithmetic_max_min_umax_imm")))
                                                                                                                                else
                                                                                                                                  (do (if ((←((pure ((Sail.BitVec.extractLsb __opcode 30 18) == (0b0010001110011#13 : (BitVec 13)))) <&&> (do
                                                                                                                                           (pure ((← readReg SEE) <b 1021))))) : Bool)
                                                                                                                                      then
                                                                                                                                        (do writeReg SEE 1021
                                                                                                                                            sailThrow ((Error_ImplementationDefined "janus-excluded decode_umin_imm_aarch64_instrs_integer_arithmetic_max_min_umin_imm")))
                                                                                                                                      else (do sailThrow ((Error_Undefined ()))))))))))))))))))))))))))))))))))))))))))))))))


end ArmASL.Functions
