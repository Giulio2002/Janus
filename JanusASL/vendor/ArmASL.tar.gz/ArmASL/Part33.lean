import ArmASL.Part32

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_2b5e3e8ebfdd2403 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_3d27f26840346448 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_3d2d295e35e201a9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_4603ea69874f5bc4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_50419316a0793567 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_69501ae43204dc12 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_7e2235d697a1476e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_a4da6c90289f656a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_b606553f5e3a24b1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_cb01e2f00db2e33f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_e72797af60944ed4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))
                    else (do (pure ())))))))))


end ArmASL.Functions
