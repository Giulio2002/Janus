import ArmASL.Part38

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def DC_ZVA_SysOpsWrite_4df78ae16ed9b1bc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCTLR_EL1_DZE ← (( do (pure (_get_SCTLR_EL1_Type_DZE (← readReg SCTLR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TDZ ← (( do (pure (_get_HCR_EL2_Type_TDZ (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGITR_EL2_DCZVA ← (( do (pure (_get_HFGITR_EL2_Type_DCZVA (← readReg HFGITR_EL2))) ) : SailM (BitVec 1) )
  let __SCTLR_EL2_DZE ← (( do (pure (_get_SCTLR_EL2_Type_DZE (← readReg SCTLR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__SCTLR_EL1_DZE == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__HCR_EL2_TDZ == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGITR_EL2_DCZVA == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__SCTLR_EL2_DZE == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_MemZero (← (X_read t 64)) CacheType_Data))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TDZ == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGITR_EL2_DCZVA == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_MemZero (← (X_read t 64)) CacheType_Data))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (AArch64_MemZero (← (X_read t 64)) CacheType_Data))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (AArch64_MemZero (← (X_read t 64)) CacheType_Data))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AArch64_AutoGen_SysOpsWrite (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3OS_SysOpsWrite_b1a90c282b7de961")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3OS_SysOpsWrite_1c55c5510bb06701")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1IS_SysOpsWrite_74cf3deb93f9c490")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1IS_SysOpsWrite_210660f1a7d14921")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1_SysOpsWrite_a60433fa9400576b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1_SysOpsWrite_21ea80b02f894ffa")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3_SysOpsWrite_14a8b6cb081a1329")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3_SysOpsWrite_c0f76daa7c4a5790")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E0W_SysOpsWrite_5d5981498f3ff63f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2OS_SysOpsWrite_5e062a952a34f1d1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2OS_SysOpsWrite_9fccdf3bc89cf2de")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1OS_SysOpsWrite_29989c3f4da9352a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1OS_SysOpsWrite_0f5703d12bddab98")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2OS_SysOpsWrite_36a17e51dcbb19d2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2OS_SysOpsWrite_0b11b74e4b3a3cfe")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1OS_SysOpsWrite_f77553e58265d00e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1OS_SysOpsWrite_46e21ce75556305b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1_SysOpsWrite_78a7997e8d77efab")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1_SysOpsWrite_cf8d18b6c0e5014a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1IS_SysOpsWrite_34cdbedbc256d566")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1IS_SysOpsWrite_73eb52c0eda77b8c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1IS_SysOpsWrite_c27f5fb50c845520")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1IS_SysOpsWrite_4976b291164ac150")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E2R_SysOpsWrite_759b68e4499a5900")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1IS_SysOpsWrite_2c882bcfeb863fe7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1IS_SysOpsWrite_2b703b96d2b79219")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1_SysOpsWrite_acd078309ca68103")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1_SysOpsWrite_801459dbccf15998")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S12E1W_SysOpsWrite_1152e7884348cb33")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CFP_RCTX_SysOpsWrite_c7a3d5c0c069ede1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DVP_RCTX_SysOpsWrite_a4d7cddd32aa439c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S12E0R_SysOpsWrite_0c5b1bd4a1d08392")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3_SysOpsWrite_41a4620adcceb248")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3_SysOpsWrite_de8987d56f578140")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E1RP_SysOpsWrite_597c8bbb547c9cc7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CPP_RCTX_SysOpsWrite_40a73711d28892b9")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2IS_SysOpsWrite_ba6a5005f8e50b0a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2IS_SysOpsWrite_b944414311b6f47e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3IS_SysOpsWrite_7257c0dcb24e4a80")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3IS_SysOpsWrite_879fb376d7b6807d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E1R_SysOpsWrite_efb944f010174dbe")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1OS_SysOpsWrite_45c25f2a662eaa2a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1OS_SysOpsWrite_4e52e85810812d01")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CVAC_SysOpsWrite_a3e7839db596aa73")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1IS_SysOpsWrite_9c420b123e788777")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1IS_SysOpsWrite_0978356bc7a2174b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E1W_SysOpsWrite_97fd2fc3596f8e01")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S12E0W_SysOpsWrite_ebaedef9bc851c96")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E0R_SysOpsWrite_40187a824e445931")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIPAPA_SysOpsWrite_bec4067ecaf3ce6b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2OS_SysOpsWrite_46b110246aedd461")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2OS_SysOpsWrite_0ebf53e3aa0f8f7f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1OS_SysOpsWrite_c9ef60d478317354")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1OS_SysOpsWrite_b1f4b958ef6b7447")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1_SysOpsWrite_97895c8e9b4d80f7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1_SysOpsWrite_b3136916ac77cb10")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1IS_SysOpsWrite_7f8b016dbe13814c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1IS_SysOpsWrite_f517d8205e0bc7df")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1_SysOpsWrite_cc74fa175b762bc3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1_SysOpsWrite_21535728b556e5b1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSSS1_SysOpsWrite_5eb47650d9a586f4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_ISW_SysOpsWrite_d415f7441de61c87")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1OS_SysOpsWrite_98a393eb5d247245")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE1OS_SysOpsWrite_ea84e7b4286ea314")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2_SysOpsWrite_b0982ca76d6c7651")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2_SysOpsWrite_ae783e9b4ab84ab2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1OS_SysOpsWrite_c650faaab3ae9387")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1OS_SysOpsWrite_5c902fb0e3a0ba5e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1IS_SysOpsWrite_9d56cb10a3da298e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1IS_SysOpsWrite_48fbca66415d71e4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded COSP_RCTX_SysOpsWrite_575f6b74afb13f3b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2_SysOpsWrite_2fb1c62ae3ec4f94")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2_SysOpsWrite_2a4e0248c72159b4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1_SysOpsWrite_a96cfc69a6f87bef")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAALE1_SysOpsWrite_51c1b09ad1bac112")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1_SysOpsWrite_30eaded0ddf7ab9d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1_SysOpsWrite_cdcaa8b8b8d87463")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2IS_SysOpsWrite_16afb405c0e2ea02")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE2IS_SysOpsWrite_f9126da69ce69c19")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1_SysOpsWrite_ab1d44d851006a7d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE1_SysOpsWrite_df0eae7799136807")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E3W_SysOpsWrite_6d38ab8c7cb15a2d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1OS_SysOpsWrite_309d90a600b530a7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1OS_SysOpsWrite_39b2c10069047b39")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CVADP_SysOpsWrite_2fe8e7b346963113")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1IS_SysOpsWrite_32a7dfc802182d9a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1IS_SysOpsWrite_5a66384446cc9c01")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E2W_SysOpsWrite_f45a5d407163b4bd")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGDPAPA_SysOpsWrite_04c6858387bf2414")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E3R_SysOpsWrite_260837ba334806bd")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIPAE_SysOpsWrite_ab72a0dcf6c65302")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2_SysOpsWrite_23241f5754371907")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2_SysOpsWrite_ab883e6d7c8e2e48")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1OS_SysOpsWrite_41165e80f36dc5fa")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2LE1OS_SysOpsWrite_f065e8faf0d6b28c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1_SysOpsWrite_2fa40a87479f02d6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1_SysOpsWrite_155f359039903b2f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1_SysOpsWrite_57dbaa0ff0b8fdce")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1_SysOpsWrite_2add4c21d48f4ea4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1IS_SysOpsWrite_12cfd4d0d4a6c225")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE1IS_SysOpsWrite_9c213afe5c766789")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CISW_SysOpsWrite_b065e0cdcdd8276d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3OS_SysOpsWrite_af6269968bb4ec2c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3OS_SysOpsWrite_767bde9c297cce04")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIVAC_SysOpsWrite_aa1291714e4724c8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1OS_SysOpsWrite_ed6e64c76758f7a2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1OS_SysOpsWrite_2c91dee891ab3686")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPUSHM_SysOpsWrite_7d31b427953fb1be")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1OS_SysOpsWrite_e3ba04498a146810")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAALE1OS_SysOpsWrite_a50e7acf9414f0e5")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1_SysOpsWrite_1f3af7628a95cec3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2E1_SysOpsWrite_49a01b03635148d3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3IS_SysOpsWrite_e7bda4e5b52e0dd2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3IS_SysOpsWrite_61186878beebdd00")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1_SysOpsWrite_643a317b5666a6f1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1_SysOpsWrite_360bee3e5adad3b9")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1IS_SysOpsWrite_1ddd15964002c062")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAAE1IS_SysOpsWrite_18faceee87b47845")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2IS_SysOpsWrite_b0e15fe998e26a14")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE2IS_SysOpsWrite_854ef2fc0be4152d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CVAP_SysOpsWrite_6979d303ac43aa55")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3OS_SysOpsWrite_51cc3eac56f81d7f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3OS_SysOpsWrite_b68e938dbaed6553")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do (DC_ZVA_SysOpsWrite_4df78ae16ed9b1bc el op0 op1 CRn op2 CRm t))
  else
    (do (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S12E1R_SysOpsWrite_90c7bc3b4c4e8ad2")))
        else (do (pure ())))
        (if ((((((CRm == 0b1001#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AT_S1E1WP_SysOpsWrite_56bf9c5f4fdf95fa")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3IS_SysOpsWrite_dae432255a8b0524")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3IS_SysOpsWrite_4c94c8515b6e4dd8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1IS_SysOpsWrite_b0e95e7b2139780d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1IS_SysOpsWrite_c037245209e28a04")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded IC_IVAU_SysOpsWrite_f40d5c6453a840a5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3IS_SysOpsWrite_067b7469c1e1bb6d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE3IS_SysOpsWrite_26beb941bc870811")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CSW_SysOpsWrite_5e3c21c77aa230fd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_IVAC_SysOpsWrite_9a59a62370daa1c9")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3OS_SysOpsWrite_bdb9e7fcdda16e82")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE3OS_SysOpsWrite_ac643f4910daad7d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RPALOS_SysOpsWrite_a11d11817d32a6eb")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3_SysOpsWrite_9115183869722fc4")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVAE3_SysOpsWrite_aa377993d94b4c2a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2OS_SysOpsWrite_f8b097ac65738708")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE2OS_SysOpsWrite_6f840e706adb25b2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1OS_SysOpsWrite_c65f7d2b6a47a2f3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAAE1OS_SysOpsWrite_e3dbcbfec1559aff")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1_SysOpsWrite_06d13305aa0971fa")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1_SysOpsWrite_43318f45323f6d95")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2_SysOpsWrite_be8d66432234a830")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2_SysOpsWrite_a051bc1bccde7cd9")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGDPAE_SysOpsWrite_8bfd8283adbf50a4")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RPAOS_SysOpsWrite_a15697b49d6ed58f")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2IS_SysOpsWrite_c832bf01bcbc2cc0")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RVALE2IS_SysOpsWrite_ca640565cc2dea92")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3_SysOpsWrite_6432751b5694bad8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VALE3_SysOpsWrite_eb6afd5e3f195389")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1IS_SysOpsWrite_3a685bcc71f41a1f")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ASIDE1IS_SysOpsWrite_15d557e1f93ce504")))
        else (do (pure ())))
        (if ((((((CRm == 0b1011#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CVAU_SysOpsWrite_994be56e554e4f7c")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1OS_SysOpsWrite_54085ab636364748")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_RIPAS2LE1OS_SysOpsWrite_d4ca3cdc19ea21bb")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1OS_SysOpsWrite_8c67238bf7f814e9")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VAE1OS_SysOpsWrite_7d3a74604ad2dbdf")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1IS_SysOpsWrite_ccc65f430a044914")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_IPAS2E1IS_SysOpsWrite_4c58dae59e564c5f")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGVAC_SysOpsWrite_c31db9a0c232aa17")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGDSW_SysOpsWrite_b520ae0cd5c0ff01")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGDVAC_SysOpsWrite_2ef9f271e7e2809f")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGDVADP_SysOpsWrite_8e52ffae1d90dad3")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGDVAC_SysOpsWrite_ec22b0e1f02114c3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_IGVAC_SysOpsWrite_79e5a655957681f5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_GVA_SysOpsWrite_26c60f1734aa9835")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGDVAP_SysOpsWrite_341059a5c0ebf49f")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGSW_SysOpsWrite_72fc6e114637ba18")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGSW_SysOpsWrite_1f93959761278ed4")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CIGVAC_SysOpsWrite_8404661bd642a412")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_IGDSW_SysOpsWrite_ad0a1d536c426f1f")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGVADP_SysOpsWrite_6e93030bf0a27352")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGDSW_SysOpsWrite_928589dc16baf135")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_CGVAP_SysOpsWrite_884677eb0934135e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_GZVA_SysOpsWrite_6a4bc458b38a36cd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_IGSW_SysOpsWrite_b40e0b982eab4603")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DC_IGDVAC_SysOpsWrite_2b2dc8b1efa4218a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2IS_SysOpsWrite_710719471e64d3ba")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2IS_SysOpsWrite_8a96112ff6953240")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_PAALL_SysOpsWrite_30c81768c02bd90b")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRB_IALL_SysOpsWrite_dd273770082db6a6")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3_SysOpsWrite_f67a5db4b11c6ca5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3_SysOpsWrite_154b769b60a9a83a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1IS_SysOpsWrite_8653d883f8306258")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1IS_SysOpsWrite_b92e6f7b045bcd26")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2_SysOpsWrite_e9f6ac4ef52598b3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2_SysOpsWrite_6a07d2a37a89d31f")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPOPX_SysOpsWrite_f5624b6324bc7c49")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1IS_SysOpsWrite_549e403ce92161b6")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1IS_SysOpsWrite_03d7588893774850")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPOPCX_SysOpsWrite_8b33b35a7177cc05")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1OS_SysOpsWrite_1c9b124b11d1cf42")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1OS_SysOpsWrite_98d1faaee38ba3a7")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1OS_SysOpsWrite_71ae489ebaf642d0")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1OS_SysOpsWrite_9b7b764d81828e24")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1_SysOpsWrite_b217b426d8c641ae")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1_SysOpsWrite_23dd50d9423d8d4d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2OS_SysOpsWrite_b46584bc29297df9")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE2OS_SysOpsWrite_1134fdc29a86072a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1_SysOpsWrite_d94c690b16646ffd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLE1_SysOpsWrite_bcd60b78fb7e2b4a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3IS_SysOpsWrite_f68dcd86f3998afd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3IS_SysOpsWrite_95e13b1ef487429e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPUSHX_SysOpsWrite_c023a281d843c45a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1OS_SysOpsWrite_a4cd3a06ce23d819")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE1OS_SysOpsWrite_614f5311238ca5e2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRB_INJ_SysOpsWrite_9a0dba3ea5bd7523")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded IC_IALLUIS_SysOpsWrite_3eb8cc845c2f9444")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1_SysOpsWrite_04d7802e0a5bffbf")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1_SysOpsWrite_252a42c486a42c51")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1IS_SysOpsWrite_3dfe7b46e2ce9676")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_VMALLS12E1IS_SysOpsWrite_94de5730f49bdd76")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_PAALLOS_SysOpsWrite_b02935bd045e4472")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded IC_IALLU_SysOpsWrite_11cf556c15dd6d58")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3OS_SysOpsWrite_7d60d9e9832a86fc")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b01#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TLBI_ALLE3OS_SysOpsWrite_f5180bd2c6904111")))
        else (do (pure ())))
        sailThrow ((Error_ImplementationDefined "janus-excluded AArch64_AutoGen_SysOpsWrite"))))

/-- Type quantifiers: t : Int -/
def GCSPOPM_SysInstrWithResult_785f34ad5cd557fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do (X_set t 64 (← (GCSPOPM ()))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do (X_set t 64 (← (GCSPOPM ()))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (← (GCSPOPM ()))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (← (GCSPOPM ()))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def GCSSS2_SysInstrWithResult_f9ffdfaa333b34bf (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do (X_set t 64 (← (GCSSS2 ()))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do (X_set t 64 (← (GCSSS2 ()))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (← (GCSSS2 ()))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (← (GCSSS2 ()))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AArch64_AutoGen_SysInstrWithResult (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do (GCSSS2_SysInstrWithResult_f9ffdfaa333b34bf el op0 op1 CRn op2 CRm t))
  else
    (do (if ((((((CRm == 0b0111#4) && (CRn == 0b0111#4)) && (op0 == 0b01#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do (GCSPOPM_SysInstrWithResult_785f34ad5cd557fe el op0 op1 CRn op2 CRm t))
        else (do (AArch64_UnallocatedSysRegAccess op0 op1 CRn op2 CRm false t)))))

def getISR (_ : Unit) : SailM (BitVec 32) := do
  let fiq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let fiq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let value_name : (BitVec 32) := (Zeros (n := 32))
  let value_name : (BitVec 32) :=
    (BitVec.update value_name 8
      (Bit
        (if ((IsPhysicalSErrorPending ()) : Bool)
        then 1#1
        else 0#1)))
  let (irq_nmi, irq_pending) ← (( do
    let (tup__0, tup__1) ← do (IRQPending ())
    let irq_pending : Bool := tup__0
    let irq_nmi : Bool := tup__1
    (pure (irq_nmi, irq_pending)) ) : SailM (Bool × Bool) )
  let (fiq_nmi, fiq_pending) : (Bool × Bool) :=
    let (tup__0, tup__1) := ((FIQPending ()) : (Bool × Bool))
    let fiq_pending : Bool := tup__0
    let fiq_nmi : Bool := tup__1
    (fiq_nmi, fiq_pending)
  let value_name ← (( do
    (if ((←((HaveFeatNMI ()) <&&> (do
         (pure (! (← (UsingAArch32 ()))))))) : Bool)
    then
      (do let value_name : (BitVec 32) :=
            (BitVec.update value_name 10
              (Bit
                (if ((irq_pending && irq_nmi) : Bool)
                then 1#1
                else 0#1)))
          (pure (BitVec.update value_name 9
              (Bit
                (if ((fiq_pending && fiq_nmi) : Bool)
                then 1#1
                else 0#1)))))
    else (do (pure value_name))) ) : SailM (BitVec 32) )
  let value_name : (BitVec 32) :=
    (BitVec.update value_name 7
      (Bit
        (if (irq_pending : Bool)
        then 1#1
        else 0#1)))
  let value_name : (BitVec 32) :=
    (BitVec.update value_name 6
      (Bit
        (if (fiq_pending : Bool)
        then 1#1
        else 0#1)))
  (if ((←((pure ((← readReg PSTATE).EL == EL1)) <&&> (do
       (EL2Enabled ())) <&&> (do
       (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
  then
    (do let value_name ← (( do
          (if ((←((HaveFeatNMI ()) <&&> (do
               (pure (! (← (UsingAArch32 ()))))) <&&> (do
               (IsHCRXEL2Enabled ())))) : Bool)
          then
            (do let value_name ← (( do
                  (if ((((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) &&& (_get_HCR_EL2_Type_VI (← readReg HCR_EL2))) == 1#1) : Bool)
                  then (do (pure (BitVec.update value_name 10 (Bit (_get_HCRX_EL2_Type_VINMI (← readReg HCRX_EL2))))))
                  else (do (pure value_name))) ) : SailM (BitVec 32) )
                (if ((((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) &&& (_get_HCR_EL2_Type_VF (← readReg HCR_EL2))) == 1#1) : Bool)
                then (do (pure (BitVec.update value_name 9 (Bit (_get_HCRX_EL2_Type_VFNMI (← readReg HCRX_EL2))))))
                else (do (pure value_name))))
          else (do (pure value_name))) ) : SailM (BitVec 32) )
        let value_name ← (( do
          (if (((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1) : Bool)
          then (do (pure (BitVec.update value_name 8 (Bit (((BitVec.access value_name 8) : BitVec 1) ||| (_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)))))))
          else (do (pure value_name))) ) : SailM (BitVec 32) )
        let value_name ← (( do
          (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
          then (do (pure (BitVec.update value_name 7 (Bit (_get_HCR_EL2_Type_VI (← readReg HCR_EL2))))))
          else (do (pure value_name))) ) : SailM (BitVec 32) )
        (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
        then (do (pure (BitVec.update value_name 6 (Bit (_get_HCR_EL2_Type_VF (← readReg HCR_EL2))))))
        else (do (pure value_name))))
  else (do (pure value_name)))

/-- Type quantifiers: k_isRNDRRS : Bool -/
def genRandomNum (isRNDRRS : Bool) : SailM (BitVec 64) := do
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb 0b0000#4 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb 0b0000#4 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb 0b0000#4 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb 0b0000#4 0 0) }
  let x ← (( do (pure (integer_subrange (← readReg __cycle_count) 127 0)) ) : SailM (BitVec 128) )
  let y ← (( do (pure (integer_subrange ((← readReg __cycle_count) +i 1) 127 0)) ) : SailM (BitVec 128) )
  let w ← (( do (pure (integer_subrange ((← readReg __cycle_count) +i 2) 127 0)) ) : SailM (BitVec 128) )
  (pure (Sail.BitVec.extractLsb (← (SHA256hash x y w true)) 63 0))

/-- Type quantifiers: k_data_cache : Bool, level : Int -/
def getCacheID (level : Int) (data_cache : Bool) : SailM (BitVec 64) := do
  let range_min := (level *i 3)
  let cache_type ← (( do (pure (BitVec.slice (← readReg CLIDR_EL1) range_min 3)) ) : SailM (BitVec 3) )
  let ccsidr_val ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  match cache_type with
  | 0b000 => (do (__UNKNOWN_bits 64))
  | 0b001 =>
    (do
      (if (data_cache : Bool)
      then (do (__UNKNOWN_bits 64))
      else
        (do sail_assert ((0 ≤b level) && (level <b 7)) "sail-arm/arm-v9.4-a/src/sysregs.sail:222.59-222.60"
            (pure (GetElem?.getElem! (← readReg __ICACHE_CCSIDR_RESET) level)))))
  | 0b010 =>
    (do
      (if ((! data_cache) : Bool)
      then (do (__UNKNOWN_bits 64))
      else
        (do sail_assert ((0 ≤b level) && (level <b 7)) "sail-arm/arm-v9.4-a/src/sysregs.sail:228.59-228.60"
            (pure (GetElem?.getElem! (← readReg __DCACHE_CCSIDR_RESET) level)))))
  | 0b011 =>
    (do
      (if (data_cache : Bool)
      then
        (do sail_assert ((0 ≤b level) && (level <b 7)) "sail-arm/arm-v9.4-a/src/sysregs.sail:234.59-234.60"
            (pure (GetElem?.getElem! (← readReg __DCACHE_CCSIDR_RESET) level)))
      else
        (do sail_assert ((0 ≤b level) && (level <b 7)) "sail-arm/arm-v9.4-a/src/sysregs.sail:237.59-237.60"
            (pure (GetElem?.getElem! (← readReg __ICACHE_CCSIDR_RESET) level)))))
  | 0b100 =>
    (do
      sail_assert ((0 ≤b level) && (level <b 7)) "sail-arm/arm-v9.4-a/src/sysregs.sail:242.55-242.56"
      (pure (GetElem?.getElem! (← readReg __DCACHE_CCSIDR_RESET) level)))
  | _ => (pure ccsidr_val)

def CacheConfigRead (cache_sel : (BitVec 4)) : SailM (BitVec 64) := do
  let data_cache : Bool :=
    if ((((BitVec.access cache_sel 0) : BitVec 1) == 0#1) : Bool)
    then true
    else false
  let level := (BitVec.toNat (Sail.BitVec.extractLsb cache_sel 3 1))
  sail_assert (level <b 7) "sail-arm/arm-v9.4-a/src/sysregs.sail:253.20-253.21"
  (getCacheID level data_cache)

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int, t : Int -/
def AArch64_SysRegRead (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) (t : Int) : SailM Unit := SailME.run do
  let index ← (( do (undefined_int ()) ) : SailME Unit Int )
  let n ← (( do (undefined_int ()) ) : SailME Unit Int )
  (if ((((op0 == 3) && (op1 == 3)) && (crn == 13)) : Bool)
  then
    (do let n := (BitVec.toNat (((integer_access crm 0) : BitVec 1) +++ (integer_subrange op2 2 0)))
        (if ((((integer_subrange crm 3 1) == 0b010#3) || ((integer_subrange crm 3 1) == 0b011#3)) : Bool)
        then
          (do (if ((n ≥b (BitVec.toNat (_get_AMCGCR_EL0_Type_CG0NC (← readReg AMCGCR_EL0)))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (pure ()))))
        else
          (do (if ((((integer_subrange crm 3 1) == 0b110#3) || ((integer_subrange crm 3 1) == 0b111#3)) : Bool)
              then
                (do (if ((n ≥b (BitVec.toNat (_get_AMCGCR_EL0_Type_CG1NC (← readReg AMCGCR_EL0)))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (pure ()))))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (op1 == 3)) && (crn == 14)) && (((integer_subrange crm 3 2) == 0b10#2) || ((integer_subrange crm 3 2) == 0b11#2))) && (((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)) != 0b11111#5)) : Bool)
  then
    (do (if ((←((pure ((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL1)) <||> (do
                 (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
                   (pure ((integer_subrange crm 3 2) == 0b10#2)) <&&> (do
                     (pure (((_get_PMUSERENR_EL0_Type_ER (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) != 0b00#2))) <||> (do
                     (pure ((integer_subrange crm 3 2) == 0b11#2)) <&&> (do
                       (pure ((_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0)) == 1#1))))))) <&&> (do
               (pure ((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
        then
          (do (if (((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure (((((op0 == 3) && (op1 == 3)) && (crn == 9)) && (crm == 13)) && ((op2 == 1) || (op2 == 2)))) <&&> (do
       (pure ((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) != 0b11111#5))))) : Bool)
  then
    (do (if ((←((pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL1)) <||> (do
                 (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
                   (pure (op2 == 2)) <&&> (do
                     (pure (((_get_PMUSERENR_EL0_Type_ER (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) != 0b00#2))) <||> (do
                     (pure (op2 == 1)) <&&> (do
                       (pure ((_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0)) == 1#1))))))) <&&> (do
               (pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
        then
          (do (if (((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  let temp ← (( do (X_read t 64) ) : SailME Unit (BitVec 64) )
  (AArch64_AutoGen_SysRegRead (← readReg PSTATE).EL (integer_subrange op0 1 0) (integer_subrange op1 2 0) (integer_subrange crn 3 0) (integer_subrange op2 2 0) (integer_subrange crm 3 0) t)
  (if ((((((op0 == 3) && (crn == 10)) && (crm == 5)) && (op2 == 0)) && ((op1 == 0) || (op1 == 5))) : Bool)
  then
    (do (if ((←((HaveRME ()) <&&> (do
             (pure ((_get_MPAMIDR_EL1_Type_HAS_ALTSP (← readReg MPAMIDR_EL1)) == 1#1))))) : Bool)
        then
          (do (X_set t 64
                (Sail.BitVec.updateSubrange (← (X_read t 64)) 54 54
                  (← do
                    (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
                    then (do (pure 1#1))
                    else (do (pure 0#1)))))))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 10)) && (crm == 5)) && (op2 == 0)) && (op1 == 4)) : Bool)
  then
    (do (if ((←((HaveRME ()) <&&> (do
             (pure ((_get_MPAMIDR_EL1_Type_HAS_ALTSP (← readReg MPAMIDR_EL1)) == 1#1))))) : Bool)
        then
          (do (X_set t 64
                (Sail.BitVec.updateSubrange (← (X_read t 64)) 54 54
                  (← do
                    (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure 1#1))
                    else (do (pure 0#1)))))))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 0)) && (op2 == 7)) && (crm == 10)) : Bool)
  then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 4 4 (← (SPE_PMBIDR_P_Read ())))))
  else (do (pure ())))
  (if ((((op0 == 3) && (crn == 9)) && (((((op1 == 3) && (op2 == 3)) && ((crm == 12) || (crm == 14))) || (((op1 == 3) && ((op2 == 1) || (op2 == 2))) && (crm == 12))) || (((op1 == 0) && ((op2 == 1) || (op2 == 2))) && (crm == 14)))) : Bool)
  then
    (do let mask ← (( do (PMUCounterMask ()) ) : SailME Unit (BitVec 64) )
        (X_set t 64 ((← (X_read t 64)) &&& mask)))
  else (do (pure ())))
  (if ((((((op0 == 3) && (op1 == 3)) && (crn == 9)) && (crm == 13)) && ((op2 == 1) || (op2 == 2))) : Bool)
  then
    (do (if ((op2 == 1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                     (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
                   (pure ((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) != 0b11111#5))) <&&> (do
                   (pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1)))))) : Bool)
              then
                (do (if (((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
                    then
                      (do (X_set t 64 temp)
                          sailThrow ((Error_Undefined ())))
                    else
                      (do (X_set t 64 temp)
                          (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) == 0b11111#5) : Bool)
                    then (do (X_set t 64 (← readReg PMCCFILTR_EL0)))
                    else
                      (do let pmselr_el0 ← (( do (pure (BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)))) ) : SailME Unit Int )
                          sail_assert (pmselr_el0 <b 31) "sail-arm/arm-v9.4-a/src/sysregs.sail:335.38-335.39"
                          (X_set t 64 (GetElem?.getElem! (← readReg PMEVTYPER_EL0) pmselr_el0)))))))
        else (do (pure ())))
        (if ((op2 == 2) : Bool)
        then
          (do (if ((←((pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1))) <&&> (do
                   (pure ((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) != 0b11111#5))) <||> (do
                   (EL2Enabled ()) <&&> (do
                     (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                       (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
                     (pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
              then
                (do (if (((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
                    then
                      (do (X_set t 64 temp)
                          sailThrow ((Error_Undefined ())))
                    else
                      (do (X_set t 64 temp)
                          (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
              else
                (do let pmselr_el0 ← (( do (pure (BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)))) ) : SailME Unit Int )
                    sail_assert (pmselr_el0 <b 31) "sail-arm/arm-v9.4-a/src/sysregs.sail:350.38-350.39"
                    (X_set t 64 (GetElem?.getElem! (← readReg PMEVCNTR_EL0) pmselr_el0)))))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 0)) && (crm == 12)) : Bool)
  then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 15 11 (integer_subrange (← (AArch64_GetNumEventCountersAccessible ())) 4 0))))
  else (do (pure ())))
  (if (((((op0 == 3) && (crn == 14)) && (op1 == 3)) && (((integer_subrange crm 3 2) == 0b10#2) || (((integer_subrange crm 3 2) == 0b11#2) && (((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)) != 0b11111#5)))) : Bool)
  then
    (do (if ((←((pure (((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1)) && (((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)) != 0b11111#5))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                 (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
               (pure ((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
        then
          (do (if (((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (X_set t 64 temp)
                    (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((((op0 == 2) && (op1 == 0)) && (crn == 7)) && (op2 == 6)) : Bool)
  then
    (do (if ((crm == 8) : Bool)
        then (do SailME.throw (← do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 7 0 0b11111111#8))))
        else
          (do (if ((crm == 9) : Bool)
              then (do SailME.throw (← do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 7 0 (Sail.BitVec.extractLsb (← readReg DBGCLAIMCLR_EL1) 7 0)))))
              else (do (pure ()))))))
  else (do (pure ())))
  (if (((((op0 == 2) && (op1 == 1)) && (crn == 7)) && (op2 == 6)) : Bool)
  then
    (do (if ((crm == 8) : Bool)
        then (do SailME.throw (← do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 31 0 (← readReg __trcclaim_tags)))))
        else
          (do (if ((crm == 9) : Bool)
              then (do SailME.throw (← do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 31 0 (← readReg __trcclaim_tags)))))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (op1 == 0)) && ((crn == (BitVec.toNat 0xA#4)) : Bool)) && (op2 == 0)) && (crm == 5)) : Bool)
  then
    (do (if ((BEq.beq (← (CurrentSecurityState ())) SS_Secure) : Bool)
        then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 60 60 (_get_MPAM3_EL3_Type_FORCE_NS (← (MPAM3_EL3_read ()))))))
        else (do (pure ()))))
  else
    (do (if ((((((op0 == 3) && ((crn == (BitVec.toNat 0xC#4)) : Bool)) && (op1 == 0)) && (op2 == 0)) && (crm == 1)) : Bool)
        then (do (X_set t 64 (Sail.BitVec.zeroExtend (← (getISR ())) 64)))
        else
          (do (if ((((((op0 == 3) && (crn == 0)) && (op1 == 1)) && ((op2 == 0) || (op2 == 2))) && (crm == 0)) : Bool)
              then
                (do (if ((op2 == 0) : Bool)
                    then (do (X_set t 64 (← (CacheConfigRead (Sail.BitVec.extractLsb (← readReg CSSELR_EL1) 3 0)))))
                    else (do (X_set t 64 (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (← (CacheConfigRead (Sail.BitVec.extractLsb (← readReg CSSELR_EL1) 3 0))) 63 32) 64)))))
              else
                (do (if ((((((op0 == 3) && (crn == 0)) && (op1 == 3)) && (op2 == 7)) && (crm == 0)) : Bool)
                    then
                      (do (if (((← readReg PSTATE).EL == EL0) : Bool)
                          then
                            (do (if ((← (IsInHost ())) : Bool)
                                then
                                  (do (X_set t 64
                                        (Sail.BitVec.updateSubrange (← (X_read t 64)) 4 4
                                          (← do
                                            (if (((_get_SCTLR_EL2_Type_DZE (← readReg SCTLR_EL2)) == 0#1) : Bool)
                                            then (do (pure 1#1))
                                            else (do (pure 0#1)))))))
                                else
                                  (do (X_set t 64
                                        (Sail.BitVec.updateSubrange (← (X_read t 64)) 4 4
                                          (← do
                                            (if ((←((pure ((_get_SCTLR_EL1_Type_DZE (← readReg SCTLR_EL1)) == 0#1)) <||> (do
                                                 (EL2Enabled ()) <&&> (do
                                                   (pure ((_get_HCR_EL2_Type_TDZ (← readReg HCR_EL2)) == 1#1)))))) : Bool)
                                            then (do (pure 1#1))
                                            else (do (pure 0#1)))))))))
                          else
                            (do (if (((← readReg PSTATE).EL == EL1) : Bool)
                                then
                                  (do (X_set t 64
                                        (Sail.BitVec.updateSubrange (← (X_read t 64)) 4 4
                                          (← do
                                            (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((_get_HCR_EL2_Type_TDZ (← readReg HCR_EL2)) == 1#1))))) : Bool)
                                            then (do (pure 1#1))
                                            else (do (pure 0#1)))))))
                                else (do (pure ()))))))
                    else
                      (do (if ((← (AArch64_CheckNVCondsIfCurrentEL op0 op1 crn crm op2)) : Bool)
                          then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 3 2 0b10#2)))
                          else (do (pure ())))
                          (if ((((((op0 == 3) && (crn == 2)) && (crm == 4)) && (op1 == 3)) && ((op2 == 0) || (op2 == 1))) : Bool)
                          then
                            (do (X_set t 64
                                  (← do
                                    (if ((op2 == 0) : Bool)
                                    then (do (genRandomNum false))
                                    else (do (genRandomNum true))))))
                          else (do (pure ())))
                          (if (((((op0 == 2) && (op1 == 1)) && (crn == 8)) && ((op2 == 0) || ((op2 == 1) || ((op2 == 2) || ((op2 == 4) || ((op2 == 5) || (op2 == 6))))))) : Bool)
                          then
                            (do let recordIdx ← (( do (pure (BitVec.toNat (((_get_BRBFCR_EL1_Type_BANK (← readReg BRBFCR_EL1)) +++ ((integer_access op2 2) : BitVec 1)) +++ (integer_subrange crm 3 0)))) ) : SailME Unit Int )
                                (if ((recordIdx <b (← (GetBRBENumRecords ()))) : Bool)
                                then
                                  (do (if (((op2 == 0) || (op2 == 4)) : Bool)
                                      then
                                        (do sail_assert ((0 ≤b recordIdx) && (recordIdx <b 64)) "sail-arm/arm-v9.4-a/src/sysregs.sail:443.70-443.71"
                                            (X_set t 64 (GetElem?.getElem! (← readReg Records_INF) recordIdx)))
                                      else (do (pure ())))
                                      (if (((op2 == 1) || (op2 == 5)) : Bool)
                                      then
                                        (do sail_assert ((0 ≤b recordIdx) && (recordIdx <b 64)) "sail-arm/arm-v9.4-a/src/sysregs.sail:447.70-447.71"
                                            (X_set t 64 (GetElem?.getElem! (← readReg Records_SRC) recordIdx)))
                                      else (do (pure ())))
                                      (if (((op2 == 2) || (op2 == 6)) : Bool)
                                      then
                                        (do sail_assert ((0 ≤b recordIdx) && (recordIdx <b 64)) "sail-arm/arm-v9.4-a/src/sysregs.sail:451.70-451.71"
                                            (X_set t 64 (GetElem?.getElem! (← readReg Records_TGT) recordIdx)))
                                      else (do (pure ()))))
                                else (do (X_set t 64 (Zeros (n := 64))))))
                          else (do (pure ())))
                          (if ((((((op0 == 3) && (crn == 5)) && (op1 == 0)) && (op2 == 0)) && (crm == 4)) : Bool)
                          then
                            (do (if ((←((pure ((BitVec.toNat (_get_ERRIDR_EL1_Type_NUM (← readReg ERRIDR_EL1))) == (BitVec.toNat 0x0#4))) <||> (do
                                     (pure ((BitVec.toNat (_get_ERRSELR_EL1_Type_SEL (← readReg ERRSELR_EL1))) ≥b (BitVec.toNat (_get_ERRIDR_EL1_Type_NUM (← readReg ERRIDR_EL1)))))))) : Bool)
                                then (do (X_set t 64 (Zeros (n := 64))))
                                else
                                  (do let index ← (( do (pure (BitVec.toNat (_get_ERRSELR_EL1_Type_SEL (← readReg ERRSELR_EL1)))) ) : SailME Unit Int )
                                      sail_assert ((0 ≤b index) && (index <b 4)) "sail-arm/arm-v9.4-a/src/sysregs.sail:464.57-464.58"
                                      (X_set t 64 (GetElem?.getElem! (← readReg ERRnFR) index)))))
                          else (do (pure ())))
                          (if ((((((op0 == 2) && (crn == 7)) && (op1 == 0)) && (op2 == 6)) && (crm == 14)) : Bool)
                          then
                            (do (if ((HaveEL EL3) : Bool)
                                then
                                  (do (if ((← (ExternalInvasiveDebugEnabled ())) : Bool)
                                      then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 1 0 0b11#2)))
                                      else (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 1 0 0b10#2))))
                                      (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 3 2 0b11#2))
                                      (if ((← (ExternalSecureInvasiveDebugEnabled ())) : Bool)
                                      then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 5 4 0b11#2)))
                                      else (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 5 4 0b10#2))))
                                      (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 7 6 (Sail.BitVec.extractLsb (← (X_read t 64)) 5 4))))
                                else (do (pure ()))))
                          else
                            (do (if ((((((op0 == 2) && (crn == 0)) && (op1 == 3)) && (op2 == 0)) && (crm == 5)) : Bool)
                                then
                                  (do (DBGDSCRint_write (_update_DBGDSCRint_Type_RXfull (← (DBGDSCRint_read ())) 0#1))
                                      writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 30 0#1)
                                      (DBGDSCRext_write (_update_DBGDSCRext_Type_RXfull (← (DBGDSCRext_read ())) 0#1))
                                      (EDSCR_write (_update_EDSCR_Type_RXfull (← (EDSCR_read ())) 0#1)))
                                else (do (pure ())))
                                (if ((((((op0 == 2) && (crn == 0)) && (op1 == 3)) && (op2 == 0)) && (crm == 4)) : Bool)
                                then
                                  (do (DBGDSCRint_write (_update_DBGDSCRint_Type_RXfull (← (DBGDSCRint_read ())) 0#1))
                                      writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 30 0#1)
                                      (DBGDSCRext_write (_update_DBGDSCRext_Type_RXfull (← (DBGDSCRext_read ())) 0#1))
                                      (EDSCR_write (_update_EDSCR_Type_RXfull (← (EDSCR_read ())) 0#1))
                                      (X_set t 64 (set_slice 32 (← (X_read t 64)) 32 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32)))
                                      (X_set t 64 (set_slice 32 (← (X_read t 64)) 0 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))
                                else (do (pure ())))
                                (if ((((((op0 == 3) && (crn == 12)) && (op1 == 4)) && (op2 == 7)) && (crm == 11)) : Bool)
                                then
                                  (do (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
                                           (pure ((← readReg PSTATE).EL == EL3))))) : Bool)
                                      then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 26 24 0b000#3)))
                                      else (do (pure ()))))
                                else (do (pure ())))
                                (if ((((((op0 == 3) && (crn == 4)) && (op1 == 0)) && (op2 == 0)) && (crm == 6)) : Bool)
                                then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 2 0 0b000#3)))
                                else (do (pure ())))
                                (if ((((((op0 == 3) && (crn == 1)) && (op1 == 4)) && (op2 == 0)) && (crm == 1)) : Bool)
                                then
                                  (do (if ((←((pure (! (← (ELUsingAArch32 EL1)))) <&&> (do
                                           (pure ((← readReg PSTATE).EL != EL1))))) : Bool)
                                      then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 31 31 1#1)))
                                      else (do (pure ()))))
                                else (do (pure ())))
                                (if ((((((op0 == 3) && (crn == 12)) && (op1 == 6)) && (op2 == 2)) && (crm == 0)) : Bool)
                                then
                                  (do (if (((_get_ID_AA64PFR0_EL1_Type_EL3 (← readReg ID_AA64PFR0_EL1)) == 0b0001#4) : Bool)
                                      then (do (X_set t 64 (Sail.BitVec.updateSubrange (← (X_read t 64)) 0 0 1#1)))
                                      else (do (pure ()))))
                                else (do (pure ())))))))))))))

def SetResetVector (value_name : (BitVec 64)) : SailM Unit := do
  (if ((! (← (HaveAArch64 ()))) : Bool)
  then
    (do (if ((HaveEL EL3) : Bool)
        then (do writeReg MVBAR (Mk_MVBAR_Type ((Sail.BitVec.extractLsb value_name 31 1) +++ 1#1)))
        else (do writeReg RVBAR ((Sail.BitVec.extractLsb value_name 31 1) +++ 1#1))))
  else
    (do (if (((HighestEL ()) == EL3) : Bool)
        then (do writeReg RVBAR_EL3 (Mk_RVBAR_EL3_Type value_name))
        else
          (do (if (((HighestEL ()) == EL2) : Bool)
              then (do writeReg RVBAR_EL2 (Mk_RVBAR_EL2_Type value_name))
              else (do writeReg RVBAR_EL1 (Mk_RVBAR_EL1_Type value_name)))))))

/-- Type quantifiers: k_cold : Bool -/
def TakeReset (cold : Bool) : SailM Unit := do
  sail_assert (((HighestEL ()) == EL1) || (((HighestEL ()) == EL2) || ((HighestEL ()) == EL3))) "sail-arm/arm-v9.4-a/src/reset.sail:1400.71-1400.72"
  writeReg FEAT_DoubleLock_IMPLEMENTED false
  writeReg FEAT_EPAC_IMPLEMENTED false
  (InitVariantImplemented ())
  (InitFeatureImpl ())
  (if (cold : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 15 12 CFG_ID_AA64PFR0_EL1_EL3)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 11 8 CFG_ID_AA64PFR0_EL1_EL2)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 7 4 CFG_ID_AA64PFR0_EL1_EL1)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 3 0 CFG_ID_AA64PFR0_EL1_EL0)
        writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 1 1 1#1)
        writeReg RMR_EL3 (Sail.BitVec.updateSubrange (← readReg RMR_EL3) 0 0 (← readReg CFG_RMR_AA64)))
  else (do (pure ())))
  (if (((_get_RMR_EL3_Type_AA64 (← readReg RMR_EL3)) == 1#1) : Bool)
  then
    (do writeReg __highest_el_aarch32 false
        (SetResetVector (← readReg CFG_RVBAR))
        (AArch64_TakeReset cold))
  else
    (do let questionMark := (HighestEL ())
        (if ((questionMark == EL3) : Bool)
        then (do sail_assert ((_get_ID_AA64PFR0_EL1_Type_EL3 (← readReg ID_AA64PFR0_EL1)) == 0b0010#4) "sail-arm/arm-v9.4-a/src/reset.sail:1420.51-1420.52")
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do sail_assert ((_get_ID_AA64PFR0_EL1_Type_EL2 (← readReg ID_AA64PFR0_EL1)) == 0b0010#4) "sail-arm/arm-v9.4-a/src/reset.sail:1423.51-1423.52")
              else
                (do (if ((questionMark == EL1) : Bool)
                    then (do sail_assert ((_get_ID_AA64PFR0_EL1_Type_EL1 (← readReg ID_AA64PFR0_EL1)) == 0b0010#4) "sail-arm/arm-v9.4-a/src/reset.sail:1426.51-1426.52")
                    else (do (pure ())))))))
        writeReg __highest_el_aarch32 true
        writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL0) false)
        writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL1) false)
        writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL2) false)
        writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL3) false)
        (if ((← readReg __ignore_rvbar_in_aarch32) : Bool)
        then (do (SetResetVector (Sail.BitVec.zeroExtend 0x0#4 64)))
        else (do (SetResetVector (← readReg CFG_RVBAR))))
        (if ((HaveEL EL3) : Bool)
        then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
        else (do (pure ())))
        (AArch32_TakeReset cold)))
  (if (((← readReg ZCR_EL3_LEN_VALUE) != (Neg.neg 1)) : Bool)
  then (do writeReg ZCR_EL3 (Sail.BitVec.updateSubrange (← readReg ZCR_EL3) 3 0 (integer_subrange (← readReg ZCR_EL3_LEN_VALUE) 3 0)))
  else (do (pure ())))
  (if (((← readReg CPTR_EL3_EZ_VALUE) != (Neg.neg 1)) : Bool)
  then (do writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 8 8 ((integer_access (← readReg CPTR_EL3_EZ_VALUE) 0) : BitVec 1)))
  else (do (pure ())))
  (if (((← readReg CPTR_EL3_ESM_VALUE) != (Neg.neg 1)) : Bool)
  then (do writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 12 12 ((integer_access (← readReg CPTR_EL3_ESM_VALUE) 0) : BitVec 1)))
  else (do (pure ())))
  (if (((← readReg SMCR_EL3_LEN_VALUE) != (Neg.neg 1)) : Bool)
  then (do writeReg SMCR_EL3 (Sail.BitVec.updateSubrange (← readReg SMCR_EL3) 3 0 (integer_subrange (← readReg SMCR_EL3_LEN_VALUE) 3 0)))
  else (do (pure ())))

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int, t : Int -/
def AArch64_SysRegWrite (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) (t : Int) : SailM Unit := SailME.run do
  let n ← (( do (undefined_int ()) ) : SailME Unit Int )
  let tempxt ← (( do (X_read t 64) ) : SailME Unit (BitVec 64) )
  let tempxt : (BitVec 64) :=
    if (((((op0 == 2) && (crn == 0)) && (op1 == 0)) && (op2 == 5)) : Bool)
    then
      (let tempxt : (BitVec 64) := (BitVec.update tempxt 8 (Bit ((BitVec.access tempxt 7) : BitVec 1)))
      (BitVec.update tempxt 6 (Bit ((BitVec.access tempxt 5) : BitVec 1))))
    else tempxt
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 4)) && (crm == 12)) : Bool)
    then
      (do let tempxt ← (pure (BitVec.update tempxt 19 (Bit (_get_ICV_CTLR_EL1_Type_ExtRange (← readReg ICV_CTLR_EL1)))))
          let tempxt ← (pure (Sail.BitVec.updateSubrange tempxt 13 11 (_get_ICV_CTLR_EL1_Type_IDbits (← readReg ICV_CTLR_EL1))))
          let tempxt ← (pure (Sail.BitVec.updateSubrange tempxt 10 8 (_get_ICV_CTLR_EL1_Type_PRIbits (← readReg ICV_CTLR_EL1))))
          let tempxt ← (pure (BitVec.update tempxt 15 (Bit (_get_ICV_CTLR_EL1_Type_A3V (← readReg ICV_CTLR_EL1)))))
          (pure (BitVec.update tempxt 14 (Bit (_get_ICV_CTLR_EL1_Type_SEIS (← readReg ICV_CTLR_EL1))))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 12)) && (op1 == 6)) && (op2 == 4)) && (crm == 12)) : Bool)
    then
      (do let tempxt ← (pure (BitVec.update tempxt 19 (Bit (_get_ICC_CTLR_EL3_Type_ExtRange (← readReg ICC_CTLR_EL3)))))
          let tempxt ← (pure (Sail.BitVec.updateSubrange tempxt 13 11 (_get_ICC_CTLR_EL3_Type_IDbits (← readReg ICC_CTLR_EL3))))
          let tempxt ← (pure (Sail.BitVec.updateSubrange tempxt 10 8 (_get_ICC_CTLR_EL3_Type_PRIbits (← readReg ICC_CTLR_EL3))))
          let tempxt ← (pure (BitVec.update tempxt 17 (Bit (_get_ICC_CTLR_EL3_Type_nDS (← readReg ICC_CTLR_EL3)))))
          let tempxt ← (pure (BitVec.update tempxt 15 (Bit (_get_ICC_CTLR_EL3_Type_A3V (← readReg ICC_CTLR_EL3)))))
          (pure (BitVec.update tempxt 14 (Bit (_get_ICC_CTLR_EL3_Type_SEIS (← readReg ICC_CTLR_EL3))))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 12)) && (op1 == 4)) && (op2 == 7)) && (crm == 11)) : Bool)
    then
      (do (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
               (pure ((← readReg PSTATE).EL == EL3))))) : Bool)
          then
            (do let tempxt ← (( do
                  (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 23 21)) <b (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
                  then (do (pure (Sail.BitVec.updateSubrange tempxt 23 21 (integer_subrange (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
                  else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
                let tempxt ← (( do
                  (if ((BEq.beq (← (CurrentSecurityState ())) SS_Secure) : Bool)
                  then
                    (do (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 20 18)) <b (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
                        then (do (pure (Sail.BitVec.updateSubrange tempxt 20 18 (integer_subrange (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
                        else (do (pure tempxt))))
                  else
                    (do (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 20 18)) <b (7 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
                        then (do (pure (Sail.BitVec.updateSubrange tempxt 20 18 (integer_subrange (7 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
                        else (do (pure tempxt))))) ) : SailME Unit (BitVec 64) )
                (if (((_get_ICC_SRE_EL1_Type_SRE (← readReg ICC_SRE_EL1_NS)) == 1#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange tempxt 3 2 0b10#2)))
                else (do (pure tempxt))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 3)) && (crm == 8)) : Bool)
    then
      (do (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 2 0)) <b (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange tempxt 2 0 (integer_subrange (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 3)) && (crm == 12)) : Bool)
    then
      (do (if (((_get_ICV_CTLR_EL1_Type_CBPR (← readReg ICV_CTLR_EL1)) == 0#1) : Bool)
          then
            (do (if ((BEq.beq (← (CurrentSecurityState ())) SS_Secure) : Bool)
                then
                  (do (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 2 0)) <b (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
                      then (do (pure (Sail.BitVec.updateSubrange tempxt 2 0 (integer_subrange (6 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
                      else (do (pure tempxt))))
                else
                  (do (if (((BitVec.toNat (Sail.BitVec.extractLsb tempxt 2 0)) <b (7 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2))))) : Bool)
                      then (do (pure (Sail.BitVec.updateSubrange tempxt 2 0 (integer_subrange (7 -i (BitVec.toNat (_get_ICH_VTR_EL2_Type_PREbits (← readReg ICH_VTR_EL2)))) 2 0))))
                      else (do (pure tempxt))))))
          else (do (pure (Sail.BitVec.updateSubrange tempxt 2 0 (_get_ICV_BPR1_EL1_Type_BinaryPoint (← readReg ICV_BPR1_EL1)))))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  (if ((((op0 == 3) && (op1 == 3)) && (crn == 13)) : Bool)
  then
    (do let n := (BitVec.toNat (((integer_access crm 0) : BitVec 1) +++ (integer_subrange op2 2 0)))
        (if ((((integer_subrange crm 3 1) == 0b010#3) || ((integer_subrange crm 3 1) == 0b011#3)) : Bool)
        then
          (do (if ((n ≥b (BitVec.toNat (_get_AMCGCR_EL0_Type_CG0NC (← readReg AMCGCR_EL0)))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (pure ()))))
        else
          (do (if ((((integer_subrange crm 3 1) == 0b110#3) || ((integer_subrange crm 3 1) == 0b111#3)) : Bool)
              then
                (do (if ((n ≥b (BitVec.toNat (_get_AMCGCR_EL0_Type_CG1NC (← readReg AMCGCR_EL0)))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (pure ()))))
              else (do (pure ()))))))
  else (do (pure ())))
  let mask ← (( do (PMUCounterMask ()) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 3)) && ((crm == 12) || (crm == 14))) : Bool)
    then
      (do let tempxt ← (( do
            (if ((crm == 12) : Bool)
            then (do (pure ((← readReg PMOVSSET_EL0) &&& (Complement.complement (tempxt &&& mask)))))
            else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
          (if ((crm == 14) : Bool)
          then (do (pure ((← readReg PMOVSSET_EL0) ||| (tempxt &&& mask))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && ((op2 == 1) || (op2 == 2))) && (crm == 12)) : Bool)
    then
      (do let tempxt ← (( do
            (if ((op2 == 2) : Bool)
            then (do (pure ((← readReg PMCNTENSET_EL0) &&& (Complement.complement (tempxt &&& mask)))))
            else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
          (if ((op2 == 1) : Bool)
          then (do (pure ((← readReg PMCNTENSET_EL0) ||| (tempxt &&& mask))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt ← (( do
    (if ((((((op0 == 3) && (crn == 9)) && (op1 == 0)) && ((op2 == 1) || (op2 == 2))) && (crm == 14)) : Bool)
    then
      (do let tempxt ← (( do
            (if ((op2 == 2) : Bool)
            then (do (pure ((← readReg PMINTENSET_EL1) &&& (Complement.complement (tempxt &&& mask)))))
            else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
          (if ((op2 == 1) : Bool)
          then (do (pure ((← readReg PMINTENSET_EL1) ||| (tempxt &&& mask))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 0)) && (crm == 12)) : Bool)
  then
    (do (if ((←((pure (((BitVec.access tempxt 3) : BitVec 1) == 1#1)) <&&> (do
             (pure ((_get_PMCR_EL0_Type_D (← readReg PMCR_EL0)) == 0#1))))) : Bool)
        then (do writeReg __clock_divider 63)
        else (do (pure ()))))
  else (do (pure ())))
  (if (((((op0 == 3) && (crn == 14)) && (op1 == 3)) && (((integer_subrange crm 3 2) == 0b10#2) || (((integer_subrange crm 3 2) == 0b11#2) && (((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)) != 0b11111#5)))) : Bool)
  then
    (do (if ((←((pure (((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1)) && (((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)) != 0b11111#5))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                 (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
               (pure ((_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0)) == 1#1))) <&&> (do
               (pure ((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
        then
          (do (if (((BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure ((((op0 == 3) && (op1 == 3)) && (crn == 9)) && (crm == 13))) <&&> (do
       (pure (op2 == 2)) <||> (do
         (pure (op2 == 1)) <&&> (do
           (pure ((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) != 0b11111#5))))))) : Bool)
  then
    (do (if ((←((pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1))) <&&> (do
             (pure ((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) != 0b11111#5))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                 (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
               (pure ((_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0)) == 1#1))) <&&> (do
               (pure ((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (AArch64_GetNumEventCountersAccessible ())) -i 1))))))) : Bool)
        then
          (do (if (((BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0))) >b ((← (GetNumEventCounters ())) -i 1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  let tempxt ← (( do
    (if (((((op0 == 2) && (op1 == 0)) && (crn == 7)) && (op2 == 6)) : Bool)
    then
      (do let tempxt ← (( do
            (if ((crm == 8) : Bool)
            then (do (pure (Sail.BitVec.updateSubrange tempxt 7 0 ((Sail.BitVec.extractLsb (← readReg DBGCLAIMCLR_EL1) 7 0) ||| (Sail.BitVec.extractLsb tempxt 7 0)))))
            else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
          (if ((crm == 9) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange tempxt 7 0 ((Sail.BitVec.extractLsb (← readReg DBGCLAIMCLR_EL1) 7 0) &&& (Complement.complement (Sail.BitVec.extractLsb tempxt 7 0))))))
          else (do (pure tempxt))))
    else (do (pure tempxt))) ) : SailME Unit (BitVec 64) )
  let tempxt2 ← (( do (undefined_bitvector 64) ) : SailME Unit (BitVec 64) )
  let restore_xt ← (( do (undefined_bool ()) ) : SailME Unit Bool )
  let (restore_xt, tempxt2) ← (( do
    (if ((tempxt != (← (X_read t 64))) : Bool)
    then
      (do let tempxt2 ← (X_read t 64)
          (X_set t 64 tempxt)
          let restore_xt : Bool := true
          (pure (restore_xt, tempxt2)))
    else
      (do let restore_xt : Bool := false
          (pure (restore_xt, tempxt2)))) ) : SailME Unit (Bool × (BitVec 64)) )
  (AArch64_AutoGen_SysRegWrite (← readReg PSTATE).EL (integer_subrange op0 1 0) (integer_subrange op1 2 0) (integer_subrange crn 3 0) (integer_subrange op2 2 0) (integer_subrange crm 3 0) t)
  (if (restore_xt : Bool)
  then (do (X_set t 64 tempxt2))
  else (do (pure ())))
  (if ((((((op0 == 2) && (op1 == 0)) && (crn == 7)) && (op2 == 6)) && (crm == 8)) : Bool)
  then (do writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 7 0 (Sail.BitVec.extractLsb tempxt 7 0)))
  else (do (pure ())))
  (if ((((((crm == 0) && (crn == 1)) && (op0 == 2)) && (op1 == 0)) && (op2 == 4)) : Bool)
  then
    (do (if ((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1)) <&&> (do
             (pure ((_get_OSLAR_EL1_Type_OSLK (← readReg OSLAR_EL1)) == 0#1))))) : Bool)
        then (do (CheckOSUnlockCatch ()))
        else (do (pure ())))
        writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 1 1 (_get_OSLAR_EL1_Type_OSLK (← readReg OSLAR_EL1)))
        writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 5 5 (_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)))
        (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLK (← (DBGOSLSR_read ())) (_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)))))
  else (do (pure ())))
  (if (((((op0 == 2) && (op1 == 1)) && (crn == 7)) && (op2 == 6)) : Bool)
  then
    (do (if ((crm == 8) : Bool)
        then (do SailME.throw (← do writeReg __trcclaim_tags ((← readReg __trcclaim_tags) ||| (Sail.BitVec.extractLsb tempxt 31 0))))
        else
          (do (if ((crm == 9) : Bool)
              then (do SailME.throw (← do writeReg __trcclaim_tags ((← readReg __trcclaim_tags) &&& (Complement.complement (Sail.BitVec.extractLsb tempxt 31 0)))))
              else (do (pure ()))))))
  else (do (pure ())))
  (if (((((((op0 == 3) && ((crn == (BitVec.toNat 0xC#4)) : Bool)) && (((op1 == 6) || (op1 == 4)) || (op1 == 0))) && (op2 == 2)) && (crm == 0)) && (((BitVec.access tempxt 1) : BitVec 1) == 1#1)) : Bool)
  then (do (TakeReset false))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 3)) && ((crm == 12) || (crm == 14))) : Bool)
  then
    (do (if ((crm == 12) : Bool)
        then (do writeReg PMOVSSET_EL0 (Mk_PMOVSSET_EL0_Type tempxt))
        else (do (pure ())))
        (if ((crm == 14) : Bool)
        then (do writeReg PMOVSCLR_EL0 (Mk_PMOVSCLR_EL0_Type tempxt))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && ((op2 == 1) || (op2 == 2))) && (crm == 12)) : Bool)
  then
    (do (if ((op2 == 2) : Bool)
        then (do writeReg PMCNTENSET_EL0 (Mk_PMCNTENSET_EL0_Type tempxt))
        else (do (pure ())))
        (if ((op2 == 1) : Bool)
        then (do writeReg PMCNTENCLR_EL0 (Mk_PMCNTENCLR_EL0_Type tempxt))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 0)) && ((op2 == 1) || (op2 == 2))) && (crm == 14)) : Bool)
  then
    (do (if ((op2 == 2) : Bool)
        then (do writeReg PMINTENSET_EL1 (Mk_PMINTENSET_EL1_Type tempxt))
        else (do (pure ())))
        (if ((op2 == 1) : Bool)
        then (do writeReg PMINTENCLR_EL1 (Mk_PMINTENCLR_EL1_Type tempxt))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 0)) && (crm == 12)) : Bool)
  then
    (do (if ((((BitVec.access tempxt 2) : BitVec 1) == 1#1) : Bool)
        then (do writeReg PMCCNTR_EL0 (Mk_PMCCNTR_EL0_Type (Zeros (n := 64))))
        else (do (pure ())))
        (if ((((BitVec.access tempxt 1) : BitVec 1) == 1#1) : Bool)
        then (do (AArch64_ClearEventCounters ()))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (op1 == 3)) && (crn == 9)) && (crm == 13)) && ((op2 == 1) || (op2 == 2))) : Bool)
  then
    (do (if ((op2 == 1) : Bool)
        then
          (do (if (((_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)) == 0b11111#5) : Bool)
              then (do writeReg PMCCFILTR_EL0 (__get_PMCCFILTR_EL0 (Mk_PMCCFILTR_EL0_Type tempxt)))
              else
                (do let pmselr_el0 ← (( do (pure (BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)))) ) : SailME Unit Int )
                    sail_assert (pmselr_el0 <b 31) "sail-arm/arm-v9.4-a/src/sysregs.sail:748.38-748.39"
                    writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) pmselr_el0 (__get_PMEVTYPER_EL0 (Mk_PMEVTYPER_EL0_Type tempxt))))))
        else (do (pure ())))
        (if ((op2 == 2) : Bool)
        then
          (do let pmselr_el0 ← (( do (pure (BitVec.toNat (_get_PMSELR_EL0_Type_SEL (← readReg PMSELR_EL0)))) ) : SailME Unit Int )
              sail_assert (pmselr_el0 <b 31) "sail-arm/arm-v9.4-a/src/sysregs.sail:754.34-754.35"
              writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) pmselr_el0 tempxt))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((((op0 == 3) && (op1 == 3)) && (crn == 14)) && ((integer_subrange crm 3 2) == 0b11#2)) : Bool)
  then
    (do let index := (BitVec.toNat ((integer_subrange crm 1 0) +++ (integer_subrange op2 2 0)))
        (if ((index == 31) : Bool)
        then (do writeReg PMCCFILTR_EL0 (__get_PMCCFILTR_EL0 (Mk_PMCCFILTR_EL0_Type tempxt)))
        else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) index (__get_PMEVTYPER_EL0 (Mk_PMEVTYPER_EL0_Type tempxt))))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 9)) && (op1 == 3)) && (op2 == 4)) && (crm == 12)) : Bool)
  then (do (AArch64_PMUSwIncrement (Sail.BitVec.extractLsb tempxt 31 0)))
  else (do (pure ())))
  (if ((((((op0 == 2) && (crn == 0)) && (op1 == 3)) && (op2 == 0)) && (crm == 5)) : Bool)
  then
    (do (DBGDSCRint_write (_update_DBGDSCRint_Type_TXfull (← (DBGDSCRint_read ())) 1#1))
        writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 29 29 1#1)
        (DBGDSCRext_write (_update_DBGDSCRext_Type_TXfull (← (DBGDSCRext_read ())) 1#1))
        (EDSCR_write (_update_EDSCR_Type_TXfull (← (EDSCR_read ())) 1#1)))
  else (do (pure ())))
  (if ((((((op0 == 2) && (crn == 0)) && (op1 == 3)) && (op2 == 0)) && (crm == 4)) : Bool)
  then
    (do (DBGDSCRint_write (_update_DBGDSCRint_Type_TXfull (← (DBGDSCRint_read ())) 1#1))
        writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 29 29 1#1)
        (DBGDSCRext_write (_update_DBGDSCRext_Type_TXfull (← (DBGDSCRext_read ())) 1#1))
        (EDSCR_write (_update_EDSCR_Type_TXfull (← (EDSCR_read ())) 1#1))
        writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice (← (DBGDTR_EL0_read__1 ())) 0 32))
        writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice (← (DBGDTR_EL0_read__1 ())) 32 32)))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 4)) && (op2 == 7)) && (crm == 11)) : Bool)
  then
    (do writeReg ICV_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_PMR_EL1) 7 0 (_get_ICH_VMCR_EL2_Type_VPMR (← readReg ICH_VMCR_EL2)))
        writeReg ICV_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR0_EL1) 2 0 (_get_ICH_VMCR_EL2_Type_VBPR0 (← readReg ICH_VMCR_EL2)))
        writeReg ICV_BPR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR1_EL1) 2 0 (_get_ICH_VMCR_EL2_Type_VBPR1 (← readReg ICH_VMCR_EL2)))
        writeReg ICV_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN0_EL1) 0 0 (_get_ICH_VMCR_EL2_Type_VENG0 (← readReg ICH_VMCR_EL2)))
        writeReg ICV_IGRPEN1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN1_EL1) 0 0 (_get_ICH_VMCR_EL2_Type_VENG1 (← readReg ICH_VMCR_EL2)))
        writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 1 1 (_get_ICH_VMCR_EL2_Type_VEOIM (← readReg ICH_VMCR_EL2)))
        writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 0 0 (_get_ICH_VMCR_EL2_Type_VCBPR (← readReg ICH_VMCR_EL2))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 4)) && (op1 == 0)) && (op2 == 0)) && (crm == 6)) : Bool)
  then (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 31 24 (_get_ICV_PMR_EL1_Type_Priority (← readReg ICV_PMR_EL1))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 3)) && (crm == 8)) : Bool)
  then (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 23 21 (_get_ICV_BPR0_EL1_Type_BinaryPoint (← readReg ICV_BPR0_EL1))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 3)) && (crm == 12)) : Bool)
  then (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 20 18 (_get_ICV_BPR1_EL1_Type_BinaryPoint (← readReg ICV_BPR1_EL1))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 4)) && (crm == 12)) : Bool)
  then
    (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 9 9 (_get_ICV_CTLR_EL1_Type_EOImode (← readReg ICV_CTLR_EL1)))
        writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 4 4 (_get_ICV_CTLR_EL1_Type_CBPR (← readReg ICV_CTLR_EL1))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 6)) && (crm == 12)) : Bool)
  then (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 0 0 (_get_ICV_IGRPEN0_EL1_Type_Enable (← readReg ICV_IGRPEN0_EL1))))
  else (do (pure ())))
  (if ((((((op0 == 3) && (crn == 12)) && (op1 == 0)) && (op2 == 7)) && (crm == 12)) : Bool)
  then (do writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 1 1 (_get_ICV_IGRPEN1_EL1_Type_Enable (← readReg ICV_IGRPEN1_EL1))))
  else (do (pure ())))

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int, t : Int -/
def AArch64_SysInstr (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) (t : Int) : SailM Unit := do
  (AArch64_AutoGen_SysOpsWrite (← readReg PSTATE).EL (integer_subrange op0 1 0) (integer_subrange op1 2 0) (integer_subrange crn 3 0) (integer_subrange op2 2 0) (integer_subrange crm 3 0) t)

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int, t : Int -/
def AArch64_SysInstrWithResult (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) (t : Int) : SailM Unit := do
  (AArch64_AutoGen_SysInstrWithResult (← readReg PSTATE).EL (integer_subrange op0 1 0) (integer_subrange op1 2 0) (integer_subrange crn 3 0) (integer_subrange op2 2 0) (integer_subrange crm 3 0) t)

def __InitSystem (_ : Unit) : SailM Unit := do
  writeReg DBGEN Signal_Low
  (TakeReset true)
  writeReg CNTCR (Sail.BitVec.updateSubrange (← readReg CNTCR) 0 0 1#1)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, k_neg : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_int_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (neg : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let element : Int :=
          if (neg : Bool)
          then (Neg.neg element)
          else (Int.natAbs element)
        let result ← (Elem_set result e esize (integer_subrange element (esize -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_abs_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_int_sisd d datasize elements esize n neg)

def decode_neg_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_int_sisd d datasize elements esize n neg)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, k_setflags : Bool, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_add_sub_carry (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (setflags : Bool) (sub_op : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let nzcv ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let operand2 : (BitVec datasize) :=
    if (sub_op : Bool)
    then (Complement.complement operand2)
    else operand2
  let (nzcv, result) ← (( do
    let (tup__0, tup__1) ← do (pure (AddWithCarry operand1 operand2 (← readReg PSTATE).C))
    let result : (BitVec datasize) := tup__0
    let nzcv : (BitVec 4) := tup__1
    (pure (nzcv, result)) ) : SailM ((BitVec 4) × (BitVec datasize)) )
  (if (setflags : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb nzcv 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb nzcv 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb nzcv 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb nzcv 0 0) })
  else (do (pure ())))
  (X_set d datasize result)

def decode_adc_aarch64_instrs_integer_arithmetic_add_sub_carry (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_carry d datasize m n setflags sub_op)

def decode_adcs_aarch64_instrs_integer_arithmetic_add_sub_carry (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_carry d datasize m n setflags sub_op)

def decode_sbc_aarch64_instrs_integer_arithmetic_add_sub_carry (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_carry d datasize m n setflags sub_op)

def decode_sbcs_aarch64_instrs_integer_arithmetic_add_sub_carry (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_carry d datasize m n setflags sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (( do
          (if (sub_op : Bool)
          then (do (Elem_set result e esize (element1 - element2)))
          else (do (Elem_set result e esize (element1 + element2)))) ) : SailM (BitVec datasize) )
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_add_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd d datasize elements esize m n sub_op)

def decode_add_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd d datasize elements esize m n sub_op)

def decode_sub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size != 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd d datasize elements esize m n sub_op)

def decode_sub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_wrapping_single_sisd d datasize elements esize m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, k_setflags : Bool, shift_amount : Nat, k_sub_op : Bool, 0 ≤ shift_amount ∧ shift_amount ≤ 63 ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (setflags : Bool) (shift_amount : Nat) (shift_type : ShiftType) (sub_op : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (ShiftReg m shift_type shift_amount datasize) ) : SailM (BitVec datasize) )
  let nzcv ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let carry_in ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
    if (sub_op : Bool)
    then
      (let operand2 : (BitVec datasize) := (Complement.complement operand2)
      let carry_in : (BitVec 1) := 1#1
      (carry_in, operand2))
    else
      (let carry_in : (BitVec 1) := 0#1
      (carry_in, operand2))
  let (nzcv, result) : ((BitVec 4) × (BitVec datasize)) :=
    let (tup__0, tup__1) := ((AddWithCarry operand1 operand2 carry_in) : ((BitVec datasize) × (BitVec 4)))
    let result : (BitVec datasize) := tup__0
    let nzcv : (BitVec 4) := tup__1
    (nzcv, result)
  (if (setflags : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb nzcv 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb nzcv 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb nzcv 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb nzcv 0 0) })
  else (do (pure ())))
  (X_set d datasize result)

def decode_add_addsub_shift_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (shift : (BitVec 2)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (if ((shift == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg d datasize m n setflags shift_amount shift_type sub_op)

def decode_adds_addsub_shift_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (shift : (BitVec 2)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (if ((shift == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg d datasize m n setflags shift_amount shift_type sub_op)

def decode_sub_addsub_shift_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (shift : (BitVec 2)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (if ((shift == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg d datasize m n setflags shift_amount shift_type sub_op)

def decode_subs_addsub_shift_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm6 : (BitVec 6)) (Rm : (BitVec 5)) (shift : (BitVec 2)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  (if ((shift == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((sf == 0#1) && (((BitVec.access imm6 5) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let shift_type ← (( do (DecodeShift shift) ) : SailM ShiftType )
  let shift_amount := (BitVec.toNat imm6)
  (execute_aarch64_instrs_integer_arithmetic_add_sub_shiftedreg d datasize m n setflags shift_amount shift_type sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, k_setflags : Bool, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_add_sub_immediate (d : Nat) (datasize : Nat) (imm : (BitVec datasize)) (n : Nat) (setflags : Bool) (sub_op : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do
    (if ((n == 31) : Bool)
    then (do (pure (Sail.BitVec.extractLsb (← (SP_read ())) (datasize -i 1) 0)))
    else (do (X_read n datasize))) ) : SailM (BitVec datasize) )
  let operand2 : (BitVec datasize) := imm
  let nzcv ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let carry_in ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
    if (sub_op : Bool)
    then
      (let operand2 : (BitVec datasize) := (Complement.complement operand2)
      let carry_in : (BitVec 1) := 1#1
      (carry_in, operand2))
    else
      (let carry_in : (BitVec 1) := 0#1
      (carry_in, operand2))
  let (nzcv, result) : ((BitVec 4) × (BitVec datasize)) :=
    let (tup__0, tup__1) := ((AddWithCarry operand1 operand2 carry_in) : ((BitVec datasize) × (BitVec 4)))
    let result : (BitVec datasize) := tup__0
    let nzcv : (BitVec 4) := tup__1
    (nzcv, result)
  (if (setflags : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb nzcv 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb nzcv 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb nzcv 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb nzcv 0 0) })
  else (do (pure ())))
  (if (((d == 31) && (! setflags)) : Bool)
  then (do (SP_set (Sail.BitVec.zeroExtend result 64)))
  else (do (X_set d datasize result)))

def decode_add_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

def decode_adds_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

def decode_sub_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

def decode_subs_addsub_imm_aarch64_instrs_integer_arithmetic_add_sub_immediate (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (sh : (BitVec 1)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let imm ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let imm : (BitVec datasize) :=
    match sh with
    | 0 => (Sail.BitVec.zeroExtend imm12 datasize)
    | _ => (Sail.BitVec.zeroExtend (imm12 +++ (Zeros (n := 12))) datasize)
  let imm := imm
  (execute_aarch64_instrs_integer_arithmetic_add_sub_immediate d datasize imm n setflags sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, m : Nat, n : Nat, k_setflags : Bool, shift : Nat, k_sub_op : Bool, List.elem shift [0, 1, 2, 3, 4, 5, 6, 7] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (d : Nat) (datasize : Nat) (extend_type : ExtendType) (m : Nat) (n : Nat) (setflags : Bool) (shift : Nat) (sub_op : Bool) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let operand1 ← (( do
    (if ((n == 31) : Bool)
    then (do (pure (Sail.BitVec.extractLsb (← (SP_read ())) (datasize -i 1) 0)))
    else (do (X_read n datasize))) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (ExtendReg m extend_type shift datasize) ) : SailM (BitVec datasize) )
  let nzcv ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let carry_in ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (carry_in, operand2) : ((BitVec 1) × (BitVec datasize)) :=
    if (sub_op : Bool)
    then
      (let operand2 : (BitVec datasize) := (Complement.complement operand2)
      let carry_in : (BitVec 1) := 1#1
      (carry_in, operand2))
    else
      (let carry_in : (BitVec 1) := 0#1
      (carry_in, operand2))
  let (nzcv, result) : ((BitVec 4) × (BitVec datasize)) :=
    let (tup__0, tup__1) := ((AddWithCarry operand1 operand2 carry_in) : ((BitVec datasize) × (BitVec 4)))
    let result : (BitVec datasize) := tup__0
    let nzcv : (BitVec 4) := tup__1
    (nzcv, result)
  (if (setflags : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb nzcv 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb nzcv 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb nzcv 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb nzcv 0 0) })
  else (do (pure ())))
  (if (((d == 31) && (! setflags)) : Bool)
  then (do (SP_set (Sail.BitVec.zeroExtend result 64)))
  else (do (X_set d datasize result)))

def decode_add_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_adds_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_sub_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)

def decode_subs_addsub_ext_aarch64_instrs_integer_arithmetic_add_sub_extendedreg (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm3 : (BitVec 3)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (S : (BitVec 1)) (op : (BitVec 1)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let sub_op : Bool := (op == 1#1)
  let setflags : Bool := (S == 1#1)
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift := (BitVec.toNat imm3)
  (if ((shift >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_integer_arithmetic_add_sub_extendedreg d datasize extend_type m n setflags shift sub_op)


end ArmASL.Functions
