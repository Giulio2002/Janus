import ArmASL.Part36

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def TFSRE0_EL1_SysRegWrite_c83d8537b51ba0c0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ATA ← (( do (pure (_get_SCR_EL3_Type_ATA (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_ATA ← (( do (pure (_get_HCR_EL2_Type_ATA (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_ATA == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TFSRE0_EL1 (Mk_TFSRE0_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TFSRE0_EL1 (Mk_TFSRE0_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TFSRE0_EL1 (Mk_TFSRE0_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TFSR_EL1_SysRegWrite_ff5023e822575c45 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ATA ← (( do (pure (_get_SCR_EL3_Type_ATA (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x190#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TFSR_EL2_SysRegWrite_0de052c6a803cdd2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ATA ← (( do (pure (_get_SCR_EL3_Type_ATA (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_ATA ← (( do (pure (_get_HCR_EL2_Type_ATA (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_ATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TFSR_EL2 (Mk_TFSR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TFSR_EL2 (Mk_TFSR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TFSR_EL2_SysRegWrite_e50f9758a2aeae18 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ATA ← (( do (pure (_get_SCR_EL3_Type_ATA (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_ATA ← (( do (pure (_get_HCR_EL2_Type_ATA (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b011#3))))) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_ATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x190#12) (← (X_read t 64))))
                                      else (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ATA == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ATA == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg TFSR_EL2 (Mk_TFSR_EL2_Type (← (X_read t 64))))
                                else (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TFSR_EL1 (Mk_TFSR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TFSR_EL3_SysRegWrite_f3f90e5ae77101da (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TFSR_EL3 (Mk_TFSR_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR2_EL0_SysRegWrite_6f661a4b0c2ce1c0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EnTP2 ← (( do (pure (_get_SCR_EL3_Type_EnTP2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCTLR_EL1_EnTP2 ← (( do (pure (_get_SCTLR_EL1_Type_EnTP2 (← readReg SCTLR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCTLR_EL2_EnTP2 ← (( do (pure (_get_SCTLR_EL2_Type_EnTP2 (← readReg SCTLR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nTPIDR2_EL0 ← (( do (pure (_get_HFGWTR_EL2_Type_nTPIDR2_EL0 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (((! (←((EL2Enabled ()) <&&> (do
                       (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__SCTLR_EL1_EnTP2 == 0#1)) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__SCTLR_EL2_EnTP2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nTPIDR2_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg TPIDR2_EL0 (← (X_read t 64)))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nTPIDR2_EL0 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TPIDR2_EL0 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_EnTP2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TPIDR2_EL0 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDR2_EL0 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDRRO_EL0_SysRegWrite_7203698352c87d5e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_TPIDRRO_EL0 ← (( do (pure (_get_HFGWTR_EL2_Type_TPIDRRO_EL0 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TPIDRRO_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do writeReg TPIDRRO_EL0 (← (X_read t 64)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg TPIDRRO_EL0 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDRRO_EL0 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL0_SysRegWrite_0cc7097850c46a2a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_TPIDR_EL0 ← (( do (pure (_get_HFGWTR_EL2_Type_TPIDR_EL0 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do writeReg TPIDR_EL0 (← (X_read t 64)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do writeReg TPIDR_EL0 (← (X_read t 64)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg TPIDR_EL0 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDR_EL0 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL1_SysRegWrite_be51f1ab4eeaabd3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_TPIDR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_TPIDR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TPIDR_EL1 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do writeReg TPIDR_EL1 (← (X_read t 64)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg TPIDR_EL1 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL2_SysRegWrite_6e0625002baa042c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x090#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg TPIDR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL3_SysRegWrite_ea00df52cbaac80c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TPIDR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TRFCR_EL1_SysRegWrite_cc3bca184cf88f2f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TTRF ← (( do (pure (_get_MDCR_EL3_Type_TTRF (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x880#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg TRFCR_EL1 (Mk_TRFCR_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg TRFCR_EL1 (Mk_TRFCR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TRFCR_EL2_SysRegWrite_20a366481946c8fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TTRF ← (( do (pure (_get_MDCR_EL3_Type_TTRF (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg TRFCR_EL2 (Mk_TRFCR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TRFCR_EL2 (Mk_TRFCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TRFCR_EL2_SysRegWrite_75efd6fa24ddc2b7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TTRF ← (( do (pure (_get_MDCR_EL3_Type_TTRF (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_TRFCR_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_TRFCR_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TTRF ← (( do (pure (_get_MDCR_EL2_Type_TTRF (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_TRFCR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TTRF == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x880#12) (← (X_read t 64))))
                                      else (do writeReg TRFCR_EL1 (Mk_TRFCR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TTRF == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg TRFCR_EL2 (Mk_TRFCR_EL2_Type (← (X_read t 64))))
                                else (do writeReg TRFCR_EL1 (Mk_TRFCR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TRFCR_EL1 (Mk_TRFCR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR0_EL1_SysRegWrite_1418275ded3dcceb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x200#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL1_read ())) 63 0 (← (X_read t 64))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL1_read ())) 63 0 (← (X_read t 64))))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR0_EL2_SysRegWrite_4eaec85b078ecd3b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_TTBR0_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_TTBR0_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TTBR0_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x200#12) (← (X_read t 64))))
                          else (do (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL1_read ())) 63 0 (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL2_read ())) 63 0 (← (X_read t 64))))))
                    else (do (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL1_read ())) 63 0 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL1_read ())) 63 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR0_EL2_SysRegWrite_6f2504a3aff125cc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL2_read ())) 63 0 (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (Sail.BitVec.updateSubrange (← (TTBR0_EL2_read ())) 63 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR0_EL3_SysRegWrite_3f52a3edf2b13467 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TTBR0_EL3 (Mk_TTBR0_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR1_EL1_SysRegWrite_4d156e352c93f29e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x210#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR1_EL1_read ())) 63 0 (← (X_read t 64))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR1_EL1_read ())) 63 0 (← (X_read t 64))))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR1_EL1_SysRegWrite_949dc27ace2a7dbe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_TTBR1_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_TTBR1_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_TTBR1_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x210#12) (← (X_read t 64))))
                          else (do (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR1_EL1_read ())) 63 0 (← (X_read t 64))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 63 0 (← (X_read t 64))))
                    else (do (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR1_EL1_read ())) 63 0 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (Sail.BitVec.updateSubrange (← (TTBR1_EL1_read ())) 63 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TTBR1_EL2_SysRegWrite_2b203badd6cd49c7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 63 0 (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 63 0 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def UAO_SysRegWrite_3265e241e210a049 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with UAO := (← do (pure ((BitVec.access (← (X_read t 64)) 23) : BitVec 1))) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with UAO := (← do (pure ((BitVec.access (← (X_read t 64)) 23) : BitVec 1))) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with UAO := (← do (pure ((BitVec.access (← (X_read t 64)) 23) : BitVec 1))) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VBAR_EL1_SysRegWrite_2545adf6b767cca1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x250#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg VBAR_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg VBAR_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VBAR_EL2_SysRegWrite_58cf9956b761a13c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_VBAR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_VBAR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b011#3))))) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_VBAR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x250#12) (← (X_read t 64))))
                          else (do writeReg VBAR_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg VBAR_EL2 (← (X_read t 64)))
                    else (do writeReg VBAR_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VBAR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VBAR_EL2_SysRegWrite_89ae3d074e337e2e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VBAR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VBAR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VBAR_EL3_SysRegWrite_a4ea3bd6f4a6393d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VBAR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VDISR_EL2_SysRegWrite_22757a602e967277 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_AMO ← (( do (pure (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EA ← (( do (pure (_get_SCR_EL3_Type_EA (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_AMO == 1#1)) : Bool)
              then (do writeReg VDISR_EL2 (Mk_VDISR_EL2_Type (← (X_read t 64))))
              else
                (do (if (((←((pure (HaveEL EL3)) <&&> (do
                           (pure (! (← (Halted ()))))))) && (__SCR_EL3_EA == 1#1)) : Bool)
                    then (do (pure ()))
                    else (do writeReg DISR_EL1 (Mk_DISR_EL1_Type (← (X_read t 64))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (HaveEL EL3)) <&&> (do
                           (pure (! (← (Halted ()))))))) && (__SCR_EL3_EA == 1#1)) : Bool)
                    then (do (pure ()))
                    else (do writeReg DISR_EL1 (Mk_DISR_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg DISR_EL1 (Mk_DISR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VDISR_EL2_SysRegWrite_d4de228de4dce7ee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x500#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VDISR_EL2 (Mk_VDISR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VDISR_EL2 (Mk_VDISR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VMECID_A_EL2_SysRegWrite_d4d52ce2ee2e86c2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg VMECID_A_EL2 (Mk_VMECID_A_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VMECID_A_EL2 (Mk_VMECID_A_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VMECID_P_EL2_SysRegWrite_b0549714107a13fc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_MECEn ← (( do (pure (_get_SCR_EL3_Type_MECEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Realm))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_MECEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg VMECID_P_EL2 (Mk_VMECID_P_EL2_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VMECID_P_EL2 (Mk_VMECID_P_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VMPIDR_EL2_SysRegWrite_652dff4d193b16d2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x050#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VMPIDR_EL2 (Mk_VMPIDR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((! (HaveEL EL2)) : Bool)
                          then (do (pure ()))
                          else (do writeReg VMPIDR_EL2 (Mk_VMPIDR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VNCR_EL2_SysRegWrite_4acc113d8c83cbf3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x0B0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VNCR_EL2 (Mk_VNCR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VNCR_EL2 (Mk_VNCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VPIDR_EL2_SysRegWrite_8d6e5569c8c164cb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x088#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VPIDR_EL2 (Mk_VPIDR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((! (HaveEL EL2)) : Bool)
                          then (do (pure ()))
                          else (do writeReg VPIDR_EL2 (Mk_VPIDR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VSESR_EL2_SysRegWrite_9e724bce6c5a8288 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x508#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VSESR_EL2 (Mk_VSESR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VSESR_EL2 (Mk_VSESR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VSTCR_EL2_SysRegWrite_9398e11d9c39d020 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x048#12) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg VSTCR_EL2 (Mk_VSTCR_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg VSTCR_EL2 (Mk_VSTCR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VSTTBR_EL2_SysRegWrite_313d4b469c28863c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x030#12) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg VSTTBR_EL2 (Mk_VSTTBR_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg VSTTBR_EL2 (Mk_VSTTBR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VTCR_EL2_SysRegWrite_087e5f2e2721566e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x040#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg VTCR_EL2 (Mk_VTCR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg VTCR_EL2 (Mk_VTCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def VTTBR_EL2_SysRegWrite_e5049cda9fc04134 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x020#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (VTTBR_EL2_write (Mk_VTTBR_EL2_Type (Sail.BitVec.updateSubrange (← (VTTBR_EL2_read ())) 63 0 (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (VTTBR_EL2_write (Mk_VTTBR_EL2_Type (Sail.BitVec.updateSubrange (← (VTTBR_EL2_read ())) 63 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ZCR_EL1_SysRegWrite_28a1dc91762b9c5d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_EZ ← (( do (pure (_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPACR_EL1_ZEN ← (( do (pure (_get_CPACR_EL1_Type_ZEN (← readReg CPACR_EL1))) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TZ ← (( do (pure (_get_CPTR_EL2_Type_TZ (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_ZEN ← (( do (pure (_get_CPTR_EL2_Type_ZEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_EZ == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((let b__2 := __CPACR_EL1_ZEN
                       if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                       then true
                       else false : Bool) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x19#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 0#1)) && (__CPTR_EL2_TZ == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__1 := __CPTR_EL2_ZEN
                                     if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                            then (do (NVMem_set (BitVec.toNat 0x1E0#12) (← (X_read t 64))))
                                            else (do writeReg ZCR_EL1 (Mk_ZCR_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TZ == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_ZEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))))
                                      else
                                        (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                            then (do writeReg ZCR_EL2 (Mk_ZCR_EL2_Type (← (X_read t 64))))
                                            else (do writeReg ZCR_EL1 (Mk_ZCR_EL1_Type (← (X_read t 64))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_EZ == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))
                          else (do writeReg ZCR_EL1 (Mk_ZCR_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ZCR_EL1_SysRegWrite_8900d1c129d0830f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_EZ ← (( do (pure (_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_ZEN ← (( do (pure (_get_CPTR_EL2_Type_ZEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x1E0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((let b__0 := __CPTR_EL2_ZEN
                                   if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                   then true
                                   else false : Bool) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))))
                                      else (do writeReg ZCR_EL1 (Mk_ZCR_EL1_Type (← (X_read t 64))))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then
                            (do (if ((__CPTR_EL3_EZ == 0#1) : Bool)
                                then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))
                                else (do writeReg ZCR_EL1 (Mk_ZCR_EL1_Type (← (X_read t 64))))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ZCR_EL2_SysRegWrite_bd0a9b879ec59921 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_EZ ← (( do (pure (_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TZ ← (( do (pure (_get_CPTR_EL2_Type_TZ (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_ZEN ← (( do (pure (_get_CPTR_EL2_Type_ZEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TZ == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_ZEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x19#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_EZ == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))))
                                      else (do writeReg ZCR_EL2 (Mk_ZCR_EL2_Type (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_EZ == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))
                          else (do writeReg ZCR_EL2 (Mk_ZCR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ZCR_EL3_SysRegWrite_8b6f2f3c0ab9da70 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CPTR_EL3_EZ ← (( do (pure (_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_EZ == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x19#8)))
                          else (do writeReg ZCR_EL3 (Mk_ZCR_EL3_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: k_read : Bool, t : Int -/
def AArch64_UnallocatedSysRegAccess (op0 : (BitVec 2)) (op1 : (BitVec 3)) (crn : (BitVec 4)) (op2 : (BitVec 3)) (crm : (BitVec 4)) (read : Bool) (t : Int) : SailM Unit := SailME.run do
  let rcs_el0_trap ← (( do (undefined_bool ()) ) : SailME Unit Bool )
  let tid3_trap : Bool := false
  let tid3_trap ← (( do
    (if ((←((pure (((← readReg PSTATE).EL == EL1) && read)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((_get_HCR_EL2_Type_TID3 (← readReg HCR_EL2)) == 1#1))))) : Bool)
    then
      (do (if ((← (HaveFGTExt ())) : Bool)
          then (do (pure true))
          else (do (__IMPDEF_boolean "Unallocated encodings trapped by HCR_EL2.TID3"))))
    else (do (pure tid3_trap))) ) : SailME Unit Bool )
  (if (((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL2)) <||> (do
           (pure ((← readReg PSTATE).EL == EL3)))))) && read) : Bool)
  then
    (do (if ((((op0 == 0b11#2) && (op1 == 0b000#3)) && (crn == 0b0000#4)) : Bool)
        then
          (do (if (((crm == 0b0010#4) && (op2 == 0b111#3)) : Bool)
              then
                (do (if (tid3_trap : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
              else
                (do (if (((crm == 0b0011#4) && ((op2 == 0b011#3) || ((op2 == 0b101#3) || ((op2 == 0b110#3) || (op2 == 0b111#3))))) : Bool)
                    then
                      (do (if (tid3_trap : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
                    else
                      (do (if (((crm == 0b0100#4) && ((op2 == 0b010#3) || ((op2 == 0b011#3) || ((op2 == 0b101#3) || ((op2 == 0b110#3) || (op2 == 0b111#3)))))) : Bool)
                          then
                            (do (if (tid3_trap : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
                          else
                            (do (if (((crm == 0b0101#4) && ((op2 == 0b010#3) || ((op2 == 0b011#3) || ((op2 == 0b110#3) || (op2 == 0b111#3))))) : Bool)
                                then
                                  (do (if (tid3_trap : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
                                else
                                  (do (if (((crm == 0b0110#4) && ((op2 == 0b010#3) || ((op2 == 0b011#3) || ((op2 == 0b100#3) || ((op2 == 0b101#3) || ((op2 == 0b110#3) || (op2 == 0b111#3))))))) : Bool)
                                      then
                                        (do (if (tid3_trap : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
                                      else
                                        (do (if (((crm == 0b0111#4) && ((op2 == 0b011#3) || ((op2 == 0b100#3) || ((op2 == 0b101#3) || ((op2 == 0b110#3) || (op2 == 0b111#3)))))) : Bool)
                                            then
                                              (do (if (tid3_trap : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else (do SailME.throw (← do (X_set t 64 (Zeros (n := 64)))))))
                                            else (do (pure ()))))))))))))))
        else (do (pure ()))))
  else (do (pure ())))
  let in_feature_space : Bool :=
    ((((op0 == 0b11#2) && (let b__1 := op1
          if (((Sail.BitVec.extractLsb b__1 2 1) == (0b00#2 : (BitVec 2))) : Bool)
          then true
          else
            (if ((b__1 == (0b011#3 : (BitVec 3))) : Bool)
            then true
            else false) : Bool)) && (crn == 0b0000#4)) && (let b__3 := crm
      if (((Sail.BitVec.extractLsb b__3 3 3) == (0#1 : (BitVec 1))) : Bool)
      then true
      else false : Bool))
  let ec_val : Int := (BitVec.toNat 0x0#4)
  let ec_val ← (( do
    (if ((← (HaveIDSExt ())) : Bool)
    then (do (pure (BitVec.toNat 0x18#8)))
    else (do (pure ec_val))) ) : SailME Unit Int )
  let ec_val := ec_val
  (if ((in_feature_space && read) : Bool)
  then
    (do (if (((← readReg PSTATE).EL == EL0) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (! (← (ELUsingAArch32 EL2))))) <&&> (do
                   (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 ec_val))
              else (do (AArch64_SystemAccessTrap EL1 ec_val))))
        else
          (do (if (((← readReg PSTATE).EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (! (← (ELUsingAArch32 EL2))))) <&&> (do
                         (pure ((_get_HCR_EL2_Type_TID3 (← readReg HCR_EL2)) == 1#1))))) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 ec_val))
                    else (do (AArch64_SystemAccessTrap EL1 ec_val))))
              else
                (do (if (((← readReg PSTATE).EL == EL2) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 ec_val))
                    else
                      (do (if (((← readReg PSTATE).EL == EL3) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 ec_val))
                          else (do (pure ()))))))))))
  else (do (pure ())))
  (if (((←((HaveFeatTIDCP1 ()) <&&> (do
         (pure ((← readReg PSTATE).EL == EL0))))) && (let b__0 := crn
       if ((((Sail.BitVec.extractLsb b__0 3 3) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
       then true
       else false : Bool)) : Bool)
  then
    (do (if ((←((pure (! (← (IsInHost ())))) <&&> (do
             (pure ((_get_SCTLR_EL1_Type_TIDCP (← readReg SCTLR_EL1)) == 1#1))))) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else (do (pure ())))
        (if ((←((IsInHost ()) <&&> (do
             (pure ((_get_SCTLR_EL2_Type_TIDCP (← readReg SCTLR_EL2)) == 1#1))))) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
           (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
           (EL2Enabled ())) <&&> (do
           (pure ((_get_HCR_EL2_Type_TIDCP (← readReg HCR_EL2)) == 1#1))))) && ((op0 == 0b01#2) || (op0 == 0b11#2))) && ((crn == 0b1011#4) || (crn == 0b1111#4))) : Bool)
  then
    (do let rcs_el0_trap ← (( do (__IMPDEF_boolean "Reserved Control Space EL0 Trapped") ) : SailME Unit Bool )
        (if ((((← readReg PSTATE).EL == EL1) || rcs_el0_trap) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((((BitVec.slice op0 0 2) == 0b01#2) || ((BitVec.slice op0 0 2) == 0b11#2)) && (((BitVec.slice crn 0 4) == 0b1011#4) || ((BitVec.slice crn 0 4) == 0b1111#4))) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "")))
  else (do (pure ())))
  let rcs_el0_trap := rcs_el0_trap
  sailThrow ((Error_Undefined ()))


end ArmASL.Functions
