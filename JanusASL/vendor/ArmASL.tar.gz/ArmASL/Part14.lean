import ArmASL.Part13

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def ICC_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_DIR_Type := value_name
  writeReg ICC_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_DIR r

def undefined_ICC_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR0 ) : SailM ICC_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR0_EL1) 0 32)))

def ICC_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR0_Type := value_name
  writeReg ICC_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR0 r

def undefined_ICC_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR1 ) : SailM ICC_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR1_EL1) 0 32)))

def ICC_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR1_Type := value_name
  writeReg ICC_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR1 r

def undefined_ICC_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR0 ) : SailM ICC_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR0_EL1) 0 32)))

def ICC_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR0_Type := value_name
  writeReg ICC_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR0 r

def undefined_ICC_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR1 ) : SailM ICC_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR1_EL1) 0 32)))

def ICC_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR1_Type := value_name
  writeReg ICC_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR1 r

def undefined_ICC_SRE_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HSRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HSRE ) : SailM ICC_HSRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL2) 0 32)))

def ICC_HSRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HSRE_Type := value_name
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HSRE r

def undefined_ICC_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR0 ) : SailM ICC_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR0_EL1) 0 32)))

def ICC_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR0_Type := value_name
  writeReg ICC_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR0 r

def undefined_ICC_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR1 ) : SailM ICC_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR1_EL1) 0 32)))

def ICC_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR1_Type := value_name
  writeReg ICC_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR1 r

def undefined_ICC_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN0 ) : SailM ICC_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN0_EL1) 0 32)))

def ICC_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN0_Type := value_name
  writeReg ICC_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN0 r

def undefined_ICC_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_NS ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_NS) 0 32)))

def ICC_IGRPEN1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_S ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_S) 0 32)))

def ICC_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_IGRPEN1_Type ()) ) : SailM ICC_IGRPEN1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_read ()))
  else (do (ICC_IGRPEN1_NS_read ())))

def ICC_IGRPEN1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_NS r

def ICC_IGRPEN1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_S r

def ICC_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_write r))
  else (do (ICC_IGRPEN1_NS_write r)))

def undefined_ICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_PMR ) : SailM ICC_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_PMR_EL1) 0 32)))

def ICC_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_PMR_Type := value_name
  writeReg ICC_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_PMR r

def undefined_ICC_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_RPR ) : SailM ICC_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_RPR_EL1) 0 32)))

def ICC_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_RPR_Type := value_name
  writeReg ICC_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_RPR r

def undefined_ICC_SGI0R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI0R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI0R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI0R ) : SailM ICC_SGI0R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI0R_EL1) 0 64)))

def ICC_SGI0R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI0R_Type := value_name
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI0R r

def undefined_ICC_SGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI1R ) : SailM ICC_SGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI1R_EL1) 0 64)))

def ICC_SGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI1R_Type := value_name
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI1R r

def undefined_ICC_SRE_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_SRE_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_NS ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_NS) 0 32)))

def ICC_SRE_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_S ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_S) 0 32)))

def ICC_SRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_SRE_Type ()) ) : SailM ICC_SRE_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_read ()))
  else (do (ICC_SRE_NS_read ())))

def ICC_SRE_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_NS r

def ICC_SRE_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_S r

def ICC_SRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_write r))
  else (do (ICC_SRE_NS_write r)))

def undefined_ICH_EISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_EISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_EISR ) : SailM ICH_EISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_EISR_EL2) 0 32)))

def ICH_EISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_EISR_Type := value_name
  writeReg ICH_EISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_EISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_EISR r

def undefined_ICH_ELRSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_ELRSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_ELRSR ) : SailM ICH_ELRSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_ELRSR_EL2) 0 32)))

def ICH_ELRSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_ELRSR_Type := value_name
  writeReg ICH_ELRSR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_ELRSR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_ELRSR r

def undefined_ICH_HCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_HCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_HCR ) : SailM ICH_HCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_HCR_EL2) 0 32)))

def ICH_HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_HCR_Type := value_name
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_HCR r

def undefined_ICH_MISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_MISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_MISR ) : SailM ICH_MISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_MISR_EL2) 0 32)))

def ICH_MISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_MISR_Type := value_name
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_MISR r

def undefined_ICH_VMCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VMCR ) : SailM ICH_VMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VMCR_EL2) 0 32)))

def ICH_VMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VMCR_Type := value_name
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VMCR r

def undefined_ICH_VTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VTR ) : SailM ICH_VTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VTR_EL2) 0 32)))

def ICH_VTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VTR_Type := value_name
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VTR r

def undefined_ICV_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR0 ) : SailM ICV_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR0_EL1) 0 32)))

def ICV_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR0_Type := value_name
  writeReg ICV_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR0 r

def undefined_ICV_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR1 ) : SailM ICV_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR1_EL1) 0 32)))

def ICV_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR1_Type := value_name
  writeReg ICV_BPR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR1 r

def undefined_ICV_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_CTLR ) : SailM ICV_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_CTLR_EL1) 0 32)))

def ICV_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_CTLR_Type := value_name
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_CTLR r

def undefined_ICV_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_DIR ) : SailM ICV_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_DIR_EL1) 0 32)))

def ICV_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_DIR_Type := value_name
  writeReg ICV_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_DIR r

def undefined_ICV_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR0 ) : SailM ICV_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR0_EL1) 0 32)))

def ICV_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR0_Type := value_name
  writeReg ICV_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR0 r

def undefined_ICV_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR1 ) : SailM ICV_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR1_EL1) 0 32)))

def ICV_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR1_Type := value_name
  writeReg ICV_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR1 r

def undefined_ICV_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR0 ) : SailM ICV_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR0_EL1) 0 32)))

def ICV_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR0_Type := value_name
  writeReg ICV_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR0 r

def undefined_ICV_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR1 ) : SailM ICV_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR1_EL1) 0 32)))

def ICV_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR1_Type := value_name
  writeReg ICV_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR1 r

def undefined_ICV_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR0 ) : SailM ICV_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR0_EL1) 0 32)))

def ICV_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR0_Type := value_name
  writeReg ICV_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR0 r

def undefined_ICV_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR1 ) : SailM ICV_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR1_EL1) 0 32)))

def ICV_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR1_Type := value_name
  writeReg ICV_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR1 r

def undefined_ICV_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN0 ) : SailM ICV_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN0_EL1) 0 32)))

def ICV_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN0_Type := value_name
  writeReg ICV_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN0 r

def undefined_ICV_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN1 ) : SailM ICV_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN1_EL1) 0 32)))

def ICV_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN1_Type := value_name
  writeReg ICV_IGRPEN1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN1 r

def undefined_ICV_PMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_PMR ) : SailM ICV_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_PMR_EL1) 0 32)))

def ICV_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_PMR_Type := value_name
  writeReg ICV_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_PMR r

def undefined_ICV_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_RPR ) : SailM ICV_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_RPR_EL1) 0 32)))

def ICV_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_RPR_Type := value_name
  writeReg ICV_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_RPR r

def ID_AFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_AFR0 ) : SailM ID_AFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_AFR0_EL1) 0 32)))

def ID_AFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_AFR0_Type := value_name
  writeReg ID_AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_AFR0 r

def undefined_ID_DFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_DFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_DFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_DFR1 ) : SailM ID_DFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_DFR1_EL1) 0 32)))

def ID_DFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_DFR1_Type := value_name
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_DFR1 r

def undefined_ID_ISAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR0 ) : SailM ID_ISAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR0_EL1) 0 32)))

def ID_ISAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR0_Type := value_name
  writeReg ID_ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR0 r

def undefined_ID_ISAR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR5 ) : SailM ID_ISAR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR5_EL1) 0 32)))

def ID_ISAR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR5_Type := value_name
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR5 r

def undefined_ID_MMFR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR5 ) : SailM ID_MMFR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR5_EL1) 0 32)))

def ID_MMFR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR5_Type := value_name
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR5 r

def undefined_ID_PFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR2 ) : SailM ID_PFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR2_EL1) 0 32)))

def ID_PFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR2_Type := value_name
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR2 r

def IFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _IFSR_NS ) : SailM IFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg IFSR32_EL2) 0 32)))

def IFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_IFSR_Type ()) ) : SailM IFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg IFSR_S)
  else (do (IFSR_NS_read ())))

def undefined_ISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ISR ) : SailM ISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ISR_EL1) 0 32)))

def ISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ISR_Type := value_name
  writeReg ISR_EL1 (Sail.BitVec.updateSubrange (← readReg ISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ISR r

def undefined_MPIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MPIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MPIDR ) : SailM MPIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MPIDR_EL1) 0 32)))

def MPIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MPIDR_Type := value_name
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MPIDR r

def undefined_MVFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR2 ) : SailM MVFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR2_EL1) 0 32)))

def MVFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR2_Type := value_name
  writeReg MVFR2_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR2 r

def Mk_AMCFGR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCGCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENCLR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENCLR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENSET0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENSET1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMUSERENR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CCSIDR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CCSIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHCTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHPS_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHVS_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHV_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTV_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CSSELR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGAUTHSTATUS_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGCLAIMCLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGCLAIMSET_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGDCCINT_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGDRAR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_DBGVCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ERRIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ERRSELR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HRMR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HSTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HTCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HTRFCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_ASGI1R_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_BPR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_BPR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_CTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_DIR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_EOIR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_EOIR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v


end ArmASL.Functions
