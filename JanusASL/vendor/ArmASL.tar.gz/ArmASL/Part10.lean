import ArmASL.Part09

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: N : Nat, List.elem N [32, 64, 128] -/
def AArch64_S2Walk (fault_in : FaultRecord) (ipa : AddressDescriptor) (walkparams : S2TTWParams) (accdesc : AccessDescriptor) (s1level : (Option Int)) (N : Nat) : SailM (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) := SailME.run do
  let fault : FaultRecord := fault_in
  let ipa_64 : (BitVec 64) := (Sail.BitVec.zeroExtend ipa.paddress.address 64)
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBContext )
  let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
  let (fault, tlbcontext, tlbrecord) ← (( do
    (if ((← readReg __tlb_enabled) : Bool)
    then
      (do let tlbcontext ← (AArch64_GetS2TLBContext accdesc.ss ipa.paddress walkparams.tgx)
          let tlbentry ← (( do (S2TLBLookup tlbcontext) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBLine )
          let tlbrecord : TLBRecord := tlbentry.tlbrecord
          let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx tlbrecord.walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
          let (fault, tlbrecord) ← (( do
            (if (((←((pure tlbentry.valid_name) <&&> (do
                   (pure (! (← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx))))))) && (! ((((((walkparams.ha +++ walkparams.hd) == 0b11#2) && ((walkparams.s2pie == 1#1) || (((BitVec.access tlbrecord.s2descriptor 51) : BitVec 1) == 1#1))) && (((BitVec.access tlbrecord.s2descriptor 7) : BitVec 1) == 0#1)) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))))) : Bool)
            then
              (do let a__1500 ← (( do
                    let tlbrecord ← (( do
                      (if ((walkparams.fwb == 1#1) : Bool)
                      then
                        (do let tlbrecord ← (pure { tlbrecord with walkstate := (← do (pure { tlbrecord.walkstate with memattrs := (← do (AArch64_S2ApplyFWBMemAttrs ipa.memattrs walkparams tlbrecord.s2descriptor)) })) })
                            (if (((Sail.BitVec.extractLsb tlbrecord.s2descriptor 5 3) == 0b111#3) : Bool)
                            then (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 1#1 } } }))
                            else (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 0#1 } } }))))
                      else (do (pure tlbrecord))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                    let fault : FaultRecord := { fault with level := tlbrecord.walkstate.level }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), tlbrecord.walkstate, (Sail.BitVec.extractLsb tlbrecord.s2descriptor (N -i 1) 0))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                  SailME.throw a__1500)
            else (do (pure (fault, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBRecord) )
          (pure (fault, tlbcontext, tlbrecord)))
    else (do (pure (fault, tlbcontext, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBContext × TLBRecord) )
  let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let walkstate ← (( do
    (if ((BEq.beq accdesc.ss SS_Secure) : Bool)
    then (do (AArch64_SS2InitialTTWState walkparams ipa.paddress.paspace))
    else (do (AArch64_S2InitialTTWState accdesc.ss walkparams))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let startlevel := walkstate.level
  let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
  let walkaccess ← (( do (CreateAccDescS2TTW accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
  let walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let skl : (BitVec 2) := 0b00#2
  let walkaddress : AddressDescriptor := { walkaddress with vaddress := ipa.vaddress }
  let walkaddress ← (pure { walkaddress with mecid := (← do (AArch64_TTWalkMECID walkparams.emec Regime_EL10 accdesc.ss)) })
  let walkaddress ← (( do
    (if (((_get_HCR_EL2_Type_CD (← readReg HCR_EL2)) == 1#1) : Bool)
    then
      (do let walkaddress ← (pure { walkaddress with memattrs := (← do (NormalNCMemAttr ())) })
          (pure { walkaddress with memattrs := { walkaddress.memattrs with xs := walkstate.memattrs.xs } }))
    else (do (pure { walkaddress with memattrs := walkstate.memattrs }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let walkaddress : AddressDescriptor := { walkaddress with memattrs := { walkaddress.memattrs with shareability := (EffectiveShareability walkaddress.memattrs) } }
  let walkaddress : AddressDescriptor := { walkaddress with tlbcontext := tlbcontext }
  let desctype ← (( do (undefined_DescriptorType ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) DescriptorType )
  let descaddress ← (( do (AArch64_S2SLTTEntryAddress walkparams ipa.paddress.address walkstate.baseaddress) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
  (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
        let fault : FaultRecord := { fault with level := 0 }
        (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
  else
    (do let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) ← (( do
          let mut loop_vars := (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate)
          repeat
            let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) := loop_vars
            loop_vars ← do
              let fault : FaultRecord := { fault with level := walkstate.level }
              let walkaddress : AddressDescriptor := { walkaddress with paddress := descaddress }
              let translation_info ← (( do
                (pure { regime := Regime_EL10
                        vmid := (← do
                          (pure (some (← (VMID_read ())))))
                        asid := none
                        va := walkaddress.vaddress
                        s1level := s1level
                        s2info := (some (ipa_64, walkstate.level))
                        s1params := none
                        s2params := (some walkparams)
                        memattrs := walkaddress.memattrs }) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TranslationInfo )
              let (descriptor, fault) ← (( do
                let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee walkaddress walkaccess fault N translation_info)
                let fault : FaultRecord := tup__0
                let descriptor : (BitVec N) := tup__1
                (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
              let (descaddress, descriptor, desctype, fault, skl, walkstate) ← (( do
                (if ((bne fault.statuscode Fault_None) : Bool)
                then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                else
                  (do let new_descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                      let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) ← (( do
                        let mut loop_vars_1 := (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate)
                        repeat
                          let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) := loop_vars_1
                          loop_vars_1 ← do
                            let new_descriptor : (BitVec N) := descriptor
                            let desctype ← (AArch64_DecodeDescriptorType descriptor walkparams.d128 walkparams.ds walkparams.tgx walkstate.level)
                            let (descaddress, fault, new_descriptor, skl, walkstate) ← (( do
                              match desctype with
                              | .DescriptorType_Table =>
                                (do
                                  let walkstate ← (AArch64_S2NextWalkStateTable walkstate walkparams descriptor)
                                  let skl ←
                                    (if ((walkparams.d128 == 1#1) : Bool)
                                    then
                                      (do sail_assert (110 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27115.49-27115.50"
                                          (pure (Sail.BitVec.extractLsb descriptor 110 109)))
                                    else (do (pure 0b00#2)))
                                  let descaddress ← (AArch64_TTEntryAddress walkstate.level walkparams.d128 skl walkparams.tgx walkparams.txsz ipa_64 walkstate.baseaddress)
                                  let (fault, new_descriptor) ← (( do
                                    (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                    then
                                      (do let a__1497 ← (( do
                                            let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
                                            (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                          SailME.throw a__1497)
                                    else
                                      (do let new_descriptor : (BitVec N) :=
                                            if ((walkparams.haft == 1#1) : Bool)
                                            then (BitVec.update new_descriptor 10 (Bit 1#1))
                                            else new_descriptor
                                          let fault ← (( do
                                            (if ((←((pure ((walkparams.d128 == 1#1) && (skl != 0b00#2))) <&&> (do
                                                 (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                                            then
                                              (do let a__1498 ← (( do
                                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                  SailME.throw a__1498)
                                            else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                                          (pure (fault, new_descriptor)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × (BitVec N)) )
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Leaf =>
                                (do
                                  sail_assert (52 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27133.44-27133.45"
                                  let walkstate ← (AArch64_S2NextWalkStateLeaf walkstate accdesc.ss walkparams ipa descriptor)
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Invalid =>
                                (do
                                  let a__1499 ← (( do
                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                  SailME.throw a__1499) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                            let (descriptor, fault) ← (( do
                              (if ((new_descriptor != descriptor) : Bool)
                              then
                                (do let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                                    sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27146.50-27146.51"
                                    let (descriptor, fault) ← (( do
                                      let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_descriptor walkparams.ee descaccess walkaddress translation_info)
                                      let fault : FaultRecord := tup__0
                                      let descriptor : (BitVec N) := tup__1
                                      (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                                    (if ((bne fault.statuscode Fault_None) : Bool)
                                    then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                    else (do (pure ())))
                                    (pure (descriptor, fault)))
                              else (do (pure (descriptor, fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                            (pure (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate))
                        until (λ (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) => (new_descriptor == descriptor)) loop_vars_1
                        (pure loop_vars_1) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                      (pure (descaddress, descriptor, desctype, fault, skl, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × TTWState) )
              (pure (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate))
          until (λ (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) => (BEq.beq desctype DescriptorType_Leaf)) loop_vars
          (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × AddressDescriptor × TTWState) )
        let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
        let fault ← (( do
          (if ((←((pure (walkstate.contiguous == 1#1)) <&&> (do
               (AArch64_ContiguousBitFaults walkparams.d128 walkparams.txsz walkparams.tgx walkstate.level)))) : Bool)
          then (do (pure { fault with statuscode := Fault_Translation }))
          else
            (do (if ((←((pure ((BEq.beq desctype DescriptorType_Leaf) && (walkstate.level <b FINAL_LEVEL))) <&&> (do
                     (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                then (do (pure { fault with statuscode := Fault_Translation }))
                else
                  (do (if ((← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                      then (do (pure { fault with statuscode := Fault_AddressSize }))
                      else
                        (do (if ((←((pure ((((BitVec.access descriptor 10) : BitVec 1) == 0#1) && (walkparams.ha == 0#1))) <&&> (do
                                 (pure (! (←((pure ((BEq.beq accdesc.acctype AccessType_DC) || (BEq.beq accdesc.acctype AccessType_IC))) <&&> (do (pure (! (← (__IMPDEF_boolean "Generate access flag fault on IC/DC operations")))))))))))) : Bool)
                            then (do (pure { fault with statuscode := Fault_AccessFlag }))
                            else (do (pure fault))))))))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
        (if ((((← readReg __tlb_enabled) && (BEq.beq fault.statuscode Fault_None)) && (((BitVec.access descriptor 10) : BitVec 1) == 1#1)) : Bool)
        then
          (do let tlbcontext : TLBContext := { tlbcontext with xs := walkstate.memattrs.xs }
              let tlbcontext : TLBContext := { tlbcontext with level := walkstate.level }
              let tlbcontext : TLBContext := { tlbcontext with isd128 := (walkparams.d128 == 1#1) }
              let tlbrecord : TLBRecord := { tlbrecord with context := tlbcontext }
              let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
              let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
              let tlbrecord ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (127 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27174.39-27174.40"
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.extractLsb descriptor 127 0) }))
                else
                  (do sail_assert (63 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27177.38-27177.39"
                      let tlbrecord : TLBRecord := { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 63 0 (Sail.BitVec.extractLsb descriptor 63 0)) }
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 127 64 (Zeros (n := 64))) }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              let tlbrecord ← (( do
                (if ((walkstate.contiguous == 1#1) : Bool)
                then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                else (do (pure { tlbrecord with contigsize := 0 }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              (pure (S2TLBCache tlbrecord)))
        else (do (pure ())))
        (pure (fault, walkaddress, walkstate, descriptor))))

def AArch64_SettingAccessFlagPermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if (((BEq.beq fault.statuscode Fault_Alignment) || (BEq.beq fault.statuscode Fault_Permission)) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_AFUPDATE))
        else (do (pure false)))))

def AArch64_SettingDirtyStatePermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if ((BEq.beq fault.statuscode Fault_Alignment) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_DBUPDATE))
        else (do (pure false)))))

/-- Type quantifiers: k_aligned : Bool, k_s1aarch64 : Bool -/
def AArch64_S2Translate (fault_in : FaultRecord) (ipa : AddressDescriptor) (s1aarch64 : Bool) (s1level : (Option Int)) (aligned : Bool) (accdesc : AccessDescriptor) : SailM (FaultRecord × AddressDescriptor) := SailME.run do
  let walkparams ← (( do (AArch64_GetS2TTWParams accdesc.ss ipa.paddress.paspace s1aarch64) ) : SailME (FaultRecord × AddressDescriptor) S2TTWParams )
  let fault : FaultRecord := fault_in
  let s2fs1mro ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault : FaultRecord := { fault with secondstage := true }
  let fault : FaultRecord := { fault with s2fs1walk := (BEq.beq accdesc.acctype AccessType_TTW) }
  let fault : FaultRecord := { fault with ipaddress := ipa.paddress }
  (if ((walkparams.vm != 1#1) : Bool)
  then (do (pure (fault, ipa)))
  else
    (do let s2mintxsz ← (( do (AArch64_S2MinTxSZ walkparams.d128 walkparams.ds walkparams.tgx s1aarch64) ) : SailME (FaultRecord × AddressDescriptor) Int )
        let s2maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        (if ((← (AArch64_S2TxSZFaults walkparams s1aarch64)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
        else
          (do let walkparams : S2TTWParams :=
                if (((BitVec.toNat walkparams.txsz) <b s2mintxsz) : Bool)
                then { walkparams with txsz := (integer_subrange s2mintxsz 5 0) }
                else
                  (if (((BitVec.toNat walkparams.txsz) >b s2maxtxsz) : Bool)
                  then { walkparams with txsz := (integer_subrange s2maxtxsz 5 0) }
                  else walkparams)
              (if ((←((pure (walkparams.d128 == 0#1)) <&&> (do
                   (AArch64_S2InvalidSL walkparams) <||> (do
                     (AArch64_S2InconsistentSL walkparams))))) : Bool)
              then
                (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                    let fault : FaultRecord := { fault with level := 0 }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
              else
                (do (if ((AArch64_IPAIsOutOfRange ipa.paddress.address walkparams) : Bool)
                    then
                      (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                          let fault : FaultRecord := { fault with level := 0 }
                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                    else
                      (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                          let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor) TTWState )
                          let descriptor ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let new_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let mem_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) ← (( do
                            let mut loop_vars := (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate)
                            repeat
                              let (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) := loop_vars
                              loop_vars ← do
                                let (descpaddr, descriptor, fault, walkstate) ← (( do
                                  (if ((walkparams.d128 == 1#1) : Bool)
                                  then
                                    (do let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S2Walk fault ipa walkparams accdesc s1level 128)
                                        let fault : FaultRecord := tup__0
                                        let descpaddr : AddressDescriptor := tup__1
                                        let walkstate : TTWState := tup__2
                                        let descriptor : (BitVec 128) := tup__3
                                        (pure (descpaddr, descriptor, fault, walkstate)))
                                  else
                                    (do let (descpaddr, descriptor, fault, walkstate) ← (( do
                                          let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S2Walk fault ipa walkparams accdesc s1level 64)
                                          let fault : FaultRecord := tup__0
                                          let descpaddr : AddressDescriptor := tup__1
                                          let walkstate : TTWState := tup__2
                                          let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 63 0 tup__3)
                                          (pure (descpaddr, descriptor, fault, walkstate)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                        let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 127 64 (Zeros (n := 64)))
                                        (pure (descpaddr, descriptor, fault, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                let (fault, mem_desc, new_desc, s2fs1mro) ← (( do
                                  (if ((bne fault.statuscode Fault_None) : Bool)
                                  then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                  else
                                    (do let fault ← (( do
                                          (if ((← (AArch64_S2HasAlignmentFault accdesc aligned walkstate.memattrs)) : Bool)
                                          then (do (pure { fault with statuscode := Fault_Alignment }))
                                          else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                        let (fault, s2fs1mro) ← (( do
                                          (if ((BEq.beq fault.statuscode Fault_None) : Bool)
                                          then
                                            (do let (tup__0, tup__1) ← do (AArch64_S2CheckPermissions fault walkstate walkparams ipa accdesc)
                                                let fault : FaultRecord := tup__0
                                                let s2fs1mro : Bool := tup__1
                                                (pure (fault, s2fs1mro)))
                                          else (do (pure (fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × Bool) )
                                        let new_desc : (BitVec 128) := descriptor
                                        let new_desc ← (( do
                                          (if ((←((pure (walkparams.ha == 1#1)) <&&> (do
                                               (AArch64_SettingAccessFlagPermitted fault)))) : Bool)
                                          then (do (pure (BitVec.update new_desc 10 (Bit 1#1))))
                                          else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                        let new_desc ← (( do
                                          (if (((((((← (AArch64_SettingDirtyStatePermitted fault)) && (walkparams.ha == 1#1)) && (walkparams.hd == 1#1)) && ((walkparams.s2pie == 1#1) || (((BitVec.access descriptor 51) : BitVec 1) == 1#1))) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))) : Bool)
                                          then (do (pure (BitVec.update new_desc 7 (Bit 1#1))))
                                          else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                        let (fault, mem_desc) ← (( do
                                          (if ((new_desc != descriptor) : Bool)
                                          then
                                            (do let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor) AccessDescriptor )
                                                let translation_info ← (( do
                                                  (pure { regime := Regime_EL10
                                                          vmid := (← do
                                                            (pure (some (← (VMID_read ())))))
                                                          asid := none
                                                          va := ipa.vaddress
                                                          s1level := s1level
                                                          s2info := (some ((Sail.BitVec.zeroExtend ipa.paddress.address 64), walkstate.level))
                                                          s1params := none
                                                          s2params := (some walkparams)
                                                          memattrs := walkstate.memattrs }) ) : SailME (FaultRecord × AddressDescriptor) TranslationInfo )
                                                let (fault, mem_desc) ← (( do
                                                  (if ((walkparams.d128 == 1#1) : Bool)
                                                  then
                                                    (do let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_desc walkparams.ee descaccess descpaddr translation_info)
                                                        let fault : FaultRecord := tup__0
                                                        let mem_desc : (BitVec 128) := tup__1
                                                        (pure (fault, mem_desc)))
                                                  else
                                                    (do let (fault, mem_desc) ← (( do
                                                          let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault (Sail.BitVec.extractLsb descriptor 63 0) (Sail.BitVec.extractLsb new_desc 63 0) walkparams.ee descaccess descpaddr translation_info)
                                                          let fault : FaultRecord := tup__0
                                                          let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 63 0 tup__1)
                                                          (pure (fault, mem_desc)) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                        let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 127 64 (Zeros (n := 64)))
                                                        (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                (pure (fault, mem_desc)))
                                          else (do (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                        (pure (fault, mem_desc, new_desc, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128) × (BitVec 128) × Bool) )
                                (pure (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate))
                            until (λ (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) => ((new_desc == descriptor) || (mem_desc == new_desc))) loop_vars
                            (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × TTWState) )
                          (if ((((← readReg __tlb_enabled) && (new_desc != descriptor)) && (((BitVec.access mem_desc 10) : BitVec 1) == 1#1)) : Bool)
                          then
                            (do let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                let tlbrecord ← (( do
                                  (if ((((BitVec.access descriptor 10) : BitVec 1) == 1#1) : Bool)
                                  then
                                    (do let tlbentry ← (( do (S2TLBLookup descpaddr.tlbcontext) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
                                        sail_assert tlbentry.valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:27304.38-27304.39"
                                        (pure tlbentry.tlbrecord))
                                  else
                                    (do let tlbrecord : TLBRecord := { tlbrecord with context := descpaddr.tlbcontext }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with xs := walkstate.memattrs.xs } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with level := walkstate.level } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with includes_s2_name := true } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with isd128 := (walkparams.d128 == 1#1) } }
                                        let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                                        let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                                        (if ((walkstate.contiguous == 1#1) : Bool)
                                        then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                                        else (do (pure { tlbrecord with contigsize := 0 }))))) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                let tlbrecord : TLBRecord :=
                                  if ((walkparams.d128 == 1#1) : Bool)
                                  then { tlbrecord with s2descriptor := mem_desc }
                                  else
                                    (let tlbrecord : TLBRecord := { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 63 0 (Sail.BitVec.extractLsb mem_desc 63 0)) }
                                    { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 127 64 (Zeros (n := 64))) })
                                (pure (S2TLBCache tlbrecord)))
                          else (do (pure ())))
                          (if ((bne fault.statuscode Fault_None) : Bool)
                          then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                          else
                            (do let ipa_64 : (BitVec 64) := (Sail.BitVec.zeroExtend ipa.paddress.address 64)
                                let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor) FullAddress )
                                let s2_memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let s2_memattrs ← (( do
                                  (if ((←((pure (((BEq.beq accdesc.acctype AccessType_TTW) && (BEq.beq walkstate.memattrs.memtype MemType_Device)) && (walkparams.ptw == 0#1))) <||> (do
                                       (pure (BEq.beq accdesc.acctype AccessType_IFETCH)) <&&> (do
                                         (pure (BEq.beq walkstate.memattrs.memtype MemType_Device)) <||> (do
                                           (pure ((_get_HCR_EL2_Type_ID (← readReg HCR_EL2)) == 1#1))))) <||> (do
                                       (pure ((bne accdesc.acctype AccessType_IFETCH) && (BEq.beq walkstate.memattrs.memtype MemType_Normal))) <&&> (do
                                         (pure ((_get_HCR_EL2_Type_CD (← readReg HCR_EL2)) == 1#1)))))) : Bool)
                                  then
                                    (do let s2_memattrs ← (NormalNCMemAttr ())
                                        (pure { s2_memattrs with xs := walkstate.memattrs.xs }))
                                  else (do (pure walkstate.memattrs))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let fault ← (( do
                                  (if ((accdesc.ls64 && (BEq.beq s2_memattrs.memtype MemType_Normal)) : Bool)
                                  then
                                    (do (if (((s2_memattrs.inner.attrs != MemAttr_NC) || (s2_memattrs.outer.attrs != MemAttr_NC)) : Bool)
                                        then
                                          (do let a__1491 ← (( do
                                                let fault : FaultRecord := { fault with statuscode := Fault_Exclusive }
                                                (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × AddressDescriptor) )
                                              SailME.throw a__1491)
                                        else (do (pure fault))))
                                  else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                let s2aarch64 : Bool := true
                                let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let memattrs ← (( do
                                  (if ((walkparams.fwb == 0#1) : Bool)
                                  then (do (S2CombineS1MemAttrs ipa.memattrs s2_memattrs s2aarch64))
                                  else (do (pure s2_memattrs))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let pa ← (( do (CreateAddressDescriptor ipa.vaddress oa memattrs) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                let pa : AddressDescriptor := { pa with tlbcontext := descpaddr.tlbcontext }
                                let pa : AddressDescriptor := { pa with s2fs1mro := s2fs1mro }
                                let pa ← (pure { pa with mecid := (← do (AArch64_S2OutputMECID walkparams pa.paddress.paspace descriptor)) })
                                (pure (fault, pa))))))))))))

def S1TLBCache (tlbrecord : TLBRecord) : Unit :=
  ()

def S1TLBLookup (tlbcontext : TLBContext) : SailM TLBLine := do
  (__UNKNOWN_TLBLine ())

/-- Type quantifiers: N : Nat, 10 < N -/
def AArch64_S1Walk (fault_in : FaultRecord) (walkparams : S1TTWParams) (va : (BitVec 64)) (regime : Regime) (accdesc : AccessDescriptor) (N : Nat) : SailM (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) := SailME.run do
  let fault : FaultRecord := fault_in
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) Bool )
  let aligned ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) Bool )
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBContext )
  let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
  let (fault, tlbcontext, tlbrecord) ← (( do
    (if ((← readReg __tlb_enabled) : Bool)
    then
      (do let tlbcontext ← (AArch64_GetS1TLBContext regime accdesc.ss va walkparams.tgx)
          let tlbentry ← (( do (S1TLBLookup tlbcontext) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBLine )
          let tlbrecord : TLBRecord := tlbentry.tlbrecord
          let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx tlbrecord.walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
          let fault ← (( do
            (if (((←((pure tlbentry.valid_name) <&&> (do
                   (pure (! (← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx))))))) && (! ((((((walkparams.ha +++ walkparams.hd) == 0b11#2) && ((walkparams.pie == 1#1) || (((BitVec.access tlbrecord.s1descriptor 51) : BitVec 1) == 1#1))) && (((BitVec.access tlbrecord.s1descriptor 7) : BitVec 1) == 1#1)) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))))) : Bool)
            then
              (do let a__1485 ← (( do
                    let fault : FaultRecord := { fault with level := tlbrecord.walkstate.level }
                    sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27381.59-27381.60"
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), tlbrecord.walkstate, (Sail.BitVec.extractLsb tlbrecord.s1descriptor (N -i 1) 0))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                  SailME.throw a__1485)
            else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
          (pure (fault, tlbcontext, tlbrecord)))
    else (do (pure (fault, tlbcontext, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBContext × TLBRecord) )
  (if ((←((pure (HasUnprivileged regime)) <&&> (do
       (pure ((← (AArch64_S1EPD regime va)) == 1#1))))) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
        let fault : FaultRecord := { fault with level := 0 }
        (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
  else
    (do let walkstate ← (( do (AArch64_S1InitialTTWState walkparams va regime accdesc.ss) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
        let startlevel := walkstate.level
        let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
        let walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let skl : (BitVec 2) := 0b00#2
        let walkaddress : AddressDescriptor := { walkaddress with vaddress := va }
        let walkaddress ← (pure { walkaddress with mecid := (← do (AArch64_TTWalkMECID walkparams.emec regime accdesc.ss)) })
        let walkaddress ← (( do
          (if ((! (← (AArch64_S1DCacheEnabled regime))) : Bool)
          then
            (do let walkaddress ← (pure { walkaddress with memattrs := (← do (NormalNCMemAttr ())) })
                (pure { walkaddress with memattrs := { walkaddress.memattrs with xs := walkstate.memattrs.xs } }))
          else (do (pure { walkaddress with memattrs := walkstate.memattrs }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let walkaddress ← (( do
          (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))) <&&> (do
               (pure (! (← (__IMPDEF_boolean "Apply effective shareability at stage 1"))))))) : Bool)
          then (do (pure { walkaddress with memattrs := { walkaddress.memattrs with shareability := walkstate.memattrs.shareability } }))
          else (do (pure { walkaddress with memattrs := { walkaddress.memattrs with shareability := (EffectiveShareability walkaddress.memattrs) } }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let walkaddress : AddressDescriptor := { walkaddress with tlbcontext := tlbcontext }
        let s2fs1mro : Bool := false
        let desctype ← (( do (undefined_DescriptorType ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) DescriptorType )
        let descaddress ← (( do (AArch64_S1SLTTEntryAddress walkstate.level walkparams va walkstate.baseaddress) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
        (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
        else
          (do let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) ← (( do
                let mut loop_vars := (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate)
                repeat
                  let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) := loop_vars
                  loop_vars ← do
                    let fault : FaultRecord := { fault with level := walkstate.level }
                    let walkaddress : AddressDescriptor := { walkaddress with paddress := descaddress }
                    let toplevel : Bool := (walkstate.level == startlevel)
                    let varange : VARange := (AArch64_GetVARange va)
                    let walkaccess ← (( do (CreateAccDescS1TTW toplevel varange accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                    let translation_info : TranslationInfo :=
                      { regime := regime
                        vmid := none
                        asid := none
                        va := walkaddress.vaddress
                        s1level := (some walkstate.level)
                        s2info := none
                        s1params := (some walkparams)
                        s2params := none
                        memattrs := walkaddress.memattrs }
                    let s2fault ← (( do (undefined_FaultRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                    let s2walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
                    let (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro) ← (( do
                      (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                           (EL2Enabled ())))) : Bool)
                      then
                        (do let s1aarch64 : Bool := true
                            let aligned : Bool := true
                            let (s2fault, s2walkaddress) ← (( do
                              let (tup__0, tup__1) ← do (AArch64_S2Translate fault walkaddress s1aarch64 (some walkstate.level) aligned walkaccess)
                              let s2fault : FaultRecord := tup__0
                              let s2walkaddress : AddressDescriptor := tup__1
                              (pure (s2fault, s2walkaddress)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor) )
                            let (descriptor, fault, s2fs1mro) ← (( do
                              (if ((bne s2fault.statuscode Fault_None) : Bool)
                              then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                              else
                                (do let s2fs1mro : Bool := s2walkaddress.s2fs1mro
                                    sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27445.50-27445.51"
                                    let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee s2walkaddress walkaccess fault N translation_info)
                                    let fault : FaultRecord := tup__0
                                    let descriptor : (BitVec N) := tup__1
                                    (pure (descriptor, fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord × Bool) )
                            (pure (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro)))
                      else
                        (do sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27448.50-27448.51"
                            let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee walkaddress walkaccess fault N translation_info)
                            let fault : FaultRecord := tup__0
                            let descriptor : (BitVec N) := tup__1
                            (pure (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × (BitVec N) × FaultRecord × Bool × FaultRecord × Bool) )
                    let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, skl, walkstate) ← (( do
                      (if ((bne fault.statuscode Fault_None) : Bool)
                      then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                      else
                        (do let new_descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                            let (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) ← (( do
                              let mut loop_vars_1 := (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate)
                              repeat
                                let (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) := loop_vars_1
                                loop_vars_1 ← do
                                  let new_descriptor : (BitVec N) := descriptor
                                  let desctype ← (AArch64_DecodeDescriptorType descriptor walkparams.d128 walkparams.ds walkparams.tgx walkstate.level)
                                  let (descaddress, fault, new_descriptor, skl, walkstate) ← (( do
                                    match desctype with
                                    | .DescriptorType_Table =>
                                      (do
                                        let walkstate ← (AArch64_S1NextWalkStateTable walkstate s2fs1mro regime walkparams descriptor)
                                        let skl ←
                                          (if ((walkparams.d128 == 1#1) : Bool)
                                          then
                                            (do sail_assert (110 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27462.49-27462.50"
                                                (pure (Sail.BitVec.extractLsb descriptor 110 109)))
                                          else (do (pure 0b00#2)))
                                        let descaddress ← (AArch64_TTEntryAddress walkstate.level walkparams.d128 skl walkparams.tgx walkparams.txsz va walkstate.baseaddress)
                                        let (fault, new_descriptor) ← (( do
                                          (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                          then
                                            (do let a__1482 ← (( do
                                                  let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
                                                  (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                SailME.throw a__1482)
                                          else
                                            (do let new_descriptor ← (( do
                                                  (if ((walkparams.haft == 1#1) : Bool)
                                                  then
                                                    (do sail_assert (10 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27471.48-27471.49"
                                                        (pure (BitVec.update new_descriptor 10 (Bit 1#1))))
                                                  else (do (pure new_descriptor))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                                                let fault ← (( do
                                                  (if ((←((pure ((walkparams.d128 == 1#1) && (skl != 0b00#2))) <&&> (do
                                                       (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                                                  then
                                                    (do let a__1483 ← (( do
                                                          let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                        SailME.throw a__1483)
                                                  else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                                                (pure (fault, new_descriptor)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × (BitVec N)) )
                                        (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                                    | .DescriptorType_Leaf =>
                                      (do
                                        let walkstate ← (AArch64_S1NextWalkStateLeaf walkstate s2fs1mro regime accdesc.ss walkparams descriptor)
                                        (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                                    | .DescriptorType_Invalid =>
                                      (do
                                        let a__1484 ← (( do
                                          let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                        SailME.throw a__1484) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                                  let (aligned, descriptor, fault, s1aarch64, s2fault) ← (( do
                                    (if ((new_descriptor != descriptor) : Bool)
                                    then
                                      (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
                                          let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                                          let (aligned, descpaddr, s1aarch64, s2fault) ← (( do
                                            (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                 (EL2Enabled ())))) : Bool)
                                            then
                                              (do let s1aarch64 : Bool := true
                                                  let aligned : Bool := true
                                                  let (descpaddr, s2fault) ← (( do
                                                    let (tup__0, tup__1) ← do (AArch64_S2Translate fault walkaddress s1aarch64 (some walkstate.level) aligned descaccess)
                                                    let s2fault : FaultRecord := tup__0
                                                    let descpaddr : AddressDescriptor := tup__1
                                                    (pure (descpaddr, s2fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (AddressDescriptor × FaultRecord) )
                                                  (if ((bne s2fault.statuscode Fault_None) : Bool)
                                                  then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                                  else (do (pure ())))
                                                  (pure (aligned, descpaddr, s1aarch64, s2fault)))
                                            else
                                              (do let descpaddr : AddressDescriptor := walkaddress
                                                  (pure (aligned, descpaddr, s1aarch64, s2fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × AddressDescriptor × Bool × FaultRecord) )
                                          sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27505.50-27505.51"
                                          let (descriptor, fault) ← (( do
                                            let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_descriptor walkparams.ee descaccess descpaddr translation_info)
                                            let fault : FaultRecord := tup__0
                                            let descriptor : (BitVec N) := tup__1
                                            (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                                          (if ((bne fault.statuscode Fault_None) : Bool)
                                          then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                          else (do (pure ())))
                                          (pure (aligned, descriptor, fault, s1aarch64, s2fault)))
                                    else (do (pure (aligned, descriptor, fault, s1aarch64, s2fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × (BitVec N) × FaultRecord × Bool × FaultRecord) )
                                  (pure (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate))
                              until (λ (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) => (new_descriptor == descriptor)) loop_vars_1
                              (pure loop_vars_1) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec N) × Bool × FaultRecord × (BitVec 2) × TTWState) )
                            (pure (aligned, descaddress, descriptor, desctype, fault, s1aarch64, skl, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × Bool × (BitVec 2) × TTWState) )
                    (pure (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate))
                until (λ (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) => (BEq.beq desctype DescriptorType_Leaf)) loop_vars
                (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × Bool × Bool × (BitVec 2) × AddressDescriptor × TTWState) )
              let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
              let fault ← (( do
                (if ((←((pure (walkstate.contiguous == 1#1)) <&&> (do
                     (AArch64_ContiguousBitFaults walkparams.d128 walkparams.txsz walkparams.tgx walkstate.level)))) : Bool)
                then (do (pure { fault with statuscode := Fault_Translation }))
                else
                  (do (if ((←((pure ((BEq.beq desctype DescriptorType_Leaf) && (walkstate.level <b FINAL_LEVEL))) <&&> (do
                           (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                      then (do (pure { fault with statuscode := Fault_Translation }))
                      else
                        (do sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27521.42-27521.43"
                            (if ((← (AArch64_S1AMECFault walkparams walkstate.baseaddress.paspace regime descriptor)) : Bool)
                            then (do (pure { fault with statuscode := Fault_Translation }))
                            else
                              (do (if ((← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_AddressSize }))
                                  else
                                    (do (if ((←((pure ((((BitVec.access descriptor 10) : BitVec 1) == 0#1) && (walkparams.ha == 0#1))) <&&> (do
                                             (pure (! (←((pure ((BEq.beq accdesc.acctype AccessType_DC) || (BEq.beq accdesc.acctype AccessType_IC))) <&&> (do (pure (! (← (__IMPDEF_boolean "Generate access flag fault on IC/DC operations")))))))))))) : Bool)
                                        then (do (pure { fault with statuscode := Fault_AccessFlag }))
                                        else (do (pure fault))))))))))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
              (if ((bne fault.statuscode Fault_None) : Bool)
              then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
              else
                (do (if ((((← readReg __tlb_enabled) && (BEq.beq fault.statuscode Fault_None)) && (((BitVec.access descriptor 10) : BitVec 1) == 1#1)) : Bool)
                    then
                      (do let tlbcontext : TLBContext := { tlbcontext with xs := walkstate.memattrs.xs }
                          let tlbcontext : TLBContext := { tlbcontext with level := walkstate.level }
                          let tlbcontext : TLBContext := { tlbcontext with nG := walkstate.nG }
                          let tlbcontext : TLBContext := { tlbcontext with isd128 := (walkparams.d128 == 1#1) }
                          let tlbrecord : TLBRecord := { tlbrecord with context := tlbcontext }
                          let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                          let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                          let tlbrecord ← (( do
                            (if ((walkparams.d128 == 1#1) : Bool)
                            then
                              (do sail_assert (127 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27542.39-27542.40"
                                  (pure { tlbrecord with s1descriptor := (Sail.BitVec.extractLsb descriptor 127 0) }))
                            else
                              (do sail_assert (63 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27545.38-27545.39"
                                  let tlbrecord : TLBRecord := { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 63 0 (Sail.BitVec.extractLsb descriptor 63 0)) }
                                  (pure { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 127 64 (Zeros (n := 64))) }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                          let tlbrecord ← (( do
                            (if ((walkstate.contiguous == 1#1) : Bool)
                            then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                            else (do (pure { tlbrecord with contigsize := 0 }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                          (pure (S1TLBCache tlbrecord)))
                    else (do (pure ())))
                    (pure (fault, walkaddress, walkstate, descriptor))))))))

def AArch64_VAIsOutOfRange (va_in : (BitVec 64)) (acctype : AccessType) (regime : Regime) (walkparams : S1TTWParams) : Bool :=
  let va : (BitVec 64) := va_in
  let addrtop := (AArch64_AddrTop walkparams.tbid acctype walkparams.tbi)
  let va : (BitVec 64) :=
    if ((walkparams.mtx == 1#1) : Bool)
    then
      (Sail.BitVec.updateSubrange va 59 56
        (if ((BEq.beq (AArch64_GetVARange va) VARange_UPPER) : Bool)
        then 0b1111#4
        else 0b0000#4))
    else va
  let iasize := (AArch64_IASize walkparams.txsz)
  if ((addrtop <b iasize) : Bool)
  then false
  else
    (if ((HasUnprivileged regime) : Bool)
    then
      (if ((BEq.beq (AArch64_GetVARange va) VARange_LOWER) : Bool)
      then (! (is_zero_subrange va addrtop iasize))
      else (! (is_ones_subrange va addrtop iasize)))
    else (! (is_zero_subrange va addrtop iasize)))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S1Translate (fault_in : FaultRecord) (regime : Regime) (va : (BitVec 64)) (aligned : Bool) (accdesc : AccessDescriptor) : SailM (FaultRecord × AddressDescriptor) := SailME.run do
  let descaccess ← (( do (undefined_AccessDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AccessDescriptor )
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let s2aligned ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let tlbentry ← (( do (undefined_TLBLine ()) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
  let fault : FaultRecord := fault_in
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  (if ((! (← (AArch64_S1Enabled regime accdesc.acctype))) : Bool)
  then (do (AArch64_S1DisabledOutput fault regime va accdesc aligned))
  else
    (do let walkparams ← (( do (AArch64_GetS1TTWParams regime accdesc.ss va) ) : SailME (FaultRecord × AddressDescriptor) S1TTWParams )
        let s1mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        let s1maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        (if ((← (AArch64_S1TxSZFaults regime walkparams)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
        else
          (do let walkparams : S1TTWParams :=
                if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
                then { walkparams with txsz := (integer_subrange s1mintxsz 5 0) }
                else
                  (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
                  then { walkparams with txsz := (integer_subrange s1maxtxsz 5 0) }
                  else walkparams)
              (if ((AArch64_VAIsOutOfRange va accdesc.acctype regime walkparams) : Bool)
              then
                (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                    let fault : FaultRecord := { fault with level := 0 }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
              else
                (do (if (((accdesc.el == EL0) && (walkparams.e0pd == 1#1)) : Bool)
                    then
                      (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                          let fault : FaultRecord := { fault with level := 0 }
                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                    else
                      (do (if (((((← (HaveTME ())) && (accdesc.el == EL0)) && (walkparams.nfd == 1#1)) && accdesc.transactional) : Bool)
                          then
                            (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                let fault : FaultRecord := { fault with level := 0 }
                                (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                          else
                            (do (if (((((← (HaveSVE ())) && (accdesc.el == EL0)) && (walkparams.nfd == 1#1)) && ((accdesc.nonfault && accdesc.contiguous) || ((accdesc.firstfault && (! accdesc.first)) && (! accdesc.contiguous)))) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                      let fault : FaultRecord := { fault with level := 0 }
                                      (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                                else
                                  (do let descipaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                      let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor) TTWState )
                                      let descriptor ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let new_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let mem_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) ← (( do
                                        let mut loop_vars := (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate)
                                        repeat
                                          let (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) := loop_vars
                                          loop_vars ← do
                                            let (descipaddr, descriptor, fault, walkstate) ← (( do
                                              (if ((walkparams.d128 == 1#1) : Bool)
                                              then
                                                (do let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S1Walk fault walkparams va regime accdesc 128)
                                                    let fault : FaultRecord := tup__0
                                                    let descipaddr : AddressDescriptor := tup__1
                                                    let walkstate : TTWState := tup__2
                                                    let descriptor : (BitVec 128) := tup__3
                                                    (pure (descipaddr, descriptor, fault, walkstate)))
                                              else
                                                (do let (descipaddr, descriptor, fault, walkstate) ← (( do
                                                      let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S1Walk fault walkparams va regime accdesc 64)
                                                      let fault : FaultRecord := tup__0
                                                      let descipaddr : AddressDescriptor := tup__1
                                                      let walkstate : TTWState := tup__2
                                                      let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 63 0 tup__3)
                                                      (pure (descipaddr, descriptor, fault, walkstate)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                                    let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 127 64 (Zeros (n := 64)))
                                                    (pure (descipaddr, descriptor, fault, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                            let (descaccess, fault, mem_desc, new_desc, s1aarch64, s2aligned) ← (( do
                                              (if ((bne fault.statuscode Fault_None) : Bool)
                                              then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                              else
                                                (do (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
                                                    then (do (SetInGuardedPage (walkstate.guardedpage == 1#1)))
                                                    else (do (pure ())))
                                                    let fault ← (( do
                                                      (if ((← (AArch64_S1HasAlignmentFault accdesc aligned walkparams.ntlsmd walkstate.memattrs)) : Bool)
                                                      then (do (pure { fault with statuscode := Fault_Alignment }))
                                                      else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                    let fault ← (( do
                                                      (if ((BEq.beq fault.statuscode Fault_None) : Bool)
                                                      then (do (AArch64_S1CheckPermissions fault regime walkstate walkparams accdesc))
                                                      else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                    let new_desc : (BitVec 128) := descriptor
                                                    let new_desc ← (( do
                                                      (if ((←((pure (walkparams.ha == 1#1)) <&&> (do
                                                           (AArch64_SettingAccessFlagPermitted fault)))) : Bool)
                                                      then (do (pure (BitVec.update new_desc 10 (Bit 1#1))))
                                                      else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                                    let new_desc ← (( do
                                                      (if (((((((← (AArch64_SettingDirtyStatePermitted fault)) && (walkparams.ha == 1#1)) && (walkparams.hd == 1#1)) && ((walkparams.pie == 1#1) || (((BitVec.access descriptor 51) : BitVec 1) == 1#1))) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))) : Bool)
                                                      then (do (pure (BitVec.update new_desc 7 (Bit 0#1))))
                                                      else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                                    let (descaccess, fault, mem_desc, s1aarch64, s2aligned) ← (( do
                                                      (if ((new_desc != descriptor) : Bool)
                                                      then
                                                        (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                                            let descaccess ← (CreateAccDescTTEUpdate accdesc)
                                                            let (descpaddr, s1aarch64, s2aligned) ← (( do
                                                              (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                                   (EL2Enabled ())))) : Bool)
                                                              then
                                                                (do let s2fault ← (( do (undefined_FaultRecord ()) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                                    let s1aarch64 : Bool := true
                                                                    let s2aligned : Bool := true
                                                                    let (descpaddr, s2fault) ← (( do
                                                                      let (tup__0, tup__1) ← do (AArch64_S2Translate fault descipaddr s1aarch64 none s2aligned descaccess)
                                                                      let s2fault : FaultRecord := tup__0
                                                                      let descpaddr : AddressDescriptor := tup__1
                                                                      (pure (descpaddr, s2fault)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × FaultRecord) )
                                                                    (if ((bne s2fault.statuscode Fault_None) : Bool)
                                                                    then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                                                    else (do (pure ())))
                                                                    (pure (descpaddr, s1aarch64, s2aligned)))
                                                              else
                                                                (do let descpaddr : AddressDescriptor := descipaddr
                                                                    (pure (descpaddr, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × Bool × Bool) )
                                                            let translation_info : TranslationInfo :=
                                                              { regime := regime
                                                                vmid := none
                                                                asid := none
                                                                va := va
                                                                s1level := (some walkstate.level)
                                                                s2info := none
                                                                s1params := (some walkparams)
                                                                s2params := none
                                                                memattrs := walkstate.memattrs }
                                                            let (fault, mem_desc) ← (( do
                                                              (if ((walkparams.d128 == 1#1) : Bool)
                                                              then
                                                                (do let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_desc walkparams.ee descaccess descpaddr translation_info)
                                                                    let fault : FaultRecord := tup__0
                                                                    let mem_desc : (BitVec 128) := tup__1
                                                                    (pure (fault, mem_desc)))
                                                              else
                                                                (do let (fault, mem_desc) ← (( do
                                                                      let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault (Sail.BitVec.extractLsb descriptor 63 0) (Sail.BitVec.extractLsb new_desc 63 0) walkparams.ee descaccess descpaddr translation_info)
                                                                      let fault : FaultRecord := tup__0
                                                                      let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 63 0 tup__1)
                                                                      (pure (fault, mem_desc)) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                                    let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 127 64 (Zeros (n := 64)))
                                                                    (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                            (pure (descaccess, fault, mem_desc, s1aarch64, s2aligned)))
                                                      else (do (pure (descaccess, fault, mem_desc, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × FaultRecord × (BitVec 128) × Bool × Bool) )
                                                    (pure (descaccess, fault, mem_desc, new_desc, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × Bool) )
                                            (pure (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate))
                                        until (λ (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) => ((new_desc == descriptor) || (mem_desc == new_desc))) loop_vars
                                        (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × AddressDescriptor × (BitVec 128) × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × Bool × TTWState) )
                                      (if ((((← readReg __tlb_enabled) && (new_desc != descriptor)) && (((BitVec.access mem_desc 10) : BitVec 1) == 1#1)) : Bool)
                                      then
                                        (do let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                            let tlbrecord ← (( do
                                              (if ((((BitVec.access descriptor 10) : BitVec 1) == 1#1) : Bool)
                                              then
                                                (do let tlbentry ← (( do (S1TLBLookup descipaddr.tlbcontext) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
                                                    sail_assert tlbentry.valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:27700.38-27700.39"
                                                    (pure tlbentry.tlbrecord))
                                              else
                                                (do let tlbrecord : TLBRecord := { tlbrecord with context := descipaddr.tlbcontext }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with xs := walkstate.memattrs.xs } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with level := walkstate.level } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with nG := walkstate.nG } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with isd128 := (walkparams.d128 == 1#1) } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                                                    let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                                                    (if ((walkstate.contiguous == 1#1) : Bool)
                                                    then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                                                    else (do (pure { tlbrecord with contigsize := 0 }))))) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                            let tlbrecord : TLBRecord :=
                                              if ((walkparams.d128 == 1#1) : Bool)
                                              then { tlbrecord with s1descriptor := mem_desc }
                                              else
                                                (let tlbrecord : TLBRecord := { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 63 0 (Sail.BitVec.extractLsb mem_desc 63 0)) }
                                                { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 127 64 (Zeros (n := 64))) })
                                            (pure (S1TLBCache tlbrecord)))
                                      else (do (pure ())))
                                      (if ((bne fault.statuscode Fault_None) : Bool)
                                      then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                                      else
                                        (do let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor) FullAddress )
                                            let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let memattrs ← (( do
                                              (if ((←((pure (BEq.beq accdesc.acctype AccessType_IFETCH)) <&&> (do
                                                   (pure (BEq.beq walkstate.memattrs.memtype MemType_Device)) <||> (do
                                                     (pure (! (← (AArch64_S1ICacheEnabled regime)))))))) : Bool)
                                              then
                                                (do let memattrs ← (NormalNCMemAttr ())
                                                    (pure { memattrs with xs := walkstate.memattrs.xs }))
                                              else
                                                (do (if (((←((pure (bne accdesc.acctype AccessType_IFETCH)) <&&> (do
                                                           (pure (! (← (AArch64_S1DCacheEnabled regime))))))) && (BEq.beq walkstate.memattrs.memtype MemType_Normal)) : Bool)
                                                    then
                                                      (do let memattrs ← (NormalNCMemAttr ())
                                                          let memattrs : MemoryAttributes := { memattrs with xs := walkstate.memattrs.xs }
                                                          (if ((←((pure ((← (HaveMTE2Ext ())) && (BEq.beq walkstate.memattrs.tags MemTag_AllocationTagged))) <&&> (do
                                                               (pure (! (← (ConstrainUnpredictableBool Unpredictable_S1CTAGGED))))))) : Bool)
                                                          then (do (pure { memattrs with tags := MemTag_Untagged }))
                                                          else (do (pure memattrs))))
                                                    else (do (pure walkstate.memattrs))))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let memattrs ← (( do
                                              (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                   (EL2Enabled ())) <&&> (do
                                                   (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))) <&&> (do
                                                   (pure (! (← (__IMPDEF_boolean "Apply effective shareability at stage 1"))))))) : Bool)
                                              then (do (pure { memattrs with shareability := walkstate.memattrs.shareability }))
                                              else (do (pure { memattrs with shareability := (EffectiveShareability memattrs) }))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let fault ← (( do
                                              (if ((accdesc.ls64 && (BEq.beq memattrs.memtype MemType_Normal)) : Bool)
                                              then
                                                (do (if (((memattrs.inner.attrs != MemAttr_NC) || (memattrs.outer.attrs != MemAttr_NC)) : Bool)
                                                    then
                                                      (do let a__1475 ← (( do
                                                            let fault : FaultRecord := { fault with statuscode := Fault_Exclusive }
                                                            (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × AddressDescriptor) )
                                                          SailME.throw a__1475)
                                                    else (do (pure fault))))
                                              else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                            let ipa ← (( do (CreateAddressDescriptor va oa memattrs) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                            let ipa : AddressDescriptor := { ipa with tlbcontext := descipaddr.tlbcontext }
                                            let ipa : AddressDescriptor := { ipa with s1assured := walkstate.s1assured }
                                            let varange : VARange := (AArch64_GetVARange va)
                                            let ipa ← (pure { ipa with mecid := (← do (AArch64_S1OutputMECID walkparams regime varange ipa.paddress.paspace descriptor)) })
                                            (pure (fault, ipa))))))))))))))))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_FullTranslate (va : (BitVec 64)) (accdesc : AccessDescriptor) (aligned : Bool) : SailM AddressDescriptor := do
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailM Bool )
  let regime ← (( do (TranslationRegime accdesc.el) ) : SailM Regime )
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let ipa ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let (fault, ipa) ← (( do
    let (tup__0, tup__1) ← do (AArch64_S1Translate fault regime va aligned accdesc)
    let fault : FaultRecord := tup__0
    let ipa : AddressDescriptor := tup__1
    (pure (fault, ipa)) ) : SailM (FaultRecord × AddressDescriptor) )
  (if ((bne fault.statuscode Fault_None) : Bool)
  then (do (CreateFaultyAddressDescriptor va fault))
  else
    (do sail_assert (implies (BEq.beq accdesc.ss SS_Realm) (← (EL2Enabled ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:27774.54-27774.55"
        (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do let s1aarch64 : Bool := true
              let pa ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
              let (fault, pa) ← (( do
                let (tup__0, tup__1) ← do (AArch64_S2Translate fault ipa s1aarch64 none aligned accdesc)
                let fault : FaultRecord := tup__0
                let pa : AddressDescriptor := tup__1
                (pure (fault, pa)) ) : SailM (FaultRecord × AddressDescriptor) )
              (if ((bne fault.statuscode Fault_None) : Bool)
              then (do (CreateFaultyAddressDescriptor va fault))
              else (do (pure pa))))
        else (do (pure ipa)))))

/-- Type quantifiers: counter_index : Nat, 0 ≤ counter_index ∨ (not (counter_index < 32)) -/
def SPEStartCounter (counter_index : Nat) : SailM Unit := do
  sail_assert (counter_index <b SPEMaxCounters) "sail-arm/arm-v9.4-a/src/v8_base.sail:27796.41-27796.42"
  writeReg SPESampleCounterPending (vectorUpdate (← readReg SPESampleCounterPending) counter_index true)

/-- Type quantifiers: counter_index : Nat, 0 ≤ counter_index ∧ counter_index < 32 -/
def SPEStopCounter (counter_index : Nat) : SailM Unit := do
  writeReg SPESampleCounterValid (vectorUpdate (← readReg SPESampleCounterValid) counter_index true)
  writeReg SPESampleCounterPending (vectorUpdate (← readReg SPESampleCounterPending) counter_index false)

def end_translation (desc : AddressDescriptor) : SailM Unit := do
  (sail_translation_end desc)

def start_translation (tsi : TranslationStartInfo) : SailM Unit := do
  (sail_translation_start tsi)

/-- Type quantifiers: k_aligned : Bool, size : Int -/
def AArch64_TranslateAddress (va : (BitVec 64)) (accdesc : AccessDescriptor) (aligned : Bool) (size : Int) : SailM AddressDescriptor := do
  (if (((← readReg SPESampleInFlight) && (! ((BEq.beq accdesc.acctype AccessType_IFETCH) || (BEq.beq accdesc.acctype AccessType_SPE)))) : Bool)
  then (do (SPEStartCounter SPECounterPosTranslationLatency))
  else (do (pure ())))
  let regime ← (( do (TranslationRegime accdesc.el) ) : SailM Regime )
  let tsi ← do (AArch64_GetTranslationStartInfo regime accdesc.ss accdesc va size)
  (start_translation tsi)
  let result ← (( do (AArch64_FullTranslate va accdesc aligned) ) : SailM AddressDescriptor )
  let result ← (( do
    (if (((! (IsFault result)) && (bne accdesc.acctype AccessType_IFETCH)) : Bool)
    then (do (pure { result with fault := (← do (AArch64_CheckDebug va accdesc size)) }))
    else (do (pure result))) ) : SailM AddressDescriptor )
  let result ← (( do
    (if ((←((pure ((← (HaveRME ())) && (! (IsFault result)))) <&&> (do
         (pure (bne accdesc.acctype AccessType_DC)) <||> (do
           (__IMPDEF_boolean "GPC Fault on DC operations"))))) : Bool)
    then
      (do let result ← (pure { result with fault := (← do (pure { result.fault with gpcf := (← do (GranuleProtectionCheck result accdesc)) })) })
          (if ((bne result.fault.gpcf.gpf GPCF_None) : Bool)
          then
            (do let result : AddressDescriptor := { result with fault := { result.fault with statuscode := Fault_GPCFOnOutput } }
                (pure { result with fault := { result.fault with paddress := result.paddress } }))
          else (do (pure result))))
    else (do (pure result))) ) : SailM AddressDescriptor )
  let result ← (( do
    (if (((! (IsFault result)) && (BEq.beq accdesc.acctype AccessType_IFETCH)) : Bool)
    then (do (pure { result with fault := (← do (AArch64_CheckDebug va accdesc size)) }))
    else (do (pure result))) ) : SailM AddressDescriptor )
  (if (((← readReg SPESampleInFlight) && (! ((BEq.beq accdesc.acctype AccessType_IFETCH) || (BEq.beq accdesc.acctype AccessType_SPE)))) : Bool)
  then (do (SPEStopCounter SPECounterPosTranslationLatency))
  else (do (pure ())))
  let result : AddressDescriptor := { result with vaddress := (Sail.BitVec.zeroExtend va 64) }
  (end_translation result)
  (pure result)

def MemHasTransactionalAccess (memattrs : MemoryAttributes) : SailM Bool := do
  (if ((((((((((BEq.beq memattrs.shareability Shareability_ISH) || (BEq.beq memattrs.shareability Shareability_OSH)) && (BEq.beq memattrs.memtype MemType_Normal)) && (memattrs.inner.attrs == MemAttr_WB)) && (memattrs.inner.hints == MemHint_RWA)) && (memattrs.inner.transient == false)) && (memattrs.outer.hints == MemHint_RWA)) && (memattrs.outer.attrs == MemAttr_WB)) && (memattrs.outer.transient == false)) : Bool)
  then (do (pure true))
  else (do (__IMPDEF_boolean "Memory Region does not support Transactional access")))

def CollectPhysicalAddress (_ : Unit) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (StatisticalProfilingEnabled ()))) : Bool)
  then (do (pure false))
  else
    (do let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        (if ((←((pure (HaveEL EL2)) <&&> (do
             (pure (bne owning_ss SS_Secure)) <||> (do
               (IsSecureEL2Enabled ()))))) : Bool)
        then (do (pure ((_get_PMSCR_EL2_Type_PA (← readReg PMSCR_EL2)) == 1#1)) <&&> (do (pure (owning_el == EL2)) <||> (do (pure ((_get_PMSCR_EL1_Type_PA (← readReg PMSCR_EL1)) == 1#1)))))
        else (do (pure ((_get_PMSCR_EL1_Type_PA (← readReg PMSCR_EL1)) == 1#1))))))

def SPESetDataPhysicalAddress (addrdesc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM Unit := do
  let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (ns, nse) ← (( do
    match addrdesc.paddress.paspace with
    | .PAS_Secure =>
      (let ns : (BitVec 1) := 0#1
      let nse : (BitVec 1) := 0#1
      (pure (ns, nse)))
    | .PAS_NonSecure =>
      (let ns : (BitVec 1) := 1#1
      let nse : (BitVec 1) := 0#1
      (pure (ns, nse)))
    | .PAS_Realm =>
      (let ns : (BitVec 1) := 1#1
      let nse : (BitVec 1) := 1#1
      (pure (ns, nse)))
    | _ =>
      (do
        (Unreachable ())
        (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
  (if ((← (HaveMTE2Ext ())) : Bool)
  then
    (do let pat ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
        let pat ← (( do
          (if (accdesc.tagchecked : Bool)
          then
            (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 62 (Bit 1#1)))
                (pure (AArch64_PhysicalTag addrdesc.vaddress)))
          else
            (do let zero_unchecked ← (( do (__IMPDEF_boolean "SPE PAT for tag unchecked access zero") ) : SailM Bool )
                (if ((! zero_unchecked) : Bool)
                then (do (pure (AArch64_PhysicalTag addrdesc.vaddress)))
                else (do (pure (Zeros (n := 4))))))) ) : SailM (BitVec 4) )
        writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 59 56 pat)))
  else (do (pure ())))
  let paddr : (BitVec 56) := addrdesc.paddress.address
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) (56 -i 1) 0 paddr))
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 63 (Bit ns)))
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 60 (Bit nse)))
  writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosDataPhysical true)

def SPESetDataVirtualAddress (vaddress : (BitVec 64)) : SailM Unit := do
  let tbi ← (( do (EffectiveTBI vaddress false (← readReg PSTATE).EL) ) : SailM (BitVec 1) )
  let non_tbi_is_zeros ← (( do (__IMPDEF_boolean "SPE non-tbi tag is zero") ) : SailM Bool )
  (if (((tbi == 1#1) || (! non_tbi_is_zeros)) : Bool)
  then (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 63 0 (Sail.BitVec.extractLsb vaddress 63 0))))
  else
    (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 63 56 (Zeros (n := 8))))
        writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 55 0 (Sail.BitVec.extractLsb vaddress 55 0)))))
  writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosDataVirtual true)

/-- Type quantifiers: k_is_load : Bool -/
def SPESampleLoadStore (is_load : Bool) (accdesc : AccessDescriptor) (addrdesc : AddressDescriptor) : SailM Unit := do
  (if (((BEq.beq accdesc.acctype AccessType_SPE) || ((BEq.beq accdesc.acctype AccessType_IFETCH) || ((BEq.beq accdesc.acctype AccessType_DC) || ((BEq.beq accdesc.acctype AccessType_TTW) || (BEq.beq accdesc.acctype AccessType_AT))))) : Bool)
  then (do (pure ()))
  else
    (do let sample_loads ← (( do (pure (((BitVec.access (← readReg SPESampleSubclass) 0) : BitVec 1) == 0#1)) <&&> (do readReg SPESampleSubclassValid) ) : SailM Bool )
        let sample_stores ← (( do (pure (((BitVec.access (← readReg SPESampleSubclass) 0) : BitVec 1) == 1#1)) <&&> (do readReg SPESampleSubclassValid) ) : SailM Bool )
        (if ((((! (← readReg SPESampleSubclassValid)) || (sample_loads && is_load)) || (sample_stores && (! is_load))) : Bool)
        then
          (do (SPESetDataVirtualAddress addrdesc.vaddress)
              (if ((← (CollectPhysicalAddress ())) : Bool)
              then (do (SPESetDataPhysicalAddress addrdesc accdesc))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((! (← readReg SPESampleSubclassValid)) : Bool)
        then
          (do writeReg SPESampleClass 0b01#2
              writeReg SPESampleSubclassValid true
              writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0001000#7)
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
                (Bit
                  (if (is_load : Bool)
                  then 0#1
                  else 1#1)))
              writeReg SPESampleOpType (if (is_load : Bool)
              then OpType_Load
              else OpType_Store)
              (if ((BEq.beq accdesc.acctype AccessType_NV2) : Bool)
              then
                (do writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0011000#7)
                    writeReg SPESampleInstIsNV2 true)
              else (do (pure ()))))
        else (do (pure ())))))

/-- Type quantifiers: k_aligned : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_read__1 (address : (BitVec 64)) (size : Nat) (accdesc_in : AccessDescriptor) (aligned : Bool) (ispair : Bool) : SailM (BitVec (size * 8)) := do
  sail_assert ((size == 1) || ((size == 2) || ((size == 4) || ((size == 8) || (size == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:27977.69-27977.70"
  let value_name ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let accdesc : AccessDescriptor := accdesc_in
  (if ((← (HaveLSE2Ext ())) : Bool)
  then (do sail_assert (← (AllInAlignedQuantity address size 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27981.54-27981.55")
  else (do sail_assert (IsAligned__1 address size) "sail-arm/arm-v9.4-a/src/v8_base.sail:27983.42-27983.43"))
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := true
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  let atomic ← (( do (undefined_bool ()) ) : SailM Bool )
  let atomic ← (( do
    (if ((((BEq.beq memaddrdesc.memattrs.memtype MemType_Normal) && (memaddrdesc.memattrs.inner.attrs == MemAttr_WB)) && (memaddrdesc.memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then (do (pure true))
    else
      (do (if (((((accdesc.exclusive || accdesc.atomicop) || accdesc.acqsc) || accdesc.acqpc) || accdesc.relsc) : Bool)
          then
            (do (if ((←((pure (! aligned)) <&&> (do
                     (pure (! (← (ConstrainUnpredictableBool Unpredictable_MISALIGNEDATOMIC))))))) : Bool)
                then
                  (do (AArch64_Abort address (← (AlignmentFault accdesc)))
                      (pure atomic))
                else (do (pure true))))
          else
            (do (if (aligned : Bool)
                then (do (pure (! ispair)))
                else (do (__IMPDEF_boolean "FEAT_LSE2: access is atomic"))))))) ) : SailM Bool )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  (if (atomic : Bool)
  then
    (do let (memstatus, value_name) ← (( do
          let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc size accdesc none)
          let memstatus : PhysMemRetStatus := tup__0
          let value_name : (BitVec (size * 8)) := tup__1
          (pure (memstatus, value_name)) ) : SailM (PhysMemRetStatus × (BitVec (size * 8))) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalReadAbort memstatus memaddrdesc size accdesc))
        else (do (pure ())))
        (pure value_name))
  else
    (do (if ((aligned && ispair) : Bool)
        then
          (do sail_assert ((size == 8) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28031.37-28031.38"
              let halfsize := (Int.ediv size 2)
              let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let (lowhalf, memstatus) ← (( do
                let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc halfsize accdesc none)
                let memstatus : PhysMemRetStatus := tup__0
                let lowhalf : (BitVec (halfsize * 8)) := tup__1
                (pure (lowhalf, memstatus)) ) : SailM ((BitVec (halfsize * 8)) × PhysMemRetStatus) )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalReadAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address halfsize) } }
              let (highhalf, memstatus) ← (( do
                let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc halfsize accdesc none)
                let memstatus : PhysMemRetStatus := tup__0
                let highhalf : (BitVec (halfsize * 8)) := tup__1
                (pure (highhalf, memstatus)) ) : SailM ((BitVec (halfsize * 8)) × PhysMemRetStatus) )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalReadAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              (pure (highhalf +++ lowhalf)))
        else
          (do let (memaddrdesc, memstatus, value_name) ← (( do
                let loop_i_lower := 0
                let loop_i_upper := (size -i 1)
                let mut loop_vars := (memaddrdesc, memstatus, value_name)
                for i in [loop_i_lower:loop_i_upper:1]i do
                  let (memaddrdesc, memstatus, value_name) := loop_vars
                  loop_vars ← do
                    let (memstatus, value_name) ← (( do
                      let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc 1 accdesc none)
                      let memstatus : PhysMemRetStatus := tup__0
                      let value_name : (BitVec (size * 8)) := (Sail.BitVec.updateSubrange value_name ((8 *i i) +i 7) (8 *i i) tup__1)
                      (pure (memstatus, value_name)) ) : SailM (PhysMemRetStatus × (BitVec (size * 8))) )
                    (if ((IsFault__2 memstatus) : Bool)
                    then (do (HandleExternalReadAbort memstatus memaddrdesc 1 accdesc))
                    else (do (pure ())))
                    let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
                    (pure (memaddrdesc, memstatus, value_name))
                (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus × (BitVec (size * 8))) )
              (pure value_name)))))

/-- Type quantifiers: k_aligned : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_read (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (aligned : Bool) : SailM (BitVec (size * 8)) := do
  let ispair : Bool := false
  (AArch64_MemSingle_read__1 address size accdesc aligned ispair)

/-- Type quantifiers: processorid : Int, size : Int -/
def ClearExclusiveByAddress (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: k_aligned : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_set__1 (address : (BitVec 64)) (size : Nat) (accdesc_in : AccessDescriptor) (aligned : Bool) (ispair : Bool) (value_name : (BitVec (size * 8))) : SailM Unit := do
  sail_assert ((size == 1) || ((size == 2) || ((size == 4) || ((size == 8) || (size == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28072.69-28072.70"
  let accdesc : AccessDescriptor := accdesc_in
  (if ((← (HaveLSE2Ext ())) : Bool)
  then (do sail_assert (← (AllInAlignedQuantity address size 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28075.54-28075.55")
  else (do sail_assert (IsAligned__1 address size) "sail-arm/arm-v9.4-a/src/v8_base.sail:28077.42-28077.43"))
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  let _ : Unit :=
    if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
    then (ClearExclusiveByAddress memaddrdesc.paddress (ProcessorID ()) size)
    else ()
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := false
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let atomic ← (( do (undefined_bool ()) ) : SailM Bool )
  let atomic ← (( do
    (if ((((BEq.beq memaddrdesc.memattrs.memtype MemType_Normal) && (memaddrdesc.memattrs.inner.attrs == MemAttr_WB)) && (memaddrdesc.memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then (do (pure true))
    else
      (do (if (((((accdesc.exclusive || accdesc.atomicop) || accdesc.acqsc) || accdesc.acqpc) || accdesc.relsc) : Bool)
          then
            (do (if ((←((pure (! aligned)) <&&> (do
                     (pure (! (← (ConstrainUnpredictableBool Unpredictable_MISALIGNEDATOMIC))))))) : Bool)
                then
                  (do (AArch64_Abort address (← (AlignmentFault accdesc)))
                      (pure atomic))
                else (do (pure true))))
          else
            (do (if (aligned : Bool)
                then (do (pure (! ispair)))
                else (do (__IMPDEF_boolean "FEAT_LSE2: access is atomic"))))))) ) : SailM Bool )
  (if (atomic : Bool)
  then
    (do let memstatus ← (( do (PhysMemWrite memaddrdesc size accdesc none value_name) ) : SailM PhysMemRetStatus )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc size accdesc))
        else (do (pure ()))))
  else
    (do (if ((aligned && ispair) : Bool)
        then
          (do sail_assert ((size == 8) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28128.37-28128.38"
              let halfsize := (Int.ediv size 2)
              let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                (highhalf, lowhalf)
              let memstatus ← (( (PhysMemWrite memaddrdesc halfsize accdesc none lowhalf) ) : SailM PhysMemRetStatus )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address halfsize) } }
              let memstatus ← (( do (PhysMemWrite memaddrdesc halfsize accdesc none highhalf) ) : SailM PhysMemRetStatus )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ()))))
        else
          (do let (memaddrdesc, memstatus) ← (( do
                let loop_i_lower := 0
                let loop_i_upper := (size -i 1)
                let mut loop_vars := (memaddrdesc, memstatus)
                for i in [loop_i_lower:loop_i_upper:1]i do
                  let (memaddrdesc, memstatus) := loop_vars
                  loop_vars ← do
                    let memstatus ← (PhysMemWrite memaddrdesc 1 accdesc none (Sail.BitVec.extractLsb value_name ((8 *i i) +i 7) (8 *i i)))
                    (if ((IsFault__2 memstatus) : Bool)
                    then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
                    else (do (pure ())))
                    let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
                    (pure (memaddrdesc, memstatus))
                (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
              (pure ())))))

/-- Type quantifiers: k_aligned : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_set (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (aligned : Bool) (value_name : (BitVec (size * 8))) : SailM Unit := do
  let ispair : Bool := false
  (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name)

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def Mem_read__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) : SailM (BitVec (size * 8)) := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let halfsize := (Int.ediv size 2)
  let value_name ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
    then
      (do let lowhalf ← (( do (AArch64_MemSingle_read__1 address halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          let highhalf ← (( do (AArch64_MemSingle_read__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          (pure (highhalf +++ lowhalf)))
    else
      (do (if ((←((HaveLSE2Ext ()) <&&> (do
               (AllInAlignedQuantity address size 16)))) : Bool)
          then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
          else
            (do (if ((ispair && aligned) : Bool)
                then
                  (do sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28194.52-28194.53"
                      let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let (highhalf, lowhalf) ← (( do
                        (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                        then
                          (do let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))
                        else
                          (do let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))) ) : SailM ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) )
                      (pure (highhalf +++ lowhalf)))
                else
                  (do (if (aligned : Bool)
                      then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
                      else
                        (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28208.23-28208.24"
                            sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28209.52-28209.53"
                            let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                            then
                              (do let highhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_1 := highhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let highhalf := loop_vars_1
                                      loop_vars_1 ← do (pure (Sail.BitVec.updateSubrange highhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned))))
                                    (pure loop_vars_1) ) : SailM (BitVec (halfsize * 8)) )
                                  let lowhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_2 := lowhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let lowhalf := loop_vars_2
                                      loop_vars_2 ← do (pure (Sail.BitVec.updateSubrange lowhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                    (pure loop_vars_2) ) : SailM (BitVec (halfsize * 8)) )
                                  (pure (highhalf +++ lowhalf)))
                            else
                              (do let value_name ← (pure (Sail.BitVec.updateSubrange value_name 7 0 (← (AArch64_MemSingle_read address 1 accdesc aligned))))
                                  let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                  sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28223.63-28223.64"
                                  let aligned : Bool :=
                                    if ((BEq.beq c Constraint_NONE) : Bool)
                                    then true
                                    else aligned
                                  let loop_i_lower := 1
                                  let loop_i_upper := (size -i 1)
                                  let mut loop_vars := value_name
                                  for i in [loop_i_lower:loop_i_upper:1]i do
                                    let value_name := loop_vars
                                    loop_vars ← do (pure (Sail.BitVec.updateSubrange value_name ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                  (pure loop_vars))))))))))) ) : SailM (BitVec (size * 8)) )
  (if ((← (BigEndian accdesc.acctype)) : Bool)
  then (do (pure (reverse_endianness value_name)))
  else (do (pure value_name)))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_read (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) : SailM (BitVec (size * 8)) := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28168.48-28168.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_read__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) : SailM (BitVec (size * 8)) := do
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28174.48-28174.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let joinedpair ← (( do (undefined_bool ()) ) : SailM Bool )
  let halfsize := (Int.ediv size 2)
  let value_name : (BitVec (size * 8)) := value_in_name
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then
      (do sail_assert (((size *i 8) == 8) || (((size *i 8) == 16) || (((size *i 8) == 32) || (((size *i 8) == 64) || ((size *i 8) == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28271.116-28271.117"
          (pure (reverse_endianness value_name)))
    else (do (pure value_name))) ) : SailM (BitVec (size * 8)) )
  (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
  then
    (do sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28275.27-28275.28"
        let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
          let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 127 64)
          let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 63 0)
          (highhalf, lowhalf)
        (AArch64_MemSingle_set__1 address halfsize accdesc aligned ispair lowhalf)
        (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair highhalf))
  else
    (do (if ((←((HaveLSE2Ext ()) <&&> (do
             (AllInAlignedQuantity address size 16)))) : Bool)
        then
          (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28282.52-28282.53"
              (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
        else
          (do (if ((ispair && aligned) : Bool)
              then
                (do let joinedpair : Bool := false
                    sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28286.27-28286.28"
                    let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28289.69-28289.70"
                    let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                      let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                      let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                      (highhalf, lowhalf)
                    (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                    then
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28292.60-28292.61"
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf)
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf))
                    else
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28296.60-28296.61"
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf)
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf))))
              else
                (do (if (aligned : Bool)
                    then
                      (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28301.52-28301.53"
                          (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
                    else
                      (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28304.23-28304.24"
                          let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                          then
                            (do sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28308.73-28308.74"
                                let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                                  let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                                  let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                                  (highhalf, lowhalf)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_1 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_1
                                  loop_vars_1 ← do (AArch64_MemSingle_set (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned (Sail.BitVec.extractLsb highhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_1)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_2 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_2
                                  loop_vars_2 ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb lowhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_2))
                          else
                            (do (AArch64_MemSingle_set address 1 accdesc aligned (Sail.BitVec.extractLsb value_name 7 0))
                                let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28319.63-28319.64"
                                let aligned : Bool :=
                                  if ((BEq.beq c Constraint_NONE) : Bool)
                                  then true
                                  else aligned
                                let loop_i_lower := 1
                                let loop_i_upper := (size -i 1)
                                let mut loop_vars := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars
                                  loop_vars ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb value_name ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars)))))))))))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_set (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_size : Nat, k_size ≥ 0 -/
def MemAtomic (address : (BitVec 64)) (cmpoperand : (BitVec k_size)) (operand : (BitVec k_size)) (accdesc_in : AccessDescriptor) : SailM (BitVec k_size) := do
  sail_assert accdesc_in.atomicop "sail-arm/arm-v9.4-a/src/v8_base.sail:28335.30-28335.31"
  let bytes := (Int.ediv (Sail.BitVec.length operand) 8)
  sail_assert ((bytes == 1) || ((bytes == 2) || ((bytes == 4) || ((bytes == 8) || (bytes == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28337.74-28337.75"
  let newvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let oldvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let accdesc : AccessDescriptor := accdesc_in
  let aligned : Bool := (IsAligned__1 address bytes)
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address bytes)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned (Sail.BitVec.length operand)) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  let _ : Unit :=
    if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
    then (ClearExclusiveByAddress memaddrdesc.paddress (ProcessorID ()) (Sail.BitVec.length operand))
    else ()
  (if ((←((pure ((← (HaveMTE2Ext ())) && accdesc.tagchecked)) <&&> (do
       (pure (! (← (HaveMTEStoreOnlyExt ())))) <||> (do
         (pure (! (← (StoreOnlyTagCheckingEnabled accdesc.el)))))))) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert ((8 *i bytes) == (Sail.BitVec.length operand)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28363.42-28363.43"
  let (memstatus, oldvalue) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc bytes accdesc none)
    let memstatus : PhysMemRetStatus := tup__0
    let oldvalue : (BitVec k_size) := tup__1
    (pure (memstatus, oldvalue)) ) : SailM (PhysMemRetStatus × (BitVec k_size)) )
  (if ((IsFault__2 memstatus) : Bool)
  then (do (HandleExternalReadAbort memstatus memaddrdesc bytes accdesc))
  else (do (pure ())))
  let oldvalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (reverse_endianness oldvalue)))
    else (do (pure oldvalue))) ) : SailM (BitVec k_size) )
  let oldvalue := oldvalue
  let cmpfail : Bool := false
  let (cmpfail, newvalue) : (Bool × (BitVec k_size)) :=
    match accdesc.modop with
    | .MemAtomicOp_ADD =>
      (let newvalue : (BitVec k_size) := (oldvalue + operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_BIC =>
      (let newvalue : (BitVec k_size) := (oldvalue &&& (Complement.complement operand))
      (cmpfail, newvalue))
    | .MemAtomicOp_EOR =>
      (let newvalue : (BitVec k_size) := (oldvalue ^^^ operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_ORR =>
      (let newvalue : (BitVec k_size) := (oldvalue ||| operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SWP =>
      (let newvalue : (BitVec k_size) := operand
      (cmpfail, newvalue))
    | .MemAtomicOp_CAS =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
    | .MemAtomicOp_GCSSS1 =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
  let accdesc ← (( do
    (if ((←((HaveMTEStoreOnlyExt ()) <&&> (do
         (StoreOnlyTagCheckingEnabled accdesc.el)))) : Bool)
    then
      (do let accdesc ← (( do
            (if ((accdesc.tagchecked && cmpfail) : Bool)
            then (do (pure { accdesc with tagchecked := (← do (ConstrainUnpredictableBool Unpredictable_STOREONLYTAGCHECKEDCAS)) }))
            else (do (pure accdesc))) ) : SailM AccessDescriptor )
          (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
          then
            (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
                (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
                then
                  (do let accdesc : AccessDescriptor := { accdesc with read := false }
                      (AArch64_TagCheckFault address accdesc)
                      (pure accdesc))
                else (do (pure accdesc))))
          else (do (pure accdesc))))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((! cmpfail) : Bool)
  then
    (do let newvalue ← (( do
          (if ((← (BigEndian accdesc.acctype)) : Bool)
          then (do (pure (reverse_endianness newvalue)))
          else (do (pure newvalue))) ) : SailM (BitVec k_size) )
        let memstatus ← (( do (PhysMemWrite memaddrdesc bytes accdesc none newvalue) ) : SailM PhysMemRetStatus )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc bytes accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := false
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  (pure oldvalue)

def undefined_RCWMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def undefined_RCWSMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def AArch64_AllocationTagFromAddress (tagged_address : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb tagged_address 59 56)

def PhysMemTagWrite (desc : AddressDescriptor) (accdesc : AccessDescriptor) (data : (BitVec 4)) : SailM PhysMemRetStatus := do
  (undefined_PhysMemRetStatus ())

def undefined_VNCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

/-- Type quantifiers: size : Int -/
def AArch64_DataMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let accdesc : AccessDescriptor := accdesc_in
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagaccess) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked vaddress accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let aligned : Bool := true
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  let (memaddrdesc, memstatus) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (size -i 1)
    let mut loop_vars := (memaddrdesc, memstatus)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (memaddrdesc, memstatus) := loop_vars
      loop_vars ← do
        (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
        then
          (do let ptag : (BitVec 4) := (AArch64_PhysicalTag vaddress)
              (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
              then
                (do (if ((← (__IMPDEF_boolean "DC_ZVA tag fault reported with lowest faulting address")) : Bool)
                    then (do (AArch64_TagCheckFault vaddress accdesc))
                    else (do (AArch64_TagCheckFault regval accdesc))))
              else (do (pure ()))))
        else (do (pure ())))
        let memstatus ← (PhysMemWrite memaddrdesc 1 accdesc none (Zeros (n := 8)))
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
        else (do (pure ())))
        let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
        (pure (memaddrdesc, memstatus))
    (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
  (pure ())

/-- Type quantifiers: size : Int -/
def AArch64_TagMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert (accdesc_in.tagaccess && (! accdesc_in.tagchecked)) "sail-arm/arm-v9.4-a/src/v8_base.sail:29013.65-29013.66"
  let accdesc : AccessDescriptor := accdesc_in
  let count := (Int.shiftr size LOG2_TAG_GRANULE)
  let tag : (BitVec 4) := (AArch64_AllocationTagFromAddress vaddress)
  let aligned : Bool := (IsAligned__1 vaddress TAG_GRANULE)
  (if ((! aligned) : Bool)
  then (do (AArch64_Abort vaddress (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let accdesc ← (( do
    (if ((← (HaveMTE2Ext ())) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if (((! accdesc.tagaccess) || (bne memaddrdesc.memattrs.tags MemTag_AllocationTagged)) : Bool)
  then (do (pure ()))
  else
    (do let (memaddrdesc, memstatus) ← (( do
          let loop_i_lower := 0
          let loop_i_upper := (count -i 1)
          let mut loop_vars := (memaddrdesc, memstatus)
          for i in [loop_i_lower:loop_i_upper:1]i do
            let (memaddrdesc, memstatus) := loop_vars
            loop_vars ← do
              let memstatus ← (PhysMemTagWrite memaddrdesc accdesc tag)
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address TAG_GRANULE) } }
              (pure (memaddrdesc, memstatus))
          (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
        (pure ())))

/-- Type quantifiers: processorid : Int, size : Int -/
def AArch64_MarkExclusiveVA (address : (BitVec 64)) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveGlobal (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveLocal (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()


end ArmASL.Functions
