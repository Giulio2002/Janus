import ArmASL.Part25

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_stlr_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_stlrb_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_stlrh_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

/-- Type quantifiers: k_acqrel : Bool, datasize : Nat, elsize : Nat, n : Nat, k_pair : Bool, regsize : Nat, k_rn_unknown : Bool, k_rt_unknown : Bool, s : Nat, t : Nat, t2 : Nat, k_tagchecked : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem elsize [32, 64] ∧ List.elem datasize [32, 64, 128] -/
def execute_aarch64_instrs_memory_exclusive_pair (acqrel : Bool) (datasize : Nat) (elsize : Nat) (memop : MemOp) (n : Nat) (pair : Bool) (regsize : Nat) (rn_unknown : Bool) (rt_unknown : Bool) (s : Nat) (t : Nat) (t2 : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescExLDST memop acqrel tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else
      (do (if (rn_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else (do (X_read n 64))))) ) : SailM (BitVec 64) )
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else
          (do (if (pair : Bool)
              then
                (do let el1 ← (( do (X_read t (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    let el2 ← (( do (X_read t2 (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    (if ((← (BigEndian accdesc.acctype)) : Bool)
                    then (do (pure (el1 +++ el2)))
                    else (do (pure (el2 +++ el1)))))
              else
                (do sail_assert ((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28040.61-28040.62"
                    (X_read t datasize))))) ) : SailM (BitVec datasize) )
      let status : (BitVec 1) := 1#1
      let status ← (( do
        (if ((← (AArch64_ExclusiveMonitorsPass address dbytes)) : Bool)
        then
          (do (Mem_set address dbytes accdesc data)
              (pure (ExclusiveMonitorsStatus ())))
        else
          (do (if ((← readReg SPESampleInFlight) : Bool)
              then (do (SPESetDataVirtualAddress address))
              else (do (pure ())))
              (pure status))) ) : SailM (BitVec 1) )
      (X_set s 32 (Sail.BitVec.zeroExtend status 32)))
  | .MemOp_LOAD =>
    (do
      (AArch64_SetExclusiveMonitors address dbytes)
      (if (pair : Bool)
      then
        (do (if (rt_unknown : Bool)
            then
              (do sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28056.58-28056.59"
                  (X_set t datasize (← (__UNKNOWN_bits datasize))))
            else
              (do (if ((elsize == 32) : Bool)
                  then
                    (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
                        (if ((← (BigEndian accdesc.acctype)) : Bool)
                        then
                          (do sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28061.110-28061.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28062.96-28062.97"
                              (X_set t (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize))
                              (X_set t2 elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0)))
                        else
                          (do (X_set t elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0))
                              sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28067.110-28067.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28068.96-28068.97"
                              (X_set t2 (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize)))))
                  else
                    (do (if ((! (IsAligned__1 address dbytes)) : Bool)
                        then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
                        else (do (pure ())))
                        (X_set t 64 (← (Mem_read (BitVec.addInt address 0) 8 accdesc)))
                        (X_set t2 64 (← (Mem_read (BitVec.addInt address 8) 8 accdesc))))))))
      else
        (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
            sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28080.73-28080.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if (acqrel : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 1#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := (BEq.beq memop MemOp_LOAD)
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldaxp_aarch64_instrs_memory_exclusive_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28114.84-28114.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28131.88-28131.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28147.88-28147.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_pair acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxp_aarch64_instrs_memory_exclusive_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28200.84-28200.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28217.88-28217.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28233.88-28233.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_pair acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stlxp_aarch64_instrs_memory_exclusive_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28286.84-28286.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28303.88-28303.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28319.88-28319.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_pair acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stxp_aarch64_instrs_memory_exclusive_pair (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 32 (BitVec.toNat sz))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28368.84-28368.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28385.88-28385.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28401.88-28401.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_pair acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

/-- Type quantifiers: k_acqrel : Bool, datasize : Nat, elsize : Nat, n : Nat, k_pair : Bool, regsize : Nat, k_rn_unknown : Bool, k_rt_unknown : Bool, s : Nat, t : Nat, t2 : Nat, k_tagchecked : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem elsize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] -/
def execute_aarch64_instrs_memory_exclusive_single (acqrel : Bool) (datasize : Nat) (elsize : Nat) (memop : MemOp) (n : Nat) (pair : Bool) (regsize : Nat) (rn_unknown : Bool) (rt_unknown : Bool) (s : Nat) (t : Nat) (t2 : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescExLDST memop acqrel tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else
      (do (if (rn_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else (do (X_read n 64))))) ) : SailM (BitVec 64) )
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else
          (do (if (pair : Bool)
              then
                (do sail_assert (((Int.ediv datasize 2) == 8) || (((Int.ediv datasize 2) == 16) || (((Int.ediv datasize 2) == 32) || ((Int.ediv datasize 2) == 64)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28454.135-28454.136"
                    let el1 ← (( do (X_read t (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    let el2 ← (( do (X_read t2 (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    (if ((← (BigEndian accdesc.acctype)) : Bool)
                    then (do (pure (el1 +++ el2)))
                    else (do (pure (el2 +++ el1)))))
              else
                (do sail_assert ((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28459.61-28459.62"
                    (X_read t datasize))))) ) : SailM (BitVec datasize) )
      let status : (BitVec 1) := 1#1
      let status ← (( do
        (if ((← (AArch64_ExclusiveMonitorsPass address dbytes)) : Bool)
        then
          (do (Mem_set address dbytes accdesc data)
              (pure (ExclusiveMonitorsStatus ())))
        else
          (do (if ((← readReg SPESampleInFlight) : Bool)
              then (do (SPESetDataVirtualAddress address))
              else (do (pure ())))
              (pure status))) ) : SailM (BitVec 1) )
      (X_set s 32 (Sail.BitVec.zeroExtend status 32)))
  | .MemOp_LOAD =>
    (do
      (AArch64_SetExclusiveMonitors address dbytes)
      (if (pair : Bool)
      then
        (do (if (rt_unknown : Bool)
            then
              (do sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28475.58-28475.59"
                  (X_set t datasize (← (__UNKNOWN_bits datasize))))
            else
              (do (if ((elsize == 32) : Bool)
                  then
                    (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
                        (if ((← (BigEndian accdesc.acctype)) : Bool)
                        then
                          (do sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28480.110-28480.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28481.96-28481.97"
                              (X_set t (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize))
                              (X_set t2 elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0)))
                        else
                          (do sail_assert ((0 ≤b (elsize -i 1)) && ((elsize -i 1) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28485.85-28485.86"
                              (X_set t elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0))
                              sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28487.110-28487.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28488.96-28488.97"
                              (X_set t2 (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize)))))
                  else
                    (do (if ((! (IsAligned__1 address dbytes)) : Bool)
                        then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
                        else (do (pure ())))
                        (X_set t 64 (← (Mem_read (BitVec.addInt address 0) 8 accdesc)))
                        (X_set t2 64 (← (Mem_read (BitVec.addInt address 8) 8 accdesc))))))))
      else
        (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
            sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:28500.73-28500.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if (acqrel : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 1#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := (BEq.beq memop MemOp_LOAD)
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldaxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28534.84-28534.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28551.88-28551.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28567.88-28567.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldaxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28620.84-28620.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28637.88-28637.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28653.88-28653.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldaxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28706.84-28706.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28723.88-28723.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28739.88-28739.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28792.84-28792.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28809.88-28809.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28825.88-28825.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28878.84-28878.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28895.88-28895.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28911.88-28911.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28964.84-28964.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28981.88-28981.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28997.88-28997.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stlxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29050.84-29050.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29067.88-29067.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29083.88-29083.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stlxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29136.84-29136.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29153.88-29153.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29169.88-29169.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stlxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29222.84-29222.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29239.88-29239.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29255.88-29255.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29308.84-29308.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29325.88-29325.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29341.88-29341.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29394.84-29394.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29411.88-29411.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29427.88-29427.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_stxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29480.84-29480.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29497.88-29497.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29513.88-29513.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, k_rt_unknown : Bool, t : Nat, t2 : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64, 128, 256] -/
def execute_aarch64_instrs_memory_pair_simdfp_no_alloc (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (rt_unknown : Bool) (t : Nat) (t2 : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let data2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30062.62-30062.63"
      let data1 ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      let data2 ← (( do (V_read t2 datasize) ) : SailM (BitVec datasize) )
      (Mem_set (BitVec.addInt address 0) dbytes accdesc data1)
      (Mem_set (BitVec.addInt address dbytes) dbytes accdesc data2))
  | .MemOp_LOAD =>
    (do
      let data1 ← (( (Mem_read (BitVec.addInt address 0) dbytes accdesc) ) : SailM (BitVec datasize) )
      let data2 ← (( (Mem_read (BitVec.addInt address dbytes) dbytes accdesc) ) : SailM (BitVec datasize) )
      let (data1, data2) ← (( do
        (if (rt_unknown : Bool)
        then
          (do let data1 ← (__UNKNOWN_bits datasize)
              let data2 ← (__UNKNOWN_bits datasize)
              (pure (data1, data2)))
        else (do (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30075.62-30075.63"
      (V_set t datasize data1)
      (V_set t2 datasize data2))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldnp_fpsimd_aarch64_instrs_memory_pair_simdfp_no_alloc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30117.84-30117.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30131.54-30131.55"
  (execute_aarch64_instrs_memory_pair_simdfp_no_alloc datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stnp_fpsimd_aarch64_instrs_memory_pair_simdfp_no_alloc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := true
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30166.84-30166.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30180.54-30180.55"
  (execute_aarch64_instrs_memory_pair_simdfp_no_alloc datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, k_rt_unknown : Bool, t : Nat, t2 : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64, 128, 256] -/
def execute_aarch64_instrs_memory_pair_simdfp_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (rt_unknown : Bool) (t : Nat) (t2 : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let data2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30217.62-30217.63"
      let data1 ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      let data2 ← (( do (V_read t2 datasize) ) : SailM (BitVec datasize) )
      (Mem_set (BitVec.addInt address 0) dbytes accdesc data1)
      (Mem_set (BitVec.addInt address dbytes) dbytes accdesc data2))
  | .MemOp_LOAD =>
    (do
      let data1 ← (( (Mem_read (BitVec.addInt address 0) dbytes accdesc) ) : SailM (BitVec datasize) )
      let data2 ← (( (Mem_read (BitVec.addInt address dbytes) dbytes accdesc) ) : SailM (BitVec datasize) )
      let (data1, data2) ← (( do
        (if (rt_unknown : Bool)
        then
          (do let data1 ← (__UNKNOWN_bits datasize)
              let data2 ← (__UNKNOWN_bits datasize)
              (pure (data1, data2)))
        else (do (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30230.62-30230.63"
      (V_set t datasize data1)
      (V_set t2 datasize data2))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30272.84-30272.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30286.54-30286.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30321.84-30321.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30335.54-30335.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30370.84-30370.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30384.54-30384.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30419.84-30419.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30433.54-30433.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30468.84-30468.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30482.54-30482.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30517.84-30517.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30531.54-30531.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, k_rt_unknown : Bool, t : Nat, t2 : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_memory_pair_general_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (t2 : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let data2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data1 ← (( do
        (if ((rt_unknown && (t == n)) : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let data2 ← (( do
        (if ((rt_unknown && (t2 == n)) : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t2 datasize))) ) : SailM (BitVec datasize) )
      (if ((← (HaveLSE2Ext ())) : Bool)
      then
        (do let full_data ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
            let full_data ← (( do
              (if ((← (BigEndian accdesc.acctype)) : Bool)
              then (do (pure (data1 +++ data2)))
              else (do (pure (data2 +++ data1)))) ) : SailM (BitVec (2 * datasize)) )
            let ispair : Bool := true
            (Mem_set__1 address (2 *i dbytes) accdesc ispair full_data))
      else
        (do (Mem_set (BitVec.addInt address 0) dbytes accdesc data1)
            (Mem_set (BitVec.addInt address dbytes) dbytes accdesc data2))))
  | .MemOp_LOAD =>
    (do
      let (data1, data2) ← (( do
        (if (((← (HaveLSE2Ext ())) && (! is_signed)) : Bool)
        then
          (do let ispair : Bool := true
              let full_data ← (( do (Mem_read__1 address (2 *i dbytes) accdesc ispair) ) : SailM (BitVec (2 * datasize)) )
              let (data1, data2) ← (( do
                (if ((← (BigEndian accdesc.acctype)) : Bool)
                then
                  (do let data2 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data (datasize -i 1) 0)
                      let data1 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data ((2 *i datasize) -i 1) datasize)
                      (pure (data1, data2)))
                else
                  (do let data1 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data (datasize -i 1) 0)
                      let data2 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data ((2 *i datasize) -i 1) datasize)
                      (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
              (pure (data1, data2)))
        else
          (do let data1 ← (Mem_read (BitVec.addInt address 0) dbytes accdesc)
              let data2 ← (Mem_read (BitVec.addInt address dbytes) dbytes accdesc)
              (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      let (data1, data2) ← (( do
        (if (rt_unknown : Bool)
        then
          (do let data1 ← (__UNKNOWN_bits datasize)
              let data2 ← (__UNKNOWN_bits datasize)
              (pure (data1, data2)))
        else (do (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      (if (is_signed : Bool)
      then
        (do (X_set t 64 (sign_extend data1 64))
            (X_set t2 64 (sign_extend data2 64)))
      else
        (do (X_set t datasize data1)
            (X_set t2 datasize data2))))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldp_gen_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30661.113-30661.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30680.107-30680.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30699.84-30699.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30713.44-30713.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldp_gen_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30750.113-30750.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30769.107-30769.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30788.84-30788.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30802.44-30802.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldp_gen_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30839.113-30839.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30858.107-30858.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30877.84-30877.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30891.44-30891.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldpsw_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30928.113-30928.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30947.107-30947.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30966.84-30966.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30980.44-30980.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldpsw_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31017.113-31017.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31036.107-31036.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31055.84-31055.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31069.44-31069.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldpsw_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31106.113-31106.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31125.107-31125.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31144.84-31144.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31158.44-31158.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31195.113-31195.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31214.107-31214.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31233.84-31233.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31247.44-31247.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31284.113-31284.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31303.107-31303.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31322.84-31322.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31336.44-31336.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_stp_gen_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31373.113-31373.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31392.107-31392.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31411.84-31411.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31425.44-31425.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31460.62-31460.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31466.62-31466.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31503.72-31503.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31533.72-31533.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_ldr_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31563.72-31563.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31593.72-31593.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31623.72-31623.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_str_imm_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31653.72-31653.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_post_idx datasize memop n nontemporal offset postindex t tagchecked wback)

/-- Type quantifiers: k_is_signed : Bool, k_nontemporal : Bool, size : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem size [4, 8] -/
def execute_aarch64_instrs_memory_literal_general (memop : MemOp) (nontemporal : Bool) (offset : (BitVec 64)) (is_signed : Bool) (size : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (pure ((← (PC_read ())) + offset)) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  match memop with
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address size accdesc) ) : SailM (BitVec (size * 8)) )
      (if (is_signed : Bool)
      then (do (X_set t 64 (sign_extend data 64)))
      else (do (X_set t (size *i 8) data))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_lit_gen_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

def decode_ldrsw_lit_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

def decode_prfm_lit_aarch64_instrs_memory_literal_general (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let memop : MemOp := MemOp_LOAD
  let is_signed : Bool := false
  let nontemporal : Bool := false
  let size : Int := 4
  let (is_signed, memop, size) : (Bool × MemOp × Int) :=
    match opc with
    | 0b00 =>
      (let size : Int := 4
      (is_signed, memop, size))
    | 0b01 =>
      (let size : Int := 8
      (is_signed, memop, size))
    | 0b10 =>
      (let size : Int := 4
      let is_signed : Bool := true
      (is_signed, memop, size))
    | _ =>
      (let memop : MemOp := MemOp_PREFETCH
      (is_signed, memop, size))
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_general memop nontemporal offset is_signed size t tagchecked)

/-- Type quantifiers: k_nontemporal : Bool, size : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem size [4, 8, 16] -/
def execute_aarch64_instrs_memory_literal_simdfp (nontemporal : Bool) (offset : (BitVec 64)) (size : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (pure ((← (PC_read ())) + offset)) ) : SailM (BitVec 64) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  (CheckFPEnabled64 ())
  let accdesc ← (( do (CreateAccDescASIMD MemOp_LOAD nontemporal tagchecked) ) : SailM AccessDescriptor )
  let data ← (( do (Mem_read address size accdesc) ) : SailM (BitVec (size * 8)) )
  (V_set t (size *i 8) data)
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_lit_fpsimd_aarch64_instrs_memory_literal_simdfp (Rt : (BitVec 5)) (imm19 : (BitVec 19)) (opc : (BitVec 2)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let size : Int := 4
  let size ← (( do
    match opc with
    | 0b00 => (pure 4)
    | 0b01 => (pure 8)
    | 0b10 => (pure 16)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM Int )
  let size := size
  let offset : (BitVec 64) := (sign_extend (imm19 +++ 0b00#2) 64)
  let tagchecked : Bool := false
  (execute_aarch64_instrs_memory_literal_simdfp nontemporal offset size t tagchecked)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31896.72-31896.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:31899.73-31899.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))


end ArmASL.Functions
