import ArmASL.Part14

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_AMDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMIIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTFID0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_TYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ID_AA64DFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64DFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def EncodePARange (_ : Unit) : SailM (BitVec 4) := do
  match (← readReg __supported_pa_size) with
  | 32 => (pure 0b0000#4)
  | 36 => (pure 0b0001#4)
  | 40 => (pure 0b0010#4)
  | 42 => (pure 0b0011#4)
  | 44 => (pure 0b0100#4)
  | 48 => (pure 0b0101#4)
  | 52 =>
    (do
      sail_assert (← (Have52BitPAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:79.33-79.34"
      (pure 0b0110#4))
  | 56 =>
    (do
      sail_assert (← (Have56BitPAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:83.33-83.34"
      (pure 0b0111#4))
  | _ => (pure 0b0110#4)

def EncodeVARange (_ : Unit) : SailM (BitVec 4) := do
  match (← readReg __supported_va_size) with
  | 48 => (pure 0b0000#4)
  | 52 =>
    (do
      sail_assert (← (Have52BitVAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:98.33-98.34"
      (pure 0b0001#4))
  | 56 =>
    (do
      sail_assert (← (Have56BitVAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:102.33-102.34"
      (pure 0b0001#4))
  | _ => (do (undefined_bitvector 4))

/-- Type quantifiers: i : Int -/
def IsG1ActivityMonitorImplemented (i : Int) : SailM Bool := do
  sail_assert ((0 ≤b i) && (i <b 16)) "sail-arm/arm-v9.4-a/src/impdefs.sail:870.26-870.27"
  (pure ((BitVec.access (← readReg __g1_activity_monitor_implemented) i) == 1#1))

/-- Type quantifiers: i : Int -/
def IsG1ActivityMonitorOffsetImplemented (i : Int) : SailM Bool := do
  sail_assert ((0 ≤b i) && (i <b 16)) "sail-arm/arm-v9.4-a/src/impdefs.sail:877.26-877.27"
  (pure ((BitVec.access (← readReg __g1_activity_monitor_offset_implemented) i) == 1#1))

def Mk_CCSIDR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_CNTFID0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMCEID1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ERRIDR_EL1_Type_NUM (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_ID_AA64DFR0_EL1_Type_BRPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 15 12)

def _get_ID_AA64DFR0_EL1_Type_CTX_CMPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 31 28)

def _get_ID_AA64DFR0_EL1_Type_PMUVer (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 11 8)

def _get_ID_AA64DFR0_EL1_Type_TraceFilt (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 43 40)

def _get_ID_AA64DFR0_EL1_Type_TraceVer (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 7 4)

def _get_ID_AA64DFR0_EL1_Type_WRPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_ID_AA64PFR0_EL1_Type_AdvSIMD (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_ID_AA64PFR0_EL1_Type_EL0 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ID_AA64PFR0_EL1_Type_EL1 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 7 4)

def _get_ID_AA64PFR0_EL1_Type_EL2 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 11 8)

def _get_ID_AA64PFR0_EL1_Type_EL3 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 15 12)

def _get_ID_AA64PFR0_EL1_Type_GIC (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 27 24)

def _get_ID_AA64PFR0_EL1_Type_MPAM (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 43 40)

def _get_ID_AA64PFR1_EL1_Type_MPAM_frac (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _update_ICC_CTLR_EL1_Type_A3V (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_ICC_CTLR_EL1_Type_ExtRange (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _update_ICC_CTLR_EL1_Type_IDbits (v : (BitVec 64)) (x : (BitVec 3)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 13 11 x)

def _update_ICC_CTLR_EL1_Type_PRIbits (v : (BitVec 64)) (x : (BitVec 3)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 10 8 x)

def AArch64_IMPDEFResets (_ : Unit) : SailM Unit := do
  writeReg DCZID_EL0 (Sail.BitVec.updateSubrange (← readReg DCZID_EL0) 4 4 0#1)
  writeReg DCZID_EL0 (Sail.BitVec.updateSubrange (← readReg DCZID_EL0) 3 0 (integer_subrange (← readReg __dczid_log2_block_size) 3 0))
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 15 0 (Sail.BitVec.zeroExtend 0x4#4 16))
  let loop_i_lower := 0
  let loop_i_upper ← (( do (pure ((BitVec.toNat (_get_ERRIDR_EL1_Type_NUM (← readReg ERRIDR_EL1))) -i 1)) ) : SailM Int )
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      sail_assert ((0 ≤b i) && (i <b 4)) "sail-arm/arm-v9.4-a/src/reset.sail:432.55-432.56"
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 54 53 0b11#2))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 52 52 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 51 51 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 50 50 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 49 49 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 48 48 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 31 31 1#1))
  (pure loop_vars)
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 25 24 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 23 22 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 21 20 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 19 18 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 17 16 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 15 15 1#1))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 14 12 0b100#3))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 11 10 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 9 8 0b11#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 7 6 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 5 4 0b11#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 1 0 0b10#2))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 31 24 (Zeros (n := 8)))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 23 16
    (← do
      (if ((IsZero (_get_PMCR_EL0_Type_IMP (← readReg PMCR_EL0))) : Bool)
      then (do (pure (Zeros (n := 8))))
      else (do (pure CFG_PMCR_IDCODE)))))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 15 11 (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 2 2 0#1)
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 1 1 0#1)
  writeReg PMCEID0_EL0 (Mk_PMCEID0_EL0_Type (Sail.BitVec.zeroExtend 0b111101001000000000100000000100000001#36 64))
  writeReg PMCEID1_EL0 (Mk_PMCEID1_EL0_Type (Zeros (n := 64)))
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 31 28 0b0000#4)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 21 21 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 19 19 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 18 18 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 17 17 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 16 16 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 15 15 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 14 14 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 13 8 0b111111#6)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 7 0 (0b000#3 +++ (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 7 4 0b0001#4)
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 3 0 0b0110#4)
  writeReg PMPIDR0 (Sail.BitVec.updateSubrange (← readReg PMPIDR0) 7 0 0b00001111#8)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 7 4 0b1011#4)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 3 0 0b1101#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 7 4 0b0000#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 3 3 1#1)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 2 0 0b011#3)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 7 4 0b0000#4)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 3 0 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 7 4 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 3 0 0b0100#4)
  writeReg PMCIDR0 (Sail.BitVec.updateSubrange (← readReg PMCIDR0) 7 0 0b00001101#8)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 7 4 0b1001#4)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 3 0 0b0000#4)
  writeReg PMCIDR2 (Sail.BitVec.updateSubrange (← readReg PMCIDR2) 7 0 0b00000101#8)
  writeReg PMCIDR3 (Sail.BitVec.updateSubrange (← readReg PMCIDR3) 7 0 0b10110001#8)
  writeReg CNTFID0 (Mk_CNTFID0_Type (← readReg __CNTbase_frequency))
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 51 48 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 39 36 0b1111#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0010#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 43 40 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 31 28 (integer_subrange ((← readReg __num_ctx_breakpoints) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 23 20 (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 15 12 (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 7 4 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1001#4)
  (if ((← (IsFeatureImplemented FEAT_RME)) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 55 52 0b0001#4)
        writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 23 20 (← readReg __rme_l0gptsz)))
  else (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 55 52 0b0000#4)))
  (if ((← (IsFeatureImplemented FEAT_BRBE)) : Bool)
  then
    (do writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 55 52 0b0010#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 15 12 0b0101#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 11 8 0b0000#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 7 0 (integer_subrange (← readReg NUM_BRBE_RECORDS) 7 0)))
  else (do (pure ())))
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 47 44 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 43 40 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 39 36 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 35 32 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 31 28 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 19 16 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0010#4)
  writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 3 0 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 43 40 0b0011#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 35 32 0b0011#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 39 36 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 47 44 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 59 56 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 63 60 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 31 28 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 23 20 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 27 24 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 19 16 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 7 4 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 3 0 (← (EncodePARange ())))
  writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 19 16 (← (EncodeVARange ())))
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 31 28 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 27 24 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 19 16 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 11 8 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 7 4 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 35 32 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 7 4 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 3 0 0b0010#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 63 60 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 59 56 0b0010#4)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 3 0 0b0001#4)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 7 4 0b0001#4)
  (if ((← (HaveCNTSCExt ())) : Bool)
  then (do writeReg CNTID (Sail.BitVec.updateSubrange (← readReg CNTID) 3 0 0b0001#4))
  else (do (pure ())))
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 47 44 0b0001#4)
  writeReg AMCIDR0 (Sail.BitVec.updateSubrange (← readReg AMCIDR0) 7 0 0b00001101#8)
  writeReg AMCIDR1 (Sail.BitVec.updateSubrange (← readReg AMCIDR1) 7 4 0b1001#4)
  writeReg AMCIDR2 (Sail.BitVec.updateSubrange (← readReg AMCIDR2) 7 0 0b00000101#8)
  writeReg AMCIDR3 (Sail.BitVec.updateSubrange (← readReg AMCIDR3) 7 0 0b10110001#8)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 7 0 0b00010011#8)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 13 8 0b111111#6)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 24 24 1#1)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 31 28 (integer_subrange ((← readReg NUM_AMU_COUNTER_GROUPS) -i 1) 3 0))
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 7 0 (integer_subrange (← readReg NUM_AMU_CG0_MONITORS) 7 0))
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 15 8 (integer_subrange (← readReg NUM_AMU_CG1_MONITORS) 7 0))
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 31 21 (0b0100#4 +++ 0b0111011#7))
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 20 20 1#1)
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 15 0 (0b0000#4 +++ 0b101001100110#12))
  writeReg AMDEVTYPE (Sail.BitVec.updateSubrange (← readReg AMDEVTYPE) 7 4 0b0001#4)
  writeReg AMDEVTYPE (Sail.BitVec.updateSubrange (← readReg AMDEVTYPE) 3 0 0b0110#4)
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 0) 15 0 0b0000000000010001#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 1 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 1) 15 0 0b0100000000000100#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 2 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 2) 15 0 0b0000000000001000#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 3 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 3) 15 0 0b0100000000000101#16))
  writeReg AMIIDR (Sail.BitVec.updateSubrange (← readReg AMIIDR) 11 0 0b010000111011#12)
  writeReg AMPIDR1 (Sail.BitVec.updateSubrange (← readReg AMPIDR1) 7 4 0b1011#4)
  writeReg AMPIDR2 (Sail.BitVec.updateSubrange (← readReg AMPIDR2) 3 3 1#1)
  writeReg AMPIDR2 (Sail.BitVec.updateSubrange (← readReg AMPIDR2) 2 0 0b011#3)
  writeReg AMPIDR4 (Sail.BitVec.updateSubrange (← readReg AMPIDR4) 3 0 0b0100#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 51 48 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 27 24 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 23 20 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 19 16 0b0000#4)
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 31 0 (← readReg CFG_MPIDR))
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 39 32 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 30 30 0#1)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 24 24 0#1)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 23 16 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 15 8 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 7 0 0b00000000#8)
  (VMPIDR_write (_update_VMPIDR_Type_M (← (VMPIDR_read ())) 1#1))
  (if ((HasArchVersion v8Ap1) : Bool)
  then
    (do writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 27 24 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 19 16 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0010#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_CRC32)) : Bool)
  then
    (do writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_VMID16)) : Bool)
  then (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 7 4 0b0010#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_PAN)) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0001#4)
        writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_AES))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0000#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_AES)) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0001#4))
  else (do (pure ())))
  (if ((←((IsFeatureImplemented FEAT_AES) <&&> (do
       (IsFeatureImplemented FEAT_PMULL)))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0010#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_SHA1))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 11 8 0b0000#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_SHA256))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0000#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap2) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 3 0 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 7 4 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 15 12 0b0001#4)
        writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 19 16 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 39 36 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 11 8 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 15 12 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 23 20 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 7 4 0b0001#4)
        (if ((HaveEL EL2) : Bool)
        then
          (do writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0010#4)
              writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 59 56 0b0010#4))
        else
          (do writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0000#4)
              writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 59 56 0b0000#4)))
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0000#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 63 63 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 32 32 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 34 34 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 35 35 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 39 36 0b1111#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 48 48 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 55 52 0b1111#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 3 0 0b0010#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 7 4 0b0001#4)
        (if ((← (HaveDoPD ())) : Bool)
        then
          (do writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 7 4 0b0001#4)
              writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 19 16 0b0001#4))
        else
          (do writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 7 4 0b0000#4)
              writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 19 16 0b0000#4)))
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 35 32 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 7 4 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 3 0 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 51 48 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 47 44 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 55 52 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 27 24 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap6) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 47 44 0b0010#4)
        writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 59 56 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_DotProd)) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 47 44 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_FP16)) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 19 16 0b0001#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 23 20 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_AA32HPD)) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0010#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 19 16 0b0010#4))
  else (do (pure ())))
  (if ((← (HaveMPAMExt ())) : Bool)
  then
    (do (if ((← readReg __empam_force_ns_implemented) : Bool)
        then
          (do writeReg __mpam_major CFG_MPAM_v0p1
              writeReg __mpam_frac CFG_MPAM_frac_v0p1
              writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 60 60 1#1))
        else
          (do writeReg __mpam_major CFG_MPAM_v1p1
              writeReg __mpam_frac CFG_MPAM_frac_v1p1))
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 43 40 (← readReg __mpam_major))
        writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 15 0 (← readReg __mpam_partid_max))
        writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 39 32 (← readReg __mpam_pmg_max))
        (if ((← readReg __mpam_has_hcr) : Bool)
        then
          (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 17 17 1#1)
              writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 20 18 (← readReg __mpam_vpmr_max)))
        else (do (pure ())))
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 19 16 (← readReg __mpam_frac))
        sail_assert (←((pure ((BitVec.toNat (_get_ID_AA64PFR0_EL1_Type_MPAM (← readReg ID_AA64PFR0_EL1))) >b 1)) <||> (do
          (do
            let b__0 ← do (pure (_get_ID_AA64PFR0_EL1_Type_MPAM (← readReg ID_AA64PFR0_EL1)))
            (if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
            then (do (pure true))
            else (do (pure false)))) <&&> (do
            (pure ((_get_ID_AA64PFR1_EL1_Type_MPAM_frac (← readReg ID_AA64PFR1_EL1)) == 0b0001#4)))))) "sail-arm/arm-v9.4-a/src/reset.sail:720.56-720.57"
        (if ((← readReg __empam_sdeflt_implemented) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 61 61 1#1))
        else (do (pure ())))
        (if ((← readReg __empam_tidr_implemented) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 58 58 1#1))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure (HasArchVersion v9Ap2)) <&&> (do
       (HaveRME ())))) : Bool)
  then
    (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 59 59 1#1)
        (if ((← readReg __mpam_has_altsp) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 57 57 1#1))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap3) : Bool)
  then
    (do (if ((← (IsFeatureImplemented FEAT_PACQARMA3)) : Bool)
        then
          (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 11 8 0b0001#4)
              writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 15 12 0b0101#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 7 4 0b0000#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 27 24 0b0000#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_PACQARMA5)) : Bool)
        then
          (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 11 8 0b0000#4)
              writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 15 12 0b0000#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 7 4 0b0101#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 27 24 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_CONSTPACFIELD)) : Bool)
        then (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 27 24 0b0001#4))
        else (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 27 24 0b0000#4)))
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 15 12 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 19 16 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 3 0 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 27 24 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 27 24 0b0001#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then
    (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 35 32 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 51 48 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 43 40 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 27 24 0b0010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1001#4)
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b0000#4))
        else (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 39 36 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 59 56 0b0010#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 55 52 0b0000#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 51 48 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 11 8 0b0001#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 55 52 (integer_subrange (← readReg __block_bbm_implemented) 3 0))
        (if ((← (IsFeatureImplemented FEAT_SHA512)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0010#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SHA3)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 35 32 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SM3)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 39 36 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SM4)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 43 40 0b0001#4))
        else (do (pure ())))
        (if ((← (HavePMUv3p4 ())) : Bool)
        then
          (do (if ((← (HavePMUv3TH ())) : Bool)
              then (do writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 23 20 0b1100#4))
              else (do (pure ())))
              writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 19 16 0b0100#4)
              writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 15 8 0b00000011#8))
        else (do (pure ()))))
  else (do (pure ())))
  writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 7 4 0b0010#4)
  (if ((HasArchVersion v8Ap5) : Bool)
  then
    (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 55 52 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 35 32 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 3 0 0b0001#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b0110#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 63 60 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 63 60 0b0001#4)
        (if ((← (HaveMTE2Ext ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0010#4))
        else (do (pure ())))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b0110#4)
        writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 11 8 0b0000#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 15 12 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 23 20 0b0000#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 11 8 0b0000#4)
  (if ((HasArchVersion v8Ap6) : Bool)
  then (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 35 32 0b0001#4))
  else (do (pure ())))
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 19 16 0b0010#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 51 48 0b0001#4)
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 3 0 0b0001#4)
  (if ((HasArchVersion v8Ap7) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 43 40 0b0001#4)
        (if (((! (HaveEL EL3)) && (HaveEL EL2)) : Bool)
        then (do writeReg HCRX_EL2 (Mk_HCRX_EL2_Type (Zeros (n := 64))))
        else (do (pure ())))
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b0111#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b0111#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0011#4)
        (if ((← readReg __feat_rpres) : Bool)
        then (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 7 4 0b0001#4))
        else (do (pure ())))
        (if ((← (Have52BitIPAAndPASpaceExt ())) : Bool)
        then
          (do writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 31 28 0b0001#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 43 40 0b0011#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 23 20 0b0010#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 35 32 0b0011#4))
        else (do (pure ())))
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 59 56 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 3 0 0b0010#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0011#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0011#4)
        (if ((← (HaveFeatLS64_ACCDATA ())) : Bool)
        then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0011#4))
        else
          (do (if ((← (HaveFeatLS64_V ())) : Bool)
              then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0010#4))
              else
                (do (if ((← (HaveFeatLS64 ())) : Bool)
                    then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0001#4))
                    else (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0000#4))))))))
  else (do (pure ())))
  writeReg GICD_TYPER (BitVec.update (← readReg GICD_TYPER) 9 (Bit 1#1))
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 31 27 0b11111#5)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 18 18 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 17 17 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 16 16 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 8 8 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 10 10 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 4 0 0b00111#5)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 23 19 0b01111#5)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 5 5 1#1)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 4 4 0#1)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 3 0 0b0000#4)
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 32 32 0#1)
  (if ((← (IsFeatureImplemented FEAT_SME)) : Bool)
  then
    (do writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 31 24 0b01000001#8)
        writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 15 15 1#1)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 27 24 0b0001#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v9Ap3) : Bool)
  then
    (do (if ((← (IsFeatureImplemented FEAT_MEC)) : Bool)
        then
          (do writeReg MECIDR_EL2 (Sail.BitVec.updateSubrange (← readReg MECIDR_EL2) 3 0 (← readReg __mecid_width))
              writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 31 28 0b0001#4))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_SME2)) : Bool)
  then
    (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 27 24 0b0010#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 59 56 0b0001#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 47 44 0b0101#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 33 33 1#1))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 39 36 0b0010#4)
        writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 3 0 0b0010#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 31 28 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 23 20 0b0001#4)
        (if ((← (HaveStatisticalProfiling ())) : Bool)
        then (do writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0100#4))
        else (do (pure ())))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 63 60 0b0001#4)
        writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 7 4 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1010#4)
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b0000#4))
        else (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 59 56 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b1000#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b1000#4))
  else (do (pure ())))
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 27 24 0b0001#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 19 16 0b0001#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 15 12 0b0001#4)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 18 18 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 17 17 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 16 16 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 15 15 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 14 14 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 13 13 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 12 12 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 11 11 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 10 10 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 9 9 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 8 8 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 7 7 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 3 3 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 2 2 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 1 1 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 0 0 0#1)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 31 31 0#1)
  writeReg CPTR_EL2 (BitVec.update (← readReg CPTR_EL2)
    (← do
      (if ((←((IsFeatureImplemented FEAT_VHE) <&&> (do
           (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
      then (do (pure 28))
      else (do (pure 20)))) (Bit 0#1))
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 49 49 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 52 52 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 50 50 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 44 44 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 43 43 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 42 42 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 41 41 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 40 40 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 38 38 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 37 37 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 36 36 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 33 33 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 32 32 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 31 31 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 30 30 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 29 29 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 28 28 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 27 27 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 26 26 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 25 25 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 24 24 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 23 23 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 22 22 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 21 21 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 20 20 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 19 19 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 18 18 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 17 17 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 16 16 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 15 15 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 14 14 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 13 13 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 12 12 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 11 10 0b00#2)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 9 9 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 7 7 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 6 6 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 5 5 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 4 4 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 3 3 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 2 2 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 1 1 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 0 0 0#1)
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 15 0 (Zeros (n := 16)))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 31 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 30 30 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 27 27 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 25 25 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 13 13 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 31 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 30 30 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 27 27 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 25 25 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 13 13 0#1)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 28 28 0#1)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 21 20 0b00#2)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 31 31 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 30 30 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 27 27 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 25 25 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 13 13 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 31 31 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 30 30 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 27 27 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 25 25 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 13 13 0#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 24 24 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 6 6 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 19 16 0b0011#4)
  match SPEMaxRecordSize with
  | 64 => writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 15 12 0b0110#4)
  | _ => (Unreachable ())
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 3 3 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 2 2 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 1 1 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 0 0 1#1)
  (if ((← (EL2Enabled ())) : Bool)
  then
    (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 14 14 0#1)
        writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 13 12 0b10#2))
  else (do (pure ())))
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 4 0 (_get_PMCR_EL0_Type_N (← readReg PMCR_EL0)))
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 0 0 1#1)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 3 3 1#1)
  writeReg ICC_SRE_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_S) 0 0 1#1)
  writeReg ICC_SRE_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_NS) 0 0 1#1)
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 0 0 1#1)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 27 24 0b0100#4)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 23 20 (← readReg __exclusive_granule_size))
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 19 16 0b0100#4)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 15 14 0b10#2)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 3 0 0b0100#4)
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 37 32 0b000100#6))
  else (do (pure ())))
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do writeReg GMID_EL1 (Sail.BitVec.updateSubrange (← readReg GMID_EL1) 3 0 (integer_subrange (← readReg __gmid_log2_block_size) 3 0)))
  else (do (pure ())))
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 23 21 0b010#3)
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 20 18 0b011#3)
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_ExtRange (← (ICC_CTLR_EL1_read ())) 1#1))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_PRIbits (← (ICC_CTLR_EL1_read ())) 0b100#3))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_A3V (← (ICC_CTLR_EL1_read ())) 1#1))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_IDbits (← (ICC_CTLR_EL1_read ())) 0b001#3))
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 19 19 1#1)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 10 8 0b100#3)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 13 11 0b001#3)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 15 15 1#1)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 29 0b100#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 28 26 0b100#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 25 23 0b001#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 21 21 1#1)
  writeReg CCSIDR_EL1 (Mk_CCSIDR_EL1_Type
    (set_slice 24 (← readReg CCSIDR_EL1)
      (← do
        (if ((← (IsFeatureImplemented FEAT_CCIDX)) : Bool)
        then (do (pure 32))
        else (do (pure 13)))) (Sail.BitVec.zeroExtend 0xFF#8 24)))
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 23 3 (Sail.BitVec.zeroExtend 0x1#4 21))
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 2 0 0b010#3)
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 23 0 (Sail.BitVec.zeroExtend 0xFF#8 24))
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 3 0 0b0000#4)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 7 4 0b0000#4)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 15 12 0b0000#4)
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 3 3 (Sail.BitVec.extractLsb 0b10#2 1 1))
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 0 0 (Sail.BitVec.extractLsb 0b10#2 0 0))
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 1 0 0b11#2)
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 55 12 (Sail.BitVec.zeroExtend 0x22000#20 44))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 11 8 (_get_ID_AA64DFR0_EL1_Type_PMUVer (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 11 0 0xA15#12)
  writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 15 12 0b1011#4)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 20 20 1#1)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 31 21 0b01000111011#11)
  writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 27 24 0b0001#4)
  writeReg EDDEVTYPE (Sail.BitVec.updateSubrange (← readReg EDDEVTYPE) 3 0 0b0101#4)
  writeReg EDDEVTYPE (Sail.BitVec.updateSubrange (← readReg EDDEVTYPE) 7 4 0b0001#4)
  writeReg EDPIDR0 (Sail.BitVec.updateSubrange (← readReg EDPIDR0) 7 0 (Sail.BitVec.zeroExtend 0xF#4 8))
  writeReg EDPIDR1 (Sail.BitVec.updateSubrange (← readReg EDPIDR1) 3 0 0xD#4)
  writeReg EDPIDR1 (Sail.BitVec.updateSubrange (← readReg EDPIDR1) 7 4 (Sail.BitVec.truncate 0x0B#8 4))
  writeReg EDPIDR2 (Sail.BitVec.updateSubrange (← readReg EDPIDR2) 2 0 0b011#3)
  writeReg EDPIDR2 (Sail.BitVec.updateSubrange (← readReg EDPIDR2) 3 3 1#1)
  writeReg EDCIDR0 (Sail.BitVec.updateSubrange (← readReg EDCIDR0) 7 0 0x0D#8)
  writeReg EDCIDR1 (Sail.BitVec.updateSubrange (← readReg EDCIDR1) 7 4 0b1001#4)
  writeReg EDCIDR2 (Sail.BitVec.updateSubrange (← readReg EDCIDR2) 7 0 0x05#8)
  writeReg EDCIDR3 (Sail.BitVec.updateSubrange (← readReg EDCIDR3) 7 0 0xB1#8)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 7 4 (_get_ID_AA64DFR0_EL1_Type_TraceVer (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 15 12 (_get_ID_AA64DFR0_EL1_Type_BRPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 23 20 (_get_ID_AA64DFR0_EL1_Type_WRPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 31 28 (_get_ID_AA64DFR0_EL1_Type_CTX_CMPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 43 40 (_get_ID_AA64DFR0_EL1_Type_TraceFilt (← readReg ID_AA64DFR0_EL1)))
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 0 0 1#1)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 3 0 (_get_ID_AA64PFR0_EL1_Type_EL0 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 7 4 (_get_ID_AA64PFR0_EL1_Type_EL1 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 11 8 (_get_ID_AA64PFR0_EL1_Type_EL2 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 15 12 (_get_ID_AA64PFR0_EL1_Type_EL3 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 23 20 (_get_ID_AA64PFR0_EL1_Type_AdvSIMD (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 27 24 (_get_ID_AA64PFR0_EL1_Type_GIC (← readReg ID_AA64PFR0_EL1)))
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 13 8 0b100000#6)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 21 16 0b100000#6)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 25 24 0b01#2)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 31 21 0b01000111011#11)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 20 20 1#1)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 15 0 0b0001101000010100#16)
  writeReg CTIDEVTYPE (Sail.BitVec.updateSubrange (← readReg CTIDEVTYPE) 7 4 0b0001#4)
  writeReg CTIDEVTYPE (Sail.BitVec.updateSubrange (← readReg CTIDEVTYPE) 3 0 0b0100#4)
  writeReg CTIPIDR4 (Sail.BitVec.updateSubrange (← readReg CTIPIDR4) 7 4 0b0000#4)
  writeReg CTIPIDR4 (Sail.BitVec.updateSubrange (← readReg CTIPIDR4) 3 0 0b0100#4)
  writeReg CTIPIDR2 (Sail.BitVec.updateSubrange (← readReg CTIPIDR2) 3 3 1#1)
  writeReg CTIPIDR2 (Sail.BitVec.updateSubrange (← readReg CTIPIDR2) 2 0 0b011#3)
  writeReg CTIPIDR1 (Sail.BitVec.updateSubrange (← readReg CTIPIDR1) 7 4 0b1011#4)
  writeReg CTIPIDR1 (Sail.BitVec.updateSubrange (← readReg CTIPIDR1) 3 0 0b1101#4)
  writeReg CTIPIDR0 (Sail.BitVec.updateSubrange (← readReg CTIPIDR0) 7 0 0b00001111#8)
  writeReg CTICIDR3 (Sail.BitVec.updateSubrange (← readReg CTICIDR3) 7 0 0b10110001#8)
  writeReg CTICIDR2 (Sail.BitVec.updateSubrange (← readReg CTICIDR2) 7 0 0b00000101#8)
  writeReg CTICIDR1 (Sail.BitVec.updateSubrange (← readReg CTICIDR1) 7 4 0b1001#4)
  writeReg CTICIDR1 (Sail.BitVec.updateSubrange (← readReg CTICIDR1) 3 0 0b0000#4)
  writeReg CTICIDR0 (Sail.BitVec.updateSubrange (← readReg CTICIDR0) 7 0 0b00001101#8)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 28 26 (integer_subrange ((← readReg NUM_GIC_PREEMPTION_BITS) -i 1) 2 0))
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 4 0 (integer_subrange ((← readReg NUM_GIC_LIST_REGS) -i 1) 4 0))
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 29 (integer_subrange ((← readReg NUM_GIC_PRIORITY_BITS) -i 1) 2 0))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 0 0
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 0)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 1 1
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 1)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 2 2
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 2)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 3 3
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 3)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 4 4
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 4)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 5 5
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 5)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 6 6
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 6)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 7 7
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 7)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 8 8
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 8)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 9 9
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 9)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 10 10
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 10)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 11 11
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 11)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 12 12
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 12)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 13 13
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 13)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 14 14
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 14)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 15 15
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 15)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 16 16
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 0)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 17 17
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 1)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 18 18
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 2)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 19 19
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 3)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 20 20
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 4)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 21 21
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 5)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 22 22
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 6)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 23 23
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 7)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 24 24
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 8)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 25 25
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 9)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 26 26
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 10)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 27 27
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 11)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 28 28
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 12)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 29 29
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 13)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 30 30
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 14)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 31 31
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 15)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  (if ((HasArchVersion v9Ap4) : Bool)
  then
    (do writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 63 56 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 35 32 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 39 36 0b0001#4)
        (if ((← (HaveLSE128 ())) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0011#4))
        else (do (pure ())))
        (if ((← (HaveGCS ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 47 44 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 3 0 0b0010#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 59 56 0b0010#4)
        (if ((←((HaveSVE2p1 ()) <||> (do
             (HaveSME2p1 ())))) : Bool)
        then
          (do writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 43 43 1#1)
              writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 27 24 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 42 42 1#1)
        writeReg PMDEVID (Sail.BitVec.updateSubrange (← readReg PMDEVID) 7 4 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 27 24 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0011#4)
        (if ((← (HaveFeatEBEP ())) : Bool)
        then (do writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 51 48 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 19 16 0b0010#4)
        writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 3 0 0b0111#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 35 32 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 39 36 0b0001#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4)
        (if ((← (HaveMTEPermExt ())) : Bool)
        then (do writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 3 0 0b0001#4))
        else (do (pure ())))
        (if ((← (HavePFAR ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 63 60 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveDoubleFault2Ext ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 59 56 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveTHExt ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 51 48 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveMTE4Ext ())) : Bool)
        then
          (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 55 52 0b0001#4)
              writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 7 4 0b0001#4)
              writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 11 8 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR4_EL1) 7 4 0b0001#4)
        (if ((← (HaveRASv2Ext ())) : Bool)
        then
          (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0011#4)
              writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 31 28 0b0011#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 43 40 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 47 44 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 55 52 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 59 56 0b0010#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 35 32 0b0001#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 31 24 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 23 16 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 15 8 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 7 0 0x1F#8)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 43 40 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0011#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 31 28 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 51 48 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 43 40 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0011#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 59 56 0b0011#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 63 60 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 3 0 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 19 16 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 15 12 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 23 20 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 27 24 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 7 4 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 63 60 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1011#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b1001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0101#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 59 56 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 19 16 0b0001#4)
        writeReg PMDEVID (Sail.BitVec.updateSubrange (← readReg PMDEVID) 3 0 0b0010#4)
        writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 27 24 0b0001#4)
        writeReg PMCFGR (BitVec.update (← readReg PMCFGR) 22 (Bit 1#1))
        writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 59 56 0b0010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b1011#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1011#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b1001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 19 16 0b0010#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 31 28 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 23 20
          (← do
            (if (((← readReg NUM_WATCHPOINTS) ≥b 16) : Bool)
            then (do (pure 0b1111#4))
            else (do (pure (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))))))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 15 12
          (← do
            (if (((← readReg NUM_BREAKPOINTS) ≥b 16) : Bool)
            then (do (pure 0b1111#4))
            else (do (pure (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0)))))))
  else (do (pure ())))

/-- Type quantifiers: k_cold : Bool -/
def __Reset (cold : Bool) : SailM Unit := do
  writeReg __last_cycle_count 0
  writeReg __last_branch_valid false
  writeReg sp_rel_access_pc (Ones (n := 64))
  writeReg __cycle_count 0

/-- Type quantifiers: k_cold : Bool -/
def ResetControlRegisters (cold : Bool) : SailM Unit := do
  (if ((← (HaveAArch64 ())) : Bool)
  then (do (AArch64_AutoGen_ArchitectureReset cold))
  else (do (AArch32_AutoGen_ArchitectureReset cold)))
  (AArch32_IMPDEFResets ())
  (AArch64_IMPDEFResets ())
  (__Reset cold)

def _TLBInvalidate (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch64_ResetControlRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg PSTATE { (← readReg PSTATE) with ZA := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with SM := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with ALLINT := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with EXLOCK := 0#1 }
  (ResetControlRegisters cold_reset)
  (pure (_TLBInvalidate ()))

/-- Type quantifiers: k_cold_reset : Bool -/
def ResetExternalDebugRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 0 0 1#1)
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 3 3 1#1)
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 5 5 1#1)
  (if (cold_reset : Bool)
  then
    (do (EDSCR_write (_update_EDSCR_Type_STATUS (← (EDSCR_read ())) 0b000010#6))
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) 0b1111#4)))
  else (do (pure ())))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch64_TakeReset (cold_reset : Bool) : SailM Unit := do
  sail_assert (← (HaveAArch64 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:33499.24-33499.25"
  writeReg PSTATE { (← readReg PSTATE) with nRW := 0#1 }
  (if ((HaveEL EL3) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with EL := EL3 })
  else
    (do (if ((HaveEL EL2) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with EL := EL2 })
        else (do writeReg PSTATE { (← readReg PSTATE) with EL := EL1 }))))
  (AArch64_ResetControlRegisters cold_reset)
  writeReg PSTATE { (← readReg PSTATE) with SP := 1#1 }
  writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb 0b1111#4 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b1111#4 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b1111#4 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b1111#4 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with DIT := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  (if ((← (HaveTME ())) : Bool)
  then (do writeReg TSTATE { (← readReg TSTATE) with depth := 0 })
  else (do (pure ())))
  (AArch64_ResetGeneralRegisters ())
  (AArch64_ResetSIMDFPRegisters ())
  (AArch64_ResetSpecialRegisters ())
  (ResetExternalDebugRegisters cold_reset)
  let rv ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rv ← (( do
    (if ((HaveEL EL3) : Bool)
    then (do readReg RVBAR_EL3)
    else
      (do (if ((HaveEL EL2) : Bool)
          then (do readReg RVBAR_EL2)
          else (do readReg RVBAR_EL1)))) ) : SailM (BitVec 64) )
  sail_assert ((is_zero_subrange rv 63 (← (AArch64_PAMax ()))) && (IsZero (Sail.BitVec.extractLsb rv 1 0))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33529.73-33529.74"
  let branch_conditional : Bool := false
  (BranchTo rv BranchType_RESET branch_conditional)

/-- Type quantifiers: ec : Int -/
def AArch64_SystemAccessTrapSyndrome (instr_in : (BitVec 32)) (ec : Int) : SailM ExceptionRecord := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let instr : (BitVec 32) := instr_in
  match ec with
  | 0 => (do (ExceptionSyndrome Exception_Uncategorized))
  | 7 =>
    (do
      let except ← (ExceptionSyndrome Exception_AdvSIMDFPAccessTrap)
      (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) }))
  | 20 =>
    (do
      let except ← (ExceptionSyndrome Exception_SystemRegister128Trap)
      let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 21 20 (Sail.BitVec.extractLsb instr 20 19)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 19 17 (Sail.BitVec.extractLsb instr 7 5)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 16 14 (Sail.BitVec.extractLsb instr 18 16)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 13 10 (Sail.BitVec.extractLsb instr 15 12)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 9 6 (Sail.BitVec.extractLsb instr 4 1)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 1 (Sail.BitVec.extractLsb instr 11 8)) }
      (pure { except with syndrome := (BitVec.update except.syndrome 0 (Bit ((BitVec.access instr 21) : BitVec 1))) }))
  | 24 =>
    (do
      let except ← (ExceptionSyndrome Exception_SystemRegisterTrap)
      let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 21 20 (Sail.BitVec.extractLsb instr 20 19)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 19 17 (Sail.BitVec.extractLsb instr 7 5)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 16 14 (Sail.BitVec.extractLsb instr 18 16)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 13 10 (Sail.BitVec.extractLsb instr 15 12)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb instr 4 0)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 1 (Sail.BitVec.extractLsb instr 11 8)) }
      (pure { except with syndrome := (BitVec.update except.syndrome 0 (Bit ((BitVec.access instr 21) : BitVec 1))) }))
  | 25 => (do (ExceptionSyndrome Exception_SVEAccessTrap))
  | 29 => (do (ExceptionSyndrome Exception_SMEAccessTrap))
  | _ =>
    (do
      (Unreachable ())
      (pure except))

/-- Type quantifiers: ec : Int -/
def AArch64_SystemAccessTrap (target_el : (BitVec 2)) (ec : Int) : SailM Unit := do
  sail_assert (←((pure ((HaveEL target_el) && (target_el != EL0))) <&&> (do
    (pure ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33913.86-33913.87"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (AArch64_SystemAccessTrapSyndrome (← (ThisInstr ())) ec) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_CheckFPAdvSIMDTrap (_ : Unit) : SailM Unit := do
  (if ((←((pure (HaveEL EL3)) <&&> (do
       (pure ((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1))) <&&> (do
       (EL3SDDUndefPriority ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
       (pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
       (EL2Enabled ())))) : Bool)
  then
    (do (if ((←((HaveVirtHostExt ()) <&&> (do
             (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailM Bool )
              let disabled ← (( do
                let b__0 ← do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2)))
                (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                      then (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                      else (do (pure false))))) ) : SailM Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do (AArch64_AdvSIMDFPAccessTrap EL2))
              else (do (pure ()))))
        else
          (do (if (((_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2)) == 1#1) : Bool)
              then (do (AArch64_AdvSIMDFPAccessTrap EL2))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
        then
          (do (if ((← (EL3SDDUndef ())) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_AdvSIMDFPAccessTrap EL3))))
        else (do (pure ()))))
  else (do (pure ())))

def AArch64_CheckFPEnabled (_ : Unit) : SailM Unit := do
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
       (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
       (pure (! (← (IsInHost ()))))))) : Bool)
  then
    (do let disabled ← (( do (undefined_bool ()) ) : SailM Bool )
        let disabled ← (( do
          let b__0 ← do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1)))
          (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
          then (do (pure true))
          else
            (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure ((← readReg PSTATE).EL == EL0)))
                else (do (pure false))))) ) : SailM Bool )
        let disabled := disabled
        (if (disabled : Bool)
        then (do (AArch64_AdvSIMDFPAccessTrap EL1))
        else (do (pure ()))))
  else (do (pure ())))
  (AArch64_CheckFPAdvSIMDTrap ())

def AArch64_CheckFPAdvSIMDEnabled (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPEnabled ())
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do
       (pure (! (← (IsFullA64Enabled ()))))))) : Bool)
  then (do (SMEAccessTrap SMEExceptionType_Streaming (← readReg PSTATE).EL))
  else (do (pure ())))

def Mk_HSTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CheckFPEnabled64 (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPEnabled ())

def CheckFPAdvSIMDEnabled64 (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch64_TakePhysicalSErrorException (implicit_esb : Bool) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure (! (← (IsInHost ())))) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x180#12)
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL3) || route_to_el3) : Bool)
    then (do (pure EL3))
    else
      (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))) ) : SailM (BitVec 2) )
  let except ← (( do (ExceptionSyndrome Exception_SError) ) : SailM ExceptionRecord )
  let syndrome ← (( do (AArch64_PhysicalSErrorSyndrome implicit_esb) ) : SailM (BitVec 25) )
  (if ((← (IsSErrorEdgeTriggered ())) : Bool)
  then (do (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))
  let except : ExceptionRecord := { except with syndrome := syndrome }
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_TakeVirtualSErrorException (_ : Unit) : SailM Unit := do
  let impdef_syndrome ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34186.63-34186.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34187.52-34187.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x180#12)
  let except ← (( do (ExceptionSyndrome Exception_SError) ) : SailM ExceptionRecord )
  let except ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then
      (do let except ← (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 24 (Bit (_get_VSESR_EL2_Type_IDS (← readReg VSESR_EL2)))))) })
          (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 23 0 (_get_VSESR_EL2_Type_ISS (← readReg VSESR_EL2))))) }))
    else
      (do let syndrome ← (( do (__IMPDEF_bits 25 "Virtual SError syndrome") ) : SailM (BitVec 25) )
          let impdef_syndrome : Bool := (((BitVec.access syndrome 24) : BitVec 1) == 1#1)
          (if (impdef_syndrome : Bool)
          then (do (pure { except with syndrome := syndrome }))
          else (do (pure except))))) ) : SailM ExceptionRecord )
  (ClearPendingVirtualSError ())
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def AArch64_TakePhysicalIRQException (_ : Unit) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x80#8)
  let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
  (if (route_to_el3 : Bool)
  then (do (AArch64_TakeException EL3 except preferred_exception_return vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
        then
          (do sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:34217.31-34217.32"
              (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else
          (do sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
                (pure ((← readReg PSTATE).EL == EL1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34220.50-34220.51"
              (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def AArch64_TakeVirtualIRQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34228.63-34228.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34229.52-34229.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x80#8)
  let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def AArch64_TakePhysicalFIQException (_ : Unit) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x100#12)
  let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
  (if (route_to_el3 : Bool)
  then (do (AArch64_TakeException EL3 except preferred_exception_return vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
        then
          (do sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:34247.31-34247.32"
              (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else
          (do sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
                (pure ((← readReg PSTATE).EL == EL1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34250.50-34250.51"
              (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def AArch64_TakeVirtualFIQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34258.63-34258.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34259.52-34259.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x100#12)
  let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def Mk_MDSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def EffectiveMDSELR_EL1_BANK (_ : Unit) : SailM (BitVec 2) := do
  let num_bp ← (( do (NumBreakpointsImplemented ()) ) : SailM Int )
  let num_wp ← (( do (NumWatchpointsImplemented ()) ) : SailM Int )
  (if (((num_bp ≤b 16) && (num_wp ≤b 16)) : Bool)
  then (do (pure 0b00#2))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_MDCR_EL3_Type_EBWE (← readReg MDCR_EL3)) == 0#1))) <||> (do
             (pure ((← readReg PSTATE).EL != EL3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_MDCR_EL2_Type_EBWE (← readReg MDCR_EL2)) == 0#1)))) <||> (do
             (pure ((← readReg PSTATE).EL == EL1)) <&&> (do
               (pure ((_get_MDSCR_EL1_Type_EMBWE (← readReg MDSCR_EL1)) == 0#1)))))) : Bool)
        then (do (pure 0b00#2))
        else
          (do let bank ← (( do (pure (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) ) : SailM (BitVec 2) )
              (if (((((bank == 0b11#2) && (num_bp ≤b 48)) && (num_wp ≤b 48)) || (((bank == 0b10#2) && (num_bp ≤b 32)) && (num_wp ≤b 32))) : Bool)
              then
                (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESMDSELR 2)
                    (pure __tup_1))
              else (do (pure bank)))))))

def AArch64_ClearEventCounters (_ : Unit) : SailM Unit := do
  let counters ← (( do (AArch64_GetNumEventCountersAccessible ()) ) : SailM Int )
  (if ((counters != 0) : Bool)
  then
    (do let loop_idx_lower := 0
        let loop_idx_upper := (counters -i 1)
        let mut loop_vars := ()
        for idx in [loop_idx_lower:loop_idx_upper:1]i do
          let () := loop_vars
          loop_vars ← do
            sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:34397.64-34397.65"
            writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) idx (Zeros (n := 64)))
        (pure loop_vars))
  else (do (pure ())))

def AArch64_PMUSwIncrement (sw_incr : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 0#1)) <&&> (do
       (pure ((_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2)) == 0#1))))) : Bool)
  then (do (pure ()))
  else
    (do let counters ← (( do (AArch64_GetNumEventCountersAccessible ()) ) : SailM Int )
        (if ((counters != 0) : Bool)
        then
          (do let loop_idx_lower := 0
              let loop_idx_upper := (counters -i 1)
              let mut loop_vars := ()
              for idx in [loop_idx_lower:loop_idx_upper:1]i do
                let () := loop_vars
                loop_vars ← do
                  sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:34413.64-34413.65"
                  (if ((((BitVec.access sw_incr idx) : BitVec 1) == 1#1) : Bool)
                  then (do (PMUEvent__2 PMU_EVENT_SW_INCR 1 idx))
                  else (do (pure ())))
              (pure loop_vars))
        else (do (pure ())))))

def undefined_PMCCNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCCNTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_conditional : Bool -/
def SPESampleAddOpOther__1 (conditional : Bool) : SailM Unit := do
  writeReg SPESampleClass 0b00#2
  writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
    (Bit
      (if (conditional : Bool)
      then 1#1
      else 0#1)))
  writeReg SPESampleOpType OpType_Other

/-- Type quantifiers: k_conditional : Bool, k_taken : Bool -/
def SPESampleAddOpOther (conditional : Bool) (taken : Bool) : SailM Unit := do
  writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 6
    (Bit
      (if ((conditional && (! taken)) : Bool)
      then 1#1
      else 0#1)))
  (SPESampleAddOpOther__1 conditional)

def Mk_PMSICR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSIRR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMBPTR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBPTR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMSDSFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSDSFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSEVFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSNEVFR_EL1_Type_E12 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_PMSNEVFR_EL1_Type_E13 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_PMSNEVFR_EL1_Type_E14 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_PMSNEVFR_EL1_Type_E15 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_PMSNEVFR_EL1_Type_E24 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_PMSNEVFR_EL1_Type_E25 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_PMSNEVFR_EL1_Type_E26 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_PMSNEVFR_EL1_Type_E27 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_PMSNEVFR_EL1_Type_E28 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_PMSNEVFR_EL1_Type_E29 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_PMSNEVFR_EL1_Type_E30 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_PMSNEVFR_EL1_Type_E31 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_PMSNEVFR_EL1_Type_E48 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _get_PMSNEVFR_EL1_Type_E49 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_PMSNEVFR_EL1_Type_E50 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_PMSNEVFR_EL1_Type_E51 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_PMSNEVFR_EL1_Type_E52 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_PMSNEVFR_EL1_Type_E53 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_PMSNEVFR_EL1_Type_E54 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_PMSNEVFR_EL1_Type_E55 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_PMSNEVFR_EL1_Type_E56 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_PMSNEVFR_EL1_Type_E57 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_PMSNEVFR_EL1_Type_E58 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_PMSNEVFR_EL1_Type_E59 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_PMSNEVFR_EL1_Type_E60 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_PMSNEVFR_EL1_Type_E61 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_PMSNEVFR_EL1_Type_E62 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _get_PMSNEVFR_EL1_Type_E63 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def Mk_PMSFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSLATFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSNEVFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def SPE_PMBIDR_P_Read (_ : Unit) : SailM (BitVec 1) := do
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let (owning_el, owning_ss) ← (( do
    let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
    let owning_ss : SecurityState := tup__0
    let owning_el : (BitVec 2) := tup__1
    (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
  (if ((←((pure ((BitVec.toNat owning_el) >b (BitVec.toNat (← readReg PSTATE).EL))) <||> (do
       (pure ((← readReg PSTATE).EL != EL3)) <&&> (do
         (pure (bne owning_ss (← (CurrentSecurityState ())))))))) : Bool)
  then (do (pure 1#1))
  else (do (pure 0#1)))

/-- Type quantifiers: k_is_load : Bool -/
def SPESampleExtendedLoadStore (ar : (BitVec 1)) (excl : (BitVec 1)) (at' : (BitVec 1)) (is_load : Bool) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  let ldst : (BitVec 1) :=
    if (is_load : Bool)
    then 0#1
    else 1#1
  writeReg SPESampleSubclass (((((0b000#3 +++ ar) +++ excl) +++ at') +++ 1#1) +++ ldst)
  writeReg SPESampleSubclassValid true
  (if (is_load : Bool)
  then
    (do (if ((at' == 1#1) : Bool)
        then (do writeReg SPESampleOpType OpType_LoadAtomic)
        else (do writeReg SPESampleOpType OpType_Load)))
  else (do writeReg SPESampleOpType OpType_Store))

def SPESampleGeneralPurposeLoadStore (_ : Unit) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 (Zeros (n := 7)))
  writeReg SPESampleSubclassValid true

def SPESampleSIMDFPLoadStore (_ : Unit) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0000010#7)
  writeReg SPESampleSubclassValid true

def SPEISB (_ : Unit) : SailM Unit := do
  let address ← (( do (pure (BitVec.addInt (← (PC_read ())) 4)) ) : SailM (BitVec 64) )
  let branch_type : BranchType := BranchType_DIR
  let branch_conditional : Bool := false
  let taken : Bool := false
  let is_isb : Bool := true
  (SPEBranch__1 address branch_type branch_conditional taken is_isb)

def Mk_BRBINFINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBSRCINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBSRCINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBTGTINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTGTINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def BRBEBranchOnISB (_ : Unit) : SailM Bool := do
  (__IMPDEF_boolean "ISB generates Branch records")

def BRBEISB (_ : Unit) : SailM Unit := do
  let branch_conditional : Bool := false
  (BRBEBranch BranchType_DIR branch_conditional (BitVec.addInt (← (PC_read ())) 4))

/-- Type quantifiers: k_branch_conditional : Bool -/
def BranchNotTaken (branchtype : BranchType) (branch_conditional : Bool) : SailM Unit := do
  let branchtaken : Bool := false
  (if ((← (HaveStatisticalProfiling ())) : Bool)
  then (do (SPEBranch (← (__UNKNOWN_bits 64)) branchtype branch_conditional branchtaken))
  else (do (pure ())))

def AArch64_PendingUnmaskedPhysicalInterrupts (mask_in : (BitVec 3)) : SailM (Bool × Bool × Bool) := do
  let fiq ← (( do (undefined_bool ()) ) : SailM Bool )
  let fiq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let mask : (BitVec 3) := mask_in
  let se_pending : (BitVec 1) :=
    if ((IsPhysicalSErrorPending ()) : Bool)
    then 1#1
    else 0#1
  let (irq, irq_nmi) ← (( do
    let (tup__0, tup__1) ← do (IRQPending ())
    let irq : Bool := tup__0
    let irq_nmi : Bool := tup__1
    (pure (irq, irq_nmi)) ) : SailM (Bool × Bool) )
  let (fiq, fiq_nmi) : (Bool × Bool) :=
    let (tup__0, tup__1) := ((FIQPending ()) : (Bool × Bool))
    let fiq : Bool := tup__0
    let fiq_nmi : Bool := tup__1
    (fiq, fiq_nmi)
  let irq_pending : (BitVec 1) :=
    if (irq : Bool)
    then 1#1
    else 0#1
  let fiq_pending : (BitVec 1) :=
    if (fiq : Bool)
    then 1#1
    else 0#1
  let allintmask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (allintmask, mask) ← (( do
    (if ((←((HaveFeatNMI ()) <&&> (do
         (pure ((_get_SCTLRType_NMI (← (SCTLR_read__1 ()))) == 1#1))))) : Bool)
    then
      (do let allintmask ← (pure ((← readReg PSTATE).ALLINT ||| ((← readReg PSTATE).SP &&& (_get_SCTLRType_SPINTMASK (← (SCTLR_read__1 ()))))))
          let mask ← (( do
            (if ((((← readReg PSTATE).EL == EL0) || (allintmask == 0#1)) : Bool)
            then
              (do let mask : (BitVec 3) :=
                    if (irq_nmi : Bool)
                    then (BitVec.update mask 1 (Bit 0#1))
                    else mask
                  (if (fiq_nmi : Bool)
                  then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                  else (do (pure mask))))
            else (do (pure mask))) ) : SailM (BitVec 3) )
          (pure (allintmask, mask)))
    else
      (do let allintmask : (BitVec 1) := 0#1
          (pure (allintmask, mask)))) ) : SailM ((BitVec 1) × (BitVec 3)) )
  let pending : (BitVec 3) := ((se_pending +++ irq_pending) +++ fiq_pending)
  let mask ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do let mask_override ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
          let mask_override ← (( do
            (if ((←((HaveVirtHostExt ()) <&&> (do
                 (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))) <&&> (do
                 (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
            then (do (pure 0b000#3))
            else
              (do (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1) : Bool)
                  then (do (pure 0b111#3))
                  else (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))))))))) ) : SailM (BitVec 3) )
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
          then (do (pure (mask &&& (Complement.complement mask_override))))
          else
            (do (if (((← readReg PSTATE).EL == EL2) : Bool)
                then
                  (do (if ((←((pure (! (← (ELUsingAArch32 EL2)))) <&&> (do
                           (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
                      then (do (pure (mask ||| (Complement.complement mask_override))))
                      else (do (pure mask))))
                else (do (pure mask))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let mask ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do (if (((← readReg PSTATE).EL != EL3) : Bool)
          then (do (pure (mask &&& (Complement.complement ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) +++ ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))))))))
          else (do (pure (mask ||| (Complement.complement ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) +++ ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))))))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let mask ← (( do
    (if ((((← readReg PSTATE).EL != EL0) && (allintmask == 1#1)) : Bool)
    then
      (do (if (((← readReg PSTATE).EL == EL1) : Bool)
          then
            (do let mask ← (( do
                  (if ((←((pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 0#1)) <&&> (do
                       (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 0#1))))) : Bool)
                  then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                  else (do (pure mask))) ) : SailM (BitVec 3) )
                (if ((←((pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 0#1)) <&&> (do
                     (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 0#1))))) : Bool)
                then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                else (do (pure mask))))
          else
            (do (if (((← readReg PSTATE).EL == EL2) : Bool)
                then
                  (do let mask ← (( do
                        (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
                      then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                      else (do (pure mask))))
                else
                  (do let mask ← (( do
                        (if (((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1) : Bool)
                      then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                      else (do (pure mask))))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
  (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))

def AArch32_PendingUnmaskedPhysicalInterrupts (_ : Unit) : SailM (Bool × Bool × Bool) := do
  let fiq ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq ← (( do (undefined_bool ()) ) : SailM Bool )
  let mask_override ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  (if ((←((pure (HaveEL EL3)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
  then (do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
  else
    (do let se_pending : (BitVec 1) :=
          if ((IsPhysicalSErrorPending ()) : Bool)
          then 1#1
          else 0#1
        let irq ← (( do
          let (__tup_0, _) ← do (IRQPending ())
          (pure __tup_0) ) : SailM Bool )
        let fiq : Bool :=
          let (__tup_0, _) := (FIQPending ())
          __tup_0
        let irq_pending : (BitVec 1) :=
          if (irq : Bool)
          then 1#1
          else 0#1
        let fiq_pending : (BitVec 1) :=
          if (fiq : Bool)
          then 1#1
          else 0#1
        let pending : (BitVec 3) := ((se_pending +++ irq_pending) +++ fiq_pending)
        let mask ← (( do (pure ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))) ) : SailM (BitVec 3) )
        let mask ← (( do
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then
            (do let mask_override ← (( do
                  (if (((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1) : Bool)
                  then (do (pure 0b111#3))
                  else (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) +++ ((_get_HCR_Type_IMO (← (HCR_read ()))) +++ (_get_HCR_Type_FMO (← (HCR_read ())))))))) ) : SailM (BitVec 3) )
                (pure (mask &&& (Complement.complement mask_override))))
          else (do (pure mask))) ) : SailM (BitVec 3) )
        let mask ← (( do
          (if ((←((pure (HaveEL EL3)) <&&> (do
               (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
          then
            (do (if (((← readReg PSTATE).EL != EL3) : Bool)
                then
                  (do let mask ← (( do
                        (if ((←((pure ((_get_SCR_Type_FIQ (← readReg SCR)) == 1#1)) <&&> (do
                             (pure ((_get_SCR_Type_FW (← readReg SCR)) == 0#1)) <||> (do
                               (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1)))))) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      let mask ← (( do
                        (if ((←((pure ((_get_SCR_Type_IRQ (← readReg SCR)) == 1#1)) <&&> (do
                             (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1))))) : Bool)
                        then (do (pure (BitVec.update mask 1 (Bit 0#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if ((←((pure ((← (EffectiveEA ())) == 1#1)) <&&> (do
                           (pure ((_get_SCR_Type_AW (← readReg SCR)) == 0#1)) <||> (do
                             (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1)))))) : Bool)
                      then (do (pure (BitVec.update mask 2 (Bit 0#1))))
                      else (do (pure mask))))
                else (do (pure mask))))
          else (do (pure mask))) ) : SailM (BitVec 3) )
        let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
        (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))))

def DecodeRegExtend (op : (BitVec 3)) : SailM ExtendType := do
  match op with
  | 0b000 => (pure ExtendType_UXTB)
  | 0b001 => (pure ExtendType_UXTH)
  | 0b010 => (pure ExtendType_UXTW)
  | 0b011 => (pure ExtendType_UXTX)
  | 0b100 => (pure ExtendType_SXTB)
  | 0b101 => (pure ExtendType_SXTH)
  | 0b110 => (pure ExtendType_SXTW)
  | 0b111 => (pure ExtendType_SXTX)
  | _ => (do (undefined_ExtendType ()))

/-- Type quantifiers: N : Nat, reg : Int, shift : Int, N ≥ 0 ∧ N = 8 ∨ N = 16 ∨ N = 32 ∨ N = 64 ∨ (not (shift ≥ 0 ∧ shift ≤ 4)) -/
def ExtendReg (reg : Int) (exttype : ExtendType) (shift : Int) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((shift ≥b 0) && (shift ≤b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:35781.34-35781.35"
  let val_name ← (( do (X_read reg N) ) : SailM (BitVec N) )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let len ← (( do (undefined_int ()) ) : SailM Int )
  let (is_unsigned, len) : (Bool × Int) :=
    match exttype with
    | .ExtendType_SXTB =>
      (let is_unsigned : Bool := false
      let len : Int := 8
      (is_unsigned, len))
    | .ExtendType_SXTH =>
      (let is_unsigned : Bool := false
      let len : Int := 16
      (is_unsigned, len))
    | .ExtendType_SXTW =>
      (let is_unsigned : Bool := false
      let len : Int := 32
      (is_unsigned, len))
    | .ExtendType_SXTX =>
      (let is_unsigned : Bool := false
      let len : Int := 64
      (is_unsigned, len))
    | .ExtendType_UXTB =>
      (let is_unsigned : Bool := true
      let len : Int := 8
      (is_unsigned, len))
    | .ExtendType_UXTH =>
      (let is_unsigned : Bool := true
      let len : Int := 16
      (is_unsigned, len))
    | .ExtendType_UXTW =>
      (let is_unsigned : Bool := true
      let len : Int := 32
      (is_unsigned, len))
    | .ExtendType_UXTX =>
      (let is_unsigned : Bool := true
      let len : Int := 64
      (is_unsigned, len))
  let is_unsigned := is_unsigned
  let len := (Min.min len (N -i shift))
  sail_assert ((0 ≤b (len -i 1)) || (! ((shift ≥b 0) && (shift ≤b 4)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:35821.73-35821.74"
  (Extend ((Sail.BitVec.extractLsb val_name (len -i 1) 0) +++ (Zeros (n := shift))) N is_unsigned)

def DecodeShift (op : (BitVec 2)) : SailM ShiftType := do
  match op with
  | 0b00 => (pure ShiftType_LSL)
  | 0b01 => (pure ShiftType_LSR)
  | 0b10 => (pure ShiftType_ASR)
  | 0b11 => (pure ShiftType_ROR)
  | _ => (do (undefined_ShiftType ()))

/-- Type quantifiers: N : Nat, amount : Int, reg : Int, List.elem N [8, 16, 32, 64] -/
def ShiftReg (reg : Int) (shiftype : ShiftType) (amount : Int) (N : Nat) : SailM (BitVec N) := do
  let result ← (( do (X_read reg N) ) : SailM (BitVec N) )
  match shiftype with
  | .ShiftType_LSL => (pure (result <<< amount))
  | .ShiftType_LSR => (pure (result >>> amount))
  | .ShiftType_ASR => (pure (BitVec.sshiftRight result amount))
  | .ShiftType_ROR =>
    (do
      sail_assert ((N >b 0) && (amount ≥b 0)) "sail-arm/arm-v9.4-a/src/v8_base.sail:35864.52-35864.53"
      (pure (ROR result amount)))

/-- Type quantifiers: k_stream : Bool, target : Int -/
def Hint_Prefetch (address : (BitVec 64)) (hint : PrefetchHint) (target : Int) (stream : Bool) : Unit :=
  ()

def Prefetch (address : (BitVec 64)) (prfop : (BitVec 5)) : SailM Unit := SailME.run do
  let hint ← (( do (undefined_PrefetchHint ()) ) : SailME Unit PrefetchHint )
  let hint ← (( do
    match (Sail.BitVec.extractLsb prfop 4 3) with
    | 0b00 => (pure Prefetch_READ)
    | 0b01 => (pure Prefetch_EXEC)
    | 0b10 => (pure Prefetch_WRITE)
    | _ => SailME.throw (() : Unit) ) : SailME Unit PrefetchHint )
  let target := (BitVec.toNat (Sail.BitVec.extractLsb prfop 2 1))
  let stream : Bool := (((BitVec.access prfop 0) : BitVec 1) != 0#1)
  let _ : Unit := (Hint_Prefetch address hint target stream)
  (pure ())

def Mk_DCZID_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DCZID_EL0_Type_BS (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def AArch64_MemZero (regval : (BitVec 64)) (cachetype : CacheType) : SailM Unit := do
  let size ← (( do (pure (4 *i (2 ^i (BitVec.toNat (_get_DCZID_EL0_Type_BS (← readReg DCZID_EL0)))))) ) : SailM Nat )
  sail_assert (size ≤b MAX_ZERO_BLOCK_SIZE) "sail-arm/arm-v9.4-a/src/v8_base.sail:36724.38-36724.39"
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do sail_assert (size ≥b TAG_GRANULE) "sail-arm/arm-v9.4-a/src/v8_base.sail:36726.34-36726.35")
  else (do (pure ())))
  let vaddress : (BitVec 64) := (Align_bits regval size)
  let tagaccess : Bool := ((BEq.beq cachetype CacheType_Tag) || (BEq.beq cachetype CacheType_Data_Tag))
  let tagchecked : Bool := (BEq.beq cachetype CacheType_Data)
  let accdesc ← (( do (CreateAccDescDCZero tagaccess tagchecked) ) : SailM AccessDescriptor )
  (if (((BEq.beq cachetype CacheType_Tag) || (BEq.beq cachetype CacheType_Data_Tag)) : Bool)
  then (do (AArch64_TagMemZero regval vaddress accdesc size))
  else (do (pure ())))
  (if (((BEq.beq cachetype CacheType_Data) || (BEq.beq cachetype CacheType_Data_Tag)) : Bool)
  then (do (AArch64_DataMemZero regval vaddress accdesc size))
  else (do (pure ())))

def undefined_MAIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_MAIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_HMAIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_HMAIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DACR32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def __IMPDEF_bit (x : String) : SailM (BitVec 1) := do
  (__UNKNOWN_bit ())

def undefined_DBGDTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGDTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def DBGDTR_EL0_read__1 (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _DBGDTR_EL0 ) : SailM DBGDTR_EL0_Type )
  let r ← (( do
    (if ((← (__IMPDEF_boolean "read")) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32))))
    else
      (do (if ((← (__IMPDEF_boolean "read")) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32))))
          else (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))))) ) : SailM (BitVec 64) )
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))
        else (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32)))))))

def Mk_MDCCINT_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CheckOSUnlockCatch (_ : Unit) : SailM Unit := do
  (if ((←((HaveDoPD ()) <&&> (do
       (pure ((_get_CTIDEVCTL_Type_OSUCE (← readReg CTIDEVCTL)) == 1#1))) <||> (do
       (pure (! (← (HaveDoPD ())))) <&&> (do
         (pure ((_get_EDECR_Type_OSUCE (← readReg EDECR)) == 1#1)))))) : Bool)
  then
    (do (if ((! (← (Halted ()))) : Bool)
        then (do writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 0 0 1#1))
        else (do (pure ()))))
  else (do (pure ())))

def Mk_TRFCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_TRFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def TraceSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def undefined_DBGBCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGBVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGBXVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGVCR32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DBGWCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGWVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

/-- Type quantifiers: n : Int -/
def Q_set (n : Int) (value_name : (BitVec 128)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 15)) "sail-arm/arm-v9.4-a/src/v8_base.sail:42248.27-42248.28"
  (V_set n 128 value_name)

def AArch32_ResetGeneralRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 7
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (R_set i (← (__UNKNOWN_bits 32)))
  (pure loop_vars)
  let loop_i_lower := 8
  let loop_i_upper := 12
  let mut loop_vars_1 := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars_1
    loop_vars_1 ← do
      (Rmode_set i M32_User (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_FIQ (← (__UNKNOWN_bits 32)))
  (pure loop_vars_1)
  (if ((HaveEL EL2) : Bool)
  then (do (Rmode_set 13 M32_Hyp (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  let loop_i_lower := 13
  let loop_i_upper := 14
  let mut loop_vars_2 := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars_2
    loop_vars_2 ← do
      (Rmode_set i M32_User (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_FIQ (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_IRQ (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Svc (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Abort (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Undef (← (__UNKNOWN_bits 32)))
      (if ((HaveEL EL3) : Bool)
      then (do (Rmode_set i M32_Monitor (← (__UNKNOWN_bits 32))))
      else (do (pure ())))
  (pure loop_vars_2)

def AArch32_ResetSIMDFPRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (Q_set i (← (__UNKNOWN_bits 128)))
  (pure loop_vars)

def AArch32_ResetSpecialRegisters (_ : Unit) : SailM Unit := do
  writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 31 0 (← (__UNKNOWN_bits 32)))
  writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 31 0 (← (__UNKNOWN_bits 32)))
  (SPSR_svc_write (Mk_SPSR_svc_Type (Sail.BitVec.updateSubrange (← (SPSR_svc_read ())) 31 0 (← (__UNKNOWN_bits 32)))))
  writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 31 0 (← (__UNKNOWN_bits 32)))
  writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 31 0 (← (__UNKNOWN_bits 32)))
  (if ((HaveEL EL2) : Bool)
  then
    (do (SPSR_hyp_write (Mk_SPSR_hyp_Type (← (__UNKNOWN_bits 32))))
        (ELR_hyp_write (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then (do writeReg SPSR_mon (Mk_SPSR_mon_Type (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch32_ResetControlRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
  (ResetControlRegisters cold_reset)
  (pure (_TLBInvalidate ()))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch32_TakeReset (cold_reset : Bool) : SailM Unit := do
  sail_assert (! (← (HaveAArch64 ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:42835.34-42835.35"
  (if ((HaveEL EL3) : Bool)
  then
    (do (AArch32_WriteMode M32_Svc)
        writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else
    (do (if ((HaveEL EL2) : Bool)
        then (do (AArch32_WriteMode M32_Hyp))
        else (do (AArch32_WriteMode M32_Svc)))))
  (AArch32_ResetControlRegisters cold_reset)
  (FPEXC_write (_update_FPEXC_Type_EN (← (FPEXC_read ())) 0#1))
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if (((HaveEL EL2) && (! (HaveEL EL3))) : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_HSCTLR_Type_TE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) })
  else
    (do writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }))
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  (AArch32_ResetGeneralRegisters ())
  (AArch32_ResetSIMDFPRegisters ())
  (AArch32_ResetSpecialRegisters ())
  (ResetExternalDebugRegisters cold_reset)
  let rv ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let rv ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do (if ((((BitVec.access (← readReg MVBAR) 0) : BitVec 1) == 1#1) : Bool)
          then (do (pure ((Sail.BitVec.extractLsb (← readReg MVBAR) 31 1) +++ 0#1)))
          else (do (__IMPDEF_bits 32 "reset vector address"))))
    else (do (pure ((Sail.BitVec.extractLsb (← readReg RVBAR) 31 1) +++ 0#1)))) ) : SailM (BitVec 32) )
  sail_assert (←((pure (((BitVec.access rv 0) : BitVec 1) == 0#1)) <&&> (do
    (pure (((← readReg PSTATE).T == 1#1) || (((BitVec.access rv 1) : BitVec 1) == 0#1)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:42870.62-42870.63"
  let branch_conditional : Bool := false
  (BranchTo rv BranchType_RESET branch_conditional)

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch32_TakePhysicalSErrorException (implicit_esb : Bool) : SailM Unit := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure (! (← (IsInHost ())))) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalSErrorException implicit_esb))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_EA (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if (route_to_monitor : Bool)
    then (do (pure EL3))
    else
      (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))) ) : SailM (BitVec 2) )
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let vaddress ← (( do (__UNKNOWN_bits 32) ) : SailM (BitVec 32) )
  let except ← (( do (AArch32_AbortSyndrome Exception_DataAbort fault vaddress target_el) ) : SailM ExceptionRecord )
  (if ((← (IsSErrorEdgeTriggered ())) : Bool)
  then (do (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))
  let questionMark := target_el
  (if ((questionMark == EL3) : Bool)
  then
    (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (if ((questionMark == EL1) : Bool)
              then
                (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
                    (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset))
              else (do (Unreachable ())))))))

def AArch32_TakeVirtualSErrorException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43224.63-43224.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43226.62-43226.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43228.56-43228.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualSErrorException ()))
  else (do (pure ())))
  let route_to_monitor : Bool := false
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  let vaddress ← (( do (__UNKNOWN_bits 32) ) : SailM (BitVec 32) )
  let parity : Bool := false
  let fault : Fault := Fault_AsyncExternal
  let level ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let fsr : (BitVec 32) := (Zeros (n := 32))
  let fsr ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then
      (do (if ((← (ELUsingAArch32 EL2)) : Bool)
          then
            (do let fsr ← (pure (Sail.BitVec.updateSubrange fsr 15 14 (_get_VDFSR_Type_AET (← (VDFSR_read ())))))
                (pure (BitVec.update fsr 12 (Bit (_get_VDFSR_Type_ExT (← (VDFSR_read ())))))))
          else
            (do let fsr ← (pure (Sail.BitVec.updateSubrange fsr 15 14 (_get_VSESR_EL2_Type_AET (← readReg VSESR_EL2))))
                (pure (BitVec.update fsr 12 (Bit (_get_VSESR_EL2_Type_ExT (← readReg VSESR_EL2))))))))
    else (do (pure (BitVec.update fsr 12 (Bit (← (__IMPDEF_bit "Virtual External abort type"))))))) ) : SailM (BitVec 32) )
  let fsr ← (( do
    (if (((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1) : Bool)
    then
      (do let fsr : (BitVec 32) := (BitVec.update fsr 9 (Bit 1#1))
          (pure (Sail.BitVec.updateSubrange fsr 5 0 (← (EncodeLDFSC fault level)))))
    else
      (do let fsr : (BitVec 32) := (BitVec.update fsr 9 (Bit 0#1))
          let split_vec ← do (EncodeSDFSC fault level)
          let fsr : (BitVec 32) := (Sail.BitVec.updateSubrange fsr 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
          (pure (Sail.BitVec.updateSubrange fsr 3 0 (Sail.BitVec.extractLsb split_vec 3 0))))) ) : SailM (BitVec 32) )
  (DFSR_write (Mk_DFSR_Type fsr))
  (DFAR_write (← (__UNKNOWN_bits 32)))
  (ClearPendingVirtualSError ())
  (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)

def AArch32_TakePhysicalIRQException (_ : Unit) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (pure (! (← (IsInHost ())))))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalIRQException ()))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_IRQ (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x18#8)
  let lr_offset := 4
  (if (route_to_monitor : Bool)
  then (do (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
              (AArch32_EnterHypMode except preferred_exception_return vect_offset))
        else (do (AArch32_EnterMode M32_IRQ preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeVirtualIRQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43298.63-43298.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43300.62-43300.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43302.56-43302.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualIRQException ()))
  else (do (pure ())))
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x18#8)
  let lr_offset := 4
  (AArch32_EnterMode M32_IRQ preferred_exception_return lr_offset vect_offset)

def AArch32_TakePhysicalFIQException (_ : Unit) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (pure (! (← (IsInHost ())))))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalFIQException ()))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_FIQ (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x1C#8)
  let lr_offset := 4
  (if (route_to_monitor : Bool)
  then (do (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
              (AArch32_EnterHypMode except preferred_exception_return vect_offset))
        else (do (AArch32_EnterMode M32_FIQ preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeVirtualFIQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43345.63-43345.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43347.62-43347.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43349.56-43349.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualFIQException ()))
  else (do (pure ())))
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x1C#8)
  let lr_offset := 4
  (AArch32_EnterMode M32_FIQ preferred_exception_return lr_offset vect_offset)

def undefined_PMOVSSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCCNTR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HDFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HDFGWTR_EL2_Type_DBGCLAIM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HDFGWTR_EL2_Type_DBGPRCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HDFGWTR_EL2_Type_MDSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HDFGWTR_EL2_Type_OSDLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HDFGWTR_EL2_Type_OSECCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_HDFGWTR_EL2_Type_PMBLIMITR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_HDFGWTR_EL2_Type_PMBPTR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_HDFGWTR_EL2_Type_PMBSR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_HDFGWTR_EL2_Type_PMCCFILTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_HDFGWTR_EL2_Type_PMCCNTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_HDFGWTR_EL2_Type_PMCNTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HDFGWTR_EL2_Type_PMINTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HDFGWTR_EL2_Type_PMOVS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_HDFGWTR_EL2_Type_PMSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_HDFGWTR_EL2_Type_PMSELR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HDFGWTR_EL2_Type_PMSEVFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_HDFGWTR_EL2_Type_PMSFCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_HDFGWTR_EL2_Type_PMSICR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_HDFGWTR_EL2_Type_PMSIRR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_HDFGWTR_EL2_Type_PMSLATFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HDFGWTR_EL2_Type_PMUSERENR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_HDFGWTR_EL2_Type_nBRBCTL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_HDFGWTR_EL2_Type_nBRBDATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_HDFGWTR_EL2_Type_nPMSNEVFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)


end ArmASL.Functions
