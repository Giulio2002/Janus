import Sail
import ArmASL.Defs
import ArmASL.SpecializationV1
import ArmASL.FakeReal
import ArmASL.JanusExtras

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: x : Int -/
def __id (x : Int) : Int :=
  x

/-- Type quantifiers: k_ex3323722_ : Bool, k_ex3323721_ : Bool -/
def neq_bool (x : Bool) (y : Bool) : Bool :=
  (! (x == y))

/-- Type quantifiers: k_n : Nat, y : Nat, k_n ≥ 0 ∧ y ≥ 0 -/
def eq_bits_int (x : (BitVec k_n)) (y : Nat) : Bool :=
  ((BitVec.toNatInt x) == y)

/-- Type quantifiers: n : Int, m : Int -/
def _shl_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftl m n)
  else (Int.shiftr m (Neg.neg n))

/-- Type quantifiers: n : Int, m : Int -/
def _shr_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftr m n)
  else (Int.shiftl m (Neg.neg n))

/-- Type quantifiers: m : Int, n : Int -/
def fdiv_int (n : Int) (m : Int) : Int :=
  if (((n <b 0) && (m >b 0)) : Bool)
  then ((Int.tdiv (n +i 1) m) -i 1)
  else
    (if (((n >b 0) && (m <b 0)) : Bool)
    then ((Int.tdiv (n -i 1) m) -i 1)
    else (Int.tdiv n m))

/-- Type quantifiers: m : Int, n : Int -/
def fmod_int (n : Int) (m : Int) : Int :=
  (n -i (m *i (fdiv_int n m)))

def enable_tracing (_ : Unit) : Unit :=
  ()

def disable_tracing (_ : Unit) : Unit :=
  ()

def is_tracing (_ : Unit) : Bool :=
  false

/-- Type quantifiers: len : Nat, k_v : Nat, len ≥ 0 ∧ k_v ≥ 0 -/
def sail_mask (len : Nat) (v : (BitVec k_v)) : (BitVec len) :=
  if ((len ≤b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v len)
  else (Sail.BitVec.zeroExtend v len)

/-- Type quantifiers: i : Int, hi : Int, lo : Int, lo ≤ hi -/
def integer_subrange (i : Int) (hi : Int) (lo : Int) : (BitVec (hi - lo + 1)) :=
  (get_slice_int ((hi -i lo) +i 1) i lo)

/-- Type quantifiers: i : Int, n : Int -/
def integer_access (i : Int) (n : Int) : (BitVec 1) :=
  (BitVec.access (integer_subrange i n n) 0)

/-- Type quantifiers: i : Int, hi : Nat, lo : Nat, 0 ≤ lo ∧ lo ≤ hi -/
def integer_update_subrange (i : Int) (hi : Nat) (lo : Nat) (x : (BitVec (hi - lo + 1))) : Int :=
  (set_slice_int ((hi -i lo) +i 1) i lo x)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def sail_ones (n : Nat) : (BitVec n) :=
  (Complement.complement (BitVec.zero n))

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def slice_mask {n : _} (i : Int) (l : Int) : (BitVec n) :=
  if ((l ≥b n) : Bool)
  then ((sail_ones n) <<< i)
  else
    (let one : (BitVec n) := (sail_mask n (1#1 : (BitVec 1)))
    (((one <<< l) - one) <<< i))

/-- Type quantifiers: n : Nat, n > 0 -/
def to_bytes_le {n : _} (b : (BitVec (8 * n))) : (Vector (BitVec 8) n) := Id.run do
  let res := (vectorInit (BitVec.zero 8))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (vectorUpdate res i (Sail.BitVec.extractLsb b ((8 *i i) +i 7) (8 *i i)))
  (pure loop_vars)

/-- Type quantifiers: n : Nat, n > 0 -/
def from_bytes_le {n : _} (v : (Vector (BitVec 8) n)) : (BitVec (8 * n)) := Id.run do
  let res := (BitVec.zero (8 *i n))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (Sail.BitVec.updateSubrange res ((8 *i i) +i 7) (8 *i i) (GetElem?.getElem! v i))
  (pure loop_vars)

/-- Type quantifiers: k_n : Int -/
def concat_str_bits (str : String) (x : (BitVec k_n)) : String :=
  (HAppend.hAppend str (BitVec.toFormatted x))

/-- Type quantifiers: x : Int -/
def concat_str_dec (str : String) (x : Int) : String :=
  (HAppend.hAppend str (Int.repr x))

/-- Type quantifiers: k_n : Nat, List.elem k_n [8, 16, 32, 64, 128] -/
def reverse_endianness (xs : (BitVec k_n)) : (BitVec k_n) :=
  let len := (Sail.BitVec.length xs)
  if ((len == 8) : Bool)
  then xs
  else
    (if ((len == 16) : Bool)
    then ((Sail.BitVec.extractLsb xs 7 0) +++ (Sail.BitVec.extractLsb xs 15 8))
    else
      (if ((len == 32) : Bool)
      then ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ (Sail.BitVec.extractLsb xs 31 24))))
      else
        (if ((len == 64) : Bool)
        then ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ ((Sail.BitVec.extractLsb xs 31 24) +++ ((Sail.BitVec.extractLsb xs 39 32) +++ ((Sail.BitVec.extractLsb xs 47 40) +++ ((Sail.BitVec.extractLsb xs 55 48) +++ (Sail.BitVec.extractLsb xs 63 56))))))))
        else ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ ((Sail.BitVec.extractLsb xs 31 24) +++ ((Sail.BitVec.extractLsb xs 39 32) +++ ((Sail.BitVec.extractLsb xs 47 40) +++ ((Sail.BitVec.extractLsb xs 55 48) +++ ((Sail.BitVec.extractLsb xs 63 56) +++ ((Sail.BitVec.extractLsb xs 71 64) +++ ((Sail.BitVec.extractLsb xs 79 72) +++ ((Sail.BitVec.extractLsb xs 87 80) +++ ((Sail.BitVec.extractLsb xs 95 88) +++ ((Sail.BitVec.extractLsb xs 103 96) +++ ((Sail.BitVec.extractLsb xs 111 104) +++ ((Sail.BitVec.extractLsb xs 119 112) +++ (Sail.BitVec.extractLsb xs 127 120)))))))))))))))))))

/-- Type quantifiers: k_a : Type -/
def is_none (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => false
  | none => true

/-- Type quantifiers: k_a : Type -/
def is_some (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => true
  | none => false

/-- Type quantifiers: k_n : Int, m : Nat, m ≥ 0 -/
def extzv {m : _} (v : (BitVec k_n)) : (BitVec m) :=
  if ((m <b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v m)
  else (Sail.BitVec.zeroExtend v m)

/-- Type quantifiers: k_n : Int, m : Nat, m ≥ 0 -/
def extsv {m : _} (v : (BitVec k_n)) : (BitVec m) :=
  if ((m <b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v m)
  else (Sail.BitVec.signExtend v m)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_zero_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) == (extzv (m := (Sail.BitVec.length xs)) (0#1 : (BitVec 1))))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_zeros_slice (xs : (BitVec k_n)) (i : Int) (l : Int) : Bool :=
  ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) == (extzv (m := (Sail.BitVec.length xs)) (0#1 : (BitVec 1))))

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_ones_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  let m : (BitVec k_n) := (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))
  ((xs &&& m) == m)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_ones_slice (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  let m : (BitVec k_n) := (slice_mask (n := (Sail.BitVec.length xs)) i j)
  ((xs &&& m) == m)

/-- Type quantifiers: l' : Int, i' : Int, l : Int, i : Int, k_n : Nat, k_m : Nat, r : Nat, k_n ≥ 0 ∧ k_m ≥ 0 ∧ r ≥ 0 -/
def slice_slice_concat {r : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (ys : (BitVec k_m)) (i' : Int) (l' : Int) : (BitVec r) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) i' l')) >>> i')
  (((extzv (m := r) xs) <<< l') ||| (extzv (m := r) ys))

/-- Type quantifiers: i : Int, k_n : Nat, l : Int, l' : Int, k_n ≥ 0 ∧ (l + l') ≥ 0 -/
def slice_zeros_concat (xs : (BitVec k_n)) (i : Int) (l : Int) (l' : Int) : (BitVec (l + l')) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  ((extzv (m := (l +i l')) xs) <<< l')

/-- Type quantifiers: k_n : Nat, hi : Int, lo : Int, l' : Int, k_n ≥ 0 ∧ (hi - lo + 1 + l') ≥ 0 -/
def subrange_zeros_concat (xs : (BitVec k_n)) (hi : Int) (lo : Int) (l' : Int) : (BitVec (hi - lo + 1 + l')) :=
  (slice_zeros_concat xs lo ((hi -i lo) +i 1) l')

/-- Type quantifiers: j' : Int, i' : Int, j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def subrange_subrange_eq (xs : (BitVec k_n)) (i : Int) (j : Int) (ys : (BitVec k_n)) (i' : Int) (j' : Int) : Bool :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length ys)) j ((i -i j) +i 1))) >>> j)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) j' ((i' -i j') +i 1))) >>> j')
  (xs == ys)

/-- Type quantifiers: k_n : Nat, i : Int, j : Int, k_m : Nat, i' : Int, j' : Int, s : Nat, s ≥ 0 ∧ k_n ≥ 0 ∧ k_m ≥ 0 -/
def subrange_subrange_concat {s : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (ys : (BitVec k_m)) (i' : Int) (j' : Int) : (BitVec s) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) j' ((i' -i j') +i 1))) >>> j')
  (((extzv (m := s) xs) <<< ((i' -i j') +i 1)) ||| (extzv (m := s) ys))

/-- Type quantifiers: shift : Int, j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (shift : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  ((extzv (m := m) xs) <<< shift)

/-- Type quantifiers: shift : Int, l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (shift : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  ((extzv (m := m) xs) <<< shift)

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def set_slice_zeros {n : _} (xs : (BitVec n)) (i : Int) (l : Int) : (BitVec n) :=
  let ys : (BitVec n) := (slice_mask (n := n) i l)
  (xs &&& (Complement.complement ys))

/-- Type quantifiers: lo : Int, hi : Int, n : Nat, n ≥ 0 -/
def set_subrange_zeros {n : _} (xs : (BitVec n)) (hi : Int) (lo : Int) : (BitVec n) :=
  (set_slice_zeros (n := n) xs lo ((hi -i lo) +i 1))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def zext_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  (extzv (m := m) xs)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def zext_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) : (BitVec m) :=
  (zext_slice (m := m) xs j ((i -i j) +i 1))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def sext_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) : (BitVec m) :=
  let xs := (BitVec.sshiftRight ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) <<< (((Sail.BitVec.length xs) -i i) -i l)) ((Sail.BitVec.length xs) -i l))
  (extsv (m := m) xs)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def sext_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) : (BitVec m) :=
  (sext_slice (m := m) xs j ((i -i j) +i 1))

/-- Type quantifiers: shift : Int, l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_slice_signed {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (shift : Int) : (BitVec m) :=
  ((sext_slice (m := m) xs i l) <<< shift)

/-- Type quantifiers: shift : Int, j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_subrange_signed {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (shift : Int) : (BitVec m) :=
  (place_slice_signed (m := m) xs j ((i -i j) +i 1) shift)

/-- Type quantifiers: i : Int, k_n : Nat, l : Nat, k_n ≥ 0 ∧ l ≥ 0 -/
def unsigned_slice (xs : (BitVec k_n)) (i : Int) (l : Nat) : Int :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  (Nat.mod (BitVec.toNat xs) (pow2 l))

/-- Type quantifiers: k_n : Nat, i : Int, j : Int, k_n ≥ 0 ∧ (i - j) ≥ 0 -/
def unsigned_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Int :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  (Nat.mod (BitVec.toNat xs) (pow2 ((i -i j) +i 1)))

/-- Type quantifiers: m : Int, n : Nat, n ≥ 0 -/
def zext_ones {n : _} (m : Int) : (BitVec n) :=
  let v : (BitVec n) := (extsv (m := n) (1#1 : (BitVec 1)))
  (v >>> (n -i m))

/-- Type quantifiers: n : Nat, s1 : Nat, e1 : Nat, k_n2 : Nat, s2 : Nat, e2 : Nat, 0 ≤ e1 ∧ e1 ≤ s1 ∧ s1 < n ∧ 0 ≤ e2 ∧ e2 ≤ s2 ∧ s2 < k_n2 ∧ (s1 - e1) = (s2 - e2) -/
def vector_update_subrange_from_subrange {n : _} (v1 : (BitVec n)) (s1 : Nat) (e1 : Nat) (v2 : (BitVec k_n2)) (s2 : Nat) (e2 : Nat) : (BitVec n) :=
  let xs := ((v2 &&& (slice_mask (n := (Sail.BitVec.length v2)) e2 ((s2 -i e2) +i 1))) >>> e2)
  let xs := ((extzv (m := n) xs) <<< e1)
  let ys := (v1 &&& (Complement.complement (slice_mask (n := (Sail.BitVec.length xs)) e1 ((s1 -i e1) +i 1))))
  (xs ||| ys)

/-- Type quantifiers: i : Int, n1 : Nat, s1 : Nat, e1 : Nat, s2 : Nat, e2 : Nat, 0 ≤ e1 ∧ e1 ≤ s1 ∧ s1 < n1 ∧ 0 ≤ e2 ∧ e2 ≤ s2 ∧ (s1 - e1) = (s2 - e2) -/
def vector_update_subrange_from_integer_subrange {n1 : _} (v1 : (BitVec n1)) (s1 : Nat) (e1 : Nat) (i : Int) (s2 : Nat) (e2 : Nat) : (BitVec n1) :=
  let v2 : (BitVec n1) := (get_slice_int n1 i e2)
  (vector_update_subrange_from_subrange (n := n1) v1 s1 e1 v2 (s2 -i e2) 0)

/-- Type quantifiers: k_a : Type, k_b : Type -/
def is_ok (r : (Result k_a k_b)) : Bool :=
  match r with
  | .Ok _ => true
  | .Err _ => false

/-- Type quantifiers: k_a : Type, k_b : Type -/
def is_err (r : (Result k_a k_b)) : Bool :=
  match r with
  | .Ok _ => false
  | .Err _ => true

/-- Type quantifiers: k_a : Type, k_b : Type -/
def ok_option (r : (Result k_a k_b)) : (Option k_a) :=
  match r with
  | .Ok x => (some x)
  | .Err _ => none

/-- Type quantifiers: k_a : Type, k_b : Type -/
def err_option (r : (Result k_a k_b)) : (Option k_b) :=
  match r with
  | .Ok _ => none
  | .Err err => (some err)

/-- Type quantifiers: k_a : Type, k_b : Type -/
def unwrap_or (r : (Result k_a k_b)) (y : k_a) : k_a :=
  match r with
  | .Ok x => x
  | .Err _ => y

/-- Type quantifiers: k_n : Nat, k_n > 0 -/
def sail_instr_announce (x_0 : (BitVec k_n)) : Unit :=
  ()

/-- Type quantifiers: x_0 : Nat, List.elem x_0 [32, 64] -/
def sail_branch_announce (x_0 : Nat) (x_1 : (BitVec x_0)) : Unit :=
  ()

def sail_reset_registers (_ : Unit) : Unit :=
  ()

def sail_synchronize_registers (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_a : Type -/
def sail_mark_register (x_0 : (RegisterRef k_a)) (x_1 : String) : Unit :=
  ()

/-- Type quantifiers: k_a : Type, k_b : Type -/
def sail_mark_register_pair (x_0 : (RegisterRef k_a)) (x_1 : (RegisterRef k_b)) (x_2 : String) : Unit :=
  ()

/-- Type quantifiers: k_a : Type -/
def sail_ignore_write_to (reg : (RegisterRef k_a)) : Unit :=
  (sail_mark_register reg "ignore_write")

/-- Type quantifiers: k_a : Type -/
def sail_pick_dependency (reg : (RegisterRef k_a)) : Unit :=
  (sail_mark_register reg "pick")

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def __monomorphize (bv : (BitVec k_n)) : (BitVec k_n) :=
  bv

/-- Type quantifiers: n : Int -/
def __monomorphize_int (n : Int) : Int :=
  n

/-- Type quantifiers: k_b : Bool -/
def __monomorphize_bool (b : Bool) : Bool :=
  b

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_read_request_is_exclusive (request : (Mem_read_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_explicit eak =>
    (match eak.variety with
    | .AV_exclusive => true
    | _ => false)
  | _ => false

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_read_request_is_ifetch (request : (Mem_read_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_ifetch () => true
  | _ => false

def __monomorphize_reads : Bool := false

def __monomorphize_writes : Bool := false

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_write_request_is_exclusive (request : (Mem_write_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_explicit eak =>
    (match eak.variety with
    | .AV_exclusive => true
    | _ => false)
  | _ => false

/-- Type quantifiers: x_0 : Nat, List.elem x_0 [32, 64] -/
def sail_address_announce (x_0 : Nat) (x_1 : (BitVec x_0)) : Unit :=
  ()

/-- Type quantifiers: k_ex3324125_ : Bool, k_ex3324124_ : Bool -/
def implies (p : Bool) (q : Bool) : Bool :=
  ((! p) || q)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def Ones {n : _} : (BitVec n) :=
  (sail_ones n)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def Zeros {n : _} : (BitVec n) :=
  (BitVec.zero n)

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def IsZero (x : (BitVec k_n)) : Bool :=
  (x == (BitVec.zero (Sail.BitVec.length x)))

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def IsOnes (x : (BitVec k_n)) : Bool :=
  (x == (sail_ones (Sail.BitVec.length x)))

def Bit (b : (BitVec 1)) : (BitVec 1) :=
  (BitVec.access b 0)

/-- Type quantifiers: k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ k_n -/
def ZeroExtend1 {m : _} (x : (BitVec k_n)) : (BitVec m) :=
  (Sail.BitVec.zeroExtend x m)

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def Slice_int (i : Int) (l : Int) (n : Nat) : (BitVec n) :=
  (get_slice_int n i l)

/-- Type quantifiers: y : Int, x : Int -/
def Align_int (x : Int) (y : Int) : Int :=
  ((fdiv_int x y) *i y)

/-- Type quantifiers: y : Int, k_n : Nat, k_n ≥ 0 -/
def Align_bits (x : (BitVec k_n)) (y : Int) : (BitVec k_n) :=
  (Slice_int (Align_int (BitVec.toNatInt x) y) 0 (Sail.BitVec.length x))

def RoundTowardsZero (r : real) : Int :=
  if ((lt_real r (to_real 0)) : Bool)
  then (round_up r)
  else (round_down r)

def IsSEE (ex : exception) : Bool :=
  match ex with
  | .Error_See _ => true
  | _ => false

def ReservedEncoding (_ : Unit) : SailM Unit := do
  sailThrow ((Error_ReservedEncoding ()))

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def __UNKNOWN_bits (n : Nat) : SailM (BitVec n) := do
  (undefined_bitvector n)

def __UNKNOWN_integer (_ : Unit) : SailM Int := do
  (undefined_int ())

def __UNKNOWN_boolean (_ : Unit) : SailM Bool := do
  (undefined_bool ())

def __UNKNOWN_bit (_ : Unit) : SailM (BitVec 1) := do
  (undefined_bitvector 1)

def EndOfInstruction (_ : Unit) : SailM Unit := do
  sailThrow ((Error_ExceptionTaken ()))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def IsZeroBit (x : (BitVec k_N)) : (BitVec 1) :=
  if ((IsZero x) : Bool)
  then 1#1
  else 0#1

/-- Type quantifiers: k_N : Nat, shift : Nat, k_N > 0 ∧ shift ≥ 0 -/
def ROR (x : (BitVec k_N)) (shift : Nat) : (BitVec k_N) :=
  if ((shift == 0) : Bool)
  then x
  else
    (let m := (Nat.mod shift (Sail.BitVec.length x))
    ((x >>> m) ||| (x <<< ((Sail.BitVec.length x) -i m))))

/-- Type quantifiers: k_M : Nat, N : Nat, k_is_unsigned : Bool, k_M ≥ 0 ∧ N ≥ 0 -/
def Extend (x : (BitVec k_M)) (N : Nat) (is_unsigned : Bool) : SailM (BitVec N) := do
  (if (is_unsigned : Bool)
  then
    (do sail_assert (((Sail.BitVec.length x) ≥b 0) && (N ≥b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/builtins.sail:121.47-121.48"
        (pure (Sail.BitVec.zeroExtend x N)))
  else
    (do sail_assert (((Sail.BitVec.length x) >b 0) && (N ≥b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/builtins.sail:124.46-124.47"
        (pure (sign_extend x N))))

/-- Type quantifiers: k_N : Nat, k_is_unsigned : Bool, k_N ≥ 0 -/
def asl_Int (x : (BitVec k_N)) (is_unsigned : Bool) : SailM Int := do
  let result ← (( do
    (if (is_unsigned : Bool)
    then (do (pure (BitVec.toNat x)))
    else
      (do sail_assert ((Sail.BitVec.length x) >b 0) "sail-arm/arm-v9.4-a/src/builtins.sail:134.33-134.34"
          (pure (BitVec.toInt x)))) ) : SailM Int )
  (pure result)

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def LowestSetBit (x : (BitVec k_N)) : Int := ExceptM.run do
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length x) -i 1)
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
      then (do throw (i : Int))
      else (do (pure ())))
  (pure loop_vars)
  (pure (Sail.BitVec.length x))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def HighestSetBit (x : (BitVec k_N)) : Int := ExceptM.run do
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length x) -i 1)
  let mut loop_vars := ()
  for i in [loop_i_upper:loop_i_lower:-1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
      then (do throw (i : Int))
      else (do (pure ())))
  (pure loop_vars)
  (pure (Neg.neg 1))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def BitCount (x : (BitVec k_N)) : Int := Id.run do
  let result : Int := 0
  let result ← (( do
    let loop_i_lower := 0
    let loop_i_upper := ((Sail.BitVec.length x) -i 1)
    let mut loop_vars := result
    for i in [loop_i_lower:loop_i_upper:1]i do
      let result := loop_vars
      loop_vars :=
        if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
        then (result +i 1)
        else result
    (pure loop_vars) ) : Id Int )
  let result := result
  (pure result)

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def CountLeadingZeroBits (x : (BitVec k_N)) : Int :=
  ((Sail.BitVec.length x) -i ((HighestSetBit x) +i 1))

/-- Type quantifiers: k_N : Nat, 1 ≤ (k_N - 1) -/
def CountLeadingSignBits (x : (BitVec k_N)) : Int :=
  (CountLeadingZeroBits ((Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 1) 1) ^^^ (Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 2) 0)))

/-- Type quantifiers: k_N : Nat, e : Int, size : Nat, k_N ≥ 0 ∧ size ≥ 0 ∧ (e * size) ≤ (e * size + size - 1) ∨ (not (e ≥ 0 ∧ ((e + 1) * size) ≤ k_N)) -/
def Elem_read (vector_name : (BitVec k_N)) (e : Int) (size : Nat) : SailM (BitVec size) := do
  sail_assert ((e ≥b 0) && (((e +i 1) *i size) ≤b (Sail.BitVec.length vector_name))) "sail-arm/arm-v9.4-a/src/builtins.sail:195.40-195.41"
  (pure (Sail.BitVec.extractLsb vector_name (((e *i size) +i size) -i 1) (e *i size)))

/-- Type quantifiers: k_N : Nat, e : Int, size : Nat, k_N ≥ 0 ∧ size ≥ 0 ∧ (e * size) ≤ ((e + 1) * size - 1) ∨ (not (e ≥ 0 ∧ ((e + 1) * size) ≤ k_N)) -/
def Elem_set (vector_name__arg : (BitVec k_N)) (e : Int) (size : Nat) (value_name : (BitVec size)) : SailM (BitVec k_N) := do
  let vector_name : (BitVec k_N) := vector_name__arg
  sail_assert ((e ≥b 0) && (((e +i 1) *i size) ≤b (Sail.BitVec.length vector_name__arg))) "sail-arm/arm-v9.4-a/src/builtins.sail:205.40-205.41"
  (pure (Sail.BitVec.updateSubrange vector_name (((e +i 1) *i size) -i 1) (e *i size) value_name))

def undefined_Configuration_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_Configuration_Type_CFGEND (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_Configuration_Type_ExceptInit (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _update_EDSCR_Type_RW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 10 x)

def _get_HCR_EL2_Type_RW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCR_EL3_Type_RW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def undefined_DormantCtl_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def num_of_Feature (arg_ : Feature) : Int :=
  match arg_ with
  | .FEAT_AA32EL0 => 0
  | .FEAT_AA32EL1 => 1
  | .FEAT_AA32EL2 => 2
  | .FEAT_AA32EL3 => 3
  | .FEAT_AA64EL0 => 4
  | .FEAT_AA64EL1 => 5
  | .FEAT_AA64EL2 => 6
  | .FEAT_AA64EL3 => 7
  | .FEAT_EL0 => 8
  | .FEAT_EL1 => 9
  | .FEAT_EL2 => 10
  | .FEAT_EL3 => 11
  | .FEAT_AES => 12
  | .FEAT_AdvSIMD => 13
  | .FEAT_CSV2_1p1 => 14
  | .FEAT_CSV2_1p2 => 15
  | .FEAT_CSV2_2 => 16
  | .FEAT_CSV2_3 => 17
  | .FEAT_DoubleLock => 18
  | .FEAT_ETMv4 => 19
  | .FEAT_ETMv4p1 => 20
  | .FEAT_ETMv4p2 => 21
  | .FEAT_ETMv4p3 => 22
  | .FEAT_ETMv4p4 => 23
  | .FEAT_ETMv4p5 => 24
  | .FEAT_ETMv4p6 => 25
  | .FEAT_ETS2 => 26
  | .FEAT_FP => 27
  | .FEAT_GICv3 => 28
  | .FEAT_GICv3_LEGACY => 29
  | .FEAT_GICv3_TDIR => 30
  | .FEAT_GICv3p1 => 31
  | .FEAT_GICv4 => 32
  | .FEAT_GICv4p1 => 33
  | .FEAT_IVIPT => 34
  | .FEAT_PCSRv8 => 35
  | .FEAT_PMULL => 36
  | .FEAT_PMUv3 => 37
  | .FEAT_PMUv3_EXT => 38
  | .FEAT_PMUv3_EXT32 => 39
  | .FEAT_SHA1 => 40
  | .FEAT_SHA256 => 41
  | .FEAT_TRC_EXT => 42
  | .FEAT_TRC_SR => 43
  | .FEAT_nTLBPA => 44
  | .FEAT_CRC32 => 45
  | .FEAT_Debugv8p1 => 46
  | .FEAT_HAFDBS => 47
  | .FEAT_HPDS => 48
  | .FEAT_LOR => 49
  | .FEAT_LSE => 50
  | .FEAT_PAN => 51
  | .FEAT_PMUv3p1 => 52
  | .FEAT_RDM => 53
  | .FEAT_VHE => 54
  | .FEAT_VMID16 => 55
  | .FEAT_AA32BF16 => 56
  | .FEAT_AA32HPD => 57
  | .FEAT_AA32I8MM => 58
  | .FEAT_ASMv8p2 => 59
  | .FEAT_DPB => 60
  | .FEAT_Debugv8p2 => 61
  | .FEAT_EDHSR => 62
  | .FEAT_F32MM => 63
  | .FEAT_F64MM => 64
  | .FEAT_FP16 => 65
  | .FEAT_HPDS2 => 66
  | .FEAT_I8MM => 67
  | .FEAT_IESB => 68
  | .FEAT_LPA => 69
  | .FEAT_LSMAOC => 70
  | .FEAT_LVA => 71
  | .FEAT_MPAM => 72
  | .FEAT_PAN2 => 73
  | .FEAT_PCSRv8p2 => 74
  | .FEAT_RAS => 75
  | .FEAT_SHA3 => 76
  | .FEAT_SHA512 => 77
  | .FEAT_SM3 => 78
  | .FEAT_SM4 => 79
  | .FEAT_SPE => 80
  | .FEAT_SVE => 81
  | .FEAT_TTCNP => 82
  | .FEAT_UAO => 83
  | .FEAT_VPIPT => 84
  | .FEAT_XNX => 85
  | .FEAT_CCIDX => 86
  | .FEAT_CONSTPACFIELD => 87
  | .FEAT_EPAC => 88
  | .FEAT_FCMA => 89
  | .FEAT_FPAC => 90
  | .FEAT_FPACCOMBINE => 91
  | .FEAT_JSCVT => 92
  | .FEAT_LRCPC => 93
  | .FEAT_NV => 94
  | .FEAT_PACIMP => 95
  | .FEAT_PACQARMA3 => 96
  | .FEAT_PACQARMA5 => 97
  | .FEAT_PAuth => 98
  | .FEAT_SPEv1p1 => 99
  | .FEAT_AMUv1 => 100
  | .FEAT_BBM => 101
  | .FEAT_CNTSC => 102
  | .FEAT_DIT => 103
  | .FEAT_Debugv8p4 => 104
  | .FEAT_DotProd => 105
  | .FEAT_DoubleFault => 106
  | .FEAT_FHM => 107
  | .FEAT_FlagM => 108
  | .FEAT_IDST => 109
  | .FEAT_LRCPC2 => 110
  | .FEAT_LSE2 => 111
  | .FEAT_NV2 => 112
  | .FEAT_PMUv3p4 => 113
  | .FEAT_RASSAv1p1 => 114
  | .FEAT_RASv1p1 => 115
  | .FEAT_S2FWB => 116
  | .FEAT_SEL2 => 117
  | .FEAT_TLBIOS => 118
  | .FEAT_TLBIRANGE => 119
  | .FEAT_TRF => 120
  | .FEAT_TTL => 121
  | .FEAT_TTST => 122
  | .FEAT_BTI => 123
  | .FEAT_CSV2 => 124
  | .FEAT_CSV3 => 125
  | .FEAT_DPB2 => 126
  | .FEAT_E0PD => 127
  | .FEAT_EVT => 128
  | .FEAT_ExS => 129
  | .FEAT_FRINTTS => 130
  | .FEAT_FlagM2 => 131
  | .FEAT_GTG => 132
  | .FEAT_MTE => 133
  | .FEAT_MTE2 => 134
  | .FEAT_PMUv3p5 => 135
  | .FEAT_RNG => 136
  | .FEAT_RNG_TRAP => 137
  | .FEAT_SB => 138
  | .FEAT_SPECRES => 139
  | .FEAT_SSBS => 140
  | .FEAT_SSBS2 => 141
  | .FEAT_AMUv1p1 => 142
  | .FEAT_BF16 => 143
  | .FEAT_DGH => 144
  | .FEAT_ECV => 145
  | .FEAT_FGT => 146
  | .FEAT_HPMN0 => 147
  | .FEAT_MPAMv0p1 => 148
  | .FEAT_MPAMv1p1 => 149
  | .FEAT_MTPMU => 150
  | .FEAT_PAuth2 => 151
  | .FEAT_TWED => 152
  | .FEAT_AFP => 153
  | .FEAT_EBF16 => 154
  | .FEAT_HCX => 155
  | .FEAT_LPA2 => 156
  | .FEAT_LS64 => 157
  | .FEAT_LS64_ACCDATA => 158
  | .FEAT_LS64_V => 159
  | .FEAT_MTE3 => 160
  | .FEAT_PAN3 => 161
  | .FEAT_PMUv3p7 => 162
  | .FEAT_RPRES => 163
  | .FEAT_SPEv1p2 => 164
  | .FEAT_WFxT => 165
  | .FEAT_XS => 166
  | .FEAT_CMOW => 167
  | .FEAT_Debugv8p8 => 168
  | .FEAT_GICv3_NMI => 169
  | .FEAT_HBC => 170
  | .FEAT_MOPS => 171
  | .FEAT_NMI => 172
  | .FEAT_PMUv3_EXT64 => 173
  | .FEAT_PMUv3_TH => 174
  | .FEAT_PMUv3p8 => 175
  | .FEAT_SCTLR2 => 176
  | .FEAT_SPEv1p3 => 177
  | .FEAT_TCR2 => 178
  | .FEAT_TIDCP1 => 179
  | .FEAT_ADERR => 180
  | .FEAT_AIE => 181
  | .FEAT_ANERR => 182
  | .FEAT_CLRBHB => 183
  | .FEAT_CSSC => 184
  | .FEAT_Debugv8p9 => 185
  | .FEAT_DoubleFault2 => 186
  | .FEAT_ECBHB => 187
  | .FEAT_FGT2 => 188
  | .FEAT_HAFT => 189
  | .FEAT_LRCPC3 => 190
  | .FEAT_MTE4 => 191
  | .FEAT_MTE_ASYM_FAULT => 192
  | .FEAT_MTE_ASYNC => 193
  | .FEAT_MTE_CANONICAL_TAGS => 194
  | .FEAT_MTE_NO_ADDRESS_TAGS => 195
  | .FEAT_MTE_PERM => 196
  | .FEAT_MTE_STORE_ONLY => 197
  | .FEAT_MTE_TAGGED_FAR => 198
  | .FEAT_PCSRv8p9 => 199
  | .FEAT_PFAR => 200
  | .FEAT_PMUv3_EDGE => 201
  | .FEAT_PMUv3_ICNTR => 202
  | .FEAT_PMUv3_SS => 203
  | .FEAT_PMUv3p9 => 204
  | .FEAT_PRFMSLC => 205
  | .FEAT_RASSAv2 => 206
  | .FEAT_RASv2 => 207
  | .FEAT_RPRFM => 208
  | .FEAT_S1PIE => 209
  | .FEAT_S1POE => 210
  | .FEAT_S2PIE => 211
  | .FEAT_S2POE => 212
  | .FEAT_SPECRES2 => 213
  | .FEAT_SPE_CRR => 214
  | .FEAT_SPE_FDS => 215
  | .FEAT_SPEv1p4 => 216
  | .FEAT_SPMU => 217
  | .FEAT_THE => 218
  | .FEAT_DoPD => 219
  | .FEAT_ETE => 220
  | .FEAT_SVE2 => 221
  | .FEAT_SVE_AES => 222
  | .FEAT_SVE_BitPerm => 223
  | .FEAT_SVE_PMULL128 => 224
  | .FEAT_SVE_SHA3 => 225
  | .FEAT_SVE_SM4 => 226
  | .FEAT_TME => 227
  | .FEAT_TRBE => 228
  | .FEAT_ETEv1p1 => 229
  | .FEAT_BRBE => 230
  | .FEAT_ETEv1p2 => 231
  | .FEAT_RME => 232
  | .FEAT_SME => 233
  | .FEAT_SME_F64F64 => 234
  | .FEAT_SME_FA64 => 235
  | .FEAT_SME_I16I64 => 236
  | .FEAT_BRBEv1p1 => 237
  | .FEAT_MEC => 238
  | .FEAT_SME2 => 239
  | .FEAT_ABLE => 240
  | .FEAT_CHK => 241
  | .FEAT_D128 => 242
  | .FEAT_EBEP => 243
  | .FEAT_ETEv1p3 => 244
  | .FEAT_GCS => 245
  | .FEAT_ITE => 246
  | .FEAT_LSE128 => 247
  | .FEAT_LVA3 => 248
  | .FEAT_SEBEP => 249
  | .FEAT_SME2p1 => 250
  | .FEAT_SME_F16F16 => 251
  | .FEAT_SVE2p1 => 252
  | .FEAT_SVE_B16B16 => 253
  | .FEAT_SYSINSTR128 => 254
  | .FEAT_SYSREG128 => 255
  | .FEAT_TRBE_EXT => 256
  | .FEAT_TRBE_MPAM => 257

def num_of_ArchVersion (arg_ : ArchVersion) : Int :=
  match arg_ with
  | .v8Ap0 => 0
  | .v8Ap1 => 1
  | .v8Ap2 => 2
  | .v8Ap3 => 3
  | .v8Ap4 => 4
  | .v8Ap5 => 5
  | .v8Ap6 => 6
  | .v8Ap7 => 7
  | .v8Ap8 => 8
  | .v8Ap9 => 9
  | .v9Ap0 => 10
  | .v9Ap1 => 11
  | .v9Ap2 => 12
  | .v9Ap3 => 13
  | .v9Ap4 => 14

def InitFeatureImpl (_ : Unit) : SailM Unit := do
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL0) (← readReg FEAT_AA32EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL1) (← readReg FEAT_AA32EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL2) (← readReg FEAT_AA32EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL3) (← readReg FEAT_AA32EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL0) (← readReg FEAT_AA64EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL1) (← readReg FEAT_AA64EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL2) (← readReg FEAT_AA64EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL3) (← readReg FEAT_AA64EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL0) (← readReg FEAT_EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL1) (← readReg FEAT_EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL2) (← readReg FEAT_EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL3) (← readReg FEAT_EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AES) (← readReg FEAT_AES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AdvSIMD) (← readReg FEAT_AdvSIMD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_1p1) (← readReg FEAT_CSV2_1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_1p2) (← readReg FEAT_CSV2_1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_2) (← readReg FEAT_CSV2_2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_3) (← readReg FEAT_CSV2_3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleLock) (← readReg FEAT_DoubleLock_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4) (← readReg FEAT_ETMv4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p1) (← readReg FEAT_ETMv4p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p2) (← readReg FEAT_ETMv4p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p3) (← readReg FEAT_ETMv4p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p4) (← readReg FEAT_ETMv4p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p5) (← readReg FEAT_ETMv4p5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p6) (← readReg FEAT_ETMv4p6_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETS2) (← readReg FEAT_ETS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FP) (← readReg FEAT_FP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3) (← readReg FEAT_GICv3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_LEGACY) (← readReg FEAT_GICv3_LEGACY_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_TDIR) (← readReg FEAT_GICv3_TDIR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3p1) (← readReg FEAT_GICv3p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv4) (← readReg FEAT_GICv4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv4p1) (← readReg FEAT_GICv4p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IVIPT) (← readReg FEAT_IVIPT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8) (← readReg FEAT_PCSRv8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMULL) (← readReg FEAT_PMULL_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3) (← readReg FEAT_PMUv3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT) (← readReg FEAT_PMUv3_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT32) (← readReg FEAT_PMUv3_EXT32_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA1) (← readReg FEAT_SHA1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA256) (← readReg FEAT_SHA256_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRC_EXT) (← readReg FEAT_TRC_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRC_SR) (← readReg FEAT_TRC_SR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_nTLBPA) (← readReg FEAT_nTLBPA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CRC32) (← readReg FEAT_CRC32_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p1) (← readReg FEAT_Debugv8p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HAFDBS) (← readReg FEAT_HAFDBS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPDS) (← readReg FEAT_HPDS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LOR) (← readReg FEAT_LOR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE) (← readReg FEAT_LSE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN) (← readReg FEAT_PAN_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p1) (← readReg FEAT_PMUv3p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RDM) (← readReg FEAT_RDM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VHE) (← readReg FEAT_VHE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VMID16) (← readReg FEAT_VMID16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32BF16) (← readReg FEAT_AA32BF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32HPD) (← readReg FEAT_AA32HPD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32I8MM) (← readReg FEAT_AA32I8MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ASMv8p2) (← readReg FEAT_ASMv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DPB) (← readReg FEAT_DPB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p2) (← readReg FEAT_Debugv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EDHSR) (← readReg FEAT_EDHSR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_F32MM) (← readReg FEAT_F32MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_F64MM) (← readReg FEAT_F64MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FP16) (← readReg FEAT_FP16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPDS2) (← readReg FEAT_HPDS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_I8MM) (← readReg FEAT_I8MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IESB) (← readReg FEAT_IESB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LPA) (← readReg FEAT_LPA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSMAOC) (← readReg FEAT_LSMAOC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LVA) (← readReg FEAT_LVA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAM) (← readReg FEAT_MPAM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN2) (← readReg FEAT_PAN2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8p2) (← readReg FEAT_PCSRv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RAS) (← readReg FEAT_RAS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA3) (← readReg FEAT_SHA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA512) (← readReg FEAT_SHA512_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SM3) (← readReg FEAT_SM3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SM4) (← readReg FEAT_SM4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE) (← readReg FEAT_SPE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE) (← readReg FEAT_SVE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTCNP) (← readReg FEAT_TTCNP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_UAO) (← readReg FEAT_UAO_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VPIPT) (← readReg FEAT_VPIPT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_XNX) (← readReg FEAT_XNX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CCIDX) (← readReg FEAT_CCIDX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CONSTPACFIELD) (← readReg FEAT_CONSTPACFIELD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EPAC) (← readReg FEAT_EPAC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FCMA) (← readReg FEAT_FCMA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FPAC) (← readReg FEAT_FPAC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FPACCOMBINE) (← readReg FEAT_FPACCOMBINE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_JSCVT) (← readReg FEAT_JSCVT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC) (← readReg FEAT_LRCPC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NV) (← readReg FEAT_NV_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACIMP) (← readReg FEAT_PACIMP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACQARMA3) (← readReg FEAT_PACQARMA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACQARMA5) (← readReg FEAT_PACQARMA5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAuth) (← readReg FEAT_PAuth_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p1) (← readReg FEAT_SPEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AMUv1) (← readReg FEAT_AMUv1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BBM) (← readReg FEAT_BBM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CNTSC) (← readReg FEAT_CNTSC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DIT) (← readReg FEAT_DIT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p4) (← readReg FEAT_Debugv8p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DotProd) (← readReg FEAT_DotProd_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleFault) (← readReg FEAT_DoubleFault_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FHM) (← readReg FEAT_FHM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FlagM) (← readReg FEAT_FlagM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IDST) (← readReg FEAT_IDST_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC2) (← readReg FEAT_LRCPC2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE2) (← readReg FEAT_LSE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NV2) (← readReg FEAT_NV2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p4) (← readReg FEAT_PMUv3p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASSAv1p1) (← readReg FEAT_RASSAv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASv1p1) (← readReg FEAT_RASv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2FWB) (← readReg FEAT_S2FWB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SEL2) (← readReg FEAT_SEL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TLBIOS) (← readReg FEAT_TLBIOS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TLBIRANGE) (← readReg FEAT_TLBIRANGE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRF) (← readReg FEAT_TRF_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTL) (← readReg FEAT_TTL_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTST) (← readReg FEAT_TTST_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BTI) (← readReg FEAT_BTI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2) (← readReg FEAT_CSV2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV3) (← readReg FEAT_CSV3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DPB2) (← readReg FEAT_DPB2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_E0PD) (← readReg FEAT_E0PD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EVT) (← readReg FEAT_EVT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ExS) (← readReg FEAT_ExS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FRINTTS) (← readReg FEAT_FRINTTS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FlagM2) (← readReg FEAT_FlagM2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GTG) (← readReg FEAT_GTG_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE) (← readReg FEAT_MTE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE2) (← readReg FEAT_MTE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p5) (← readReg FEAT_PMUv3p5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RNG) (← readReg FEAT_RNG_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RNG_TRAP) (← readReg FEAT_RNG_TRAP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SB) (← readReg FEAT_SB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPECRES) (← readReg FEAT_SPECRES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SSBS) (← readReg FEAT_SSBS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SSBS2) (← readReg FEAT_SSBS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AMUv1p1) (← readReg FEAT_AMUv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BF16) (← readReg FEAT_BF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DGH) (← readReg FEAT_DGH_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ECV) (← readReg FEAT_ECV_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FGT) (← readReg FEAT_FGT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPMN0) (← readReg FEAT_HPMN0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAMv0p1) (← readReg FEAT_MPAMv0p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAMv1p1) (← readReg FEAT_MPAMv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTPMU) (← readReg FEAT_MTPMU_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAuth2) (← readReg FEAT_PAuth2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TWED) (← readReg FEAT_TWED_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AFP) (← readReg FEAT_AFP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EBF16) (← readReg FEAT_EBF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HCX) (← readReg FEAT_HCX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LPA2) (← readReg FEAT_LPA2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64) (← readReg FEAT_LS64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64_ACCDATA) (← readReg FEAT_LS64_ACCDATA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64_V) (← readReg FEAT_LS64_V_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE3) (← readReg FEAT_MTE3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN3) (← readReg FEAT_PAN3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p7) (← readReg FEAT_PMUv3p7_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RPRES) (← readReg FEAT_RPRES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p2) (← readReg FEAT_SPEv1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_WFxT) (← readReg FEAT_WFxT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_XS) (← readReg FEAT_XS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CMOW) (← readReg FEAT_CMOW_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p8) (← readReg FEAT_Debugv8p8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_NMI) (← readReg FEAT_GICv3_NMI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HBC) (← readReg FEAT_HBC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MOPS) (← readReg FEAT_MOPS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NMI) (← readReg FEAT_NMI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT64) (← readReg FEAT_PMUv3_EXT64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_TH) (← readReg FEAT_PMUv3_TH_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p8) (← readReg FEAT_PMUv3p8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SCTLR2) (← readReg FEAT_SCTLR2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p3) (← readReg FEAT_SPEv1p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TCR2) (← readReg FEAT_TCR2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TIDCP1) (← readReg FEAT_TIDCP1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ADERR) (← readReg FEAT_ADERR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AIE) (← readReg FEAT_AIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ANERR) (← readReg FEAT_ANERR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CLRBHB) (← readReg FEAT_CLRBHB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSSC) (← readReg FEAT_CSSC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p9) (← readReg FEAT_Debugv8p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleFault2) (← readReg FEAT_DoubleFault2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ECBHB) (← readReg FEAT_ECBHB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FGT2) (← readReg FEAT_FGT2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HAFT) (← readReg FEAT_HAFT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC3) (← readReg FEAT_LRCPC3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE4) (← readReg FEAT_MTE4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_ASYM_FAULT) (← readReg FEAT_MTE_ASYM_FAULT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_ASYNC) (← readReg FEAT_MTE_ASYNC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_CANONICAL_TAGS) (← readReg FEAT_MTE_CANONICAL_TAGS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_NO_ADDRESS_TAGS) (← readReg FEAT_MTE_NO_ADDRESS_TAGS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_PERM) (← readReg FEAT_MTE_PERM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_STORE_ONLY) (← readReg FEAT_MTE_STORE_ONLY_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_TAGGED_FAR) (← readReg FEAT_MTE_TAGGED_FAR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8p9) (← readReg FEAT_PCSRv8p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PFAR) (← readReg FEAT_PFAR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EDGE) (← readReg FEAT_PMUv3_EDGE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_ICNTR) (← readReg FEAT_PMUv3_ICNTR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_SS) (← readReg FEAT_PMUv3_SS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p9) (← readReg FEAT_PMUv3p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PRFMSLC) (← readReg FEAT_PRFMSLC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASSAv2) (← readReg FEAT_RASSAv2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASv2) (← readReg FEAT_RASv2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RPRFM) (← readReg FEAT_RPRFM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S1PIE) (← readReg FEAT_S1PIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S1POE) (← readReg FEAT_S1POE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2PIE) (← readReg FEAT_S2PIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2POE) (← readReg FEAT_S2POE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPECRES2) (← readReg FEAT_SPECRES2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE_CRR) (← readReg FEAT_SPE_CRR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE_FDS) (← readReg FEAT_SPE_FDS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p4) (← readReg FEAT_SPEv1p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPMU) (← readReg FEAT_SPMU_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_THE) (← readReg FEAT_THE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoPD) (← readReg FEAT_DoPD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETE) (← readReg FEAT_ETE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE2) (← readReg FEAT_SVE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_AES) (← readReg FEAT_SVE_AES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_BitPerm) (← readReg FEAT_SVE_BitPerm_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_PMULL128) (← readReg FEAT_SVE_PMULL128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_SHA3) (← readReg FEAT_SVE_SHA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_SM4) (← readReg FEAT_SVE_SM4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TME) (← readReg FEAT_TME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE) (← readReg FEAT_TRBE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p1) (← readReg FEAT_ETEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BRBE) (← readReg FEAT_BRBE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p2) (← readReg FEAT_ETEv1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RME) (← readReg FEAT_RME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME) (← readReg FEAT_SME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_F64F64) (← readReg FEAT_SME_F64F64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_FA64) (← readReg FEAT_SME_FA64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_I16I64) (← readReg FEAT_SME_I16I64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BRBEv1p1) (← readReg FEAT_BRBEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MEC) (← readReg FEAT_MEC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME2) (← readReg FEAT_SME2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ABLE) (← readReg FEAT_ABLE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CHK) (← readReg FEAT_CHK_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_D128) (← readReg FEAT_D128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EBEP) (← readReg FEAT_EBEP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p3) (← readReg FEAT_ETEv1p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GCS) (← readReg FEAT_GCS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ITE) (← readReg FEAT_ITE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE128) (← readReg FEAT_LSE128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LVA3) (← readReg FEAT_LVA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SEBEP) (← readReg FEAT_SEBEP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME2p1) (← readReg FEAT_SME2p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_F16F16) (← readReg FEAT_SME_F16F16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE2p1) (← readReg FEAT_SVE2p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_B16B16) (← readReg FEAT_SVE_B16B16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SYSINSTR128) (← readReg FEAT_SYSINSTR128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SYSREG128) (← readReg FEAT_SYSREG128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE_EXT) (← readReg FEAT_TRBE_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE_MPAM) (← readReg FEAT_TRBE_MPAM_IMPLEMENTED))

def InitVariantImplemented (_ : Unit) : SailM Unit := do
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap0) (← readReg v8Ap0_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap1) (← readReg v8Ap1_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap2) (← readReg v8Ap2_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap3) (← readReg v8Ap3_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap4) (← readReg v8Ap4_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap5) (← readReg v8Ap5_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap6) (← readReg v8Ap6_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap7) (← readReg v8Ap7_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap8) (← readReg v8Ap8_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap9) (← readReg v8Ap9_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap0) (← readReg v9Ap0_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap1) (← readReg v9Ap1_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap2) (← readReg v9Ap2_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap3) (← readReg v9Ap3_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap4) (← readReg v9Ap4_IMPLEMENTED))

def IsFeatureImplemented (feat : Feature) : SailM Bool := do
  (pure (GetElem?.getElem! (← readReg FeatureImpl) (num_of_Feature feat)))

def Mk_SCRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCR_Type_AW (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_SCRType_EA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCR_EL3_Type_EA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCR_Type_EA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCRType_FIQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_EL3_Type_FIQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_Type_FIQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_Type_FW (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_SCRType_IRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCR_EL3_Type_IRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCR_Type_IRQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCRType_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_EDSCR_Type_NS (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _get_SCR_EL3_Type_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCR_Type_NS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCR_EL3_Type_SIF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _update_HCR_Type_TWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _get_HCR_EL2_Type_TWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCR_EL3_Type_TWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _update_HCR_Type_TWI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _get_HCR_EL2_Type_TWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_SCR_EL3_Type_TWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def undefined_SCTLRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_SCTLR_Type_A (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_HSCTLR_Type_A (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL1_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL2_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL3_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_Type_A (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_HSCTLR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_PMCR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_SCTLR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _get_PMCNTENSET_EL0_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_PMCNTENSET_Type_C (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL1_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR_EL2_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR_EL3_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_SCTLR_Type_CP15BEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_HSCTLR_Type_DSSBS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_Type_DSSBS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_FPCR_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_SCTLR_EL1_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCTLR_EL2_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCTLRType_E0E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_SCTLRType_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _update_HSCTLR_Type_EE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _update_SCTLR_Type_EE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _get_HSCTLR_Type_EE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL1_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL2_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL3_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_Type_EE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL1_Type_EPAN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_SCTLR_EL2_Type_EPAN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _update_HSCTLR_Type_I (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_SCTLR_Type_I (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _get_SCTLR_EL1_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_SCTLR_EL2_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_SCTLR_EL3_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _update_SCTLR_Type_ITD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_HSCTLR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_MPIDR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_SCTLR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_VMPIDR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_SCTLR_EL1_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLR_EL2_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLR_EL3_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLRType_NMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_SCTLRType_SA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_VSTCR_EL2_Type_SA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLRType_SA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _update_SCTLR_Type_SED (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_SCTLR_Type_SPAN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _get_SCTLR_Type_SPAN (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_SCTLRType_SPINTMASK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _update_HCR_Type_TIDCP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _get_HCR_EL2_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_SCTLR_EL1_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_SCTLR_EL2_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_SCTLR_EL1_Type_UMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _update_SCTLR_Type_WXN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_SCTLR_EL1_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLR_EL2_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLR_EL3_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLRType_nAA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_SCTLRType_nTWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _update_SCTLR_Type_nTWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _get_SCTLRType_nTWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _update_SCTLR_Type_nTWI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def undefined_MAIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_S1PIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S1PIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_S1PORType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S1PORType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_S2PIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2PIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSESR_EL2_Type_ISS (v : (BitVec 64)) : (BitVec 24) :=
  (Sail.BitVec.extractLsb v 23 0)

def Mk_FPCRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_FPCRType_AH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_FPCR_Type_AH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_FPCRType_AHP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_FPCRType_DN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_FPCRType_FIZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_FPCRType_FZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_FPCRType_FZ16 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_FPCR_Type_IDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_FPCR_Type_IOE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_FPCR_Type_IXE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_FPCRType_NEP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_FPCR_Type_OFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_FPCRType_RMode (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _get_FPCR_Type_Stride (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_FPCRType_UFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_FPCR_Type_UFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_FPCR_Type_length (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def undefined_BRBSRCType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBSRCType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBTGTType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTGTType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBINFType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_BRBCR_EL1_Type_CC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_BRBCR_EL2_Type_CC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_EDSCR_Type_EL (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _get_BRBFCR_EL1_Type_LASTFAILED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_BRBCR_EL1_Type_MPRED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_BRBCR_EL2_Type_MPRED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def undefined_Signal (_ : Unit) : SailM Signal := do
  (internal_pick [Signal_Low, Signal_High])

def CYCLE_COUNTER_ID : Nat := 31

def INSTRUCTION_COUNTER_ID : Nat := 32

def PMU_EVENT_SW_INCR : (BitVec 16) := 0x0000#16

def PMU_EVENT_L1D_CACHE_REFILL : (BitVec 16) := 0x0003#16

def PMU_EVENT_L1D_CACHE : (BitVec 16) := 0x0004#16

def PMU_EVENT_INST_RETIRED : (BitVec 16) := 0x0008#16

def PMU_EVENT_EXC_TAKEN : (BitVec 16) := 0x0009#16

def PMU_EVENT_BR_MIS_PRED : (BitVec 16) := 0x0010#16

def PMU_EVENT_BR_MIS_PRED_RETIRED : (BitVec 16) := 0x0022#16

def PMU_EVENT_L1D_TLB : (BitVec 16) := 0x0025#16

def PMU_EVENT_REMOTE_ACCESS : (BitVec 16) := 0x0031#16

def PMU_EVENT_LL_CACHE : (BitVec 16) := 0x0032#16

def PMU_EVENT_LL_CACHE_MISS : (BitVec 16) := 0x0033#16

def PMU_EVENT_DTLB_WALK : (BitVec 16) := 0x0034#16

def PMU_EVENT_L1D_CACHE_LMISS_RD : (BitVec 16) := 0x0039#16

def PMU_EVENT_L2D_CACHE_RD : (BitVec 16) := 0x0050#16

def PMU_EVENT_L2D_CACHE_LMISS_RD : (BitVec 16) := 0x4009#16

def PMU_EVENT_LDST_ALIGN_LAT : (BitVec 16) := 0x4020#16

def PMU_EVENT_SVE_PRED_EMPTY_SPEC : (BitVec 16) := 0x8075#16

def PMU_EVENT_SVE_PRED_PARTIAL_SPEC : (BitVec 16) := 0x8077#16

def PMU_EVENT_BRB_FILTRATE : (BitVec 16) := 0x811F#16

def PMU_EVENT_DSNP_HIT_RD : (BitVec 16) := 0x8194#16

def PMU_EVENT_L1D_CACHE_HITM_RD : (BitVec 16) := 0x8214#16

def PMU_EVENT_L2D_CACHE_HITM_RD : (BitVec 16) := 0x8215#16

def PMU_EVENT_L3D_CACHE_HITM_RD : (BitVec 16) := 0x8216#16

def PMU_EVENT_LL_CACHE_HITM_RD : (BitVec 16) := 0x8217#16

def PMU_EVENT_L1D_LFB_HIT_RD : (BitVec 16) := 0x8244#16

def PMU_EVENT_L2D_LFB_HIT_RD : (BitVec 16) := 0x8245#16

def PMU_EVENT_L3D_LFB_HIT_RD : (BitVec 16) := 0x8246#16

def PMU_EVENT_LL_LFB_HIT_RD : (BitVec 16) := 0x8247#16

def undefined_SecurityState (_ : Unit) : SailM SecurityState := do
  (internal_pick [SS_NonSecure, SS_Root, SS_Realm, SS_Secure])

def M32_User : (BitVec 5) := 0b10000#5

def M32_FIQ : (BitVec 5) := 0b10001#5

def M32_IRQ : (BitVec 5) := 0b10010#5

def M32_Svc : (BitVec 5) := 0b10011#5

def M32_Monitor : (BitVec 5) := 0b10110#5

def M32_Abort : (BitVec 5) := 0b10111#5

def M32_Hyp : (BitVec 5) := 0b11010#5

def M32_Undef : (BitVec 5) := 0b11011#5

def M32_System : (BitVec 5) := 0b11111#5

def EL3 : (BitVec 2) := 0b11#2

def EL2 : (BitVec 2) := 0b10#2

def EL1 : (BitVec 2) := 0b01#2

def EL0 : (BitVec 2) := 0b00#2

def undefined_ProcState (_ : Unit) : SailM ProcState := do
  (pure { N := (← do
            (undefined_bitvector 1))
          Z := (← do
            (undefined_bitvector 1))
          C := (← do
            (undefined_bitvector 1))
          V := (← do
            (undefined_bitvector 1))
          D := (← do
            (undefined_bitvector 1))
          A := (← do
            (undefined_bitvector 1))
          I := (← do
            (undefined_bitvector 1))
          F := (← do
            (undefined_bitvector 1))
          EXLOCK := (← do
            (undefined_bitvector 1))
          PAN := (← do
            (undefined_bitvector 1))
          UAO := (← do
            (undefined_bitvector 1))
          DIT := (← do
            (undefined_bitvector 1))
          TCO := (← do
            (undefined_bitvector 1))
          PM := (← do
            (undefined_bitvector 1))
          PPEND := (← do
            (undefined_bitvector 1))
          BTYPE := (← do
            (undefined_bitvector 2))
          ZA := (← do
            (undefined_bitvector 1))
          SM := (← do
            (undefined_bitvector 1))
          ALLINT := (← do
            (undefined_bitvector 1))
          SS := (← do
            (undefined_bitvector 1))
          IL := (← do
            (undefined_bitvector 1))
          EL := (← do
            (undefined_bitvector 2))
          nRW := (← do
            (undefined_bitvector 1))
          SP := (← do
            (undefined_bitvector 1))
          Q := (← do
            (undefined_bitvector 1))
          GE := (← do
            (undefined_bitvector 4))
          SSBS := (← do
            (undefined_bitvector 1))
          IT := (← do
            (undefined_bitvector 8))
          J := (← do
            (undefined_bitvector 1))
          T := (← do
            (undefined_bitvector 1))
          E := (← do
            (undefined_bitvector 1))
          M := (← do
            (undefined_bitvector 5)) })

def undefined_InstrSet (_ : Unit) : SailM InstrSet := do
  (internal_pick [InstrSet_A64, InstrSet_A32, InstrSet_T32])

def undefined_DSBAlias (_ : Unit) : SailM DSBAlias := do
  (internal_pick [DSBAlias_SSBB, DSBAlias_PSSBB, DSBAlias_DSB])

def __UNKNOWN_PARTIDtype (_ : Unit) : SailM (BitVec 16) := do
  (undefined_bitvector 16)

def __UNKNOWN_PMGtype (_ : Unit) : SailM (BitVec 8) := do
  (undefined_bitvector 8)

def undefined_PARTIDspaceType (_ : Unit) : SailM PARTIDspaceType := do
  (internal_pick [PIdSpace_Secure, PIdSpace_Root, PIdSpace_Realm, PIdSpace_NonSecure])

def undefined_MPAMinfo (_ : Unit) : SailM MPAMinfo := do
  (pure { mpam_sp := (← do
            (undefined_PARTIDspaceType ()))
          partid := (← do
            (undefined_bitvector 16))
          pmg := (← do
            (undefined_bitvector 8)) })

def undefined_AccessType (_ : Unit) : SailM AccessType := do
  (internal_pick [AccessType_IFETCH, AccessType_GPR, AccessType_ASIMD, AccessType_SVE, AccessType_SME, AccessType_IC, AccessType_DC, AccessType_DCZero, AccessType_AT, AccessType_NV2, AccessType_SPE, AccessType_GCS, AccessType_GPTW, AccessType_TTW])

def undefined_MemOp (_ : Unit) : SailM MemOp := do
  (internal_pick [MemOp_LOAD, MemOp_STORE, MemOp_PREFETCH])

def undefined_VARange (_ : Unit) : SailM VARange := do
  (internal_pick [VARange_LOWER, VARange_UPPER])

def undefined_MemAtomicOp (_ : Unit) : SailM MemAtomicOp := do
  (internal_pick [MemAtomicOp_GCSSS1, MemAtomicOp_ADD, MemAtomicOp_BIC, MemAtomicOp_EOR, MemAtomicOp_ORR, MemAtomicOp_SMAX, MemAtomicOp_SMIN, MemAtomicOp_UMAX, MemAtomicOp_UMIN, MemAtomicOp_SWP, MemAtomicOp_CAS])

def undefined_CacheOp (_ : Unit) : SailM CacheOp := do
  (internal_pick [CacheOp_Clean, CacheOp_Invalidate, CacheOp_CleanInvalidate])

def undefined_CacheOpScope (_ : Unit) : SailM CacheOpScope := do
  (internal_pick [CacheOpScope_SetWay, CacheOpScope_PoU, CacheOpScope_PoC, CacheOpScope_PoE, CacheOpScope_PoP, CacheOpScope_PoDP, CacheOpScope_PoPA, CacheOpScope_ALLU, CacheOpScope_ALLUIS])

def undefined_CacheType (_ : Unit) : SailM CacheType := do
  (internal_pick [CacheType_Data, CacheType_Tag, CacheType_Data_Tag, CacheType_Instruction])

def undefined_AccessDescriptor (_ : Unit) : SailM AccessDescriptor := do
  (pure { acctype := (← do
            (undefined_AccessType ()))
          el := (← do
            (undefined_bitvector 2))
          ss := (← do
            (undefined_SecurityState ()))
          acqsc := (← do
            (undefined_bool ()))
          acqpc := (← do
            (undefined_bool ()))
          relsc := (← do
            (undefined_bool ()))
          limitedordered := (← do
            (undefined_bool ()))
          exclusive := (← do
            (undefined_bool ()))
          atomicop := (← do
            (undefined_bool ()))
          modop := (← do
            (undefined_MemAtomicOp ()))
          nontemporal := (← do
            (undefined_bool ()))
          read := (← do
            (undefined_bool ()))
          write := (← do
            (undefined_bool ()))
          cacheop := (← do
            (undefined_CacheOp ()))
          opscope := (← do
            (undefined_CacheOpScope ()))
          cachetype := (← do
            (undefined_CacheType ()))
          pan := (← do
            (undefined_bool ()))
          transactional := (← do
            (undefined_bool ()))
          nonfault := (← do
            (undefined_bool ()))
          firstfault := (← do
            (undefined_bool ()))
          first := (← do
            (undefined_bool ()))
          contiguous := (← do
            (undefined_bool ()))
          streamingsve := (← do
            (undefined_bool ()))
          ls64 := (← do
            (undefined_bool ()))
          mops := (← do
            (undefined_bool ()))
          rcw := (← do
            (undefined_bool ()))
          rcws := (← do
            (undefined_bool ()))
          toplevel := (← do
            (undefined_bool ()))
          varange := (← do
            (undefined_VARange ()))
          a32lsmd := (← do
            (undefined_bool ()))
          tagchecked := (← do
            (undefined_bool ()))
          tagaccess := (← do
            (undefined_bool ()))
          mpam := (← do
            (undefined_MPAMinfo ())) })

def __UNKNOWN_AccessDescriptor (_ : Unit) : SailM AccessDescriptor := do
  (undefined_AccessDescriptor ())

def undefined_MemType (_ : Unit) : SailM MemType := do
  (internal_pick [MemType_Normal, MemType_Device])

def undefined_DeviceType (_ : Unit) : SailM DeviceType := do
  (internal_pick [DeviceType_GRE, DeviceType_nGRE, DeviceType_nGnRE, DeviceType_nGnRnE])

def undefined_MemAttrHints (_ : Unit) : SailM MemAttrHints := do
  (pure { attrs := (← do
            (undefined_bitvector 2))
          hints := (← do
            (undefined_bitvector 2))
          transient := (← do
            (undefined_bool ())) })

def LOG2_TAG_GRANULE : Nat := 4

def MemAttr_NC : (BitVec 2) := 0b00#2

def MemAttr_WT : (BitVec 2) := 0b10#2

def MemAttr_WB : (BitVec 2) := 0b11#2

def MemHint_No : (BitVec 2) := 0b00#2

def MemHint_WA : (BitVec 2) := 0b01#2

def MemHint_RA : (BitVec 2) := 0b10#2

def MemHint_RWA : (BitVec 2) := 0b11#2

def undefined_Shareability (_ : Unit) : SailM Shareability := do
  (internal_pick [Shareability_NSH, Shareability_ISH, Shareability_OSH])

def undefined_MemTagType (_ : Unit) : SailM MemTagType := do
  (internal_pick [MemTag_Untagged, MemTag_AllocationTagged, MemTag_CanonicallyTagged])

def undefined_MemoryAttributes (_ : Unit) : SailM MemoryAttributes := do
  (pure { memtype := (← do
            (undefined_MemType ()))
          device := (← do
            (undefined_DeviceType ()))
          inner := (← do
            (undefined_MemAttrHints ()))
          outer := (← do
            (undefined_MemAttrHints ()))
          shareability := (← do
            (undefined_Shareability ()))
          tags := (← do
            (undefined_MemTagType ()))
          notagaccess := (← do
            (undefined_bool ()))
          xs := (← do
            (undefined_bitvector 1)) })

def undefined_PASpace (_ : Unit) : SailM PASpace := do
  (internal_pick [PAS_NonSecure, PAS_Secure, PAS_Root, PAS_Realm])

def __UNKNOWN_PASpace (_ : Unit) : SailM PASpace := do
  (undefined_PASpace ())

def undefined_FullAddress (_ : Unit) : SailM FullAddress := do
  (pure { paspace := (← do
            (undefined_PASpace ()))
          address := (← do
            (undefined_bitvector 56)) })

def undefined_GPCF (_ : Unit) : SailM GPCF := do
  (internal_pick [GPCF_None, GPCF_AddressSize, GPCF_Walk, GPCF_EABT, GPCF_Fail])

def undefined_GPCFRecord (_ : Unit) : SailM GPCFRecord := do
  (pure { gpf := (← do
            (undefined_GPCF ()))
          level := (← do
            (undefined_int ())) })

def undefined_Fault (_ : Unit) : SailM Fault := do
  (internal_pick [Fault_None, Fault_AccessFlag, Fault_Alignment, Fault_Background, Fault_Domain, Fault_Permission, Fault_Translation, Fault_AddressSize, Fault_SyncExternal, Fault_SyncExternalOnWalk, Fault_SyncParity, Fault_SyncParityOnWalk, Fault_GPCFOnWalk, Fault_GPCFOnOutput, Fault_AsyncParity, Fault_AsyncExternal, Fault_TagCheck, Fault_Debug, Fault_TLBConflict, Fault_BranchTarget, Fault_HWUpdateAccessFlag, Fault_Lockdown, Fault_Exclusive, Fault_ICacheMaint])

def undefined_ErrorState (_ : Unit) : SailM ErrorState := do
  (internal_pick [ErrorState_UC, ErrorState_UEU, ErrorState_UEO, ErrorState_UER, ErrorState_CE, ErrorState_Uncategorized, ErrorState_IMPDEF])

def undefined_FaultRecord (_ : Unit) : SailM FaultRecord := do
  (pure { statuscode := (← do
            (undefined_Fault ()))
          access := (← do
            (undefined_AccessDescriptor ()))
          ipaddress := (← do
            (undefined_FullAddress ()))
          gpcf := (← do
            (undefined_GPCFRecord ()))
          paddress := (← do
            (undefined_FullAddress ()))
          gpcfs2walk := (← do
            (undefined_bool ()))
          s2fs1walk := (← do
            (undefined_bool ()))
          write := (← do
            (undefined_bool ()))
          s1tagnotdata := (← do
            (undefined_bool ()))
          tagaccess := (← do
            (undefined_bool ()))
          level := (← do
            (undefined_int ()))
          extflag := (← do
            (undefined_bitvector 1))
          secondstage := (← do
            (undefined_bool ()))
          assuredonly := (← do
            (undefined_bool ()))
          toplevel := (← do
            (undefined_bool ()))
          overlay := (← do
            (undefined_bool ()))
          dirtybit := (← do
            (undefined_bool ()))
          domain := (← do
            (undefined_bitvector 4))
          merrorstate := (← do
            (undefined_ErrorState ()))
          debugmoe := (← do
            (undefined_bitvector 4)) })

def __UNKNOWN_FaultRecord (_ : Unit) : SailM FaultRecord := do
  (undefined_FaultRecord ())

def undefined_PhysMemRetStatus (_ : Unit) : SailM PhysMemRetStatus := do
  (pure { statuscode := (← do
            (undefined_Fault ()))
          extflag := (← do
            (undefined_bitvector 1))
          merrorstate := (← do
            (undefined_ErrorState ()))
          store64bstatus := (← do
            (undefined_bitvector 64)) })

def undefined_Permissions (_ : Unit) : SailM Permissions := do
  (pure { ap_table := (← do
            (undefined_bitvector 2))
          xn_table := (← do
            (undefined_bitvector 1))
          pxn_table := (← do
            (undefined_bitvector 1))
          uxn_table := (← do
            (undefined_bitvector 1))
          ap := (← do
            (undefined_bitvector 3))
          xn := (← do
            (undefined_bitvector 1))
          uxn := (← do
            (undefined_bitvector 1))
          pxn := (← do
            (undefined_bitvector 1))
          ppi := (← do
            (undefined_bitvector 4))
          upi := (← do
            (undefined_bitvector 4))
          ndirty := (← do
            (undefined_bitvector 1))
          s2pi := (← do
            (undefined_bitvector 4))
          s2dirty := (← do
            (undefined_bitvector 1))
          po_index := (← do
            (undefined_bitvector 4))
          s2po_index := (← do
            (undefined_bitvector 4))
          s2ap := (← do
            (undefined_bitvector 2))
          s2tag_na := (← do
            (undefined_bitvector 1))
          s2xnx := (← do
            (undefined_bitvector 1))
          s2xn := (← do
            (undefined_bitvector 1)) })

def undefined_S1AccessControls (_ : Unit) : SailM S1AccessControls := do
  (pure { r := (← do
            (undefined_bitvector 1))
          w := (← do
            (undefined_bitvector 1))
          x := (← do
            (undefined_bitvector 1))
          gcs := (← do
            (undefined_bitvector 1))
          overlay := (← do
            (undefined_bool ()))
          or := (← do
            (undefined_bitvector 1))
          ow := (← do
            (undefined_bitvector 1))
          ox := (← do
            (undefined_bitvector 1))
          wxn := (← do
            (undefined_bitvector 1)) })

def undefined_S2AccessControls (_ : Unit) : SailM S2AccessControls := do
  (pure { r := (← do
            (undefined_bitvector 1))
          w := (← do
            (undefined_bitvector 1))
          x := (← do
            (undefined_bitvector 1))
          r_rcw := (← do
            (undefined_bitvector 1))
          w_rcw := (← do
            (undefined_bitvector 1))
          r_mmu := (← do
            (undefined_bitvector 1))
          w_mmu := (← do
            (undefined_bitvector 1))
          toplevel0 := (← do
            (undefined_bitvector 1))
          toplevel1 := (← do
            (undefined_bitvector 1))
          overlay := (← do
            (undefined_bool ()))
          or := (← do
            (undefined_bitvector 1))
          ow := (← do
            (undefined_bitvector 1))
          ox := (← do
            (undefined_bitvector 1))
          or_rcw := (← do
            (undefined_bitvector 1))
          ow_rcw := (← do
            (undefined_bitvector 1))
          or_mmu := (← do
            (undefined_bitvector 1))
          ow_mmu := (← do
            (undefined_bitvector 1)) })

def undefined_MBReqDomain (_ : Unit) : SailM MBReqDomain := do
  (internal_pick [MBReqDomain_Nonshareable, MBReqDomain_InnerShareable, MBReqDomain_OuterShareable, MBReqDomain_FullSystem])

def undefined_MBReqTypes (_ : Unit) : SailM MBReqTypes := do
  (internal_pick [MBReqTypes_Reads, MBReqTypes_Writes, MBReqTypes_All])

def undefined_PrefetchHint (_ : Unit) : SailM PrefetchHint := do
  (internal_pick [Prefetch_READ, Prefetch_WRITE, Prefetch_EXEC])

def undefined_Constraint (_ : Unit) : SailM Constraint := do
  (internal_pick [Constraint_NONE, Constraint_UNKNOWN, Constraint_UNDEF, Constraint_UNDEFEL0, Constraint_NOP, Constraint_TRUE, Constraint_FALSE, Constraint_DISABLED, Constraint_UNCOND, Constraint_COND, Constraint_ADDITIONAL_DECODE, Constraint_WBSUPPRESS, Constraint_FAULT, Constraint_LIMITED_ATOMICITY, Constraint_NVNV1_00, Constraint_NVNV1_01, Constraint_NVNV1_11, Constraint_EL1TIMESTAMP, Constraint_EL2TIMESTAMP, Constraint_OSH, Constraint_ISH, Constraint_NSH, Constraint_NC, Constraint_WT, Constraint_WB, Constraint_FORCE, Constraint_FORCENOSLCHECK, Constraint_MAPTOALLOCATED, Constraint_PMSCR_PCT_VIRT])

def __UNKNOWN_Constraint (_ : Unit) : SailM Constraint := do
  (undefined_Constraint ())

def undefined_FPRounding (_ : Unit) : SailM FPRounding := do
  (internal_pick [FPRounding_TIEEVEN, FPRounding_POSINF, FPRounding_NEGINF, FPRounding_ZERO, FPRounding_TIEAWAY, FPRounding_ODD])

def undefined_FPType (_ : Unit) : SailM FPType := do
  (internal_pick [FPType_Zero, FPType_Denormal, FPType_Nonzero, FPType_Infinity, FPType_QNaN, FPType_SNaN])

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def read_gpr (n : Nat) : SailM (BitVec 64) := do
  match n with
  | 0 => readReg R0
  | 1 => readReg R1
  | 2 => readReg R2
  | 3 => readReg R3
  | 4 => readReg R4
  | 5 => readReg R5
  | 6 => readReg R6
  | 7 => readReg R7
  | 8 => readReg R8
  | 9 => readReg R9
  | 10 => readReg R10
  | 11 => readReg R11
  | 12 => readReg R12
  | 13 => readReg R13
  | 14 => readReg R14
  | 15 => readReg R15
  | 16 => readReg R16
  | 17 => readReg R17
  | 18 => readReg R18
  | 19 => readReg R19
  | 20 => readReg R20
  | 21 => readReg R21
  | 22 => readReg R22
  | 23 => readReg R23
  | 24 => readReg R24
  | 25 => readReg R25
  | 26 => readReg R26
  | 27 => readReg R27
  | 28 => readReg R28
  | 29 => readReg R29
  | _ => readReg R30

/-- Type quantifiers: n : Nat, lo : Nat, hi : Nat, 0 ≤ n ∧ n ≤ 30 ∧ 0 ≤ lo ∧ lo ≤ hi ∧ hi ≤ 63 -/
def write_gpr_bits (n : Nat) (hi : Nat) (lo : Nat) (v : (BitVec (hi - lo + 1))) : SailM Unit := do
  match n with
  | 0 => writeReg R0 (Sail.BitVec.updateSubrange (← readReg R0) hi lo v)
  | 1 => writeReg R1 (Sail.BitVec.updateSubrange (← readReg R1) hi lo v)
  | 2 => writeReg R2 (Sail.BitVec.updateSubrange (← readReg R2) hi lo v)
  | 3 => writeReg R3 (Sail.BitVec.updateSubrange (← readReg R3) hi lo v)
  | 4 => writeReg R4 (Sail.BitVec.updateSubrange (← readReg R4) hi lo v)
  | 5 => writeReg R5 (Sail.BitVec.updateSubrange (← readReg R5) hi lo v)
  | 6 => writeReg R6 (Sail.BitVec.updateSubrange (← readReg R6) hi lo v)
  | 7 => writeReg R7 (Sail.BitVec.updateSubrange (← readReg R7) hi lo v)
  | 8 => writeReg R8 (Sail.BitVec.updateSubrange (← readReg R8) hi lo v)
  | 9 => writeReg R9 (Sail.BitVec.updateSubrange (← readReg R9) hi lo v)
  | 10 => writeReg R10 (Sail.BitVec.updateSubrange (← readReg R10) hi lo v)
  | 11 => writeReg R11 (Sail.BitVec.updateSubrange (← readReg R11) hi lo v)
  | 12 => writeReg R12 (Sail.BitVec.updateSubrange (← readReg R12) hi lo v)
  | 13 => writeReg R13 (Sail.BitVec.updateSubrange (← readReg R13) hi lo v)
  | 14 => writeReg R14 (Sail.BitVec.updateSubrange (← readReg R14) hi lo v)
  | 15 => writeReg R15 (Sail.BitVec.updateSubrange (← readReg R15) hi lo v)
  | 16 => writeReg R16 (Sail.BitVec.updateSubrange (← readReg R16) hi lo v)
  | 17 => writeReg R17 (Sail.BitVec.updateSubrange (← readReg R17) hi lo v)
  | 18 => writeReg R18 (Sail.BitVec.updateSubrange (← readReg R18) hi lo v)
  | 19 => writeReg R19 (Sail.BitVec.updateSubrange (← readReg R19) hi lo v)
  | 20 => writeReg R20 (Sail.BitVec.updateSubrange (← readReg R20) hi lo v)
  | 21 => writeReg R21 (Sail.BitVec.updateSubrange (← readReg R21) hi lo v)
  | 22 => writeReg R22 (Sail.BitVec.updateSubrange (← readReg R22) hi lo v)
  | 23 => writeReg R23 (Sail.BitVec.updateSubrange (← readReg R23) hi lo v)
  | 24 => writeReg R24 (Sail.BitVec.updateSubrange (← readReg R24) hi lo v)
  | 25 => writeReg R25 (Sail.BitVec.updateSubrange (← readReg R25) hi lo v)
  | 26 => writeReg R26 (Sail.BitVec.updateSubrange (← readReg R26) hi lo v)
  | 27 => writeReg R27 (Sail.BitVec.updateSubrange (← readReg R27) hi lo v)
  | 28 => writeReg R28 (Sail.BitVec.updateSubrange (← readReg R28) hi lo v)
  | 29 => writeReg R29 (Sail.BitVec.updateSubrange (← readReg R29) hi lo v)
  | _ => writeReg R30 (Sail.BitVec.updateSubrange (← readReg R30) hi lo v)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def write_gpr (n : Nat) (v : (BitVec 64)) : SailM Unit := do
  match n with
  | 0 => writeReg R0 v
  | 1 => writeReg R1 v
  | 2 => writeReg R2 v
  | 3 => writeReg R3 v
  | 4 => writeReg R4 v
  | 5 => writeReg R5 v
  | 6 => writeReg R6 v
  | 7 => writeReg R7 v
  | 8 => writeReg R8 v
  | 9 => writeReg R9 v
  | 10 => writeReg R10 v
  | 11 => writeReg R11 v
  | 12 => writeReg R12 v
  | 13 => writeReg R13 v
  | 14 => writeReg R14 v
  | 15 => writeReg R15 v
  | 16 => writeReg R16 v
  | 17 => writeReg R17 v
  | 18 => writeReg R18 v
  | 19 => writeReg R19 v
  | 20 => writeReg R20 v
  | 21 => writeReg R21 v
  | 22 => writeReg R22 v
  | 23 => writeReg R23 v
  | 24 => writeReg R24 v
  | 25 => writeReg R25 v
  | 26 => writeReg R26 v
  | 27 => writeReg R27 v
  | 28 => writeReg R28 v
  | 29 => writeReg R29 v
  | _ => writeReg R30 v

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def get_R (n : Nat) : SailM (BitVec 64) := do
  (read_gpr n)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def set_R (n : Nat) (v : (BitVec 64)) : SailM Unit := do
  (write_gpr n v)

/-- Type quantifiers: n : Nat, lo : Nat, hi : Nat, 0 ≤ n ∧ n ≤ 30 ∧ 0 ≤ lo ∧ lo ≤ hi ∧ hi ≤ 63 -/
def set_R_bits (n : Nat) (hi : Nat) (lo : Nat) (v : (BitVec (hi - lo + 1))) : SailM Unit := do
  (write_gpr_bits n hi lo v)

def undefined_BranchType (_ : Unit) : SailM BranchType := do
  (internal_pick [BranchType_DIRCALL, BranchType_INDCALL, BranchType_ERET, BranchType_DBGEXIT, BranchType_RET, BranchType_DIR, BranchType_INDIR, BranchType_EXCEPTION, BranchType_TMFAIL, BranchType_RESET, BranchType_UNKNOWN])

def DefaultPARTID : PARTIDtype := (integer_subrange 0 15 0)

def DefaultPMG : PMGtype := (integer_subrange 0 7 0)

def undefined_Exception (_ : Unit) : SailM Exception := do
  (internal_pick [Exception_Uncategorized, Exception_WFxTrap, Exception_CP15RTTrap, Exception_CP15RRTTrap, Exception_CP14RTTrap, Exception_CP14DTTrap, Exception_CP14RRTTrap, Exception_AdvSIMDFPAccessTrap, Exception_FPIDTrap, Exception_LDST64BTrap, Exception_PACTrap, Exception_IllegalState, Exception_SupervisorCall, Exception_HypervisorCall, Exception_MonitorCall, Exception_SystemRegisterTrap, Exception_ERetTrap, Exception_InstructionAbort, Exception_PCAlignment, Exception_DataAbort, Exception_NV2DataAbort, Exception_PACFail, Exception_SPAlignment, Exception_FPTrappedException, Exception_SError, Exception_Breakpoint, Exception_SoftwareStep, Exception_Watchpoint, Exception_NV2Watchpoint, Exception_SoftwareBreakpoint, Exception_VectorCatch, Exception_IRQ, Exception_SVEAccessTrap, Exception_SMEAccessTrap, Exception_TSTARTAccessTrap, Exception_GPC, Exception_BranchTarget, Exception_MemCpyMemSet, Exception_GCSFail, Exception_SystemRegister128Trap, Exception_FIQ])

def undefined_ExceptionRecord (_ : Unit) : SailM ExceptionRecord := do
  (pure { exceptype := (← do
            (undefined_Exception ()))
          syndrome := (← do
            (undefined_bitvector 25))
          syndrome2 := (← do
            (undefined_bitvector 24))
          paddress := (← do
            (undefined_FullAddress ()))
          vaddress := (← do
            (undefined_bitvector 64))
          ipavalid := (← do
            (undefined_bool ()))
          pavalid := (← do
            (undefined_bool ()))
          NS := (← do
            (undefined_bitvector 1))
          ipaddress := (← do
            (undefined_bitvector 56))
          trappedsyscallinst := (← do
            (undefined_bool ())) })

def undefined_Regime (_ : Unit) : SailM Regime := do
  (internal_pick [Regime_EL3, Regime_EL30, Regime_EL2, Regime_EL20, Regime_EL10])

def undefined_TGx (_ : Unit) : SailM TGx := do
  (internal_pick [TGx_4KB, TGx_16KB, TGx_64KB])

def undefined_DescriptorType (_ : Unit) : SailM DescriptorType := do
  (internal_pick [DescriptorType_Table, DescriptorType_Leaf, DescriptorType_Invalid])

def undefined_SDFType (_ : Unit) : SailM SDFType := do
  (internal_pick [SDFType_Table, SDFType_Invalid, SDFType_Supersection, SDFType_Section, SDFType_LargePage, SDFType_SmallPage])

def undefined_TTWState (_ : Unit) : SailM TTWState := do
  (pure { istable := (← do
            (undefined_bool ()))
          level := (← do
            (undefined_int ()))
          baseaddress := (← do
            (undefined_FullAddress ()))
          contiguous := (← do
            (undefined_bitvector 1))
          s1assured := (← do
            (undefined_bool ()))
          s2assuredonly := (← do
            (undefined_bitvector 1))
          disch := (← do
            (undefined_bitvector 1))
          nG := (← do
            (undefined_bitvector 1))
          guardedpage := (← do
            (undefined_bitvector 1))
          sdftype := (← do
            (undefined_SDFType ()))
          domain := (← do
            (undefined_bitvector 4))
          memattrs := (← do
            (undefined_MemoryAttributes ()))
          permissions := (← do
            (undefined_Permissions ())) })

def __UNKNOWN_TTWState (_ : Unit) : SailM TTWState := do
  (undefined_TTWState ())

def undefined_S1TTWParams (_ : Unit) : SailM S1TTWParams := do
  (pure { ha := (← do
            (undefined_bitvector 1))
          hd := (← do
            (undefined_bitvector 1))
          tbi := (← do
            (undefined_bitvector 1))
          tbid := (← do
            (undefined_bitvector 1))
          nfd := (← do
            (undefined_bitvector 1))
          e0pd := (← do
            (undefined_bitvector 1))
          d128 := (← do
            (undefined_bitvector 1))
          aie := (← do
            (undefined_bitvector 1))
          mair2 := (← do
            (undefined_MAIRType ()))
          ds := (← do
            (undefined_bitvector 1))
          ps := (← do
            (undefined_bitvector 3))
          txsz := (← do
            (undefined_bitvector 6))
          epan := (← do
            (undefined_bitvector 1))
          dct := (← do
            (undefined_bitvector 1))
          nv1 := (← do
            (undefined_bitvector 1))
          cmow := (← do
            (undefined_bitvector 1))
          pnch := (← do
            (undefined_bitvector 1))
          disch := (← do
            (undefined_bitvector 1))
          haft := (← do
            (undefined_bitvector 1))
          mtx := (← do
            (undefined_bitvector 1))
          skl := (← do
            (undefined_bitvector 2))
          pie := (← do
            (undefined_bitvector 1))
          pir := (← do
            (undefined_S1PIRType ()))
          pire0 := (← do
            (undefined_S1PIRType ()))
          emec := (← do
            (undefined_bitvector 1))
          amec := (← do
            (undefined_bitvector 1))
          t0sz := (← do
            (undefined_bitvector 3))
          t1sz := (← do
            (undefined_bitvector 3))
          uwxn := (← do
            (undefined_bitvector 1))
          tgx := (← do
            (undefined_TGx ()))
          irgn := (← do
            (undefined_bitvector 2))
          orgn := (← do
            (undefined_bitvector 2))
          sh := (← do
            (undefined_bitvector 2))
          hpd := (← do
            (undefined_bitvector 1))
          ee := (← do
            (undefined_bitvector 1))
          wxn := (← do
            (undefined_bitvector 1))
          ntlsmd := (← do
            (undefined_bitvector 1))
          dc := (← do
            (undefined_bitvector 1))
          sif := (← do
            (undefined_bitvector 1))
          mair := (← do
            (undefined_MAIRType ())) })

def undefined_S2TTWParams (_ : Unit) : SailM S2TTWParams := do
  (pure { ha := (← do
            (undefined_bitvector 1))
          hd := (← do
            (undefined_bitvector 1))
          sl2 := (← do
            (undefined_bitvector 1))
          ds := (← do
            (undefined_bitvector 1))
          d128 := (← do
            (undefined_bitvector 1))
          sw := (← do
            (undefined_bitvector 1))
          nsw := (← do
            (undefined_bitvector 1))
          sa := (← do
            (undefined_bitvector 1))
          nsa := (← do
            (undefined_bitvector 1))
          ps := (← do
            (undefined_bitvector 3))
          txsz := (← do
            (undefined_bitvector 6))
          fwb := (← do
            (undefined_bitvector 1))
          cmow := (← do
            (undefined_bitvector 1))
          skl := (← do
            (undefined_bitvector 2))
          s2pie := (← do
            (undefined_bitvector 1))
          s2pir := (← do
            (undefined_S2PIRType ()))
          tl0 := (← do
            (undefined_bitvector 1))
          tl1 := (← do
            (undefined_bitvector 1))
          assuredonly := (← do
            (undefined_bitvector 1))
          haft := (← do
            (undefined_bitvector 1))
          emec := (← do
            (undefined_bitvector 1))
          s := (← do
            (undefined_bitvector 1))
          t0sz := (← do
            (undefined_bitvector 4))
          tgx := (← do
            (undefined_TGx ()))
          sl0 := (← do
            (undefined_bitvector 2))
          irgn := (← do
            (undefined_bitvector 2))
          orgn := (← do
            (undefined_bitvector 2))
          sh := (← do
            (undefined_bitvector 2))
          ee := (← do
            (undefined_bitvector 1))
          ptw := (← do
            (undefined_bitvector 1))
          vm := (← do
            (undefined_bitvector 1)) })

def undefined_TLBContext (_ : Unit) : SailM TLBContext := do
  (pure { ss := (← do
            (undefined_SecurityState ()))
          regime := (← do
            (undefined_Regime ()))
          vmid := (← do
            (undefined_bitvector 16))
          asid := (← do
            (undefined_bitvector 16))
          nG := (← do
            (undefined_bitvector 1))
          ipaspace := (← do
            (undefined_PASpace ()))
          includes_s1_name := (← do
            (undefined_bool ()))
          includes_s2_name := (← do
            (undefined_bool ()))
          includes_gpt_name := (← do
            (undefined_bool ()))
          ia := (← do
            (undefined_bitvector 64))
          tg := (← do
            (undefined_TGx ()))
          cnp := (← do
            (undefined_bitvector 1))
          level := (← do
            (undefined_int ()))
          isd128 := (← do
            (undefined_bool ()))
          xs := (← do
            (undefined_bitvector 1)) })

def undefined_TLBRecord (_ : Unit) : SailM TLBRecord := do
  (pure { context := (← do
            (undefined_TLBContext ()))
          walkstate := (← do
            (undefined_TTWState ()))
          blocksize := (← do
            (undefined_int ()))
          contigsize := (← do
            (undefined_int ()))
          s1descriptor := (← do
            (undefined_bitvector 128))
          s2descriptor := (← do
            (undefined_bitvector 128)) })

def undefined_AddressDescriptor (_ : Unit) : SailM AddressDescriptor := do
  (pure { fault := (← do
            (undefined_FaultRecord ()))
          memattrs := (← do
            (undefined_MemoryAttributes ()))
          paddress := (← do
            (undefined_FullAddress ()))
          tlbcontext := (← do
            (undefined_TLBContext ()))
          s1assured := (← do
            (undefined_bool ()))
          s2fs1mro := (← do
            (undefined_bool ()))
          mecid := (← do
            (undefined_bitvector 16))
          vaddress := (← do
            (undefined_bitvector 64)) })

def __UNKNOWN_AddressDescriptor (_ : Unit) : SailM AddressDescriptor := do
  (undefined_AddressDescriptor ())

def FINAL_LEVEL : Nat := 3

def MAX_VL : Nat := 2048

def MAX_PL : Nat := 256

def ZT0_LEN : Nat := 512

def undefined_GCSInstruction (_ : Unit) : SailM GCSInstruction := do
  (internal_pick [GCSInstType_PRET, GCSInstType_POPM, GCSInstType_PRETAA, GCSInstType_PRETAB, GCSInstType_SS1, GCSInstType_SS2, GCSInstType_POPCX, GCSInstType_POPX])

def DEFAULT_MECID : (BitVec 16) := (Zeros (n := 16))

def undefined_FPCR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPCR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_FPSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPSR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_CTR_Type_IDC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_PMCR_Type_N (v : (BitVec 32)) (x : (BitVec 5)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 11 x)

def _update_TTBCR_Type_N (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _get_PMCR_EL0_Type_N (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 15 11)

def _get_PMCR_Type_N (v : (BitVec 32)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 15 11)

def _update_FPSCR_Type_UFC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_SCTLR_Type_V (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _get_SCTLR_Type_V (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def undefined_ICC_PMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_PMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_ICC_PMR_Type_Priority (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_ICV_PMR_Type_Priority (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _get_ICV_PMR_EL1_Type_Priority (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def undefined_TMState (_ : Unit) : SailM TMState := do
  (pure { depth := (← do
            (undefined_int ()))
          Rt := (← do
            (undefined_int ()))
          nPC := (← do
            (undefined_bitvector 64))
          X := (← do
            (undefined_vector 31 (← (undefined_bitvector 64))))
          Z := (← do
            (undefined_vector 32 (← (undefined_bitvector 2048))))
          P := (← do
            (undefined_vector 16 (← (undefined_bitvector 256))))
          FFR := (← do
            (undefined_bitvector 256))
          SP := (← do
            (undefined_bitvector 64))
          FPCR := (← do
            (undefined_bitvector 64))
          FPSR := (← do
            (undefined_bitvector 64))
          ICC_PMR_EL1 := (← do
            (undefined_bitvector 64))
          GCSPR_ELx := (← do
            (undefined_bitvector 64))
          nzcv := (← do
            (undefined_bitvector 4))
          D := (← do
            (undefined_bitvector 1))
          A := (← do
            (undefined_bitvector 1))
          I := (← do
            (undefined_bitvector 1))
          F := (← do
            (undefined_bitvector 1)) })

def undefined_PGSe (_ : Unit) : SailM PGSe := do
  (internal_pick [PGS_4KB, PGS_16KB, PGS_64KB])

def GPT_NoAccess : (BitVec 4) := 0b0000#4

def GPT_Table : (BitVec 4) := 0b0011#4

def GPT_Block : (BitVec 4) := 0b0001#4

def GPT_Contig : (BitVec 4) := 0b0001#4

def GPT_Secure : (BitVec 4) := 0b1000#4

def GPT_NonSecure : (BitVec 4) := 0b1001#4

def GPT_Root : (BitVec 4) := 0b1010#4

def GPT_Realm : (BitVec 4) := 0b1011#4

def GPT_Any : (BitVec 4) := 0b1111#4

def GPTRange_4KB : Nat := 12

def GPTRange_16KB : Nat := 14

def GPTRange_64KB : Nat := 16

def GPTRange_2MB : Nat := 21

def GPTRange_32MB : Nat := 25

def GPTRange_512MB : Nat := 29

def GPTRange_1GB : Nat := 30

def GPTRange_16GB : Nat := 34

def GPTRange_64GB : Nat := 36

def GPTRange_512GB : Nat := 39

def undefined_GPTTable (_ : Unit) : SailM GPTTable := do
  (pure { address := (← do (undefined_bitvector 56)) })

def __UNKNOWN_GPTTable (_ : Unit) : SailM GPTTable := do
  (undefined_GPTTable ())

def undefined_GPTEntry (_ : Unit) : SailM GPTEntry := do
  (pure { gpi := (← do
            (undefined_bitvector 4))
          size := (← do
            (undefined_int ()))
          contig_size := (← do
            (undefined_int ()))
          level := (← do
            (undefined_int ()))
          pa := (← do
            (undefined_bitvector 56)) })

def __UNKNOWN_GPTEntry (_ : Unit) : SailM GPTEntry := do
  (undefined_GPTEntry ())

def SPEMaxCounters : Nat := 32

def SPEMaxRecordSize : Nat := 64

def undefined_OpType (_ : Unit) : SailM OpType := do
  (internal_pick [OpType_Load, OpType_Store, OpType_LoadAtomic, OpType_Branch, OpType_Other])

def SPEAddrPosBranchTarget : Nat := 1

def SPEAddrPosDataVirtual : Nat := 2

def SPEAddrPosDataPhysical : Nat := 3

def SPEAddrPosPrevBranchTarget : Nat := 4

def SPECounterPosTranslationLatency : Nat := 2

def undefined_ExtendType (_ : Unit) : SailM ExtendType := do
  (internal_pick [ExtendType_SXTB, ExtendType_SXTH, ExtendType_SXTW, ExtendType_SXTX, ExtendType_UXTB, ExtendType_UXTH, ExtendType_UXTW, ExtendType_UXTX])

def undefined_FPMaxMinOp (_ : Unit) : SailM FPMaxMinOp := do
  (internal_pick [FPMaxMinOp_MAX, FPMaxMinOp_MIN, FPMaxMinOp_MAXNUM, FPMaxMinOp_MINNUM])

def undefined_FPUnaryOp (_ : Unit) : SailM FPUnaryOp := do
  (internal_pick [FPUnaryOp_ABS, FPUnaryOp_MOV, FPUnaryOp_NEG, FPUnaryOp_SQRT])

def undefined_FPConvOp (_ : Unit) : SailM FPConvOp := do
  (internal_pick [FPConvOp_CVT_FtoI, FPConvOp_CVT_ItoF, FPConvOp_MOV_FtoI, FPConvOp_MOV_ItoF, FPConvOp_CVT_FtoI_JS])

def undefined_MoveWideOp (_ : Unit) : SailM MoveWideOp := do
  (internal_pick [MoveWideOp_N, MoveWideOp_Z, MoveWideOp_K])

def undefined_ShiftType (_ : Unit) : SailM ShiftType := do
  (internal_pick [ShiftType_LSL, ShiftType_LSR, ShiftType_ASR, ShiftType_ROR])

def undefined_LogicalOp (_ : Unit) : SailM LogicalOp := do
  (internal_pick [LogicalOp_AND, LogicalOp_EOR, LogicalOp_ORR])

def undefined_SystemHintOp (_ : Unit) : SailM SystemHintOp := do
  (internal_pick [SystemHintOp_NOP, SystemHintOp_YIELD, SystemHintOp_WFE, SystemHintOp_WFI, SystemHintOp_SEV, SystemHintOp_SEVL, SystemHintOp_DGH, SystemHintOp_ESB, SystemHintOp_PSB, SystemHintOp_TSB, SystemHintOp_BTI, SystemHintOp_WFET, SystemHintOp_WFIT, SystemHintOp_CLRBHB, SystemHintOp_GCSB, SystemHintOp_CHKFEAT, SystemHintOp_CSDB])

def undefined_PSTATEField (_ : Unit) : SailM PSTATEField := do
  (internal_pick [PSTATEField_DAIFSet, PSTATEField_DAIFClr, PSTATEField_PAN, PSTATEField_UAO, PSTATEField_DIT, PSTATEField_SSBS, PSTATEField_TCO, PSTATEField_SVCRSM, PSTATEField_SVCRZA, PSTATEField_SVCRSMZA, PSTATEField_ALLINT, PSTATEField_PM, PSTATEField_SP])

def VMID_NONE : (BitVec 16) := (Zeros (n := 16))

def MAX_ZERO_BLOCK_SIZE : Nat := 2048

def undefined_VBitOp (_ : Unit) : SailM VBitOp := do
  (internal_pick [VBitOp_VBIF, VBitOp_VBIT, VBitOp_VBSL, VBitOp_VEOR])

def undefined_CompareOp (_ : Unit) : SailM CompareOp := do
  (internal_pick [CompareOp_GT, CompareOp_GE, CompareOp_EQ, CompareOp_LE, CompareOp_LT])

def undefined_ImmediateOp (_ : Unit) : SailM ImmediateOp := do
  (internal_pick [ImmediateOp_MOVI, ImmediateOp_MVNI, ImmediateOp_ORR, ImmediateOp_BIC])

def DebugHalt_Breakpoint : (BitVec 6) := 0b000111#6

def DebugHalt_Step_Normal : (BitVec 6) := 0b011011#6

def DebugHalt_Step_Exclusive : (BitVec 6) := 0b011111#6

def DebugHalt_Watchpoint : (BitVec 6) := 0b101011#6

def DebugHalt_HaltInstruction : (BitVec 6) := 0b101111#6

def DebugHalt_ExceptionCatch : (BitVec 6) := 0b110111#6

def DebugHalt_Step_NoSyndrome : (BitVec 6) := 0b111011#6

def undefined_TLBLine (_ : Unit) : SailM TLBLine := do
  (pure { tlbrecord := (← do
            (undefined_TLBRecord ()))
          valid_name := (← do
            (undefined_bool ())) })

def __UNKNOWN_TLBLine (_ : Unit) : SailM TLBLine := do
  (undefined_TLBLine ())

def undefined_GPTTLBLine (_ : Unit) : SailM GPTTLBLine := do
  (pure { gpt_entry := (← do
            (undefined_GPTEntry ()))
          valid_name := (← do
            (undefined_bool ())) })

def __UNKNOWN_GPTTLBLine (_ : Unit) : SailM GPTTLBLine := do
  (undefined_GPTTLBLine ())

def undefined_InterruptReq (_ : Unit) : SailM InterruptReq := do
  (pure { take_SE := (← do
            (undefined_bool ()))
          take_vSE := (← do
            (undefined_bool ()))
          take_IRQ := (← do
            (undefined_bool ()))
          take_vIRQ := (← do
            (undefined_bool ()))
          take_FIQ := (← do
            (undefined_bool ()))
          take_vFIQ := (← do
            (undefined_bool ()))
          iesb_req := (← do
            (undefined_bool ())) })

def undefined___InstrEnc (_ : Unit) : SailM __InstrEnc := do
  (internal_pick [__A64, __A32, __T16, __T32])

def CFG_ID_AA64PFR0_EL1_EL0 : (BitVec 4) := 0b0010#4

def CFG_ID_AA64PFR0_EL1_EL1 : (BitVec 4) := 0b0001#4

def CFG_ID_AA64PFR0_EL1_EL2 : (BitVec 4) := 0b0001#4

def CFG_ID_AA64PFR0_EL1_EL3 : (BitVec 4) := 0b0001#4

def CFG_PMCR_IDCODE : (BitVec 8) := 0b00000000#8

def CFG_MPAM_none : (BitVec 4) := 0b0000#4

def CFG_MPAM_v0p1 : (BitVec 4) := 0b0000#4

def CFG_MPAM_v1p1 : (BitVec 4) := 0b0001#4

def CFG_MPAM_frac_none : (BitVec 4) := 0b0000#4

def CFG_MPAM_frac_v0p1 : (BitVec 4) := 0b0001#4

def CFG_MPAM_frac_v1p1 : (BitVec 4) := 0b0001#4

def DebugException_VectorCatch : (BitVec 4) := 0b0101#4

def undefined_HCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HCR_EL2_Type_AMO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_HCR_Type_AMO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_HCR_Type_AMO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HCR_EL2_Type_API (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_SCR_EL3_Type_API (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HCR_EL2_Type_ATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_SCR_EL3_Type_ATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_SCTLR_EL1_Type_ATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_SCTLR_EL2_Type_ATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_SCTLR_EL3_Type_ATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _update_HCR_Type_BSU (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 10 x)

def _get_HCR_EL2_Type_CD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _update_HCR2_Type_CD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_HCR_EL2_Type_DC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _update_HCR_Type_DC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _get_HCR_EL2_Type_DCT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_HCR_EL2_Type_E2H (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _update_HCR_Type_FB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _get_HCR_EL2_Type_FMO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_HCR_Type_FMO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_HCR_Type_FMO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HCR_EL2_Type_FWB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 46 46)

def _get_HCR_EL2_Type_GPF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _get_SCR_EL3_Type_GPF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _update_HCR_Type_HCD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_HCR_EL2_Type_ID (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _update_HCR2_Type_ID (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_HCR_EL2_Type_IMO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _update_HCR_Type_IMO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _get_HCR_Type_IMO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HCR_EL2_Type_NV (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_HCR_EL2_Type_NV1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_HCR_EL2_Type_PTW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_HCR_Type_PTW (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_HCR_Type_SWIO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_HCR_EL2_Type_TDZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_HCR_EL2_Type_TEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _update_HCR2_Type_TEA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_HCR2_Type_TEA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_HCR2_Type_TERR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _get_HCR_EL2_Type_TGE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _update_HCR_Type_TGE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _get_HCR_Type_TGE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _update_HCR2_Type_TICAB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_HCR_Type_TID0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_HCR_Type_TID1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _update_HCR_Type_TID2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _get_HCR_EL2_Type_TID3 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _update_HCR_Type_TID3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_HCR2_Type_TID4 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _update_HCR2_Type_TOCU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _update_HCR_Type_TPC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _update_HCR_Type_TPU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_HCR_Type_TRVM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_HCR_Type_TSC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _update_HCR_Type_TSW (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _update_HCR_Type_TTLB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _update_HCR2_Type_TTLBIS (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _update_HCR_Type_TVM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _get_HCR_EL2_Type_TWEDEL (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 63 60)

def _get_SCR_EL3_Type_TWEDEL (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 33 30)

def _get_SCTLR_EL1_Type_TWEDEL (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 49 46)

def _get_SCTLR_EL2_Type_TWEDEL (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 49 46)

def _get_HCR_EL2_Type_TWEDEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCR_EL3_Type_TWEDEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_SCTLR_EL1_Type_TWEDEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 45 45)

def _get_SCTLR_EL2_Type_TWEDEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 45 45)

def _get_HCR_EL2_Type_VF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _update_HCR_Type_VF (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_HCR_Type_VF (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_HCR_EL2_Type_VI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_HCR_Type_VI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_HCR_Type_VI (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HCR_EL2_Type_VM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_HCR_Type_VM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_HCR_EL2_Type_VSE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def HaveAArch64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AA64EL0) <||> (do
    (IsFeatureImplemented FEAT_AA64EL1)) <||> (do
    (IsFeatureImplemented FEAT_AA64EL2)) <||> (do
    (IsFeatureImplemented FEAT_AA64EL3))

def HaveSecureEL2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SEL2)

def HaveVirtHostExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_VHE)

def undefined_SCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCR_EL3_Type_EASE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLR2_EL1_Type_EASE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_SCTLR2_EL2_Type_EASE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_SCR_EL3_Type_EEL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_SCR_EL3_Type_FGTEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_SCR_EL3_Type_GCSEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 39 39)

def _get_HCRX_EL2_Type_GCSEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_SCR_EL3_Type_HXEn (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_SCR_EL3_Type_NMEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_SCTLR2_EL1_Type_NMEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR2_EL2_Type_NMEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_EL3_Type_NSE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _get_SCR_EL3_Type_SCTLR2En (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_HCRX_EL2_Type_SCTLR2En (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_SCR_EL3_Type_TCR2En (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_HCRX_EL2_Type_TCR2En (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCR_EL3_Type_TMEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_HCRX_EL2_Type_TMEA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def HaveAArch32EL (el : (BitVec 2)) : Bool :=
  (el == EL0)

def HaveEL (el : (BitVec 2)) : Bool :=
  true

/-- Type quantifiers: k_secure : Bool -/
def ELStateUsingAArch32K (el : (BitVec 2)) (secure : Bool) : SailM (Bool × Bool) := do
  (if ((! (HaveAArch32EL el)) : Bool)
  then (do (pure (true, false)))
  else
    (do (if ((secure && (el == EL2)) : Bool)
        then (do (pure (true, false)))
        else
          (do (if ((! (← (HaveAArch64 ()))) : Bool)
              then (do (pure (true, true)))
              else
                (do let aarch32 ← (( do (__UNKNOWN_boolean ()) ) : SailM Bool )
                    let known : Bool := true
                    let aarch32_below_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure (! secure)) <||> (do (pure (! (← (HaveSecureEL2Ext ()))))) <||> (do (pure ((_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3)) == 0#1)))) <&&> (do (pure ((_get_SCR_EL3_Type_RW (← readReg SCR_EL3)) == 0#1))) ) : SailM Bool )
                    let aarch32_at_el1 ← (( do (pure aarch32_below_el3) <||> (do (pure (HaveEL EL2)) <&&> (do (pure (! secure)) <||> (do (HaveSecureEL2Ext ()) <&&> (do (pure ((_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3)) == 1#1))))) <&&> (do (pure (! (←((HaveVirtHostExt ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))))) <&&> (do (pure ((_get_HCR_EL2_Type_RW (← readReg HCR_EL2)) == 0#1)))) ) : SailM Bool )
                    let (aarch32, known) ← (( do
                      (if (((el == EL0) && (! aarch32_at_el1)) : Bool)
                      then
                        (do let (aarch32, known) ← (( do
                              (if (((← readReg PSTATE).EL == EL0) : Bool)
                              then
                                (do let aarch32 ← (pure ((← readReg PSTATE).nRW == 1#1))
                                    (pure (aarch32, known)))
                              else
                                (do let known : Bool := false
                                    (pure (aarch32, known)))) ) : SailM (Bool × Bool) )
                            (pure (aarch32, known)))
                      else
                        (do let aarch32 : Bool := ((aarch32_below_el3 && (el != EL3)) || (aarch32_at_el1 && ((el == EL1) || (el == EL0))))
                            (pure (aarch32, known)))) ) : SailM (Bool × Bool) )
                    let aarch32 ← (( do
                      (if ((! known) : Bool)
                      then (do (__UNKNOWN_boolean ()))
                      else (do (pure aarch32))) ) : SailM Bool )
                    (pure (known, aarch32))))))))

/-- Type quantifiers: k_secure : Bool -/
def ELStateUsingAArch32 (el : (BitVec 2)) (secure : Bool) : SailM Bool := do
  let aarch32 ← (( do (undefined_bool ()) ) : SailM Bool )
  let known ← (( do (undefined_bool ()) ) : SailM Bool )
  let (aarch32, known) ← (( do
    let (tup__0, tup__1) ← do (ELStateUsingAArch32K el secure)
    let known : Bool := tup__0
    let aarch32 : Bool := tup__1
    (pure (aarch32, known)) ) : SailM (Bool × Bool) )
  sail_assert known "sail-arm/arm-v9.4-a/src/v8_base.sail:3453.16-3453.17"
  (pure aarch32)

def undefined_SCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def SCR_GEN_read (_ : Unit) : SailM (BitVec 64) := do
  sail_assert (HaveEL EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:3479.22-3479.23"
  let r ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (HaveAArch64 ()))) : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← readReg SCR) 64)))
    else (do readReg SCR_EL3)) ) : SailM (BitVec 64) )
  (pure (Mk_SCRType r))

def HaveStatisticalProfilingv1p2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPEv1p2)

def HighestEL (_ : Unit) : (BitVec 2) :=
  if ((HaveEL EL3) : Bool)
  then EL3
  else
    (if ((HaveEL EL2) : Bool)
    then EL2
    else EL1)

def HasArchVersion (version : ArchVersion) : Bool :=
  true


end ArmASL.Functions
