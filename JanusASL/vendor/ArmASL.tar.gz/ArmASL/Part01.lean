import Sail
import ArmASL.Defs
import ArmASL.SpecializationV1
import ArmASL.FakeReal
import ArmASL.JanusExtras

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: x : Int -/
def __id (x : Int) : Int :=
  x

/-- Type quantifiers: k_ex3836654_ : Bool, k_ex3836653_ : Bool -/
def neq_bool (x : Bool) (y : Bool) : Bool :=
  (! (x == y))

/-- Type quantifiers: k_n : Nat, y : Nat, k_n ≥ 0 ∧ y ≥ 0 -/
def eq_bits_int (x : (BitVec k_n)) (y : Nat) : Bool :=
  ((BitVec.toNatInt x) == y)

/-- Type quantifiers: n : Int, m : Int -/
def _shl_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftl m n)
  else (Int.shiftr m (Neg.neg n))

/-- Type quantifiers: n : Int, m : Int -/
def _shr_int_general (m : Int) (n : Int) : Int :=
  if ((n ≥b 0) : Bool)
  then (Int.shiftr m n)
  else (Int.shiftl m (Neg.neg n))

/-- Type quantifiers: m : Int, n : Int -/
def fdiv_int (n : Int) (m : Int) : Int :=
  if (((n <b 0) && (m >b 0)) : Bool)
  then ((Int.tdiv (n +i 1) m) -i 1)
  else
    (if (((n >b 0) && (m <b 0)) : Bool)
    then ((Int.tdiv (n -i 1) m) -i 1)
    else (Int.tdiv n m))

/-- Type quantifiers: m : Int, n : Int -/
def fmod_int (n : Int) (m : Int) : Int :=
  (n -i (m *i (fdiv_int n m)))

def enable_tracing (_ : Unit) : Unit :=
  ()

def disable_tracing (_ : Unit) : Unit :=
  ()

def is_tracing (_ : Unit) : Bool :=
  false

/-- Type quantifiers: len : Nat, k_v : Nat, len ≥ 0 ∧ k_v ≥ 0 -/
def sail_mask (len : Nat) (v : (BitVec k_v)) : (BitVec len) :=
  if ((len ≤b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v len)
  else (Sail.BitVec.zeroExtend v len)

/-- Type quantifiers: i : Int, hi : Int, lo : Int, lo ≤ hi -/
def integer_subrange (i : Int) (hi : Int) (lo : Int) : (BitVec (hi - lo + 1)) :=
  (get_slice_int ((hi -i lo) +i 1) i lo)

/-- Type quantifiers: i : Int, n : Int -/
def integer_access (i : Int) (n : Int) : (BitVec 1) :=
  (BitVec.access (integer_subrange i n n) 0)

/-- Type quantifiers: i : Int, hi : Nat, lo : Nat, 0 ≤ lo ∧ lo ≤ hi -/
def integer_update_subrange (i : Int) (hi : Nat) (lo : Nat) (x : (BitVec (hi - lo + 1))) : Int :=
  (set_slice_int ((hi -i lo) +i 1) i lo x)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def sail_ones (n : Nat) : (BitVec n) :=
  (Complement.complement (BitVec.zero n))

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def slice_mask {n : _} (i : Int) (l : Int) : (BitVec n) :=
  if ((l ≥b n) : Bool)
  then ((sail_ones n) <<< i)
  else
    (let one : (BitVec n) := (sail_mask n (1#1 : (BitVec 1)))
    (((one <<< l) - one) <<< i))

/-- Type quantifiers: n : Nat, n > 0 -/
def to_bytes_le {n : _} (b : (BitVec (8 * n))) : (Vector (BitVec 8) n) := Id.run do
  let res := (vectorInit (BitVec.zero 8))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (vectorUpdate res i (Sail.BitVec.extractLsb b ((8 *i i) +i 7) (8 *i i)))
  (pure loop_vars)

/-- Type quantifiers: n : Nat, n > 0 -/
def from_bytes_le {n : _} (v : (Vector (BitVec 8) n)) : (BitVec (8 * n)) := Id.run do
  let res := (BitVec.zero (8 *i n))
  let loop_i_lower := 0
  let loop_i_upper := (n -i 1)
  let mut loop_vars := res
  for i in [loop_i_lower:loop_i_upper:1]i do
    let res := loop_vars
    loop_vars := (Sail.BitVec.updateSubrange res ((8 *i i) +i 7) (8 *i i) (GetElem?.getElem! v i))
  (pure loop_vars)

/-- Type quantifiers: k_n : Int -/
def concat_str_bits (str : String) (x : (BitVec k_n)) : String :=
  (HAppend.hAppend str (BitVec.toFormatted x))

/-- Type quantifiers: x : Int -/
def concat_str_dec (str : String) (x : Int) : String :=
  (HAppend.hAppend str (Int.repr x))

/-- Type quantifiers: k_n : Nat, List.elem k_n [8, 16, 32, 64, 128] -/
def reverse_endianness (xs : (BitVec k_n)) : (BitVec k_n) :=
  let len := (Sail.BitVec.length xs)
  if ((len == 8) : Bool)
  then xs
  else
    (if ((len == 16) : Bool)
    then ((Sail.BitVec.extractLsb xs 7 0) +++ (Sail.BitVec.extractLsb xs 15 8))
    else
      (if ((len == 32) : Bool)
      then ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ (Sail.BitVec.extractLsb xs 31 24))))
      else
        (if ((len == 64) : Bool)
        then ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ ((Sail.BitVec.extractLsb xs 31 24) +++ ((Sail.BitVec.extractLsb xs 39 32) +++ ((Sail.BitVec.extractLsb xs 47 40) +++ ((Sail.BitVec.extractLsb xs 55 48) +++ (Sail.BitVec.extractLsb xs 63 56))))))))
        else ((Sail.BitVec.extractLsb xs 7 0) +++ ((Sail.BitVec.extractLsb xs 15 8) +++ ((Sail.BitVec.extractLsb xs 23 16) +++ ((Sail.BitVec.extractLsb xs 31 24) +++ ((Sail.BitVec.extractLsb xs 39 32) +++ ((Sail.BitVec.extractLsb xs 47 40) +++ ((Sail.BitVec.extractLsb xs 55 48) +++ ((Sail.BitVec.extractLsb xs 63 56) +++ ((Sail.BitVec.extractLsb xs 71 64) +++ ((Sail.BitVec.extractLsb xs 79 72) +++ ((Sail.BitVec.extractLsb xs 87 80) +++ ((Sail.BitVec.extractLsb xs 95 88) +++ ((Sail.BitVec.extractLsb xs 103 96) +++ ((Sail.BitVec.extractLsb xs 111 104) +++ ((Sail.BitVec.extractLsb xs 119 112) +++ (Sail.BitVec.extractLsb xs 127 120)))))))))))))))))))

/-- Type quantifiers: k_a : Type -/
def is_none (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => false
  | none => true

/-- Type quantifiers: k_a : Type -/
def is_some (opt : (Option k_a)) : Bool :=
  match opt with
  | .some _ => true
  | none => false

/-- Type quantifiers: k_n : Int, m : Nat, m ≥ 0 -/
def extzv {m : _} (v : (BitVec k_n)) : (BitVec m) :=
  if ((m <b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v m)
  else (Sail.BitVec.zeroExtend v m)

/-- Type quantifiers: k_n : Int, m : Nat, m ≥ 0 -/
def extsv {m : _} (v : (BitVec k_n)) : (BitVec m) :=
  if ((m <b (Sail.BitVec.length v)) : Bool)
  then (Sail.BitVec.truncate v m)
  else (Sail.BitVec.signExtend v m)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_zero_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) == (extzv (m := (Sail.BitVec.length xs)) (0#1 : (BitVec 1))))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_zeros_slice (xs : (BitVec k_n)) (i : Int) (l : Int) : Bool :=
  ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) == (extzv (m := (Sail.BitVec.length xs)) (0#1 : (BitVec 1))))

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_ones_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  let m : (BitVec k_n) := (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))
  ((xs &&& m) == m)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def is_ones_slice (xs : (BitVec k_n)) (i : Int) (j : Int) : Bool :=
  let m : (BitVec k_n) := (slice_mask (n := (Sail.BitVec.length xs)) i j)
  ((xs &&& m) == m)

/-- Type quantifiers: l' : Int, i' : Int, l : Int, i : Int, k_n : Nat, k_m : Nat, r : Nat, k_n ≥ 0 ∧ k_m ≥ 0 ∧ r ≥ 0 -/
def slice_slice_concat {r : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (ys : (BitVec k_m)) (i' : Int) (l' : Int) : (BitVec r) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) i' l')) >>> i')
  (((extzv (m := r) xs) <<< l') ||| (extzv (m := r) ys))

/-- Type quantifiers: i : Int, k_n : Nat, l : Int, l' : Int, k_n ≥ 0 ∧ (l + l') ≥ 0 -/
def slice_zeros_concat (xs : (BitVec k_n)) (i : Int) (l : Int) (l' : Int) : (BitVec (l + l')) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  ((extzv (m := (l +i l')) xs) <<< l')

/-- Type quantifiers: k_n : Nat, hi : Int, lo : Int, l' : Int, k_n ≥ 0 ∧ (hi - lo + 1 + l') ≥ 0 -/
def subrange_zeros_concat (xs : (BitVec k_n)) (hi : Int) (lo : Int) (l' : Int) : (BitVec (hi - lo + 1 + l')) :=
  (slice_zeros_concat xs lo ((hi -i lo) +i 1) l')

/-- Type quantifiers: j' : Int, i' : Int, j : Int, i : Int, k_n : Nat, k_n ≥ 0 -/
def subrange_subrange_eq (xs : (BitVec k_n)) (i : Int) (j : Int) (ys : (BitVec k_n)) (i' : Int) (j' : Int) : Bool :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length ys)) j ((i -i j) +i 1))) >>> j)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) j' ((i' -i j') +i 1))) >>> j')
  (xs == ys)

/-- Type quantifiers: k_n : Nat, i : Int, j : Int, k_m : Nat, i' : Int, j' : Int, s : Nat, s ≥ 0 ∧ k_n ≥ 0 ∧ k_m ≥ 0 -/
def subrange_subrange_concat {s : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (ys : (BitVec k_m)) (i' : Int) (j' : Int) : (BitVec s) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  let ys := ((ys &&& (slice_mask (n := (Sail.BitVec.length ys)) j' ((i' -i j') +i 1))) >>> j')
  (((extzv (m := s) xs) <<< ((i' -i j') +i 1)) ||| (extzv (m := s) ys))

/-- Type quantifiers: shift : Int, j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (shift : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  ((extzv (m := m) xs) <<< shift)

/-- Type quantifiers: shift : Int, l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (shift : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  ((extzv (m := m) xs) <<< shift)

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def set_slice_zeros {n : _} (xs : (BitVec n)) (i : Int) (l : Int) : (BitVec n) :=
  let ys : (BitVec n) := (slice_mask (n := n) i l)
  (xs &&& (Complement.complement ys))

/-- Type quantifiers: lo : Int, hi : Int, n : Nat, n ≥ 0 -/
def set_subrange_zeros {n : _} (xs : (BitVec n)) (hi : Int) (lo : Int) : (BitVec n) :=
  (set_slice_zeros (n := n) xs lo ((hi -i lo) +i 1))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def zext_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) : (BitVec m) :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  (extzv (m := m) xs)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def zext_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) : (BitVec m) :=
  (zext_slice (m := m) xs j ((i -i j) +i 1))

/-- Type quantifiers: l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def sext_slice {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) : (BitVec m) :=
  let xs := (BitVec.sshiftRight ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) <<< (((Sail.BitVec.length xs) -i i) -i l)) ((Sail.BitVec.length xs) -i l))
  (extsv (m := m) xs)

/-- Type quantifiers: j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def sext_subrange {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) : (BitVec m) :=
  (sext_slice (m := m) xs j ((i -i j) +i 1))

/-- Type quantifiers: shift : Int, l : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_slice_signed {m : _} (xs : (BitVec k_n)) (i : Int) (l : Int) (shift : Int) : (BitVec m) :=
  ((sext_slice (m := m) xs i l) <<< shift)

/-- Type quantifiers: shift : Int, j : Int, i : Int, k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ 0 -/
def place_subrange_signed {m : _} (xs : (BitVec k_n)) (i : Int) (j : Int) (shift : Int) : (BitVec m) :=
  (place_slice_signed (m := m) xs j ((i -i j) +i 1) shift)

/-- Type quantifiers: i : Int, k_n : Nat, l : Nat, k_n ≥ 0 ∧ l ≥ 0 -/
def unsigned_slice (xs : (BitVec k_n)) (i : Int) (l : Nat) : Int :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) i l)) >>> i)
  (Nat.mod (BitVec.toNat xs) (pow2 l))

/-- Type quantifiers: k_n : Nat, i : Int, j : Int, k_n ≥ 0 ∧ (i - j) ≥ 0 -/
def unsigned_subrange (xs : (BitVec k_n)) (i : Int) (j : Int) : Int :=
  let xs := ((xs &&& (slice_mask (n := (Sail.BitVec.length xs)) j ((i -i j) +i 1))) >>> j)
  (Nat.mod (BitVec.toNat xs) (pow2 ((i -i j) +i 1)))

/-- Type quantifiers: m : Int, n : Nat, n ≥ 0 -/
def zext_ones {n : _} (m : Int) : (BitVec n) :=
  let v : (BitVec n) := (extsv (m := n) (1#1 : (BitVec 1)))
  (v >>> (n -i m))

/-- Type quantifiers: n : Nat, s1 : Nat, e1 : Nat, k_n2 : Nat, s2 : Nat, e2 : Nat, 0 ≤ e1 ∧ e1 ≤ s1 ∧ s1 < n ∧ 0 ≤ e2 ∧ e2 ≤ s2 ∧ s2 < k_n2 ∧ (s1 - e1) = (s2 - e2) -/
def vector_update_subrange_from_subrange {n : _} (v1 : (BitVec n)) (s1 : Nat) (e1 : Nat) (v2 : (BitVec k_n2)) (s2 : Nat) (e2 : Nat) : (BitVec n) :=
  let xs := ((v2 &&& (slice_mask (n := (Sail.BitVec.length v2)) e2 ((s2 -i e2) +i 1))) >>> e2)
  let xs := ((extzv (m := n) xs) <<< e1)
  let ys := (v1 &&& (Complement.complement (slice_mask (n := (Sail.BitVec.length xs)) e1 ((s1 -i e1) +i 1))))
  (xs ||| ys)

/-- Type quantifiers: i : Int, n1 : Nat, s1 : Nat, e1 : Nat, s2 : Nat, e2 : Nat, 0 ≤ e1 ∧ e1 ≤ s1 ∧ s1 < n1 ∧ 0 ≤ e2 ∧ e2 ≤ s2 ∧ (s1 - e1) = (s2 - e2) -/
def vector_update_subrange_from_integer_subrange {n1 : _} (v1 : (BitVec n1)) (s1 : Nat) (e1 : Nat) (i : Int) (s2 : Nat) (e2 : Nat) : (BitVec n1) :=
  let v2 : (BitVec n1) := (get_slice_int n1 i e2)
  (vector_update_subrange_from_subrange (n := n1) v1 s1 e1 v2 (s2 -i e2) 0)

/-- Type quantifiers: k_a : Type, k_b : Type -/
def is_ok (r : (Result k_a k_b)) : Bool :=
  match r with
  | .Ok _ => true
  | .Err _ => false

/-- Type quantifiers: k_a : Type, k_b : Type -/
def is_err (r : (Result k_a k_b)) : Bool :=
  match r with
  | .Ok _ => false
  | .Err _ => true

/-- Type quantifiers: k_a : Type, k_b : Type -/
def ok_option (r : (Result k_a k_b)) : (Option k_a) :=
  match r with
  | .Ok x => (some x)
  | .Err _ => none

/-- Type quantifiers: k_a : Type, k_b : Type -/
def err_option (r : (Result k_a k_b)) : (Option k_b) :=
  match r with
  | .Ok _ => none
  | .Err err => (some err)

/-- Type quantifiers: k_a : Type, k_b : Type -/
def unwrap_or (r : (Result k_a k_b)) (y : k_a) : k_a :=
  match r with
  | .Ok x => x
  | .Err _ => y

/-- Type quantifiers: k_n : Nat, k_n > 0 -/
def sail_instr_announce (x_0 : (BitVec k_n)) : Unit :=
  ()

/-- Type quantifiers: x_0 : Nat, List.elem x_0 [32, 64] -/
def sail_branch_announce (x_0 : Nat) (x_1 : (BitVec x_0)) : Unit :=
  ()

def sail_reset_registers (_ : Unit) : Unit :=
  ()

def sail_synchronize_registers (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_a : Type -/
def sail_mark_register (x_0 : (RegisterRef k_a)) (x_1 : String) : Unit :=
  ()

/-- Type quantifiers: k_a : Type, k_b : Type -/
def sail_mark_register_pair (x_0 : (RegisterRef k_a)) (x_1 : (RegisterRef k_b)) (x_2 : String) : Unit :=
  ()

/-- Type quantifiers: k_a : Type -/
def sail_ignore_write_to (reg : (RegisterRef k_a)) : Unit :=
  (sail_mark_register reg "ignore_write")

/-- Type quantifiers: k_a : Type -/
def sail_pick_dependency (reg : (RegisterRef k_a)) : Unit :=
  (sail_mark_register reg "pick")

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def __monomorphize (bv : (BitVec k_n)) : (BitVec k_n) :=
  bv

/-- Type quantifiers: n : Int -/
def __monomorphize_int (n : Int) : Int :=
  n

/-- Type quantifiers: k_b : Bool -/
def __monomorphize_bool (b : Bool) : Bool :=
  b

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_read_request_is_exclusive (request : (Mem_read_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_explicit eak =>
    (match eak.variety with
    | .AV_exclusive => true
    | _ => false)
  | _ => false

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_read_request_is_ifetch (request : (Mem_read_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_ifetch () => true
  | _ => false

def __monomorphize_reads : Bool := false

def __monomorphize_writes : Bool := false

/-- Type quantifiers: k_n : Nat, k_vasize : Nat, k_pa : Type, k_translation_summary : Type, k_arch_ak : Type, k_n > 0 ∧ k_vasize > 0 -/
def mem_write_request_is_exclusive (request : (Mem_write_request k_n k_vasize k_pa k_translation_summary k_arch_ak)) : Bool :=
  match request.access_kind with
  | .AK_explicit eak =>
    (match eak.variety with
    | .AV_exclusive => true
    | _ => false)
  | _ => false

/-- Type quantifiers: x_0 : Nat, List.elem x_0 [32, 64] -/
def sail_address_announce (x_0 : Nat) (x_1 : (BitVec x_0)) : Unit :=
  ()

/-- Type quantifiers: k_ex3837057_ : Bool, k_ex3837056_ : Bool -/
def implies (p : Bool) (q : Bool) : Bool :=
  ((! p) || q)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def Ones {n : _} : (BitVec n) :=
  (sail_ones n)

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def Zeros {n : _} : (BitVec n) :=
  (BitVec.zero n)

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def IsZero (x : (BitVec k_n)) : Bool :=
  (x == (BitVec.zero (Sail.BitVec.length x)))

/-- Type quantifiers: k_n : Nat, k_n ≥ 0 -/
def IsOnes (x : (BitVec k_n)) : Bool :=
  (x == (sail_ones (Sail.BitVec.length x)))

def Bit (b : (BitVec 1)) : (BitVec 1) :=
  (BitVec.access b 0)

/-- Type quantifiers: k_n : Nat, m : Nat, k_n ≥ 0 ∧ m ≥ k_n -/
def ZeroExtend1 {m : _} (x : (BitVec k_n)) : (BitVec m) :=
  (Sail.BitVec.zeroExtend x m)

/-- Type quantifiers: l : Int, i : Int, n : Nat, n ≥ 0 -/
def Slice_int (i : Int) (l : Int) (n : Nat) : (BitVec n) :=
  (get_slice_int n i l)

/-- Type quantifiers: y : Int, x : Int -/
def Align_int (x : Int) (y : Int) : Int :=
  ((fdiv_int x y) *i y)

/-- Type quantifiers: y : Int, k_n : Nat, k_n ≥ 0 -/
def Align_bits (x : (BitVec k_n)) (y : Int) : (BitVec k_n) :=
  (Slice_int (Align_int (BitVec.toNatInt x) y) 0 (Sail.BitVec.length x))

def RoundTowardsZero (r : real) : Int :=
  if ((lt_real r (to_real 0)) : Bool)
  then (round_up r)
  else (round_down r)

def IsSEE (ex : exception) : Bool :=
  match ex with
  | .Error_See _ => true
  | _ => false

def ReservedEncoding (_ : Unit) : SailM Unit := do
  sailThrow ((Error_ReservedEncoding ()))

/-- Type quantifiers: n : Nat, n ≥ 0 -/
def __UNKNOWN_bits (n : Nat) : SailM (BitVec n) := do
  (undefined_bitvector n)

def __UNKNOWN_integer (_ : Unit) : SailM Int := do
  (undefined_int ())

def __UNKNOWN_boolean (_ : Unit) : SailM Bool := do
  (undefined_bool ())

def __UNKNOWN_bit (_ : Unit) : SailM (BitVec 1) := do
  (undefined_bitvector 1)

def EndOfInstruction (_ : Unit) : SailM Unit := do
  sailThrow ((Error_ExceptionTaken ()))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def IsZeroBit (x : (BitVec k_N)) : (BitVec 1) :=
  if ((IsZero x) : Bool)
  then 1#1
  else 0#1

/-- Type quantifiers: k_N : Nat, shift : Nat, k_N > 0 ∧ shift ≥ 0 -/
def ROR (x : (BitVec k_N)) (shift : Nat) : (BitVec k_N) :=
  if ((shift == 0) : Bool)
  then x
  else
    (let m := (Nat.mod shift (Sail.BitVec.length x))
    ((x >>> m) ||| (x <<< ((Sail.BitVec.length x) -i m))))

/-- Type quantifiers: k_M : Nat, N : Nat, k_is_unsigned : Bool, k_M ≥ 0 ∧ N ≥ 0 -/
def Extend (x : (BitVec k_M)) (N : Nat) (is_unsigned : Bool) : SailM (BitVec N) := do
  (if (is_unsigned : Bool)
  then
    (do sail_assert (((Sail.BitVec.length x) ≥b 0) && (N ≥b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/builtins.sail:121.47-121.48"
        (pure (Sail.BitVec.zeroExtend x N)))
  else
    (do sail_assert (((Sail.BitVec.length x) >b 0) && (N ≥b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/builtins.sail:124.46-124.47"
        (pure (sign_extend x N))))

/-- Type quantifiers: k_N : Nat, k_is_unsigned : Bool, k_N ≥ 0 -/
def asl_Int (x : (BitVec k_N)) (is_unsigned : Bool) : SailM Int := do
  let result ← (( do
    (if (is_unsigned : Bool)
    then (do (pure (BitVec.toNat x)))
    else
      (do sail_assert ((Sail.BitVec.length x) >b 0) "sail-arm/arm-v9.4-a/src/builtins.sail:134.33-134.34"
          (pure (BitVec.toInt x)))) ) : SailM Int )
  (pure result)

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def LowestSetBit (x : (BitVec k_N)) : Int := ExceptM.run do
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length x) -i 1)
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
      then (do throw (i : Int))
      else (do (pure ())))
  (pure loop_vars)
  (pure (Sail.BitVec.length x))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def HighestSetBit (x : (BitVec k_N)) : Int := ExceptM.run do
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length x) -i 1)
  let mut loop_vars := ()
  for i in [loop_i_upper:loop_i_lower:-1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
      then (do throw (i : Int))
      else (do (pure ())))
  (pure loop_vars)
  (pure (Neg.neg 1))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def BitCount (x : (BitVec k_N)) : Int := Id.run do
  let result : Int := 0
  let result ← (( do
    let loop_i_lower := 0
    let loop_i_upper := ((Sail.BitVec.length x) -i 1)
    let mut loop_vars := result
    for i in [loop_i_lower:loop_i_upper:1]i do
      let result := loop_vars
      loop_vars :=
        if ((((BitVec.access x i) : BitVec 1) == 1#1) : Bool)
        then (result +i 1)
        else result
    (pure loop_vars) ) : Id Int )
  let result := result
  (pure result)

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def CountLeadingZeroBits (x : (BitVec k_N)) : Int :=
  ((Sail.BitVec.length x) -i ((HighestSetBit x) +i 1))

/-- Type quantifiers: k_N : Nat, 1 ≤ (k_N - 1) -/
def CountLeadingSignBits (x : (BitVec k_N)) : Int :=
  (CountLeadingZeroBits ((Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 1) 1) ^^^ (Sail.BitVec.extractLsb x ((Sail.BitVec.length x) -i 2) 0)))

/-- Type quantifiers: k_N : Nat, e : Int, size : Nat, k_N ≥ 0 ∧ size ≥ 0 ∧ (e * size) ≤ (e * size + size - 1) ∨ (not (e ≥ 0 ∧ ((e + 1) * size) ≤ k_N)) -/
def Elem_read (vector_name : (BitVec k_N)) (e : Int) (size : Nat) : SailM (BitVec size) := do
  sail_assert ((e ≥b 0) && (((e +i 1) *i size) ≤b (Sail.BitVec.length vector_name))) "sail-arm/arm-v9.4-a/src/builtins.sail:195.40-195.41"
  (pure (Sail.BitVec.extractLsb vector_name (((e *i size) +i size) -i 1) (e *i size)))

/-- Type quantifiers: k_N : Nat, e : Int, size : Nat, k_N ≥ 0 ∧ size ≥ 0 ∧ (e * size) ≤ ((e + 1) * size - 1) ∨ (not (e ≥ 0 ∧ ((e + 1) * size) ≤ k_N)) -/
def Elem_set (vector_name__arg : (BitVec k_N)) (e : Int) (size : Nat) (value_name : (BitVec size)) : SailM (BitVec k_N) := do
  let vector_name : (BitVec k_N) := vector_name__arg
  sail_assert ((e ≥b 0) && (((e +i 1) *i size) ≤b (Sail.BitVec.length vector_name__arg))) "sail-arm/arm-v9.4-a/src/builtins.sail:205.40-205.41"
  (pure (Sail.BitVec.updateSubrange vector_name (((e +i 1) *i size) -i 1) (e *i size) value_name))

def undefined_Configuration_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_Configuration_Type_CFGEND (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_Configuration_Type_ExceptInit (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _update_EDSCR_Type_RW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 10 x)

def _get_HCR_EL2_Type_RW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCR_EL3_Type_RW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def undefined_DormantCtl_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def num_of_Feature (arg_ : Feature) : Int :=
  match arg_ with
  | .FEAT_AA32EL0 => 0
  | .FEAT_AA32EL1 => 1
  | .FEAT_AA32EL2 => 2
  | .FEAT_AA32EL3 => 3
  | .FEAT_AA64EL0 => 4
  | .FEAT_AA64EL1 => 5
  | .FEAT_AA64EL2 => 6
  | .FEAT_AA64EL3 => 7
  | .FEAT_EL0 => 8
  | .FEAT_EL1 => 9
  | .FEAT_EL2 => 10
  | .FEAT_EL3 => 11
  | .FEAT_AES => 12
  | .FEAT_AdvSIMD => 13
  | .FEAT_CSV2_1p1 => 14
  | .FEAT_CSV2_1p2 => 15
  | .FEAT_CSV2_2 => 16
  | .FEAT_CSV2_3 => 17
  | .FEAT_DoubleLock => 18
  | .FEAT_ETMv4 => 19
  | .FEAT_ETMv4p1 => 20
  | .FEAT_ETMv4p2 => 21
  | .FEAT_ETMv4p3 => 22
  | .FEAT_ETMv4p4 => 23
  | .FEAT_ETMv4p5 => 24
  | .FEAT_ETMv4p6 => 25
  | .FEAT_ETS2 => 26
  | .FEAT_FP => 27
  | .FEAT_GICv3 => 28
  | .FEAT_GICv3_LEGACY => 29
  | .FEAT_GICv3_TDIR => 30
  | .FEAT_GICv3p1 => 31
  | .FEAT_GICv4 => 32
  | .FEAT_GICv4p1 => 33
  | .FEAT_IVIPT => 34
  | .FEAT_PCSRv8 => 35
  | .FEAT_PMULL => 36
  | .FEAT_PMUv3 => 37
  | .FEAT_PMUv3_EXT => 38
  | .FEAT_PMUv3_EXT32 => 39
  | .FEAT_SHA1 => 40
  | .FEAT_SHA256 => 41
  | .FEAT_TRC_EXT => 42
  | .FEAT_TRC_SR => 43
  | .FEAT_nTLBPA => 44
  | .FEAT_CRC32 => 45
  | .FEAT_Debugv8p1 => 46
  | .FEAT_HAFDBS => 47
  | .FEAT_HPDS => 48
  | .FEAT_LOR => 49
  | .FEAT_LSE => 50
  | .FEAT_PAN => 51
  | .FEAT_PMUv3p1 => 52
  | .FEAT_RDM => 53
  | .FEAT_VHE => 54
  | .FEAT_VMID16 => 55
  | .FEAT_AA32BF16 => 56
  | .FEAT_AA32HPD => 57
  | .FEAT_AA32I8MM => 58
  | .FEAT_ASMv8p2 => 59
  | .FEAT_DPB => 60
  | .FEAT_Debugv8p2 => 61
  | .FEAT_EDHSR => 62
  | .FEAT_F32MM => 63
  | .FEAT_F64MM => 64
  | .FEAT_FP16 => 65
  | .FEAT_HPDS2 => 66
  | .FEAT_I8MM => 67
  | .FEAT_IESB => 68
  | .FEAT_LPA => 69
  | .FEAT_LSMAOC => 70
  | .FEAT_LVA => 71
  | .FEAT_MPAM => 72
  | .FEAT_PAN2 => 73
  | .FEAT_PCSRv8p2 => 74
  | .FEAT_RAS => 75
  | .FEAT_SHA3 => 76
  | .FEAT_SHA512 => 77
  | .FEAT_SM3 => 78
  | .FEAT_SM4 => 79
  | .FEAT_SPE => 80
  | .FEAT_SVE => 81
  | .FEAT_TTCNP => 82
  | .FEAT_UAO => 83
  | .FEAT_VPIPT => 84
  | .FEAT_XNX => 85
  | .FEAT_CCIDX => 86
  | .FEAT_CONSTPACFIELD => 87
  | .FEAT_EPAC => 88
  | .FEAT_FCMA => 89
  | .FEAT_FPAC => 90
  | .FEAT_FPACCOMBINE => 91
  | .FEAT_JSCVT => 92
  | .FEAT_LRCPC => 93
  | .FEAT_NV => 94
  | .FEAT_PACIMP => 95
  | .FEAT_PACQARMA3 => 96
  | .FEAT_PACQARMA5 => 97
  | .FEAT_PAuth => 98
  | .FEAT_SPEv1p1 => 99
  | .FEAT_AMUv1 => 100
  | .FEAT_BBM => 101
  | .FEAT_CNTSC => 102
  | .FEAT_DIT => 103
  | .FEAT_Debugv8p4 => 104
  | .FEAT_DotProd => 105
  | .FEAT_DoubleFault => 106
  | .FEAT_FHM => 107
  | .FEAT_FlagM => 108
  | .FEAT_IDST => 109
  | .FEAT_LRCPC2 => 110
  | .FEAT_LSE2 => 111
  | .FEAT_NV2 => 112
  | .FEAT_PMUv3p4 => 113
  | .FEAT_RASSAv1p1 => 114
  | .FEAT_RASv1p1 => 115
  | .FEAT_S2FWB => 116
  | .FEAT_SEL2 => 117
  | .FEAT_TLBIOS => 118
  | .FEAT_TLBIRANGE => 119
  | .FEAT_TRF => 120
  | .FEAT_TTL => 121
  | .FEAT_TTST => 122
  | .FEAT_BTI => 123
  | .FEAT_CSV2 => 124
  | .FEAT_CSV3 => 125
  | .FEAT_DPB2 => 126
  | .FEAT_E0PD => 127
  | .FEAT_EVT => 128
  | .FEAT_ExS => 129
  | .FEAT_FRINTTS => 130
  | .FEAT_FlagM2 => 131
  | .FEAT_GTG => 132
  | .FEAT_MTE => 133
  | .FEAT_MTE2 => 134
  | .FEAT_PMUv3p5 => 135
  | .FEAT_RNG => 136
  | .FEAT_RNG_TRAP => 137
  | .FEAT_SB => 138
  | .FEAT_SPECRES => 139
  | .FEAT_SSBS => 140
  | .FEAT_SSBS2 => 141
  | .FEAT_AMUv1p1 => 142
  | .FEAT_BF16 => 143
  | .FEAT_DGH => 144
  | .FEAT_ECV => 145
  | .FEAT_FGT => 146
  | .FEAT_HPMN0 => 147
  | .FEAT_MPAMv0p1 => 148
  | .FEAT_MPAMv1p1 => 149
  | .FEAT_MTPMU => 150
  | .FEAT_PAuth2 => 151
  | .FEAT_TWED => 152
  | .FEAT_AFP => 153
  | .FEAT_EBF16 => 154
  | .FEAT_HCX => 155
  | .FEAT_LPA2 => 156
  | .FEAT_LS64 => 157
  | .FEAT_LS64_ACCDATA => 158
  | .FEAT_LS64_V => 159
  | .FEAT_MTE3 => 160
  | .FEAT_PAN3 => 161
  | .FEAT_PMUv3p7 => 162
  | .FEAT_RPRES => 163
  | .FEAT_SPEv1p2 => 164
  | .FEAT_WFxT => 165
  | .FEAT_XS => 166
  | .FEAT_CMOW => 167
  | .FEAT_Debugv8p8 => 168
  | .FEAT_GICv3_NMI => 169
  | .FEAT_HBC => 170
  | .FEAT_MOPS => 171
  | .FEAT_NMI => 172
  | .FEAT_PMUv3_EXT64 => 173
  | .FEAT_PMUv3_TH => 174
  | .FEAT_PMUv3p8 => 175
  | .FEAT_SCTLR2 => 176
  | .FEAT_SPEv1p3 => 177
  | .FEAT_TCR2 => 178
  | .FEAT_TIDCP1 => 179
  | .FEAT_ADERR => 180
  | .FEAT_AIE => 181
  | .FEAT_ANERR => 182
  | .FEAT_CLRBHB => 183
  | .FEAT_CSSC => 184
  | .FEAT_Debugv8p9 => 185
  | .FEAT_DoubleFault2 => 186
  | .FEAT_ECBHB => 187
  | .FEAT_FGT2 => 188
  | .FEAT_HAFT => 189
  | .FEAT_LRCPC3 => 190
  | .FEAT_MTE4 => 191
  | .FEAT_MTE_ASYM_FAULT => 192
  | .FEAT_MTE_ASYNC => 193
  | .FEAT_MTE_CANONICAL_TAGS => 194
  | .FEAT_MTE_NO_ADDRESS_TAGS => 195
  | .FEAT_MTE_PERM => 196
  | .FEAT_MTE_STORE_ONLY => 197
  | .FEAT_MTE_TAGGED_FAR => 198
  | .FEAT_PCSRv8p9 => 199
  | .FEAT_PFAR => 200
  | .FEAT_PMUv3_EDGE => 201
  | .FEAT_PMUv3_ICNTR => 202
  | .FEAT_PMUv3_SS => 203
  | .FEAT_PMUv3p9 => 204
  | .FEAT_PRFMSLC => 205
  | .FEAT_RASSAv2 => 206
  | .FEAT_RASv2 => 207
  | .FEAT_RPRFM => 208
  | .FEAT_S1PIE => 209
  | .FEAT_S1POE => 210
  | .FEAT_S2PIE => 211
  | .FEAT_S2POE => 212
  | .FEAT_SPECRES2 => 213
  | .FEAT_SPE_CRR => 214
  | .FEAT_SPE_FDS => 215
  | .FEAT_SPEv1p4 => 216
  | .FEAT_SPMU => 217
  | .FEAT_THE => 218
  | .FEAT_DoPD => 219
  | .FEAT_ETE => 220
  | .FEAT_SVE2 => 221
  | .FEAT_SVE_AES => 222
  | .FEAT_SVE_BitPerm => 223
  | .FEAT_SVE_PMULL128 => 224
  | .FEAT_SVE_SHA3 => 225
  | .FEAT_SVE_SM4 => 226
  | .FEAT_TME => 227
  | .FEAT_TRBE => 228
  | .FEAT_ETEv1p1 => 229
  | .FEAT_BRBE => 230
  | .FEAT_ETEv1p2 => 231
  | .FEAT_RME => 232
  | .FEAT_SME => 233
  | .FEAT_SME_F64F64 => 234
  | .FEAT_SME_FA64 => 235
  | .FEAT_SME_I16I64 => 236
  | .FEAT_BRBEv1p1 => 237
  | .FEAT_MEC => 238
  | .FEAT_SME2 => 239
  | .FEAT_ABLE => 240
  | .FEAT_CHK => 241
  | .FEAT_D128 => 242
  | .FEAT_EBEP => 243
  | .FEAT_ETEv1p3 => 244
  | .FEAT_GCS => 245
  | .FEAT_ITE => 246
  | .FEAT_LSE128 => 247
  | .FEAT_LVA3 => 248
  | .FEAT_SEBEP => 249
  | .FEAT_SME2p1 => 250
  | .FEAT_SME_F16F16 => 251
  | .FEAT_SVE2p1 => 252
  | .FEAT_SVE_B16B16 => 253
  | .FEAT_SYSINSTR128 => 254
  | .FEAT_SYSREG128 => 255
  | .FEAT_TRBE_EXT => 256
  | .FEAT_TRBE_MPAM => 257

def num_of_ArchVersion (arg_ : ArchVersion) : Int :=
  match arg_ with
  | .v8Ap0 => 0
  | .v8Ap1 => 1
  | .v8Ap2 => 2
  | .v8Ap3 => 3
  | .v8Ap4 => 4
  | .v8Ap5 => 5
  | .v8Ap6 => 6
  | .v8Ap7 => 7
  | .v8Ap8 => 8
  | .v8Ap9 => 9
  | .v9Ap0 => 10
  | .v9Ap1 => 11
  | .v9Ap2 => 12
  | .v9Ap3 => 13
  | .v9Ap4 => 14

def InitFeatureImpl (_ : Unit) : SailM Unit := do
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL0) (← readReg FEAT_AA32EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL1) (← readReg FEAT_AA32EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL2) (← readReg FEAT_AA32EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32EL3) (← readReg FEAT_AA32EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL0) (← readReg FEAT_AA64EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL1) (← readReg FEAT_AA64EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL2) (← readReg FEAT_AA64EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA64EL3) (← readReg FEAT_AA64EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL0) (← readReg FEAT_EL0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL1) (← readReg FEAT_EL1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL2) (← readReg FEAT_EL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EL3) (← readReg FEAT_EL3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AES) (← readReg FEAT_AES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AdvSIMD) (← readReg FEAT_AdvSIMD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_1p1) (← readReg FEAT_CSV2_1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_1p2) (← readReg FEAT_CSV2_1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_2) (← readReg FEAT_CSV2_2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2_3) (← readReg FEAT_CSV2_3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleLock) (← readReg FEAT_DoubleLock_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4) (← readReg FEAT_ETMv4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p1) (← readReg FEAT_ETMv4p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p2) (← readReg FEAT_ETMv4p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p3) (← readReg FEAT_ETMv4p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p4) (← readReg FEAT_ETMv4p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p5) (← readReg FEAT_ETMv4p5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETMv4p6) (← readReg FEAT_ETMv4p6_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETS2) (← readReg FEAT_ETS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FP) (← readReg FEAT_FP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3) (← readReg FEAT_GICv3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_LEGACY) (← readReg FEAT_GICv3_LEGACY_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_TDIR) (← readReg FEAT_GICv3_TDIR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3p1) (← readReg FEAT_GICv3p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv4) (← readReg FEAT_GICv4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv4p1) (← readReg FEAT_GICv4p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IVIPT) (← readReg FEAT_IVIPT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8) (← readReg FEAT_PCSRv8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMULL) (← readReg FEAT_PMULL_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3) (← readReg FEAT_PMUv3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT) (← readReg FEAT_PMUv3_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT32) (← readReg FEAT_PMUv3_EXT32_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA1) (← readReg FEAT_SHA1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA256) (← readReg FEAT_SHA256_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRC_EXT) (← readReg FEAT_TRC_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRC_SR) (← readReg FEAT_TRC_SR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_nTLBPA) (← readReg FEAT_nTLBPA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CRC32) (← readReg FEAT_CRC32_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p1) (← readReg FEAT_Debugv8p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HAFDBS) (← readReg FEAT_HAFDBS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPDS) (← readReg FEAT_HPDS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LOR) (← readReg FEAT_LOR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE) (← readReg FEAT_LSE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN) (← readReg FEAT_PAN_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p1) (← readReg FEAT_PMUv3p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RDM) (← readReg FEAT_RDM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VHE) (← readReg FEAT_VHE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VMID16) (← readReg FEAT_VMID16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32BF16) (← readReg FEAT_AA32BF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32HPD) (← readReg FEAT_AA32HPD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AA32I8MM) (← readReg FEAT_AA32I8MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ASMv8p2) (← readReg FEAT_ASMv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DPB) (← readReg FEAT_DPB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p2) (← readReg FEAT_Debugv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EDHSR) (← readReg FEAT_EDHSR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_F32MM) (← readReg FEAT_F32MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_F64MM) (← readReg FEAT_F64MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FP16) (← readReg FEAT_FP16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPDS2) (← readReg FEAT_HPDS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_I8MM) (← readReg FEAT_I8MM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IESB) (← readReg FEAT_IESB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LPA) (← readReg FEAT_LPA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSMAOC) (← readReg FEAT_LSMAOC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LVA) (← readReg FEAT_LVA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAM) (← readReg FEAT_MPAM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN2) (← readReg FEAT_PAN2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8p2) (← readReg FEAT_PCSRv8p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RAS) (← readReg FEAT_RAS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA3) (← readReg FEAT_SHA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SHA512) (← readReg FEAT_SHA512_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SM3) (← readReg FEAT_SM3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SM4) (← readReg FEAT_SM4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE) (← readReg FEAT_SPE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE) (← readReg FEAT_SVE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTCNP) (← readReg FEAT_TTCNP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_UAO) (← readReg FEAT_UAO_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_VPIPT) (← readReg FEAT_VPIPT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_XNX) (← readReg FEAT_XNX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CCIDX) (← readReg FEAT_CCIDX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CONSTPACFIELD) (← readReg FEAT_CONSTPACFIELD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EPAC) (← readReg FEAT_EPAC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FCMA) (← readReg FEAT_FCMA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FPAC) (← readReg FEAT_FPAC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FPACCOMBINE) (← readReg FEAT_FPACCOMBINE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_JSCVT) (← readReg FEAT_JSCVT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC) (← readReg FEAT_LRCPC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NV) (← readReg FEAT_NV_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACIMP) (← readReg FEAT_PACIMP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACQARMA3) (← readReg FEAT_PACQARMA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PACQARMA5) (← readReg FEAT_PACQARMA5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAuth) (← readReg FEAT_PAuth_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p1) (← readReg FEAT_SPEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AMUv1) (← readReg FEAT_AMUv1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BBM) (← readReg FEAT_BBM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CNTSC) (← readReg FEAT_CNTSC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DIT) (← readReg FEAT_DIT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p4) (← readReg FEAT_Debugv8p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DotProd) (← readReg FEAT_DotProd_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleFault) (← readReg FEAT_DoubleFault_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FHM) (← readReg FEAT_FHM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FlagM) (← readReg FEAT_FlagM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_IDST) (← readReg FEAT_IDST_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC2) (← readReg FEAT_LRCPC2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE2) (← readReg FEAT_LSE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NV2) (← readReg FEAT_NV2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p4) (← readReg FEAT_PMUv3p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASSAv1p1) (← readReg FEAT_RASSAv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASv1p1) (← readReg FEAT_RASv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2FWB) (← readReg FEAT_S2FWB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SEL2) (← readReg FEAT_SEL2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TLBIOS) (← readReg FEAT_TLBIOS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TLBIRANGE) (← readReg FEAT_TLBIRANGE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRF) (← readReg FEAT_TRF_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTL) (← readReg FEAT_TTL_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TTST) (← readReg FEAT_TTST_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BTI) (← readReg FEAT_BTI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV2) (← readReg FEAT_CSV2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSV3) (← readReg FEAT_CSV3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DPB2) (← readReg FEAT_DPB2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_E0PD) (← readReg FEAT_E0PD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EVT) (← readReg FEAT_EVT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ExS) (← readReg FEAT_ExS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FRINTTS) (← readReg FEAT_FRINTTS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FlagM2) (← readReg FEAT_FlagM2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GTG) (← readReg FEAT_GTG_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE) (← readReg FEAT_MTE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE2) (← readReg FEAT_MTE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p5) (← readReg FEAT_PMUv3p5_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RNG) (← readReg FEAT_RNG_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RNG_TRAP) (← readReg FEAT_RNG_TRAP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SB) (← readReg FEAT_SB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPECRES) (← readReg FEAT_SPECRES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SSBS) (← readReg FEAT_SSBS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SSBS2) (← readReg FEAT_SSBS2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AMUv1p1) (← readReg FEAT_AMUv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BF16) (← readReg FEAT_BF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DGH) (← readReg FEAT_DGH_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ECV) (← readReg FEAT_ECV_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FGT) (← readReg FEAT_FGT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HPMN0) (← readReg FEAT_HPMN0_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAMv0p1) (← readReg FEAT_MPAMv0p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MPAMv1p1) (← readReg FEAT_MPAMv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTPMU) (← readReg FEAT_MTPMU_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAuth2) (← readReg FEAT_PAuth2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TWED) (← readReg FEAT_TWED_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AFP) (← readReg FEAT_AFP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EBF16) (← readReg FEAT_EBF16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HCX) (← readReg FEAT_HCX_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LPA2) (← readReg FEAT_LPA2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64) (← readReg FEAT_LS64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64_ACCDATA) (← readReg FEAT_LS64_ACCDATA_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LS64_V) (← readReg FEAT_LS64_V_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE3) (← readReg FEAT_MTE3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PAN3) (← readReg FEAT_PAN3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p7) (← readReg FEAT_PMUv3p7_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RPRES) (← readReg FEAT_RPRES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p2) (← readReg FEAT_SPEv1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_WFxT) (← readReg FEAT_WFxT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_XS) (← readReg FEAT_XS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CMOW) (← readReg FEAT_CMOW_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p8) (← readReg FEAT_Debugv8p8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GICv3_NMI) (← readReg FEAT_GICv3_NMI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HBC) (← readReg FEAT_HBC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MOPS) (← readReg FEAT_MOPS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_NMI) (← readReg FEAT_NMI_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EXT64) (← readReg FEAT_PMUv3_EXT64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_TH) (← readReg FEAT_PMUv3_TH_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p8) (← readReg FEAT_PMUv3p8_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SCTLR2) (← readReg FEAT_SCTLR2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p3) (← readReg FEAT_SPEv1p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TCR2) (← readReg FEAT_TCR2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TIDCP1) (← readReg FEAT_TIDCP1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ADERR) (← readReg FEAT_ADERR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_AIE) (← readReg FEAT_AIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ANERR) (← readReg FEAT_ANERR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CLRBHB) (← readReg FEAT_CLRBHB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CSSC) (← readReg FEAT_CSSC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_Debugv8p9) (← readReg FEAT_Debugv8p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoubleFault2) (← readReg FEAT_DoubleFault2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ECBHB) (← readReg FEAT_ECBHB_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_FGT2) (← readReg FEAT_FGT2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_HAFT) (← readReg FEAT_HAFT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LRCPC3) (← readReg FEAT_LRCPC3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE4) (← readReg FEAT_MTE4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_ASYM_FAULT) (← readReg FEAT_MTE_ASYM_FAULT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_ASYNC) (← readReg FEAT_MTE_ASYNC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_CANONICAL_TAGS) (← readReg FEAT_MTE_CANONICAL_TAGS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_NO_ADDRESS_TAGS) (← readReg FEAT_MTE_NO_ADDRESS_TAGS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_PERM) (← readReg FEAT_MTE_PERM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_STORE_ONLY) (← readReg FEAT_MTE_STORE_ONLY_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MTE_TAGGED_FAR) (← readReg FEAT_MTE_TAGGED_FAR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PCSRv8p9) (← readReg FEAT_PCSRv8p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PFAR) (← readReg FEAT_PFAR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_EDGE) (← readReg FEAT_PMUv3_EDGE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_ICNTR) (← readReg FEAT_PMUv3_ICNTR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3_SS) (← readReg FEAT_PMUv3_SS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PMUv3p9) (← readReg FEAT_PMUv3p9_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_PRFMSLC) (← readReg FEAT_PRFMSLC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASSAv2) (← readReg FEAT_RASSAv2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RASv2) (← readReg FEAT_RASv2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RPRFM) (← readReg FEAT_RPRFM_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S1PIE) (← readReg FEAT_S1PIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S1POE) (← readReg FEAT_S1POE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2PIE) (← readReg FEAT_S2PIE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_S2POE) (← readReg FEAT_S2POE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPECRES2) (← readReg FEAT_SPECRES2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE_CRR) (← readReg FEAT_SPE_CRR_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPE_FDS) (← readReg FEAT_SPE_FDS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPEv1p4) (← readReg FEAT_SPEv1p4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SPMU) (← readReg FEAT_SPMU_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_THE) (← readReg FEAT_THE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_DoPD) (← readReg FEAT_DoPD_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETE) (← readReg FEAT_ETE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE2) (← readReg FEAT_SVE2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_AES) (← readReg FEAT_SVE_AES_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_BitPerm) (← readReg FEAT_SVE_BitPerm_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_PMULL128) (← readReg FEAT_SVE_PMULL128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_SHA3) (← readReg FEAT_SVE_SHA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_SM4) (← readReg FEAT_SVE_SM4_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TME) (← readReg FEAT_TME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE) (← readReg FEAT_TRBE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p1) (← readReg FEAT_ETEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BRBE) (← readReg FEAT_BRBE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p2) (← readReg FEAT_ETEv1p2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_RME) (← readReg FEAT_RME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME) (← readReg FEAT_SME_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_F64F64) (← readReg FEAT_SME_F64F64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_FA64) (← readReg FEAT_SME_FA64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_I16I64) (← readReg FEAT_SME_I16I64_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_BRBEv1p1) (← readReg FEAT_BRBEv1p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_MEC) (← readReg FEAT_MEC_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME2) (← readReg FEAT_SME2_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ABLE) (← readReg FEAT_ABLE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_CHK) (← readReg FEAT_CHK_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_D128) (← readReg FEAT_D128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_EBEP) (← readReg FEAT_EBEP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ETEv1p3) (← readReg FEAT_ETEv1p3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_GCS) (← readReg FEAT_GCS_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_ITE) (← readReg FEAT_ITE_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LSE128) (← readReg FEAT_LSE128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_LVA3) (← readReg FEAT_LVA3_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SEBEP) (← readReg FEAT_SEBEP_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME2p1) (← readReg FEAT_SME2p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SME_F16F16) (← readReg FEAT_SME_F16F16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE2p1) (← readReg FEAT_SVE2p1_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SVE_B16B16) (← readReg FEAT_SVE_B16B16_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SYSINSTR128) (← readReg FEAT_SYSINSTR128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_SYSREG128) (← readReg FEAT_SYSREG128_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE_EXT) (← readReg FEAT_TRBE_EXT_IMPLEMENTED))
  writeReg FeatureImpl (vectorUpdate (← readReg FeatureImpl) (num_of_Feature FEAT_TRBE_MPAM) (← readReg FEAT_TRBE_MPAM_IMPLEMENTED))

def InitVariantImplemented (_ : Unit) : SailM Unit := do
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap0) (← readReg v8Ap0_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap1) (← readReg v8Ap1_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap2) (← readReg v8Ap2_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap3) (← readReg v8Ap3_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap4) (← readReg v8Ap4_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap5) (← readReg v8Ap5_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap6) (← readReg v8Ap6_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap7) (← readReg v8Ap7_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap8) (← readReg v8Ap8_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v8Ap9) (← readReg v8Ap9_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap0) (← readReg v9Ap0_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap1) (← readReg v9Ap1_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap2) (← readReg v9Ap2_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap3) (← readReg v9Ap3_IMPLEMENTED))
  writeReg VariantImplemented (vectorUpdate (← readReg VariantImplemented) (num_of_ArchVersion v9Ap4) (← readReg v9Ap4_IMPLEMENTED))

def IsFeatureImplemented (feat : Feature) : SailM Bool := do
  (pure (GetElem?.getElem! (← readReg FeatureImpl) (num_of_Feature feat)))

def Mk_SCRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCR_Type_AW (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_SCRType_EA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCR_EL3_Type_EA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCR_Type_EA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_SCRType_FIQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_EL3_Type_FIQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_Type_FIQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCR_Type_FW (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_SCRType_IRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCR_EL3_Type_IRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCR_Type_IRQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCRType_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_EDSCR_Type_NS (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _get_SCR_EL3_Type_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCR_Type_NS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCR_EL3_Type_SIF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_SCR_EL3_Type_ST (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _update_HCR_Type_TWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _get_HCR_EL2_Type_TWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCR_EL3_Type_TWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _update_HCR_Type_TWI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _get_HCR_EL2_Type_TWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_SCR_EL3_Type_TWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def undefined_SCTLRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_SCTLR_Type_A (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_HSCTLR_Type_A (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL1_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL2_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_EL3_Type_A (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR_Type_A (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_HSCTLR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_PMCR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_SCTLR_Type_C (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _get_PMCNTENSET_EL0_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_PMCNTENSET_Type_C (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_PMCR_EL0_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR_EL1_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR_EL2_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_SCTLR_EL3_Type_C (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_SCTLR_Type_CP15BEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_SCTLR_EL1_Type_CP15BEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HSCTLR_Type_DSSBS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_Type_DSSBS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_FPCR_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_SCTLR_EL1_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCTLR_EL2_Type_DZE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_SCTLRType_E0E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_SCTLRType_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _update_HSCTLR_Type_EE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _update_SCTLR_Type_EE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _get_HSCTLR_Type_EE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL1_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL2_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL3_Type_EE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_Type_EE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_SCTLR_EL1_Type_EPAN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_SCTLR_EL2_Type_EPAN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _update_HSCTLR_Type_I (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_SCTLR_Type_I (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _get_SCTLR_EL1_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_SCTLR_EL2_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_SCTLR_EL3_Type_I (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _update_SCTLR_Type_ITD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_SCTLR_EL1_Type_ITD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_SCTLR_EL2_Type_ITD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_HSCTLR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_MPIDR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_SCTLR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_VMPIDR_Type_M (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_SCTLR_EL1_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLR_EL2_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLR_EL3_Type_M (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_SCTLRType_NMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_SCTLRType_SA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_VSTCR_EL2_Type_SA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLRType_SA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _update_SCTLR_Type_SED (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_SCTLR_Type_SPAN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _get_SCTLR_Type_SPAN (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_SCTLRType_SPINTMASK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _update_HCR_Type_TIDCP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _get_HCR_EL2_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_SCTLR_EL1_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_SCTLR_EL2_Type_TIDCP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_SCTLR_EL1_Type_TSCXT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_SCTLR_EL2_Type_TSCXT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_SCTLR_EL1_Type_UMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _update_SCTLR_Type_WXN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_SCTLR_EL1_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLR_EL2_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLR_EL3_Type_WXN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_SCTLRType_nAA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_SCTLRType_nTWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _update_SCTLR_Type_nTWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _get_SCTLRType_nTWI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _update_SCTLR_Type_nTWI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def undefined_MAIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_S1PIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S1PIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_S1PORType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S1PORType (v : (BitVec 64)) : (BitVec 64) :=
  v


end ArmASL.Functions
