import ArmASL.Part15

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_ICH_AP1R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMEVCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_ICV_IGRPEN0_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_IGRPEN1_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICC_SRE_EL1_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_ICH_AP0R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_PMSELR_EL0_Type_SEL (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _get_ERRSELR_EL1_Type_SEL (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_ICC_CTLR_EL3_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_CBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_CTLR_EL1_Type_EOImode (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICC_CTLR_EL3_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICV_CTLR_EL1_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICC_CTLR_EL3_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICV_CTLR_EL1_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICC_CTLR_EL3_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICV_CTLR_EL1_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICC_CTLR_EL3_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_ICV_CTLR_EL1_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def undefined_ICC_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMINTENSET_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGRTR_EL2_Type_TPIDR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_PMUSERENR_EL0_Type_ER (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def undefined_SPMACCESSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMICNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMIAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_ICH_VMCR_EL2_Type_VBPR0 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 23 21)

def _get_ICH_VMCR_EL2_Type_VBPR1 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 20 18)

def _get_ICH_VMCR_EL2_Type_VCBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_ICH_VMCR_EL2_Type_VENG0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICH_VMCR_EL2_Type_VENG1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICH_VMCR_EL2_Type_VEOIM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_ICH_VMCR_EL2_Type_VPMR (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def Mk_VPIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICC_CTLR_EL3_Type_nDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_ICH_VTR_EL2_Type_PREbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 28 26)

def undefined_RNDRRS_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SMPRIMAP_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_RNDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_HFGRTR_EL2_Type_DCZID_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_HFGRTR_EL2_Type_MIDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def undefined_ICV_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SPMACCESSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def CNTVOFF_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _CNTVOFF ) : SailM CNTVOFF_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg CNTVOFF_EL2) 0 64)))

def undefined_CNTV_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVTYPER1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_AMCGCR_EL0_Type_CG0NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def _get_AMCGCR_EL0_Type_CG1NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 15 8)

def undefined_ERXGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBINF_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBTGT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBSRC_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDTRTXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP1R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP0R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMINTENSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSECCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRTXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LRC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def __get_FPSR (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : FPSR_Type := value_name
  (Mk_FPSR_Type (tmp &&& (Complement.complement 0xFFFFFFFF07FFFF60#64)))

def __get_MIDR_EL1 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : MIDR_EL1_Type := value_name
  (Mk_MIDR_EL1_Type (tmp &&& (Complement.complement 0xFFFFFFFF00000000#64)))

def __get_PMCCFILTR_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMCCFILTR_EL0_Type := value_name
  (Mk_PMCCFILTR_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFF020FFFFF#64)))

def __get_CNTFRQ_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : CNTFRQ_EL0_Type := value_name
  (tmp &&& (Complement.complement 0xFFFFFFFF00000000#64))

def __get_DCZID_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : DCZID_EL0_Type := value_name
  (Mk_DCZID_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFFFFFFFFE0#64)))

def __get_PMEVTYPER_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMEVTYPER_EL0_Type := value_name
  (Mk_PMEVTYPER_EL0_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0xBFFF000000F0000#60 64))))

def __get_VPIDR_EL2 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : VPIDR_EL2_Type := value_name
  (Mk_VPIDR_EL2_Type (tmp &&& (Complement.complement 0xFFFFFFFF00000000#64)))

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int -/
def AArch64_CheckNVCondsIfCurrentEL (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) : SailM Bool := do
  let is_reg_current_el : Bool := (((((op0 == 3) && (op1 == 0)) && (crn == 4)) && (crm == 2)) && (op2 == 2))
  let have_nv_trap_conds ← (( do (HaveNVExt ()) <&&> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((BitVec.slice (← readReg HCR_EL2) 42 1) == 1#1))) ) : SailM Bool )
  (pure (is_reg_current_el && have_nv_trap_conds))

def ConsumptionOfSpeculativeDataBarrier (_ : Unit) : Unit :=
  ()

def Hint_CLRBHB (_ : Unit) : Unit :=
  ()

def Hint_DGH (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: count : Int, length : Int, reuse : Int, stride : Int -/
def Hint_RangePrefetch (address : (BitVec 64)) (length : Int) (stride : Int) (count : Int) (reuse : Int) (operation : (BitVec 6)) : Unit :=
  ()

def Hint_Yield (_ : Unit) : Unit :=
  ()

def ProfilingSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def SendEvent (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToPA (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToVA (_ : Unit) : Unit :=
  ()

def AArch64_PendingUnmaskedVirtualInterrupts (mask_in : (BitVec 3)) : SailM (Bool × Bool × Bool) := do
  let allintmask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let mask : (BitVec 3) := mask_in
  let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  let (mask, pending) ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
         (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
    then
      (do let pending ← (pure (((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_VI (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_VF (← readReg HCR_EL2)))) &&& ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))))))
          let mask ← (( do
            (if ((←((HaveFeatNMI ()) <&&> (do
                 (pure ((_get_SCTLRType_NMI (← (SCTLR_read__1 ()))) == 1#1))))) : Bool)
            then
              (do let allintmask ← (( do (pure ((← readReg PSTATE).ALLINT ||| ((← readReg PSTATE).SP &&& (_get_SCTLRType_SPINTMASK (← (SCTLR_read__1 ())))))) ) : SailM (BitVec 1) )
                  let mask ← (( do
                    (if ((←((IsHCRXEL2Enabled ()) <&&> (do
                         (pure (((← readReg PSTATE).EL == EL0) || (allintmask == 0#1)))))) : Bool)
                    then
                      (do let mask ← (( do
                            (if (((_get_HCRX_EL2_Type_VFNMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                            then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                            else (do (pure mask))) ) : SailM (BitVec 3) )
                          (if (((_get_HCRX_EL2_Type_VINMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 1 (Bit 0#1))))
                          else (do (pure mask))))
                    else (do (pure mask))) ) : SailM (BitVec 3) )
                  (if ((((← readReg PSTATE).EL == EL1) && (allintmask == 1#1)) : Bool)
                  then
                    (do let mask ← (( do
                          (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                          else (do (pure mask))) ) : SailM (BitVec 3) )
                        (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                        else (do (pure mask))))
                  else (do (pure mask))))
            else (do (pure mask))) ) : SailM (BitVec 3) )
          (pure (mask, pending)))
    else
      (do let pending : (BitVec 3) := 0b000#3
          (pure (mask, pending)))) ) : SailM ((BitVec 3) × (BitVec 3)) )
  let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
  (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))

def AArch32_PendingUnmaskedVirtualInterrupts (_ : Unit) : SailM (Bool × Bool × Bool) := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL2))))) <||> (do
       (pure (HaveEL EL3)) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3)))))))) : Bool)
  then (do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
  else
    (do let mask ← (( do (pure ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))) ) : SailM (BitVec 3) )
        let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
        let pending ← (( do
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1))))) : Bool)
          then (do (pure (((_get_HCR_Type_VA (← (HCR_read ()))) +++ ((_get_HCR_Type_VI (← (HCR_read ()))) +++ (_get_HCR_Type_VF (← (HCR_read ()))))) &&& ((_get_HCR_Type_AMO (← (HCR_read ()))) +++ ((_get_HCR_Type_IMO (← (HCR_read ()))) +++ (_get_HCR_Type_FMO (← (HCR_read ()))))))))
          else (do (pure 0b000#3))) ) : SailM (BitVec 3) )
        let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
        (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))))

def TakePendingInterrupts (interrupt_req : InterruptReq) : SailM Bool := do
  let interrupt_pend ← (( do (undefined_bool ()) ) : SailM Bool )
  let interrupt_taken ← (( do (undefined_bool ()) ) : SailM Bool )
  let vAA ← (( do (undefined_bool ()) ) : SailM Bool )
  let vIRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let vSE ← (( do (undefined_bool ()) ) : SailM Bool )
  let vFIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let AA ← (( do (undefined_bool ()) ) : SailM Bool )
  let IRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let FIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let SE ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let (vAA, vFIQ, vIRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedVirtualInterrupts ())
          let vAA : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vAA, vFIQ, vIRQ)) ) : SailM (Bool × Bool × Bool) )
        let (AA, FIQ, IRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedPhysicalInterrupts ())
          let AA : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (AA, FIQ, IRQ)) ) : SailM (Bool × Bool × Bool) )
        let AA : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else AA
        let vAA : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vAA
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let interrupt_taken : Bool :=
          if ((((((AA || FIQ) || IRQ) || vAA) || vFIQ) || vIRQ) : Bool)
          then true
          else false
        (if (vFIQ : Bool)
        then (do (AArch32_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch32_TakeVirtualIRQException ()))
              else
                (do (if (vAA : Bool)
                    then (do (AArch32_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch32_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch32_TakePhysicalIRQException ()))
                                else
                                  (do (if (AA : Bool)
                                      then (do (AArch32_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken))
  else
    (do let (vFIQ, vIRQ, vSE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let vSE : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
        let (FIQ, IRQ, SE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let SE : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
        let SE : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else SE
        let vSE : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vSE
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE) ← (( do
          (if ((((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ) : Bool)
          then
            (do let (FIQ, IRQ, SE, vFIQ, vIRQ, vSE) ← (( do
                  (if ((←((HaveTME ()) <&&> (do
                       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
                  then
                    (do let (vFIQ, vIRQ, vSE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let vSE : Bool := tup__0
                          let vIRQ : Bool := tup__1
                          let vFIQ : Bool := tup__2
                          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
                        let (FIQ, IRQ, SE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let SE : Bool := tup__0
                          let IRQ : Bool := tup__1
                          let FIQ : Bool := tup__2
                          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
                        let SE : Bool :=
                          if ((! interrupt_req.take_SE) : Bool)
                          then false
                          else SE
                        let vSE : Bool :=
                          if ((! interrupt_req.take_vSE) : Bool)
                          then false
                          else vSE
                        let IRQ : Bool :=
                          if ((! interrupt_req.take_IRQ) : Bool)
                          then false
                          else IRQ
                        let vIRQ : Bool :=
                          if ((! interrupt_req.take_vIRQ) : Bool)
                          then false
                          else vIRQ
                        let FIQ : Bool :=
                          if ((! interrupt_req.take_FIQ) : Bool)
                          then false
                          else FIQ
                        let vFIQ : Bool :=
                          if ((! interrupt_req.take_vFIQ) : Bool)
                          then false
                          else vFIQ
                        let interrupt_pend : Bool := (((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ)
                        (FailTransaction__1 TMFailure_IMP interrupt_pend (! interrupt_pend) (Zeros (n := 15)))
                        (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))
                  else (do (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool) )
                let interrupt_taken : Bool := true
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))
          else
            (do let interrupt_taken : Bool := false
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool × Bool) )
        (if (vFIQ : Bool)
        then (do (AArch64_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch64_TakeVirtualIRQException ()))
              else
                (do (if (vSE : Bool)
                    then (do (AArch64_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch64_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch64_TakePhysicalIRQException ()))
                                else
                                  (do (if (SE : Bool)
                                      then (do (AArch64_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken)))

def TakeUnmaskedSErrorInterrupts (_ : Unit) : SailM Unit := do
  let interrupt_req ← (( do (undefined_InterruptReq ()) ) : SailM InterruptReq )
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_FIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vFIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_IRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vIRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with iesb_req := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := true }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := true }
  let interrupt_taken ← (( do (TakePendingInterrupts interrupt_req) ) : SailM Bool )
  (pure ())

def HaveFP16Ext (_ : Unit) : Bool :=
  true

def ExclusiveMonitorsStatus (_ : Unit) : (BitVec 1) :=
  0#1

/-- Type quantifiers: Rt : Int, k_acq_rel : Bool, k_sign_extend : Bool, k_sixty_four : Bool, size : Int -/
def AArch64_SetLSInstructionSyndrome (size : Int) (sign_extend : Bool) (Rt : Int) (sixty_four : Bool) (acq_rel : Bool) : Unit :=
  ()

def DataMemoryBarrier (domain : MBReqDomain) (types : MBReqTypes) : SailM Unit := do
  (sail_barrier
    (Barrier_DMB
      { domain := domain
        types := types
        nXS := false }))

/-- Type quantifiers: k_nXS : Bool -/
def DataSynchronizationBarrier (domain : MBReqDomain) (types : MBReqTypes) (nXS : Bool) : SailM Unit := do
  (sail_barrier
    (Barrier_DSB
      { domain := domain
        types := types
        nXS := nXS }))

def InstructionSynchronizationBarrier (_ : Unit) : SailM Unit := do
  (sail_barrier (Barrier_ISB ()))

/-- Type quantifiers: t : Int -/
def CNTFRQ_EL0_SysRegRead_aed619ec0d882dc5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
             (pure (((_get_CNTKCTL_EL1_Type_EL0PCTEN (← readReg CNTKCTL_EL1)) +++ (_get_CNTKCTL_EL1_Type_EL0VCTEN (← readReg CNTKCTL_EL1))) == 0b00#2))))) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                   (pure (((_get_CNTHCTL_EL2_Type_EL0PCTEN (← readReg CNTHCTL_EL2)) +++ (_get_CNTHCTL_EL2_Type_EL0VCTEN (← readReg CNTHCTL_EL2))) == 0b00#2))))) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (__get_CNTFRQ_EL0 (← readReg CNTFRQ_EL0))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do (X_set t 64 (__get_CNTFRQ_EL0 (← readReg CNTFRQ_EL0))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (__get_CNTFRQ_EL0 (← readReg CNTFRQ_EL0))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (__get_CNTFRQ_EL0 (← readReg CNTFRQ_EL0))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTVCT_EL0_SysRegRead_1d562372e622baf9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0VCTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0VCTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0VCTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0VCTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1TVCT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1TVCT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0VCTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0VCTEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1TVCT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((pure (HaveEL EL2)) <&&> (do
                               (pure (! (← (EL2Enabled ())))) <||> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2)))))) : Bool)
                          then (do (X_set t 64 ((← (PhysicalCountInt ())) - (← readReg CNTVOFF_EL2))))
                          else (do (X_set t 64 (← (PhysicalCountInt ()))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__CNTHCTL_EL2_EL1TVCT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((HaveEL EL2) : Bool)
                    then (do (X_set t 64 ((← (PhysicalCountInt ())) - (← readReg CNTVOFF_EL2))))
                    else (do (X_set t 64 (← (PhysicalCountInt ()))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 0#1) : Bool)
                    then (do (X_set t 64 ((← (PhysicalCountInt ())) - (← readReg CNTVOFF_EL2))))
                    else (do (X_set t 64 (← (PhysicalCountInt ()))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((←((pure (HaveEL EL2)) <&&> (do
                               (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
                          then (do (X_set t 64 ((← (PhysicalCountInt ())) - (← readReg CNTVOFF_EL2))))
                          else
                            (do (if ((←((pure (HaveEL EL2)) <&&> (do
                                     (ELUsingAArch32 EL2)))) : Bool)
                                then (do (X_set t 64 ((← (PhysicalCountInt ())) - (← (CNTVOFF_read ())))))
                                else (do (X_set t 64 (← (PhysicalCountInt ()))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DCZID_EL0_SysRegRead_9bb2971f34b1558f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_DCZID_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_DCZID_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DIT_SysRegRead_80b5d608e76aa495 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do (X_set t 64 (((Zeros (n := 39)) +++ (← readReg PSTATE).DIT) +++ (Zeros (n := 24)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do (X_set t 64 (((Zeros (n := 39)) +++ (← readReg PSTATE).DIT) +++ (Zeros (n := 24)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (((Zeros (n := 39)) +++ (← readReg PSTATE).DIT) +++ (Zeros (n := 24)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (((Zeros (n := 39)) +++ (← readReg PSTATE).DIT) +++ (Zeros (n := 24)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def FPCR_SysRegRead_48b824e8174adfc0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TFP ← (( do (pure (_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPACR_EL1_FPEN ← (( do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1))) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_FPEN ← (( do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TFP ← (( do (pure (_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (((! (←((EL2Enabled ()) <&&> (do
                       (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CPACR_EL1_FPEN != 0b11#2)) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x00#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CPTR_EL2_FPEN != 0b11#2)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__3 := __CPTR_EL2_FPEN
                               if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                               then true
                               else false : Bool)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (← (__get_FPCR (← readReg FPCR)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((let b__2 := __CPACR_EL1_FPEN
                       if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                       then true
                       else false : Bool) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__1 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (← (__get_FPCR (← readReg FPCR)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (← (__get_FPCR (← readReg FPCR)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_TFP == 1#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))
                          else (do (X_set t 64 (← (__get_FPCR (← readReg FPCR)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def FPSR_SysRegRead_f0c8f9b942affbc0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TFP ← (( do (pure (_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPACR_EL1_FPEN ← (( do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1))) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_FPEN ← (( do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TFP ← (( do (pure (_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (((! (←((EL2Enabled ()) <&&> (do
                       (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CPACR_EL1_FPEN != 0b11#2)) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x00#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CPTR_EL2_FPEN != 0b11#2)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__3 := __CPTR_EL2_FPEN
                               if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                               then true
                               else false : Bool)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (__get_FPSR (← readReg FPSR))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((let b__2 := __CPACR_EL1_FPEN
                       if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                       then true
                       else false : Bool) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__1 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (__get_FPSR (← readReg FPSR))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (X_set t 64 (__get_FPSR (← readReg FPSR))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_TFP == 1#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))
                          else (do (X_set t 64 (__get_FPSR (← readReg FPSR))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def MIDR_EL1_SysRegRead_5aac357d91bc3b98 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_MIDR_EL1 ← (( do (pure (_get_HFGRTR_EL2_Type_MIDR_EL1 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((← (IsFeatureImplemented FEAT_IDST)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else (do sailThrow ((Error_Undefined ())))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_MIDR_EL1 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((← (EL2Enabled ())) : Bool)
                    then (do (X_set t 64 (__get_VPIDR_EL2 (← readReg VPIDR_EL2))))
                    else (do (X_set t 64 (__get_MIDR_EL1 (← readReg MIDR_EL1))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (__get_MIDR_EL1 (← readReg MIDR_EL1))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (__get_MIDR_EL1 (← readReg MIDR_EL1))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def NZCV_SysRegRead_66dd3f91dc048279 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do (X_set t 64 (((Zeros (n := 32)) +++ ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))) +++ (Zeros (n := 28)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do (X_set t 64 (((Zeros (n := 32)) +++ ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))) +++ (Zeros (n := 28)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (((Zeros (n := 32)) +++ ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))) +++ (Zeros (n := 28)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (((Zeros (n := 32)) +++ ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))) +++ (Zeros (n := 28)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL0_SysRegRead_512297cd575d98fa (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_TPIDR_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_TPIDR_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (← readReg TPIDR_EL0)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (← readReg TPIDR_EL0)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (← readReg TPIDR_EL0)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (← readReg TPIDR_EL0)))
                    else (do (pure ())))))))))


end ArmASL.Functions
