import ArmASL.Part15

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_ID_ISAR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR2 ) : SailM ID_ISAR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR2_EL1) 0 32)))

def ID_ISAR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR2_Type := value_name
  writeReg ID_ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR2 r

def undefined_ID_ISAR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR3_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR3 ) : SailM ID_ISAR3_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR3_EL1) 0 32)))

def ID_ISAR3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR3_Type := value_name
  writeReg ID_ISAR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR3_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR3 r

def undefined_ID_ISAR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR4_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR4 ) : SailM ID_ISAR4_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR4_EL1) 0 32)))

def ID_ISAR4_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR4_Type := value_name
  writeReg ID_ISAR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR4_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR4 r

def undefined_ID_ISAR6_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR6_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR6_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR6 ) : SailM ID_ISAR6_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR6_EL1) 0 32)))

def ID_ISAR6_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR6_Type := value_name
  writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR6 r

def undefined_ID_MMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR0 ) : SailM ID_MMFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR0_EL1) 0 32)))

def ID_MMFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR0_Type := value_name
  writeReg ID_MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR0 r

def undefined_ID_MMFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR1 ) : SailM ID_MMFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR1_EL1) 0 32)))

def ID_MMFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR1_Type := value_name
  writeReg ID_MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR1 r

def undefined_ID_MMFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR2 ) : SailM ID_MMFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR2_EL1) 0 32)))

def ID_MMFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR2_Type := value_name
  writeReg ID_MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR2 r

def undefined_ID_MMFR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR3_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR3 ) : SailM ID_MMFR3_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR3_EL1) 0 32)))

def ID_MMFR3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR3_Type := value_name
  writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR3 r

def undefined_ID_MMFR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR4_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR4 ) : SailM ID_MMFR4_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR4_EL1) 0 32)))

def ID_MMFR4_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR4_Type := value_name
  writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR4 r

def undefined_ID_PFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR0 ) : SailM ID_PFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR0_EL1) 0 32)))

def ID_PFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR0_Type := value_name
  writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR0 r

def undefined_ID_PFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR1 ) : SailM ID_PFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR1_EL1) 0 32)))

def ID_PFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR1_Type := value_name
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR1 r

def undefined_MIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MIDR ) : SailM MIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MIDR_EL1) 0 32)))

def MIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MIDR_Type := value_name
  writeReg MIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MIDR r

def undefined_MVFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR0 ) : SailM MVFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR0_EL1) 0 32)))

def MVFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR0_Type := value_name
  writeReg MVFR0_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR0 r

def undefined_MVFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR1 ) : SailM MVFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR1_EL1) 0 32)))

def MVFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR1_Type := value_name
  writeReg MVFR1_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR1 r

def Mk_CLIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_ISAR6_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_NMRR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID3_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_NMRR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def NMRR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _NMRR_NS ) : SailM NMRR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MAIR_EL1) 32 32)))

def NMRR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_NMRR_Type ()) ) : SailM NMRR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg NMRR_S)
  else (do (NMRR_NS_read ())))

def NMRR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : NMRR_Type := value_name
  writeReg MAIR_EL1 (Sail.BitVec.updateSubrange (← readReg MAIR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _NMRR_NS r

def NMRR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : NMRR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg NMRR_S r)
  else (do (NMRR_NS_write r)))

def undefined_PMCEID0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCEID0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID0_Type := value_name
  writeReg PMCEID0_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCEID0 r

def undefined_PMCEID1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCEID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID1_Type := value_name
  writeReg PMCEID1_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCEID1 r

def undefined_PMCEID2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID2_Type := value_name
  writeReg PMCEID0_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID0_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _PMCEID2 r

def undefined_PMCEID3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID3_Type := value_name
  writeReg PMCEID1_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID1_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _PMCEID3 r

def _get_ID_DFR0_EL1_Type_CopDbg (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ID_DFR0_Type_CopDbg (v : (BitVec 32)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _update_CCSIDR_Type_Associativity (v : (BitVec 32)) (x : (BitVec 21)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 3 x)

def _update_CCSIDR_Type_LineSize (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _update_ID_DFR0_Type_CopDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_DFR0_Type_CopSDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_DFR0_Type_CopTrc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_DFR0_Type_MMapDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_DFR0_Type_MMapTrc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_DFR0_Type_MProfDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_DFR0_Type_PerfMon (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_DFR0_Type_TraceFilt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_DFR1_Type_MTPMU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR0_Type_BitCount (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR0_Type_BitField (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR0_Type_CmpBranch (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR0_Type_Coproc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR0_Type_Debug (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR0_Type_Divide (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR0_Type_Swap (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR1_Type_Endian (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR1_Type_Except (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR1_Type_Except_AR (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR1_Type_Extend (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR1_Type_IfThen (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR1_Type_Immediate (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR1_Type_Interwork (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR1_Type_Jazelle (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR2_Type_LoadStore (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR2_Type_MemHint (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR2_Type_Mult (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR2_Type_MultS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR2_Type_MultU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR2_Type_MultiAccessInt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR2_Type_PSR_AR (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR2_Type_Reversal (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR3_Type_SIMD (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR3_Type_SVC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR3_Type_Saturate (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR3_Type_SynchPrim (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR3_Type_T32Copy (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR3_Type_T32EE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR3_Type_TabBranch (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR3_Type_TrueNOP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR4_Type_Barrier (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR4_Type_PSR_M (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR4_Type_SMC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR4_Type_SWP_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR4_Type_SynchPrim_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR4_Type_Unpriv (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR4_Type_WithShifts (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR4_Type_Writeback (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR5_Type_AES (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR5_Type_CRC32 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR5_Type_RDM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR5_Type_SEVL (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR5_Type_SHA1 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR5_Type_SHA2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR5_Type_VCMA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR6_Type_BF16 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR6_Type_FHM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR6_Type_I8MM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR6_Type_JSCVT (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR6_Type_SPECRES (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR0_Type_AuxReg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR0_Type_FCSE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR0_Type_InnerShr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR0_Type_OuterShr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR0_Type_PMSA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR0_Type_ShareLvl (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR0_Type_TCM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR0_Type_VMSA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR1_Type_BPred (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR1_Type_L1Hvd (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR1_Type_L1HvdSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR1_Type_L1HvdVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR1_Type_L1TstCln (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR1_Type_L1Uni (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR1_Type_L1UniSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR1_Type_L1UniVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR2_Type_HWAccFlg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR2_Type_HvdTLB (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR2_Type_L1HvdBG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR2_Type_L1HvdFG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR2_Type_L1HvdRng (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR2_Type_MemBarr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR2_Type_UniTLB (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR2_Type_WFIStall (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_BPMaint (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR3_Type_CMaintSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR3_Type_CMaintVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR3_Type_CMemSz (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_CohWalk (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR3_Type_MaintBcst (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR3_Type_Supersec (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR4_Type_CCIDX (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR5_Type_ETS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR0_Type_AMU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_PFR0_Type_CSV2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_PFR0_Type_RAS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_PFR0_Type_State0 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR0_Type_State1 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_PFR0_Type_State2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_PFR0_Type_State3 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_PFR1_Type_GIC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_PFR1_Type_GenTimer (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_PFR1_Type_MProgMod (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_PFR1_Type_ProgMod (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR1_Type_Sec_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_PFR1_Type_Security (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_PFR1_Type_Virt_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_PFR1_Type_Virtualization (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MIDR_Type_Architecture (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MIDR_Type_Implementer (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 24 x)

def _update_MIDR_Type_PartNum (v : (BitVec 32)) (x : (BitVec 12)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 4 x)

def _update_MIDR_Type_Revision (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MIDR_Type_Variant (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MPIDR_Type_Aff0 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_MPIDR_Type_Aff1 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def _update_MPIDR_Type_Aff2 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 16 x)

def _update_MVFR0_Type_FPDP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_MVFR0_Type_FPDivide (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MVFR0_Type_FPRound (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_MVFR0_Type_FPSP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR0_Type_FPShVec (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_MVFR0_Type_FPSqrt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MVFR0_Type_FPTrap (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MVFR0_Type_SIMDReg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MVFR1_Type_FPDNaN (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR1_Type_FPFtZ (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MVFR1_Type_FPHP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_MVFR1_Type_SIMDFMAC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_MVFR1_Type_SIMDHP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MVFR1_Type_SIMDInt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MVFR1_Type_SIMDLS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_MVFR1_Type_SIMDSP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MVFR2_Type_FPMisc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR2_Type_SIMDMisc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)


end ArmASL.Functions
