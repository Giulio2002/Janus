import ArmASL.Part15

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_ICH_LR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_LR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_BPR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICV_BPR1_EL1_Type_BinaryPoint (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_ICV_BPR0_EL1_Type_BinaryPoint (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def Mk_PMECR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_EOIR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_RMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_RMR_EL3_Type_AA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def Mk_OSLAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTHPS_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHPS_CTL_EL2_Type := value_name
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def Mk_HAFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_BPR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ACCDATA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_SCTLR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : SCTLR_EL1_Type := value_name
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 4 0 (BitVec.slice r 0 5))
  writeReg SCTLR_EL1 (BitVec.update (← readReg SCTLR_EL1) 6 (Bit (BitVec.slice r 6 1)))
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 63 8 (BitVec.slice r 8 56))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_ITD")))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 7 7 (_get_SCTLR_EL1_Type_ITD r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_CP15BEN")))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 5 5 (_get_SCTLR_EL1_Type_CP15BEN r)))
  else (do (pure ())))

def Mk_PMSSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_PMSSCR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMSSCR_EL1_Type := value_name
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 63 1 (BitVec.slice r 1 63))
  (if ((! (← (__IMPDEF_boolean "Capture events are disabled"))) : Bool)
  then (do writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 0 0 (_get_PMSSCR_EL1_Type_SS r)))
  else (do (pure ())))

def Mk_ICC_SGI0R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_FPCR (value_name : (BitVec 64)) : SailM Unit := do
  let r : FPCR_Type := value_name
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 7 0 (BitVec.slice r 0 8))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 14 13 (BitVec.slice r 13 2))
  writeReg FPCR (BitVec.update (← readReg FPCR) 19 (Bit (BitVec.slice r 19 1)))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 63 22 (BitVec.slice r 22 42))
  (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_FPSCR.LEN,STRIDE as RAZ"))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 21 20 (_get_FPCR_Type_Stride r)))
  else (do (pure ())))
  (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_FPSCR.LEN,STRIDE as RAZ"))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 18 16 (_get_FPCR_Type_length r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Input Denormal floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 15 15 (_get_FPCR_Type_IDE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Inexact floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 12 12 (_get_FPCR_Type_IXE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Underflow floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 11 11 (_get_FPCR_Type_UFE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Overflow floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 10 10 (_get_FPCR_Type_OFE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Divide by Zero floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 9 9 (_get_FPCR_Type_DZE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Invalid Operation floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 8 8 (_get_FPCR_Type_IOE r)))
  else (do (pure ())))

def __set_CNTHVS_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHVS_CTL_EL2_Type := value_name
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def undefined_SPMACCESSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_SPMSELR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SPMSELR_EL0_Type_SYSPMUSEL (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 9 4)

def __get_selected_SPMACCESSR_EL1_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL1) idx 2))

def undefined_ICH_AP1R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_AP1R_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_DIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMEVCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_ICC_SRE_EL2_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_ICC_SRE_EL3_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_ICV_IGRPEN0_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_IGRPEN1_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def Mk_DBGCLAIMSET_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICC_SRE_EL1_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICC_SRE_EL2_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICC_SRE_EL3_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_ICH_AP0R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_AP0R_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMUACR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_RMR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSELR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSELR_EL0_Type_SEL (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _get_ERRSELR_EL1_Type_SEL (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_ICC_CTLR_EL3_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_CBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_CTLR_EL1_Type_EOImode (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICC_CTLR_EL3_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICV_CTLR_EL1_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICC_CTLR_EL3_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICV_CTLR_EL1_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICC_CTLR_EL3_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICV_CTLR_EL1_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICC_CTLR_EL3_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_ICV_CTLR_EL1_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def undefined_ICC_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_AP1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: n : Int -/
def ICC_AP1R_EL1_set (n : Int) (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_AP1R_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then
    (do sail_assert ((0 ≤b n) && (n <b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:44781.45-44781.46"
        writeReg ICC_AP1R_EL1_S (vectorUpdate (← readReg ICC_AP1R_EL1_S) n r))
  else
    (do sail_assert ((0 ≤b n) && (n <b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:44784.45-44784.46"
        writeReg ICC_AP1R_EL1_NS (vectorUpdate (← readReg ICC_AP1R_EL1_NS) n r)))

def __set_CNTP_CTL_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTP_CTL_EL0_Type := value_name
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 1 0 (BitVec.slice r 0 2))
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 63 3 (BitVec.slice r 3 61))

def Mk_CSSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_PMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_BPR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMCCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMINTENSET_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGWTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGWTR_EL2_Type_AFSR0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HFGWTR_EL2_Type_AFSR1_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HFGWTR_EL2_Type_AMAIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HFGWTR_EL2_Type_APDAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HFGWTR_EL2_Type_APDBKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HFGWTR_EL2_Type_APGAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_HFGWTR_EL2_Type_APIAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HFGWTR_EL2_Type_APIBKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HFGWTR_EL2_Type_CONTEXTIDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HFGWTR_EL2_Type_CPACR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HFGWTR_EL2_Type_CSSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HFGWTR_EL2_Type_ERRSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_HFGWTR_EL2_Type_ERXADDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_HFGWTR_EL2_Type_ERXCTLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_HFGWTR_EL2_Type_ERXMISCn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 45 45)

def _get_HFGWTR_EL2_Type_ERXPFGCDN_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _get_HFGWTR_EL2_Type_ERXPFGCTL_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 47 47)

def _get_HFGWTR_EL2_Type_ERXSTATUS_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_HFGWTR_EL2_Type_ESR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_HFGWTR_EL2_Type_FAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HFGWTR_EL2_Type_ICC_IGRPENn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 39 39)

def _get_HFGWTR_EL2_Type_LORC_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HFGWTR_EL2_Type_LOREA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_HFGWTR_EL2_Type_LORN_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_HFGWTR_EL2_Type_LORSA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_HFGWTR_EL2_Type_MAIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_HFGWTR_EL2_Type_PAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_HFGWTR_EL2_Type_SCTLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_HFGWTR_EL2_Type_SCXTNUM_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_HFGWTR_EL2_Type_SCXTNUM_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_HFGWTR_EL2_Type_TCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HFGWTR_EL2_Type_TPIDRRO_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_HFGWTR_EL2_Type_TPIDR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_HFGRTR_EL2_Type_TPIDR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_HFGWTR_EL2_Type_TPIDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_HFGWTR_EL2_Type_TTBR0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_HFGWTR_EL2_Type_TTBR1_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_HFGWTR_EL2_Type_VBAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_HFGWTR_EL2_Type_nACCDATA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_HFGWTR_EL2_Type_nAMAIR2_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_HFGWTR_EL2_Type_nGCS_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_HFGWTR_EL2_Type_nGCS_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_HFGWTR_EL2_Type_nMAIR2_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _get_HFGWTR_EL2_Type_nPIRE0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_HFGWTR_EL2_Type_nPIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_HFGWTR_EL2_Type_nPOR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_HFGWTR_EL2_Type_nPOR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_HFGWTR_EL2_Type_nRCWMASK_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_HFGWTR_EL2_Type_nS2POR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_HFGWTR_EL2_Type_nSMPRI_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_HFGWTR_EL2_Type_nTPIDR2_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def Mk_SMPRI_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMUSERENR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMUSERENR_EL0_Type_ER (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_PMUSERENR_EL0_Type_UEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def Mk_ICV_CTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_FPEXC32_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : FPEXC32_EL2_Type := value_name
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 6 5 (BitVec.slice r 5 2))
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 30 8 (BitVec.slice r 8 23))
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 63 32 (BitVec.slice r 32 32))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Input Denormal floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 7 7 (_get_FPEXC32_EL2_Type_IDF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Inexact floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 4 4 (_get_FPEXC32_EL2_Type_IXF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Underflow floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 3 3 (_get_FPEXC32_EL2_Type_UFF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Overflow floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 2 2 (_get_FPEXC32_EL2_Type_OFF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Divide by Zero floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 1 1 (_get_FPEXC32_EL2_Type_DZF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Invalid Operation floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 0 0 (_get_FPEXC32_EL2_Type_IOF r)))
  else (do (pure ())))

def __set_MDSCR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MDSCR_EL1_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 5 0 (BitVec.slice r 0 6))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 13 7 (BitVec.slice r 7 7))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 18 15 (BitVec.slice r 15 4))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 20 (Bit (BitVec.slice r 20 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 25 24 (BitVec.slice r 24 2))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 28 (Bit (BitVec.slice r 28 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 34 32 (BitVec.slice r 32 3))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 36 (BitVec.slice r 36 28))
  (if ((! ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 35 35 (_get_MDSCR_EL1_Type_EHBWE r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 31 31 (_get_MDSCR_EL1_Type_TFO r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 30 30 (_get_MDSCR_EL1_Type_RXfull r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 29 29 (_get_MDSCR_EL1_Type_TXfull r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 27 27 (_get_MDSCR_EL1_Type_RXO r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 26 26 (_get_MDSCR_EL1_Type_TXU r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 23 22 (_get_MDSCR_EL1_Type_INTdis r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 21 21 (_get_MDSCR_EL1_Type_TDA r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 19 19 (_get_MDSCR_EL1_Type_SC2 r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 14 14 (_get_MDSCR_EL1_Type_HDE r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 6 6 (_get_MDSCR_EL1_Type_ERR r)))
  else (do (pure ())))

def __set_GPCCR_EL3 (value_name : (BitVec 64)) : SailM Unit := do
  let r : GPCCR_EL3_Type := value_name
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 19 0 (BitVec.slice r 0 20))
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 63 24 (BitVec.slice r 24 40))

def Mk_HDFGWTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR2_EL2_Type_nMDSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HDFGWTR2_EL2_Type_nPMECR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HDFGWTR2_EL2_Type_nPMIAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HDFGWTR2_EL2_Type_nPMICFILTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HDFGWTR2_EL2_Type_nPMICNTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_HDFGWTR2_EL2_Type_nPMSDSFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HDFGWTR2_EL2_Type_nPMSSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HDFGWTR2_EL2_Type_nPMUACR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HDFGWTR2_EL2_Type_nPMZR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_HDFGWTR2_EL2_Type_nSPMACCESSR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_HDFGWTR2_EL2_Type_nSPMCNTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HDFGWTR2_EL2_Type_nSPMCR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_HDFGWTR2_EL2_Type_nSPMEVCNTRn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_HDFGWTR2_EL2_Type_nSPMINTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDFGWTR2_EL2_Type_nSPMOVS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HDFGWTR2_EL2_Type_nSPMSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_HDFGWTR2_EL2_Type_nSPMSELR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def __set_CNTHP_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHP_CTL_EL2_Type := value_name
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def undefined_SPMACCESSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __get_selected_SPMACCESSR_EL2_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL2) idx 2))

def Mk_PMZR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMICNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_IGRPEN1_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_LORSA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSWINC_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTV_CTL_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTV_CTL_EL0_Type := value_name
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 1 0 (BitVec.slice r 0 2))
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 63 3 (BitVec.slice r 3 61))

def undefined_PMIAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMIAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICH_VMCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_VMCR_EL2_Type_VBPR0 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 23 21)

def _get_ICH_VMCR_EL2_Type_VBPR1 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 20 18)

def _get_ICH_VMCR_EL2_Type_VCBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_ICH_VMCR_EL2_Type_VENG0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICH_VMCR_EL2_Type_VENG1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICH_VMCR_EL2_Type_VEOIM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_ICH_VMCR_EL2_Type_VPMR (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def Mk_VPIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_CTLR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICC_CTLR_EL3_Type_nDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def __set_SCTLR_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : SCTLR_EL2_Type := value_name
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 6 0 (BitVec.slice r 0 7))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 63 8 (BitVec.slice r 8 56))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_ITD")))) : Bool)
  then (do writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 7 7 (_get_SCTLR_EL2_Type_ITD r)))
  else (do (pure ())))

def Mk_ICC_SRE_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTPS_CTL_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTPS_CTL_EL1_Type := value_name
  writeReg CNTPS_CTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_CTL_EL1) 1 0 (BitVec.slice r 0 2))
  writeReg CNTPS_CTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_CTL_EL1) 63 3 (BitVec.slice r 3 61))

def Mk_LORC_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_ASGI1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGRTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGWTR2_EL2_Type_nPFAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HFGWTR2_EL2_Type_nRCWSMASK_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def Mk_RMR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICH_HCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_HCR_EL2_Type_TALL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_ICH_HCR_EL2_Type_TALL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_ICH_HCR_EL2_Type_TDIR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def Mk_ICC_IGRPEN0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_EOIR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_PMCR_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMCR_EL0_Type := value_name
  writeReg PMCR_EL0 (BitVec.update (← readReg PMCR_EL0) 0 (Bit (BitVec.slice r 0 1)))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 15 3 (BitVec.slice r 3 13))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 63 32 (BitVec.slice r 32 32))
  (if ((! (! (← (IsFeatureImplemented FEAT_PMUv3p7)))) : Bool)
  then (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 31 24 (_get_PMCR_EL0_Type_IMP r)))
  else (do (pure ())))
  (if ((! ((_get_PMCR_EL0_Type_IMP (← readReg PMCR_EL0)) != 0b00000000#8)) : Bool)
  then (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 23 16 (_get_PMCR_EL0_Type_IDCODE r)))
  else (do (pure ())))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 2 2 (_get_PMCR_EL0_Type_C r))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 1 1 (_get_PMCR_EL0_Type_P r))

def Mk_HDFGRTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_VMPIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_VTR_EL2_Type_PREbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 28 26)

def __set_MDSELR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MDSELR_EL1_Type := value_name
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 3 0 (BitVec.slice r 0 4))
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 63 6 (BitVec.slice r 6 58))
  (if ((! (←((pure ((← readReg NUM_BREAKPOINTS) ≤b 16)) <&&> (do
         (pure ((← readReg NUM_WATCHPOINTS) ≤b 16)))))) : Bool)
  then (do writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 5 4 (_get_MDSELR_EL1_Type_BANK r)))
  else (do (pure ())))

def DBGDTR_EL0_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : DBGDTR_EL0_Type := value_name
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 32 32)))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 32 32)))
        else (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 32 32))))))
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 0 32)))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 0 32)))
        else (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 0 32))))))
  writeReg _DBGDTR_EL0 r

def Mk_ICV_EOIR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RNDRRS_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_LORN_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_IGRPEN0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SMPRIMAP_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMPRIMAP_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RNDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGRTR_EL2_Type_DCZID_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def Mk_ICV_IGRPEN1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGWTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SGI1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SRE_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HDFGWTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR_EL2_Type_OSLAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HDFGWTR_EL2_Type_PMCR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_HDFGWTR_EL2_Type_PMSWINC_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_HDFGWTR_EL2_Type_TRFCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def undefined_ICV_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICV_AP1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_LOREA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_DIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_DBGCLAIMCLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPMACCESSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __get_selected_SPMACCESSR_EL3_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL3) idx 2))

def __set_CNTHV_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHV_CTL_EL2_Type := value_name
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def Mk_ICC_EOIR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CNTVOFF_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _CNTVOFF ) : SailM CNTVOFF_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg CNTVOFF_EL2) 0 64)))

def undefined_CNTV_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def __set_MPAM2_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM2_EL2_Type := value_name
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 53 0 (BitVec.slice r 0 54))
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 62 55 (BitVec.slice r 55 8))
  (if ((! (HaveEL EL3)) : Bool)
  then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 63 63 (_get_MPAM2_EL2_Type_MPAMEN r)))
  else (do (pure ())))

def __set_MPAM3_EL3 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM3_EL3_Type := value_name
  (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 63 (← (MPAM3_EL3_read ())) 0 (BitVec.slice r 0 63))))
  (MPAM3_EL3_write (_update_MPAM3_EL3_Type_MPAMEN (← (MPAM3_EL3_read ())) (_get_MPAM3_EL3_Type_MPAMEN r)))

def __set_MPAM1_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM1_EL1_Type := value_name
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 54 (← (MPAM1_EL1_read ())) 0 (BitVec.slice r 0 54))))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 5 (← (MPAM1_EL1_read ())) 55 (BitVec.slice r 55 5))))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 2 (← (MPAM1_EL1_read ())) 61 (BitVec.slice r 61 2))))
  (if (((! (HaveEL EL3)) && (! (HaveEL EL2))) : Bool)
  then (do (MPAM1_EL1_write (_update_MPAM1_EL1_Type_MPAMEN (← (MPAM1_EL1_read ())) (_get_MPAM1_EL1_Type_MPAMEN r))))
  else (do (pure ())))

def undefined_AMEVCNTR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVCNTR1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVCNTR0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMCR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENSET0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENCLR0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENSET1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENCLR1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVCNTR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVCNTR0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 4 -/
def AMEVCNTR0_EL0_set (n : Nat) (value_name : (BitVec 64)) : SailM Unit := do
  let r : AMEVCNTR0_EL0_Type := value_name
  writeReg AMEVCNTR0 (vectorUpdate (← readReg AMEVCNTR0) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVCNTR0) n) 63 0 (BitVec.slice r 0 64)))
  writeReg _AMEVCNTR0_EL0 (vectorUpdate (← readReg _AMEVCNTR0_EL0) n r)

def Mk_AMUSERENR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVTYPER1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVTYPER1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_AMCGCR_EL0_Type_CG0NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def _get_AMCGCR_EL0_Type_CG1NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 15 8)

def __set_PMSNEVFR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMSNEVFR_EL1_Type := value_name
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 63 is not implemented, or filtering on event 63 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 63 63 (_get_PMSNEVFR_EL1_Type_E63 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 62 is not implemented, or filtering on event 62 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 62 62 (_get_PMSNEVFR_EL1_Type_E62 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 61 is not implemented, or filtering on event 61 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 61 61 (_get_PMSNEVFR_EL1_Type_E61 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 60 is not implemented, or filtering on event 60 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 60 60 (_get_PMSNEVFR_EL1_Type_E60 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 59 is not implemented, or filtering on event 59 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 59 59 (_get_PMSNEVFR_EL1_Type_E59 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 58 is not implemented, or filtering on event 58 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 58 58 (_get_PMSNEVFR_EL1_Type_E58 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 57 is not implemented, or filtering on event 57 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 57 57 (_get_PMSNEVFR_EL1_Type_E57 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 56 is not implemented, or filtering on event 56 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 56 56 (_get_PMSNEVFR_EL1_Type_E56 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 55 is not implemented, or filtering on event 55 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 55 55 (_get_PMSNEVFR_EL1_Type_E55 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 54 is not implemented, or filtering on event 54 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 54 54 (_get_PMSNEVFR_EL1_Type_E54 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 53 is not implemented, or filtering on event 53 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 53 53 (_get_PMSNEVFR_EL1_Type_E53 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 52 is not implemented, or filtering on event 52 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 52 52 (_get_PMSNEVFR_EL1_Type_E52 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 51 is not implemented, or filtering on event 51 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 51 51 (_get_PMSNEVFR_EL1_Type_E51 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 50 is not implemented, or filtering on event 50 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 50 50 (_get_PMSNEVFR_EL1_Type_E50 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 49 is not implemented, or filtering on event 49 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 49 49 (_get_PMSNEVFR_EL1_Type_E49 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 48 is not implemented, or filtering on event 48 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 48 48 (_get_PMSNEVFR_EL1_Type_E48 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 31 is not implemented, or filtering on event 31 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 31 31 (_get_PMSNEVFR_EL1_Type_E31 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 30 is not implemented, or filtering on event 30 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 30 30 (_get_PMSNEVFR_EL1_Type_E30 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 29 is not implemented, or filtering on event 29 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 29 29 (_get_PMSNEVFR_EL1_Type_E29 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 28 is not implemented, or filtering on event 28 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 28 28 (_get_PMSNEVFR_EL1_Type_E28 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 27 is not implemented, or filtering on event 27 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 27 27 (_get_PMSNEVFR_EL1_Type_E27 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 26 is not implemented, or filtering on event 26 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 26 26 (_get_PMSNEVFR_EL1_Type_E26 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 25 is not implemented, or filtering on event 25 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 25 25 (_get_PMSNEVFR_EL1_Type_E25 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 24 is not implemented, or filtering on event 24 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 24 24 (_get_PMSNEVFR_EL1_Type_E24 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 15 is not implemented, or filtering on event 15 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 15 15 (_get_PMSNEVFR_EL1_Type_E15 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 14 is not implemented, or filtering on event 14 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 14 14 (_get_PMSNEVFR_EL1_Type_E14 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 13 is not implemented, or filtering on event 13 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 13 13 (_get_PMSNEVFR_EL1_Type_E13 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 12 is not implemented, or filtering on event 12 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 12 12 (_get_PMSNEVFR_EL1_Type_E12 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  writeReg PMSNEVFR_EL1 r

def Mk_ERRSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ERXGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBINF_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBTGT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBSRC_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def __set_BRBSRCINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBSRCINJ_EL1_Type := value_name
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2)))))) : Bool)
  then (do writeReg BRBSRCINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBSRCINJ_EL1) 63 0 (_get_BRBSRCINJ_EL1_Type_ADDRESS r)))
  else (do (pure ())))

def __set_BRBINFINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBINFINJ_EL1_Type := value_name
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 4 0 (BitVec.slice r 0 5))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 15 14 (BitVec.slice r 14 2))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 31 18 (BitVec.slice r 18 14))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 63 47 (BitVec.slice r 47 17))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 46 46 (_get_BRBINFINJ_EL1_Type_CCU r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_CCU (← readReg BRBINFINJ_EL1)) == 1#1)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 45 32 (_get_BRBINFINJ_EL1_Type_CC r)))
  else (do (pure ())))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 17 17 (_get_BRBINFINJ_EL1_Type_LASTFAILED r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 16 16 (_get_BRBINFINJ_EL1_Type_T r)))
  else (do (pure ())))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 13 8 (_get_BRBINFINJ_EL1_Type_TYPE r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b10#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 7 6 (_get_BRBINFINJ_EL1_Type_EL r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2))) <||> (do
         (pure (((BitVec.access (_get_BRBINFINJ_EL1_Type_TYPE (← readReg BRBINFINJ_EL1)) 5) : BitVec 1) == 1#1)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 5 5 (_get_BRBINFINJ_EL1_Type_MPRED r)))
  else (do (pure ())))

def __set_BRBTGTINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBTGTINJ_EL1_Type := value_name
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b10#2)))))) : Bool)
  then (do writeReg BRBTGTINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBTGTINJ_EL1) 63 0 (_get_BRBTGTINJ_EL1_Type_ADDRESS r)))
  else (do (pure ())))

def undefined_DBGDTRTXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP1R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP0R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMINTENSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSECCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRTXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LRC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def __get_PMCCFILTR_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMCCFILTR_EL0_Type := value_name
  (Mk_PMCCFILTR_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFF020FFFFF#64)))

def __get_DCZID_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : DCZID_EL0_Type := value_name
  (Mk_DCZID_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFFFFFFFFE0#64)))

def __get_PMEVTYPER_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMEVTYPER_EL0_Type := value_name
  (Mk_PMEVTYPER_EL0_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0xBFFF000000F0000#60 64))))

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int -/
def AArch64_CheckNVCondsIfCurrentEL (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) : SailM Bool := do
  let is_reg_current_el : Bool := (((((op0 == 3) && (op1 == 0)) && (crn == 4)) && (crm == 2)) && (op2 == 2))
  let have_nv_trap_conds ← (( do (HaveNVExt ()) <&&> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((BitVec.slice (← readReg HCR_EL2) 42 1) == 1#1))) ) : SailM Bool )
  (pure (is_reg_current_el && have_nv_trap_conds))

def ConstrainUnpredictableProcedure (which : Unpredictable) : Unit :=
  ()

def ConsumptionOfSpeculativeDataBarrier (_ : Unit) : Unit :=
  ()

def Hint_CLRBHB (_ : Unit) : Unit :=
  ()

def Hint_DGH (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: count : Int, length : Int, reuse : Int, stride : Int -/
def Hint_RangePrefetch (address : (BitVec 64)) (length : Int) (stride : Int) (count : Int) (reuse : Int) (operation : (BitVec 6)) : Unit :=
  ()

def Hint_Yield (_ : Unit) : Unit :=
  ()

def ProfilingSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def SendEvent (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToPA (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToVA (_ : Unit) : Unit :=
  ()

def AArch64_PendingUnmaskedVirtualInterrupts (mask_in : (BitVec 3)) : SailM (Bool × Bool × Bool) := do
  let allintmask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let mask : (BitVec 3) := mask_in
  let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  let (mask, pending) ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
         (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
    then
      (do let pending ← (pure (((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_VI (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_VF (← readReg HCR_EL2)))) &&& ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))))))
          let mask ← (( do
            (if ((←((HaveFeatNMI ()) <&&> (do
                 (pure ((_get_SCTLRType_NMI (← (SCTLR_read__1 ()))) == 1#1))))) : Bool)
            then
              (do let allintmask ← (( do (pure ((← readReg PSTATE).ALLINT ||| ((← readReg PSTATE).SP &&& (_get_SCTLRType_SPINTMASK (← (SCTLR_read__1 ())))))) ) : SailM (BitVec 1) )
                  let mask ← (( do
                    (if ((←((IsHCRXEL2Enabled ()) <&&> (do
                         (pure (((← readReg PSTATE).EL == EL0) || (allintmask == 0#1)))))) : Bool)
                    then
                      (do let mask ← (( do
                            (if (((_get_HCRX_EL2_Type_VFNMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                            then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                            else (do (pure mask))) ) : SailM (BitVec 3) )
                          (if (((_get_HCRX_EL2_Type_VINMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 1 (Bit 0#1))))
                          else (do (pure mask))))
                    else (do (pure mask))) ) : SailM (BitVec 3) )
                  (if ((((← readReg PSTATE).EL == EL1) && (allintmask == 1#1)) : Bool)
                  then
                    (do let mask ← (( do
                          (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                          else (do (pure mask))) ) : SailM (BitVec 3) )
                        (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                        else (do (pure mask))))
                  else (do (pure mask))))
            else (do (pure mask))) ) : SailM (BitVec 3) )
          (pure (mask, pending)))
    else
      (do let pending : (BitVec 3) := 0b000#3
          (pure (mask, pending)))) ) : SailM ((BitVec 3) × (BitVec 3)) )
  let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
  (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))

def AArch32_PendingUnmaskedVirtualInterrupts (_ : Unit) : SailM (Bool × Bool × Bool) := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL2))))) <||> (do
       (pure (HaveEL EL3)) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3)))))))) : Bool)
  then (do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
  else
    (do let mask ← (( do (pure ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))) ) : SailM (BitVec 3) )
        let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
        let pending ← (( do
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1))))) : Bool)
          then (do (pure (((_get_HCR_Type_VA (← (HCR_read ()))) +++ ((_get_HCR_Type_VI (← (HCR_read ()))) +++ (_get_HCR_Type_VF (← (HCR_read ()))))) &&& ((_get_HCR_Type_AMO (← (HCR_read ()))) +++ ((_get_HCR_Type_IMO (← (HCR_read ()))) +++ (_get_HCR_Type_FMO (← (HCR_read ()))))))))
          else (do (pure 0b000#3))) ) : SailM (BitVec 3) )
        let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
        (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))))

def TakePendingInterrupts (interrupt_req : InterruptReq) : SailM Bool := do
  let interrupt_pend ← (( do (undefined_bool ()) ) : SailM Bool )
  let interrupt_taken ← (( do (undefined_bool ()) ) : SailM Bool )
  let vAA ← (( do (undefined_bool ()) ) : SailM Bool )
  let vIRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let vSE ← (( do (undefined_bool ()) ) : SailM Bool )
  let vFIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let AA ← (( do (undefined_bool ()) ) : SailM Bool )
  let IRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let FIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let SE ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let (vAA, vFIQ, vIRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedVirtualInterrupts ())
          let vAA : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vAA, vFIQ, vIRQ)) ) : SailM (Bool × Bool × Bool) )
        let (AA, FIQ, IRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedPhysicalInterrupts ())
          let AA : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (AA, FIQ, IRQ)) ) : SailM (Bool × Bool × Bool) )
        let AA : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else AA
        let vAA : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vAA
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let interrupt_taken : Bool :=
          if ((((((AA || FIQ) || IRQ) || vAA) || vFIQ) || vIRQ) : Bool)
          then true
          else false
        (if (vFIQ : Bool)
        then (do (AArch32_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch32_TakeVirtualIRQException ()))
              else
                (do (if (vAA : Bool)
                    then (do (AArch32_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch32_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch32_TakePhysicalIRQException ()))
                                else
                                  (do (if (AA : Bool)
                                      then (do (AArch32_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken))
  else
    (do let (vFIQ, vIRQ, vSE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let vSE : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
        let (FIQ, IRQ, SE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let SE : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
        let SE : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else SE
        let vSE : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vSE
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE) ← (( do
          (if ((((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ) : Bool)
          then
            (do let (FIQ, IRQ, SE, vFIQ, vIRQ, vSE) ← (( do
                  (if ((←((HaveTME ()) <&&> (do
                       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
                  then
                    (do let (vFIQ, vIRQ, vSE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let vSE : Bool := tup__0
                          let vIRQ : Bool := tup__1
                          let vFIQ : Bool := tup__2
                          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
                        let (FIQ, IRQ, SE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let SE : Bool := tup__0
                          let IRQ : Bool := tup__1
                          let FIQ : Bool := tup__2
                          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
                        let SE : Bool :=
                          if ((! interrupt_req.take_SE) : Bool)
                          then false
                          else SE
                        let vSE : Bool :=
                          if ((! interrupt_req.take_vSE) : Bool)
                          then false
                          else vSE
                        let IRQ : Bool :=
                          if ((! interrupt_req.take_IRQ) : Bool)
                          then false
                          else IRQ
                        let vIRQ : Bool :=
                          if ((! interrupt_req.take_vIRQ) : Bool)
                          then false
                          else vIRQ
                        let FIQ : Bool :=
                          if ((! interrupt_req.take_FIQ) : Bool)
                          then false
                          else FIQ
                        let vFIQ : Bool :=
                          if ((! interrupt_req.take_vFIQ) : Bool)
                          then false
                          else vFIQ
                        let interrupt_pend : Bool := (((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ)
                        (FailTransaction__1 TMFailure_IMP interrupt_pend (! interrupt_pend) (Zeros (n := 15)))
                        (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))
                  else (do (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool) )
                let interrupt_taken : Bool := true
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))
          else
            (do let interrupt_taken : Bool := false
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool × Bool) )
        (if (vFIQ : Bool)
        then (do (AArch64_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch64_TakeVirtualIRQException ()))
              else
                (do (if (vSE : Bool)
                    then (do (AArch64_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch64_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch64_TakePhysicalIRQException ()))
                                else
                                  (do (if (SE : Bool)
                                      then (do (AArch64_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken)))

def TakeUnmaskedSErrorInterrupts (_ : Unit) : SailM Unit := do
  let interrupt_req ← (( do (undefined_InterruptReq ()) ) : SailM InterruptReq )
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_FIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vFIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_IRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vIRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with iesb_req := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := true }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := true }
  let interrupt_taken ← (( do (TakePendingInterrupts interrupt_req) ) : SailM Bool )
  (pure ())

def HaveFP16Ext (_ : Unit) : Bool :=
  true

def ExclusiveMonitorsStatus (_ : Unit) : (BitVec 1) :=
  0#1

/-- Type quantifiers: Rt : Int, k_acq_rel : Bool, k_sign_extend : Bool, k_sixty_four : Bool, size : Int -/
def AArch64_SetLSInstructionSyndrome (size : Int) (sign_extend : Bool) (Rt : Int) (sixty_four : Bool) (acq_rel : Bool) : Unit :=
  ()

def DataMemoryBarrier (domain : MBReqDomain) (types : MBReqTypes) : SailM Unit := do
  (sail_barrier
    (Barrier_DMB
      { domain := domain
        types := types
        nXS := false }))

/-- Type quantifiers: k_nXS : Bool -/
def DataSynchronizationBarrier (domain : MBReqDomain) (types : MBReqTypes) (nXS : Bool) : SailM Unit := do
  (sail_barrier
    (Barrier_DSB
      { domain := domain
        types := types
        nXS := nXS }))

def InstructionSynchronizationBarrier (_ : Unit) : SailM Unit := do
  (sail_barrier (Barrier_ISB ()))

/-- Type quantifiers: t : Int -/
def DCZID_EL0_SysRegRead_9bb2971f34b1558f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_DCZID_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_DCZID_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL0_SysRegRead_512297cd575d98fa (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_TPIDR_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_TPIDR_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (← readReg TPIDR_EL0)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (← readReg TPIDR_EL0)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (← readReg TPIDR_EL0)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (← readReg TPIDR_EL0)))
                    else (do (pure ())))))))))


end ArmASL.Functions
