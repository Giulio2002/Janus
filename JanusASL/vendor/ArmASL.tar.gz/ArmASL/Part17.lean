import ArmASL.Part16

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def _update_PRRR_Type_DS0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _update_PRRR_Type_DS1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _update_PRRR_Type_NS0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_PRRR_Type_NS1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def AArch32_IMPDEFResets (_ : Unit) : SailM Unit := do
  (PMCR_write (_update_PMCR_Type_IMP (← (PMCR_read ())) (Zeros (n := 8))))
  (PMCR_write
    (_update_PMCR_Type_IDCODE (← (PMCR_read ()))
      (← do
        (if ((IsZero (_get_PMCR_Type_IMP (← (PMCR_read ())))) : Bool)
        then (do (pure (Zeros (n := 8))))
        else (do (pure CFG_PMCR_IDCODE))))))
  (PMCR_write (_update_PMCR_Type_N (← (PMCR_read ())) (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  (PMCR_write (_update_PMCR_Type_C (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_P (← (PMCR_read ())) 0#1))
  (PMCEID0_write (Mk_PMCEID0_Type 0b01001000000000100000000100000001#32))
  (PMCEID2_write (Mk_PMCEID2_Type (Sail.BitVec.zeroExtend 0b1111#4 32)))
  (PMCEID1_write (Mk_PMCEID1_Type (Zeros (n := 32))))
  (PMCEID3_write (Mk_PMCEID3_Type (Zeros (n := 32))))
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 31 28 0b0000#4)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 21 21 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 19 19 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 18 18 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 17 17 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 16 16 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 15 15 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 14 14 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 13 8 0b111111#6)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 7 0 (0b000#3 +++ (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 7 4 0b0001#4)
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 3 0 0b0110#4)
  writeReg PMPIDR0 (Sail.BitVec.updateSubrange (← readReg PMPIDR0) 7 0 0b00001111#8)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 7 4 0b1011#4)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 3 0 0b1101#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 7 4 0b0000#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 3 3 1#1)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 2 0 0b011#3)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 7 4 0b0000#4)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 3 0 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 7 4 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 3 0 0b0100#4)
  writeReg PMCIDR0 (Sail.BitVec.updateSubrange (← readReg PMCIDR0) 7 0 0b00001101#8)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 7 4 0b1001#4)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 3 0 0b0000#4)
  writeReg PMCIDR2 (Sail.BitVec.updateSubrange (← readReg PMCIDR2) 7 0 0b00000101#8)
  writeReg PMCIDR3 (Sail.BitVec.updateSubrange (← readReg PMCIDR3) 7 0 0b10110001#8)
  writeReg VBAR_S (Sail.BitVec.updateSubrange (← readReg VBAR_S) 31 5 (Zeros (n := 27)))
  (CCSIDR_write (_update_CCSIDR_Type_Associativity (← (CCSIDR_read ())) (Sail.BitVec.zeroExtend 0x1#4 21)))
  (CCSIDR_write (_update_CCSIDR_Type_LineSize (← (CCSIDR_read ())) 0b010#3))
  (CLIDR_write (_update_CLIDR_Type_ICB (← (CLIDR_read ())) 0b00#2))
  (CLIDR_write (_update_CLIDR_Type_LoUU (← (CLIDR_read ())) 0b000#3))
  (CLIDR_write (_update_CLIDR_Type_LoUIS (← (CLIDR_read ())) 0b000#3))
  (CLIDR_write (Mk_CLIDR_Type (Sail.BitVec.updateSubrange (← (CLIDR_read ())) 20 0 0b000000000000000100011#21)))
  (CTR_write (_update_CTR_Type_DIC (← (CTR_read ())) 0#1))
  (CTR_write (_update_CTR_Type_IDC (← (CTR_read ())) 0#1))
  (CTR_write (_update_CTR_Type_CWG (← (CTR_read ())) 0b0100#4))
  (CTR_write (_update_CTR_Type_ERG (← (CTR_read ())) (← readReg __exclusive_granule_size)))
  (CTR_write (_update_CTR_Type_DminLine (← (CTR_read ())) 0b0100#4))
  (CTR_write (_update_CTR_Type_L1Ip (← (CTR_read ())) 0b10#2))
  (CTR_write (_update_CTR_Type_IminLine (← (CTR_read ())) 0b0100#4))
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 31 24 0b01000001#8)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 23 23 0#1)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 22 16 0b0000100#7)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 15 8 0b00110000#8)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 7 4 0b0111#4)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 3 0 0b0000#4)
  (ID_DFR0_write (_update_ID_DFR0_Type_MProfDbg (← (ID_DFR0_read ())) 0b0000#4))
  (ID_DFR0_write (_update_ID_DFR0_Type_MMapDbg (← (ID_DFR0_read ())) 0b0000#4))
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
  then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
  else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())))))))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Divide (← (ID_ISAR0_read ())) 0b0010#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Debug (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Coproc (← (ID_ISAR0_read ())) 0b0000#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_CmpBranch (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_BitField (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_BitCount (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Swap (← (ID_ISAR0_read ())) 0b0000#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Jazelle (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Interwork (← (ID_ISAR1_read ())) 0b0011#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Immediate (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_IfThen (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Extend (← (ID_ISAR1_read ())) 0b0010#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Except_AR (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Except (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Endian (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_Reversal (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_PSR_AR (← (ID_ISAR2_read ())) 0b0001#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultU (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultS (← (ID_ISAR2_read ())) 0b0011#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_Mult (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultiAccessInt (← (ID_ISAR2_read ())) 0b0000#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MemHint (← (ID_ISAR2_read ())) 0b0100#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_LoadStore (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_T32EE (← (ID_ISAR3_read ())) 0b0000#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_TrueNOP (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_T32Copy (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_TabBranch (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SynchPrim (← (ID_ISAR3_read ())) 0b0010#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SVC (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SIMD (← (ID_ISAR3_read ())) 0b0011#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_Saturate (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SWP_frac (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_PSR_M (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SynchPrim_frac (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Barrier (← (ID_ISAR4_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SMC (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Writeback (← (ID_ISAR4_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_WithShifts (← (ID_ISAR4_read ())) 0b0100#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Unpriv (← (ID_ISAR4_read ())) 0b0010#4))
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 7 4 0b0001#4)
  (ID_ISAR5_write (_update_ID_ISAR5_Type_VCMA (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_RDM (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_CRC32 (← (ID_ISAR5_read ())) 0b0000#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SHA2 (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SHA1 (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_AES (← (ID_ISAR5_read ())) 0b0010#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SEVL (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_DP (← (ID_ISAR6_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_BF16 (← (ID_ISAR6_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_I8MM (← (ID_ISAR6_read ())) 0b0001#4))
  (if ((← (IsFeatureImplemented FEAT_FP16)) : Bool)
  then
    (do (MVFR1_write (_update_MVFR1_Type_FPHP (← (MVFR1_read ())) 0b0011#4))
        (MVFR1_write (_update_MVFR1_Type_SIMDHP (← (MVFR1_read ())) 0b0010#4)))
  else
    (do (MVFR1_write (_update_MVFR1_Type_FPHP (← (MVFR1_read ())) 0b0010#4))
        (MVFR1_write (_update_MVFR1_Type_SIMDHP (← (MVFR1_read ())) 0b0001#4))))
  (if ((HasArchVersion v8Ap3) : Bool)
  then
    (do (ID_MMFR4_write (_update_ID_MMFR4_Type_CCIDX (← (ID_MMFR4_read ())) 0b0001#4))
        (ID_ISAR6_write (_update_ID_ISAR6_Type_JSCVT (← (ID_ISAR6_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_TraceFilt (← (ID_DFR0_read ())) 0b0001#4)))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then
    (do writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 39 36 0b0001#4)
        (ID_ISAR6_write (_update_ID_ISAR6_Type_FHM (← (ID_ISAR6_read ())) 0b0001#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_AMU (← (ID_PFR0_read ())) 0b0001#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_DIT (← (ID_PFR0_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1001#4))
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
        else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap7) : Bool)
  then (do (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b0111#4)))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do (ID_MMFR5_write (_update_ID_MMFR5_Type_ETS (← (ID_MMFR5_read ())) 0b0010#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1010#4))
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
        else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ()))))))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap6) : Bool)
  then
    (do (ID_PFR1_write (_update_ID_PFR1_Type_GenTimer (← (ID_PFR1_read ())) 0b0010#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_AMU (← (ID_PFR0_read ())) 0b0010#4)))
  else (do (pure ())))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_InnerShr (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_FCSE (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_AuxReg (← (ID_MMFR0_read ())) 0b0010#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_TCM (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_ShareLvl (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_OuterShr (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_PMSA (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_VMSA (← (ID_MMFR0_read ())) 0b0101#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_BPred (← (ID_MMFR1_read ())) 0b0010#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1TstCln (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1Uni (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1Hvd (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1UniSW (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1HvdSW (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1UniVA (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1HvdVA (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_HWAccFlg (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_WFIStall (← (ID_MMFR2_read ())) 0b0001#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_MemBarr (← (ID_MMFR2_read ())) 0b0010#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_UniTLB (← (ID_MMFR2_read ())) 0b0110#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_HvdTLB (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdRng (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdBG (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdFG (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_Supersec (← (ID_MMFR3_read ())) 0b0000#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMemSz (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CohWalk (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_PAN (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_MaintBcst (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_BPMaint (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMaintSW (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMaintVA (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_RAS (← (ID_PFR0_read ())) 0b0010#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State3 (← (ID_PFR0_read ())) 0b0000#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State2 (← (ID_PFR0_read ())) 0b0001#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State1 (← (ID_PFR0_read ())) 0b0011#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State0 (← (ID_PFR0_read ())) 0b0001#4))
  (ID_DFR1_write (_update_ID_DFR1_Type_MTPMU (← (ID_DFR1_read ())) 0b0001#4))
  (if ((HasArchVersion v8Ap5) : Bool)
  then
    (do (ID_PFR0_write (_update_ID_PFR0_Type_CSV2 (← (ID_PFR0_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b0110#4)))
  else (do (pure ())))
  (ID_DFR0_write (_update_ID_DFR0_Type_MMapTrc (← (ID_DFR0_read ())) 0b0001#4))
  (ID_DFR0_write (_update_ID_DFR0_Type_CopTrc (← (ID_DFR0_read ())) 0b0001#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_GIC (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Virt_frac (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Sec_frac (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_MProgMod (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_ProgMod (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Security (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Virtualization (← (ID_PFR1_read ())) 0b0000#4))
  (MIDR_write (_update_MIDR_Type_Implementer (← (MIDR_read ())) 0b01000001#8))
  (MIDR_write (_update_MIDR_Type_Variant (← (MIDR_read ())) 0b0000#4))
  (MIDR_write (_update_MIDR_Type_Architecture (← (MIDR_read ())) 0b1111#4))
  (MIDR_write (_update_MIDR_Type_PartNum (← (MIDR_read ())) 0b110100001111#12))
  (MIDR_write (_update_MIDR_Type_Revision (← (MIDR_read ())) 0b0000#4))
  (VPIDR_write (_update_VPIDR_Type_Implementer (← (VPIDR_read ())) 0b01000001#8))
  (VPIDR_write (_update_VPIDR_Type_Variant (← (VPIDR_read ())) 0b0000#4))
  (VPIDR_write (_update_VPIDR_Type_Architecture (← (VPIDR_read ())) 0b1111#4))
  (VPIDR_write (_update_VPIDR_Type_PartNum (← (VPIDR_read ())) 0b110100001111#12))
  (VPIDR_write (_update_VPIDR_Type_Revision (← (VPIDR_read ())) 0b0000#4))
  (MPIDR_write (_update_MPIDR_Type_M (← (MPIDR_read ())) 1#1))
  (MPIDR_write (_update_MPIDR_Type_U (← (MPIDR_read ())) 0#1))
  (MPIDR_write (_update_MPIDR_Type_MT (← (MPIDR_read ())) 0#1))
  (MPIDR_write (_update_MPIDR_Type_Aff2 (← (MPIDR_read ())) 0b00000000#8))
  (MPIDR_write (_update_MPIDR_Type_Aff1 (← (MPIDR_read ())) 0b00000000#8))
  (MPIDR_write (_update_MPIDR_Type_Aff0 (← (MPIDR_read ())) 0b00000000#8))
  (MVFR0_write (_update_MVFR0_Type_FPRound (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPShVec (← (MVFR0_read ())) 0b0000#4))
  (MVFR0_write (_update_MVFR0_Type_FPSqrt (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPDivide (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPTrap (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPDP (← (MVFR0_read ())) 0b0010#4))
  (MVFR0_write (_update_MVFR0_Type_FPSP (← (MVFR0_read ())) 0b0010#4))
  (MVFR0_write (_update_MVFR0_Type_SIMDReg (← (MVFR0_read ())) 0b0010#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDFMAC (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDSP (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDInt (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDLS (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_FPDNaN (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_FPFtZ (← (MVFR1_read ())) 0b0001#4))
  (MVFR2_write (_update_MVFR2_Type_FPMisc (← (MVFR2_read ())) 0b0100#4))
  (MVFR2_write (_update_MVFR2_Type_SIMDMisc (← (MVFR2_read ())) 0b0011#4))
  writeReg TLBTR (Sail.BitVec.updateSubrange (← readReg TLBTR) 0 0 0#1)
  (HSCTLR_write (_update_HSCTLR_Type_EE (← (HSCTLR_read ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_TE (← (SCTLR_read__2 ())) (_get_Configuration_Type_ExceptInit (← readReg _ConfigReg))))
  (SCTLR_write (_update_SCTLR_Type_EE (← (SCTLR_read__2 ())) (_get_Configuration_Type_CFGEND (← readReg _ConfigReg))))
  (SCTLR_write (_update_SCTLR_Type_SPAN (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_V (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_UNK (← (SCTLR_read__2 ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_EX (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_FP2V (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_VV (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_TFV (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_VECITR (← (FPEXC_read ())) 0b111#3))
  (HTCR_write (_update_HTCR_Type_HWU62 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU61 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU60 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU59 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HPD (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_SH0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_ORGN0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_IRGN0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_T0SZ (← (HTCR_read ())) 0b000#3))
  (NMRR_write (Mk_NMRR_Type (Sail.BitVec.updateSubrange (← (NMRR_read ())) 31 16 0b0100010011100000#16)))
  (NMRR_write (Mk_NMRR_Type (Sail.BitVec.updateSubrange (← (NMRR_read ())) 15 0 0b0100100011100000#16)))
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 11 11 0#1)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 10 10 0#1)
  (PRRR_write (Mk_PRRR_Type (Sail.BitVec.updateSubrange (← (PRRR_read ())) 31 24 (Zeros (n := 8)))))
  (PRRR_write (_update_PRRR_Type_NS1 (← (PRRR_read ())) 1#1))
  (PRRR_write (_update_PRRR_Type_NS0 (← (PRRR_read ())) 0#1))
  (PRRR_write (_update_PRRR_Type_DS1 (← (PRRR_read ())) 0#1))
  (PRRR_write (_update_PRRR_Type_DS0 (← (PRRR_read ())) 1#1))
  (PRRR_write (Mk_PRRR_Type (Sail.BitVec.updateSubrange (← (PRRR_read ())) 15 0 0b1000101010100100#16)))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 31 28 (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 27 24 (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 23 20 (integer_subrange ((← readReg __num_ctx_breakpoints) -i 1) 3 0))
  (if ((HasArchVersion v8Ap2) : Bool)
  then (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1000#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1010#4)
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b1000#4)))
  else (do (pure ())))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 14 14 1#1)
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 12 12 1#1)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 7 4 0b0001#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 11 8 0b1111#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 15 12 0b0000#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 19 16 0b0001#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 27 24 0b0001#4)
  (HDCR_write (_update_HDCR_Type_HPMN (← (HDCR_read ())) (_get_PMCR_Type_N (← (PMCR_read ())))))
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 0 0 1#1)
  (ICC_HSRE_write (_update_ICC_HSRE_Type_SRE (← (ICC_HSRE_read ())) 1#1))
  writeReg JMCR (Zeros (n := 32))
  writeReg JOSCR (Zeros (n := 32))
  writeReg JIDR (Zeros (n := 32))
  (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLM (← (DBGOSLSR_read ())) 0b10#2))
  (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLK (← (DBGOSLSR_read ())) 1#1))
  (HCPTR_write (_update_HCPTR_Type_TCPAC (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TTA (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TASE (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TCP11 (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TCP10 (← (HCPTR_read ())) 0#1))
  (if ((HasArchVersion v9Ap4) : Bool)
  then
    (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b1011#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1011#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b1001#4))
        (ID_ISAR6_write (_update_ID_ISAR6_Type_SPECRES (← (ID_ISAR6_read ())) 0b0010#4))
        (ID_ISAR6_write (Mk_ID_ISAR6_Type (Sail.BitVec.updateSubrange (← (ID_ISAR6_read ())) 31 28 0b0001#4)))
        writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1011#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4))
  else (do (pure ())))

def undefined_ACCDATA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCG1IDR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBINFINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHPS_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHP_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHVS_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHV_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTPS_TVAL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_TVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_TVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DACR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DCZID_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GMID_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HAFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGRTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGWTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGWTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGRTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGWTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGWTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_CTLR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN1_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_NMIAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SRE_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_NMIAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64SMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ZFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORC_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LOREA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORID_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORN_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORSA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MDSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MECIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_OSLAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMBIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMECR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMMIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSEVFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSFCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSICR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSIRR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSLATFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSNEVFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMUACR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMXEVCNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMZR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SMIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SMPRI_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SPMSELR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_BPR1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_BPR1_EL1_Type ()) ) : SailM ICC_BPR1_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_BPR1_EL1_S)
  else (do readReg ICC_BPR1_EL1_NS))

def ICC_BPR1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_BPR1_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_BPR1_EL1_S r)
  else (do writeReg ICC_BPR1_EL1_NS r))

def ICC_CTLR_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_CTLR_EL1_Type ()) ) : SailM ICC_CTLR_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_CTLR_EL1_S)
  else (do readReg ICC_CTLR_EL1_NS))

def ICC_CTLR_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_CTLR_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_CTLR_EL1_S r)
  else (do writeReg ICC_CTLR_EL1_NS r))

def ICC_IGRPEN1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_IGRPEN1_EL1_Type ()) ) : SailM ICC_IGRPEN1_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_IGRPEN1_EL1_S)
  else (do readReg ICC_IGRPEN1_EL1_NS))

def ICC_IGRPEN1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_IGRPEN1_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_IGRPEN1_EL1_S r)
  else (do writeReg ICC_IGRPEN1_EL1_NS r))

def ICC_SRE_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_SRE_EL1_Type ()) ) : SailM ICC_SRE_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_SRE_EL1_S)
  else (do readReg ICC_SRE_EL1_NS))

def ICC_SRE_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SRE_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_SRE_EL1_S r)
  else (do writeReg ICC_SRE_EL1_NS r))

def MPAM3_EL3_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM3_EL3_Type := value_name
  writeReg MPAM2_EL2 (BitVec.update (← readReg MPAM2_EL2) 63 (Bit (BitVec.slice r 63 1)))
  writeReg _MPAM3_EL3 r

def MPAM1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM1_EL1_Type := value_name
  (if ((HaveEL EL3) : Bool)
  then (do (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 1 (← (MPAM3_EL3_read ())) 63 (BitVec.slice r 63 1)))))
  else (do writeReg MPAM2_EL2 (BitVec.update (← readReg MPAM2_EL2) 63 (Bit (BitVec.slice r 63 1)))))
  writeReg _MPAM1_EL1 r

def Mk_ICC_BPR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_CTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_IGRPEN1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SRE_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PAR_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def undefined_PAR_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def PAR_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _PAR_EL1 ) : SailM PAR_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (PAR_read ())) 0 64)))

def PAR_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : PAR_EL1_Type := value_name
  (PAR_write (Mk_PAR_Type (set_slice 64 (← (PAR_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _PAR_EL1 r

def TTBR0_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR0_EL1_Type := value_name
  (TTBR0_write (Mk_TTBR0_Type (set_slice 64 (← (TTBR0_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _TTBR0_EL1 r

def TTBR0_EL2_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR0_EL2_Type := value_name
  writeReg HTTBR (Sail.BitVec.updateSubrange (← readReg HTTBR) 47 1 (BitVec.slice r 1 47))
  writeReg _TTBR0_EL2 r

def TTBR1_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR1_EL1_Type := value_name
  (TTBR1_write (Mk_TTBR1_Type (set_slice 64 (← (TTBR1_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _TTBR1_EL1 r

def VTTBR_EL2_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : VTTBR_EL2_Type := value_name
  writeReg VTTBR (Sail.BitVec.updateSubrange (← readReg VTTBR) 63 0 (BitVec.slice r 0 64))
  writeReg _VTTBR_EL2 r

def _update_ICC_IGRPEN1_EL1_Type_Enable (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICC_SRE_EL1_Type_DFB (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICC_SRE_EL1_Type_DIB (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICC_SRE_EL1_Type_SRE (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

/-- Type quantifiers: k_cold : Bool -/
def AArch64_AutoGen_ArchitectureReset (cold : Bool) : SailM Unit := do
  writeReg ID_MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR2_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR2_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 47 44 0b0000#4)
  writeReg VTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VTCR_EL2) 63 45 0b0000000000000000000#19)
  writeReg VTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VTCR_EL2) 43 42 0b00#2)
  writeReg VTCR_EL2 (BitVec.update (← readReg VTCR_EL2) 39 (Bit 0#1))
  writeReg VTCR_EL2 (BitVec.update (← readReg VTCR_EL2) 31 (Bit 1#1))
  writeReg VTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VTCR_EL2) 24 23 0b00#2)
  writeReg VTCR_EL2 (BitVec.update (← readReg VTCR_EL2) 20 (Bit 0#1))
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 63 63 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 62 62 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 61 61 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 60 60 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 59 59 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 58 58 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 57 57 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 56 49 0b00000000#8)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 48 48 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 47 47 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 46 46 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 45 45 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 44 44 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 43 43 0#1)
  writeReg HDFGRTR_EL2 (BitVec.update (← readReg HDFGRTR_EL2) 42 (Bit 0#1))
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 41 41 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 40 40 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 39 38 0b00#2)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 37 37 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 36 36 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 35 35 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 34 34 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 33 33 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 32 32 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 31 31 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 30 30 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 29 29 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 28 28 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 27 27 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 26 26 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 25 25 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 24 24 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 23 23 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 22 22 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 21 20 0b00#2)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 19 19 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 18 18 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 17 17 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 16 16 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 15 15 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 14 14 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 13 13 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 12 12 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 11 11 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 10 10 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 9 9 0#1)
  writeReg HDFGRTR_EL2 (BitVec.update (← readReg HDFGRTR_EL2) 8 (Bit 0#1))
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 7 7 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 6 6 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 5 5 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 4 4 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 3 3 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 2 2 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 1 1 0#1)
  writeReg HDFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR_EL2) 0 0 0#1)
  writeReg ICV_NMIAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_NMIAR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 63 32 0b00000000000000000000000000000000#32)
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 63 31 0b000000000000000000000000000000000#33)
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 30 30 0#1)
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 29 29 0#1)
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 28 0 0b00000000000000000000000000000#29)
  writeReg MVFR0_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR0_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg MVFR0_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg ICC_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 63 13 0b000000000000000000000000000000000000000000000000000#51)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 12 12 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 12 12 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 11 11 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 11 11 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 10 10 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 10 10 (← (__UNKNOWN_bits 1)))))
  writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 9 5 0b00000#5)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 4 4 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 3 3 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  writeReg TCR2_EL2 (BitVec.update (← readReg TCR2_EL2) 2 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 1 1 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 0 0 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 13 13 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 13 13 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 12 12 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 12 12 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 11 11 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 11 11 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 10 10 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 10 10 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 9 8 0b00#2))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 9 8 (← (__UNKNOWN_bits 2)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 7 6 0b00#2))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 7 6 (← (__UNKNOWN_bits 2)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 5 5 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 5 5 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 4 4 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 3 3 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 2 2 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 1 1 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 0 0 0#1))
  else (do writeReg TCR2_EL2 (Sail.BitVec.updateSubrange (← readReg TCR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg ESR_EL1 (Sail.BitVec.updateSubrange (← readReg ESR_EL1) 63 56 0b00000000#8)
  writeReg ICV_BPR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR1_EL1) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg TCR_EL3 (Sail.BitVec.updateSubrange (← readReg TCR_EL3) 63 44 0b00000000000000000000#20)
  writeReg TCR_EL3 (Sail.BitVec.updateSubrange (← readReg TCR_EL3) 40 39 0b00#2)
  writeReg TCR_EL3 (BitVec.update (← readReg TCR_EL3) 31 (Bit 1#1))
  writeReg TCR_EL3 (BitVec.update (← readReg TCR_EL3) 23 (Bit 1#1))
  writeReg TCR_EL3 (BitVec.update (← readReg TCR_EL3) 19 (Bit 0#1))
  writeReg TCR_EL3 (Sail.BitVec.updateSubrange (← readReg TCR_EL3) 7 6 0b00#2)
  writeReg ID_ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR2_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR2_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg PMECR_EL1 (Sail.BitVec.updateSubrange (← readReg PMECR_EL1) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  (if ((cold && true) : Bool)
  then (do writeReg PMECR_EL1 (Sail.BitVec.updateSubrange (← readReg PMECR_EL1) 4 3 (← (__UNKNOWN_bits 2))))
  else
    (do (if (((cold && (! (HaveEL EL3))) && (! (HaveEL EL2))) : Bool)
        then (do writeReg PMECR_EL1 (Sail.BitVec.updateSubrange (← readReg PMECR_EL1) 4 3 0b00#2))
        else (do (pure ())))))
  writeReg ICC_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_PMR_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ICC_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_PMR_EL1) 7 0 0b00000000#8)
  writeReg ICV_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg RMR_EL1 (Sail.BitVec.updateSubrange (← readReg RMR_EL1) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg RMR_EL1 (Sail.BitVec.updateSubrange (← readReg RMR_EL1) 1 1 0#1)
  writeReg OSLAR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLAR_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg PMICFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMICFILTR_EL0) 63 59 0b00000#5)
  writeReg PMICFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMICFILTR_EL0) 57 32 0b00000000000000000000000000#26)
  writeReg PMICFILTR_EL0 (BitVec.update (← readReg PMICFILTR_EL0) 25 (Bit 0#1))
  writeReg PMICFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMICFILTR_EL0) 19 16 0b0000#4)
  writeReg ICC_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg VMECID_A_EL2 (Sail.BitVec.updateSubrange (← readReg VMECID_A_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg MECID_RL_A_EL3 (Sail.BitVec.updateSubrange (← readReg MECID_RL_A_EL3) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 63 16 (Sail.BitVec.extractLsb 0b00000000000000000000000000000000000000000000000000#50 49 2))
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 14 14 (Sail.BitVec.extractLsb 0b00000000000000000000000000000000000000000000000000#50 1 1))
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 4 4 (Sail.BitVec.extractLsb 0b00000000000000000000000000000000000000000000000000#50 0 0))
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg PMOVSCLR_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSCLR_EL0) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMOVSCLR_EL0 (BitVec.update (← readReg PMOVSCLR_EL0) 32 (Bit 0#1))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 63 50 0b00000000000000#14)
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 49 49 (Sail.BitVec.extractLsb 0b0000000000000000#16 15 15))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 47 47 (Sail.BitVec.extractLsb 0b0000000000000000#16 14 14))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 45 45 (Sail.BitVec.extractLsb 0b0000000000000000#16 13 13))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 43 43 (Sail.BitVec.extractLsb 0b0000000000000000#16 12 12))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 41 41 (Sail.BitVec.extractLsb 0b0000000000000000#16 11 11))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 39 39 (Sail.BitVec.extractLsb 0b0000000000000000#16 10 10))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 37 37 (Sail.BitVec.extractLsb 0b0000000000000000#16 9 9))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 35 35 (Sail.BitVec.extractLsb 0b0000000000000000#16 8 8))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 33 33 (Sail.BitVec.extractLsb 0b0000000000000000#16 7 7))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 31 31 (Sail.BitVec.extractLsb 0b0000000000000000#16 6 6))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 29 29 (Sail.BitVec.extractLsb 0b0000000000000000#16 5 5))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 27 27 (Sail.BitVec.extractLsb 0b0000000000000000#16 4 4))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 25 25 (Sail.BitVec.extractLsb 0b0000000000000000#16 3 3))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 23 23 (Sail.BitVec.extractLsb 0b0000000000000000#16 2 2))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 21 21 (Sail.BitVec.extractLsb 0b0000000000000000#16 1 1))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 19 19 (Sail.BitVec.extractLsb 0b0000000000000000#16 0 0))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 48 48 (Sail.BitVec.extractLsb 0b0000000000000000#16 15 15))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 46 46 (Sail.BitVec.extractLsb 0b0000000000000000#16 14 14))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 44 44 (Sail.BitVec.extractLsb 0b0000000000000000#16 13 13))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 42 42 (Sail.BitVec.extractLsb 0b0000000000000000#16 12 12))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 40 40 (Sail.BitVec.extractLsb 0b0000000000000000#16 11 11))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 38 38 (Sail.BitVec.extractLsb 0b0000000000000000#16 10 10))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 36 36 (Sail.BitVec.extractLsb 0b0000000000000000#16 9 9))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 34 34 (Sail.BitVec.extractLsb 0b0000000000000000#16 8 8))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 32 32 (Sail.BitVec.extractLsb 0b0000000000000000#16 7 7))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 30 30 (Sail.BitVec.extractLsb 0b0000000000000000#16 6 6))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 28 28 (Sail.BitVec.extractLsb 0b0000000000000000#16 5 5))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 26 26 (Sail.BitVec.extractLsb 0b0000000000000000#16 4 4))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 24 24 (Sail.BitVec.extractLsb 0b0000000000000000#16 3 3))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 22 22 (Sail.BitVec.extractLsb 0b0000000000000000#16 2 2))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 20 20 (Sail.BitVec.extractLsb 0b0000000000000000#16 1 1))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 18 18 (Sail.BitVec.extractLsb 0b0000000000000000#16 0 0))
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 17 17 0#1)
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 0 0 0#1)
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 16 5 0b000000000000#12)
  writeReg HAFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HAFGRTR_EL2) 4 1 0b0000#4)
  writeReg ICC_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_BPR0_EL1) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg ACCDATA_EL1 (Sail.BitVec.updateSubrange (← readReg ACCDATA_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg OSDLR_EL1 (Sail.BitVec.updateSubrange (← readReg OSDLR_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg OSDLR_EL1 (Sail.BitVec.updateSubrange (← readReg OSDLR_EL1) 0 0 0#1)
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 61 61 0#1))
  else (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 61 61 (← (__UNKNOWN_bits 1)))))
  writeReg SCTLR_EL1 (BitVec.update (← readReg SCTLR_EL1) 34 (Bit 0#1))
  writeReg SCTLR_EL1 (BitVec.update (← readReg SCTLR_EL1) 17 (Bit 0#1))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 12 12 0#1))
  else (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 12 12 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 2 2 0#1))
  else (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 2 2 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 0 0 0#1))
  else (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 32 32 1#1)
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 31 1 0b0000000000000000000000000000000#31)
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 0 0 0#1)
  writeReg LORID_EL1 (Sail.BitVec.updateSubrange (← readReg LORID_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg LORID_EL1 (Sail.BitVec.updateSubrange (← readReg LORID_EL1) 15 8 0b00000000#8)
  writeReg CONTEXTIDR_EL2 (Sail.BitVec.updateSubrange (← readReg CONTEXTIDR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 63 32 0b00000000000000000000000000000000#32)
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 26 8 0b0000000000000000000#19)
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 6 5 0b00#2)
  writeReg CNTP_TVAL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_TVAL_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_AA64MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR4_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ID_AA64MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR4_EL1) 3 0 0b0000#4)
  writeReg ICH_EISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_EISR_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg MIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MIDR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICC_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_RPR_EL1) 61 8 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg ICH_ELRSR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_ELRSR_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg VBAR_EL2 (Sail.BitVec.updateSubrange (← readReg VBAR_EL2) 10 0 0b00000000000#11)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 63 61 0b000#3)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 60 60 0#1)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 59 59 0#1))
  else (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 59 59 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 58 58 0#1))
  else (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 58 58 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 57 57 0#1))
  else (do writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 57 57 (← (__UNKNOWN_bits 1)))))
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 56 56 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 55 55 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 54 54 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 53 53 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 52 52 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 51 51 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 50 50 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 49 49 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 48 48 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 47 47 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 46 46 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 45 45 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 44 44 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 43 43 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 42 42 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 41 41 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 40 40 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 39 39 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 38 38 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 37 37 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 36 36 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 35 35 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 34 34 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 33 33 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 32 32 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 31 31 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 30 30 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 29 29 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 28 28 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 27 27 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 26 26 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 25 25 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 24 24 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 23 23 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 22 22 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 21 21 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 20 20 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 19 19 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 18 18 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 17 17 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 16 16 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 15 15 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 14 14 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 13 13 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 12 12 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 11 11 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 10 10 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 9 9 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 8 8 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 7 7 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 6 6 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 5 5 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 4 4 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 3 3 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 2 2 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 1 1 0#1)
  writeReg HFGITR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR_EL2) 0 0 0#1)
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 63 56 0b00000000#8)
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 43 41 0b000#3)
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 31 28 0b0000#4)
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 63 27 0b0000000000000000000000000000000000000#37)
  writeReg FPCR (BitVec.update (← readReg FPCR) 14 (Bit 0#1))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 7 3 0b00000#5)
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 23 20 0b0000#4)
  writeReg ICC_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_DIR_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg SDER32_EL2 (Sail.BitVec.updateSubrange (← readReg SDER32_EL2) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg VSTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTCR_EL2) 63 34 0b000000000000000000000000000000#30)
  writeReg VSTCR_EL2 (BitVec.update (← readReg VSTCR_EL2) 32 (Bit 0#1))
  writeReg VSTCR_EL2 (BitVec.update (← readReg VSTCR_EL2) 31 (Bit 1#1))
  writeReg VSTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTCR_EL2) 28 16 0b0000000000000#13)
  writeReg VSTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTCR_EL2) 13 8 0b000000#6)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 3 0 0b0000#4)
  writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 63 28 0b000000000000000000000000000000000000#36)
  writeReg ICV_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  (ICC_IGRPEN1_EL1_write (Mk_ICC_IGRPEN1_EL1_Type (set_slice 63 (← (ICC_IGRPEN1_EL1_read ())) 1 0b000000000000000000000000000000000000000000000000000000000000000#63)))
  (ICC_IGRPEN1_EL1_write (_update_ICC_IGRPEN1_EL1_Type_Enable (← (ICC_IGRPEN1_EL1_read ())) 0#1))
  writeReg GPTBR_EL3 (Sail.BitVec.updateSubrange (← readReg GPTBR_EL3) 63 40 0b000000000000000000000000#24)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 63 31 0b000000000000000000000000000000000#33)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 28 19 0b0000000000#10)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 18 15 0b0000#4)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 14 13 0b00#2)
  writeReg MDCCSR_EL0 (BitVec.update (← readReg MDCCSR_EL0) 12 (Bit 0#1))
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 11 6 0b000000#6)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 5 2 0b0000#4)
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 1 0 0b00#2)
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg TTBR0_EL3 (Sail.BitVec.updateSubrange (← readReg TTBR0_EL3) 63 56 0b00000000#8)
  writeReg TTBR0_EL3 (Sail.BitVec.updateSubrange (← readReg TTBR0_EL3) 4 3 0b00#2)
  writeReg TTBR0_EL3 (Sail.BitVec.updateSubrange (← readReg TTBR0_EL3) 63 48 0b0000000000000000#16)
  writeReg PMCCFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCCFILTR_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMCCFILTR_EL0 (BitVec.update (← readReg PMCCFILTR_EL0) 25 (Bit 0#1))
  writeReg PMCCFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCCFILTR_EL0) 19 0 0b00000000000000000000#20)
  writeReg ICC_NMIAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_NMIAR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg DBGCLAIMSET_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMSET_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg DBGCLAIMSET_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMSET_EL1) 31 8 0b000000000000000000000000#24)
  (ICC_SRE_EL1_write (Mk_ICC_SRE_EL1_Type (set_slice 61 (← (ICC_SRE_EL1_read ())) 3 0b0000000000000000000000000000000000000000000000000000000000000#61)))
  (ICC_SRE_EL1_write (_update_ICC_SRE_EL1_Type_DIB (← (ICC_SRE_EL1_read ())) 0#1))
  (ICC_SRE_EL1_write (_update_ICC_SRE_EL1_Type_DFB (← (ICC_SRE_EL1_read ())) 0#1))
  (ICC_SRE_EL1_write (_update_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())) 0#1))
  writeReg ICC_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ESR_EL2 (Sail.BitVec.updateSubrange (← readReg ESR_EL2) 63 56 0b00000000#8)
  writeReg CONTEXTIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CONTEXTIDR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR4_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR4_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg ID_ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR1_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg PMUACR_EL1 (Sail.BitVec.updateSubrange (← readReg PMUACR_EL1) 63 33 0b0000000000000000000000000000000#31)
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 63 34 0b000000000000000000000000000000#30)
  writeReg DSPSR_EL0 (BitVec.update (← readReg DSPSR_EL0) 32 (Bit 0#1))
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 63 35 0b00000000000000000000000000000#29)
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 27 26 0b00#2)
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 19 14 0b000000#6)
  writeReg DSPSR_EL0 (BitVec.update (← readReg DSPSR_EL0) 5 (Bit 0#1))
  writeReg RMR_EL2 (Sail.BitVec.updateSubrange (← readReg RMR_EL2) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg RMR_EL2 (Sail.BitVec.updateSubrange (← readReg RMR_EL2) 1 1 0#1)
  writeReg VNCR_EL2 (Sail.BitVec.updateSubrange (← readReg VNCR_EL2) 11 0 0b000000000000#12)
  writeReg PMINTENCLR_EL1 (Sail.BitVec.updateSubrange (← readReg PMINTENCLR_EL1) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMINTENCLR_EL1 (BitVec.update (← readReg PMINTENCLR_EL1) 32 (Bit 0#1))
  writeReg PMSELR_EL0 (Sail.BitVec.updateSubrange (← readReg PMSELR_EL0) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (set_slice 44 (← (ICC_CTLR_EL1_read ())) 20 0b00000000000000000000000000000000000000000000#44)))
  (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (set_slice 2 (← (ICC_CTLR_EL1_read ())) 16 0b00#2)))
  (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (set_slice 1 (← (ICC_CTLR_EL1_read ())) 7 0#1)))
  (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (set_slice 4 (← (ICC_CTLR_EL1_read ())) 2 0b0000#4)))
  writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg HFGITR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGITR2_EL2) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg CNTHV_TVAL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_TVAL_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 7 7 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 6 6 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 5 5 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 4 4 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 3 3 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 2 2 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 1 1 0#1)
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 0 0 0#1)
  writeReg CSSELR_EL1 (Sail.BitVec.updateSubrange (← readReg CSSELR_EL1) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  writeReg ICV_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_RPR_EL1) 62 8 0b0000000000000000000000000000000000000000000000000000000#55)
  writeReg PFAR_EL2 (Sail.BitVec.updateSubrange (← readReg PFAR_EL2) 61 56 0b000000#6)
  writeReg ICV_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_PMR_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg MFAR_EL3 (Sail.BitVec.updateSubrange (← readReg MFAR_EL3) 61 56 0b000000#6)
  writeReg MFAR_EL3 (Sail.BitVec.updateSubrange (← readReg MFAR_EL3) 11 0 0b000000000000#12)
  writeReg MFAR_EL3 (Sail.BitVec.updateSubrange (← readReg MFAR_EL3) 61 56 0b000000#6)
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 63 34 0b000000000000000000000000000000#30)
  writeReg SPSR_EL2 (BitVec.update (← readReg SPSR_EL2) 32 (Bit 0#1))
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 63 35 0b00000000000000000000000000000#29)
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 27 26 0b00#2)
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 19 14 0b000000#6)
  writeReg SPSR_EL2 (BitVec.update (← readReg SPSR_EL2) 5 (Bit 0#1))
  writeReg TCR_EL1 (Sail.BitVec.updateSubrange (← readReg TCR_EL1) 63 62 0b00#2)
  writeReg TCR_EL1 (BitVec.update (← readReg TCR_EL1) 35 (Bit 0#1))
  writeReg TCR_EL1 (BitVec.update (← readReg TCR_EL1) 6 (Bit 0#1))
  writeReg ICV_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 63 7 0b000000000000000000000000000000000000000000000000000000000#57)
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 6 6 0#1))
  else (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 6 6 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 5 5 0#1))
  else (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 5 5 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 4 4 0#1))
  else (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 4 4 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 3 3 0#1))
  else (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 3 3 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 2 2 0#1))
  else (do writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 2 2 (← (__UNKNOWN_bits 1)))))
  writeReg SCTLR2_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL1) 1 0 0b00#2)
  writeReg ICV_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR0_EL1) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg ISR_EL1 (Sail.BitVec.updateSubrange (← readReg ISR_EL1) 63 11 0b00000000000000000000000000000000000000000000000000000#53)
  writeReg ISR_EL1 (Sail.BitVec.updateSubrange (← readReg ISR_EL1) 5 0 0b000000#6)
  writeReg ID_ISAR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR3_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR3_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg MECIDR_EL2 (Sail.BitVec.updateSubrange (← readReg MECIDR_EL2) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  writeReg PMINTENSET_EL1 (Sail.BitVec.updateSubrange (← readReg PMINTENSET_EL1) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMINTENSET_EL1 (BitVec.update (← readReg PMINTENSET_EL1) 32 (Bit 0#1))
  writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 14 12 0b000#3)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 63 63 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 62 62 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 61 61 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 60 60 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 59 59 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 58 58 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 57 57 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 56 56 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 55 55 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 54 54 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 53 53 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 52 52 0#1)
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 51 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 50 50 0#1)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 49 49 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 49 49 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 48 48 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 48 48 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 47 47 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 47 47 (← (__UNKNOWN_bits 1)))))
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 46 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 45 45 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 45 45 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 44 44 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 44 44 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 43 43 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 43 43 (← (__UNKNOWN_bits 1)))))
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 42 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 41 41 0#1))
  else (do writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 41 41 (← (__UNKNOWN_bits 1)))))
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 40 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 39 39 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 38 38 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 37 37 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 36 36 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 35 35 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 34 34 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 33 33 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 32 32 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 31 31 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 30 30 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 29 29 0#1)
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 28 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 27 27 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 26 25 0b00#2)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 24 24 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 23 23 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 22 22 0#1)
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 21 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 20 20 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 19 19 0#1)
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 18 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 17 17 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 16 16 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 15 14 0b00#2)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 13 13 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 12 12 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 11 11 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 10 9 0b00#2)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 8 8 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 7 7 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 6 6 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 5 5 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 4 4 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 3 3 0#1)
  writeReg HFGWTR_EL2 (BitVec.update (← readReg HFGWTR_EL2) 2 (Bit 0#1))
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 1 1 0#1)
  writeReg HFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR_EL2) 0 0 0#1)
  writeReg SMPRI_EL1 (Sail.BitVec.updateSubrange (← readReg SMPRI_EL1) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  writeReg PMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg PMUSERENR_EL0) 63 7 0b000000000000000000000000000000000000000000000000000000000#57)
  writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 63 7 0b000000000000000000000000000000000000000000000000000000000#57)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 6 6 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 6 6 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 5 5 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 5 5 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 4 4 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 3 3 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 2 2 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 1 1 0#1))
  else (do writeReg SCTLR2_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  writeReg SCTLR2_EL2 (BitVec.update (← readReg SCTLR2_EL2) 0 (Bit 0#1))
  writeReg PMOVSSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSSET_EL0) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMOVSSET_EL0 (BitVec.update (← readReg PMOVSSET_EL0) 32 (Bit 0#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 63 (Bit 0#1))
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 61 61 0#1)
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 60 (Bit 0#1))
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 58 54 0b00000#5)
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 52 (Bit 0#1))
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 50 45 0b000000#6)
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 42 (Bit 0#1))
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 39 38 0b00#2)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 35 32 0b0000#4)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 29 28 0b11#2)
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 26 (Bit 0#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 24 (Bit 0#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 23 (Bit 1#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 20 (Bit 0#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 18 (Bit 1#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 17 (Bit 0#1))
  writeReg SCTLR_EL3 (BitVec.update (← readReg SCTLR_EL3) 16 (Bit 1#1))
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 15 14 0b00#2)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 12 12 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 10 7 0b0000#4)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 5 4 0b11#2)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 2 2 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 0 0 0#1)
  writeReg VBAR_EL1 (Sail.BitVec.updateSubrange (← readReg VBAR_EL1) 10 0 0b00000000000#11)
  writeReg CNTFRQ_EL0 (Sail.BitVec.updateSubrange (← readReg CNTFRQ_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 17 16 0b00#2)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 7 2 0b000000#6)
  writeReg MECID_A0_EL2 (Sail.BitVec.updateSubrange (← readReg MECID_A0_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg ICV_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 63 30 0b0000000000000000000000000000000000#34)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 27 26 0b00#2)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 23 22 0b00#2)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 19 18 0b00#2)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 15 0 0b0000000000000000#16)
  writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 63 34 0b000000000000000000000000000000#30)
  writeReg SPSR_EL1 (BitVec.update (← readReg SPSR_EL1) 32 (Bit 0#1))
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 63 35 0b00000000000000000000000000000#29)
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 27 26 0b00#2)
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 19 14 0b000000#6)
  writeReg SPSR_EL1 (BitVec.update (← readReg SPSR_EL1) 5 (Bit 0#1))
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 25 11 0b000000000000000#15)
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 6 5 0b00#2)
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 36 0b0000000000000000000000000000#28)
  (if (cold : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 35 35 0#1))
  else (do (pure ())))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 33 (Bit 0#1))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 32 32 0#1))
  else (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 32 32 (← (__UNKNOWN_bits 1)))))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 28 (Bit 0#1))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 25 24 0b00#2)
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 20 (Bit 0#1))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 18 16 0b000#3)
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 11 7 0b00000#5)
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 5 1 0b00000#5)
  writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 63 32 0b00000000000000000000000000000000#32)
  writeReg MECID_P0_EL2 (Sail.BitVec.updateSubrange (← readReg MECID_P0_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 19 18 0b00#2)
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 16 16 0#1)
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 7 3 0b00000#5)
  writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg MVFR1_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR1_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg MVFR1_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 63 22 0b000000000000000000000000000000000000000000#42)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 21 21 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 21 21 (← (__UNKNOWN_bits 1)))))
  writeReg HDFGWTR2_EL2 (BitVec.update (← readReg HDFGWTR2_EL2) 20 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 19 19 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 19 19 (← (__UNKNOWN_bits 1)))))
  writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 18 17 0b00#2)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 16 16 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 16 16 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 15 15 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 15 15 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 14 14 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 14 14 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 13 13 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 13 13 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 12 12 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 12 12 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 11 11 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 11 11 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 10 10 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 10 10 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 9 9 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 9 9 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 8 8 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 8 8 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 7 7 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 7 7 (← (__UNKNOWN_bits 1)))))
  writeReg HDFGWTR2_EL2 (BitVec.update (← readReg HDFGWTR2_EL2) 6 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 5 5 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 5 5 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 4 4 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 3 3 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 2 2 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 1 1 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 0 0 0#1))
  else (do writeReg HDFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 13 12 0b00#2)
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 11 11 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 11 11 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 10 10 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 10 10 (← (__UNKNOWN_bits 1)))))
  writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 9 6 0b0000#4)
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 5 5 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 5 5 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 4 4 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 4 4 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 3 3 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 3 3 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 2 2 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 2 2 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 1 1 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 1 1 (← (__UNKNOWN_bits 1)))))
  (if ((((! cold) && (! (HaveEL EL2))) && (! (HaveEL EL3))) : Bool)
  then (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 0 0 0#1))
  else (do writeReg TCR2_EL1 (Sail.BitVec.updateSubrange (← readReg TCR2_EL1) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg ID_ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR0_EL1) 63 28 0b000000000000000000000000000000000000#36)
  writeReg ID_ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg DCZID_EL0 (Sail.BitVec.updateSubrange (← readReg DCZID_EL0) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  writeReg VSTTBR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTTBR_EL2) 63 56 0b00000000#8)
  writeReg VSTTBR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTTBR_EL2) 4 3 0b00#2)
  writeReg VSTTBR_EL2 (Sail.BitVec.updateSubrange (← readReg VSTTBR_EL2) 63 48 0b0000000000000000#16)
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 63 7 0b000000000000000000000000000000000000000000000000000000000#57)
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 6 5 0b00#2)
  writeReg TRFCR_EL2 (BitVec.update (← readReg TRFCR_EL2) 4 (Bit 0#1))
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 3 3 0#1)
  writeReg TRFCR_EL2 (BitVec.update (← readReg TRFCR_EL2) 2 (Bit 0#1))
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 1 1 0#1)
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 0 0 0#1)
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg CNTHVS_TVAL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_TVAL_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg CNTHP_TVAL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_TVAL_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMZR_EL0 (Sail.BitVec.updateSubrange (← readReg PMZR_EL0) 63 33 0b0000000000000000000000000000000#31)
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 11 8 0b0000#4)
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 63 56 0b00000000#8)
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 11 2 0b0000000000#10)
  writeReg OSDTRRX_EL1 (Sail.BitVec.updateSubrange (← readReg OSDTRRX_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg PFAR_EL1 (Sail.BitVec.updateSubrange (← readReg PFAR_EL1) 61 56 0b000000#6)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 63 17 0b00000000000000000000000000000000000000000000000#47)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 15 13 0b000#3)
  writeReg IFSR32_EL2 (BitVec.update (← readReg IFSR32_EL2) 11 (Bit 0#1))
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 8 4 0b00000#5)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 63 17 0b00000000000000000000000000000000000000000000000#47)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 15 13 0b000#3)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 11 10 0b00#2)
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 8 6 0b000#3)
  writeReg ICC_IGRPEN1_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL3) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg ICC_IGRPEN1_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL3) 1 1 0#1)
  writeReg ICC_IGRPEN1_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL3) 0 0 0#1)
  writeReg ID_MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR1_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg LORSA_EL1 (Sail.BitVec.updateSubrange (← readReg LORSA_EL1) 63 56 0b00000000#8)
  writeReg LORSA_EL1 (Sail.BitVec.updateSubrange (← readReg LORSA_EL1) 15 1 0b000000000000000#15)
  writeReg LORSA_EL1 (Sail.BitVec.updateSubrange (← readReg LORSA_EL1) 0 0 0#1)
  writeReg PMSWINC_EL0 (Sail.BitVec.updateSubrange (← readReg PMSWINC_EL0) 63 31 0b000000000000000000000000000000000#33)
  writeReg ESR_EL3 (Sail.BitVec.updateSubrange (← readReg ESR_EL3) 63 56 0b00000000#8)
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg TRFCR_EL1 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL1) 63 7 0b000000000000000000000000000000000000000000000000000000000#57)
  writeReg TRFCR_EL1 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL1) 4 2 0b000#3)
  writeReg TRFCR_EL1 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL1) 1 1 0#1)
  writeReg TRFCR_EL1 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL1) 0 0 0#1)
  writeReg ID_MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR0_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg OSDTRTX_EL1 (Sail.BitVec.updateSubrange (← readReg OSDTRTX_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 17 10 0b00000000#8)
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 8 5 0b0000#4)
  writeReg VPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VPIDR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICC_CTLR_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL3) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg ICC_CTLR_EL3 (BitVec.update (← readReg ICC_CTLR_EL3) 16 (Bit 0#1))
  writeReg ICC_CTLR_EL3 (BitVec.update (← readReg ICC_CTLR_EL3) 7 (Bit 0#1))
  writeReg ICC_CTLR_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL3) 6 6 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 61 61 0#1)
  writeReg SCTLR_EL2 (BitVec.update (← readReg SCTLR_EL2) 34 (Bit 0#1))
  writeReg SCTLR_EL2 (BitVec.update (← readReg SCTLR_EL2) 17 (Bit 0#1))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 12 12 0#1)
  writeReg SCTLR_EL2 (BitVec.update (← readReg SCTLR_EL2) 9 (Bit 0#1))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 2 2 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 0 0 0#1)
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  (if (cold : Bool)
  then (do writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 1 1 1#1))
  else (do (pure ())))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 63 47 0b00000000000000000#17)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 46 45 0b00#2)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 43 43 0#1)
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 39 (Bit 0#1))
  (if (cold : Bool)
  then (do writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 38 38 0#1))
  else (do (pure ())))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 37 37 0#1)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 35 35 0#1)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 34 34 0#1)
  (if (cold : Bool)
  then (do writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 31 30 0b00#2))
  else (do (pure ())))
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 29 (Bit 0#1))
  (if (cold : Bool)
  then (do writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 28 28 1#1))
  else (do (pure ())))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 26 24 0b000#3)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 23 23 0#1)
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 22 (Bit 0#1))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 21 21 0#1)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 20 20 0#1)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 18 18 0#1)
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 17 17 0#1)
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 8 (Bit 0#1))
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 5 (Bit 0#1))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 4 4 0#1)
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 3 (Bit 0#1))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 2 2 0#1)
  writeReg MDCR_EL3 (BitVec.update (← readReg MDCR_EL3) 1 (Bit 0#1))
  writeReg MDCR_EL3 (Sail.BitVec.updateSubrange (← readReg MDCR_EL3) 0 0 0#1)
  writeReg SCTLR2_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL3) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  writeReg SCTLR2_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL3) 4 4 0#1)
  writeReg SCTLR2_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL3) 3 3 0#1)
  writeReg SCTLR2_EL3 (BitVec.update (← readReg SCTLR2_EL3) 2 (Bit 0#1))
  writeReg SCTLR2_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR2_EL3) 1 1 0#1)
  writeReg SCTLR2_EL3 (BitVec.update (← readReg SCTLR2_EL3) 0 (Bit 0#1))
  writeReg PMCNTENSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMCNTENSET_EL0) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMCNTENSET_EL0 (BitVec.update (← readReg PMCNTENSET_EL0) 32 (Bit 0#1))
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 2 2 0#1)
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 1 1 0#1)
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 0 0 0#1)
  writeReg CNTPS_CTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_CTL_EL1) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg DACR32_EL2 (Sail.BitVec.updateSubrange (← readReg DACR32_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg LORC_EL1 (Sail.BitVec.updateSubrange (← readReg LORC_EL1) 63 10 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg LORC_EL1 (BitVec.update (← readReg LORC_EL1) 1 (Bit 0#1))
  writeReg LORC_EL1 (Sail.BitVec.updateSubrange (← readReg LORC_EL1) 0 0 0#1)
  writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 63 12 0b0000000000000000000000000000000000000000000000000000#52)
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 63 34 0b000000000000000000000000000000#30)
  writeReg TCR_EL2 (BitVec.update (← readReg TCR_EL2) 31 (Bit 1#1))
  writeReg TCR_EL2 (BitVec.update (← readReg TCR_EL2) 23 (Bit 1#1))
  writeReg TCR_EL2 (BitVec.update (← readReg TCR_EL2) 19 (Bit 0#1))
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 7 6 0b00#2)
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 63 62 0b00#2)
  writeReg TCR_EL2 (BitVec.update (← readReg TCR_EL2) 35 (Bit 0#1))
  writeReg TCR_EL2 (BitVec.update (← readReg TCR_EL2) 6 (Bit 0#1))
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 63 56 0b00000000#8)
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 43 41 0b000#3)
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 31 28 0b0000#4)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 63 38 0b00000000000000000000000000#26)
  writeReg CTR_EL0 (BitVec.update (← readReg CTR_EL0) 31 (Bit 1#1))
  writeReg CTR_EL0 (BitVec.update (← readReg CTR_EL0) 30 (Bit 0#1))
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 13 4 0b0000000000#10)
  writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 63 56 0b00000000#8)
  writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 47 44 0b0000#4)
  writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 63 32 0b00000000000000000000000000000000#32)
  writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 29 21 0b000000000#9)
  writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 19 13 0b0000000#7)
  writeReg CPTR_EL3 (BitVec.update (← readReg CPTR_EL3) 11 (Bit 0#1))
  writeReg CPTR_EL3 (BitVec.update (← readReg CPTR_EL3) 9 (Bit 0#1))
  writeReg CPTR_EL3 (Sail.BitVec.updateSubrange (← readReg CPTR_EL3) 7 0 0b00000000#8)
  writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 2 2 0#1))
  else (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 1 1 0#1))
  else (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 0 0 0#1))
  else (do writeReg HFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 23 20 0b0000#4)
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg RMR_EL3 (Sail.BitVec.updateSubrange (← readReg RMR_EL3) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg RMR_EL3 (Sail.BitVec.updateSubrange (← readReg RMR_EL3) 1 1 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 31 27 0b00000#5)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 26 16 0b00000000000#11)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 15 15 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 14 14 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 13 13 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 12 12 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 11 11 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 10 10 0#1)
  writeReg ICH_HCR_EL2 (BitVec.update (← readReg ICH_HCR_EL2) 9 (Bit 0#1))
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 8 8 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 7 7 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 6 6 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 5 5 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 4 4 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 3 3 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 2 2 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 1 1 0#1)
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 0 0 0#1)
  writeReg ICC_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN0_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg ICC_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN0_EL1) 0 0 0#1)
  writeReg CNTHPS_TVAL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_TVAL_EL2) 63 32 0b00000000000000000000000000000000#32)
  (ICC_BPR1_EL1_write (Mk_ICC_BPR1_EL1_Type (set_slice 61 (← (ICC_BPR1_EL1_read ())) 3 0b0000000000000000000000000000000000000000000000000000000000000#61)))
  writeReg MECID_A1_EL2 (Sail.BitVec.updateSubrange (← readReg MECID_A1_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg ICC_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 55 48 0b00000000#8)
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 63 33 0b0000000000000000000000000000000#31)
  (if (((! cold) && (HaveAArch32 ())) : Bool)
  then (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 32 32 0#1))
  else (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 32 32 (← (__UNKNOWN_bits 1)))))
  writeReg PMCR_EL0 (BitVec.update (← readReg PMCR_EL0) 10 (Bit 0#1))
  writeReg PMCR_EL0 (BitVec.update (← readReg PMCR_EL0) 8 (Bit 0#1))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 0 0 0#1)
  writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 63 20 0b00000000000000000000000000000000000000000000#44)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 19 19 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 19 19 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 18 18 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 18 18 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 17 17 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 17 17 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 16 16 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 16 16 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 15 15 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 15 15 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 14 14 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 14 14 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 13 13 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 13 13 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 12 12 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 12 12 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 11 11 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 11 11 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 10 10 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 10 10 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 9 9 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 9 9 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 8 8 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 8 8 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 7 7 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 7 7 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 6 6 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 6 6 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 5 5 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 5 5 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 4 4 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 3 3 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 2 2 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 1 1 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 0 0 0#1))
  else (do writeReg HDFGRTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGRTR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg DBGPRCR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGPRCR_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg PMCNTENCLR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCNTENCLR_EL0) 63 33 0b0000000000000000000000000000000#31)
  writeReg PMCNTENCLR_EL0 (BitVec.update (← readReg PMCNTENCLR_EL0) 32 (Bit 0#1))
  (SDER32_EL3_write (Mk_SDER32_EL3_Type (set_slice 62 (← (SDER32_EL3_read ())) 2 0b00000000000000000000000000000000000000000000000000000000000000#62)))
  writeReg HPFAR_EL2 (Sail.BitVec.updateSubrange (← readReg HPFAR_EL2) 62 48 0b000000000000000#15)
  writeReg HPFAR_EL2 (Sail.BitVec.updateSubrange (← readReg HPFAR_EL2) 3 0 0b0000#4)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 63 40 0b000000000000000000000000#24)
  writeReg VMPIDR_EL2 (BitVec.update (← readReg VMPIDR_EL2) 31 (Bit 1#1))
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 29 25 0b00000#5)
  writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 51 48 0b0000#4)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 17 5 0b0000000000000#13)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 63 6 0b0000000000000000000000000000000000000000000000000000000000#58)
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 3 0 0b0000#4)
  writeReg ICV_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg VBAR_EL3 (Sail.BitVec.updateSubrange (← readReg VBAR_EL3) 10 0 0b00000000000#11)
  writeReg ID_AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AFR0_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg ID_AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AFR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 63 44 0b00000000000000000000#20)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 43 43 0#1))
  else (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 43 43 (← (__UNKNOWN_bits 1)))))
  writeReg MDCR_EL2 (BitVec.update (← readReg MDCR_EL2) 42 (Bit 0#1))
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 39 37 0b000#3)
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 35 32 0b0000#4)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 31 30 0b00#2))
  else (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 31 30 (← (__UNKNOWN_bits 2)))))
  (if (cold : Bool)
  then (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 28 28 1#1))
  else (do (pure ())))
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 25 24 0b00#2)
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 23 23 0#1)
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 22 20 0b000#3)
  writeReg MDCR_EL2 (BitVec.update (← readReg MDCR_EL2) 18 (Bit 0#1))
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 17 17 0#1)
  writeReg MDCR_EL2 (BitVec.update (← readReg MDCR_EL2) 16 (Bit 0#1))
  writeReg CNTKCTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTKCTL_EL1) 63 18 0b0000000000000000000000000000000000000000000000#46)
  writeReg CNTKCTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTKCTL_EL1) 16 10 0b0000000#7)
  writeReg LORN_EL1 (Sail.BitVec.updateSubrange (← readReg LORN_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg ICV_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN0_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) 63 34 0b000000000000000000000000000000#30)
  writeReg SPSR_EL3 (BitVec.update (← readReg SPSR_EL3) 32 (Bit 0#1))
  writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) 63 35 0b00000000000000000000000000000#29)
  writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) 27 26 0b00#2)
  writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) 19 14 0b000000#6)
  writeReg SPSR_EL3 (BitVec.update (← readReg SPSR_EL3) 5 (Bit 0#1))
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 63 56 0b00000000#8)
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 31 24 0b00000000#8)
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 31 28 0b0000#4)
  writeReg VMECID_P_EL2 (Sail.BitVec.updateSubrange (← readReg VMECID_P_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg OSECCR_EL1 (Sail.BitVec.updateSubrange (← readReg OSECCR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg DBGVCR32_EL2 (BitVec.update (← readReg DBGVCR32_EL2) 29 (Bit 0#1))
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 24 8 0b00000000000000000#17)
  writeReg DBGVCR32_EL2 (BitVec.update (← readReg DBGVCR32_EL2) 5 (Bit 0#1))
  writeReg DBGVCR32_EL2 (BitVec.update (← readReg DBGVCR32_EL2) 0 (Bit 0#1))
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg DBGVCR32_EL2 (BitVec.update (← readReg DBGVCR32_EL2) 5 (Bit 0#1))
  writeReg DBGVCR32_EL2 (BitVec.update (← readReg DBGVCR32_EL2) 0 (Bit 0#1))
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 63 63 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 62 62 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 61 61 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 60 60 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 59 59 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 58 58 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 57 57 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 56 56 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 55 55 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 54 54 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 53 53 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 52 52 0#1)
  writeReg HFGRTR_EL2 (BitVec.update (← readReg HFGRTR_EL2) 51 (Bit 0#1))
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 50 50 0#1)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 49 49 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 49 49 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 48 48 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 48 48 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 47 47 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 47 47 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 46 46 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 46 46 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 45 45 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 45 45 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 44 44 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 44 44 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 43 43 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 43 43 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 42 42 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 42 42 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 41 41 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 41 41 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 40 40 0#1))
  else (do writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 40 40 (← (__UNKNOWN_bits 1)))))
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 39 39 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 38 38 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 37 37 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 36 36 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 35 35 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 34 34 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 33 33 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 32 32 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 31 31 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 30 30 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 29 29 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 28 28 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 27 27 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 26 26 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 25 25 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 24 24 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 23 23 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 22 22 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 21 21 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 20 20 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 19 19 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 18 18 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 17 17 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 16 16 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 15 15 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 14 14 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 13 13 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 12 12 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 11 11 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 10 10 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 9 9 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 8 8 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 7 7 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 6 6 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 5 5 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 4 4 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 3 3 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 2 2 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 1 1 0#1)
  writeReg HFGRTR_EL2 (Sail.BitVec.updateSubrange (← readReg HFGRTR_EL2) 0 0 0#1)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 27 26 0b00#2)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 23 22 0b00#2)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 19 18 0b00#2)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 15 0 0b0000000000000000#16)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 29 21 0b000000000#9)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 19 14 0b000000#6)
  writeReg CPTR_EL2 (BitVec.update (← readReg CPTR_EL2) 13 (Bit 1#1))
  writeReg CPTR_EL2 (BitVec.update (← readReg CPTR_EL2) 11 (Bit 0#1))
  writeReg CPTR_EL2 (BitVec.update (← readReg CPTR_EL2) 9 (Bit 1#1))
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 7 0 0b11111111#8)
  writeReg CLIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CLIDR_EL1) 63 47 0b00000000000000000#17)
  writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 63 23 0b00000000000000000000000000000000000000000#41)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 22 22 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 22 22 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 20 20 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 20 20 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 19 19 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 19 19 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 18 18 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 18 18 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 17 17 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 17 17 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 15 15 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 15 15 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 14 14 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 14 14 (← (__UNKNOWN_bits 1)))))
  writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 13 12 0b00#2)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 11 11 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 11 11 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 10 10 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 10 10 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 9 9 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 9 9 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 8 8 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 8 8 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 7 7 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 7 7 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 6 6 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 6 6 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 5 5 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 5 5 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 4 4 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 4 4 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 3 3 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 3 3 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 2 2 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 1 1 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 1 1 (← (__UNKNOWN_bits 1)))))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 0 0 0#1))
  else (do writeReg HCRX_EL2 (Sail.BitVec.updateSubrange (← readReg HCRX_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg ICV_IGRPEN1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN1_EL1) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg PMXEVCNTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMXEVCNTR_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg HFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR2_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR2_EL2) 2 2 0#1))
  else (do writeReg HFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR2_EL2) 2 2 (← (__UNKNOWN_bits 1)))))
  writeReg HFGWTR2_EL2 (BitVec.update (← readReg HFGWTR2_EL2) 1 (Bit 0#1))
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR2_EL2) 0 0 0#1))
  else (do writeReg HFGWTR2_EL2 (Sail.BitVec.updateSubrange (← readReg HFGWTR2_EL2) 0 0 (← (__UNKNOWN_bits 1)))))
  writeReg MECID_P1_EL2 (Sail.BitVec.updateSubrange (← readReg MECID_P1_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 63 56 0b00000000#8)
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 43 41 0b000#3)
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 31 28 0b0000#4)
  writeReg MVFR2_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR2_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg MVFR2_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR2_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg SPMSELR_EL0 (Sail.BitVec.updateSubrange (← readReg SPMSELR_EL0) 63 10 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg SPMSELR_EL0 (Sail.BitVec.updateSubrange (← readReg SPMSELR_EL0) 3 2 0b00#2)
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 63 28 0b000000000000000000000000000000000000#36)
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 23 16 0b00000000#8)
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 11 8 0b0000#4)
  writeReg SCR_EL3 (BitVec.update (← readReg SCR_EL3) 63 (Bit 0#1))
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 61 60 0b00#2)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 58 56 0b000#3)
  writeReg SCR_EL3 (BitVec.update (← readReg SCR_EL3) 54 (Bit 0#1))
  writeReg SCR_EL3 (BitVec.update (← readReg SCR_EL3) 50 (Bit 0#1))
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 40 40 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 24 22 0b000#3)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 20 20 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 19 19 0#1)
  writeReg SCR_EL3 (BitVec.update (← readReg SCR_EL3) 6 (Bit 0#1))
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 5 4 0b11#2)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 2 2 0#1)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 1 1 0#1)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 0 0 0#1)
  writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 63 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 62 62 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 61 61 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 60 60 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 59 58 0b00#2)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 57 57 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 56 50 0b0000000#7)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 49 49 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 48 48 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 47 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 46 46 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 45 45 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 44 44 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 43 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 42 42 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 41 41 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 40 38 0b000#3)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 37 37 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 36 36 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 35 35 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 34 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 33 33 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 32 32 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 31 31 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 30 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 29 29 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 28 28 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 27 27 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 26 26 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 25 25 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 24 24 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 23 23 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 22 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 21 21 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 20 20 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 19 19 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 18 18 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 17 17 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 16 16 0#1)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 15 15 0#1))
  else (do writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 15 15 (← (__UNKNOWN_bits 1)))))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 14 14 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 13 13 0#1)
  (if (((! cold) && (! (HaveEL EL3))) : Bool)
  then (do writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 12 12 0#1))
  else (do writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 12 12 (← (__UNKNOWN_bits 1)))))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 11 11 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 10 10 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 9 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 8 8 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 7 7 0#1)
  writeReg HDFGWTR_EL2 (BitVec.update (← readReg HDFGWTR_EL2) 6 (Bit 0#1))
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 5 5 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 4 4 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 3 3 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 2 2 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 1 1 0#1)
  writeReg HDFGWTR_EL2 (Sail.BitVec.updateSubrange (← readReg HDFGWTR_EL2) 0 0 0#1)
  writeReg CNTPS_TVAL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_TVAL_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_AA64AFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64AFR1_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg LOREA_EL1 (Sail.BitVec.updateSubrange (← readReg LOREA_EL1) 63 56 0b00000000#8)
  writeReg LOREA_EL1 (Sail.BitVec.updateSubrange (← readReg LOREA_EL1) 15 0 0b0000000000000000#16)
  writeReg CNTV_TVAL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_TVAL_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg ICV_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_DIR_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ICC_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 63 40 0b000000000000000000000000#24)
  writeReg MPIDR_EL1 (BitVec.update (← readReg MPIDR_EL1) 31 (Bit 1#1))
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 29 25 0b00000#5)
  writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 31 8 0b000000000000000000000000#24)
  (if (cold : Bool)
  then (do writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 7 0 0b00000000#8))
  else (do (pure ())))
  writeReg ICV_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR1_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ID_AA64AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64AFR0_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 63 12 0b0000000000000000000000000000000000000000000000000000#52)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 63 3 0b0000000000000000000000000000000000000000000000000000000000000#61)
  writeReg ICC_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR0_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 63 60 0b0000#4)
  writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 51 48 0b0000#4)
  writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 39 36 0b0000#4)
  writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 31 28 0b0000#4)
  writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 15 8 0b00000000#8)
  writeReg ZCR_EL3 (Sail.BitVec.updateSubrange (← readReg ZCR_EL3) 63 9 0b0000000000000000000000000000000000000000000000000000000#55)
  writeReg ZCR_EL3 (Sail.BitVec.updateSubrange (← readReg ZCR_EL3) 8 4 0b00000#5)
  writeReg ZCR_EL1 (Sail.BitVec.updateSubrange (← readReg ZCR_EL1) 63 9 0b0000000000000000000000000000000000000000000000000000000#55)
  writeReg ZCR_EL1 (Sail.BitVec.updateSubrange (← readReg ZCR_EL1) 8 4 0b00000#5)
  writeReg ZCR_EL2 (Sail.BitVec.updateSubrange (← readReg ZCR_EL2) 63 9 0b0000000000000000000000000000000000000000000000000000000#55)
  writeReg ZCR_EL2 (Sail.BitVec.updateSubrange (← readReg ZCR_EL2) 8 4 0b00000#5)
  writeReg SMCR_EL3 (Sail.BitVec.updateSubrange (← readReg SMCR_EL3) 63 32 0b00000000000000000000000000000000#32)
  writeReg SMCR_EL3 (Sail.BitVec.updateSubrange (← readReg SMCR_EL3) 29 9 0b000000000000000000000#21)
  writeReg SMCR_EL3 (Sail.BitVec.updateSubrange (← readReg SMCR_EL3) 8 4 0b00000#5)
  writeReg SMCR_EL1 (Sail.BitVec.updateSubrange (← readReg SMCR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg SMCR_EL1 (Sail.BitVec.updateSubrange (← readReg SMCR_EL1) 29 9 0b000000000000000000000#21)
  writeReg SMCR_EL1 (Sail.BitVec.updateSubrange (← readReg SMCR_EL1) 8 4 0b00000#5)
  writeReg SMCR_EL2 (Sail.BitVec.updateSubrange (← readReg SMCR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg SMCR_EL2 (Sail.BitVec.updateSubrange (← readReg SMCR_EL2) 29 9 0b000000000000000000000#21)
  writeReg SMCR_EL2 (Sail.BitVec.updateSubrange (← readReg SMCR_EL2) 8 4 0b00000#5)
  writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 62 60 0b000#3)
  writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 51 49 0b000#3)
  writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 41 40 0b00#2)
  writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 31 0 0b00000000000000000000000000000000#32)
  writeReg MPAMHCR_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMHCR_EL2) 63 32 0b00000000000000000000000000000000#32)
  (if ((HaveEL EL3) : Bool)
  then (do writeReg MPAMHCR_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMHCR_EL2) 31 31 (← (__UNKNOWN_bits 1))))
  else
    (do (if (((! cold) && (! (HaveEL EL3))) : Bool)
        then (do writeReg MPAMHCR_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMHCR_EL2) 31 31 1#1))
        else (do (pure ())))))
  writeReg MPAMHCR_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMHCR_EL2) 30 9 0b0000000000000000000000#22)
  writeReg MPAMHCR_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMHCR_EL2) 7 2 0b000000#6)
  writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 63 62 0b00#2)
  writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 56 40 0b00000000000000000#17)
  writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 31 21 0b00000000000#11)
  writeReg MPAMIDR_EL1 (BitVec.update (← readReg MPAMIDR_EL1) 16 (Bit 0#1))
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 63 63 0#1)
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 62 59 0b0000#4)
  writeReg MPAM2_EL2 (BitVec.update (← readReg MPAM2_EL2) 57 (Bit 0#1))
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 53 51 0b000#3)
  (if ((HaveEL EL3) : Bool)
  then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 49 49 (← (__UNKNOWN_bits 1))))
  else
    (do (if (((! cold) && (! (HaveEL EL3))) : Bool)
        then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 49 49 1#1))
        else (do (pure ())))))
  (if ((HaveEL EL3) : Bool)
  then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 48 48 (← (__UNKNOWN_bits 1))))
  else
    (do (if (((! cold) && (! (HaveEL EL3))) : Bool)
        then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 48 48 1#1))
        else (do (pure ())))))
  (MPAM3_EL3_write (_update_MPAM3_EL3_Type_MPAMEN (← (MPAM3_EL3_read ())) 0#1))
  (MPAM3_EL3_write (_update_MPAM3_EL3_Type_TRAPLOWER (← (MPAM3_EL3_read ())) 1#1))
  (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 2 (← (MPAM3_EL3_read ())) 58 0b00#2)))
  (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 2 (← (MPAM3_EL3_read ())) 53 0b00#2)))
  (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 4 (← (MPAM3_EL3_read ())) 48 0b0000#4)))
  writeReg MPAM0_EL1 (Sail.BitVec.updateSubrange (← readReg MPAM0_EL1) 63 48 0b0000000000000000#16)
  writeReg MPAMSM_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMSM_EL1) 63 48 0b0000000000000000#16)
  writeReg MPAMSM_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMSM_EL1) 39 32 0b00000000#8)
  writeReg MPAMSM_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMSM_EL1) 15 0 0b0000000000000000#16)
  (MPAM1_EL1_write (_update_MPAM1_EL1_Type_MPAMEN (← (MPAM1_EL1_read ())) 0#1))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 2 (← (MPAM1_EL1_read ())) 61 0b00#2)))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 5 (← (MPAM1_EL1_read ())) 55 0b00000#5)))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 6 (← (MPAM1_EL1_read ())) 48 0b000000#6)))
  writeReg MPAMVPMV_EL2 (Sail.BitVec.updateSubrange (← readReg MPAMVPMV_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg GMID_EL1 (Sail.BitVec.updateSubrange (← readReg GMID_EL1) 63 4 0b000000000000000000000000000000000000000000000000000000000000#60)
  writeReg TFSR_EL3 (Sail.BitVec.updateSubrange (← readReg TFSR_EL3) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg TFSRE0_EL1 (Sail.BitVec.updateSubrange (← readReg TFSRE0_EL1) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg TFSR_EL2 (Sail.BitVec.updateSubrange (← readReg TFSR_EL2) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg TFSR_EL1 (Sail.BitVec.updateSubrange (← readReg TFSR_EL1) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg RGSR_EL1 (Sail.BitVec.updateSubrange (← readReg RGSR_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  writeReg RGSR_EL1 (Sail.BitVec.updateSubrange (← readReg RGSR_EL1) 7 4 0b0000#4)
  writeReg RGSR_EL1 (Sail.BitVec.updateSubrange (← readReg RGSR_EL1) 63 56 0b00000000#8)
  writeReg RGSR_EL1 (Sail.BitVec.updateSubrange (← readReg RGSR_EL1) 7 4 0b0000#4)
  writeReg GCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCR_EL1) 63 17 0b00000000000000000000000000000000000000000000000#47)
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 63 18 0b0000000000000000000000000000000000000000000000#46)
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 16 11 0b000000#6)
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 9 0 0b0000000000#10)
  writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 15 4 0b000000000000#12)
  (if (cold : Bool)
  then (do writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 3 0 0b0000#4))
  else (do (pure ())))
  writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 15 4 0b000000000000#12)
  (if (cold : Bool)
  then (do writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 3 0 0b0000#4))
  else (do (pure ())))
  writeReg AMCNTENSET1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET1_EL0) 63 16 0b000000000000000000000000000000000000000000000000#48)
  (if (cold : Bool)
  then (do writeReg AMCNTENSET1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET1_EL0) 15 0 0b0000000000000000#16))
  else (do (pure ())))
  writeReg AMCNTENCLR1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR1_EL0) 63 16 0b000000000000000000000000000000000000000000000000#48)
  (if (cold : Bool)
  then (do writeReg AMCNTENCLR1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR1_EL0) 15 0 0b0000000000000000#16))
  else (do (pure ())))
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 27 25 0b000#3)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 23 14 0b0000000000#10)
  writeReg AMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg AMUSERENR_EL0) 63 1 0b000000000000000000000000000000000000000000000000000000000000000#63)
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 63 32 0b00000000000000000000000000000000#32)
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg PMSFCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSFCR_EL1) 63 19 0b000000000000000000000000000000000000000000000#45)
  writeReg PMSFCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSFCR_EL1) 15 5 0b00000000000#11)
  writeReg PMSIRR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIRR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMSIRR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIRR_EL1) 7 1 0b0000000#7)
  writeReg PMSICR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSICR_EL1) 55 32 0b000000000000000000000000#24)
  writeReg PMSEVFR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSEVFR_EL1) 47 32 0b0000000000000000#16)
  writeReg PMSEVFR_EL1 (BitVec.update (← readReg PMSEVFR_EL1) 0 (Bit 0#1))
  writeReg PMBLIMITR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBLIMITR_EL1) 11 6 0b000000#6)
  writeReg PMBLIMITR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBLIMITR_EL1) 4 3 0b00#2)
  writeReg PMBLIMITR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBLIMITR_EL1) 0 0 0#1)
  writeReg PMBSR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBSR_EL1) 63 40 0b000000000000000000000000#24)
  writeReg PMBSR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBSR_EL1) 36 32 0b00000#5)
  writeReg PMBSR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBSR_EL1) 25 20 0b000000#6)
  writeReg PMSCR_EL2 (Sail.BitVec.updateSubrange (← readReg PMSCR_EL2) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg PMSCR_EL2 (BitVec.update (← readReg PMSCR_EL2) 2 (Bit 0#1))
  writeReg PMSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSCR_EL1) 63 8 0b00000000000000000000000000000000000000000000000000000000#56)
  writeReg PMSCR_EL1 (BitVec.update (← readReg PMSCR_EL1) 2 (Bit 0#1))
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 63 26 0b00000000000000000000000000000000000000#38)
  writeReg PMSNEVFR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSNEVFR_EL1) 47 32 0b0000000000000000#16)
  writeReg PMSNEVFR_EL1 (BitVec.update (← readReg PMSNEVFR_EL1) 0 (Bit 0#1))
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 63 12 0b0000000000000000000000000000000000000000000000000000#52)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 7 6 0b00#2)
  writeReg PMSLATFR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSLATFR_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 30 25 0b000000#6)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 30 16 0b000000000000000#15)
  writeReg VDISR_EL2 (BitVec.update (← readReg VDISR_EL2) 13 (Bit 0#1))
  writeReg VDISR_EL2 (BitVec.update (← readReg VDISR_EL2) 11 (Bit 0#1))
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 8 4 0b00000#5)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 63 32 0b00000000000000000000000000000000#32)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 30 16 0b000000000000000#15)
  writeReg VDISR_EL2 (BitVec.update (← readReg VDISR_EL2) 13 (Bit 0#1))
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 11 10 0b00#2)
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 8 6 0b000#3)
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 30 25 0b000000#6)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 23 13 0b00000000000#11)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 8 6 0b000#3)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 63 32 0b00000000000000000000000000000000#32)
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 30 25 0b000000#6)
  writeReg ERRSELR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRSELR_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg VSESR_EL2 (Sail.BitVec.updateSubrange (← readReg VSESR_EL2) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg VSESR_EL2 (BitVec.update (← readReg VSESR_EL2) 13 (Bit 0#1))
  writeReg VSESR_EL2 (Sail.BitVec.updateSubrange (← readReg VSESR_EL2) 11 0 0b000000000000#12)
  writeReg VSESR_EL2 (Sail.BitVec.updateSubrange (← readReg VSESR_EL2) 63 25 0b000000000000000000000000000000000000000#39)
  writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 63 24 0b0000000000000000000000000000000000000000#40)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 23 23 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 23 23 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 21 10 0b000000000000#12)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 8 8 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 8 8 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL2 (BitVec.update (← readReg BRBCR_EL2) 7 (Bit 0#1))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 6 5 (← (__UNKNOWN_bits 2))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 6 5 (← (__UNKNOWN_bits 2))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 4 4 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 4 4 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 3 3 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 3 3 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL2 (BitVec.update (← readReg BRBCR_EL2) 2 (Bit 0#1))
  writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 1 1 0#1)
  writeReg BRBCR_EL2 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL2) 0 0 0#1)
  writeReg BRBTS_EL1 (Sail.BitVec.updateSubrange (← readReg BRBTS_EL1) 63 0 0b0000000000000000000000000000000000000000000000000000000000000000#64)
  writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 63 30 0b0000000000000000000000000000000000#34)
  writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 27 23 0b00000#5)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 21 21 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 21 21 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 20 20 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 20 20 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 19 19 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 19 19 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 18 18 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 18 18 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 17 17 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 17 17 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 16 16 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 16 16 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 15 8 0b00000000#8)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 7 7 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 7 7 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 5 0 0b000000#6)
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 63 47 0b00000000000000000#17)
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 31 18 0b00000000000000#14)
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 15 14 0b00#2)
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 4 2 0b000#3)
  writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 63 24 0b0000000000000000000000000000000000000000#40)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 23 23 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 23 23 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 22 22 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 21 10 0b000000000000#12)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 8 8 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 8 8 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL1 (BitVec.update (← readReg BRBCR_EL1) 7 (Bit 0#1))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 6 5 (← (__UNKNOWN_bits 2))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 6 5 (← (__UNKNOWN_bits 2))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 4 4 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 4 4 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_BRBEv1p1)))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 3 3 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (IsFeatureImplemented FEAT_BRBEv1p1))))))) : Bool)
  then (do writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 3 3 (← (__UNKNOWN_bits 1))))
  else (do (pure ())))
  writeReg BRBCR_EL1 (BitVec.update (← readReg BRBCR_EL1) 2 (Bit 0#1))
  writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 1 1 0#1)
  writeReg BRBCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBCR_EL1) 0 0 0#1)
  writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 63 16 0b000000000000000000000000000000000000000000000000#48)
  writeReg GCSPR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL3) 2 0 0b000#3)
  writeReg GCSPR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL1) 2 0 0b000#3)
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 63 10 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 9 9 0#1)
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 8 8 0#1)
  writeReg GCSCR_EL3 (BitVec.update (← readReg GCSCR_EL3) 7 (Bit 0#1))
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 6 6 0#1)
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 4 1 0b0000#4)
  writeReg GCSCR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL3) 0 0 0#1)
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 63 10 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 9 9 0#1)
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 8 8 0#1)
  writeReg GCSCR_EL1 (BitVec.update (← readReg GCSCR_EL1) 7 (Bit 0#1))
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 6 6 0#1)
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 4 1 0b0000#4)
  writeReg GCSCR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL1) 0 0 0#1)
  writeReg GCSPR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL2) 2 0 0b000#3)
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 63 10 0b000000000000000000000000000000000000000000000000000000#54)
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 9 9 0#1)
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 8 8 0#1)
  writeReg GCSCR_EL2 (BitVec.update (← readReg GCSCR_EL2) 7 (Bit 0#1))
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 6 6 0#1)
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 4 1 0b0000#4)
  writeReg GCSCR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSCR_EL2) 0 0 0#1)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 63 11 0b00000000000000000000000000000000000000000000000000000#53)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 10 10 0#1)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 9 9 0#1)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 8 8 0#1)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 7 6 0b00#2)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 4 1 0b0000#4)
  writeReg GCSCRE0_EL1 (Sail.BitVec.updateSubrange (← readReg GCSCRE0_EL1) 0 0 0#1)
  writeReg GCSPR_EL0 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL0) 2 0 0b000#3)
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 8 (← (PAR_EL1_read ())) 120 0b00000000#8)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 11 (← (PAR_EL1_read ())) 65 0b00000000000#11)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 44 (← (PAR_EL1_read ())) 12 0b00000000000000000000000000000000000000000000#44)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 6 (← (PAR_EL1_read ())) 1 0b000000#6)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 63 (← (PAR_EL1_read ())) 65 0b000000000000000000000000000000000000000000000000000000000000000#63)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 32 (← (PAR_EL1_read ())) 16 0b00000000000000000000000000000000#32)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 11 1#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 10 0#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 7 0#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 63 (← (PAR_EL1_read ())) 65 0b000000000000000000000000000000000000000000000000000000000000000#63)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 4 (← (PAR_EL1_read ())) 52 0b0000#4)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 6 (← (PAR_EL1_read ())) 1 0b000000#6)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 63 (← (PAR_EL1_read ())) 65 0b000000000000000000000000000000000000000000000000000000000000000#63)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 32 (← (PAR_EL1_read ())) 16 0b00000000000000000000000000000000#32)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 11 1#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 10 0#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 7 0#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 4 (← (PAR_EL1_read ())) 52 0b0000#4)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 6 (← (PAR_EL1_read ())) 1 0b000000#6)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 32 (← (PAR_EL1_read ())) 16 0b00000000000000000000000000000000#32)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 11 1#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 10 0#1)))
  (PAR_EL1_write (Mk_PAR_EL1_Type (set_slice 1 (← (PAR_EL1_read ())) 7 0#1)))
  (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (set_slice 40 (← (TTBR1_EL1_read ())) 88 0b0000000000000000000000000000000000000000#40)))
  (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (set_slice 16 (← (TTBR1_EL1_read ())) 64 0b0000000000000000#16)))
  (TTBR1_EL1_write (Mk_TTBR1_EL1_Type (set_slice 2 (← (TTBR1_EL1_read ())) 3 0b00#2)))
  (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (set_slice 40 (← (TTBR0_EL2_read ())) 88 0b0000000000000000000000000000000000000000#40)))
  (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (set_slice 16 (← (TTBR0_EL2_read ())) 64 0b0000000000000000#16)))
  (TTBR0_EL2_write (Mk_TTBR0_EL2_Type (set_slice 2 (← (TTBR0_EL2_read ())) 3 0b00#2)))
  (VTTBR_EL2_write (Mk_VTTBR_EL2_Type (set_slice 40 (← (VTTBR_EL2_read ())) 88 0b0000000000000000000000000000000000000000#40)))
  (VTTBR_EL2_write (Mk_VTTBR_EL2_Type (set_slice 16 (← (VTTBR_EL2_read ())) 64 0b0000000000000000#16)))
  (VTTBR_EL2_write (Mk_VTTBR_EL2_Type (set_slice 2 (← (VTTBR_EL2_read ())) 3 0b00#2)))
  (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (set_slice 40 (← (TTBR0_EL1_read ())) 88 0b0000000000000000000000000000000000000000#40)))
  (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (set_slice 16 (← (TTBR0_EL1_read ())) 64 0b0000000000000000#16)))
  (TTBR0_EL1_write (Mk_TTBR0_EL1_Type (set_slice 2 (← (TTBR0_EL1_read ())) 3 0b00#2)))
  writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 127 88 0b0000000000000000000000000000000000000000#40)
  writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 79 64 0b0000000000000000#16)
  writeReg TTBR1_EL2 (Sail.BitVec.updateSubrange (← readReg TTBR1_EL2) 4 3 0b00#2)

def undefined_AMDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMIIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTFID0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVARCH_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_TYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ID_AA64DFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64DFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def EncodePARange (_ : Unit) : SailM (BitVec 4) := do
  match (← readReg __supported_pa_size) with
  | 32 => (pure 0b0000#4)
  | 36 => (pure 0b0001#4)
  | 40 => (pure 0b0010#4)
  | 42 => (pure 0b0011#4)
  | 44 => (pure 0b0100#4)
  | 48 => (pure 0b0101#4)
  | 52 =>
    (do
      sail_assert (← (Have52BitPAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:79.33-79.34"
      (pure 0b0110#4))
  | 56 =>
    (do
      sail_assert (← (Have56BitPAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:83.33-83.34"
      (pure 0b0111#4))
  | _ => (pure 0b0110#4)

def EncodeVARange (_ : Unit) : SailM (BitVec 4) := do
  match (← readReg __supported_va_size) with
  | 48 => (pure 0b0000#4)
  | 52 =>
    (do
      sail_assert (← (Have52BitVAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:98.33-98.34"
      (pure 0b0001#4))
  | 56 =>
    (do
      sail_assert (← (Have56BitVAExt ())) "sail-arm/arm-v9.4-a/src/reset.sail:102.33-102.34"
      (pure 0b0001#4))
  | _ => (do (undefined_bitvector 4))

/-- Type quantifiers: i : Int -/
def IsG1ActivityMonitorImplemented (i : Int) : SailM Bool := do
  sail_assert ((0 ≤b i) && (i <b 16)) "sail-arm/arm-v9.4-a/src/impdefs.sail:870.26-870.27"
  (pure ((BitVec.access (← readReg __g1_activity_monitor_implemented) i) == 1#1))

/-- Type quantifiers: i : Int -/
def IsG1ActivityMonitorOffsetImplemented (i : Int) : SailM Bool := do
  sail_assert ((0 ≤b i) && (i <b 16)) "sail-arm/arm-v9.4-a/src/impdefs.sail:877.26-877.27"
  (pure ((BitVec.access (← readReg __g1_activity_monitor_offset_implemented) i) == 1#1))

def Mk_CCSIDR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_CNTFID0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMCEID1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ERRIDR_EL1_Type_NUM (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_ID_AA64DFR0_EL1_Type_BRPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 15 12)

def _get_ID_AA64DFR0_EL1_Type_CTX_CMPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 31 28)

def _get_ID_AA64DFR0_EL1_Type_PMUVer (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 11 8)

def _get_ID_AA64DFR0_EL1_Type_TraceFilt (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 43 40)

def _get_ID_AA64DFR0_EL1_Type_TraceVer (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 7 4)

def _get_ID_AA64DFR0_EL1_Type_WRPs (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_ID_AA64PFR0_EL1_Type_AdvSIMD (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_ID_AA64PFR0_EL1_Type_EL0 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ID_AA64PFR0_EL1_Type_EL1 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 7 4)

def _get_ID_AA64PFR0_EL1_Type_EL2 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 11 8)

def _get_ID_AA64PFR0_EL1_Type_EL3 (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 15 12)

def _get_ID_AA64PFR0_EL1_Type_GIC (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 27 24)

def _get_ID_AA64PFR0_EL1_Type_MPAM (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 43 40)

def _get_ID_AA64PFR1_EL1_Type_MPAM_frac (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _update_ICC_CTLR_EL1_Type_A3V (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_ICC_CTLR_EL1_Type_ExtRange (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _update_ICC_CTLR_EL1_Type_IDbits (v : (BitVec 64)) (x : (BitVec 3)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 13 11 x)

def _update_ICC_CTLR_EL1_Type_PRIbits (v : (BitVec 64)) (x : (BitVec 3)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 10 8 x)

def AArch64_IMPDEFResets (_ : Unit) : SailM Unit := do
  writeReg DCZID_EL0 (Sail.BitVec.updateSubrange (← readReg DCZID_EL0) 4 4 0#1)
  writeReg DCZID_EL0 (Sail.BitVec.updateSubrange (← readReg DCZID_EL0) 3 0 (integer_subrange (← readReg __dczid_log2_block_size) 3 0))
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 15 0 (Sail.BitVec.zeroExtend 0x4#4 16))
  let loop_i_lower := 0
  let loop_i_upper ← (( do (pure ((BitVec.toNat (_get_ERRIDR_EL1_Type_NUM (← readReg ERRIDR_EL1))) -i 1)) ) : SailM Int )
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      sail_assert ((0 ≤b i) && (i <b 4)) "sail-arm/arm-v9.4-a/src/reset.sail:432.55-432.56"
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 54 53 0b11#2))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 52 52 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 51 51 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 50 50 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 49 49 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 48 48 1#1))
      writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) i (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) i) 31 31 1#1))
  (pure loop_vars)
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 25 24 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 23 22 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 21 20 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 19 18 0b01#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 17 16 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 15 15 1#1))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 14 12 0b100#3))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 11 10 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 9 8 0b11#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 7 6 0b10#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 5 4 0b11#2))
  writeReg ERRnFR (vectorUpdate (← readReg ERRnFR) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg ERRnFR) 0) 1 0 0b10#2))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 31 24 (Zeros (n := 8)))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 23 16
    (← do
      (if ((IsZero (_get_PMCR_EL0_Type_IMP (← readReg PMCR_EL0))) : Bool)
      then (do (pure (Zeros (n := 8))))
      else (do (pure CFG_PMCR_IDCODE)))))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 15 11 (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 2 2 0#1)
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 1 1 0#1)
  writeReg PMCEID0_EL0 (Mk_PMCEID0_EL0_Type (Sail.BitVec.zeroExtend 0b111101001000000000100000000100000001#36 64))
  writeReg PMCEID1_EL0 (Mk_PMCEID1_EL0_Type (Zeros (n := 64)))
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 31 28 0b0000#4)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 21 21 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 19 19 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 18 18 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 17 17 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 16 16 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 15 15 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 14 14 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 13 8 0b111111#6)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 7 0 (0b000#3 +++ (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 7 4 0b0001#4)
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 3 0 0b0110#4)
  writeReg PMPIDR0 (Sail.BitVec.updateSubrange (← readReg PMPIDR0) 7 0 0b00001111#8)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 7 4 0b1011#4)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 3 0 0b1101#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 7 4 0b0000#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 3 3 1#1)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 2 0 0b011#3)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 7 4 0b0000#4)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 3 0 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 7 4 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 3 0 0b0100#4)
  writeReg PMCIDR0 (Sail.BitVec.updateSubrange (← readReg PMCIDR0) 7 0 0b00001101#8)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 7 4 0b1001#4)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 3 0 0b0000#4)
  writeReg PMCIDR2 (Sail.BitVec.updateSubrange (← readReg PMCIDR2) 7 0 0b00000101#8)
  writeReg PMCIDR3 (Sail.BitVec.updateSubrange (← readReg PMCIDR3) 7 0 0b10110001#8)
  writeReg CNTFID0 (Mk_CNTFID0_Type (← readReg __CNTbase_frequency))
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 51 48 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 39 36 0b1111#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0010#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 43 40 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 31 28 (integer_subrange ((← readReg __num_ctx_breakpoints) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 23 20 (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 15 12 (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0))
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 7 4 0b0001#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1001#4)
  (if ((← (IsFeatureImplemented FEAT_RME)) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 55 52 0b0001#4)
        writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 23 20 (← readReg __rme_l0gptsz)))
  else (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 55 52 0b0000#4)))
  (if ((← (IsFeatureImplemented FEAT_BRBE)) : Bool)
  then
    (do writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 55 52 0b0010#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 15 12 0b0101#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 11 8 0b0000#4)
        writeReg BRBIDR0_EL1 (Sail.BitVec.updateSubrange (← readReg BRBIDR0_EL1) 7 0 (integer_subrange (← readReg NUM_BRBE_RECORDS) 7 0)))
  else (do (pure ())))
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 47 44 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 43 40 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 39 36 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 35 32 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 31 28 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 19 16 0b0000#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0010#4)
  writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 3 0 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 43 40 0b0011#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 35 32 0b0011#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 39 36 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 47 44 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 59 56 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 63 60 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 31 28 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 23 20 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 27 24 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 19 16 0b0000#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 7 4 0b0010#4)
  writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 3 0 (← (EncodePARange ())))
  writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 19 16 (← (EncodeVARange ())))
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 31 28 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 27 24 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 19 16 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 11 8 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 7 4 0b0000#4)
  writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 35 32 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 15 12 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 11 8 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 7 4 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 3 0 0b0010#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 63 60 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 59 56 0b0010#4)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 3 0 0b0001#4)
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 7 4 0b0001#4)
  (if ((← (HaveCNTSCExt ())) : Bool)
  then (do writeReg CNTID (Sail.BitVec.updateSubrange (← readReg CNTID) 3 0 0b0001#4))
  else (do (pure ())))
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 47 44 0b0001#4)
  writeReg AMCIDR0 (Sail.BitVec.updateSubrange (← readReg AMCIDR0) 7 0 0b00001101#8)
  writeReg AMCIDR1 (Sail.BitVec.updateSubrange (← readReg AMCIDR1) 7 4 0b1001#4)
  writeReg AMCIDR2 (Sail.BitVec.updateSubrange (← readReg AMCIDR2) 7 0 0b00000101#8)
  writeReg AMCIDR3 (Sail.BitVec.updateSubrange (← readReg AMCIDR3) 7 0 0b10110001#8)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 7 0 0b00010011#8)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 13 8 0b111111#6)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 24 24 1#1)
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 31 28 (integer_subrange ((← readReg NUM_AMU_COUNTER_GROUPS) -i 1) 3 0))
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 7 0 (integer_subrange (← readReg NUM_AMU_CG0_MONITORS) 7 0))
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 15 8 (integer_subrange (← readReg NUM_AMU_CG1_MONITORS) 7 0))
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 31 21 (0b0100#4 +++ 0b0111011#7))
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 20 20 1#1)
  writeReg AMDEVARCH (Sail.BitVec.updateSubrange (← readReg AMDEVARCH) 15 0 (0b0000#4 +++ 0b101001100110#12))
  writeReg AMDEVTYPE (Sail.BitVec.updateSubrange (← readReg AMDEVTYPE) 7 4 0b0001#4)
  writeReg AMDEVTYPE (Sail.BitVec.updateSubrange (← readReg AMDEVTYPE) 3 0 0b0110#4)
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 0) 15 0 0b0000000000010001#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 1 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 1) 15 0 0b0100000000000100#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 2 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 2) 15 0 0b0000000000001000#16))
  writeReg AMEVTYPER0_EL0 (vectorUpdate (← readReg AMEVTYPER0_EL0) 3 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVTYPER0_EL0) 3) 15 0 0b0100000000000101#16))
  writeReg AMIIDR (Sail.BitVec.updateSubrange (← readReg AMIIDR) 11 0 0b010000111011#12)
  writeReg AMPIDR1 (Sail.BitVec.updateSubrange (← readReg AMPIDR1) 7 4 0b1011#4)
  writeReg AMPIDR2 (Sail.BitVec.updateSubrange (← readReg AMPIDR2) 3 3 1#1)
  writeReg AMPIDR2 (Sail.BitVec.updateSubrange (← readReg AMPIDR2) 2 0 0b011#3)
  writeReg AMPIDR4 (Sail.BitVec.updateSubrange (← readReg AMPIDR4) 3 0 0b0100#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 51 48 0b0001#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 27 24 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 23 20 0b0000#4)
  writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 19 16 0b0000#4)
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 31 0 (← readReg CFG_MPIDR))
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 39 32 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 30 30 0#1)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 24 24 0#1)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 23 16 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 15 8 0b00000000#8)
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 7 0 0b00000000#8)
  (VMPIDR_write (_update_VMPIDR_Type_M (← (VMPIDR_read ())) 1#1))
  (if ((HasArchVersion v8Ap1) : Bool)
  then
    (do writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 27 24 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 19 16 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0010#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_CRC32)) : Bool)
  then
    (do writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_VMID16)) : Bool)
  then (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 7 4 0b0010#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_PAN)) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0001#4)
        writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_AES))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0000#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_AES)) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0001#4))
  else (do (pure ())))
  (if ((←((IsFeatureImplemented FEAT_AES) <&&> (do
       (IsFeatureImplemented FEAT_PMULL)))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 7 4 0b0010#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_SHA1))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 11 8 0b0000#4))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_SHA256))) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0000#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap2) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 3 0 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 7 4 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 15 12 0b0001#4)
        writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 19 16 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 39 36 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 11 8 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 15 12 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 23 20 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 7 4 0b0001#4)
        (if ((HaveEL EL2) : Bool)
        then
          (do writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0010#4)
              writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 59 56 0b0010#4))
        else
          (do writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0000#4)
              writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 59 56 0b0000#4)))
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 28 0b0000#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 63 63 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 32 32 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 34 34 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 35 35 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 39 36 0b1111#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 48 48 1#1)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 55 52 0b1111#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 3 0 0b0010#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 7 4 0b0001#4)
        (if ((← (HaveDoPD ())) : Bool)
        then
          (do writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 7 4 0b0001#4)
              writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 19 16 0b0001#4))
        else
          (do writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 7 4 0b0000#4)
              writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 19 16 0b0000#4)))
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 35 32 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 7 4 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 3 0 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 51 48 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 47 44 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 55 52 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 27 24 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap6) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 47 44 0b0010#4)
        writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 59 56 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_DotProd)) : Bool)
  then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 47 44 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_FP16)) : Bool)
  then
    (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 19 16 0b0001#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 23 20 0b0001#4))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_AA32HPD)) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 15 12 0b0010#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 19 16 0b0010#4))
  else (do (pure ())))
  (if ((← (HaveMPAMExt ())) : Bool)
  then
    (do (if ((← readReg __empam_force_ns_implemented) : Bool)
        then
          (do writeReg __mpam_major CFG_MPAM_v0p1
              writeReg __mpam_frac CFG_MPAM_frac_v0p1
              writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 60 60 1#1))
        else
          (do writeReg __mpam_major CFG_MPAM_v1p1
              writeReg __mpam_frac CFG_MPAM_frac_v1p1))
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 43 40 (← readReg __mpam_major))
        writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 15 0 (← readReg __mpam_partid_max))
        writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 39 32 (← readReg __mpam_pmg_max))
        (if ((← readReg __mpam_has_hcr) : Bool)
        then
          (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 17 17 1#1)
              writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 20 18 (← readReg __mpam_vpmr_max)))
        else (do (pure ())))
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 19 16 (← readReg __mpam_frac))
        sail_assert (←((pure ((BitVec.toNat (_get_ID_AA64PFR0_EL1_Type_MPAM (← readReg ID_AA64PFR0_EL1))) >b 1)) <||> (do
          (do
            let b__0 ← do (pure (_get_ID_AA64PFR0_EL1_Type_MPAM (← readReg ID_AA64PFR0_EL1)))
            (if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
            then (do (pure true))
            else (do (pure false)))) <&&> (do
            (pure ((_get_ID_AA64PFR1_EL1_Type_MPAM_frac (← readReg ID_AA64PFR1_EL1)) == 0b0001#4)))))) "sail-arm/arm-v9.4-a/src/reset.sail:720.56-720.57"
        (if ((← readReg __empam_sdeflt_implemented) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 61 61 1#1))
        else (do (pure ())))
        (if ((← readReg __empam_tidr_implemented) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 58 58 1#1))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure (HasArchVersion v9Ap2)) <&&> (do
       (HaveRME ())))) : Bool)
  then
    (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 59 59 1#1)
        (if ((← readReg __mpam_has_altsp) : Bool)
        then (do writeReg MPAMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPAMIDR_EL1) 57 57 1#1))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap3) : Bool)
  then
    (do (if ((← (IsFeatureImplemented FEAT_PACQARMA3)) : Bool)
        then
          (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 11 8 0b0001#4)
              writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 15 12 0b0101#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 7 4 0b0000#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 27 24 0b0000#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_PACQARMA5)) : Bool)
        then
          (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 11 8 0b0000#4)
              writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 15 12 0b0000#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 7 4 0b0101#4)
              writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 27 24 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_CONSTPACFIELD)) : Bool)
        then (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 27 24 0b0001#4))
        else (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 27 24 0b0000#4)))
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 15 12 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 19 16 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 3 0 0b0001#4)
        writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 27 24 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 27 24 0b0001#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 23 20 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then
    (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 31 28 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 35 32 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 51 48 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 43 40 0b0001#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 27 24 0b0010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1001#4)
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b0000#4))
        else (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 39 36 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 59 56 0b0010#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 55 52 0b0000#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 51 48 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 11 8 0b0001#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0010#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 55 52 (integer_subrange (← readReg __block_bbm_implemented) 3 0))
        (if ((← (IsFeatureImplemented FEAT_SHA512)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 15 12 0b0010#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SHA3)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 35 32 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SM3)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 39 36 0b0001#4))
        else (do (pure ())))
        (if ((← (IsFeatureImplemented FEAT_SM4)) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 43 40 0b0001#4))
        else (do (pure ())))
        (if ((← (HavePMUv3p4 ())) : Bool)
        then
          (do (if ((← (HavePMUv3TH ())) : Bool)
              then (do writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 23 20 0b1100#4))
              else (do (pure ())))
              writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 19 16 0b0100#4)
              writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 15 8 0b00000011#8))
        else (do (pure ()))))
  else (do (pure ())))
  writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 7 4 0b0010#4)
  (if ((HasArchVersion v8Ap5) : Bool)
  then
    (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 55 52 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 35 32 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 3 0 0b0001#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b0110#4)
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 63 60 0b0001#4)
        writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 63 60 0b0001#4)
        (if ((← (HaveMTE2Ext ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0010#4))
        else (do (pure ())))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b0110#4)
        writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 11 8 0b0000#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 15 12 0b0001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 19 16 0b0001#4))
  else (do (pure ())))
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 23 20 0b0000#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 11 8 0b0000#4)
  (if ((HasArchVersion v8Ap6) : Bool)
  then (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 35 32 0b0001#4))
  else (do (pure ())))
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 19 16 0b0010#4)
  writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 51 48 0b0001#4)
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 3 0 0b0001#4)
  (if ((HasArchVersion v8Ap7) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 43 40 0b0001#4)
        (if (((! (HaveEL EL3)) && (HaveEL EL2)) : Bool)
        then (do writeReg HCRX_EL2 (Mk_HCRX_EL2_Type (Zeros (n := 64))))
        else (do (pure ())))
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b0111#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b0111#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0011#4)
        (if ((← readReg __feat_rpres) : Bool)
        then (do writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 7 4 0b0001#4))
        else (do (pure ())))
        (if ((← (Have52BitIPAAndPASpaceExt ())) : Bool)
        then
          (do writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 31 28 0b0001#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 43 40 0b0011#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 23 20 0b0010#4)
              writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 35 32 0b0011#4))
        else (do (pure ())))
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 59 56 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 3 0 0b0010#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 23 20 0b0011#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0011#4)
        (if ((← (HaveFeatLS64_ACCDATA ())) : Bool)
        then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0011#4))
        else
          (do (if ((← (HaveFeatLS64_V ())) : Bool)
              then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0010#4))
              else
                (do (if ((← (HaveFeatLS64 ())) : Bool)
                    then (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0001#4))
                    else (do writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 63 60 0b0000#4))))))))
  else (do (pure ())))
  writeReg GICD_TYPER (BitVec.update (← readReg GICD_TYPER) 9 (Bit 1#1))
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 31 27 0b11111#5)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 18 18 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 17 17 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 16 16 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 8 8 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 10 10 1#1)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 4 0 0b00111#5)
  writeReg GICD_TYPER (Sail.BitVec.updateSubrange (← readReg GICD_TYPER) 23 19 0b01111#5)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 5 5 1#1)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 4 4 0#1)
  writeReg PMBIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMBIDR_EL1) 3 0 0b0000#4)
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 32 32 0#1)
  (if ((← (IsFeatureImplemented FEAT_SME)) : Bool)
  then
    (do writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 31 24 0b01000001#8)
        writeReg SMIDR_EL1 (Sail.BitVec.updateSubrange (← readReg SMIDR_EL1) 15 15 1#1)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 27 24 0b0001#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0001#4))
  else (do (pure ())))
  (if ((HasArchVersion v9Ap3) : Bool)
  then
    (do (if ((← (IsFeatureImplemented FEAT_MEC)) : Bool)
        then
          (do writeReg MECIDR_EL2 (Sail.BitVec.updateSubrange (← readReg MECIDR_EL2) 3 0 (← readReg __mecid_width))
              writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 31 28 0b0001#4))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← (IsFeatureImplemented FEAT_SME2)) : Bool)
  then
    (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 27 24 0b0010#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 59 56 0b0001#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 47 44 0b0101#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 33 33 1#1))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 39 36 0b0010#4)
        writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 3 0 0b0010#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 31 28 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 19 16 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 23 20 0b0001#4)
        (if ((← (HaveStatisticalProfiling ())) : Bool)
        then (do writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0100#4))
        else (do (pure ())))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 63 60 0b0001#4)
        writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 7 4 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1010#4)
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b0000#4))
        else (do writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 59 56 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b1000#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b1000#4))
  else (do (pure ())))
  writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 27 24 0b0001#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 19 16 0b0001#4)
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 15 12 0b0001#4)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 18 18 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 17 17 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 16 16 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 15 15 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 14 14 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 13 13 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 12 12 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 11 11 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 10 10 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 9 9 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 8 8 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 7 7 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 3 3 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 2 2 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 1 1 0#1)
  writeReg SCR_EL3 (Sail.BitVec.updateSubrange (← readReg SCR_EL3) 0 0 0#1)
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 31 31 0#1)
  writeReg CPTR_EL2 (BitVec.update (← readReg CPTR_EL2)
    (← do
      (if ((←((IsFeatureImplemented FEAT_VHE) <&&> (do
           (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
      then (do (pure 28))
      else (do (pure 20)))) (Bit 0#1))
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 49 49 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 52 52 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 50 50 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 44 44 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 43 43 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 42 42 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 41 41 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 40 40 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 38 38 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 37 37 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 36 36 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 33 33 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 32 32 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 31 31 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 30 30 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 29 29 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 28 28 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 27 27 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 26 26 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 25 25 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 24 24 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 23 23 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 22 22 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 21 21 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 20 20 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 19 19 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 18 18 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 17 17 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 16 16 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 15 15 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 14 14 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 13 13 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 12 12 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 11 10 0b00#2)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 9 9 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 7 7 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 6 6 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 5 5 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 4 4 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 3 3 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 2 2 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 1 1 0#1)
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 0 0 0#1)
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 15 0 (Zeros (n := 16)))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 31 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 30 30 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 27 27 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 25 25 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 13 13 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 31 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 30 30 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 27 27 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 25 25 0#1)
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 13 13 0#1)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 28 28 0#1)
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 21 20 0b00#2)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 31 31 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 30 30 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 27 27 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 25 25 0#1)
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 13 13 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 31 31 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 30 30 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 27 27 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 25 25 0#1)
  writeReg SCTLR_EL3 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL3) 13 13 0#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 24 24 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 6 6 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 19 16 0b0011#4)
  match SPEMaxRecordSize with
  | 64 => writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 15 12 0b0110#4)
  | _ => (Unreachable ())
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 3 3 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 2 2 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 1 1 1#1)
  writeReg PMSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSIDR_EL1) 0 0 1#1)
  (if ((← (EL2Enabled ())) : Bool)
  then
    (do writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 14 14 0#1)
        writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 13 12 0b10#2))
  else (do (pure ())))
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 4 0 (_get_PMCR_EL0_Type_N (← readReg PMCR_EL0)))
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 0 0 1#1)
  writeReg ICC_SRE_EL3 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL3) 3 3 1#1)
  writeReg ICC_SRE_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_S) 0 0 1#1)
  writeReg ICC_SRE_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_NS) 0 0 1#1)
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 0 0 1#1)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 27 24 0b0100#4)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 23 20 (← readReg __exclusive_granule_size))
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 19 16 0b0100#4)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 15 14 0b10#2)
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 3 0 0b0100#4)
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 37 32 0b000100#6))
  else (do (pure ())))
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do writeReg GMID_EL1 (Sail.BitVec.updateSubrange (← readReg GMID_EL1) 3 0 (integer_subrange (← readReg __gmid_log2_block_size) 3 0)))
  else (do (pure ())))
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 23 21 0b010#3)
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 20 18 0b011#3)
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_ExtRange (← (ICC_CTLR_EL1_read ())) 1#1))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_PRIbits (← (ICC_CTLR_EL1_read ())) 0b100#3))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_A3V (← (ICC_CTLR_EL1_read ())) 1#1))
  (ICC_CTLR_EL1_write (_update_ICC_CTLR_EL1_Type_IDbits (← (ICC_CTLR_EL1_read ())) 0b001#3))
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 19 19 1#1)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 10 8 0b100#3)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 13 11 0b001#3)
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 15 15 1#1)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 29 0b100#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 28 26 0b100#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 25 23 0b001#3)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 21 21 1#1)
  writeReg CCSIDR_EL1 (Mk_CCSIDR_EL1_Type
    (set_slice 24 (← readReg CCSIDR_EL1)
      (← do
        (if ((← (IsFeatureImplemented FEAT_CCIDX)) : Bool)
        then (do (pure 32))
        else (do (pure 13)))) (Sail.BitVec.zeroExtend 0xFF#8 24)))
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 23 3 (Sail.BitVec.zeroExtend 0x1#4 21))
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 2 0 0b010#3)
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 23 0 (Sail.BitVec.zeroExtend 0xFF#8 24))
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 3 0 0b0000#4)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 7 4 0b0000#4)
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 15 12 0b0000#4)
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 3 3 (Sail.BitVec.extractLsb 0b10#2 1 1))
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 0 0 (Sail.BitVec.extractLsb 0b10#2 0 0))
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 1 0 0b11#2)
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 55 12 (Sail.BitVec.zeroExtend 0x22000#20 44))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 11 8 (_get_ID_AA64DFR0_EL1_Type_PMUVer (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 11 0 0xA15#12)
  writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 15 12 0b1011#4)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 20 20 1#1)
  writeReg EDDEVARCH (Sail.BitVec.updateSubrange (← readReg EDDEVARCH) 31 21 0b01000111011#11)
  writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 27 24 0b0001#4)
  writeReg EDDEVTYPE (Sail.BitVec.updateSubrange (← readReg EDDEVTYPE) 3 0 0b0101#4)
  writeReg EDDEVTYPE (Sail.BitVec.updateSubrange (← readReg EDDEVTYPE) 7 4 0b0001#4)
  writeReg EDPIDR0 (Sail.BitVec.updateSubrange (← readReg EDPIDR0) 7 0 (Sail.BitVec.zeroExtend 0xF#4 8))
  writeReg EDPIDR1 (Sail.BitVec.updateSubrange (← readReg EDPIDR1) 3 0 0xD#4)
  writeReg EDPIDR1 (Sail.BitVec.updateSubrange (← readReg EDPIDR1) 7 4 (Sail.BitVec.truncate 0x0B#8 4))
  writeReg EDPIDR2 (Sail.BitVec.updateSubrange (← readReg EDPIDR2) 2 0 0b011#3)
  writeReg EDPIDR2 (Sail.BitVec.updateSubrange (← readReg EDPIDR2) 3 3 1#1)
  writeReg EDCIDR0 (Sail.BitVec.updateSubrange (← readReg EDCIDR0) 7 0 0x0D#8)
  writeReg EDCIDR1 (Sail.BitVec.updateSubrange (← readReg EDCIDR1) 7 4 0b1001#4)
  writeReg EDCIDR2 (Sail.BitVec.updateSubrange (← readReg EDCIDR2) 7 0 0x05#8)
  writeReg EDCIDR3 (Sail.BitVec.updateSubrange (← readReg EDCIDR3) 7 0 0xB1#8)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 7 4 (_get_ID_AA64DFR0_EL1_Type_TraceVer (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 15 12 (_get_ID_AA64DFR0_EL1_Type_BRPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 23 20 (_get_ID_AA64DFR0_EL1_Type_WRPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 31 28 (_get_ID_AA64DFR0_EL1_Type_CTX_CMPs (← readReg ID_AA64DFR0_EL1)))
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 43 40 (_get_ID_AA64DFR0_EL1_Type_TraceFilt (← readReg ID_AA64DFR0_EL1)))
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 0 0 1#1)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 3 0 (_get_ID_AA64PFR0_EL1_Type_EL0 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 7 4 (_get_ID_AA64PFR0_EL1_Type_EL1 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 11 8 (_get_ID_AA64PFR0_EL1_Type_EL2 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 15 12 (_get_ID_AA64PFR0_EL1_Type_EL3 (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 23 20 (_get_ID_AA64PFR0_EL1_Type_AdvSIMD (← readReg ID_AA64PFR0_EL1)))
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 27 24 (_get_ID_AA64PFR0_EL1_Type_GIC (← readReg ID_AA64PFR0_EL1)))
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 13 8 0b100000#6)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 21 16 0b100000#6)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 25 24 0b01#2)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 31 21 0b01000111011#11)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 20 20 1#1)
  writeReg CTIDEVARCH (Sail.BitVec.updateSubrange (← readReg CTIDEVARCH) 15 0 0b0001101000010100#16)
  writeReg CTIDEVTYPE (Sail.BitVec.updateSubrange (← readReg CTIDEVTYPE) 7 4 0b0001#4)
  writeReg CTIDEVTYPE (Sail.BitVec.updateSubrange (← readReg CTIDEVTYPE) 3 0 0b0100#4)
  writeReg CTIPIDR4 (Sail.BitVec.updateSubrange (← readReg CTIPIDR4) 7 4 0b0000#4)
  writeReg CTIPIDR4 (Sail.BitVec.updateSubrange (← readReg CTIPIDR4) 3 0 0b0100#4)
  writeReg CTIPIDR2 (Sail.BitVec.updateSubrange (← readReg CTIPIDR2) 3 3 1#1)
  writeReg CTIPIDR2 (Sail.BitVec.updateSubrange (← readReg CTIPIDR2) 2 0 0b011#3)
  writeReg CTIPIDR1 (Sail.BitVec.updateSubrange (← readReg CTIPIDR1) 7 4 0b1011#4)
  writeReg CTIPIDR1 (Sail.BitVec.updateSubrange (← readReg CTIPIDR1) 3 0 0b1101#4)
  writeReg CTIPIDR0 (Sail.BitVec.updateSubrange (← readReg CTIPIDR0) 7 0 0b00001111#8)
  writeReg CTICIDR3 (Sail.BitVec.updateSubrange (← readReg CTICIDR3) 7 0 0b10110001#8)
  writeReg CTICIDR2 (Sail.BitVec.updateSubrange (← readReg CTICIDR2) 7 0 0b00000101#8)
  writeReg CTICIDR1 (Sail.BitVec.updateSubrange (← readReg CTICIDR1) 7 4 0b1001#4)
  writeReg CTICIDR1 (Sail.BitVec.updateSubrange (← readReg CTICIDR1) 3 0 0b0000#4)
  writeReg CTICIDR0 (Sail.BitVec.updateSubrange (← readReg CTICIDR0) 7 0 0b00001101#8)
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 28 26 (integer_subrange ((← readReg NUM_GIC_PREEMPTION_BITS) -i 1) 2 0))
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 4 0 (integer_subrange ((← readReg NUM_GIC_LIST_REGS) -i 1) 4 0))
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 29 (integer_subrange ((← readReg NUM_GIC_PRIORITY_BITS) -i 1) 2 0))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 0 0
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 0)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 1 1
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 1)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 2 2
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 2)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 3 3
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 3)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 4 4
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 4)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 5 5
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 5)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 6 6
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 6)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 7 7
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 7)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 8 8
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 8)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 9 9
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 9)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 10 10
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 10)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 11 11
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 11)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 12 12
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 12)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 13 13
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 13)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 14 14
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 14)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 15 15
    (← do
      (if ((← (IsG1ActivityMonitorImplemented 15)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 16 16
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 0)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 17 17
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 1)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 18 18
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 2)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 19 19
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 3)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 20 20
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 4)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 21 21
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 5)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 22 22
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 6)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 23 23
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 7)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 24 24
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 8)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 25 25
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 9)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 26 26
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 10)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 27 27
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 11)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 28 28
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 12)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 29 29
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 13)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 30 30
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 14)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  writeReg AMCG1IDR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCG1IDR_EL0) 31 31
    (← do
      (if ((← (IsG1ActivityMonitorOffsetImplemented 15)) : Bool)
      then (do (pure 1#1))
      else (do (pure 0#1)))))
  (if ((HasArchVersion v9Ap4) : Bool)
  then
    (do writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 63 56 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 43 40 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 35 32 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 39 36 0b0001#4)
        (if ((← (HaveLSE128 ())) : Bool)
        then (do writeReg ID_AA64ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR0_EL1) 23 20 0b0011#4))
        else (do (pure ())))
        (if ((← (HaveGCS ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 47 44 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 3 0 0b0010#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 47 44 0b0001#4)
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 59 56 0b0010#4)
        (if ((←((HaveSVE2p1 ()) <||> (do
             (HaveSME2p1 ())))) : Bool)
        then
          (do writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 43 43 1#1)
              writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 27 24 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64SMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64SMFR0_EL1) 42 42 1#1)
        writeReg PMDEVID (Sail.BitVec.updateSubrange (← readReg PMDEVID) 7 4 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 27 24 0b0001#4)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 11 8 0b0011#4)
        (if ((← (HaveFeatEBEP ())) : Bool)
        then (do writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 51 48 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR2_EL1) 19 16 0b0010#4)
        writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 3 0 0b0111#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 35 32 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 39 36 0b0001#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4)
        (if ((← (HaveMTEPermExt ())) : Bool)
        then (do writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 3 0 0b0001#4))
        else (do (pure ())))
        (if ((← (HavePFAR ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 63 60 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveDoubleFault2Ext ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 59 56 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveTHExt ())) : Bool)
        then (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 51 48 0b0001#4))
        else (do (pure ())))
        (if ((← (HaveMTE4Ext ())) : Bool)
        then
          (do writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 55 52 0b0001#4)
              writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 7 4 0b0001#4)
              writeReg ID_AA64PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR2_EL1) 11 8 0b0001#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR4_EL1) 7 4 0b0001#4)
        (if ((← (HaveRASv2Ext ())) : Bool)
        then
          (do writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 31 28 0b0011#4)
              writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 31 28 0b0011#4))
        else (do (pure ())))
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 43 40 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 47 44 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 55 52 0b0010#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 59 56 0b0010#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 39 36 0b0001#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 35 32 0b0001#4)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 31 24 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 23 16 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 15 8 0x3F#8)
        writeReg ID_AA64DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR1_EL1) 7 0 0x1F#8)
        writeReg ID_AA64PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR1_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 47 44 0b0010#4)
        writeReg ID_AA64ZFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ZFR0_EL1) 23 20 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 43 40 0b0010#4)
        writeReg ID_AA64ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR1_EL1) 23 20 0b0011#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 31 28 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 55 52 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 51 48 0b0001#4)
        writeReg ID_AA64ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64ISAR2_EL1) 43 40 0b0001#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 3 0 0b0011#4)
        writeReg ID_AA64PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64PFR0_EL1) 59 56 0b0011#4)
        writeReg ID_AA64MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR1_EL1) 63 60 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 3 0 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 11 8 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 19 16 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 15 12 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 23 20 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 27 24 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 7 4 0b0001#4)
        writeReg ID_AA64MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR3_EL1) 63 60 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 3 0 0b1011#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 11 8 0b1001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 35 32 0b0101#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 59 56 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 19 16 0b0001#4)
        writeReg PMDEVID (Sail.BitVec.updateSubrange (← readReg PMDEVID) 3 0 0b0010#4)
        writeReg PMMIR_EL1 (Sail.BitVec.updateSubrange (← readReg PMMIR_EL1) 27 24 0b0001#4)
        writeReg PMCFGR (BitVec.update (← readReg PMCFGR) 22 (Bit 1#1))
        writeReg ID_AA64MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64MMFR0_EL1) 59 56 0b0010#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 7 4 0b1011#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 3 0 0b1011#4)
        writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 27 24 0b1001#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 19 16 0b0010#4)
        writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 31 28 0b0001#4)
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 23 20
          (← do
            (if (((← readReg NUM_WATCHPOINTS) ≥b 16) : Bool)
            then (do (pure 0b1111#4))
            else (do (pure (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))))))
        writeReg ID_AA64DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AA64DFR0_EL1) 15 12
          (← do
            (if (((← readReg NUM_BREAKPOINTS) ≥b 16) : Bool)
            then (do (pure 0b1111#4))
            else (do (pure (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0)))))))
  else (do (pure ())))

/-- Type quantifiers: k_cold : Bool -/
def __Reset (cold : Bool) : SailM Unit := do
  writeReg __last_cycle_count 0
  writeReg __last_branch_valid false
  writeReg sp_rel_access_pc (Ones (n := 64))
  writeReg __cycle_count 0

/-- Type quantifiers: k_cold : Bool -/
def ResetControlRegisters (cold : Bool) : SailM Unit := do
  (if ((← (HaveAArch64 ())) : Bool)
  then (do (AArch64_AutoGen_ArchitectureReset cold))
  else (do (AArch32_AutoGen_ArchitectureReset cold)))
  (AArch32_IMPDEFResets ())
  (AArch64_IMPDEFResets ())
  (__Reset cold)

def _TLBInvalidate (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch64_ResetControlRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg PSTATE { (← readReg PSTATE) with ZA := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with SM := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with ALLINT := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with EXLOCK := 0#1 }
  (ResetControlRegisters cold_reset)
  (pure (_TLBInvalidate ()))

/-- Type quantifiers: k_cold_reset : Bool -/
def ResetExternalDebugRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 0 0 1#1)
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 3 3 1#1)
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 5 5 1#1)
  (if (cold_reset : Bool)
  then
    (do (EDSCR_write (_update_EDSCR_Type_STATUS (← (EDSCR_read ())) 0b000010#6))
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) 0b1111#4)))
  else (do (pure ())))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch64_TakeReset (cold_reset : Bool) : SailM Unit := do
  sail_assert (← (HaveAArch64 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:33499.24-33499.25"
  writeReg PSTATE { (← readReg PSTATE) with nRW := 0#1 }
  (if ((HaveEL EL3) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with EL := EL3 })
  else
    (do (if ((HaveEL EL2) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with EL := EL2 })
        else (do writeReg PSTATE { (← readReg PSTATE) with EL := EL1 }))))
  (AArch64_ResetControlRegisters cold_reset)
  writeReg PSTATE { (← readReg PSTATE) with SP := 1#1 }
  writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb 0b1111#4 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b1111#4 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b1111#4 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b1111#4 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with DIT := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  (if ((← (HaveTME ())) : Bool)
  then (do writeReg TSTATE { (← readReg TSTATE) with depth := 0 })
  else (do (pure ())))
  (AArch64_ResetGeneralRegisters ())
  (AArch64_ResetSIMDFPRegisters ())
  (AArch64_ResetSpecialRegisters ())
  (ResetExternalDebugRegisters cold_reset)
  let rv ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rv ← (( do
    (if ((HaveEL EL3) : Bool)
    then (do readReg RVBAR_EL3)
    else
      (do (if ((HaveEL EL2) : Bool)
          then (do readReg RVBAR_EL2)
          else (do readReg RVBAR_EL1)))) ) : SailM (BitVec 64) )
  sail_assert ((is_zero_subrange rv 63 (← (AArch64_PAMax ()))) && (IsZero (Sail.BitVec.extractLsb rv 1 0))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33529.73-33529.74"
  let branch_conditional : Bool := false
  (BranchTo rv BranchType_RESET branch_conditional)

/-- Type quantifiers: ec : Int -/
def AArch64_SystemAccessTrapSyndrome (instr_in : (BitVec 32)) (ec : Int) : SailM ExceptionRecord := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let instr : (BitVec 32) := instr_in
  match ec with
  | 0 => (do (ExceptionSyndrome Exception_Uncategorized))
  | 7 =>
    (do
      let except ← (ExceptionSyndrome Exception_AdvSIMDFPAccessTrap)
      (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) }))
  | 20 =>
    (do
      let except ← (ExceptionSyndrome Exception_SystemRegister128Trap)
      let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 21 20 (Sail.BitVec.extractLsb instr 20 19)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 19 17 (Sail.BitVec.extractLsb instr 7 5)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 16 14 (Sail.BitVec.extractLsb instr 18 16)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 13 10 (Sail.BitVec.extractLsb instr 15 12)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 9 6 (Sail.BitVec.extractLsb instr 4 1)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 1 (Sail.BitVec.extractLsb instr 11 8)) }
      (pure { except with syndrome := (BitVec.update except.syndrome 0 (Bit ((BitVec.access instr 21) : BitVec 1))) }))
  | 24 =>
    (do
      let except ← (ExceptionSyndrome Exception_SystemRegisterTrap)
      let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 21 20 (Sail.BitVec.extractLsb instr 20 19)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 19 17 (Sail.BitVec.extractLsb instr 7 5)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 16 14 (Sail.BitVec.extractLsb instr 18 16)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 13 10 (Sail.BitVec.extractLsb instr 15 12)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb instr 4 0)) }
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 1 (Sail.BitVec.extractLsb instr 11 8)) }
      (pure { except with syndrome := (BitVec.update except.syndrome 0 (Bit ((BitVec.access instr 21) : BitVec 1))) }))
  | 25 => (do (ExceptionSyndrome Exception_SVEAccessTrap))
  | 29 => (do (ExceptionSyndrome Exception_SMEAccessTrap))
  | _ =>
    (do
      (Unreachable ())
      (pure except))

/-- Type quantifiers: ec : Int -/
def AArch64_SystemAccessTrap (target_el : (BitVec 2)) (ec : Int) : SailM Unit := do
  sail_assert (←((pure ((HaveEL target_el) && (target_el != EL0))) <&&> (do
    (pure ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33913.86-33913.87"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (AArch64_SystemAccessTrapSyndrome (← (ThisInstr ())) ec) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_CheckFPAdvSIMDTrap (_ : Unit) : SailM Unit := do
  (if ((←((pure (HaveEL EL3)) <&&> (do
       (pure ((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1))) <&&> (do
       (EL3SDDUndefPriority ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
       (pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
       (EL2Enabled ())))) : Bool)
  then
    (do (if ((←((HaveVirtHostExt ()) <&&> (do
             (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailM Bool )
              let disabled ← (( do
                let b__0 ← do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2)))
                (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                      then (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                      else (do (pure false))))) ) : SailM Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do (AArch64_AdvSIMDFPAccessTrap EL2))
              else (do (pure ()))))
        else
          (do (if (((_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2)) == 1#1) : Bool)
              then (do (AArch64_AdvSIMDFPAccessTrap EL2))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
        then
          (do (if ((← (EL3SDDUndef ())) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (AArch64_AdvSIMDFPAccessTrap EL3))))
        else (do (pure ()))))
  else (do (pure ())))

def AArch64_CheckFPEnabled (_ : Unit) : SailM Unit := do
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
       (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
       (pure (! (← (IsInHost ()))))))) : Bool)
  then
    (do let disabled ← (( do (undefined_bool ()) ) : SailM Bool )
        let disabled ← (( do
          let b__0 ← do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1)))
          (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
          then (do (pure true))
          else
            (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure ((← readReg PSTATE).EL == EL0)))
                else (do (pure false))))) ) : SailM Bool )
        let disabled := disabled
        (if (disabled : Bool)
        then (do (AArch64_AdvSIMDFPAccessTrap EL1))
        else (do (pure ()))))
  else (do (pure ())))
  (AArch64_CheckFPAdvSIMDTrap ())

def AArch64_CheckFPAdvSIMDEnabled (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPEnabled ())
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do
       (pure (! (← (IsFullA64Enabled ()))))))) : Bool)
  then (do (SMEAccessTrap SMEExceptionType_Streaming (← readReg PSTATE).EL))
  else (do (pure ())))

def Mk_HSTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CheckFPEnabled64 (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPEnabled ())

def CheckFPAdvSIMDEnabled64 (_ : Unit) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch64_TakePhysicalSErrorException (implicit_esb : Bool) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure (! (← (IsInHost ())))) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x180#12)
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL3) || route_to_el3) : Bool)
    then (do (pure EL3))
    else
      (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))) ) : SailM (BitVec 2) )
  let except ← (( do (ExceptionSyndrome Exception_SError) ) : SailM ExceptionRecord )
  let syndrome ← (( do (AArch64_PhysicalSErrorSyndrome implicit_esb) ) : SailM (BitVec 25) )
  (if ((← (IsSErrorEdgeTriggered ())) : Bool)
  then (do (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))
  let except : ExceptionRecord := { except with syndrome := syndrome }
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_TakeVirtualSErrorException (_ : Unit) : SailM Unit := do
  let impdef_syndrome ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34186.63-34186.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34187.52-34187.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x180#12)
  let except ← (( do (ExceptionSyndrome Exception_SError) ) : SailM ExceptionRecord )
  let except ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then
      (do let except ← (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 24 (Bit (_get_VSESR_EL2_Type_IDS (← readReg VSESR_EL2)))))) })
          (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 23 0 (_get_VSESR_EL2_Type_ISS (← readReg VSESR_EL2))))) }))
    else
      (do let syndrome ← (( do (__IMPDEF_bits 25 "Virtual SError syndrome") ) : SailM (BitVec 25) )
          let impdef_syndrome : Bool := (((BitVec.access syndrome 24) : BitVec 1) == 1#1)
          (if (impdef_syndrome : Bool)
          then (do (pure { except with syndrome := syndrome }))
          else (do (pure except))))) ) : SailM ExceptionRecord )
  (ClearPendingVirtualSError ())
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def AArch64_TakePhysicalIRQException (_ : Unit) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x80#8)
  let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
  (if (route_to_el3 : Bool)
  then (do (AArch64_TakeException EL3 except preferred_exception_return vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
        then
          (do sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:34217.31-34217.32"
              (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else
          (do sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
                (pure ((← readReg PSTATE).EL == EL1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34220.50-34220.51"
              (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def AArch64_TakeVirtualIRQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34228.63-34228.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34229.52-34229.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x80#8)
  let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def AArch64_TakePhysicalFIQException (_ : Unit) : SailM Unit := do
  let route_to_el3 ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1))) ) : SailM Bool )
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x100#12)
  let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
  (if (route_to_el3 : Bool)
  then (do (AArch64_TakeException EL3 except preferred_exception_return vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
        then
          (do sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:34247.31-34247.32"
              (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else
          (do sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
                (pure ((← readReg PSTATE).EL == EL1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34250.50-34250.51"
              (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def AArch64_TakeVirtualFIQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34258.63-34258.64"
  sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do
    (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:34259.52-34259.53"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x100#12)
  let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL1 except preferred_exception_return vect_offset)

def Mk_MDSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def EffectiveMDSELR_EL1_BANK (_ : Unit) : SailM (BitVec 2) := do
  let num_bp ← (( do (NumBreakpointsImplemented ()) ) : SailM Int )
  let num_wp ← (( do (NumWatchpointsImplemented ()) ) : SailM Int )
  (if (((num_bp ≤b 16) && (num_wp ≤b 16)) : Bool)
  then (do (pure 0b00#2))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_MDCR_EL3_Type_EBWE (← readReg MDCR_EL3)) == 0#1))) <||> (do
             (pure ((← readReg PSTATE).EL != EL3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_MDCR_EL2_Type_EBWE (← readReg MDCR_EL2)) == 0#1)))) <||> (do
             (pure ((← readReg PSTATE).EL == EL1)) <&&> (do
               (pure ((_get_MDSCR_EL1_Type_EMBWE (← readReg MDSCR_EL1)) == 0#1)))))) : Bool)
        then (do (pure 0b00#2))
        else
          (do let bank ← (( do (pure (_get_MDSELR_EL1_Type_BANK (← readReg MDSELR_EL1))) ) : SailM (BitVec 2) )
              (if (((((bank == 0b11#2) && (num_bp ≤b 48)) && (num_wp ≤b 48)) || (((bank == 0b10#2) && (num_bp ≤b 32)) && (num_wp ≤b 32))) : Bool)
              then
                (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESMDSELR 2)
                    (pure __tup_1))
              else (do (pure bank)))))))

def AArch64_ClearEventCounters (_ : Unit) : SailM Unit := do
  let counters ← (( do (AArch64_GetNumEventCountersAccessible ()) ) : SailM Int )
  (if ((counters != 0) : Bool)
  then
    (do let loop_idx_lower := 0
        let loop_idx_upper := (counters -i 1)
        let mut loop_vars := ()
        for idx in [loop_idx_lower:loop_idx_upper:1]i do
          let () := loop_vars
          loop_vars ← do
            sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:34397.64-34397.65"
            writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) idx (Zeros (n := 64)))
        (pure loop_vars))
  else (do (pure ())))

def AArch64_PMUSwIncrement (sw_incr : (BitVec 32)) : SailM Unit := do
  (if ((←((pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 0#1)) <&&> (do
       (pure ((_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2)) == 0#1))))) : Bool)
  then (do (pure ()))
  else
    (do let counters ← (( do (AArch64_GetNumEventCountersAccessible ()) ) : SailM Int )
        (if ((counters != 0) : Bool)
        then
          (do let loop_idx_lower := 0
              let loop_idx_upper := (counters -i 1)
              let mut loop_vars := ()
              for idx in [loop_idx_lower:loop_idx_upper:1]i do
                let () := loop_vars
                loop_vars ← do
                  sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:34413.64-34413.65"
                  (if ((((BitVec.access sw_incr idx) : BitVec 1) == 1#1) : Bool)
                  then (do (PMUEvent__2 PMU_EVENT_SW_INCR 1 idx))
                  else (do (pure ())))
              (pure loop_vars))
        else (do (pure ())))))

def undefined_PMCCNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCCNTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_conditional : Bool -/
def SPESampleAddOpOther__1 (conditional : Bool) : SailM Unit := do
  writeReg SPESampleClass 0b00#2
  writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
    (Bit
      (if (conditional : Bool)
      then 1#1
      else 0#1)))
  writeReg SPESampleOpType OpType_Other

/-- Type quantifiers: k_conditional : Bool, k_taken : Bool -/
def SPESampleAddOpOther (conditional : Bool) (taken : Bool) : SailM Unit := do
  writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 6
    (Bit
      (if ((conditional && (! taken)) : Bool)
      then 1#1
      else 0#1)))
  (SPESampleAddOpOther__1 conditional)

def Mk_PMSICR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSIRR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMBPTR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBPTR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMSDSFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSDSFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSEVFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSNEVFR_EL1_Type_E12 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_PMSNEVFR_EL1_Type_E13 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_PMSNEVFR_EL1_Type_E14 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_PMSNEVFR_EL1_Type_E15 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_PMSNEVFR_EL1_Type_E24 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_PMSNEVFR_EL1_Type_E25 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_PMSNEVFR_EL1_Type_E26 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_PMSNEVFR_EL1_Type_E27 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_PMSNEVFR_EL1_Type_E28 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_PMSNEVFR_EL1_Type_E29 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_PMSNEVFR_EL1_Type_E30 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_PMSNEVFR_EL1_Type_E31 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_PMSNEVFR_EL1_Type_E48 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _get_PMSNEVFR_EL1_Type_E49 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_PMSNEVFR_EL1_Type_E50 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_PMSNEVFR_EL1_Type_E51 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_PMSNEVFR_EL1_Type_E52 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_PMSNEVFR_EL1_Type_E53 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_PMSNEVFR_EL1_Type_E54 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_PMSNEVFR_EL1_Type_E55 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_PMSNEVFR_EL1_Type_E56 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_PMSNEVFR_EL1_Type_E57 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_PMSNEVFR_EL1_Type_E58 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_PMSNEVFR_EL1_Type_E59 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_PMSNEVFR_EL1_Type_E60 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_PMSNEVFR_EL1_Type_E61 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_PMSNEVFR_EL1_Type_E62 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _get_PMSNEVFR_EL1_Type_E63 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def Mk_PMSFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSLATFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSNEVFR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def SPE_PMBIDR_P_Read (_ : Unit) : SailM (BitVec 1) := do
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let (owning_el, owning_ss) ← (( do
    let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
    let owning_ss : SecurityState := tup__0
    let owning_el : (BitVec 2) := tup__1
    (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
  (if ((←((pure ((BitVec.toNat owning_el) >b (BitVec.toNat (← readReg PSTATE).EL))) <||> (do
       (pure ((← readReg PSTATE).EL != EL3)) <&&> (do
         (pure (bne owning_ss (← (CurrentSecurityState ())))))))) : Bool)
  then (do (pure 1#1))
  else (do (pure 0#1)))

/-- Type quantifiers: k_is_load : Bool -/
def SPESampleExtendedLoadStore (ar : (BitVec 1)) (excl : (BitVec 1)) (at' : (BitVec 1)) (is_load : Bool) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  let ldst : (BitVec 1) :=
    if (is_load : Bool)
    then 0#1
    else 1#1
  writeReg SPESampleSubclass (((((0b000#3 +++ ar) +++ excl) +++ at') +++ 1#1) +++ ldst)
  writeReg SPESampleSubclassValid true
  (if (is_load : Bool)
  then
    (do (if ((at' == 1#1) : Bool)
        then (do writeReg SPESampleOpType OpType_LoadAtomic)
        else (do writeReg SPESampleOpType OpType_Load)))
  else (do writeReg SPESampleOpType OpType_Store))

def SPESampleGeneralPurposeLoadStore (_ : Unit) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 (Zeros (n := 7)))
  writeReg SPESampleSubclassValid true

def SPESampleSIMDFPLoadStore (_ : Unit) : SailM Unit := do
  writeReg SPESampleClass 0b01#2
  writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0000010#7)
  writeReg SPESampleSubclassValid true

def SPEISB (_ : Unit) : SailM Unit := do
  let address ← (( do (pure (BitVec.addInt (← (PC_read ())) 4)) ) : SailM (BitVec 64) )
  let branch_type : BranchType := BranchType_DIR
  let branch_conditional : Bool := false
  let taken : Bool := false
  let is_isb : Bool := true
  (SPEBranch__1 address branch_type branch_conditional taken is_isb)

def Mk_BRBINFINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBSRCINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBSRCINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBTGTINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTGTINJ_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def BRBEBranchOnISB (_ : Unit) : SailM Bool := do
  (__IMPDEF_boolean "ISB generates Branch records")

def BRBEISB (_ : Unit) : SailM Unit := do
  let branch_conditional : Bool := false
  (BRBEBranch BranchType_DIR branch_conditional (BitVec.addInt (← (PC_read ())) 4))

/-- Type quantifiers: k_branch_conditional : Bool -/
def BranchNotTaken (branchtype : BranchType) (branch_conditional : Bool) : SailM Unit := do
  let branchtaken : Bool := false
  (if ((← (HaveStatisticalProfiling ())) : Bool)
  then (do (SPEBranch (← (__UNKNOWN_bits 64)) branchtype branch_conditional branchtaken))
  else (do (pure ())))

def AArch64_PendingUnmaskedPhysicalInterrupts (mask_in : (BitVec 3)) : SailM (Bool × Bool × Bool) := do
  let fiq ← (( do (undefined_bool ()) ) : SailM Bool )
  let fiq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_nmi ← (( do (undefined_bool ()) ) : SailM Bool )
  let mask : (BitVec 3) := mask_in
  let se_pending : (BitVec 1) :=
    if ((IsPhysicalSErrorPending ()) : Bool)
    then 1#1
    else 0#1
  let (irq, irq_nmi) ← (( do
    let (tup__0, tup__1) ← do (IRQPending ())
    let irq : Bool := tup__0
    let irq_nmi : Bool := tup__1
    (pure (irq, irq_nmi)) ) : SailM (Bool × Bool) )
  let (fiq, fiq_nmi) : (Bool × Bool) :=
    let (tup__0, tup__1) := ((FIQPending ()) : (Bool × Bool))
    let fiq : Bool := tup__0
    let fiq_nmi : Bool := tup__1
    (fiq, fiq_nmi)
  let irq_pending : (BitVec 1) :=
    if (irq : Bool)
    then 1#1
    else 0#1
  let fiq_pending : (BitVec 1) :=
    if (fiq : Bool)
    then 1#1
    else 0#1
  let allintmask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (allintmask, mask) ← (( do
    (if ((←((HaveFeatNMI ()) <&&> (do
         (pure ((_get_SCTLRType_NMI (← (SCTLR_read__1 ()))) == 1#1))))) : Bool)
    then
      (do let allintmask ← (pure ((← readReg PSTATE).ALLINT ||| ((← readReg PSTATE).SP &&& (_get_SCTLRType_SPINTMASK (← (SCTLR_read__1 ()))))))
          let mask ← (( do
            (if ((((← readReg PSTATE).EL == EL0) || (allintmask == 0#1)) : Bool)
            then
              (do let mask : (BitVec 3) :=
                    if (irq_nmi : Bool)
                    then (BitVec.update mask 1 (Bit 0#1))
                    else mask
                  (if (fiq_nmi : Bool)
                  then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                  else (do (pure mask))))
            else (do (pure mask))) ) : SailM (BitVec 3) )
          (pure (allintmask, mask)))
    else
      (do let allintmask : (BitVec 1) := 0#1
          (pure (allintmask, mask)))) ) : SailM ((BitVec 1) × (BitVec 3)) )
  let pending : (BitVec 3) := ((se_pending +++ irq_pending) +++ fiq_pending)
  let mask ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do let mask_override ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
          let mask_override ← (( do
            (if ((←((HaveVirtHostExt ()) <&&> (do
                 (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))) <&&> (do
                 (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
            then (do (pure 0b000#3))
            else
              (do (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1) : Bool)
                  then (do (pure 0b111#3))
                  else (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))))))))) ) : SailM (BitVec 3) )
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
          then (do (pure (mask &&& (Complement.complement mask_override))))
          else
            (do (if (((← readReg PSTATE).EL == EL2) : Bool)
                then
                  (do (if ((←((pure (! (← (ELUsingAArch32 EL2)))) <&&> (do
                           (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
                      then (do (pure (mask ||| (Complement.complement mask_override))))
                      else (do (pure mask))))
                else (do (pure mask))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let mask ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do (if (((← readReg PSTATE).EL != EL3) : Bool)
          then (do (pure (mask &&& (Complement.complement ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) +++ ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))))))))
          else (do (pure (mask ||| (Complement.complement ((_get_SCR_EL3_Type_EA (← readReg SCR_EL3)) +++ ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))))))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let mask ← (( do
    (if ((((← readReg PSTATE).EL != EL0) && (allintmask == 1#1)) : Bool)
    then
      (do (if (((← readReg PSTATE).EL == EL1) : Bool)
          then
            (do let mask ← (( do
                  (if ((←((pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 0#1)) <&&> (do
                       (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 0#1))))) : Bool)
                  then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                  else (do (pure mask))) ) : SailM (BitVec 3) )
                (if ((←((pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 0#1)) <&&> (do
                     (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 0#1))))) : Bool)
                then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                else (do (pure mask))))
          else
            (do (if (((← readReg PSTATE).EL == EL2) : Bool)
                then
                  (do let mask ← (( do
                        (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
                      then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                      else (do (pure mask))))
                else
                  (do let mask ← (( do
                        (if (((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1) : Bool)
                      then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                      else (do (pure mask))))))))
    else (do (pure mask))) ) : SailM (BitVec 3) )
  let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
  (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))

def AArch32_PendingUnmaskedPhysicalInterrupts (_ : Unit) : SailM (Bool × Bool × Bool) := do
  let fiq ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq ← (( do (undefined_bool ()) ) : SailM Bool )
  let mask_override ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  (if ((←((pure (HaveEL EL3)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
  then (do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
  else
    (do let se_pending : (BitVec 1) :=
          if ((IsPhysicalSErrorPending ()) : Bool)
          then 1#1
          else 0#1
        let irq ← (( do
          let (__tup_0, _) ← do (IRQPending ())
          (pure __tup_0) ) : SailM Bool )
        let fiq : Bool :=
          let (__tup_0, _) := (FIQPending ())
          __tup_0
        let irq_pending : (BitVec 1) :=
          if (irq : Bool)
          then 1#1
          else 0#1
        let fiq_pending : (BitVec 1) :=
          if (fiq : Bool)
          then 1#1
          else 0#1
        let pending : (BitVec 3) := ((se_pending +++ irq_pending) +++ fiq_pending)
        let mask ← (( do (pure ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))) ) : SailM (BitVec 3) )
        let mask ← (( do
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then
            (do let mask_override ← (( do
                  (if (((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1) : Bool)
                  then (do (pure 0b111#3))
                  else (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) +++ ((_get_HCR_Type_IMO (← (HCR_read ()))) +++ (_get_HCR_Type_FMO (← (HCR_read ())))))))) ) : SailM (BitVec 3) )
                (pure (mask &&& (Complement.complement mask_override))))
          else (do (pure mask))) ) : SailM (BitVec 3) )
        let mask ← (( do
          (if ((←((pure (HaveEL EL3)) <&&> (do
               (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
          then
            (do (if (((← readReg PSTATE).EL != EL3) : Bool)
                then
                  (do let mask ← (( do
                        (if ((←((pure ((_get_SCR_Type_FIQ (← readReg SCR)) == 1#1)) <&&> (do
                             (pure ((_get_SCR_Type_FW (← readReg SCR)) == 0#1)) <||> (do
                               (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1)))))) : Bool)
                        then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      let mask ← (( do
                        (if ((←((pure ((_get_SCR_Type_IRQ (← readReg SCR)) == 1#1)) <&&> (do
                             (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1))))) : Bool)
                        then (do (pure (BitVec.update mask 1 (Bit 0#1))))
                        else (do (pure mask))) ) : SailM (BitVec 3) )
                      (if ((←((pure ((← (EffectiveEA ())) == 1#1)) <&&> (do
                           (pure ((_get_SCR_Type_AW (← readReg SCR)) == 0#1)) <||> (do
                             (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1)))))) : Bool)
                      then (do (pure (BitVec.update mask 2 (Bit 0#1))))
                      else (do (pure mask))))
                else (do (pure mask))))
          else (do (pure mask))) ) : SailM (BitVec 3) )
        let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
        (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))))

def DecodeRegExtend (op : (BitVec 3)) : SailM ExtendType := do
  match op with
  | 0b000 => (pure ExtendType_UXTB)
  | 0b001 => (pure ExtendType_UXTH)
  | 0b010 => (pure ExtendType_UXTW)
  | 0b011 => (pure ExtendType_UXTX)
  | 0b100 => (pure ExtendType_SXTB)
  | 0b101 => (pure ExtendType_SXTH)
  | 0b110 => (pure ExtendType_SXTW)
  | 0b111 => (pure ExtendType_SXTX)
  | _ => (do (undefined_ExtendType ()))

/-- Type quantifiers: N : Nat, reg : Int, shift : Int, N ≥ 0 ∧ N = 8 ∨ N = 16 ∨ N = 32 ∨ N = 64 ∨ (not (shift ≥ 0 ∧ shift ≤ 4)) -/
def ExtendReg (reg : Int) (exttype : ExtendType) (shift : Int) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((shift ≥b 0) && (shift ≤b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:35781.34-35781.35"
  let val_name ← (( do (X_read reg N) ) : SailM (BitVec N) )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let len ← (( do (undefined_int ()) ) : SailM Int )
  let (is_unsigned, len) : (Bool × Int) :=
    match exttype with
    | .ExtendType_SXTB =>
      (let is_unsigned : Bool := false
      let len : Int := 8
      (is_unsigned, len))
    | .ExtendType_SXTH =>
      (let is_unsigned : Bool := false
      let len : Int := 16
      (is_unsigned, len))
    | .ExtendType_SXTW =>
      (let is_unsigned : Bool := false
      let len : Int := 32
      (is_unsigned, len))
    | .ExtendType_SXTX =>
      (let is_unsigned : Bool := false
      let len : Int := 64
      (is_unsigned, len))
    | .ExtendType_UXTB =>
      (let is_unsigned : Bool := true
      let len : Int := 8
      (is_unsigned, len))
    | .ExtendType_UXTH =>
      (let is_unsigned : Bool := true
      let len : Int := 16
      (is_unsigned, len))
    | .ExtendType_UXTW =>
      (let is_unsigned : Bool := true
      let len : Int := 32
      (is_unsigned, len))
    | .ExtendType_UXTX =>
      (let is_unsigned : Bool := true
      let len : Int := 64
      (is_unsigned, len))
  let is_unsigned := is_unsigned
  let len := (Min.min len (N -i shift))
  sail_assert ((0 ≤b (len -i 1)) || (! ((shift ≥b 0) && (shift ≤b 4)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:35821.73-35821.74"
  (Extend ((Sail.BitVec.extractLsb val_name (len -i 1) 0) +++ (Zeros (n := shift))) N is_unsigned)


end ArmASL.Functions
