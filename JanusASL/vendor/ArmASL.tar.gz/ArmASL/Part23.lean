import ArmASL.Part22

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: d : Nat, fltsize : Nat, intsize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem intsize [32, 64] ∧ List.elem fltsize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_convert_int (d : Nat) (fltsize : Nat) (intsize : Nat) (n : Nat) (op : FPConvOp) (part : Nat) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (if ((BEq.beq op FPConvOp_CVT_FtoI_JS) : Bool)
  then (do (CheckFPAdvSIMDEnabled64 ()))
  else (do (CheckFPEnabled64 ())))
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let fsize :=
    if (((BEq.beq op FPConvOp_CVT_ItoF) && merge) : Bool)
    then 128
    else fltsize
  let fltval ← (( do (undefined_bitvector fsize) ) : SailM (BitVec fsize) )
  let intval ← (( do (undefined_bitvector intsize) ) : SailM (BitVec intsize) )
  match op with
  | .FPConvOp_CVT_FtoI =>
    (do
      let fltval ← (( do (V_read n fsize) ) : SailM (BitVec fsize) )
      sail_assert ((((fsize == 16) || (fsize == 32)) || (fsize == 64)) && (((intsize == 16) || (intsize == 32)) || (intsize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:13741.80-13741.81"
      let intval ← (( do (FPToFixed fltval 0 is_unsigned fpcr rounding intsize) ) : SailM (BitVec intsize) )
      (X_set d intsize intval))
  | .FPConvOp_CVT_ItoF =>
    (do
      let intval ← (( do (X_read n intsize) ) : SailM (BitVec intsize) )
      let fltval ← ((
        (if (merge : Bool)
        then (do (V_read d fsize))
        else (do (pure (Zeros (n := fsize))))) ) : SailM (BitVec fsize) )
      sail_assert ((((fltsize == 16) || (fltsize == 32)) || (fltsize == 64)) && (((intsize == 16) || (intsize == 32)) || (intsize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:13749.82-13749.83"
      let fltval ← (Elem_set fltval 0 fltsize (← (FixedToFP intval 0 is_unsigned fpcr rounding fltsize)))
      (V_set d fsize fltval))
  | .FPConvOp_MOV_FtoI =>
    (do
      let fltval ← (( do (Vpart_read n part fsize) ) : SailM (BitVec fsize) )
      sail_assert ((fsize ≥b 0) && (intsize ≥b fsize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13755.63-13755.64"
      let intval : (BitVec intsize) := (Sail.BitVec.zeroExtend fltval intsize)
      (X_set d intsize intval))
  | .FPConvOp_MOV_ItoF =>
    (do
      let intval ← (( do (X_read n intsize) ) : SailM (BitVec intsize) )
      sail_assert ((0 ≤b (fsize -i 1)) && ((fsize -i 1) <b intsize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:13761.70-13761.71"
      let fltval : (BitVec fsize) := (Sail.BitVec.extractLsb intval (fsize -i 1) 0)
      (Vpart_set d part fsize fltval))
  | .FPConvOp_CVT_FtoI_JS =>
    (do
      let z ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
      let fltval ← (( do (V_read n fsize) ) : SailM (BitVec fsize) )
      sail_assert (fsize == 64) "sail-arm/arm-v9.4-a/src/instrs64.sail:13768.41-13768.42"
      sail_assert (intsize == 32) "sail-arm/arm-v9.4-a/src/instrs64.sail:13769.43-13769.44"
      let (intval, z) ← (( do
        let (tup__0, tup__1) ← do (FPToFixedJS fltval fpcr true intsize)
        let intval : (BitVec intsize) := tup__0
        let z : (BitVec 1) := tup__1
        (pure (intval, z)) ) : SailM ((BitVec intsize) × (BitVec 1)) )
      let split_vec := ((0#1 +++ z) +++ 0b00#2)
      writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
      writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
      writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
      writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) }
      (X_set d intsize intval))

def decode_fcvtas_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:13871.22-13871.23"

def decode_fcvtau_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:13981.22-13981.23"

def decode_fcvtms_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14091.22-14091.23"

def decode_fcvtmu_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14201.22-14201.23"

def decode_fcvtns_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14311.22-14311.23"

def decode_fcvtnu_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14421.22-14421.23"

def decode_fcvtps_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14531.22-14531.23"

def decode_fcvtpu_float_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14641.22-14641.23"

def decode_fcvtzs_float_int_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14751.22-14751.23"

def decode_fcvtzu_float_int_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14861.22-14861.23"

def decode_fjcvtzs_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:14971.22-14971.23"

def decode_fmov_float_gen_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:15081.22-15081.23"

def decode_scvtf_float_int_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:15191.22-15191.23"

def decode_ucvtf_float_int_aarch64_instrs_float_convert_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let part : Int := 0
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 =>
      (do
        (if ((((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) != 0b1101#4) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 128))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let (fltsize, is_unsigned, op, part, rounding) ← (( do
    let b__0 := ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode)
    let (fltsize, is_unsigned, op, part, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding rmode)
            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
            let op : FPConvOp := FPConvOp_CVT_FtoI
            (pure (fltsize, is_unsigned, op, part, rounding)))
      else
        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
              (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
              then
                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                    let op : FPConvOp := FPConvOp_CVT_ItoF
                    (pure (fltsize, is_unsigned, op, part, rounding)))
              else
                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                      (if ((b__0 == (0x8#4 : (BitVec 4))) : Bool)
                      then
                        (do let rounding : FPRounding := FPRounding_TIEAWAY
                            let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                            let op : FPConvOp := FPConvOp_CVT_FtoI
                            (pure (fltsize, is_unsigned, op, part, rounding)))
                      else
                        (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                              (if ((b__0 == (0xC#4 : (BitVec 4))) : Bool)
                              then
                                (do (if (((fltsize != 16) && ((fltsize != intsize) : Bool)) : Bool)
                                    then (do sailThrow ((Error_Undefined ())))
                                    else (do (pure ())))
                                    let op : FPConvOp :=
                                      if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                      then FPConvOp_MOV_ItoF
                                      else FPConvOp_MOV_FtoI
                                    let part : Int := 0
                                    (pure (fltsize, is_unsigned, op, part, rounding)))
                              else
                                (do let (fltsize, is_unsigned, op, part, rounding) ← (( do
                                      (if ((b__0 == (0xD#4 : (BitVec 4))) : Bool)
                                      then
                                        (do (if (((intsize != 64) || ((fltsize != 128) : Bool)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let op : FPConvOp :=
                                              if ((((BitVec.access opcode 0) : BitVec 1) == 1#1) : Bool)
                                              then FPConvOp_MOV_ItoF
                                              else FPConvOp_MOV_FtoI
                                            let part : Int := 1
                                            let fltsize : Int := 64
                                            (pure (fltsize, is_unsigned, op, part, rounding)))
                                      else
                                        (do let (is_unsigned, op, rounding) ← (( do
                                              (if ((b__0 == (0xF#4 : (BitVec 4))) : Bool)
                                              then
                                                (do (if ((! (← (HaveFJCVTZSExt ()))) : Bool)
                                                    then (do sailThrow ((Error_Undefined ())))
                                                    else (do (pure ())))
                                                    let rounding : FPRounding := FPRounding_ZERO
                                                    let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
                                                    let op : FPConvOp := FPConvOp_CVT_FtoI_JS
                                                    (pure (is_unsigned, op, rounding)))
                                              else (do sailThrow ((Error_Undefined ())))) ) : SailM (Bool × FPConvOp × FPRounding) )
                                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
                    (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
            (pure (fltsize, is_unsigned, op, part, rounding)))) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
    (pure (fltsize, is_unsigned, op, part, rounding)) ) : SailM (Int × Bool × FPConvOp × Int × FPRounding) )
  let op := op
  let part := part
  let fltsize := fltsize
  match fltsize with
  | 16 => (execute_aarch64_instrs_float_convert_int d 16 intsize n op part rounding is_unsigned)
  | 32 => (execute_aarch64_instrs_float_convert_int d 32 intsize n op part rounding is_unsigned)
  | 64 => (execute_aarch64_instrs_float_convert_int d 64 intsize n op part rounding is_unsigned)
  | 128 => (execute_aarch64_instrs_float_convert_int d 128 intsize n op part rounding is_unsigned)
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:15301.22-15301.23"

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_float_widen (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e (2 *i esize) (← (FPConvert__1 (← (Elem_read operand e esize)) (← (FPCR_read ())) (2 *i esize))))
    (pure loop_vars) ) : SailM (BitVec (2 * datasize)) )
  (V_set d (2 *i datasize) result)

def decode_fcvtl_advsimd_aarch64_instrs_vector_arithmetic_unary_float_widen (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 16 (BitVec.toNat sz))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  sail_assert ((esize == 16) || (esize == 32)) "sail-arm/arm-v9.4-a/src/instrs64.sail:15340.41-15340.42"
  (execute_aarch64_instrs_vector_arithmetic_unary_float_widen d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FPToFixed element 0 is_unsigned fpcr rounding esize)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fcvtms_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtms_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtmu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtmu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtns_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtns_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtnu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtnu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtps_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtps_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtpu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtpu_advsimd_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtzs_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtzs_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtzu_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

def decode_fcvtzu_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_float_bulk_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding ← (( do (FPDecodeRounding (o1 +++ o2)) ) : SailM FPRounding )
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_float_bulk_sisd d datasize elements esize n rounding is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_float_narrow (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize (← (FPConvert__1 (← (Elem_read operand e (2 *i esize))) (← (FPCR_read ())) esize)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (Vpart_set d part datasize result)

def decode_fcvtn_advsimd_aarch64_instrs_vector_arithmetic_unary_float_narrow (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 16 (BitVec.toNat sz))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  sail_assert ((esize == 16) || (esize == 32)) "sail-arm/arm-v9.4-a/src/instrs64.sail:16146.41-16146.42"
  (execute_aarch64_instrs_vector_arithmetic_unary_float_narrow d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ esize = 32 ∧ List.elem elements [1, 2] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_float_xtn_sisd (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do (Elem_set result e esize (← (FPConvert (← (Elem_read operand e (2 *i esize))) fpcr FPRounding_ODD esize)))
    (pure loop_vars) ) : SailM (BitVec 128) )
  (if (merge : Bool)
  then (do (V_set d 128 result))
  else (do (Vpart_set d part datasize (← (Elem_read result 0 datasize)))))

def decode_fcvtxn_advsimd_aarch64_instrs_vector_arithmetic_unary_float_xtn_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize := esize
  let elements := 1
  let part := 0
  (execute_aarch64_instrs_vector_arithmetic_unary_float_xtn_sisd d datasize elements esize n part)

def decode_fcvtxn_advsimd_aarch64_instrs_vector_arithmetic_unary_float_xtn_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((sz == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := 32
  let datasize := 64
  let elements := 2
  let part := (BitVec.toNat Q)
  (execute_aarch64_instrs_vector_arithmetic_unary_float_xtn_sisd d datasize elements esize n part)

/-- Type quantifiers: d : Nat, fltsize : Nat, fracbits : Nat, intsize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem intsize [32, 64] ∧ 1 ≤ fracbits ∧ fracbits ≤ 64 ∧ List.elem fltsize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_convert_fix (d : Nat) (fltsize : Nat) (fracbits : Nat) (intsize : Nat) (n : Nat) (op : FPConvOp) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let fsize :=
    if (((BEq.beq op FPConvOp_CVT_ItoF) && merge) : Bool)
    then 128
    else fltsize
  let fltval ← (( do (undefined_bitvector fsize) ) : SailM (BitVec fsize) )
  let intval ← (( do (undefined_bitvector intsize) ) : SailM (BitVec intsize) )
  match op with
  | .FPConvOp_CVT_FtoI =>
    (do
      let fltval ← (( do (V_read n fsize) ) : SailM (BitVec fsize) )
      sail_assert ((((fsize == 16) || (fsize == 32)) || (fsize == 64)) && (((intsize == 16) || (intsize == 32)) || (intsize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:16240.80-16240.81"
      let intval ← (( do (FPToFixed fltval fracbits is_unsigned fpcr rounding intsize) ) : SailM (BitVec intsize) )
      (X_set d intsize intval))
  | .FPConvOp_CVT_ItoF =>
    (do
      let intval ← (( do (X_read n intsize) ) : SailM (BitVec intsize) )
      let fltval ← ((
        (if (merge : Bool)
        then (do (V_read d fsize))
        else (do (pure (Zeros (n := fsize))))) ) : SailM (BitVec fsize) )
      let fltval ← (Elem_set fltval 0 fltsize (← (FixedToFP intval fracbits is_unsigned fpcr rounding fltsize)))
      (V_set d fsize fltval))
  | _ => (pure ())

def decode_fcvtzs_float_fix_aarch64_instrs_float_convert_fix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (scale : (BitVec 6)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let fltsize := fltsize
  (if (((sf == 0#1) && (((BitVec.access scale 5) : BitVec 1) == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let fracbits := (64 -i (BitVec.toNat scale))
  let (is_unsigned, op, rounding) ← (( do
    match ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) with
    | 0b0011 =>
      (let rounding : FPRounding := FPRounding_ZERO
      let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
      let op : FPConvOp := FPConvOp_CVT_FtoI
      (pure (is_unsigned, op, rounding)))
    | 0b0100 =>
      (do
        let rounding ← (FPRoundingMode (← (FPCR_read ())))
        let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
        let op : FPConvOp := FPConvOp_CVT_ItoF
        (pure (is_unsigned, op, rounding)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × FPConvOp × FPRounding) )
  (execute_aarch64_instrs_float_convert_fix d fltsize fracbits intsize n op rounding is_unsigned)

def decode_fcvtzu_float_fix_aarch64_instrs_float_convert_fix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (scale : (BitVec 6)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let fltsize := fltsize
  (if (((sf == 0#1) && (((BitVec.access scale 5) : BitVec 1) == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let fracbits := (64 -i (BitVec.toNat scale))
  let (is_unsigned, op, rounding) ← (( do
    match ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) with
    | 0b0011 =>
      (let rounding : FPRounding := FPRounding_ZERO
      let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
      let op : FPConvOp := FPConvOp_CVT_FtoI
      (pure (is_unsigned, op, rounding)))
    | 0b0100 =>
      (do
        let rounding ← (FPRoundingMode (← (FPCR_read ())))
        let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
        let op : FPConvOp := FPConvOp_CVT_ItoF
        (pure (is_unsigned, op, rounding)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × FPConvOp × FPRounding) )
  (execute_aarch64_instrs_float_convert_fix d fltsize fracbits intsize n op rounding is_unsigned)

def decode_scvtf_float_fix_aarch64_instrs_float_convert_fix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (scale : (BitVec 6)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let fltsize := fltsize
  (if (((sf == 0#1) && (((BitVec.access scale 5) : BitVec 1) == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let fracbits := (64 -i (BitVec.toNat scale))
  let (is_unsigned, op, rounding) ← (( do
    match ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) with
    | 0b0011 =>
      (let rounding : FPRounding := FPRounding_ZERO
      let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
      let op : FPConvOp := FPConvOp_CVT_FtoI
      (pure (is_unsigned, op, rounding)))
    | 0b0100 =>
      (do
        let rounding ← (FPRoundingMode (← (FPCR_read ())))
        let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
        let op : FPConvOp := FPConvOp_CVT_ItoF
        (pure (is_unsigned, op, rounding)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × FPConvOp × FPRounding) )
  (execute_aarch64_instrs_float_convert_fix d fltsize fracbits intsize n op rounding is_unsigned)

def decode_ucvtf_float_fix_aarch64_instrs_float_convert_fix (Rd : (BitVec 5)) (Rn : (BitVec 5)) (scale : (BitVec 6)) (opcode : (BitVec 3)) (rmode : (BitVec 2)) (ftype : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let intsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let fltsize : Int := 16
  let op ← (( do (undefined_FPConvOp ()) ) : SailM FPConvOp )
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let is_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let fltsize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let fltsize := fltsize
  (if (((sf == 0#1) && (((BitVec.access scale 5) : BitVec 1) == 0#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let fracbits := (64 -i (BitVec.toNat scale))
  let (is_unsigned, op, rounding) ← (( do
    match ((Sail.BitVec.extractLsb opcode 2 1) +++ rmode) with
    | 0b0011 =>
      (let rounding : FPRounding := FPRounding_ZERO
      let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
      let op : FPConvOp := FPConvOp_CVT_FtoI
      (pure (is_unsigned, op, rounding)))
    | 0b0100 =>
      (do
        let rounding ← (FPRoundingMode (← (FPCR_read ())))
        let is_unsigned : Bool := (((BitVec.access opcode 0) : BitVec 1) == 1#1)
        let op : FPConvOp := FPConvOp_CVT_ItoF
        (pure (is_unsigned, op, rounding)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Bool × FPConvOp × FPRounding) )
  (execute_aarch64_instrs_float_convert_fix d fltsize fracbits intsize n op rounding is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, fracbits : Int, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_conv_float_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (fracbits : Int) (n : Nat) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FPToFixed element fracbits is_unsigned fpcr rounding esize)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fcvtzs_advsimd_fix_aarch64_instrs_vector_shift_conv_float_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize := esize
  let elements := 1
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding : FPRounding := FPRounding_ZERO
  (execute_aarch64_instrs_vector_shift_conv_float_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_fcvtzs_advsimd_fix_aarch64_instrs_vector_shift_conv_float_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding : FPRounding := FPRounding_ZERO
  (execute_aarch64_instrs_vector_shift_conv_float_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_fcvtzu_advsimd_fix_aarch64_instrs_vector_shift_conv_float_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize := esize
  let elements := 1
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding : FPRounding := FPRounding_ZERO
  (execute_aarch64_instrs_vector_shift_conv_float_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_fcvtzu_advsimd_fix_aarch64_instrs_vector_shift_conv_float_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding : FPRounding := FPRounding_ZERO
  (execute_aarch64_instrs_vector_shift_conv_float_sisd d datasize elements esize fracbits n rounding is_unsigned)

/-- Type quantifiers: d : Nat, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_div (d : Nat) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPEnabled64 ())
  let operand1 ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let operand2 ← (( do (V_read m esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let result ← (Elem_set result 0 esize (← (FPDiv operand1 operand2 (← (FPCR_read ())))))
  (V_set d 128 result)

def decode_fdiv_float_aarch64_instrs_float_arithmetic_div (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  (execute_aarch64_instrs_float_arithmetic_div d esize m n)

/-- Type quantifiers: a : Nat, d : Nat, esize : Nat, m : Nat, n : Nat, k_op1_neg : Bool, k_opa_neg : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_mul_add_sub (a : Nat) (d : Nat) (esize : Nat) (m : Nat) (n : Nat) (op1_neg : Bool) (opa_neg : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let operanda ← (( do (V_read a esize) ) : SailM (BitVec esize) )
  let operand1 ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let operand2 ← (( do (V_read m esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read a 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let operanda ← (( do
    (if (opa_neg : Bool)
    then (do (FPNeg operanda))
    else (do (pure operanda))) ) : SailM (BitVec esize) )
  let operand1 ← (( do
    (if (op1_neg : Bool)
    then (do (FPNeg operand1))
    else (do (pure operand1))) ) : SailM (BitVec esize) )
  let result ← (Elem_set result 0 esize (← (FPMulAdd operanda operand1 operand2 fpcr)))
  (V_set d 128 result)

def decode_fmadd_float_aarch64_instrs_float_arithmetic_mul_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (o1 : (BitVec 1)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let a := (BitVec.toNat Ra)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let opa_neg : Bool := (o1 == 1#1)
  let op1_neg : Bool := (o0 != o1)
  (execute_aarch64_instrs_float_arithmetic_mul_add_sub a d esize m n op1_neg opa_neg)

def decode_fmsub_float_aarch64_instrs_float_arithmetic_mul_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (o1 : (BitVec 1)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let a := (BitVec.toNat Ra)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let opa_neg : Bool := (o1 == 1#1)
  let op1_neg : Bool := (o0 != o1)
  (execute_aarch64_instrs_float_arithmetic_mul_add_sub a d esize m n op1_neg opa_neg)

def decode_fnmadd_float_aarch64_instrs_float_arithmetic_mul_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (o1 : (BitVec 1)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let a := (BitVec.toNat Ra)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let opa_neg : Bool := (o1 == 1#1)
  let op1_neg : Bool := (o0 != o1)
  (execute_aarch64_instrs_float_arithmetic_mul_add_sub a d esize m n op1_neg opa_neg)

def decode_fnmsub_float_aarch64_instrs_float_arithmetic_mul_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (o1 : (BitVec 1)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let a := (BitVec.toNat Ra)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let opa_neg : Bool := (o1 == 1#1)
  let op1_neg : Bool := (o0 != o1)
  (execute_aarch64_instrs_float_arithmetic_mul_add_sub a d esize m n op1_neg opa_neg)

/-- Type quantifiers: d : Nat, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_max_min (d : Nat) (esize : Nat) (m : Nat) (n : Nat) (operation : FPMaxMinOp) : SailM Unit := do
  (CheckFPEnabled64 ())
  let operand1 ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let operand2 ← (( do (V_read m esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let result ← (( do
    match operation with
    | .FPMaxMinOp_MAX => (do (Elem_set result 0 esize (← (FPMax operand1 operand2 fpcr))))
    | .FPMaxMinOp_MIN => (do (Elem_set result 0 esize (← (FPMin operand1 operand2 fpcr))))
    | .FPMaxMinOp_MAXNUM => (do (Elem_set result 0 esize (← (FPMaxNum operand1 operand2 fpcr))))
    | .FPMaxMinOp_MINNUM => (do (Elem_set result 0 esize (← (FPMinNum operand1 operand2 fpcr)))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_fmax_float_aarch64_instrs_float_arithmetic_max_min (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let operation ← (( do (undefined_FPMaxMinOp ()) ) : SailM FPMaxMinOp )
  let operation : FPMaxMinOp :=
    match op with
    | 0b00 => FPMaxMinOp_MAX
    | 0b01 => FPMaxMinOp_MIN
    | 0b10 => FPMaxMinOp_MAXNUM
    | _ => FPMaxMinOp_MINNUM
  let operation := operation
  (execute_aarch64_instrs_float_arithmetic_max_min d esize m n operation)

def decode_fmaxnm_float_aarch64_instrs_float_arithmetic_max_min (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let operation ← (( do (undefined_FPMaxMinOp ()) ) : SailM FPMaxMinOp )
  let operation : FPMaxMinOp :=
    match op with
    | 0b00 => FPMaxMinOp_MAX
    | 0b01 => FPMaxMinOp_MIN
    | 0b10 => FPMaxMinOp_MAXNUM
    | _ => FPMaxMinOp_MINNUM
  let operation := operation
  (execute_aarch64_instrs_float_arithmetic_max_min d esize m n operation)

def decode_fmin_float_aarch64_instrs_float_arithmetic_max_min (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let operation ← (( do (undefined_FPMaxMinOp ()) ) : SailM FPMaxMinOp )
  let operation : FPMaxMinOp :=
    match op with
    | 0b00 => FPMaxMinOp_MAX
    | 0b01 => FPMaxMinOp_MIN
    | 0b10 => FPMaxMinOp_MAXNUM
    | _ => FPMaxMinOp_MINNUM
  let operation := operation
  (execute_aarch64_instrs_float_arithmetic_max_min d esize m n operation)

def decode_fminnm_float_aarch64_instrs_float_arithmetic_max_min (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let operation ← (( do (undefined_FPMaxMinOp ()) ) : SailM FPMaxMinOp )
  let operation : FPMaxMinOp :=
    match op with
    | 0b00 => FPMaxMinOp_MAX
    | 0b01 => FPMaxMinOp_MIN
    | 0b10 => FPMaxMinOp_MAXNUM
    | _ => FPMaxMinOp_MINNUM
  let operation := operation
  (execute_aarch64_instrs_float_arithmetic_max_min d esize m n operation)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, k_minimum : Bool, n : Nat, k_pair : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_1985 (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (minimum : Bool) (n : Nat) (pair : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand2 +++ operand1)
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let (element1, element2) ← (( do
          (if (pair : Bool)
          then
            (do let element1 ← (Elem_read concat (2 *i e) esize)
                let element2 ← (Elem_read concat ((2 *i e) +i 1) esize)
                (pure (element1, element2)))
          else
            (do let element1 ← (Elem_read operand1 e esize)
                let element2 ← (Elem_read operand2 e esize)
                (pure (element1, element2)))) ) : SailM ((BitVec esize) × (BitVec esize)) )
        let result ← (( do
          (if (minimum : Bool)
          then (do (Elem_set result e esize (← (FPMin element1 element2 (← (FPCR_read ()))))))
          else (do (Elem_set result e esize (← (FPMax element1 element2 (← (FPCR_read ()))))))) ) : SailM (BitVec datasize) )
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fmax_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_1985 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_1985 d datasize elements esize m minimum n pair)

def decode_fmaxp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_1985 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_1985 d datasize elements esize m minimum n pair)

def decode_fmin_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_1985 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_1985 d datasize elements esize m minimum n pair)


end ArmASL.Functions
