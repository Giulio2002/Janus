import ArmASL.Part26

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31962.113-31962.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:31981.107-31981.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32048.113-32048.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32067.107-32067.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldr_imm_gen_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32134.113-32134.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32153.107-32153.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32220.113-32220.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32239.107-32239.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32306.113-32306.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32325.107-32325.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32392.113-32392.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32411.107-32411.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32478.113-32478.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32497.107-32497.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32564.113-32564.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32583.107-32583.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32650.113-32650.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32669.107-32669.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32736.113-32736.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32755.107-32755.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32822.113-32822.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32841.107-32841.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32908.113-32908.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32927.107-32927.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32994.113-32994.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33013.107-33013.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33080.113-33080.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33099.107-33099.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33166.113-33166.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33185.107-33185.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33252.113-33252.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33271.107-33271.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33338.113-33338.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33357.107-33357.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33424.113-33424.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33443.107-33443.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33510.113-33510.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33529.107-33529.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33596.113-33596.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33615.107-33615.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33682.113-33682.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33701.107-33701.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33768.113-33768.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33787.107-33787.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33854.113-33854.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33873.107-33873.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33940.113-33940.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33959.107-33959.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34026.113-34026.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34045.107-34045.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34112.113-34112.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34131.107-34131.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34198.113-34198.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34217.107-34217.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, m : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, shift : Nat, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem shift [0, 1, 2, 3] ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_register (datasize : Nat) (extend_type : ExtendType) (m : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (shift : Nat) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let offset ← (( do (ExtendReg m extend_type shift 64) ) : SailM (BitVec 64) )
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34286.72-34286.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34289.73-34289.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_reg_gen_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34361.113-34361.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34380.107-34380.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34458.113-34458.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34477.107-34477.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34555.113-34555.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34574.107-34574.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34652.113-34652.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34671.107-34671.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34749.113-34749.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34768.107-34768.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34846.113-34846.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34865.107-34865.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)


end ArmASL.Functions
