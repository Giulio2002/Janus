import ArmASL.Part26

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_77c9154118b31c0b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (21 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 21 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (21 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 21 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 21 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 21 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_7838a7b85145fa49 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (19 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 19 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (19 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 19 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 19 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 19 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_85d1907975c67ab9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (16 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 16 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (16 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 16 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 16 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 16 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_86cfe4162e1d3fcf (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (25 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 25 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (25 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 25 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 25 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 25 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_87d6d2e24b5727f8 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (24 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 24 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (24 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 24 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 24 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 24 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_9232da1ea5d3e3e4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (7 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 7 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (7 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 7 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 7 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 7 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_934ceed712a1fe87 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (10 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 10 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (10 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 10 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 10 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 10 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_97e51861c983d469 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (13 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 13 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (13 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 13 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 13 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 13 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_984883ae00534017 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (18 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 18 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (18 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 18 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 18 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 18 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_9af53f393498a306 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (28 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 28 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (28 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 28 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 28 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 28 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_9bc9d4832692907c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (22 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 22 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (22 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 22 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 22 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 22 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_a6565ec15f45df72 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (6 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 6 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (6 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 6 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 6 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 6 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_a6cb14c3d935c495 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (5 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 5 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (5 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 5 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 5 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 5 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_ae5d8b12796ab9e6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (26 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 26 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (26 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 26 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 26 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 26 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_d19f1d744e0cb4cf (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (2 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 2 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (2 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 2 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 2 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 2 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_dd76d9177614ce63 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (30 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 30 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (30 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 30 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 30 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 30 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_f3ccdb6f88982dfd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (14 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 14 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (14 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 14 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 14 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 14 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVCNTR_EL0_SysRegWrite_ff8724b529749d0c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVCNTRn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (17 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 17 (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVCNTRn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (17 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 17 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 17 (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVCNTR_EL0 (vectorUpdate (← readReg PMEVCNTR_EL0) 17 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_085f9c623183c27e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (11 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 11 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (11 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 11 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 11 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 11 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_103d29a45c9a97d5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (16 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 16 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (16 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 16 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 16 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 16 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_1fbed854e7b6ea60 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (13 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 13 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (13 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 13 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 13 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 13 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))


end ArmASL.Functions
