import ArmASL.Part26

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32875.113-32875.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32894.107-32894.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32961.113-32961.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:32980.107-32980.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33047.113-33047.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33066.107-33066.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33133.113-33133.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33152.107-33152.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33219.113-33219.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33238.107-33238.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33305.113-33305.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33324.107-33324.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33391.113-33391.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33410.107-33410.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_str_imm_gen_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33477.113-33477.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33496.107-33496.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33563.113-33563.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33582.107-33582.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33649.113-33649.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33668.107-33668.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strb_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33735.113-33735.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33754.107-33754.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33821.113-33821.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33840.107-33840.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_signed_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33907.113-33907.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33926.107-33926.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_strh_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then (do sailThrow ((Error_Undefined ())))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:33993.113-33993.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34012.107-34012.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_post_idx datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, m : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, shift : Nat, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem shift [0, 1, 2, 3] ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_register (datasize : Nat) (extend_type : ExtendType) (m : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (shift : Nat) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let offset ← (( do (ExtendReg m extend_type shift 64) ) : SailM (BitVec 64) )
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34081.72-34081.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34084.73-34084.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldr_reg_gen_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34156.113-34156.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34175.107-34175.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34253.113-34253.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34272.107-34272.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34350.113-34350.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34369.107-34369.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34447.113-34447.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34466.107-34466.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34544.113-34544.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34563.107-34563.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_ldrsw_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34641.113-34641.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34660.107-34660.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_prfm_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  sail_assert (! (let b__0 := Rt
    if (((Sail.BitVec.extractLsb b__0 4 3) == (0b11#2 : (BitVec 2))) : Bool)
    then true
    else false : Bool)) "sail-arm/arm-v9.4-a/src/instrs64.sail:34698.14-34698.15"
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34742.113-34742.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34761.107-34761.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_str_reg_gen_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34842.113-34842.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34861.107-34861.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_strb_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34939.113-34939.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:34958.107-34958.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

def decode_strh_reg_aarch64_instrs_memory_single_general_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35036.113-35036.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:35055.107-35055.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_register datasize extend_type m memop n nontemporal postindex regsize rt_unknown shift is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, m : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, shift : Nat, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem shift [0, 1, 2, 3, 4, 5, 6, 7] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_register (datasize : Nat) (extend_type : ExtendType) (m : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (postindex : Bool) (shift : Nat) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let offset ← (( do (ExtendReg m extend_type shift 64) ) : SailM (BitVec 64) )
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35108.62-35108.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35114.62-35114.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldr_reg_fpsimd_aarch64_instrs_memory_single_simdfp_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35156.72-35156.73"
  (execute_aarch64_instrs_memory_single_simdfp_register datasize extend_type m memop n nontemporal postindex shift t tagchecked wback)

def decode_str_reg_fpsimd_aarch64_instrs_memory_single_simdfp_register (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access option_name 1) : BitVec 1) == 0#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let extend_type ← (( do (DecodeRegExtend option_name) ) : SailM ExtendType )
  let shift :=
    if ((S == 1#1) : Bool)
    then scale
    else 0
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let m := (BitVec.toNat Rm)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := (bne memop MemOp_PREFETCH)
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:35193.72-35193.73"
  (execute_aarch64_instrs_memory_single_simdfp_register datasize extend_type m memop n nontemporal postindex shift t tagchecked wback)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64, 128, 256, 512, 1024] -/
def execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36180.62-36180.63"
      let data ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36186.62-36186.63"
      (V_set t datasize data))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36223.72-36223.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal datasize memop n nontemporal offset postindex t tagchecked wback)

def decode_stur_fpsimd_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat (((BitVec.access opc 1) : BitVec 1) +++ size))
  (if ((scale >b 4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  sail_assert ((((((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) || (datasize == 512)) || (datasize == 1024)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36253.72-36253.73"
  (execute_aarch64_instrs_memory_single_simdfp_immediate_signed_offset_normal datasize memop n nontemporal offset postindex t tagchecked wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36305.72-36305.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:36308.73-36308.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldur_gen_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36375.113-36375.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36394.107-36394.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldurb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36465.113-36465.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36484.107-36484.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldurh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36555.113-36555.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36574.107-36574.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldursb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36645.113-36645.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36664.107-36664.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_ldursh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36735.113-36735.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36754.107-36754.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)


end ArmASL.Functions
