import ArmASL.Part10

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def SetBTypeNext (x : (BitVec 2)) : SailM Unit := do
  writeReg BTypeNext x

def AArch64_AllocationTagAccessIsEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((((_get_SCR_EL3_Type_ATA (← readReg SCR_EL3)) == 0#1) && ((el == EL0) || ((el == EL1) || (el == EL2)))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (((_get_HCR_EL2_Type_ATA (← readReg HCR_EL2)) == 0#1) && ((el == EL0) || (el == EL1)))) <&&> (do
             (EL2Enabled ())) <&&> (do
             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) : Bool)
        then (do (pure false))
        else
          (do let regime ← (( do (TranslationRegime el) ) : SailM Regime )
              match regime with
              | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_ATA (← readReg SCTLR_EL3)) == 1#1))
              | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1))
              | .Regime_EL20 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL2_Type_ATA0 (← readReg SCTLR_EL2)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1)))))
              | .Regime_EL10 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL1_Type_ATA0 (← readReg SCTLR_EL1)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL1_Type_ATA (← readReg SCTLR_EL1)) == 1#1)))))
              | _ =>
                (do
                  (Unreachable ())
                  (undefined_bool ()))))))

def undefined_GCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RGSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: alignment : Int, size : Int -/
def AllInAlignedQuantity (address : (BitVec 64)) (size : Int) (alignment : Int) : SailM Bool := do
  sail_assert (size ≤b alignment) "sail-arm/arm-v9.4-a/src/v8_base.sail:22735.28-22735.29"
  (pure ((Align_bits (BitVec.subInt (BitVec.addInt address size) 1) alignment) == (Align_bits address alignment)))

def AArch64_SPAlignmentFault (_ : Unit) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_SPAlignment) ) : SailM ExceptionRecord )
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((EL2Enabled ()) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def SP_read (_ : Unit) : SailM (BitVec 64) := do
  (if (((← readReg PSTATE).SP == 0#1) : Bool)
  then (do readReg SP_EL0)
  else
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do readReg SP_EL0)
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do readReg SP_EL1)
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do readReg SP_EL2)
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do readReg SP_EL3)
                          else (do (undefined_bitvector 64)))))))))))

def CheckSPAlignment (_ : Unit) : SailM Unit := do
  let sp ← (( do (SP_read ()) ) : SailM (BitVec 64) )
  let stack_align_check ← (( do (undefined_bool ()) ) : SailM Bool )
  let stack_align_check ← (( do
    (if (((← readReg PSTATE).EL == EL0) : Bool)
    then (do (pure ((_get_SCTLRType_SA0 (← (SCTLR_read__1 ()))) != 0#1)))
    else (do (pure ((_get_SCTLRType_SA (← (SCTLR_read__1 ()))) != 0#1)))) ) : SailM Bool )
  (if ((stack_align_check && (sp != (Align_bits sp 16))) : Bool)
  then (do (AArch64_SPAlignmentFault ()))
  else (do (pure ())))

/-- Type quantifiers: size : Int -/
def AArch64_UnalignedAccessFaults (accdesc : AccessDescriptor) (address : (BitVec 64)) (size : Int) : SailM Bool := do
  (if ((← (AlignmentEnforced ())) : Bool)
  then (do (pure true))
  else
    (do (if ((BEq.beq accdesc.acctype AccessType_GCS) : Bool)
        then (do (pure true))
        else
          (do (if (accdesc.rcw : Bool)
              then (do (pure true))
              else
                (do (if (accdesc.ls64 : Bool)
                    then (do (pure true))
                    else
                      (do (if ((accdesc.exclusive || accdesc.atomicop) : Bool)
                          then (do (pure (! (← (HaveLSE2Ext ())))) <||> (do (pure (! (← (AllInAlignedQuantity address size 16))))))
                          else
                            (do (if (((accdesc.acqsc || accdesc.acqpc) || accdesc.relsc) : Bool)
                                then (do (pure (! (← (HaveLSE2Ext ())))) <||> (do (pure ((_get_SCTLRType_nAA (← (SCTLR_read__1 ()))) == 0#1)) <&&> (do (pure (! (← (AllInAlignedQuantity address size 16)))))))
                                else (do (pure false)))))))))))))

def StoreOnlyTagCheckingEnabled (el : (BitVec 2)) : SailM Bool := do
  sail_assert (← (HaveMTEStoreOnlyExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:22820.32-22820.33"
  let tcso ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let tcso ← (( do
    let questionMark := el
    (if ((questionMark == EL0) : Bool)
    then
      (do (if ((! (← (ELIsInHost el))) : Bool)
          then (do (pure (_get_SCTLR_EL1_Type_TCSO0 (← readReg SCTLR_EL1))))
          else (do (pure (_get_SCTLR_EL2_Type_TCSO0 (← readReg SCTLR_EL2))))))
    else
      (do (if ((questionMark == EL1) : Bool)
          then (do (pure (_get_SCTLR_EL1_Type_TCSO (← readReg SCTLR_EL1))))
          else
            (do (if ((questionMark == EL2) : Bool)
                then (do (pure (_get_SCTLR_EL2_Type_TCSO (← readReg SCTLR_EL2))))
                else (do (pure (_get_SCTLR_EL3_Type_TCSO (← readReg SCTLR_EL3))))))))) ) : SailM (BitVec 1) )
  (pure (tcso == 1#1))

def AArch64_AccessIsTagChecked (vaddr : (BitVec 64)) (accdesc : AccessDescriptor) : SailM Bool := do
  sail_assert accdesc.tagchecked "sail-arm/arm-v9.4-a/src/v8_base.sail:22846.29-22846.30"
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do let is_instr : Bool := false
        (if ((←((pure ((← (EffectiveMTX vaddr is_instr (← readReg PSTATE).EL)) == 0#1)) <&&> (do
             (pure ((← (EffectiveTBI vaddr is_instr (← readReg PSTATE).EL)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((((← (EffectiveTCMA vaddr (← readReg PSTATE).EL)) == 1#1) && (((Sail.BitVec.extractLsb vaddr 59 55) == 0b00000#5) || ((Sail.BitVec.extractLsb vaddr 59 55) == 0b11111#5))) : Bool)
              then (do (pure false))
              else
                (do (if ((! (← (AArch64_AllocationTagAccessIsEnabled accdesc.el))) : Bool)
                    then (do (pure false))
                    else
                      (do (if (((← readReg PSTATE).TCO == 1#1) : Bool)
                          then (do (pure false))
                          else
                            (do (if ((←((pure ((← (HaveMTEStoreOnlyExt ())) && (! accdesc.write))) <&&> (do
                                     (StoreOnlyTagCheckingEnabled accdesc.el)))) : Bool)
                                then (do (pure false))
                                else (do (pure true)))))))))))))

def PhysMemTagRead (desc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM (PhysMemRetStatus × (BitVec 4)) := do
  (pure ((← (undefined_PhysMemRetStatus ())), (← (undefined_bitvector 4))))

def AArch64_AllocationTagCheck (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (ptag : (BitVec 4)) : SailM Bool := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let readtag ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_AllocationTagged) : Bool)
  then
    (do let (memstatus, readtag) ← (( do
          let (tup__0, tup__1) ← do (PhysMemTagRead memaddrdesc accdesc)
          let memstatus : PhysMemRetStatus := tup__0
          let readtag : (BitVec 4) := tup__1
          (pure (memstatus, readtag)) ) : SailM (PhysMemRetStatus × (BitVec 4)) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalReadAbort memstatus memaddrdesc 1 accdesc))
        else (do (pure ())))
        (pure (ptag == readtag)))
  else (do (pure true)))

def AArch64_CanonicalTagCheck (memaddrdesc : AddressDescriptor) (ptag : (BitVec 4)) : Bool :=
  let expected_tag : (BitVec 4) :=
    if ((((BitVec.access memaddrdesc.vaddress 55) : BitVec 1) == 0#1) : Bool)
    then 0b0000#4
    else 0b1111#4
  (ptag == expected_tag)

def AArch64_CheckTag (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (ptag : (BitVec 4)) : SailM Bool := do
  (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_AllocationTagged) : Bool)
  then (do (AArch64_AllocationTagCheck memaddrdesc accdesc ptag))
  else
    (do (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_CanonicallyTagged) : Bool)
        then (do (pure (AArch64_CanonicalTagCheck memaddrdesc ptag)))
        else (do (pure true)))))

def AArch64_PhysicalTag (vaddr : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb vaddr 59 56)

def AArch64_EffectiveTCF (el : (BitVec 2)) : SailM (BitVec 2) := do
  let tcf ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let regime ← (( do (TranslationRegime el) ) : SailM Regime )
  let tcf ← (( do
    match regime with
    | .Regime_EL3 => (do (pure (_get_SCTLR_EL3_Type_TCF (← readReg SCTLR_EL3))))
    | .Regime_EL2 => (do (pure (_get_SCTLR_EL2_Type_TCF (← readReg SCTLR_EL2))))
    | .Regime_EL20 =>
      (do
        (if ((el == EL0) : Bool)
        then (do (pure (_get_SCTLR_EL2_Type_TCF0 (← readReg SCTLR_EL2))))
        else (do (pure (_get_SCTLR_EL2_Type_TCF (← readReg SCTLR_EL2))))))
    | .Regime_EL10 =>
      (do
        (if ((el == EL0) : Bool)
        then (do (pure (_get_SCTLR_EL1_Type_TCF0 (← readReg SCTLR_EL1))))
        else (do (pure (_get_SCTLR_EL1_Type_TCF (← readReg SCTLR_EL1))))))
    | _ =>
      (do
        (Unreachable ())
        (pure tcf)) ) : SailM (BitVec 2) )
  (if ((tcf == 0b11#2) : Bool)
  then
    (do (if ((! (← (HaveMTEAsymFaultExt ()))) : Bool)
        then
          (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESTCF 2)
              (pure __tup_1))
        else (do (pure tcf))))
  else (do (pure tcf)))

def AArch64_RaiseTagCheckFault (va : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  let except ← (( do (AArch64_AbortSyndrome Exception_DataAbort fault va target_el) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def undefined_TFSRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSRE0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_ReportTagCheckFault (el : (BitVec 2)) (ttbr : (BitVec 1)) : SailM Unit := do
  let questionMark := el
  (if ((questionMark == EL3) : Bool)
  then
    (do sail_assert (ttbr == 0#1) "sail-arm/arm-v9.4-a/src/v8_base.sail:22983.28-22983.29"
        writeReg TFSR_EL3 (Sail.BitVec.updateSubrange (← readReg TFSR_EL3) 0 0 1#1))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if ((ttbr == 0#1) : Bool)
              then (do writeReg TFSR_EL2 (Sail.BitVec.updateSubrange (← readReg TFSR_EL2) 0 0 1#1))
              else (do writeReg TFSR_EL2 (Sail.BitVec.updateSubrange (← readReg TFSR_EL2) 1 1 1#1))))
        else
          (do (if ((questionMark == EL1) : Bool)
              then
                (do (if ((ttbr == 0#1) : Bool)
                    then (do writeReg TFSR_EL1 (Sail.BitVec.updateSubrange (← readReg TFSR_EL1) 0 0 1#1))
                    else (do writeReg TFSR_EL1 (Sail.BitVec.updateSubrange (← readReg TFSR_EL1) 1 1 1#1))))
              else
                (do (if ((questionMark == EL0) : Bool)
                    then
                      (do (if ((ttbr == 0#1) : Bool)
                          then (do writeReg TFSRE0_EL1 (Sail.BitVec.updateSubrange (← readReg TFSRE0_EL1) 0 0 1#1))
                          else (do writeReg TFSRE0_EL1 (Sail.BitVec.updateSubrange (← readReg TFSRE0_EL1) 1 1 1#1))))
                    else (do (pure ())))))))))

def AArch64_TagCheckFault (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) : SailM Unit := do
  let tcf ← (( do (AArch64_EffectiveTCF accdesc.el) ) : SailM (BitVec 2) )
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_TagCheck }
  match tcf with
  | 0b00 => (pure ())
  | 0b01 => (AArch64_RaiseTagCheckFault vaddress fault)
  | 0b10 =>
    (do
      (if ((← (HaveMTEAsyncExt ())) : Bool)
      then (do (AArch64_ReportTagCheckFault accdesc.el ((BitVec.access vaddress 55) : BitVec 1)))
      else (do (pure ()))))
  | _ =>
    (do
      (if ((← (HaveMTEAsymFaultExt ())) : Bool)
      then
        (do (if (accdesc.read : Bool)
            then (do (AArch64_RaiseTagCheckFault vaddress fault))
            else (do (AArch64_ReportTagCheckFault accdesc.el ((BitVec.access vaddress 55) : BitVec 1)))))
      else (do (pure ()))))

def NumBreakpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of breakpoints")

def NumContextAwareBreakpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of context-aware breakpoints")

/-- Type quantifiers: n : Int -/
def AArch64_ReservedBreakpointType (n : Int) (bt2_in : (BitVec 1)) (bt_in : (BitVec 4)) : SailM (Constraint × (BitVec 1) × (BitVec 4)) := SailME.run do
  let bt2 : (BitVec 1) := bt2_in
  let bt : (BitVec 4) := bt_in
  let reserved : Bool := false
  let context_aware ← (( do (pure (n ≥b ((← (NumBreakpointsImplemented ())) -i (← (NumContextAwareBreakpointsImplemented ()))))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
  let reserved ← (( do
    (if ((bt2 == 0#1) : Bool)
    then
      (do let reserved : Bool :=
            if (((! (let b__1 := bt
                   if ((((Sail.BitVec.extractLsb b__1 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__1 1 1) == (0#1 : (BitVec 1)))) : Bool)
                   then true
                   else false : Bool)) && (! context_aware)) : Bool)
            then true
            else reserved
          let reserved : Bool :=
            if (((let b__2 := bt
                 if (((Sail.BitVec.extractLsb b__2 3 3) == (1#1 : (BitVec 1))) : Bool)
                 then true
                 else false : Bool) && (! (HaveEL EL2))) : Bool)
            then true
            else reserved
          let reserved ← (( do
            (if ((←((pure (let b__3 := bt
                 if (((Sail.BitVec.extractLsb b__3 3 1) == (0b011#3 : (BitVec 3))) : Bool)
                 then true
                 else
                   (if (((Sail.BitVec.extractLsb b__3 3 2) == (0b11#2 : (BitVec 2))) : Bool)
                   then true
                   else false) : Bool)) <&&> (do
                 (pure (! (← (HaveVirtHostExt ()))))) <&&> (do
                 (pure (! (← (HaveV82Debug ()))))))) : Bool)
            then (do (pure true))
            else (do (pure reserved))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
          (if (((←((pure (let b__5 := bt
                 if (((Sail.BitVec.extractLsb b__5 3 1) == (0b010#3 : (BitVec 3))) : Bool)
                 then true
                 else false : Bool)) <&&> (do
                 (pure (! (← (HaveFeatABLE ()))))))) && (! (HaveAArch32EL EL1))) : Bool)
          then (do (pure true))
          else (do (pure reserved))))
    else
      (do (if ((! (let b__0 := bt
               if ((((Sail.BitVec.extractLsb b__0 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1)))) : Bool)
               then true
               else false : Bool)) : Bool)
          then (do (pure true))
          else (do (pure reserved))))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
  let (bt, bt2) ← (( do
    (if (reserved : Bool)
    then
      (do let c ← (( do (undefined_Constraint ()) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Constraint )
          let (bt, bt2, c) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableBits Unpredictable_RESBPTYPE 5)
            let c : Constraint := tup__0
            let bt2 : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 4 4)
            let bt : (BitVec 4) := (Sail.BitVec.extractLsb tup__1 3 0)
            (pure (bt, bt2, c)) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) ((BitVec 4) × (BitVec 1) × Constraint) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23104.65-23104.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw (← do (pure (c, (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bits 4))))))
          else (do (pure ())))
          (pure (bt, bt2)))
    else (do (pure (bt, bt2)))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) ((BitVec 4) × (BitVec 1)) )
  (pure (Constraint_NONE, bt2, bt))

def undefined_CONTEXTIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CONTEXTIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DBGBCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGBCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DBGBCR_EL1_Type_BAS (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 8 5)

def _get_DBGWCR_EL1_Type_BAS (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 12 5)

def _get_DBGBCR_EL1_Type_BT2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_DBGBCR_EL1_Type_HMC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_DBGWCR_EL1_Type_HMC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_DBGBCR_EL1_Type_LBN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _get_DBGWCR_EL1_Type_LBN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _get_DBGBCR_EL1_Type_LBNX (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_DBGWCR_EL1_Type_LBNX (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_DBGBCR_EL1_Type_MASK (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 28 24)

def _get_DBGWCR_EL1_Type_MASK (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 28 24)

def _get_DBGBCR_EL1_Type_PMC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_DBGBCR_EL1_Type_SSC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_DBGWCR_EL1_Type_SSC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_DBGBCR_EL1_Type_SSCE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_DBGWCR_EL1_Type_SSCE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def undefined_DBGBVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGBVR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTTBR_EL2_Type_VMID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_VTTBR_Type_VMID (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 55 48)

def DebugAddrTop (_ : Unit) : SailM Int := do
  (if ((← (Have56BitVAExt ())) : Bool)
  then (do (pure 55))
  else
    (do (if ((← (Have52BitVAExt ())) : Bool)
        then (do (pure 52))
        else (do (pure 48)))))

def undefined_EDSCR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDSCR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def EDSCR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDSCR2 ) : SailM EDSCR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDSCR_EL1) 32 32)))

def HaltOnBreakpointOrWatchpoint (_ : Unit) : SailM Bool := do
  (HaltingAllowed ()) <&&> (do
    (pure ((_get_EDSCR_Type_HDE (← (EDSCR_read ()))) == 1#1))) <&&> (do
    (pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)))

def NumWatchpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of watchpoints")

def SelfHostedExtendedBPWPEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure ((← (NumBreakpointsImplemented ())) ≤b 16)) <&&> (do
       (pure ((← (NumWatchpointsImplemented ())) ≤b 16))))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_MDCR_EL3_Type_EBWE (← readReg MDCR_EL3)) == 0#1))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((_get_MDCR_EL2_Type_EBWE (← readReg MDCR_EL2)) == 0#1)))))) : Bool)
        then (do (pure false))
        else (do (pure ((_get_MDSCR_EL1_Type_EMBWE (← readReg MDSCR_EL1)) == 1#1))))))

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 64 -/
def IsBreakpointEnabled (n : Nat) : SailM Bool := do
  (if ((←((pure (n >b 15)) <&&> (do
       (pure (! (← (HaltOnBreakpointOrWatchpoint ())))) <&&> (do
         (pure (! (← (SelfHostedExtendedBPWPEnabled ()))))) <||> (do
         (HaltOnBreakpointOrWatchpoint ()) <&&> (do
           (pure ((_get_EDSCR2_Type_EHBWE (← (EDSCR2_read ()))) == 0#1))))))) : Bool)
  then (do (pure false))
  else (do (pure ((_get_DBGBCR_EL1_Type_E (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) == 1#1))))

def undefined_VTCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VTCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTCR_EL2_Type_GCSH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 40 40)

def _get_VTCR_EL2_Type_NSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_VTCR_EL2_Type_NSW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_VTCR_EL2_Type_S2PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_VTCR_EL2_Type_S2POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_VTCR_EL2_Type_SL0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_VSTCR_EL2_Type_SL0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_VTCR_EL2_Type_SL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_VSTCR_EL2_Type_SL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_VTCR_EL2_Type_TL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_VTCR_EL2_Type_TL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_VTCR_EL2_Type_VS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_VTTBR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_VTTBR_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_VTTBR_EL2_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def VTTBR_EL2_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _VTTBR_EL2 ) : SailM VTTBR_EL2_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg VTTBR) 0 64)))

/-- Type quantifiers: k_isbreakpnt : Bool, k_linked_to : Bool, n_in : Int -/
def AArch64_BreakpointValueMatch (n_in : Int) (vaddress : (BitVec 64)) (linked_to : Bool) (isbreakpnt : Bool) : SailM (Bool × Bool) := SailME.run do
  let n : Int := n_in
  let c ← (( do (undefined_Constraint ()) ) : SailME (Bool × Bool) Constraint )
  let (c, n) ← (( do
    (if ((n ≥b (← (NumBreakpointsImplemented ()))) : Bool)
    then
      (do let (c, n) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger 0 ((← (NumBreakpointsImplemented ())) -i 1) Unpredictable_BPNOTIMPL)
            let c : Constraint := tup__0
            let n : Int := tup__1
            (pure (c, n)) ) : SailME (Bool × Bool) (Constraint × Int) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23258.65-23258.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw ((false, false) : (Bool × Bool)))
          else (do (pure ())))
          (pure (c, n)))
    else (do (pure (c, n)))) ) : SailME (Bool × Bool) (Constraint × Int) )
  let n := n
  sail_assert ((0 ≤b n) && (n <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23265.42-23265.43"
  (if ((! (← (IsBreakpointEnabled n))) : Bool)
  then (do (pure (false, false)))
  else
    (do let dbgtype ← (( do (pure (_get_DBGBCR_EL1_Type_BT (GetElem?.getElem! (← readReg DBGBCR_EL1) n))) ) : SailME (Bool × Bool) (BitVec 4) )
        let bt2 ← (( do
          (if ((← (HaveFeatABLE ())) : Bool)
          then (do (pure (_get_DBGBCR_EL1_Type_BT2 (GetElem?.getElem! (← readReg DBGBCR_EL1) n))))
          else (do (pure 0#1))) ) : SailME (Bool × Bool) (BitVec 1) )
        let (bt2, c, dbgtype) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_ReservedBreakpointType n bt2 dbgtype)
          let c : Constraint := tup__0
          let bt2 : (BitVec 1) := tup__1
          let dbgtype : (BitVec 4) := tup__2
          (pure (bt2, c, dbgtype)) ) : SailME (Bool × Bool) ((BitVec 1) × Constraint × (BitVec 4)) )
        (if ((BEq.beq c Constraint_DISABLED) : Bool)
        then (do (pure (false, false)))
        else
          (do let match_addr : Bool :=
                (let b__8 := dbgtype
                if ((((Sail.BitVec.extractLsb b__8 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__8 1 1) == (0#1 : (BitVec 1)))) : Bool)
                then true
                else false : Bool)
              let mismatch : Bool :=
                (let b__7 := dbgtype
                if (((Sail.BitVec.extractLsb b__7 3 1) == (0b010#3 : (BitVec 3))) : Bool)
                then true
                else false : Bool)
              let match_vmid : Bool :=
                (let b__6 := dbgtype
                if (((Sail.BitVec.extractLsb b__6 3 2) == (0b10#2 : (BitVec 2))) : Bool)
                then true
                else false : Bool)
              let match_cid : Bool :=
                (let b__5 := dbgtype
                if (((Sail.BitVec.extractLsb b__5 3 1) == (0b001#3 : (BitVec 3))) : Bool)
                then true
                else false : Bool)
              let match_cid1 : Bool :=
                (let b__3 := dbgtype
                if (((Sail.BitVec.extractLsb b__3 3 1) == (0b101#3 : (BitVec 3))) : Bool)
                then true
                else
                  (if (((Sail.BitVec.extractLsb b__3 2 1) == (0b11#2 : (BitVec 2))) : Bool)
                  then true
                  else false) : Bool)
              let match_cid2 : Bool :=
                (let b__2 := dbgtype
                if (((Sail.BitVec.extractLsb b__2 3 2) == (0b11#2 : (BitVec 2))) : Bool)
                then true
                else false : Bool)
              let linking_enabled : Bool :=
                ((let b__0 := dbgtype
                  if (((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2))) : Bool)
                  then true
                  else
                    (if ((((Sail.BitVec.extractLsb b__0 3 3) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                    then true
                    else false) : Bool) || (bt2 == 1#1))
              (if ((linked_to && (! linking_enabled)) : Bool)
              then (do (pure (false, false)))
              else
                (do (if ((((! linked_to) && linking_enabled) && (! match_addr)) : Bool)
                    then (do (pure (false, false)))
                    else
                      (do (if (((linked_to && match_addr) && isbreakpnt) : Bool)
                          then
                            (do (if ((! (← (ConstrainUnpredictableBool Unpredictable_BPLINKEDADDRMATCH))) : Bool)
                                then (do SailME.throw ((false, false) : (Bool × Bool)))
                                else (do (pure ()))))
                          else (do (pure ())))
                          (if ((←((pure mismatch) <&&> (do
                               (UsingAArch32 ())))) : Bool)
                          then (do (pure (false, false)))
                          else
                            (do let bvr_match : Bool := false
                                let bxvr_match : Bool := false
                                let mask ← (( do (undefined_int ()) ) : SailME (Bool × Bool) Int )
                                let mask ← (( do
                                  (if ((← (HaveFeatABLE ())) : Bool)
                                  then
                                    (do let mask ← (( (pure (BitVec.toNat (_get_DBGBCR_EL1_Type_MASK (GetElem?.getElem! (← readReg DBGBCR_EL1) n)))) ) : SailME (Bool × Bool) Int )
                                        let mask ← (( do
                                          (if (((mask == 1) || (mask == 2)) : Bool)
                                          then
                                            (do let (c, mask) ← (( do
                                                  let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger 3 31 Unpredictable_RESBPMASK)
                                                  let c : Constraint := tup__0
                                                  let mask : Int := tup__1
                                                  (pure (c, mask)) ) : SailME (Bool × Bool) (Constraint × Int) )
                                                sail_assert ((BEq.beq c Constraint_DISABLED) || ((BEq.beq c Constraint_NONE) || (BEq.beq c Constraint_UNKNOWN))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23327.92-23327.93"
                                                match c with
                                                | .Constraint_DISABLED => SailME.throw ((false, false) : (Bool × Bool))
                                                | .Constraint_NONE => (pure 0)
                                                | _ => (pure mask))
                                          else (do (pure mask))) ) : SailME (Bool × Bool) Int )
                                        (if ((mask != 0) : Bool)
                                        then
                                          (do (if ((←((pure ((match_cid || match_cid1) || match_cid2)) <||> (do
                                                   (pure (((_get_DBGBCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) != 0b1111#4) && (HaveAArch32 ())))))) : Bool)
                                              then
                                                (do (if ((! (← (ConstrainUnpredictableBool Unpredictable_BPMASK))) : Bool)
                                                    then (do SailME.throw ((false, false) : (Bool × Bool)))
                                                    else (do (pure ()))))
                                              else (do (pure ()))))
                                        else
                                          (do (if (mismatch : Bool)
                                              then (do SailME.throw ((false, false) : (Bool × Bool)))
                                              else (do (pure ())))))
                                        (pure mask))
                                  else (do (pure 0))) ) : SailME (Bool × Bool) Int )
                                let mask := mask
                                let bvr_match ← (( do
                                  (if (match_addr : Bool)
                                  then
                                    (do let byte_select_match ← (( do (undefined_bool ()) ) : SailME (Bool × Bool) Bool )
                                        let byte := (BitVec.toNat (Sail.BitVec.extractLsb vaddress 1 0))
                                        let byte_select_match ← (( do
                                          (if ((HaveAArch32 ()) : Bool)
                                          then
                                            (do sail_assert ((byte == 0) || (byte == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23360.40-23360.41"
                                                (pure (((BitVec.access (_get_DBGBCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) byte) : BitVec 1) == 1#1)))
                                          else
                                            (do sail_assert (byte == 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:23363.28-23363.29"
                                                (pure true))) ) : SailME (Bool × Bool) Bool )
                                        let top ← (( do (DebugAddrTop ()) ) : SailME (Bool × Bool) Int )
                                        let bottom := 2
                                        let top ← (( do
                                          (if ((←((pure (top <b 55)) <&&> (do
                                               (pure (! (is_ones_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 top)))) <&&> (do
                                               (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 top)))) <&&> (do
                                               (ConstrainUnpredictableBool Unpredictable_DBGxVR_RESS)))) : Bool)
                                          then (do (pure 63))
                                          else (do (pure top))) ) : SailME (Bool × Bool) Int )
                                        let top := top
                                        (if ((mask >b bottom) : Bool)
                                        then
                                          (do sail_assert ((0 ≤b mask) && ((mask ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23373.71-23373.72"
                                              let bvr_match ← (pure (((Sail.BitVec.extractLsb vaddress top mask) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) top mask)) && byte_select_match))
                                              (if ((←((pure bvr_match) <&&> (do
                                                   (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) (mask -i 1) bottom)))))) : Bool)
                                              then (do (ConstrainUnpredictableBool Unpredictable_BPMASKEDBITS))
                                              else (do (pure bvr_match))))
                                        else
                                          (do sail_assert ((0 ≤b bottom) && ((bottom ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23380.75-23380.76"
                                              (pure (((Sail.BitVec.extractLsb vaddress top bottom) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) top bottom)) && byte_select_match)))))
                                  else
                                    (do (if (match_cid : Bool)
                                        then
                                          (do (if ((← (IsInHost ())) : Bool)
                                              then (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL2) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0))))
                                              else (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL1) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0)))))))
                                        else
                                          (do (if (match_cid1 : Bool)
                                              then (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure (! (← (IsInHost ()))))) <&&> (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL1) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0)))))
                                              else (do (pure bvr_match))))))) ) : SailME (Bool × Bool) Bool )
                                let bxvr_match ← (( do
                                  (if (match_vmid : Bool)
                                  then
                                    (do let vmid ← (( do (undefined_bitvector 16) ) : SailME (Bool × Bool) (BitVec 16) )
                                        let bvr_vmid ← (( do (undefined_bitvector 16) ) : SailME (Bool × Bool) (BitVec 16) )
                                        let (bvr_vmid, vmid) ← (( do
                                          (if ((←((pure (! (← (Have16bitVMID ())))) <||> (do
                                               (pure ((_get_VTCR_EL2_Type_VS (← readReg VTCR_EL2)) == 0#1))))) : Bool)
                                          then
                                            (do let vmid ← (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ()))) 7 0) 16))
                                                let bvr_vmid ← (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 39 32) 16))
                                                (pure (bvr_vmid, vmid)))
                                          else
                                            (do let vmid ← (pure (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ()))))
                                                let bvr_vmid ← (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 47 32))
                                                (pure (bvr_vmid, vmid)))) ) : SailME (Bool × Bool) ((BitVec 16) × (BitVec 16)) )
                                        (pure ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure (! (← (IsInHost ()))))))) && (vmid == bvr_vmid))))
                                  else
                                    (do (if (match_cid2 : Bool)
                                        then (do (pure ((← readReg PSTATE).EL != EL3)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 32) == (Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL2) 31 0)))))
                                        else (do (pure bxvr_match))))) ) : SailME (Bool × Bool) Bool )
                                let bvr_match_valid : Bool := ((match_addr || match_cid) || match_cid1)
                                let bxvr_match_valid : Bool := (match_vmid || match_cid2)
                                let value_match_name : Bool := (((! bxvr_match_valid) || bxvr_match) && ((! bvr_match_valid) || bvr_match))
                                (pure (value_match_name, mismatch))))))))))))

/-- Type quantifiers: k_isbreakpnt : Bool -/
def CheckValidStateMatch (ssc_in : (BitVec 2)) (ssce_in : (BitVec 1)) (hmc_in : (BitVec 1)) (pxc_in : (BitVec 2)) (isbreakpnt : Bool) : SailM (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) := SailME.run do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do sail_assert (ssce_in == 0#1) "sail-arm/arm-v9.4-a/src/v8_base.sail:23417.29-23417.30")
  else (do (pure ())))
  let reserved : Bool := false
  let ssc : (BitVec 2) := ssc_in
  let ssce : (BitVec 1) := ssce_in
  let hmc : (BitVec 1) := hmc_in
  let pxc : (BitVec 2) := pxc_in
  let reserved ← (( do
    let b__0 := (((hmc +++ ssce) +++ ssc) +++ pxc)
    (if ((b__0 == (0b001110#6 : (BitVec 6))) : Bool)
    then (do (pure true))
    else
      (do (if (((Sail.BitVec.extractLsb b__0 5 3) == (0b001#3 : (BitVec 3))) : Bool)
          then (do (pure (! (← (HaveSecureState ())))))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 5 2) == (0x8#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__0 == (0b100110#6 : (BitVec 6))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 5 3) == (0b101#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                            then (do (pure true))
                            else
                              (do (if (((Sail.BitVec.extractLsb b__0 4 4) == (1#1 : (BitVec 1))) : Bool)
                                  then (do (pure ((ssc != 0b01#2) || (((hmc +++ pxc) == 0b000#3) || ((hmc +++ pxc) == 0b110#3)))))
                                  else (do (pure false))))))))))))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let reserved : Bool :=
    if (((((! isbreakpnt) || (! (HaveAArch32EL EL1))) && ((hmc +++ pxc) == 0b000#3)) && (ssc != 0b11#2)) : Bool)
    then true
    else reserved
  let reserved : Bool :=
    if ((((! (HaveEL EL3)) && (! (HaveEL EL2))) && ((hmc != 0#1) || (ssc != 0b00#2))) : Bool)
    then true
    else reserved
  let reserved : Bool :=
    if ((((! (HaveEL EL3)) && ((ssc == 0b01#2) || (ssc == 0b10#2))) && (((hmc +++ ssc) +++ pxc) != 0b10100#5)) : Bool)
    then true
    else reserved
  let reserved ← (( do
    (if (((←((pure (! (HaveEL EL3))) <||> (do
           (pure (! (← (HaveAArch64 ()))))))) && (((hmc +++ ssc) +++ pxc) == 0b11000#5)) : Bool)
    then (do (pure true))
    else (do (pure reserved))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let reserved : Bool :=
    if (((! (HaveEL EL2)) && (((hmc +++ ssc) +++ pxc) == 0b11100#5)) : Bool)
    then true
    else reserved
  let reserved ← (( do
    (if (((! (← (HaveSecureEL2Ext ()))) && (let b__6 := ((hmc +++ ssc) +++ pxc)
         if ((b__6 == (0b01100#5 : (BitVec 5))) : Bool)
         then true
         else
           (if ((b__6 == (0b10100#5 : (BitVec 5))) : Bool)
           then true
           else
             (if ((((Sail.BitVec.extractLsb b__6 3 2) == (0b11#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__6 0 0) == (1#1 : (BitVec 1)))) : Bool)
             then true
             else false)) : Bool)) : Bool)
    then (do (pure true))
    else (do (pure reserved))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let (hmc, pxc, ssc, ssce) ← (( do
    (if (reserved : Bool)
    then
      (do let c ← (( do (undefined_Constraint ()) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Constraint )
          let (c, hmc, pxc, ssc, ssce) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableBits Unpredictable_RESBPWPCTRL 6)
            let c : Constraint := tup__0
            let hmc : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 5 5)
            let ssc : (BitVec 2) := (Sail.BitVec.extractLsb tup__1 4 3)
            let ssce : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 2 2)
            let pxc : (BitVec 2) := (Sail.BitVec.extractLsb tup__1 1 0)
            (pure (c, hmc, pxc, ssc, ssce)) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) (Constraint × (BitVec 1) × (BitVec 2) × (BitVec 2) × (BitVec 1)) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23473.65-23473.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw (← do (pure (c, (← (__UNKNOWN_bits 2)), (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bits 2))))))
          else (do (pure ())))
          (pure (hmc, pxc, ssc, ssce)))
    else (do (pure (hmc, pxc, ssc, ssce)))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) ((BitVec 1) × (BitVec 2) × (BitVec 2) × (BitVec 1)) )
  (pure (Constraint_NONE, ssc, ssce, hmc, pxc))

def ContextMatchingBreakpointRange (_ : Unit) : SailM (Int × Int) := do
  let b ← (( do (NumBreakpointsImplemented ()) ) : SailM Int )
  let c ← (( do (NumContextAwareBreakpointsImplemented ()) ) : SailM Int )
  (if ((b ≤b 16) : Bool)
  then (do (pure ((b -i c), (b -i 1))))
  else
    (do (if ((c ≤b 16) : Bool)
        then (do (pure ((16 -i c), 15)))
        else (do (pure (0, (c -i 1)))))))

/-- Type quantifiers: n : Int -/
def IsContextMatchingBreakpoint (n : Int) : SailM Bool := do
  let lower ← (( do (undefined_int ()) ) : SailM Int )
  let upper ← (( do (undefined_int ()) ) : SailM Int )
  let (lower, upper) ← (( do
    let (tup__0, tup__1) ← do (ContextMatchingBreakpointRange ())
    let lower : Int := tup__0
    let upper : Int := tup__1
    (pure (lower, upper)) ) : SailM (Int × Int) )
  let upper := upper
  let lower := lower
  (pure ((n ≥b lower) && (n ≤b upper)))

/-- Type quantifiers: k_isbreakpnt : Bool, k_linked_in : Bool, linked_n_in : Int -/
def AArch64_StateMatch (ssc_in : (BitVec 2)) (ssce_in : (BitVec 1)) (hmc_in : (BitVec 1)) (pxc_in : (BitVec 2)) (linked_in : Bool) (linked_n_in : Int) (isbreakpnt : Bool) (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) : SailM Bool := SailME.run do
  let first_ctx_cmp ← (( do (undefined_int ()) ) : SailME Bool Int )
  let last_ctx_cmp ← (( do (undefined_int ()) ) : SailME Bool Int )
  let linked_to ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  (if ((! (← (HaveRME ()))) : Bool)
  then (do sail_assert (ssce_in == 0#1) "sail-arm/arm-v9.4-a/src/v8_base.sail:23515.29-23515.30")
  else (do (pure ())))
  let ssc : (BitVec 2) := ssc_in
  let ssce : (BitVec 1) := ssce_in
  let hmc : (BitVec 1) := hmc_in
  let pxc : (BitVec 2) := pxc_in
  let linked : Bool := linked_in
  let linked_n : Int := linked_n_in
  let c ← (( do (undefined_Constraint ()) ) : SailME Bool Constraint )
  let (c, hmc, pxc, ssc, ssce) ← (( do
    let (tup__0, tup__1, tup__2, tup__3, tup__4) ← do (CheckValidStateMatch ssc ssce hmc pxc isbreakpnt)
    let c : Constraint := tup__0
    let ssc : (BitVec 2) := tup__1
    let ssce : (BitVec 1) := tup__2
    let hmc : (BitVec 1) := tup__3
    let pxc : (BitVec 2) := tup__4
    (pure (c, hmc, pxc, ssc, ssce)) ) : SailME Bool (Constraint × (BitVec 1) × (BitVec 2) × (BitVec 2) × (BitVec 1)) )
  (if ((BEq.beq c Constraint_DISABLED) : Bool)
  then (do (pure false))
  else
    (do let EL3_match : Bool := (((HaveEL EL3) && (hmc == 1#1)) && (((BitVec.access ssc 0) : BitVec 1) == 0#1))
        let EL2_match : Bool := ((HaveEL EL2) && (((hmc == 1#1) && ((ssc +++ pxc) != 0b1000#4)) || (ssc == 0b11#2)))
        let EL1_match : Bool := (((BitVec.access pxc 0) : BitVec 1) == 1#1)
        let EL0_match : Bool := (((BitVec.access pxc 1) : BitVec 1) == 1#1)
        let priv_match ← (( do (undefined_bool ()) ) : SailME Bool Bool )
        let priv_match : Bool :=
          let questionMark := accdesc.el
          if ((questionMark == EL3) : Bool)
          then EL3_match
          else
            (if ((questionMark == EL2) : Bool)
            then EL2_match
            else
              (if ((questionMark == EL1) : Bool)
              then EL1_match
              else
                (if ((questionMark == EL0) : Bool)
                then EL0_match
                else priv_match)))
        let ss_match ← (( do (undefined_bool ()) ) : SailME Bool Bool )
        let ss_match : Bool :=
          match (ssce +++ ssc) with
          | 0b000 => ((hmc == 1#1) || (bne accdesc.ss SS_Root))
          | 0b001 => (BEq.beq accdesc.ss SS_NonSecure)
          | 0b010 => (((hmc == 1#1) && (BEq.beq accdesc.ss SS_Root)) || (BEq.beq accdesc.ss SS_Secure))
          | 0b011 => (((hmc == 1#1) && (bne accdesc.ss SS_Root)) || (BEq.beq accdesc.ss SS_Secure))
          | 0b101 => (BEq.beq accdesc.ss SS_Realm)
          | _ => ss_match
        let linked_match : Bool := false
        let is_linked_mismatch : Bool := false
        let (linked, linked_n) ← (( do
          (if (linked : Bool)
          then
            (do let (linked, linked_n) ← (( do
                  (if ((! (← (IsContextMatchingBreakpoint linked_n))) : Bool)
                  then
                    (do let (first_ctx_cmp, last_ctx_cmp) ← (( do
                          let (tup__0, tup__1) ← do (ContextMatchingBreakpointRange ())
                          let first_ctx_cmp : Int := tup__0
                          let last_ctx_cmp : Int := tup__1
                          (pure (first_ctx_cmp, last_ctx_cmp)) ) : SailME Bool (Int × Int) )
                        let last_ctx_cmp := last_ctx_cmp
                        let first_ctx_cmp := first_ctx_cmp
                        let (c, linked_n) ← (( do
                          let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger first_ctx_cmp last_ctx_cmp Unpredictable_BPNOTCTXCMP)
                          let c : Constraint := tup__0
                          let linked_n : Int := tup__1
                          (pure (c, linked_n)) ) : SailME Bool (Constraint × Int) )
                        sail_assert ((BEq.beq c Constraint_DISABLED) || ((BEq.beq c Constraint_NONE) || (BEq.beq c Constraint_UNKNOWN))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23575.92-23575.93"
                        let linked ← (( do
                          match c with
                          | .Constraint_DISABLED => SailME.throw (false : Bool)
                          | .Constraint_NONE => (pure false)
                          | _ => (pure linked) ) : SailME Bool Bool )
                        (pure (linked, linked_n)))
                  else (do (pure (linked, linked_n)))) ) : SailME Bool (Bool × Int) )
                (pure (linked, linked_n)))
          else (do (pure (linked, linked_n)))) ) : SailME Bool (Bool × Int) )
        let linked_n := linked_n
        let (is_linked_mismatch, linked_match) ← (( do
          (if (linked : Bool)
          then
            (do let linked_to : Bool := true
                let (tup__0, tup__1) ← do (AArch64_BreakpointValueMatch linked_n vaddress linked_to isbreakpnt)
                let linked_match : Bool := tup__0
                let is_linked_mismatch : Bool := tup__1
                (pure (is_linked_mismatch, linked_match)))
          else (do (pure (is_linked_mismatch, linked_match)))) ) : SailME Bool (Bool × Bool) )
        (pure ((priv_match && ss_match) && (((! linked) || ((! is_linked_mismatch) && linked_match)) || (is_linked_mismatch && (! linked_match)))))))

/-- Type quantifiers: n : Nat, size : Int, 0 ≤ n ∧ n < 64 -/
def AArch64_BreakpointMatch (n : Nat) (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) (size : Int) : SailM (Bool × Bool) := do
  let match_i ← (( do (undefined_bool ()) ) : SailM Bool )
  let valid_mismatch_name ← (( do (undefined_bool ()) ) : SailM Bool )
  let value_match_name ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (! (← (ELUsingAArch32 (← (S1TranslationRegime__1 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23603.61-23603.62"
  sail_assert (n <b (← (NumBreakpointsImplemented ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23604.42-23604.43"
  let linking_enabled ← (( do
    (do
      let b__1 ← do (pure (_get_DBGBCR_EL1_Type_BT (GetElem?.getElem! (← readReg DBGBCR_EL1) n)))
      (if ((((Sail.BitVec.extractLsb b__1 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__1 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
      then (do (pure true))
      else
        (do (if ((((Sail.BitVec.extractLsb b__1 3 3) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__1 0 0) == (1#1 : (BitVec 1)))) : Bool)
            then (do (pure true))
            else (do (pure false)))))) <||> (do
      (HaveFeatABLE ()) <&&> (do
        (pure ((_get_DBGBCR_EL1_Type_BT2 (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) == 1#1)))) ) : SailM Bool )
  (if (linking_enabled : Bool)
  then (do (pure (false, false)))
  else
    (do let enabled ← (( do (IsBreakpointEnabled n) ) : SailM Bool )
        let linked ← (( do
          let b__0 ← do (pure (_get_DBGBCR_EL1_Type_BT (GetElem?.getElem! (← readReg DBGBCR_EL1) n)))
          (if ((((Sail.BitVec.extractLsb b__0 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure true))
          else (do (pure false))) ) : SailM Bool )
        let isbreakpnt : Bool := true
        let linked_to : Bool := false
        let lbnx ← (( do
          (if ((← (Havev8p9Debug ())) : Bool)
          then (do (pure (_get_DBGBCR_EL1_Type_LBNX (GetElem?.getElem! (← readReg DBGBCR_EL1) n))))
          else (do (pure 0b00#2))) ) : SailM (BitVec 2) )
        let linked_n ← (( do (pure (BitVec.toNat (lbnx +++ (_get_DBGBCR_EL1_Type_LBN (GetElem?.getElem! (← readReg DBGBCR_EL1) n))))) ) : SailM Int )
        let ssce ← (( do
          (if ((← (HaveRME ())) : Bool)
          then (do (pure (_get_DBGBCR_EL1_Type_SSCE (GetElem?.getElem! (← readReg DBGBCR_EL1) n))))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        let state_match ← (( do (AArch64_StateMatch (_get_DBGBCR_EL1_Type_SSC (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) ssce (_get_DBGBCR_EL1_Type_HMC (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) (_get_DBGBCR_EL1_Type_PMC (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) linked linked_n isbreakpnt vaddress accdesc) ) : SailM Bool )
        let (valid_mismatch_name, value_match_name) ← (( do
          let (tup__0, tup__1) ← do (AArch64_BreakpointValueMatch n vaddress linked_to isbreakpnt)
          let value_match_name : Bool := tup__0
          let valid_mismatch_name : Bool := tup__1
          (pure (valid_mismatch_name, value_match_name)) ) : SailM (Bool × Bool) )
        let value_match_name ← (( do
          (if (((HaveAArch32 ()) && (size == 4)) : Bool)
          then
            (do let match_i ← (( do
                  let (__tup_0, _) ← do (AArch64_BreakpointValueMatch n (BitVec.addInt vaddress 2) linked_to isbreakpnt)
                  (pure __tup_0) ) : SailM Bool )
                (if (((! value_match_name) && match_i) : Bool)
                then (do (ConstrainUnpredictableBool Unpredictable_BPMATCHHALF))
                else (do (pure value_match_name))))
          else (do (pure value_match_name))) ) : SailM Bool )
        let value_match_name ← (( do
          (if ((←((pure (((BitVec.access vaddress 1) : BitVec 1) == 1#1)) <&&> (do
               (pure ((_get_DBGBCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) == 0b1111#4))))) : Bool)
          then
            (do (if (value_match_name : Bool)
                then (do (ConstrainUnpredictableBool Unpredictable_BPMATCHHALF))
                else (do (pure value_match_name))))
          else (do (pure value_match_name))) ) : SailM Bool )
        let val_match : Bool := ((value_match_name && state_match) && enabled)
        let is_mismatch : Bool := ((valid_mismatch_name && state_match) && enabled)
        (pure (val_match, is_mismatch))))

/-- Type quantifiers: size : Int -/
def AArch64_CheckBreakpoint (fault_in : FaultRecord) (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) (size : Int) : SailM FaultRecord := do
  let is_mismatch_i ← (( do (undefined_bool ()) ) : SailM Bool )
  let match_i ← (( do (undefined_bool ()) ) : SailM Bool )
  let reason ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
  sail_assert (! (← (ELUsingAArch32 (← (S1TranslationRegime__1 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23655.61-23655.62"
  sail_assert (((← (UsingAArch32 ())) && ((size == 2) || (size == 4))) || (size == 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23656.63-23656.64"
  let fault : FaultRecord := fault_in
  let val_match : Bool := false
  let mismatch : Bool := true
  let mismatch_bp : Bool := false
  let (is_mismatch_i, match_i, mismatch, mismatch_bp, val_match) ← (( do
    let loop_i_lower := 0
    let loop_i_upper ← (( do (pure ((← (NumBreakpointsImplemented ())) -i 1)) ) : SailM Int )
    let mut loop_vars := (is_mismatch_i, match_i, mismatch, mismatch_bp, val_match)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (is_mismatch_i, match_i, mismatch, mismatch_bp, val_match) := loop_vars
      loop_vars ← do
        sail_assert ((i <b 64) || (! (((size == 2) || (size == 4)) || (size == 4)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23662.67-23662.68"
        let (is_mismatch_i, match_i) ← (( do
          let (tup__0, tup__1) ← do (AArch64_BreakpointMatch i vaddress accdesc size)
          let match_i : Bool := tup__0
          let is_mismatch_i : Bool := tup__1
          (pure (is_mismatch_i, match_i)) ) : SailM (Bool × Bool) )
        let (mismatch, mismatch_bp, val_match) : (Bool × Bool × Bool) :=
          if (is_mismatch_i : Bool)
          then
            (let mismatch_bp : Bool := true
            let mismatch : Bool := (mismatch && (! match_i))
            (mismatch, mismatch_bp, val_match))
          else
            (let val_match : Bool := (val_match || match_i)
            (mismatch, mismatch_bp, val_match))
        (pure (is_mismatch_i, match_i, mismatch, mismatch_bp, val_match))
    (pure loop_vars) ) : SailM (Bool × Bool × Bool × Bool × Bool) )
  (if ((val_match || (mismatch && mismatch_bp)) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_Debug }
        (if ((← (HaltOnBreakpointOrWatchpoint ())) : Bool)
        then
          (do let reason : (BitVec 6) := DebugHalt_Breakpoint
              (Halt reason))
        else (do (pure ())))
        (pure fault))
  else (do (pure fault)))

def undefined_DBGWCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGWCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DBGWCR_EL1_Type_LSC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 4 3)

def _get_DBGWCR_EL1_Type_PAC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_DBGWCR_EL1_Type_WT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def undefined_DBGWVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGWVR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 64 -/
def AArch64_WatchpointByteMatch (n : Nat) (vaddress : (BitVec 64)) : SailM Bool := SailME.run do
  let LSB ← (( do (undefined_bitvector 8) ) : SailME Bool (BitVec 8) )
  let MSB ← (( do (undefined_bitvector 8) ) : SailME Bool (BitVec 8) )
  let top ← (( do (DebugAddrTop ()) ) : SailME Bool Int )
  let bottom ← (( do
    (if ((((BitVec.access (GetElem?.getElem! (← readReg DBGWVR_EL1) n) 2) : BitVec 1) == 1#1) : Bool)
    then (do (pure 2))
    else (do (pure 3))) ) : SailME Bool Nat )
  let byte_select_match ← (( do
    let bottom := bottom
    (pure (((BitVec.access (_get_DBGWCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) (BitVec.toNat (Sail.BitVec.extractLsb vaddress (bottom -i 1) 0))) : BitVec 1) != 0#1)) ) : SailME Bool Bool )
  let mask ← (( do (pure (BitVec.toNat (_get_DBGWCR_EL1_Type_MASK (GetElem?.getElem! (← readReg DBGWCR_EL1) n)))) ) : SailME Bool Int )
  let (bottom, byte_select_match) ← (( do
    (if ((←((pure (mask >b 0)) <&&> (do
         (pure (! (IsOnes (_get_DBGWCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGWCR_EL1) n)))))))) : Bool)
    then
      (do let byte_select_match ← (ConstrainUnpredictableBool Unpredictable_WPMASKANDBAS)
          (pure (bottom, byte_select_match)))
    else
      (do let LSB ← (( do (pure ((_get_DBGWCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) &&& (Complement.complement (BitVec.subInt (_get_DBGWCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) 1)))) ) : SailME Bool (BitVec 8) )
          let MSB ← (( do (pure ((_get_DBGWCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) + LSB)) ) : SailME Bool (BitVec 8) )
          let (bottom, byte_select_match) ← (( do
            (if ((! (IsZero (MSB &&& (BitVec.subInt MSB 1)))) : Bool)
            then
              (do let byte_select_match ← (ConstrainUnpredictableBool Unpredictable_WPBASCONTIGUOUS)
                  let bottom : Nat := 3
                  (pure (bottom, byte_select_match)))
            else (do (pure (bottom, byte_select_match)))) ) : SailME Bool (Int × Bool) )
          (pure (bottom, byte_select_match)))) ) : SailME Bool (Int × Bool) )
  let bottom := bottom
  let mask ← (( do
    (if (((mask >b 0) && (mask ≤b 2)) : Bool)
    then
      (do let c ← (( do (undefined_Constraint ()) ) : SailME Bool Constraint )
          let (c, mask) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger 3 31 Unpredictable_RESWPMASK)
            let c : Constraint := tup__0
            let mask : Int := tup__1
            (pure (c, mask)) ) : SailME Bool (Constraint × Int) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || ((BEq.beq c Constraint_NONE) || (BEq.beq c Constraint_UNKNOWN))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23732.88-23732.89"
          match c with
          | .Constraint_DISABLED => SailME.throw (false : Bool)
          | .Constraint_NONE => (pure 0)
          | _ => (pure mask))
    else (do (pure mask))) ) : SailME Bool Int )
  let mask := mask
  let top ← (( do
    (if ((←((pure (top <b 55)) <&&> (do
         (pure (! (is_ones_subrange (GetElem?.getElem! (← readReg DBGWVR_EL1) n) 63 top)))) <&&> (do
         (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGWVR_EL1) n) 63 top)))) <&&> (do
         (ConstrainUnpredictableBool Unpredictable_DBGxVR_RESS)))) : Bool)
    then (do (pure 63))
    else (do (pure top))) ) : SailME Bool Int )
  let top := top
  let WVR_match ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  let WVR_match ← (( do
    (if ((mask >b bottom) : Bool)
    then
      (do sail_assert ((0 ≤b mask) && ((mask ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23750.67-23750.68"
          let WVR_match ← (pure ((Sail.BitVec.extractLsb vaddress top mask) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGWVR_EL1) n) top mask)))
          (if ((←((pure WVR_match) <&&> (do
               (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGWVR_EL1) n) (mask -i 1) bottom)))))) : Bool)
          then (do (ConstrainUnpredictableBool Unpredictable_WPMASKEDBITS))
          else (do (pure WVR_match))))
    else
      (do sail_assert ((0 ≤b bottom) && ((bottom ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23757.71-23757.72"
          (pure ((Sail.BitVec.extractLsb vaddress top bottom) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGWVR_EL1) n) top bottom))))) ) : SailME Bool Bool )
  (pure (WVR_match && byte_select_match))

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 64 -/
def IsWatchpointEnabled (n : Nat) : SailM Bool := do
  (if ((←((pure (n >b 15)) <&&> (do
       (pure (! (← (HaltOnBreakpointOrWatchpoint ())))) <&&> (do
         (pure (! (← (SelfHostedExtendedBPWPEnabled ()))))) <||> (do
         (HaltOnBreakpointOrWatchpoint ()) <&&> (do
           (pure ((_get_EDSCR2_Type_EHBWE (← (EDSCR2_read ()))) == 0#1))))))) : Bool)
  then (do (pure false))
  else (do (pure ((_get_DBGWCR_EL1_Type_E (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) == 1#1))))

/-- Type quantifiers: n : Nat, size : Int, 0 ≤ n ∧ n < 64 -/
def AArch64_WatchpointMatch (n : Nat) (vaddress : (BitVec 64)) (size : Int) (accdesc : AccessDescriptor) : SailM Bool := do
  sail_assert (! (← (ELUsingAArch32 (← (S1TranslationRegime__1 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23776.61-23776.62"
  sail_assert (n <b (← (NumWatchpointsImplemented ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23777.42-23777.43"
  let enabled ← (( do (IsWatchpointEnabled n) ) : SailM Bool )
  let linked ← (( do (pure ((_get_DBGWCR_EL1_Type_WT (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) == 1#1)) ) : SailM Bool )
  let isbreakpnt : Bool := false
  let lbnx ← (( do
    (if ((← (Havev8p9Debug ())) : Bool)
    then (do (pure (_get_DBGWCR_EL1_Type_LBNX (GetElem?.getElem! (← readReg DBGWCR_EL1) n))))
    else (do (pure 0b00#2))) ) : SailM (BitVec 2) )
  let linked_n ← (( do (pure (BitVec.toNat (lbnx +++ (_get_DBGWCR_EL1_Type_LBN (GetElem?.getElem! (← readReg DBGWCR_EL1) n))))) ) : SailM Int )
  let ssce ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure (_get_DBGWCR_EL1_Type_SSCE (GetElem?.getElem! (← readReg DBGWCR_EL1) n))))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let state_match ← (( do (AArch64_StateMatch (_get_DBGWCR_EL1_Type_SSC (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) ssce (_get_DBGWCR_EL1_Type_HMC (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) (_get_DBGWCR_EL1_Type_PAC (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) linked linked_n isbreakpnt (← (PC_read ())) accdesc) ) : SailM Bool )
  let ls_match ← (( do (undefined_bool ()) ) : SailM Bool )
  let ls_match ← (( do
    match (Sail.BitVec.extractLsb (_get_DBGWCR_EL1_Type_LSC (GetElem?.getElem! (← readReg DBGWCR_EL1) n)) 1 0) with
    | 0b00 => (pure false)
    | 0b01 => (pure accdesc.read)
    | 0b10 => (pure (accdesc.write || (BEq.beq accdesc.acctype AccessType_DC)))
    | 0b11 => (pure true)
    | _ => (pure ls_match) ) : SailM Bool )
  let value_match_name : Bool := false
  let value_match_name ← (( do
    let loop_byte_lower := 0
    let loop_byte_upper := (size -i 1)
    let mut loop_vars := value_match_name
    for byte in [loop_byte_lower:loop_byte_upper:1]i do
      let value_match_name := loop_vars
      loop_vars ← do (pure value_match_name) <||> (do (AArch64_WatchpointByteMatch n (BitVec.addInt vaddress byte)))
    (pure loop_vars) ) : SailM Bool )
  (pure (((value_match_name && state_match) && ls_match) && enabled))

/-- Type quantifiers: size : Int -/
def AArch64_CheckWatchpoint (fault_in : FaultRecord) (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) (size : Int) : SailM FaultRecord := SailME.run do
  let reason ← (( do (undefined_bitvector 6) ) : SailME FaultRecord (BitVec 6) )
  sail_assert (! (← (ELUsingAArch32 (← (S1TranslationRegime__1 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23817.61-23817.62"
  let fault : FaultRecord := fault_in
  (if ((BEq.beq accdesc.acctype AccessType_DC) : Bool)
  then
    (do (if ((bne accdesc.cacheop CacheOp_Invalidate) : Bool)
        then (do SailME.throw (fault : FaultRecord))
        else (do (pure ()))))
  else
    (do (if ((! (IsDataAccess accdesc.acctype)) : Bool)
        then (do SailME.throw (fault : FaultRecord))
        else (do (pure ())))))
  let fault ← (( do
    let loop_i_lower := 0
    let loop_i_upper ← (( do (pure ((← (NumWatchpointsImplemented ())) -i 1)) ) : SailME FaultRecord Int )
    let mut loop_vars := fault
    for i in [loop_i_lower:loop_i_upper:1]i do
      let fault := loop_vars
      loop_vars ← do
        sail_assert (i <b 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:23828.39-23828.40"
        (if ((← (AArch64_WatchpointMatch i vaddress size accdesc)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Debug }
              (if (((((BitVec.access (_get_DBGWCR_EL1_Type_LSC (GetElem?.getElem! (← readReg DBGWCR_EL1) i)) 0) : BitVec 1) == 1#1) && accdesc.read) : Bool)
              then (do (pure { fault with write := false }))
              else
                (do (if (((((BitVec.access (_get_DBGWCR_EL1_Type_LSC (GetElem?.getElem! (← readReg DBGWCR_EL1) i)) 1) : BitVec 1) == 1#1) && accdesc.write) : Bool)
                    then (do (pure { fault with write := true }))
                    else (do (pure fault))))))
        else (do (pure fault)))
    (pure loop_vars) ) : SailME FaultRecord FaultRecord )
  (if ((((←((pure (BEq.beq fault.statuscode Fault_Debug)) <&&> (do
           (HaltOnBreakpointOrWatchpoint ())))) && (! accdesc.nonfault)) && (! (accdesc.firstfault && (! accdesc.first)))) : Bool)
  then
    (do let reason : (BitVec 6) := DebugHalt_Watchpoint
        writeReg EDWAR vaddress
        (Halt reason))
  else (do (pure ())))
  (pure fault)

/-- Type quantifiers: size : Int -/
def AArch64_CheckDebug (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) (size : Int) : SailM FaultRecord := do
  let mask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let generate_exception ← (( do (undefined_bool ()) ) : SailM Bool )
  let d_side : Bool := ((IsDataAccess accdesc.acctype) || (BEq.beq accdesc.acctype AccessType_DC))
  let i_side : Bool := (BEq.beq accdesc.acctype AccessType_IFETCH)
  let generate_exception ← (( do
    (if ((BEq.beq accdesc.acctype AccessType_NV2) : Bool)
    then
      (do let mask : (BitVec 1) := 0#1
          let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
          (AArch64_GenerateDebugExceptionsFrom EL2 ss mask) <&&> (do
            (pure ((_get_MDSCR_EL1_Type_MDE (← readReg MDSCR_EL1)) == 1#1))))
    else (do (AArch64_GenerateDebugExceptions ()) <&&> (do (pure ((_get_MDSCR_EL1_Type_MDE (← readReg MDSCR_EL1)) == 1#1))))) ) : SailM Bool )
  let halt ← (( do (HaltOnBreakpointOrWatchpoint ()) ) : SailM Bool )
  (if ((generate_exception || halt) : Bool)
  then
    (do (if (d_side : Bool)
        then (do (AArch64_CheckWatchpoint fault vaddress accdesc size))
        else
          (do (if (i_side : Bool)
              then (do (AArch64_CheckBreakpoint fault vaddress accdesc size))
              else (do (pure fault))))))
  else (do (pure fault)))

def __GIC_ClearActiveInterrupt (intid : (BitVec 32)) : SailM Unit := do
  match (← readReg __GIC_Active) with
  | .some active_intid =>
    (do
      (if (((__GIC_InterruptID active_intid) == intid) : Bool)
      then (do writeReg __GIC_Active none)
      else (do (pure ()))))
  | _ => (pure ())

def gic_readonly (offset : (BitVec 16)) : Unit :=
  (prerr_bits "[GIC] Write to RO offset: " offset)

def __WriteGIC (offset : (BitVec 16)) (data : (BitVec 32)) : SailM Unit := do
  match offset with
  | 0x1004 => (pure (gic_readonly offset))
  | 0x1100 =>
    (let _ : Unit := (prerr_bits "[GIC] Registering interrupts " data)
    let intID := (HighestSetBit data)
    (pure (prerr_int "[GIC] Registering interrupt " intID)))
  | 0x1800 => (pure (gic_readonly offset))
  | 0x2000 =>
    (do
      let _ : Unit := (prerr_bits "[GIC] GICC_CTLR = " data)
      writeReg GICC_CTLR data)
  | 0x200C => (pure (gic_readonly offset))
  | 0x20FC => (pure (gic_readonly offset))
  | 0x2010 =>
    (do
      let _ : Unit := (prerr_bits "[GIC] End of interrupt = " data)
      (__GIC_ClearActiveInterrupt data))
  | 0x3000 =>
    (do
      let _ : Unit := (prerr_bits "[GIC] Deactivating interrupt " data)
      (__GIC_ClearActiveInterrupt data))
  | _ =>
    (let _ : Unit := (prerr_bits "[GIC] Unknown write offset: " offset)
    (pure (prerr_bits "[GIC] Unknown write data: " data)))

/-- Type quantifiers: n : Nat, n > 0 -/
def __WriteUART (offset : (BitVec 16)) (n : Nat) (data : (BitVec (8 * n))) : Unit :=
  match offset with
  | 0x0000 => (putchar (BitVec.toNat (Sail.BitVec.extractLsb data 7 0)))
  | _ =>
    (let _ : Unit := (prerr_bits "[UART] Unknown write offset: " offset)
    (prerr_bits "[UART] Unknown write data: " data))

/-- Type quantifiers: size : Nat, size > 0 -/
def write_request (accdesc : AccessDescriptor) (ti : (Option TranslationInfo)) (size : Nat) (va : (BitVec 64)) (pa : (BitVec 56)) (value : (BitVec (8 * size))) : (Mem_write_request size 64 (BitVec 56) (Option TranslationInfo) arm_acc_type) :=
  { access_kind := (AccessDescriptor_to_Access_kind accdesc)
    va := (some va)
    pa := pa
    translation := ti
    size := size
    value := (some value)
    tag := none }

/-- Type quantifiers: size : Nat, size > 0 -/
def PhysMemWrite (desc : AddressDescriptor) (size : Nat) (accdesc : AccessDescriptor) (translation_info : (Option TranslationInfo)) (data : (BitVec (8 * size))) : SailM PhysMemRetStatus := do
  let paddress := desc.paddress.address
  (if (((size == 4) && ((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) GIC_BASE))) : Bool)
  then
    (do (__WriteGIC (Sail.BitVec.extractLsb paddress 15 0) data)
        (pure (CreatePhysMemRetStatus Fault_None)))
  else
    (do (if (((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) UART_BASE)) : Bool)
        then
          (do let _ : Unit := (__WriteUART (Sail.BitVec.extractLsb paddress 15 0) size data)
              (pure (CreatePhysMemRetStatus Fault_None)))
        else
          (do match (← (sail_mem_write (write_request accdesc translation_info size desc.vaddress desc.paddress.address data))) with
              | .Ok _ => (pure (CreatePhysMemRetStatus Fault_None))
              | .Err statuscode => (pure (CreatePhysMemRetStatus statuscode))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_MemSwapTableDesc (fault_in : FaultRecord) (prev_desc : (BitVec k_N)) (new_desc : (BitVec k_N)) (ee : (BitVec 1)) (descaccess : AccessDescriptor) (descpaddr : AddressDescriptor) (translation_info : TranslationInfo) : SailM (FaultRecord × (BitVec k_N)) := SailME.run do
  let ordered_new_desc ← (( do (undefined_bitvector (Sail.BitVec.length prev_desc)) ) : SailME (FaultRecord × (BitVec k_N)) (BitVec k_N) )
  let fault : FaultRecord := fault_in
  let iswrite ← (( do (undefined_bool ()) ) : SailME (FaultRecord × (BitVec k_N)) Bool )
  let fault ← (( do
    (if ((← (HaveRME ())) : Bool)
    then
      (do let fault ← (pure { fault with gpcf := (← do (GranuleProtectionCheck descpaddr descaccess)) })
          (if ((bne fault.gpcf.gpf GPCF_None) : Bool)
          then
            (do let a__11109 ← (( do
                  let fault : FaultRecord := { fault with statuscode := Fault_GPCFOnWalk }
                  let fault : FaultRecord := { fault with paddress := descpaddr.paddress }
                  let fault : FaultRecord := { fault with gpcfs2walk := fault.secondstage }
                  (pure (fault, (← (__UNKNOWN_bits (Sail.BitVec.length prev_desc))))) ) : SailME (FaultRecord × (BitVec k_N)) (FaultRecord × (BitVec k_N)) )
                SailME.throw a__11109)
          else (do (pure fault))))
    else (do (pure fault))) ) : SailME (FaultRecord × (BitVec k_N)) FaultRecord )
  let mem_desc ← (( do (undefined_bitvector (Sail.BitVec.length prev_desc)) ) : SailME (FaultRecord × (BitVec k_N)) (BitVec k_N) )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailME (FaultRecord × (BitVec k_N)) PhysMemRetStatus )
  let (mem_desc, memstatus) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead descpaddr (Int.ediv (Sail.BitVec.length prev_desc) 8) descaccess (some translation_info))
    let memstatus : PhysMemRetStatus := tup__0
    let mem_desc : (BitVec k_N) := tup__1
    (pure (mem_desc, memstatus)) ) : SailME (FaultRecord × (BitVec k_N)) ((BitVec k_N) × PhysMemRetStatus) )
  let mem_desc : (BitVec k_N) :=
    if ((ee == 1#1) : Bool)
    then (reverse_endianness mem_desc)
    else mem_desc
  let (fault, iswrite) ← (( do
    (if ((IsFault__2 memstatus) : Bool)
    then
      (do let iswrite : Bool := false
          let fault ← (HandleExternalTTWAbort memstatus iswrite descpaddr descaccess (Int.ediv (Sail.BitVec.length prev_desc) 8) fault)
          (if ((IsFault__1 fault.statuscode) : Bool)
          then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_bits (Sail.BitVec.length prev_desc)))))))
          else (do (pure ())))
          (pure (fault, iswrite)))
    else (do (pure (fault, iswrite)))) ) : SailME (FaultRecord × (BitVec k_N)) (FaultRecord × Bool) )
  let (fault, mem_desc) ← (( do
    (if ((mem_desc == prev_desc) : Bool)
    then
      (do let ordered_new_desc : (BitVec k_N) :=
            if ((ee == 1#1) : Bool)
            then (reverse_endianness new_desc)
            else new_desc
          let memstatus ← (( do (PhysMemWrite descpaddr (Int.ediv (Sail.BitVec.length prev_desc) 8) descaccess (some translation_info) ordered_new_desc) ) : SailME (FaultRecord × (BitVec k_N)) PhysMemRetStatus )
          let fault ← (( do
            (if ((IsFault__2 memstatus) : Bool)
            then
              (do let iswrite : Bool := true
                  let fault ← (HandleExternalTTWAbort memstatus iswrite descpaddr descaccess (Int.ediv (Sail.BitVec.length prev_desc) 8) fault)
                  (if ((IsFault__1 fault.statuscode) : Bool)
                  then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_bits (Sail.BitVec.length prev_desc)))))))
                  else (do (pure ())))
                  (pure fault))
            else (do (pure fault))) ) : SailME (FaultRecord × (BitVec k_N)) FaultRecord )
          let mem_desc : (BitVec k_N) := new_desc
          (pure (fault, mem_desc)))
    else (do (pure (fault, mem_desc)))) ) : SailME (FaultRecord × (BitVec k_N)) (FaultRecord × (BitVec k_N)) )
  (pure (fault, mem_desc))

def AArch64_S1DirectBasePermissions (regime : Regime) (walkstate : TTWState) (walkparams : S1TTWParams) (accdesc : AccessDescriptor) : SailM S1AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let x ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pr ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ur ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let permissions : Permissions := walkstate.permissions
  let s1perms ← (( do (undefined_S1AccessControls ()) ) : SailM S1AccessControls )
  let (pr, pw, px, ur, uw, ux) ← (( do
    (if ((HasUnprivileged regime) : Bool)
    then
      (do let (pr, pw, ur, uw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
            match (Sail.BitVec.extractLsb permissions.ap 2 1) with
            | 0b00 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | 0b01 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | 0b10 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | _ =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
          let (pr, pw, ur, uw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
            match permissions.ap_table with
            | 0b00 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((pr, pw, ur, uw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | 0b01 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((pr, pw, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | 0b10 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((pr, 0#1, ur, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
            | _ =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((pr, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              let ur : (BitVec 1) := tup__2
              let uw : (BitVec 1) := tup__3
              (pr, pw, ur, uw))
          let px : (BitVec 1) := (Complement.complement ((permissions.pxn ||| permissions.pxn_table) ||| uw))
          let ux : (BitVec 1) := (Complement.complement (permissions.uxn ||| permissions.uxn_table))
          let (pr, pw, ux) ← (( do
            (if ((((← (HavePANExt ())) && accdesc.pan) && (! ((BEq.beq regime Regime_EL10) && (walkparams.nv1 == 1#1)))) : Bool)
            then
              (do let ux ← (( do
                    (if (((((← (__IMPDEF_boolean "SCR_EL3.SIF affects EPAN")) && (BEq.beq accdesc.ss SS_Secure)) && (BEq.beq walkstate.baseaddress.paspace PAS_NonSecure)) && (walkparams.sif == 1#1)) : Bool)
                    then (do (pure 0#1))
                    else (do (pure ux))) ) : SailM (BitVec 1) )
                  let ux ← (( do
                    (if (((((← (__IMPDEF_boolean "Realm EL2&0 regime affects EPAN")) && (BEq.beq accdesc.ss SS_Realm)) && (BEq.beq regime Regime_EL20)) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
                    then (do (pure 0#1))
                    else (do (pure ux))) ) : SailM (BitVec 1) )
                  let pan ← (( do (pure ((← readReg PSTATE).PAN &&& ((ur ||| uw) ||| (walkparams.epan &&& ux)))) ) : SailM (BitVec 1) )
                  let pr : (BitVec 1) := (pr &&& (Complement.complement pan))
                  let pw : (BitVec 1) := (pw &&& (Complement.complement pan))
                  (pure (pr, pw, ux)))
            else (do (pure (pr, pw, ux)))) ) : SailM ((BitVec 1) × (BitVec 1) × (BitVec 1)) )
          (pure (pr, pw, px, ur, uw, ux)))
    else
      (do let (pr, pw) : ((BitVec 1) × (BitVec 1)) :=
            match ((BitVec.access permissions.ap 2) : BitVec 1) with
            | 0 =>
              (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              (pr, pw))
            | _ =>
              (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              (pr, pw))
          let (pr, pw) : ((BitVec 1) × (BitVec 1)) :=
            match ((BitVec.access permissions.ap_table 1) : BitVec 1) with
            | 0 =>
              (let (tup__0, tup__1) := ((pr, pw) : ((BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              (pr, pw))
            | _ =>
              (let (tup__0, tup__1) := ((pr, 0#1) : ((BitVec 1) × (BitVec 1)))
              let pr : (BitVec 1) := tup__0
              let pw : (BitVec 1) := tup__1
              (pr, pw))
          let px : (BitVec 1) := (Complement.complement (permissions.xn ||| permissions.xn_table))
          (pure (pr, pw, px, ur, uw, ux)))) ) : SailM ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) )
  let (r, w, x) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1, tup__2) :=
      (if ((accdesc.el == EL0) : Bool)
      then (ur, uw, ux)
      else (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
    let r : (BitVec 1) := tup__0
    let w : (BitVec 1) := tup__1
    let x : (BitVec 1) := tup__2
    (r, w, x)
  let wxn : (BitVec 1) := ((walkparams.wxn &&& w) &&& x)
  let x : (BitVec 1) :=
    if (((BEq.beq accdesc.ss SS_Secure) && (BEq.beq walkstate.baseaddress.paspace PAS_NonSecure)) : Bool)
    then (x &&& (Complement.complement walkparams.sif))
    else x
  let x : (BitVec 1) :=
    if (((BEq.beq accdesc.ss SS_Root) && (bne walkstate.baseaddress.paspace PAS_Root)) : Bool)
    then 0#1
    else x
  let x : (BitVec 1) :=
    if ((((BEq.beq accdesc.ss SS_Realm) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
    then 0#1
    else x
  let x := x
  let s1perms : S1AccessControls := { s1perms with r := r }
  let s1perms : S1AccessControls := { s1perms with w := w }
  let s1perms : S1AccessControls := { s1perms with x := x }
  let s1perms : S1AccessControls := { s1perms with gcs := 0#1 }
  let s1perms : S1AccessControls := { s1perms with wxn := wxn }
  (pure { s1perms with overlay := true })

def AArch64_S1E0POEnabled (regime : Regime) (nv1 : (BitVec 1)) : SailM Bool := do
  sail_assert (HasUnprivileged regime) "sail-arm/arm-v9.4-a/src/v8_base.sail:24025.34-24025.35"
  (if ((! (← (HaveS1POExt ()))) : Bool)
  then (do (pure false))
  else
    (do match regime with
        | .Regime_EL20 => (IsTCR2EL2Enabled ()) <&&> (do (pure ((_get_TCR2_EL2_Type_E0POE (← readReg TCR2_EL2)) == 1#1)))
        | .Regime_EL10 => (pure ((← (IsTCR2EL1Enabled ())) && (nv1 == 0#1))) <&&> (do (pure ((_get_TCR2_EL1_Type_E0POE (← readReg TCR2_EL1)) == 1#1)))
        | _ => (do (undefined_bool ()))))

def AArch64_S1IndirectBasePermissions (regime : Regime) (walkstate : TTWState) (walkparams : S1TTWParams) (accdesc : AccessDescriptor) : SailM S1AccessControls := do
  let gcs ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let overlay ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let wxn ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let x ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pgcs ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pr ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let u_overlay ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ugcs ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ur ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uwxn ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let permissions : Permissions := walkstate.permissions
  let s1perms ← (( do (undefined_S1AccessControls ()) ) : SailM S1AccessControls )
  let (pgcs, pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    match permissions.ppi with
    | 0b0000 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0001 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0010 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0011 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0100 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0101 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0110 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b0111 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1000 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1001 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1010 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1011 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1100 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1101 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | 0b1110 =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
    | _ =>
      (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let pr : (BitVec 1) := tup__0
      let pw : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let pgcs : (BitVec 1) := tup__3
      (pgcs, pr, pw, px))
  let p_overlay : (BitVec 1) := (Complement.complement ((BitVec.access permissions.ppi 3) : BitVec 1))
  let pwxn : (BitVec 1) :=
    if ((permissions.ppi == 0b0110#4) : Bool)
    then 1#1
    else 0#1
  let (pgcs, pr, pw, px, u_overlay, ugcs, ur, uw, uwxn, ux) ← (( do
    (if ((HasUnprivileged regime) : Bool)
    then
      (do let (ugcs, ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
            match permissions.upi with
            | 0b0000 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0001 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0010 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0011 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0100 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0101 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0110 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b0111 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1000 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1001 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1010 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1011 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1100 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1101 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | 0b1110 =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((1#1, 1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
            | _ =>
              (let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (ugcs, ur, uw, ux))
          let u_overlay : (BitVec 1) := (Complement.complement ((BitVec.access permissions.upi 3) : BitVec 1))
          let uwxn : (BitVec 1) :=
            if ((permissions.upi == 0b0110#4) : Bool)
            then 1#1
            else 0#1
          let (pgcs, pr, pw, px, ugcs, ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
            if ((((px == 1#1) || (pgcs == 1#1)) && ((uw == 1#1) || (ugcs == 1#1))) : Bool)
            then
              (let (pgcs, pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
                let pr : (BitVec 1) := tup__0
                let pw : (BitVec 1) := tup__1
                let px : (BitVec 1) := tup__2
                let pgcs : (BitVec 1) := tup__3
                (pgcs, pr, pw, px)
              let (tup__0, tup__1, tup__2, tup__3) := ((0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              let ugcs : (BitVec 1) := tup__3
              (pgcs, pr, pw, px, ugcs, ur, uw, ux))
            else (pgcs, pr, pw, px, ugcs, ur, uw, ux)
          let (pr, pw) ← (( do
            (if ((((← (HavePANExt ())) && accdesc.pan) && (! ((BEq.beq regime Regime_EL10) && (walkparams.nv1 == 1#1)))) : Bool)
            then
              (do let (pr, pw) ← (( do
                    (if ((((← readReg PSTATE).PAN == 1#1) && (permissions.upi != 0b0000#4)) : Bool)
                    then
                      (do let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
                          let pr : (BitVec 1) := tup__0
                          let pw : (BitVec 1) := tup__1
                          (pure (pr, pw)))
                    else (do (pure (pr, pw)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                  (pure (pr, pw)))
            else (do (pure (pr, pw)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
          (pure (pgcs, pr, pw, px, u_overlay, ugcs, ur, uw, uwxn, ux)))
    else (do (pure (pgcs, pr, pw, px, u_overlay, ugcs, ur, uw, uwxn, ux)))) ) : SailM ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) )
  let uwxn := uwxn
  let u_overlay := u_overlay
  let (gcs, overlay, r, w, wxn, x) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    if ((accdesc.el == EL0) : Bool)
    then
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((ur, uw, ux, ugcs, uwxn, u_overlay) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let x : (BitVec 1) := tup__2
      let gcs : (BitVec 1) := tup__3
      let wxn : (BitVec 1) := tup__4
      let overlay : (BitVec 1) := tup__5
      (gcs, overlay, r, w, wxn, x))
    else
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((pr, pw, px, pgcs, pwxn, p_overlay) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let x : (BitVec 1) := tup__2
      let gcs : (BitVec 1) := tup__3
      let wxn : (BitVec 1) := tup__4
      let overlay : (BitVec 1) := tup__5
      (gcs, overlay, r, w, wxn, x))
  let (gcs, x) : ((BitVec 1) × (BitVec 1)) :=
    if (((BEq.beq accdesc.ss SS_Secure) && (BEq.beq walkstate.baseaddress.paspace PAS_NonSecure)) : Bool)
    then
      (let x : (BitVec 1) := (x &&& (Complement.complement walkparams.sif))
      let gcs : (BitVec 1) := 0#1
      (gcs, x))
    else (gcs, x)
  let (gcs, x) : ((BitVec 1) × (BitVec 1)) :=
    if (((BEq.beq accdesc.ss SS_Root) && (bne walkstate.baseaddress.paspace PAS_Root)) : Bool)
    then
      (let x : (BitVec 1) := 0#1
      let gcs : (BitVec 1) := 0#1
      (gcs, x))
    else (gcs, x)
  let (gcs, x) : ((BitVec 1) × (BitVec 1)) :=
    if ((((BEq.beq accdesc.ss SS_Realm) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
    then
      (let x : (BitVec 1) := 0#1
      let gcs : (BitVec 1) := 0#1
      (gcs, x))
    else (gcs, x)
  let x := x
  let gcs := gcs
  let s1perms : S1AccessControls := { s1perms with r := r }
  let s1perms : S1AccessControls := { s1perms with w := w }
  let s1perms : S1AccessControls := { s1perms with x := x }
  let s1perms : S1AccessControls := { s1perms with gcs := gcs }
  let s1perms : S1AccessControls := { s1perms with wxn := wxn }
  (pure { s1perms with overlay := (overlay == 1#1) })

def undefined_POR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_POR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_POR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_POR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_POR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_POR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1POR (regime : Regime) : SailM (BitVec 64) := do
  match regime with
  | .Regime_EL3 => (pure (Mk_S1PORType (← readReg POR_EL3)))
  | .Regime_EL2 => (pure (Mk_S1PORType (← readReg POR_EL2)))
  | .Regime_EL20 => (pure (Mk_S1PORType (← readReg POR_EL2)))
  | .Regime_EL10 => (pure (Mk_S1PORType (← readReg POR_EL1)))
  | _ => (do (undefined_S1PORType ()))

def undefined_POR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_POR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1OverlayPermissions (regime : Regime) (walkstate : TTWState) (accdesc : AccessDescriptor) : SailM S1AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let x ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pr ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let pw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ur ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let permissions : Permissions := walkstate.permissions
  let s1overlay_perms ← (( do (undefined_S1AccessControls ()) ) : SailM S1AccessControls )
  let por ← (( do (AArch64_S1POR regime) ) : SailM S1PORType )
  let bit_index := (4 *i (BitVec.toNat permissions.po_index))
  let ppo : (BitVec 4) := (Sail.BitVec.extractLsb por (bit_index +i 3) bit_index)
  let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    let b__0 := ppo
    let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
      if ((b__0 == (0x0#4 : (BitVec 4))) : Bool)
      then
        (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
        let pr : (BitVec 1) := tup__0
        let pw : (BitVec 1) := tup__1
        let px : (BitVec 1) := tup__2
        (pr, pw, px))
      else
        (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
          if ((b__0 == (0x1#4 : (BitVec 4))) : Bool)
          then
            (let (tup__0, tup__1, tup__2) := ((1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
            let pr : (BitVec 1) := tup__0
            let pw : (BitVec 1) := tup__1
            let px : (BitVec 1) := tup__2
            (pr, pw, px))
          else
            (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
              if ((b__0 == (0x2#4 : (BitVec 4))) : Bool)
              then
                (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                let pr : (BitVec 1) := tup__0
                let pw : (BitVec 1) := tup__1
                let px : (BitVec 1) := tup__2
                (pr, pw, px))
              else
                (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                  if ((b__0 == (0x3#4 : (BitVec 4))) : Bool)
                  then
                    (let (tup__0, tup__1, tup__2) := ((1#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                    let pr : (BitVec 1) := tup__0
                    let pw : (BitVec 1) := tup__1
                    let px : (BitVec 1) := tup__2
                    (pr, pw, px))
                  else
                    (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                      if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                        let pr : (BitVec 1) := tup__0
                        let pw : (BitVec 1) := tup__1
                        let px : (BitVec 1) := tup__2
                        (pr, pw, px))
                      else
                        (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                          if ((b__0 == (0x5#4 : (BitVec 4))) : Bool)
                          then
                            (let (tup__0, tup__1, tup__2) := ((1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                            let pr : (BitVec 1) := tup__0
                            let pw : (BitVec 1) := tup__1
                            let px : (BitVec 1) := tup__2
                            (pr, pw, px))
                          else
                            (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                              if ((b__0 == (0x6#4 : (BitVec 4))) : Bool)
                              then
                                (let (tup__0, tup__1, tup__2) := ((0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                let pr : (BitVec 1) := tup__0
                                let pw : (BitVec 1) := tup__1
                                let px : (BitVec 1) := tup__2
                                (pr, pw, px))
                              else
                                (let (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                                  if ((b__0 == (0x7#4 : (BitVec 4))) : Bool)
                                  then
                                    (let (tup__0, tup__1, tup__2) := ((1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                    let pr : (BitVec 1) := tup__0
                                    let pw : (BitVec 1) := tup__1
                                    let px : (BitVec 1) := tup__2
                                    (pr, pw, px))
                                  else
                                    (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                    let pr : (BitVec 1) := tup__0
                                    let pw : (BitVec 1) := tup__1
                                    let px : (BitVec 1) := tup__2
                                    (pr, pw, px))
                                (pr, pw, px))
                            (pr, pw, px))
                        (pr, pw, px))
                    (pr, pw, px))
                (pr, pw, px))
            (pr, pw, px))
        (pr, pw, px))
    (pr, pw, px)
  let (ur, uw, ux) ← (( do
    (if ((HasUnprivileged regime) : Bool)
    then
      (do let upo ← (( do (pure (Sail.BitVec.extractLsb (← readReg POR_EL0) (bit_index +i 3) bit_index)) ) : SailM (BitVec 4) )
          let b__9 := upo
          let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
            if ((b__9 == (0x0#4 : (BitVec 4))) : Bool)
            then
              (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
              let ur : (BitVec 1) := tup__0
              let uw : (BitVec 1) := tup__1
              let ux : (BitVec 1) := tup__2
              (ur, uw, ux))
            else
              (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                if ((b__9 == (0x1#4 : (BitVec 4))) : Bool)
                then
                  (let (tup__0, tup__1, tup__2) := ((1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                  let ur : (BitVec 1) := tup__0
                  let uw : (BitVec 1) := tup__1
                  let ux : (BitVec 1) := tup__2
                  (ur, uw, ux))
                else
                  (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                    if ((b__9 == (0x2#4 : (BitVec 4))) : Bool)
                    then
                      (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                      let ur : (BitVec 1) := tup__0
                      let uw : (BitVec 1) := tup__1
                      let ux : (BitVec 1) := tup__2
                      (ur, uw, ux))
                    else
                      (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                        if ((b__9 == (0x3#4 : (BitVec 4))) : Bool)
                        then
                          (let (tup__0, tup__1, tup__2) := ((1#1, 0#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                          let ur : (BitVec 1) := tup__0
                          let uw : (BitVec 1) := tup__1
                          let ux : (BitVec 1) := tup__2
                          (ur, uw, ux))
                        else
                          (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                            if ((b__9 == (0x4#4 : (BitVec 4))) : Bool)
                            then
                              (let (tup__0, tup__1, tup__2) := ((0#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                              let ur : (BitVec 1) := tup__0
                              let uw : (BitVec 1) := tup__1
                              let ux : (BitVec 1) := tup__2
                              (ur, uw, ux))
                            else
                              (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                                if ((b__9 == (0x5#4 : (BitVec 4))) : Bool)
                                then
                                  (let (tup__0, tup__1, tup__2) := ((1#1, 1#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                  let ur : (BitVec 1) := tup__0
                                  let uw : (BitVec 1) := tup__1
                                  let ux : (BitVec 1) := tup__2
                                  (ur, uw, ux))
                                else
                                  (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                                    if ((b__9 == (0x6#4 : (BitVec 4))) : Bool)
                                    then
                                      (let (tup__0, tup__1, tup__2) := ((0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                      let ur : (BitVec 1) := tup__0
                                      let uw : (BitVec 1) := tup__1
                                      let ux : (BitVec 1) := tup__2
                                      (ur, uw, ux))
                                    else
                                      (let (ur, uw, ux) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
                                        if ((b__9 == (0x7#4 : (BitVec 4))) : Bool)
                                        then
                                          (let (tup__0, tup__1, tup__2) := ((1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                          let ur : (BitVec 1) := tup__0
                                          let uw : (BitVec 1) := tup__1
                                          let ux : (BitVec 1) := tup__2
                                          (ur, uw, ux))
                                        else
                                          (let (tup__0, tup__1, tup__2) := ((0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
                                          let ur : (BitVec 1) := tup__0
                                          let uw : (BitVec 1) := tup__1
                                          let ux : (BitVec 1) := tup__2
                                          (ur, uw, ux))
                                      (ur, uw, ux))
                                  (ur, uw, ux))
                              (ur, uw, ux))
                          (ur, uw, ux))
                      (ur, uw, ux))
                  (ur, uw, ux))
              (ur, uw, ux))
          (pure (ur, uw, ux)))
    else (do (pure (ur, uw, ux)))) ) : SailM ((BitVec 1) × (BitVec 1) × (BitVec 1)) )
  let (r, w, x) : ((BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1, tup__2) :=
      (if ((accdesc.el == EL0) : Bool)
      then (ur, uw, ux)
      else (pr, pw, px) : ((BitVec 1) × (BitVec 1) × (BitVec 1)))
    let r : (BitVec 1) := tup__0
    let w : (BitVec 1) := tup__1
    let x : (BitVec 1) := tup__2
    (r, w, x)
  let s1overlay_perms : S1AccessControls := { s1overlay_perms with or := r }
  let s1overlay_perms : S1AccessControls := { s1overlay_perms with ow := w }
  (pure { s1overlay_perms with ox := x })

def AArch64_S1POEnabled (regime : Regime) : SailM Bool := do
  (if ((! (← (HaveS1POExt ()))) : Bool)
  then (do (pure false))
  else
    (do match regime with
        | .Regime_EL3 => (pure ((_get_TCR_EL3_Type_POE (← readReg TCR_EL3)) == 1#1))
        | .Regime_EL2 => (IsTCR2EL2Enabled ()) <&&> (do (pure ((_get_TCR2_EL2_Type_POE (← readReg TCR2_EL2)) == 1#1)))
        | .Regime_EL20 => (IsTCR2EL2Enabled ()) <&&> (do (pure ((_get_TCR2_EL2_Type_POE (← readReg TCR2_EL2)) == 1#1)))
        | .Regime_EL10 => (IsTCR2EL1Enabled ()) <&&> (do (pure ((_get_TCR2_EL1_Type_POE (← readReg TCR2_EL1)) == 1#1)))
        | _ => (do (undefined_bool ()))))

def AArch64_S1ComputePermissions (regime : Regime) (walkstate : TTWState) (walkparams : S1TTWParams) (accdesc : AccessDescriptor) : SailM S1AccessControls := do
  let s1overlay_perms ← (( do (undefined_S1AccessControls ()) ) : SailM S1AccessControls )
  let permissions : Permissions := walkstate.permissions
  let s1perms ← (( do (undefined_S1AccessControls ()) ) : SailM S1AccessControls )
  let s1perms ← (( do
    (if ((walkparams.pie == 1#1) : Bool)
    then (do (AArch64_S1IndirectBasePermissions regime walkstate walkparams accdesc))
    else (do (AArch64_S1DirectBasePermissions regime walkstate walkparams accdesc))) ) : SailM S1AccessControls )
  let s1perms ← (( do
    (if ((←((pure (accdesc.el == EL0)) <&&> (do
         (pure (! (← (AArch64_S1E0POEnabled regime walkparams.nv1))))))) : Bool)
    then (do (pure { s1perms with overlay := false }))
    else
      (do (if ((←((pure (accdesc.el != EL0)) <&&> (do
               (pure (! (← (AArch64_S1POEnabled regime))))))) : Bool)
          then (do (pure { s1perms with overlay := false }))
          else (do (pure s1perms))))) ) : SailM S1AccessControls )
  let s1perms ← (( do
    (if (s1perms.overlay : Bool)
    then
      (do let s1overlay_perms ← (( do (AArch64_S1OverlayPermissions regime walkstate accdesc) ) : SailM S1AccessControls )
          let s1perms : S1AccessControls := { s1perms with or := s1overlay_perms.or }
          let s1perms : S1AccessControls := { s1perms with ow := s1overlay_perms.ow }
          (pure { s1perms with ox := s1overlay_perms.ox }))
    else (do (pure s1perms))) ) : SailM S1AccessControls )
  (if (((s1perms.overlay && (s1perms.wxn == 1#1)) && (s1perms.ox == 1#1)) : Bool)
  then (do (pure { s1perms with ow := 0#1 }))
  else
    (do (if ((s1perms.wxn == 1#1) : Bool)
        then (do (pure { s1perms with x := 0#1 }))
        else (do (pure s1perms)))))

def AArch64_S1CheckPermissions (fault_in : FaultRecord) (regime : Regime) (walkstate : TTWState) (walkparams : S1TTWParams) (accdesc : AccessDescriptor) : SailM FaultRecord := do
  let fault : FaultRecord := fault_in
  let permissions : Permissions := walkstate.permissions
  let s1perms ← (( do (AArch64_S1ComputePermissions regime walkstate walkparams accdesc) ) : SailM S1AccessControls )
  (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
  then
    (do (if ((s1perms.overlay && (s1perms.ox == 0#1)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
              (pure { fault with overlay := true }))
        else
          (do (if ((←((pure (BEq.beq walkstate.memattrs.memtype MemType_Device)) <&&> (do
                   (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_INSTRDEVICE)) Constraint_FAULT))))) : Bool)
              then (do (pure { fault with statuscode := Fault_Permission }))
              else
                (do (if ((s1perms.x == 0#1) : Bool)
                    then (do (pure { fault with statuscode := Fault_Permission }))
                    else (do (pure fault))))))))
  else
    (do (if ((BEq.beq accdesc.acctype AccessType_DC) : Bool)
        then
          (do (if ((BEq.beq accdesc.cacheop CacheOp_Invalidate) : Bool)
              then
                (do (if ((s1perms.overlay && (s1perms.ow == 0#1)) : Bool)
                    then
                      (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                          (pure { fault with overlay := true }))
                    else
                      (do (if ((s1perms.w == 0#1) : Bool)
                          then (do (pure { fault with statuscode := Fault_Permission }))
                          else (do (pure fault))))))
              else
                (do (if ((accdesc.el == EL0) : Bool)
                    then
                      (do (if ((s1perms.overlay && (s1perms.or == 0#1)) : Bool)
                          then
                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                (pure { fault with overlay := true }))
                          else
                            (do (if ((((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && s1perms.overlay) && (s1perms.ow == 0#1)) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                      (pure { fault with overlay := true }))
                                else
                                  (do (if ((s1perms.r == 0#1) : Bool)
                                      then (do (pure { fault with statuscode := Fault_Permission }))
                                      else
                                        (do (if (((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && (s1perms.w == 0#1)) : Bool)
                                            then (do (pure { fault with statuscode := Fault_Permission }))
                                            else (do (pure fault))))))))))
                    else (do (pure fault))))))
        else
          (do (if ((BEq.beq accdesc.acctype AccessType_IC) : Bool)
              then
                (do (if ((accdesc.el == EL0) : Bool)
                    then
                      (do (if ((←((pure (s1perms.overlay && (s1perms.or == 0#1))) <&&> (do
                               (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                          then
                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                (pure { fault with overlay := true }))
                          else
                            (do (if ((((walkparams.cmow == 1#1) && s1perms.overlay) && (s1perms.ow == 0#1)) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                      (pure { fault with overlay := true }))
                                else
                                  (do (if ((←((pure (s1perms.r == 0#1)) <&&> (do
                                           (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                                      then (do (pure { fault with statuscode := Fault_Permission }))
                                      else
                                        (do (if (((walkparams.cmow == 1#1) && (s1perms.w == 0#1)) : Bool)
                                            then (do (pure { fault with statuscode := Fault_Permission }))
                                            else (do (pure fault))))))))))
                    else (do (pure fault))))
              else
                (do (if (((← (HaveGCS ())) && (BEq.beq accdesc.acctype AccessType_GCS)) : Bool)
                    then
                      (do (if ((s1perms.gcs == 0#1) : Bool)
                          then (do (pure { fault with statuscode := Fault_Permission }))
                          else
                            (do (if (((accdesc.write && ((walkparams.ha +++ walkparams.hd) != 0b11#2)) && (permissions.ndirty == 1#1)) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                      let fault : FaultRecord := { fault with dirtybit := true }
                                      (pure { fault with write := true }))
                                else (do (pure fault))))))
                    else
                      (do (if (((accdesc.read && s1perms.overlay) && (s1perms.or == 0#1)) : Bool)
                          then
                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                let fault : FaultRecord := { fault with overlay := true }
                                (pure { fault with write := false }))
                          else
                            (do (if (((accdesc.write && s1perms.overlay) && (s1perms.ow == 0#1)) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                      let fault : FaultRecord := { fault with overlay := true }
                                      (pure { fault with write := true }))
                                else
                                  (do (if ((accdesc.read && (s1perms.r == 0#1)) : Bool)
                                      then
                                        (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                            (pure { fault with write := false }))
                                      else
                                        (do (if ((accdesc.write && (s1perms.w == 0#1)) : Bool)
                                            then
                                              (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                  (pure { fault with write := true }))
                                            else
                                              (do (if (((accdesc.write && accdesc.tagaccess) && (BEq.beq walkstate.memattrs.tags MemTag_CanonicallyTagged)) : Bool)
                                                  then
                                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                        let fault : FaultRecord := { fault with write := true }
                                                        (pure { fault with s1tagnotdata := true }))
                                                  else
                                                    (do (if ((((accdesc.write && (! ((walkparams.ha +++ walkparams.hd) == 0b11#2))) && (walkparams.pie == 1#1)) && (permissions.ndirty == 1#1)) : Bool)
                                                        then
                                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                              let fault : FaultRecord := { fault with dirtybit := true }
                                                              (pure { fault with write := true }))
                                                        else (do (pure fault)))))))))))))))))))))

def AArch64_S1DCacheEnabled (regime : Regime) : SailM Bool := do
  match regime with
  | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_C (← readReg SCTLR_EL3)) == 1#1))
  | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_C (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL20 => (pure ((_get_SCTLR_EL2_Type_C (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL10 => (pure ((_get_SCTLR_EL1_Type_C (← readReg SCTLR_EL1)) == 1#1))
  | _ => (do (undefined_bool ()))

def AArch64_AddrTop (tbid : (BitVec 1)) (acctype : AccessType) (tbi : (BitVec 1)) : Int :=
  if (((tbid == 1#1) && (BEq.beq acctype AccessType_IFETCH)) : Bool)
  then 63
  else
    (if ((tbi == 1#1) : Bool)
    then 55
    else 63)

def undefined_MECID_P0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MECID_P0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MECID_P0_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MECID_A0_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MECID_A1_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MECID_P1_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MECID_RL_A_EL3_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_VMECID_A_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_VMECID_P_EL2_Type_MECID (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def undefined_VMECID_P_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VMECID_P_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1DisabledOutputMECID (walkparams : S1TTWParams) (regime : Regime) (paspace : PASpace) : SailM (BitVec 16) := do
  (if ((walkparams.emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((! ((BEq.beq regime Regime_EL2) || ((BEq.beq regime Regime_EL20) || (BEq.beq regime Regime_EL10)))) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do (if ((bne paspace PAS_Realm) : Bool)
              then (do (pure DEFAULT_MECID))
              else
                (do (if ((BEq.beq regime Regime_EL10) : Bool)
                    then (do (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2))))
                    else (do (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2)))))))))))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S1HasAlignmentFault (accdesc : AccessDescriptor) (aligned : Bool) (ntlsmd : (BitVec 1)) (memattrs : MemoryAttributes) : SailM Bool := do
  (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
  then (do (pure false))
  else
    (do (if ((((← (HaveMTEExt ())) && accdesc.tagaccess) && accdesc.write) : Bool)
        then (do (pure (BEq.beq memattrs.memtype MemType_Device)) <&&> (do (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_DEVICETAGSTORE)) Constraint_FAULT))))
        else
          (do (if ((accdesc.a32lsmd && (ntlsmd == 0#1)) : Bool)
              then (do (pure ((BEq.beq memattrs.memtype MemType_Device) && (bne memattrs.device DeviceType_GRE))))
              else
                (do (if ((BEq.beq accdesc.acctype AccessType_DCZero) : Bool)
                    then (do (pure (BEq.beq memattrs.memtype MemType_Device)))
                    else (do (pure ((BEq.beq memattrs.memtype MemType_Device) && (! aligned)))))))))))

def AArch64_S1ICacheEnabled (regime : Regime) : SailM Bool := do
  match regime with
  | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_I (← readReg SCTLR_EL3)) == 1#1))
  | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_I (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL20 => (pure ((_get_SCTLR_EL2_Type_I (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL10 => (pure ((_get_SCTLR_EL1_Type_I (← readReg SCTLR_EL1)) == 1#1))
  | _ => (do (undefined_bool ()))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S1DisabledOutput (fault_in : FaultRecord) (regime : Regime) (va_in : (BitVec 64)) (accdesc : AccessDescriptor) (aligned : Bool) : SailM (FaultRecord × AddressDescriptor) := do
  let ipa ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let va : (BitVec 64) := va_in
  let walkparams ← (( do (AArch64_GetS1TTWParams regime accdesc.ss va) ) : SailM S1TTWParams )
  let fault : FaultRecord := fault_in
  (SetInGuardedPage false)
  let oa ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let oa : FullAddress := { oa with address := (Sail.BitVec.extractLsb va 55 0) }
  let oa : FullAddress :=
    match accdesc.ss with
    | .SS_Secure => { oa with paspace := PAS_Secure }
    | .SS_NonSecure => { oa with paspace := PAS_NonSecure }
    | .SS_Root => { oa with paspace := PAS_Root }
    | .SS_Realm => { oa with paspace := PAS_Realm }
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let (memattrs, va) ← (( do
    (if (((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
           (EL2Enabled ())))) && (walkparams.dc == 1#1)) : Bool)
    then
      (do let default_cacheability ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
          let default_cacheability : MemAttrHints := { default_cacheability with attrs := MemAttr_WB }
          let default_cacheability : MemAttrHints := { default_cacheability with hints := MemHint_RWA }
          let default_cacheability : MemAttrHints := { default_cacheability with transient := false }
          let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
          let memattrs : MemoryAttributes := { memattrs with outer := default_cacheability }
          let memattrs : MemoryAttributes := { memattrs with inner := default_cacheability }
          let memattrs : MemoryAttributes := { memattrs with shareability := Shareability_NSH }
          let (memattrs, va) : (MemoryAttributes × (BitVec 64)) :=
            if ((walkparams.dct == 1#1) : Bool)
            then
              (let memattrs : MemoryAttributes := { memattrs with tags := MemTag_AllocationTagged }
              (memattrs, va))
            else
              (let (memattrs, va) : (MemoryAttributes × (BitVec 64)) :=
                if ((walkparams.mtx == 1#1) : Bool)
                then
                  (let memattrs : MemoryAttributes := { memattrs with tags := MemTag_CanonicallyTagged }
                  let va : (BitVec 64) :=
                    if ((walkparams.tbi == 0#1) : Bool)
                    then (Sail.BitVec.updateSubrange va 59 56 (BitVec.replicateBits ((BitVec.access va 55) : BitVec 1) 4))
                    else va
                  (memattrs, va))
                else
                  (let memattrs : MemoryAttributes := { memattrs with tags := MemTag_Untagged }
                  (memattrs, va))
              (memattrs, va))
          let memattrs : MemoryAttributes := { memattrs with xs := 0#1 }
          (pure (memattrs, va)))
    else
      (do let (memattrs, va) ← (( do
            (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
            then
              (do let i_cache_attr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
                  let i_cache_attr ← (( do
                    (if ((← (AArch64_S1ICacheEnabled regime)) : Bool)
                    then
                      (do let i_cache_attr : MemAttrHints := { i_cache_attr with attrs := MemAttr_WT }
                          let i_cache_attr : MemAttrHints := { i_cache_attr with hints := MemHint_RA }
                          (pure { i_cache_attr with transient := false }))
                    else (do (pure { i_cache_attr with attrs := MemAttr_NC }))) ) : SailM MemAttrHints )
                  let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                  let memattrs : MemoryAttributes := { memattrs with outer := i_cache_attr }
                  let memattrs : MemoryAttributes := { memattrs with inner := i_cache_attr }
                  let memattrs : MemoryAttributes := { memattrs with shareability := Shareability_OSH }
                  let memattrs : MemoryAttributes :=
                    if ((walkparams.mtx == 1#1) : Bool)
                    then { memattrs with tags := MemTag_CanonicallyTagged }
                    else { memattrs with tags := MemTag_Untagged }
                  let memattrs : MemoryAttributes := { memattrs with xs := 1#1 }
                  (pure (memattrs, va)))
            else
              (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
                  let memattrs : MemoryAttributes := { memattrs with device := DeviceType_nGnRnE }
                  let memattrs : MemoryAttributes := { memattrs with shareability := Shareability_OSH }
                  let (memattrs, va) : (MemoryAttributes × (BitVec 64)) :=
                    if ((walkparams.mtx == 1#1) : Bool)
                    then
                      (let memattrs : MemoryAttributes := { memattrs with tags := MemTag_CanonicallyTagged }
                      let va : (BitVec 64) :=
                        if ((walkparams.tbi == 0#1) : Bool)
                        then
                          (if ((HasUnprivileged regime) : Bool)
                          then (Sail.BitVec.updateSubrange va 59 56 (BitVec.replicateBits ((BitVec.access va 55) : BitVec 1) 4))
                          else (Sail.BitVec.updateSubrange va 59 56 0b0000#4))
                        else va
                      (memattrs, va))
                    else
                      (let memattrs : MemoryAttributes := { memattrs with tags := MemTag_Untagged }
                      (memattrs, va))
                  let memattrs : MemoryAttributes := { memattrs with xs := 1#1 }
                  (pure (memattrs, va)))) ) : SailM (MemoryAttributes × (BitVec 64)) )
          (pure (memattrs, va)))) ) : SailM (MemoryAttributes × (BitVec 64)) )
  let memattrs : MemoryAttributes := { memattrs with notagaccess := false }
  let fault : FaultRecord := { fault with level := 0 }
  let addrtop := (AArch64_AddrTop walkparams.tbid accdesc.acctype walkparams.tbi)
  let fault ← (( do
    (if ((! (is_zero_subrange va addrtop (← (AArch64_PAMax ())))) : Bool)
    then (do (pure { fault with statuscode := Fault_AddressSize }))
    else
      (do (if ((← (AArch64_S1HasAlignmentFault accdesc aligned walkparams.ntlsmd memattrs)) : Bool)
          then (do (pure { fault with statuscode := Fault_Alignment }))
          else (do (pure fault))))) ) : SailM FaultRecord )
  (if ((bne fault.statuscode Fault_None) : Bool)
  then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
  else
    (do let ipa ← (( (CreateAddressDescriptor va_in oa memattrs) ) : SailM AddressDescriptor )
        let ipa ← (pure { ipa with mecid := (← do (AArch64_S1DisabledOutputMECID walkparams regime ipa.paddress.paspace)) })
        (pure (fault, ipa))))

def AArch64_S1Enabled (regime : Regime) (acctype : AccessType) : SailM Bool := do
  match regime with
  | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_M (← readReg SCTLR_EL3)) == 1#1))
  | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_M (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL20 => (pure ((_get_SCTLR_EL2_Type_M (← readReg SCTLR_EL2)) == 1#1))
  | .Regime_EL10 => (pure (! (← (EL2Enabled ())))) <||> (do (pure (((_get_HCR_EL2_Type_DC (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b00#2))) <&&> (do (pure ((_get_SCTLR_EL1_Type_M (← readReg SCTLR_EL1)) == 1#1)))
  | _ => (do (undefined_bool ()))

def undefined_MECID_A0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MECID_A0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MECID_A1_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MECID_A1_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MECID_P1_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MECID_P1_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MECID_RL_A_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MECID_RL_A_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_S1OutputMECID (walkparams : S1TTWParams) (regime : Regime) (varange : VARange) (paspace : PASpace) (descriptor : (BitVec k_N)) : SailM (BitVec 16) := do
  sail_assert (((Sail.BitVec.length descriptor) == 64) || ((Sail.BitVec.length descriptor) == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24790.31-24790.32"
  (if ((walkparams.emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((bne paspace PAS_Realm) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do let descriptor_amec ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (103 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24798.35-24798.36"
                      (pure ((BitVec.access descriptor 103) : BitVec 1)))
                else (do (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
              match regime with
              | .Regime_EL3 => (pure (_get_MECID_RL_A_EL3_Type_MECID (← readReg MECID_RL_A_EL3)))
              | .Regime_EL2 =>
                (do
                  (if ((descriptor_amec == 0#1) : Bool)
                  then (do (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2))))
                  else (do (pure (_get_MECID_A0_EL2_Type_MECID (← readReg MECID_A0_EL2))))))
              | .Regime_EL20 =>
                (do
                  (if ((BEq.beq varange VARange_LOWER) : Bool)
                  then
                    (do (if ((descriptor_amec == 0#1) : Bool)
                        then (do (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2))))
                        else (do (pure (_get_MECID_A0_EL2_Type_MECID (← readReg MECID_A0_EL2))))))
                  else
                    (do (if ((descriptor_amec == 0#1) : Bool)
                        then (do (pure (_get_MECID_P1_EL2_Type_MECID (← readReg MECID_P1_EL2))))
                        else (do (pure (_get_MECID_A1_EL2_Type_MECID (← readReg MECID_A1_EL2))))))))
              | .Regime_EL10 => (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2)))
              | _ => (do (undefined_bitvector 16))))))

def AArch64_BlockBBMSupportLevel (_ : Unit) : SailM Int := do
  (if ((! (← (HaveBlockBBM ()))) : Bool)
  then (do (__UNKNOWN_integer ()))
  else (do (__IMPDEF_integer "Block BBM support level")))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_BlocknTFaults (d128 : (BitVec 1)) (descriptor : (BitVec k_N)) : SailM Bool := do
  (if ((! (← (HaveBlockBBM ()))) : Bool)
  then (do (pure false))
  else
    (do let nT ← (( do
          (if ((d128 == 1#1) : Bool)
          then
            (do sail_assert (6 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24853.33-24853.34"
                (pure ((BitVec.access descriptor 6) : BitVec 1)))
          else
            (do sail_assert (16 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24856.34-24856.35"
                (pure ((BitVec.access descriptor 16) : BitVec 1)))) ) : SailM (BitVec 1) )
        let bbm_level ← (( do (AArch64_BlockBBMSupportLevel ()) ) : SailM Int )
        let nT_faults ← (( do (__IMPDEF_boolean "BBM level 1 or 2 support nT bit causes Translation Fault") ) : SailM Bool )
        (pure ((((bbm_level == 1) || (bbm_level == 2)) && (nT == 1#1)) && nT_faults))))

def AArch64_IASize (txsz : (BitVec 6)) : Int :=
  (64 -i (BitVec.toNat txsz))

/-- Type quantifiers: level : Int -/
def AArch64_ContiguousBitFaults (d128 : (BitVec 1)) (txsz : (BitVec 6)) (tgx : TGx) (level : Int) : SailM Bool := do
  let iasize := (AArch64_IASize txsz)
  let tsize ← (( do (pure ((TranslationSize d128 tgx level) +i (← (ContiguousSize d128 tgx level)))) ) : SailM Int )
  (pure (tsize >b iasize)) <&&> (do
    (__IMPDEF_boolean "Translation fault on misprogrammed contiguous bit"))

/-- Type quantifiers: level : Int -/
def AArch64_BlockDescSupported (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (level : Int) : SailM Bool := SailME.run do
  SailME.throw (← do
      match tgx with
      | .TGx_4KB => (pure ((((level == 0) && ((ds == 1#1) || (d128 == 1#1))) || (level == 1)) || (level == 2)))
      | .TGx_16KB => (pure (((level == 1) && ((ds == 1#1) || (d128 == 1#1))) || (level == 2)))
      | .TGx_64KB => (pure ((←((pure (level == 1)) <&&> (do (pure (d128 == 1#1)) <||> (do (pure ((← (AArch64_PAMax ())) ≥b 52)))))) || (level == 2))))
  (pure false)

/-- Type quantifiers: k_N : Nat, level : Int, 0 < k_N -/
def AArch64_DecodeDescriptorType (descriptor : (BitVec k_N)) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (level : Int) : SailM DescriptorType := do
  (if ((((BitVec.access descriptor 0) : BitVec 1) == 0#1) : Bool)
  then (do (pure DescriptorType_Invalid))
  else
    (do (if ((d128 == 1#1) : Bool)
        then
          (do sail_assert (110 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24904.35-24904.36"
              let skl : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 110 109)
              (if ((((BEq.beq tgx TGx_16KB) || (BEq.beq tgx TGx_64KB)) && (((BitVec.toNat skl) == 3) : Bool)) : Bool)
              then (do (pure DescriptorType_Invalid))
              else
                (do let effective_level := (level +i (BitVec.toNat skl))
                    (if ((effective_level >b FINAL_LEVEL) : Bool)
                    then (do (pure DescriptorType_Invalid))
                    else
                      (do (if ((effective_level == FINAL_LEVEL) : Bool)
                          then (do (pure DescriptorType_Leaf))
                          else (do (pure DescriptorType_Table))))))))
        else
          (do sail_assert (1 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:24918.33-24918.34"
              (if ((((BitVec.access descriptor 1) : BitVec 1) == 1#1) : Bool)
              then
                (do (if ((level == FINAL_LEVEL) : Bool)
                    then (do (pure DescriptorType_Leaf))
                    else (do (pure DescriptorType_Table))))
              else
                (do (if ((((BitVec.access descriptor 1) : BitVec 1) == 0#1) : Bool)
                    then
                      (do (if ((← (AArch64_BlockDescSupported d128 ds tgx level)) : Bool)
                          then (do (pure DescriptorType_Leaf))
                          else (do (pure DescriptorType_Invalid))))
                    else (do (undefined_DescriptorType ())))))))))

def VMID_read (_ : Unit) : SailM (BitVec 16) := do
  (if ((← (EL2Enabled ())) : Bool)
  then
    (do (if ((! (← (ELUsingAArch32 EL2))) : Bool)
        then
          (do (if ((←((Have16bitVMID ()) <&&> (do
                   (pure ((_get_VTCR_EL2_Type_VS (← readReg VTCR_EL2)) == 1#1))))) : Bool)
              then (do (pure (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ())))))
              else (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ()))) 7 0) 16)))))
        else (do (pure (Sail.BitVec.zeroExtend (_get_VTTBR_Type_VMID (← readReg VTTBR)) 16)))))
  else
    (do (if ((←((pure (HaveEL EL2)) <&&> (do
             (HaveSecureEL2Ext ())))) : Bool)
        then (do (pure (Zeros (n := 16))))
        else (do (pure VMID_NONE)))))

def AArch64_TLBContextEL10 (ss : SecurityState) (va : (BitVec 64)) (tg : TGx) : SailM TLBContext := do
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL10 }
  let tlbcontext ← (pure { tlbcontext with vmid := (← do (VMID_read ())) })
  let tlbcontext ←
    (pure { tlbcontext with asid := (← do
        (if (((_get_TCR_EL1_Type_A1 (← readReg TCR_EL1)) == 0#1) : Bool)
        then (do (pure (_get_TTBR0_EL1_Type_ASID (← (TTBR0_EL1_read ())))))
        else (do (pure (_get_TTBR1_EL1_Type_ASID (← (TTBR1_EL1_read ()))))))) })
  let tlbcontext ← (( do
    (if (((_get_TCR_EL1_Type_AS (← readReg TCR_EL1)) == 0#1) : Bool)
    then (do (pure { tlbcontext with asid := (Sail.BitVec.updateSubrange tlbcontext.asid 15 8 (Zeros (n := 8))) }))
    else (do (pure tlbcontext))) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := va }
  (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
  then
    (do (if ((BEq.beq (AArch64_GetVARange va) VARange_LOWER) : Bool)
        then (do (pure { tlbcontext with cnp := (← do (pure (_get_TTBR0_EL1_Type_CnP (← (TTBR0_EL1_read ()))))) }))
        else (do (pure { tlbcontext with cnp := (← do (pure (_get_TTBR1_EL1_Type_CnP (← (TTBR1_EL1_read ()))))) }))))
  else (do (pure { tlbcontext with cnp := 0#1 })))

def AArch64_TLBContextEL2 (ss : SecurityState) (va : (BitVec 64)) (tg : TGx) : SailM TLBContext := do
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL2 }
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := va }
  (pure { tlbcontext with cnp := (← do
      (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
      then (do (pure (_get_TTBR0_EL2_Type_CnP (← (TTBR0_EL2_read ())))))
      else (do (pure 0#1)))) })

def AArch64_TLBContextEL20 (ss : SecurityState) (va : (BitVec 64)) (tg : TGx) : SailM TLBContext := do
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL20 }
  let tlbcontext ←
    (pure { tlbcontext with asid := (← do
        (if (((_get_TCR_EL2_Type_A1 (← readReg TCR_EL2)) == 0#1) : Bool)
        then (do (pure (_get_TTBR0_EL2_Type_ASID (← (TTBR0_EL2_read ())))))
        else (do (pure (_get_TTBR1_EL2_Type_ASID (← readReg TTBR1_EL2)))))) })
  let tlbcontext ← (( do
    (if (((_get_TCR_EL2_Type_AS (← readReg TCR_EL2)) == 0#1) : Bool)
    then (do (pure { tlbcontext with asid := (Sail.BitVec.updateSubrange tlbcontext.asid 15 8 (Zeros (n := 8))) }))
    else (do (pure tlbcontext))) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := va }
  (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
  then
    (do (if ((BEq.beq (AArch64_GetVARange va) VARange_LOWER) : Bool)
        then (do (pure { tlbcontext with cnp := (← do (pure (_get_TTBR0_EL2_Type_CnP (← (TTBR0_EL2_read ()))))) }))
        else (do (pure { tlbcontext with cnp := (← do (pure (_get_TTBR1_EL2_Type_CnP (← readReg TTBR1_EL2)))) }))))
  else (do (pure { tlbcontext with cnp := 0#1 })))

def AArch64_TLBContextEL3 (ss : SecurityState) (va : (BitVec 64)) (tg : TGx) : SailM TLBContext := do
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL3 }
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := va }
  (pure { tlbcontext with cnp := (← do
      (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
      then (do (pure (_get_TTBR0_EL3_Type_CnP (← readReg TTBR0_EL3))))
      else (do (pure 0#1)))) })

def AArch64_GetS1TLBContext (regime : Regime) (ss : SecurityState) (va : (BitVec 64)) (tg : TGx) : SailM TLBContext := do
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext ← (( do
    match regime with
    | .Regime_EL3 => (do (AArch64_TLBContextEL3 ss va tg))
    | .Regime_EL2 => (do (AArch64_TLBContextEL2 ss va tg))
    | .Regime_EL20 => (do (AArch64_TLBContextEL20 ss va tg))
    | .Regime_EL10 => (do (AArch64_TLBContextEL10 ss va tg))
    | _ => (pure tlbcontext) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with includes_s1_name := true }
  let tlbcontext : TLBContext := { tlbcontext with includes_s2_name := false }
  (pure { tlbcontext with includes_gpt_name := false })

/-- Type quantifiers: size : Int -/
def AArch64_GetTranslationStartInfo (regime : Regime) (ss : SecurityState) (accdesc : AccessDescriptor) (va : (BitVec 64)) (size : Int) : SailM TranslationStartInfo := do
  let tlbcontext ← (( do (AArch64_GetS1TLBContext regime ss va (← (undefined_TGx ()))) ) : SailM TLBContext )
  (pure { ss := ss
          regime := regime
          vmid := tlbcontext.vmid
          asid := tlbcontext.asid
          va := va
          cnp := tlbcontext.cnp
          accdesc := accdesc
          size := size })

def AArch64_PhysicalAddressSize (d128 : (BitVec 1)) (encoded_ps : (BitVec 3)) (tgx : TGx) : SailM Int := do
  let ps : Int := 32
  let max_ps ← (( do (undefined_int ()) ) : SailM Int )
  let ps : Int :=
    match encoded_ps with
    | 0b000 => 32
    | 0b001 => 36
    | 0b010 => 40
    | 0b011 => 42
    | 0b100 => 44
    | 0b101 => 48
    | 0b110 => 52
    | _ => 56
  let ps := ps
  let max_ps ← (( do
    (if (((! (← (Have56BitPAExt ()))) || (d128 == 0#1)) : Bool)
    then
      (do (if ((←((pure (bne tgx TGx_64KB)) <&&> (do
               (pure (! (← (Have52BitIPAAndPASpaceExt ()))))))) : Bool)
          then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
          else
            (do (if ((! (← (Have52BitPAExt ()))) : Bool)
                then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
                else (do (pure (Min.min 52 (← (AArch64_PAMax ())))))))))
    else (do (AArch64_PAMax ()))) ) : SailM Int )
  let max_ps := max_ps
  (pure (Min.min ps max_ps))

def AArch64_OAOutOfRange (address : (BitVec 56)) (d128 : (BitVec 1)) (ps : (BitVec 3)) (tgx : TGx) : SailM Bool := do
  let oasize ← (( do (AArch64_PhysicalAddressSize d128 ps tgx) ) : SailM Int )
  (if ((oasize <b 56) : Bool)
  then (do (pure (! (is_zero_subrange address 55 oasize))))
  else (do (pure false)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_S1AMECFault (walkparams : S1TTWParams) (paspace : PASpace) (regime : Regime) (descriptor : (BitVec k_N)) : SailM Bool := do
  sail_assert (((Sail.BitVec.length descriptor) == 64) || ((Sail.BitVec.length descriptor) == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25140.31-25140.32"
  let descriptor_amec ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (103 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25142.35-25142.36"
          (pure ((BitVec.access descriptor 103) : BitVec 1)))
    else (do (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
  (pure (((((walkparams.emec +++ walkparams.amec) == 0b10#2) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) && (BEq.beq paspace PAS_Realm)) && (descriptor_amec == 1#1)))

def AArch64_S1EPD (regime : Regime) (va : (BitVec 64)) : SailM (BitVec 1) := do
  sail_assert (HasUnprivileged regime) "sail-arm/arm-v9.4-a/src/v8_base.sail:25151.34-25151.35"
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL20 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (_get_TCR_EL2_Type_EPD0 (← readReg TCR_EL2))))
      else (do (pure (_get_TCR_EL2_Type_EPD1 (← readReg TCR_EL2))))))
  | .Regime_EL10 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (_get_TCR_EL1_Type_EPD0 (← readReg TCR_EL1))))
      else (do (pure (_get_TCR_EL1_Type_EPD1 (← readReg TCR_EL1))))))
  | _ => (do (undefined_bitvector 1))

def AArch64_S1StartLevel (walkparams : S1TTWParams) : Int :=
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let s1startlevel : Int := (FINAL_LEVEL -i (fdiv_int ((iasize -i 1) -i granulebits) stride))
  let s1startlevel : Int :=
    if ((walkparams.d128 == 1#1) : Bool)
    then (s1startlevel +i (BitVec.toNat walkparams.skl))
    else s1startlevel
  let s1startlevel := s1startlevel
  s1startlevel

def AArch64_S1TTBR (regime : Regime) (va : (BitVec 64)) : SailM (BitVec 128) := do
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL3 => (pure (Sail.BitVec.zeroExtend (← readReg TTBR0_EL3) 128))
  | .Regime_EL2 => (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL2_read ())) 128))
  | .Regime_EL20 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL2_read ())) 128)))
      else (do (pure (Sail.BitVec.zeroExtend (← readReg TTBR1_EL2) 128)))))
  | .Regime_EL10 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL1_read ())) 128)))
      else (do (pure (Sail.BitVec.zeroExtend (← (TTBR1_EL1_read ())) 128)))))
  | _ => (do (undefined_bitvector 128))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1TTBaseAddress (walkparams : S1TTWParams) (regime : Regime) (ttbr : (BitVec k_N)) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let startlevel := (AArch64_S1StartLevel walkparams)
  let levels := (FINAL_LEVEL -i startlevel)
  let tsize : Int := ((iasize -i ((levels *i stride) +i granulebits)) +i descsizelog2)
  let (tablebase, tsize) ← (( do
    (if (((← (Have56BitPAExt ())) && (walkparams.d128 == 1#1)) : Bool)
    then
      (do let tsize : Int := (Max.max tsize 5)
          let tablebase ← (( do
            (if ((BEq.beq regime Regime_EL3) : Bool)
            then
              (do sail_assert (55 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25229.38-25229.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 (Sail.BitVec.extractLsb ttbr 55 5))))
            else
              (do sail_assert (87 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25232.38-25232.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 ((Sail.BitVec.extractLsb ttbr 87 80) +++ (Sail.BitVec.extractLsb ttbr 47 5)))))) ) : SailM (BitVec 56) )
          (pure (tablebase, tsize)))
    else
      (do let (tablebase, tsize) ← (( do
            (if (((((← (Have52BitPAExt ())) && (BEq.beq walkparams.tgx TGx_64KB)) && (walkparams.ps == 0b110#3)) || (walkparams.ds == 1#1)) : Bool)
            then
              (do let tsize : Int := (Max.max tsize 6)
                  sail_assert (5 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25237.33-25237.34"
                  sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25238.34-25238.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 51 6 ((Sail.BitVec.extractLsb ttbr 5 2) +++ (Sail.BitVec.extractLsb ttbr 47 6)))
                  (pure (tablebase, tsize)))
            else
              (do sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25241.34-25241.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 47 1 (Sail.BitVec.extractLsb ttbr 47 1))
                  (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
          (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
  let tsize := tsize
  (pure (Align_bits tablebase (_shl_int_general 1 tsize)))

def AArch64_S1InitialTTWState (walkparams : S1TTWParams) (va : (BitVec 64)) (regime : Regime) (ss : SecurityState) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let permissions ← (( do (undefined_Permissions ()) ) : SailM Permissions )
  let ttbr ← (( do (AArch64_S1TTBR regime va) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    match ss with
    | .SS_Secure => { tablebase with paspace := PAS_Secure }
    | .SS_NonSecure => { tablebase with paspace := PAS_NonSecure }
    | .SS_Root => { tablebase with paspace := PAS_Root }
    | .SS_Realm => { tablebase with paspace := PAS_Realm }
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S1TTBaseAddress walkparams regime ttbr)) })
  let permissions : Permissions := { permissions with ap_table := 0b00#2 }
  let permissions : Permissions :=
    if ((HasUnprivileged regime) : Bool)
    then
      (let permissions : Permissions := { permissions with uxn_table := 0#1 }
      { permissions with pxn_table := 0#1 })
    else { permissions with xn_table := 0#1 }
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate : TTWState := { walkstate with level := (AArch64_S1StartLevel walkparams) }
  let walkstate : TTWState := { walkstate with istable := true }
  let walkstate : TTWState :=
    { walkstate with nG := if ((HasUnprivileged regime) : Bool)
      then 1#1
      else 0#1 }
  let walkstate ← (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })
  let walkstate : TTWState := { walkstate with permissions := permissions }
  let walkstate : TTWState :=
    if (((walkparams.d128 == 1#1) || (walkparams.pnch == 1#1)) : Bool)
    then { walkstate with s1assured := true }
    else { walkstate with s1assured := false }
  (pure { walkstate with disch := walkparams.disch })

/-- Type quantifiers: k_N : Nat, level : Int, 52 < k_N -/
def AArch64_ContiguousBit (tgx : TGx) (d128 : (BitVec 1)) (level : Int) (descriptor : (BitVec k_N)) : SailM (BitVec 1) := do
  (if ((d128 == 1#1) : Bool)
  then
    (do (if ((((BEq.beq tgx TGx_64KB) && (level == 1)) || ((BEq.beq tgx TGx_4KB) && (level == 0))) : Bool)
        then (do (pure 0#1))
        else
          (do sail_assert (111 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25301.39-25301.40"
              (pure ((BitVec.access descriptor 111) : BitVec 1)))))
  else
    (do (if (((BEq.beq tgx TGx_64KB) && (level == 1)) : Bool)
        then (do (pure 0#1))
        else
          (do (if (((BEq.beq tgx TGx_16KB) && (level == 1)) : Bool)
              then (do (pure 0#1))
              else
                (do (if (((BEq.beq tgx TGx_4KB) && (level == 0)) : Bool)
                    then (do (pure 0#1))
                    else (do (pure ((BitVec.access descriptor 52) : BitVec 1))))))))))

/-- Type quantifiers: k_N : Nat, level : Int, k_N ≥ 0 -/
def AArch64_LeafBase (descriptor : (BitVec k_N)) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (level : Int) : SailM (BitVec 56) := do
  let leafbase : (BitVec 56) := (Zeros (n := 56))
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let leafsize := (granulebits +i (stride *i (FINAL_LEVEL -i level)))
  sail_assert ((0 ≤b leafsize) && ((leafsize ≤b 47) && (47 <b (Sail.BitVec.length descriptor)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25326.67-25326.68"
  let leafbase : (BitVec 56) := (Sail.BitVec.updateSubrange leafbase 47 0 ((Sail.BitVec.extractLsb descriptor 47 leafsize) +++ (Zeros (n := leafsize))))
  (if (((← (Have56BitPAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25329.34-25329.35"
        (pure (Sail.BitVec.updateSubrange leafbase 55 48 (Sail.BitVec.extractLsb descriptor 55 48))))
  else
    (do (if (((← (Have52BitPAExt ())) && (BEq.beq tgx TGx_64KB)) : Bool)
        then (do (pure (Sail.BitVec.updateSubrange leafbase 51 48 (Sail.BitVec.extractLsb descriptor 15 12))))
        else
          (do (if ((ds == 1#1) : Bool)
              then
                (do sail_assert (49 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25336.34-25336.35"
                    (pure (Sail.BitVec.updateSubrange leafbase 51 48 ((Sail.BitVec.extractLsb descriptor 9 8) +++ (Sail.BitVec.extractLsb descriptor 49 48)))))
              else (do (pure leafbase)))))))

/-- Type quantifiers: index : Int -/
def AArch64_MAIRAttr (index : Int) (mair2 : (BitVec 64)) (mair : (BitVec 64)) : SailM (BitVec 8) := do
  let bit_index : Int := (8 *i index)
  sail_assert (←((pure (index <b 8)) <||> (do
    (pure ((← (HaveAIEExt ())) && (index <b 16)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25347.48-25347.49"
  (if ((index >b 7) : Bool)
  then
    (do let bit_index := (bit_index -i 64)
        sail_assert ((0 ≤b bit_index) && ((bit_index ≤b (bit_index +i 7)) && ((bit_index +i 7) <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25350.97-25350.98"
        (pure (Sail.BitVec.extractLsb mair2 (bit_index +i 7) bit_index)))
  else
    (do let bit_index := bit_index
        sail_assert ((0 ≤b bit_index) && ((bit_index ≤b (bit_index +i 7)) && ((bit_index +i 7) <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25354.97-25354.98"
        (pure (Sail.BitVec.extractLsb mair (bit_index +i 7) bit_index))))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1ApplyOutputPerms (permissions_in : Permissions) (descriptor : (BitVec k_N)) (regime : Regime) (walkparams : S1TTWParams) : SailM Permissions := do
  let bit_index ← (( do (undefined_int ()) ) : SailM Int )
  let permissions : Permissions := permissions_in
  let pi_index ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let permissions ← (( do
    (if ((walkparams.pie == 1#1) : Bool)
    then
      (do let pi_index ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25368.39-25368.40"
                  (pure (Sail.BitVec.extractLsb descriptor 118 115)))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25371.38-25371.39"
                  (pure (((Sail.BitVec.extractLsb descriptor 54 53) +++ ((BitVec.access descriptor 51) : BitVec 1)) +++ ((BitVec.access descriptor 6) : BitVec 1))))) ) : SailM (BitVec 4) )
          let bit_index := (4 *i (BitVec.toNat pi_index))
          let permissions : Permissions := { permissions with ppi := (Sail.BitVec.extractLsb walkparams.pir (bit_index +i 3) bit_index) }
          let permissions : Permissions := { permissions with upi := (Sail.BitVec.extractLsb walkparams.pire0 (bit_index +i 3) bit_index) }
          sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25377.33-25377.34"
          (pure { permissions with ndirty := ((BitVec.access descriptor 7) : BitVec 1) }))
    else
      (do let permissions ← (( do
            (if (((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                   (EL2Enabled ())))) && (walkparams.nv1 == 1#1)) : Bool)
            then
              (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25381.37-25381.38"
                  let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (((BitVec.access descriptor 7) : BitVec 1) +++ 0#1)) }
                  sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25383.38-25383.39"
                  (pure { permissions with pxn := ((BitVec.access descriptor 54) : BitVec 1) }))
            else
              (do (if ((HasUnprivileged regime) : Bool)
                  then
                    (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25386.37-25386.38"
                        let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (Sail.BitVec.extractLsb descriptor 7 6)) }
                        sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25388.38-25388.39"
                        let permissions : Permissions := { permissions with uxn := ((BitVec.access descriptor 54) : BitVec 1) }
                        (pure { permissions with pxn := ((BitVec.access descriptor 53) : BitVec 1) }))
                  else
                    (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25392.37-25392.38"
                        let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (((BitVec.access descriptor 7) : BitVec 1) +++ 1#1)) }
                        sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25394.38-25394.39"
                        (pure { permissions with xn := ((BitVec.access descriptor 54) : BitVec 1) }))))) ) : SailM Permissions )
          sail_assert (51 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25397.34-25397.35"
          (if ((((walkparams.ha == 1#1) && (walkparams.hd == 1#1)) && (((BitVec.access descriptor 51) : BitVec 1) == 1#1)) : Bool)
          then (do (pure { permissions with ap := (BitVec.update permissions.ap 2 (Bit 0#1)) }))
          else (do (pure permissions))))) ) : SailM Permissions )
  let poe ← (( do (AArch64_S1POEnabled regime) ) : SailM Bool )
  let e0poe ← (( do (pure (HasUnprivileged regime)) <&&> (do (AArch64_S1E0POEnabled regime walkparams.nv1)) ) : SailM Bool )
  (if ((poe || e0poe) : Bool)
  then
    (do (if ((walkparams.d128 == 1#1) : Bool)
        then
          (do sail_assert (124 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25407.39-25407.40"
              (pure { permissions with po_index := (Sail.BitVec.extractLsb descriptor 124 121) }))
        else
          (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25410.38-25410.39"
              (pure { permissions with po_index := (0#1 +++ (Sail.BitVec.extractLsb descriptor 62 60)) }))))
  else (do (pure permissions)))

/-- Type quantifiers: k_N : Nat, k_s2fs1mro : Bool, k_N ≥ 0 -/
def AArch64_S1NextWalkStateLeaf (currentstate : TTWState) (s2fs1mro : Bool) (regime : Regime) (ss : SecurityState) (walkparams : S1TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let baseaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let baseaddress ← (pure { baseaddress with address := (← do (AArch64_LeafBase descriptor walkparams.d128 walkparams.ds walkparams.tgx currentstate.level)) })
  let baseaddress ← (( do
    (if ((BEq.beq currentstate.baseaddress.paspace PAS_Secure) : Bool)
    then
      (do let ns ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25426.39-25426.40"
                  (pure ((BitVec.access descriptor 127) : BitVec 1)))
            else
              (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25429.37-25429.38"
                  (pure ((BitVec.access descriptor 5) : BitVec 1)))) ) : SailM (BitVec 1) )
          (pure { baseaddress with paspace := if ((ns == 0#1) : Bool)
              then PAS_Secure
              else PAS_NonSecure }))
    else
      (do (if ((BEq.beq currentstate.baseaddress.paspace PAS_Root) : Bool)
          then
            (do let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                let (ns, nse) ← (( do
                  let split_vec ← do
                    (if ((walkparams.d128 == 1#1) : Bool)
                    then
                      (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25437.38-25437.39"
                          sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25438.39-25438.40"
                          (pure (((BitVec.access descriptor 11) : BitVec 1) +++ ((BitVec.access descriptor 127) : BitVec 1))))
                    else
                      (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25441.38-25441.39"
                          (pure (((BitVec.access descriptor 11) : BitVec 1) +++ ((BitVec.access descriptor 5) : BitVec 1)))))
                  let nse : (BitVec 1) := (Sail.BitVec.extractLsb split_vec 1 1)
                  let ns : (BitVec 1) := (Sail.BitVec.extractLsb split_vec 0 0)
                  (pure (ns, nse)) ) : SailM ((BitVec 1) × (BitVec 1)) )
                let baseaddress ← (pure { baseaddress with paspace := (← do (DecodePASpace nse ns)) })
                (if ((←((pure (BEq.beq baseaddress.paspace PAS_Secure)) <&&> (do
                     (pure (! (← (HaveSecureState ()))))))) : Bool)
                then (do (pure { baseaddress with paspace := PAS_NonSecure }))
                else (do (pure baseaddress))))
          else
            (do (if (((BEq.beq currentstate.baseaddress.paspace PAS_Realm) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) : Bool)
                then
                  (do let ns ← (( do
                        (if ((walkparams.d128 == 1#1) : Bool)
                        then
                          (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25451.39-25451.40"
                              (pure ((BitVec.access descriptor 127) : BitVec 1)))
                        else
                          (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25454.37-25454.38"
                              (pure ((BitVec.access descriptor 5) : BitVec 1)))) ) : SailM (BitVec 1) )
                      (pure { baseaddress with paspace := if ((ns == 0#1) : Bool)
                          then PAS_Realm
                          else PAS_NonSecure }))
                else
                  (do (if ((BEq.beq currentstate.baseaddress.paspace PAS_Realm) : Bool)
                      then (do (pure { baseaddress with paspace := PAS_Realm }))
                      else (do (pure { baseaddress with paspace := PAS_NonSecure }))))))))) ) : SailM FullAddress )
  let nextstate : TTWState := { nextstate with istable := false }
  let nextstate : TTWState := { nextstate with level := currentstate.level }
  let nextstate : TTWState := { nextstate with baseaddress := baseaddress }
  let attrindx ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let attrindx ← (( do
    (if ((walkparams.aie == 1#1) : Bool)
    then
      (do (if ((walkparams.d128 == 1#1) : Bool)
          then
            (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25469.37-25469.38"
                (pure (Sail.BitVec.extractLsb descriptor 5 2)))
          else
            (do sail_assert (59 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25472.38-25472.39"
                (pure (((BitVec.access descriptor 59) : BitVec 1) +++ (Sail.BitVec.extractLsb descriptor 4 2))))))
    else
      (do sail_assert (4 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25476.33-25476.34"
          (pure (0#1 +++ (Sail.BitVec.extractLsb descriptor 4 2))))) ) : SailM (BitVec 4) )
  let sh ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let sh ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25481.33-25481.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))
    else
      (do (if ((walkparams.ds == 1#1) : Bool)
          then (do (pure walkparams.sh))
          else
            (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25486.33-25486.34"
                (pure (Sail.BitVec.extractLsb descriptor 9 8)))))) ) : SailM (BitVec 2) )
  let attr ← (( do (AArch64_MAIRAttr (BitVec.toNat attrindx) walkparams.mair2 walkparams.mair) ) : SailM (BitVec 8) )
  let s1aarch64 : Bool := true
  let nextstate ← (pure { nextstate with memattrs := (← do (S1DecodeMemAttrs attr sh s1aarch64 walkparams)) })
  let nextstate ← (pure { nextstate with permissions := (← do (AArch64_S1ApplyOutputPerms currentstate.permissions descriptor regime walkparams)) })
  let protectedbit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let protectedbit ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25495.35-25495.36"
          (pure ((BitVec.access descriptor 114) : BitVec 1)))
    else
      (do (if ((walkparams.pnch == 1#1) : Bool)
          then
            (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25499.38-25499.39"
                (pure ((BitVec.access descriptor 52) : BitVec 1)))
          else (do (pure 0#1))))) ) : SailM (BitVec 1) )
  let nextstate : TTWState :=
    if (((currentstate.s1assured && s2fs1mro) && (protectedbit == 1#1)) : Bool)
    then { nextstate with s1assured := true }
    else { nextstate with s1assured := false }
  let nextstate ← (( do
    (if (((walkparams.pnch == 1#1) || (currentstate.disch == 1#1)) : Bool)
    then (do (pure { nextstate with contiguous := 0#1 }))
    else
      (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25511.34-25511.35"
          (pure { nextstate with contiguous := (← do (AArch64_ContiguousBit walkparams.tgx walkparams.d128 currentstate.level descriptor)) }))) ) : SailM TTWState )
  let nextstate ← (( do
    (if ((! (HasUnprivileged regime)) : Bool)
    then (do (pure { nextstate with nG := 0#1 }))
    else
      (do (if (((BEq.beq ss SS_Secure) && (BEq.beq currentstate.baseaddress.paspace PAS_NonSecure)) : Bool)
          then (do (pure { nextstate with nG := 1#1 }))
          else
            (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25519.34-25519.35"
                (pure { nextstate with nG := ((BitVec.access descriptor 11) : BitVec 1) }))))) ) : SailM TTWState )
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do sail_assert (113 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25523.35-25523.36"
        (pure { nextstate with guardedpage := ((BitVec.access descriptor 113) : BitVec 1) }))
  else
    (do sail_assert (50 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25526.34-25526.35"
        (pure { nextstate with guardedpage := ((BitVec.access descriptor 50) : BitVec 1) })))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_NextTableBase (descriptor : (BitVec k_N)) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let tablebase ← (( do
    match tgx with
    | .TGx_4KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25539.36-25539.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 12 (Sail.BitVec.extractLsb descriptor 47 12))))
    | .TGx_16KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25543.36-25543.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 14 (Sail.BitVec.extractLsb descriptor 47 14))))
    | .TGx_64KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25547.36-25547.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 16 (Sail.BitVec.extractLsb descriptor 47 16)))) ) : SailM (BitVec 56) )
  (if (((← (Have56BitPAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25552.34-25552.35"
        (pure (Sail.BitVec.updateSubrange tablebase 55 48 (Sail.BitVec.extractLsb descriptor 55 48))))
  else
    (do (if (((← (Have52BitPAExt ())) && (BEq.beq tgx TGx_64KB)) : Bool)
        then
          (do sail_assert (15 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25557.34-25557.35"
              (pure (Sail.BitVec.updateSubrange tablebase 51 48 (Sail.BitVec.extractLsb descriptor 15 12))))
        else
          (do (if ((ds == 1#1) : Bool)
              then
                (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25562.33-25562.34"
                    sail_assert (49 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25563.34-25563.35"
                    (pure (Sail.BitVec.updateSubrange tablebase 51 48 ((Sail.BitVec.extractLsb descriptor 9 8) +++ (Sail.BitVec.extractLsb descriptor 49 48)))))
              else (do (pure tablebase)))))))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1ApplyTablePerms (permissions_in : Permissions) (descriptor : (BitVec k_N)) (regime : Regime) (walkparams : S1TTWParams) : SailM Permissions := do
  let permissions : Permissions := permissions_in
  let ap_table ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let pxn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uxn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let xn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  (if (((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
         (EL2Enabled ())))) && (walkparams.nv1 == 1#1)) : Bool)
  then
    (do let (ap_table, pxn_table) ← (( do
          (if ((walkparams.d128 == 1#1) : Bool)
          then
            (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25581.39-25581.40"
                let ap_table : (BitVec 2) := (((BitVec.access descriptor 126) : BitVec 1) +++ 0#1)
                let pxn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                (pure (ap_table, pxn_table)))
          else
            (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25585.38-25585.39"
                let ap_table : (BitVec 2) := (((BitVec.access descriptor 62) : BitVec 1) +++ 0#1)
                let pxn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                (pure (ap_table, pxn_table)))) ) : SailM ((BitVec 2) × (BitVec 1)) )
        let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
        (pure { permissions with pxn_table := (permissions.pxn_table ||| pxn_table) }))
  else
    (do (if ((HasUnprivileged regime) : Bool)
        then
          (do let (ap_table, pxn_table, uxn_table) ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25593.39-25593.40"
                      let ap_table : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 126 125)
                      let uxn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                      let pxn_table : (BitVec 1) := ((BitVec.access descriptor 123) : BitVec 1)
                      (pure (ap_table, pxn_table, uxn_table)))
                else
                  (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25598.38-25598.39"
                      let ap_table : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 62 61)
                      let uxn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                      let pxn_table : (BitVec 1) := ((BitVec.access descriptor 59) : BitVec 1)
                      (pure (ap_table, pxn_table, uxn_table)))) ) : SailM ((BitVec 2) × (BitVec 1) × (BitVec 1)) )
              let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
              let permissions : Permissions := { permissions with uxn_table := (permissions.uxn_table ||| uxn_table) }
              (pure { permissions with pxn_table := (permissions.pxn_table ||| pxn_table) }))
        else
          (do let (ap_table, xn_table) ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25608.39-25608.40"
                      let ap_table : (BitVec 2) := (((BitVec.access descriptor 126) : BitVec 1) +++ 0#1)
                      let xn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                      (pure (ap_table, xn_table)))
                else
                  (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25612.38-25612.39"
                      let ap_table : (BitVec 2) := (((BitVec.access descriptor 62) : BitVec 1) +++ 0#1)
                      let xn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                      (pure (ap_table, xn_table)))) ) : SailM ((BitVec 2) × (BitVec 1)) )
              let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
              (pure { permissions with xn_table := (permissions.xn_table ||| xn_table) })))))

/-- Type quantifiers: k_N : Nat, k_s2fs1mro : Bool, k_N ≥ 0 -/
def AArch64_S1NextWalkStateTable (currentstate : TTWState) (s2fs1mro : Bool) (regime : Regime) (walkparams : S1TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let skl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let tablebase ← (pure { tablebase with address := (← do (AArch64_NextTableBase descriptor walkparams.d128 walkparams.ds walkparams.tgx)) })
  let tablebase ← (( do
    (if ((BEq.beq currentstate.baseaddress.paspace PAS_Secure) : Bool)
    then
      (do let nstable ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25632.39-25632.40"
                  (pure ((BitVec.access descriptor 127) : BitVec 1)))
            else
              (do sail_assert (63 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25635.38-25635.39"
                  (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
          (pure { tablebase with paspace := if ((nstable == 0#1) : Bool)
              then PAS_Secure
              else PAS_NonSecure }))
    else (do (pure { tablebase with paspace := currentstate.baseaddress.paspace }))) ) : SailM FullAddress )
  let nextstate : TTWState := { nextstate with istable := true }
  let nextstate : TTWState := { nextstate with nG := currentstate.nG }
  let nextstate ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (110 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25645.35-25645.36"
          let skl : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 110 109)
          (pure { nextstate with level := ((currentstate.level +i (BitVec.toNat skl)) +i 1) }))
    else (do (pure { nextstate with level := (currentstate.level +i 1) }))) ) : SailM TTWState )
  let nextstate : TTWState := { nextstate with baseaddress := tablebase }
  let nextstate : TTWState := { nextstate with memattrs := currentstate.memattrs }
  let nextstate ← (( do
    (if (((walkparams.hpd == 0#1) && (walkparams.pie == 0#1)) : Bool)
    then (do (pure { nextstate with permissions := (← do (AArch64_S1ApplyTablePerms currentstate.permissions descriptor regime walkparams)) }))
    else (do (pure { nextstate with permissions := currentstate.permissions }))) ) : SailM TTWState )
  let protectedbit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let protectedbit ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25660.35-25660.36"
          (pure ((BitVec.access descriptor 114) : BitVec 1)))
    else
      (do (if ((walkparams.pnch == 1#1) : Bool)
          then
            (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25664.38-25664.39"
                (pure ((BitVec.access descriptor 52) : BitVec 1)))
          else (do (pure 0#1))))) ) : SailM (BitVec 1) )
  let nextstate : TTWState :=
    if (((currentstate.s1assured && s2fs1mro) && (protectedbit == 1#1)) : Bool)
    then { nextstate with s1assured := true }
    else { nextstate with s1assured := false }
  (pure { nextstate with disch := (← do
      (if ((walkparams.d128 == 1#1) : Bool)
      then
        (do sail_assert (112 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25674.35-25674.36"
            (pure ((BitVec.access descriptor 112) : BitVec 1)))
      else (do (pure 0#1)))) })

/-- Type quantifiers: level : Int -/
def AArch64_S1SLTTEntryAddress (level : Int) (walkparams : S1TTWParams) (ia : (BitVec 64)) (tablebase : FullAddress) : SailM FullAddress := do
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i level)
  let lsb := ((levels *i stride) +i granulebits)
  let msb := (iasize -i 1)
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25691.61-25691.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25692.60-25692.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ia msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_HaveS2TG (tgx : TGx) : SailM Bool := do
  sail_assert (HaveEL EL2) "sail-arm/arm-v9.4-a/src/v8_base.sail:25703.22-25703.23"
  (if ((← (HaveGTGExt ())) : Bool)
  then
    (do match tgx with
        | .TGx_4KB => (__IMPDEF_boolean "Has Stage 2 4K Translation Granule")
        | .TGx_16KB => (__IMPDEF_boolean "Has Stage 2 16K Translation Granule")
        | .TGx_64KB => (__IMPDEF_boolean "Has Stage 2 64K Translation Granule"))
  else (do (AArch64_HaveS1TG tgx)))

def AArch64_S2DecodeTG0 (tg0_in : (BitVec 2)) : SailM TGx := do
  let tg0 : (BitVec 2) := tg0_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg0 ← (( do
    (if ((tg0 == 0b11#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG0 encoded granule size"))
    else (do (pure tg0))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg0 with
    | 0b00 => TGx_4KB
    | 0b01 => TGx_64KB
    | 0b10 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS2TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG0 encoded granule size")) with
        | 0b00 => (pure TGx_4KB)
        | 0b01 => (pure TGx_64KB)
        | 0b10 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def undefined_S2PIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2PIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_NSS2TTWParams (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  let walkparams ← (pure { walkparams with vm := (← do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) ||| (_get_HCR_EL2_Type_DC (← readReg HCR_EL2))))) })
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VTCR_EL2_Type_TG0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VTCR_EL2_Type_T0SZ (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_VTCR_EL2_Type_PS (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_VTCR_EL2_Type_IRGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_VTCR_EL2_Type_ORGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_VTCR_EL2_Type_SH0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_D128 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with skl := (← do (pure (_get_VTTBR_EL2_Type_SKL (← (VTTBR_EL2_read ()))))) }))
    else (do (pure { walkparams with sl0 := (← do (pure (_get_VTCR_EL2_Type_SL0 (← readReg VTCR_EL2)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with ptw := (← do
        (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
        then (do (pure (_get_HCR_EL2_Type_PTW (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with fwb := (← do
        (if ((← (HaveStage2MemAttrControl ())) : Bool)
        then (do (pure (_get_HCR_EL2_Type_FWB (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HA (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HD (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ← (( do
    (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with sl2 := (← do (pure ((_get_VTCR_EL2_Type_SL2 (← readReg VTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
    else (do (pure { walkparams with sl2 := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((←((HaveFeatCMOW ()) <&&> (do
             (IsHCRXEL2Enabled ())))) : Bool)
        then (do (pure (_get_HCRX_EL2_Type_CMOW (← readReg HCRX_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with s2pie := 1#1 }))
    else
      (do (pure { walkparams with s2pie := (← do
              (if ((← (HaveS2PIExt ())) : Bool)
              then (do (pure (_get_VTCR_EL2_Type_S2PIE (← readReg VTCR_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with s2pir := (← do
        (if ((← (HaveS2PIExt ())) : Bool)
        then (do (pure (Mk_S2PIRType (← readReg S2PIR_EL2))))
        else (do (pure (Mk_S2PIRType (Zeros (n := 64))))))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 != 1#1)) : Bool)
    then (do (pure { walkparams with assuredonly := (← do (pure (_get_VTCR_EL2_Type_AssuredOnly (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with assuredonly := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with tl0 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL0 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tl1 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL1 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
  then (do (pure { walkparams with haft := (← do (pure (_get_VTCR_EL2_Type_HAFT (← readReg VTCR_EL2)))) }))
  else (do (pure { walkparams with haft := 0#1 })))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_RLS2TTWParams (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (AArch64_NSS2TTWParams s1aarch64) ) : SailM S2TTWParams )
  (pure { walkparams with emec := (← do
      (if ((←((HaveFeatMEC ()) <&&> (do
           (IsSCTLR2EL2Enabled ())))) : Bool)
      then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
      else (do (pure 0#1)))) })

def undefined_VSTCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSTCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSTCR_EL2_Type_SW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_PMUSERENR_EL0_Type_SW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_VSTTBR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSTTBR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_SS2TTWParams (ipaspace : PASpace) (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_D128 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VSTCR_EL2_Type_TG0 (← readReg VSTCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VSTCR_EL2_Type_T0SZ (← readReg VSTCR_EL2)))) })
          let walkparams ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then (do (pure { walkparams with skl := (← do (pure (_get_VSTTBR_EL2_Type_SKL (← readReg VSTTBR_EL2)))) }))
            else (do (pure { walkparams with sl0 := (← do (pure (_get_VSTCR_EL2_Type_SL0 (← readReg VSTCR_EL2)))) }))) ) : SailM S2TTWParams )
          (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
               (Have52BitIPAAndPASpaceExt ())))) : Bool)
          then (do (pure { walkparams with sl2 := (← do (pure ((_get_VSTCR_EL2_Type_SL2 (← readReg VSTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
          else (do (pure { walkparams with sl2 := 0#1 }))))
    else
      (do (if ((BEq.beq ipaspace PAS_NonSecure) : Bool)
          then
            (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VTCR_EL2_Type_TG0 (← readReg VTCR_EL2)))) })
                let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VTCR_EL2_Type_T0SZ (← readReg VTCR_EL2)))) })
                let walkparams ← (( do
                  (if ((walkparams.d128 == 1#1) : Bool)
                  then (do (pure { walkparams with skl := (← do (pure (_get_VTTBR_EL2_Type_SKL (← (VTTBR_EL2_read ()))))) }))
                  else (do (pure { walkparams with sl0 := (← do (pure (_get_VTCR_EL2_Type_SL0 (← readReg VTCR_EL2)))) }))) ) : SailM S2TTWParams )
                (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
                     (Have52BitIPAAndPASpaceExt ())))) : Bool)
                then (do (pure { walkparams with sl2 := (← do (pure ((_get_VTCR_EL2_Type_SL2 (← readReg VTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
                else (do (pure { walkparams with sl2 := 0#1 }))))
          else
            (do (Unreachable ())
                (pure walkparams))))) ) : SailM S2TTWParams )
  let walkparams ← (pure { walkparams with sw := (← do (pure (_get_VSTCR_EL2_Type_SW (← readReg VSTCR_EL2)))) })
  let walkparams ← (pure { walkparams with nsw := (← do (pure (_get_VTCR_EL2_Type_NSW (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sa := (← do (pure (_get_VSTCR_EL2_Type_SA (← readReg VSTCR_EL2)))) })
  let walkparams ← (pure { walkparams with nsa := (← do (pure (_get_VTCR_EL2_Type_NSA (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with vm := (← do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) ||| (_get_HCR_EL2_Type_DC (← readReg HCR_EL2))))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_VTCR_EL2_Type_PS (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_VTCR_EL2_Type_IRGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_VTCR_EL2_Type_ORGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_VTCR_EL2_Type_SH0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ←
    (pure { walkparams with ptw := (← do
        (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
        then (do (pure (_get_HCR_EL2_Type_PTW (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with fwb := (← do
        (if ((← (HaveStage2MemAttrControl ())) : Bool)
        then (do (pure (_get_HCR_EL2_Type_FWB (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HA (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HD (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((←((HaveFeatCMOW ()) <&&> (do
             (IsHCRXEL2Enabled ())))) : Bool)
        then (do (pure (_get_HCRX_EL2_Type_CMOW (← readReg HCRX_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with s2pie := 1#1 }))
    else
      (do (pure { walkparams with s2pie := (← do
              (if ((← (HaveS2PIExt ())) : Bool)
              then (do (pure (_get_VTCR_EL2_Type_S2PIE (← readReg VTCR_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with s2pir := (← do
        (if ((← (HaveS2PIExt ())) : Bool)
        then (do (pure (Mk_S2PIRType (← readReg S2PIR_EL2))))
        else (do (pure (Mk_S2PIRType (Zeros (n := 64))))))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 != 1#1)) : Bool)
    then (do (pure { walkparams with assuredonly := (← do (pure (_get_VTCR_EL2_Type_AssuredOnly (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with assuredonly := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with tl0 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL0 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tl1 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL1 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_VTCR_EL2_Type_HAFT (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S2TTWParams )
  (pure { walkparams with emec := 0#1 })

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_GetS2TTWParams (ss : SecurityState) (ipaspace : PASpace) (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  (if ((BEq.beq ss SS_NonSecure) : Bool)
  then (do (AArch64_NSS2TTWParams s1aarch64))
  else
    (do (if (((← (HaveSecureEL2Ext ())) && (BEq.beq ss SS_Secure)) : Bool)
        then (do (AArch64_SS2TTWParams ipaspace s1aarch64))
        else
          (do (if ((BEq.beq ss SS_Realm) : Bool)
              then (do (AArch64_RLS2TTWParams s1aarch64))
              else
                (do (Unreachable ())
                    (pure walkparams)))))))

def AArch64_IPAIsOutOfRange (ipa : (BitVec 56)) (walkparams : S2TTWParams) : Bool :=
  let iasize := (AArch64_IASize walkparams.txsz)
  if ((iasize <b 56) : Bool)
  then (! (is_zero_subrange ipa 55 iasize))
  else false

def AArch64_S2DirectBasePermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let r : (BitVec 1) := ((BitVec.access permissions.s2ap 0) : BitVec 1)
  let w : (BitVec 1) := ((BitVec.access permissions.s2ap 1) : BitVec 1)
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (px, ux) : ((BitVec 1) × (BitVec 1)) :=
    match (permissions.s2xn +++ permissions.s2xnx) with
    | 0b00 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | 0b01 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | 0b10 =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | _ =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let s2perms : S2AccessControls := { s2perms with r := r }
  let s2perms : S2AccessControls := { s2perms with w := w }
  let s2perms : S2AccessControls := { s2perms with x := x }
  let s2perms : S2AccessControls := { s2perms with r_rcw := r }
  let s2perms : S2AccessControls := { s2perms with w_rcw := w }
  let s2perms : S2AccessControls := { s2perms with r_mmu := r }
  (pure { s2perms with w_mmu := w })

def AArch64_S2IndirectBasePermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel0 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let s2pi : (BitVec 4) := permissions.s2pi
  let (px, r, ux, w, w_mmu, w_rcw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    match s2pi with
    | 0b0000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 1#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0111 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | _ =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let (r_mmu, r_rcw) : ((BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1) := ((r, r) : ((BitVec 1) × (BitVec 1)))
    let r_rcw : (BitVec 1) := tup__0
    let r_mmu : (BitVec 1) := tup__1
    (r_mmu, r_rcw)
  let (toplevel0, toplevel1) : ((BitVec 1) × (BitVec 1)) :=
    match s2pi with
    | 0b0110 =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0011 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0111 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | _ =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
  let s2perms : S2AccessControls := { s2perms with r := r }
  let s2perms : S2AccessControls := { s2perms with w := w }
  let s2perms : S2AccessControls := { s2perms with x := x }
  let s2perms : S2AccessControls := { s2perms with r_rcw := r_rcw }
  let s2perms : S2AccessControls := { s2perms with r_mmu := r_mmu }
  let s2perms : S2AccessControls := { s2perms with w_rcw := w_rcw }
  let s2perms : S2AccessControls := { s2perms with w_mmu := w_mmu }
  let s2perms : S2AccessControls := { s2perms with toplevel0 := toplevel0 }
  (pure { s2perms with toplevel1 := toplevel1 })

def undefined_S2POR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2POR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S2OverlayPermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel0 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let s2overlay_perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let index := (4 *i (BitVec.toNat permissions.s2po_index))
  let s2po ← (( do (pure (Sail.BitVec.extractLsb (← readReg S2POR_EL1) (index +i 3) index)) ) : SailM (BitVec 4) )
  let (px, r, ux, w, w_mmu, w_rcw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    match s2po with
    | 0b0000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 1#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0111 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | _ =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let (r_mmu, r_rcw) : ((BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1) := ((r, r) : ((BitVec 1) × (BitVec 1)))
    let r_rcw : (BitVec 1) := tup__0
    let r_mmu : (BitVec 1) := tup__1
    (r_mmu, r_rcw)
  let (toplevel0, toplevel1) : ((BitVec 1) × (BitVec 1)) :=
    match s2po with
    | 0b0110 =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0011 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0111 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | _ =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or := r }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow := w }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ox := x }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or_rcw := r_rcw }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow_rcw := w_rcw }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or_mmu := r_mmu }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow_mmu := w_mmu }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with toplevel0 := toplevel0 }
  (pure { s2overlay_perms with toplevel1 := toplevel1 })

def AArch64_S2ComputePermissions (permissions : Permissions) (walkparams : S2TTWParams) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let s2overlay_perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  (if ((walkparams.s2pie == 1#1) : Bool)
  then
    (do let s2perms ← (AArch64_S2IndirectBasePermissions permissions accdesc)
        let s2perms ← (pure { s2perms with overlay := (← do (HaveS2POExt ()) <&&> (do (pure ((_get_VTCR_EL2_Type_S2POE (← readReg VTCR_EL2)) == 1#1)))) })
        (if (s2perms.overlay : Bool)
        then
          (do let s2overlay_perms ← (( do (AArch64_S2OverlayPermissions permissions accdesc) ) : SailM S2AccessControls )
              let s2perms : S2AccessControls := { s2perms with or := s2overlay_perms.or }
              let s2perms : S2AccessControls := { s2perms with ow := s2overlay_perms.ow }
              let s2perms : S2AccessControls := { s2perms with ox := s2overlay_perms.ox }
              let s2perms : S2AccessControls := { s2perms with or_rcw := s2overlay_perms.or_rcw }
              let s2perms : S2AccessControls := { s2perms with ow_rcw := s2overlay_perms.ow_rcw }
              let s2perms : S2AccessControls := { s2perms with or_mmu := s2overlay_perms.or_mmu }
              let s2perms : S2AccessControls := { s2perms with ow_mmu := s2overlay_perms.ow_mmu }
              (if ((((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) &&& (s2perms.ow +++ (s2perms.ow_rcw +++ s2perms.ow_mmu))) == 0b011#3) : Bool)
              then
                (do let s2perms : S2AccessControls := { s2perms with toplevel0 := (s2perms.toplevel0 ||| s2overlay_perms.toplevel0) }
                    (pure { s2perms with toplevel1 := (s2perms.toplevel1 ||| s2overlay_perms.toplevel1) }))
              else
                (do let s2perms : S2AccessControls := { s2perms with toplevel0 := 0#1 }
                    (pure { s2perms with toplevel1 := 0#1 }))))
        else (do (pure s2perms))))
  else (do (AArch64_S2DirectBasePermissions permissions accdesc)))

def AArch64_S2CheckPermissions (fault_in : FaultRecord) (walkstate : TTWState) (walkparams : S2TTWParams) (ipa : AddressDescriptor) (accdesc : AccessDescriptor) : SailM (FaultRecord × Bool) := do
  let memtype : MemType := walkstate.memattrs.memtype
  let permissions : Permissions := walkstate.permissions
  let fault : FaultRecord := fault_in
  let s2perms ← (( do (AArch64_S2ComputePermissions permissions walkparams accdesc) ) : SailM S2AccessControls )
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let or ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ow ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (or, ow, r, w) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    if ((BEq.beq accdesc.acctype AccessType_TTW) : Bool)
    then
      (let r : (BitVec 1) := s2perms.r_mmu
      let w : (BitVec 1) := s2perms.w_mmu
      let or : (BitVec 1) := s2perms.or_mmu
      let ow : (BitVec 1) := s2perms.ow_mmu
      (or, ow, r, w))
    else
      (let (or, ow, r, w) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
        if (accdesc.rcw : Bool)
        then
          (let r : (BitVec 1) := s2perms.r_rcw
          let w : (BitVec 1) := s2perms.w_rcw
          let or : (BitVec 1) := s2perms.or_rcw
          let ow : (BitVec 1) := s2perms.ow_rcw
          (or, ow, r, w))
        else
          (let r : (BitVec 1) := s2perms.r
          let w : (BitVec 1) := s2perms.w
          let or : (BitVec 1) := s2perms.or
          let ow : (BitVec 1) := s2perms.ow
          (or, ow, r, w))
      (or, ow, r, w))
  let fault ← (( do
    (if ((BEq.beq accdesc.acctype AccessType_TTW) : Bool)
    then
      (do (if (((accdesc.toplevel && (BEq.beq accdesc.varange VARange_LOWER)) && (((walkparams.tl0 == 1#1) && (s2perms.toplevel0 == 0#1)) || ((walkparams.tl1 == 1#1) && ((s2perms.toplevel1 +++ s2perms.toplevel0) == 0b10#2)))) : Bool)
          then
            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                (pure { fault with toplevel := true }))
          else
            (do (if (((accdesc.toplevel && (BEq.beq accdesc.varange VARange_UPPER)) && (((walkparams.tl1 == 1#1) && (s2perms.toplevel1 == 0#1)) || ((walkparams.tl0 == 1#1) && ((s2perms.toplevel1 +++ s2perms.toplevel0) == 0b01#2)))) : Bool)
                then
                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                      (pure { fault with toplevel := true }))
                else
                  (do (if (((walkparams.ptw == 1#1) && (BEq.beq memtype MemType_Device)) : Bool)
                      then (do (pure { fault with statuscode := Fault_Permission }))
                      else
                        (do (if ((s2perms.overlay && (or == 0#1)) : Bool)
                            then
                              (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                  (pure { fault with overlay := true }))
                            else
                              (do (if (((accdesc.write && s2perms.overlay) && (ow == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if (((BEq.beq accdesc.ss SS_Realm) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
                                        then (do (pure { fault with statuscode := Fault_Permission }))
                                        else
                                          (do (if ((r == 0#1) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if ((accdesc.write && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else
                                                      (do (if ((((accdesc.write && (! ((walkparams.ha +++ walkparams.hd) == 0b11#2))) && (walkparams.s2pie == 1#1)) && (permissions.s2dirty == 0#1)) : Bool)
                                                          then
                                                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                (pure { fault with dirtybit := true }))
                                                          else (do (pure fault))))))))))))))))))))
    else
      (do (if ((←((pure ((walkstate.s2assuredonly == 1#1) && (! ipa.s1assured))) <||> (do
               (pure (((←((pure (walkstate.s2assuredonly != 1#1)) <&&> (do (HaveGCS ())) <&&> (do (pure ((_get_VTCR_EL2_Type_GCSH (← readReg VTCR_EL2)) == 1#1))))) && (BEq.beq accdesc.acctype AccessType_GCS)) && (accdesc.el != EL0)))))) : Bool)
          then
            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                (pure { fault with assuredonly := true }))
          else
            (do (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
                then
                  (do (if ((s2perms.overlay && (s2perms.ox == 0#1)) : Bool)
                      then
                        (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                            (pure { fault with overlay := true }))
                      else
                        (do (if ((←((pure (BEq.beq memtype MemType_Device)) <&&> (do
                                 (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_INSTRDEVICE)) Constraint_FAULT))))) : Bool)
                            then (do (pure { fault with statuscode := Fault_Permission }))
                            else
                              (do (if (((BEq.beq accdesc.ss SS_Realm) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_Permission }))
                                  else
                                    (do (if ((s2perms.x == 0#1) : Bool)
                                        then (do (pure { fault with statuscode := Fault_Permission }))
                                        else (do (pure fault))))))))))
                else
                  (do (if ((BEq.beq accdesc.acctype AccessType_DC) : Bool)
                      then
                        (do (if ((BEq.beq accdesc.cacheop CacheOp_Invalidate) : Bool)
                            then
                              (do let fault ← (( do
                                    (if ((((! (← (ELUsingAArch32 EL1))) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                    then
                                      (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                          (pure { fault with overlay := true }))
                                    else (do (pure fault))) ) : SailM FaultRecord )
                                  (if (((! (← (ELUsingAArch32 EL1))) && (w == 0#1)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_Permission }))
                                  else (do (pure fault))))
                            else
                              (do (if (((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && s2perms.overlay) && (or == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if ((((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              (pure { fault with overlay := true }))
                                        else
                                          (do (if ((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && (r == 0#1)) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if (((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else (do (pure fault))))))))))))
                      else
                        (do (if ((BEq.beq accdesc.acctype AccessType_IC) : Bool)
                            then
                              (do (if ((←((pure ((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && s2perms.overlay) && (or == 0#1))) <&&> (do
                                       (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if ((((walkparams.cmow == 1#1) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              (pure { fault with overlay := true }))
                                        else
                                          (do (if ((←((pure (((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && (r == 0#1))) <&&> (do
                                                   (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if (((walkparams.cmow == 1#1) && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else (do (pure fault))))))))))
                            else
                              (do (if (((accdesc.read && s2perms.overlay) && (or == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        let fault : FaultRecord := { fault with overlay := true }
                                        (pure { fault with write := false }))
                                  else
                                    (do (if (((accdesc.write && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              let fault : FaultRecord := { fault with overlay := true }
                                              (pure { fault with write := true }))
                                        else
                                          (do (if ((accdesc.read && (r == 0#1)) : Bool)
                                              then
                                                (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                    (pure { fault with write := false }))
                                              else
                                                (do (if ((accdesc.write && (w == 0#1)) : Bool)
                                                    then
                                                      (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                          (pure { fault with write := true }))
                                                    else
                                                      (do (if ((((accdesc.tagaccess || accdesc.tagchecked) && (BEq.beq ipa.memattrs.tags MemTag_AllocationTagged)) && (permissions.s2tag_na == 1#1)) : Bool)
                                                          then
                                                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                let fault : FaultRecord := { fault with tagaccess := true }
                                                                (pure { fault with write := (accdesc.tagaccess && accdesc.write) }))
                                                          else
                                                            (do (if ((((accdesc.write && (! ((walkparams.ha +++ walkparams.hd) == 0b11#2))) && (walkparams.s2pie == 1#1)) && (permissions.s2dirty == 0#1)) : Bool)
                                                                then
                                                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                      let fault : FaultRecord := { fault with dirtybit := true }
                                                                      (pure { fault with write := true }))
                                                                else (do (pure fault))))))))))))))))))))))) ) : SailM FaultRecord )
  let mro ← (( do (undefined_bool ()) ) : SailM Bool )
  let mro : Bool :=
    if (s2perms.overlay : Bool)
    then (((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) &&& (s2perms.ow +++ (s2perms.ow_rcw +++ s2perms.ow_mmu))) == 0b011#3)
    else ((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) == 0b011#3)
  (pure (fault, mro))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S2HasAlignmentFault (accdesc : AccessDescriptor) (aligned : Bool) (memattrs : MemoryAttributes) : SailM Bool := do
  (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
  then (do (pure false))
  else
    (do (if ((((← (HaveMTEExt ())) && accdesc.tagaccess) && accdesc.write) : Bool)
        then (do (pure (BEq.beq memattrs.memtype MemType_Device)) <&&> (do (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_DEVICETAGSTORE)) Constraint_FAULT))))
        else
          (do (if ((BEq.beq accdesc.acctype AccessType_DCZero) : Bool)
              then (do (pure (BEq.beq memattrs.memtype MemType_Device)))
              else (do (pure ((BEq.beq memattrs.memtype MemType_Device) && (! aligned)))))))))

def AArch64_S2StartLevel (walkparams : S2TTWParams) : SailM Int := do
  let descsizelog2 ← (( do (undefined_int ()) ) : SailM Int )
  let granulebits ← (( do (undefined_int ()) ) : SailM Int )
  let iasize ← (( do (undefined_int ()) ) : SailM Int )
  let s2startlevel ← (( do (undefined_int ()) ) : SailM Int )
  let stride ← (( do (undefined_int ()) ) : SailM Int )
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do let iasize := (AArch64_IASize walkparams.txsz)
        let granulebits := (TGxGranuleBits walkparams.tgx)
        let descsizelog2 := 4
        let stride := (granulebits -i descsizelog2)
        let s2startlevel : Int := (FINAL_LEVEL -i (fdiv_int ((iasize -i 1) -i granulebits) stride))
        let s2startlevel := (s2startlevel +i (BitVec.toNat walkparams.skl))
        (pure s2startlevel))
  else
    (do match walkparams.tgx with
        | .TGx_4KB =>
          (do
            match (walkparams.sl2 +++ walkparams.sl0) with
            | 0b000 => (pure 2)
            | 0b001 => (pure 1)
            | 0b010 => (pure 0)
            | 0b011 => (pure 3)
            | 0b100 => (pure (Neg.neg 1))
            | _ => (do (undefined_int ())))
        | .TGx_16KB =>
          (do
            match walkparams.sl0 with
            | 0b00 => (pure 3)
            | 0b01 => (pure 2)
            | 0b10 => (pure 1)
            | 0b11 => (pure 0)
            | _ => (do (undefined_int ())))
        | .TGx_64KB =>
          (do
            match walkparams.sl0 with
            | 0b00 => (pure 3)
            | 0b01 => (pure 2)
            | 0b10 => (pure 1)
            | _ => (do (undefined_int ())))))

def AArch64_S2InconsistentSL (walkparams : S2TTWParams) : SailM Bool := do
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let levels := (FINAL_LEVEL -i startlevel)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 := 3
  let stride := (granulebits -i descsizelog2)
  let sl_min_iasize := (((levels *i stride) +i granulebits) +i 1)
  let sl_max_iasize := ((sl_min_iasize +i (stride -i 1)) +i 4)
  let iasize := (AArch64_IASize walkparams.txsz)
  (pure ((iasize <b sl_min_iasize) || (iasize >b sl_max_iasize)))

def AArch64_S2InvalidSL (walkparams : S2TTWParams) : SailM Bool := do
  match walkparams.tgx with
  | .TGx_4KB =>
    (do
      let b__0 := (walkparams.sl2 +++ walkparams.sl0)
      (if ((((Sail.BitVec.extractLsb b__0 2 2) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
      then (do (pure true))
      else
        (do (if (((Sail.BitVec.extractLsb b__0 2 1) == (0b11#2 : (BitVec 2))) : Bool)
            then (do (pure true))
            else
              (do (if ((b__0 == (0b010#3 : (BitVec 3))) : Bool)
                  then (do (pure ((← (AArch64_PAMax ())) <b 44)))
                  else
                    (do (if ((b__0 == (0b011#3 : (BitVec 3))) : Bool)
                        then (do (pure (! (← (HaveSmallTranslationTableExt ())))))
                        else (do (pure false))))))))))
  | .TGx_16KB =>
    (do
      match walkparams.sl0 with
      | 0b11 => (pure (walkparams.ds == 0#1))
      | 0b10 => (pure ((← (AArch64_PAMax ())) <b 42))
      | _ => (pure false))
  | .TGx_64KB =>
    (do
      match walkparams.sl0 with
      | 0b11 => (pure true)
      | 0b10 => (pure ((← (AArch64_PAMax ())) <b 44))
      | _ => (pure false))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_S2MinTxSZ (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (s1aarch64 : Bool) : SailM Int := do
  let ips ← (( do (AArch64_PAMax ()) ) : SailM Int )
  let ips ← (( do
    (if ((d128 == 0#1) : Bool)
    then
      (do (if ((((← (Have52BitPAExt ())) && (bne tgx TGx_64KB)) && (ds == 0#1)) : Bool)
          then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
          else (do (pure (Min.min 52 (← (AArch64_PAMax ())))))))
    else (do (pure ips))) ) : SailM Int )
  let ips := ips
  let min_txsz : Int := (64 -i ips)
  let min_txsz : Int :=
    if ((! s1aarch64) : Bool)
    then (Min.min min_txsz 24)
    else min_txsz
  let min_txsz := min_txsz
  (pure min_txsz)

def undefined_VMECID_A_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VMECID_A_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_S2OutputMECID (walkparams : S2TTWParams) (paspace : PASpace) (descriptor : (BitVec k_N)) : SailM (BitVec 16) := do
  sail_assert (((Sail.BitVec.length descriptor) == 64) || ((Sail.BitVec.length descriptor) == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26576.31-26576.32"
  (if ((walkparams.emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((bne paspace PAS_Realm) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do let descriptor_amec ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (103 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26584.35-26584.36"
                      (pure ((BitVec.access descriptor 103) : BitVec 1)))
                else (do (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
              (if ((descriptor_amec == 0#1) : Bool)
              then (do (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2))))
              else (do (pure (_get_VMECID_A_EL2_Type_MECID (← readReg VMECID_A_EL2)))))))))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_S2TxSZFaults (walkparams : S2TTWParams) (s1aarch64 : Bool) : SailM Bool := do
  let mintxsz ← (( do (AArch64_S2MinTxSZ walkparams.d128 walkparams.ds walkparams.tgx s1aarch64) ) : SailM Int )
  let maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailM Int )
  (if (((BitVec.toNat walkparams.txsz) <b mintxsz) : Bool)
  then (do (Have52BitPAExt ()) <||> (do (__IMPDEF_boolean "Fault on TxSZ value below minimum")))
  else
    (do (if (((BitVec.toNat walkparams.txsz) >b maxtxsz) : Bool)
        then (do (__IMPDEF_boolean "Fault on TxSZ value above maximum"))
        else (do (pure false)))))

def AArch64_GetS2TLBContext (ss : SecurityState) (ipa : FullAddress) (tg : TGx) : SailM TLBContext := do
  sail_assert (← (EL2Enabled ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:26612.23-26612.24"
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL10 }
  let tlbcontext : TLBContext := { tlbcontext with ipaspace := ipa.paspace }
  let tlbcontext ← (pure { tlbcontext with vmid := (← do (VMID_read ())) })
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := (Sail.BitVec.zeroExtend ipa.address 64) }
  let tlbcontext ← (( do
    (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
    then
      (do (pure { tlbcontext with cnp := (← do
              (if ((BEq.beq ipa.paspace PAS_Secure) : Bool)
              then (do (pure (_get_VSTTBR_EL2_Type_CnP (← readReg VSTTBR_EL2))))
              else (do (pure (_get_VTTBR_EL2_Type_CnP (← (VTTBR_EL2_read ()))))))) }))
    else (do (pure { tlbcontext with cnp := 0#1 }))) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with includes_s1_name := false }
  let tlbcontext : TLBContext := { tlbcontext with includes_s2_name := true }
  (pure { tlbcontext with includes_gpt_name := false })

/-- Type quantifiers: k_N : Nat, 11 < k_N -/
def AArch64_S2ApplyFWBMemAttrs (s1_memattrs : MemoryAttributes) (walkparams : S2TTWParams) (descriptor : (BitVec k_N)) : SailM MemoryAttributes := do
  let s2_device ← (( do (undefined_DeviceType ()) ) : SailM DeviceType )
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let s2_attr : (BitVec 4) := (Sail.BitVec.extractLsb descriptor 5 2)
  let s2_sh ← (( do
    (if ((walkparams.ds == 1#1) : Bool)
    then (do (pure walkparams.sh))
    else
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26640.33-26640.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))) ) : SailM (BitVec 2) )
  let s2_fnxs : (BitVec 1) := ((BitVec.access descriptor 11) : BitVec 1)
  let memattrs ← (( do
    (if ((((BitVec.access s2_attr 2) : BitVec 1) == 0#1) : Bool)
    then
      (do let s2_device ← (( do (DecodeDevice (Sail.BitVec.extractLsb s2_attr 1 0)) ) : SailM DeviceType )
          let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          let memattrs : MemoryAttributes :=
            if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
            then { memattrs with device := (S2CombineS1Device s1_memattrs.device s2_device) }
            else { memattrs with device := s2_device }
          (pure { memattrs with xs := s1_memattrs.xs }))
    else
      (do (if (((Sail.BitVec.extractLsb s2_attr 1 0) == 0b11#2) : Bool)
          then (do (pure s1_memattrs))
          else
            (do (if (((Sail.BitVec.extractLsb s2_attr 1 0) == 0b10#2) : Bool)
                then
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WB } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WB } }
                      let memattrs : MemoryAttributes :=
                        if (((BEq.beq s1_memattrs.memtype MemType_Normal) && (s1_memattrs.inner.attrs != MemAttr_NC)) : Bool)
                        then
                          (let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := s1_memattrs.inner.hints } }
                          { memattrs with inner := { memattrs.inner with transient := s1_memattrs.inner.transient } })
                        else
                          (let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RWA } }
                          { memattrs with inner := { memattrs.inner with transient := false } })
                      let memattrs : MemoryAttributes :=
                        if (((BEq.beq s1_memattrs.memtype MemType_Normal) && (s1_memattrs.outer.attrs != MemAttr_NC)) : Bool)
                        then
                          (let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := s1_memattrs.outer.hints } }
                          { memattrs with outer := { memattrs.outer with transient := s1_memattrs.outer.transient } })
                        else
                          (let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RWA } }
                          { memattrs with outer := { memattrs.outer with transient := false } })
                      (pure { memattrs with xs := 0#1 }))
                else
                  (do (if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
                      then (do (pure s1_memattrs))
                      else
                        (do let cacheability_attr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
                            let cacheability_attr : MemAttrHints := { cacheability_attr with attrs := MemAttr_NC }
                            let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs : MemoryAttributes := { memattrs with inner := cacheability_attr }
                            let memattrs : MemoryAttributes := { memattrs with outer := cacheability_attr }
                            (pure { memattrs with xs := s1_memattrs.xs }))))))))) ) : SailM MemoryAttributes )
  let s2_shareability ← (( do (DecodeShareability s2_sh) ) : SailM Shareability )
  let memattrs : MemoryAttributes := { memattrs with shareability := (S2CombineS1Shareability s1_memattrs.shareability s2_shareability) }
  let memattrs ← (pure { memattrs with tags := (← do (S2MemTagType memattrs s1_memattrs.tags)) })
  let memattrs : MemoryAttributes := { memattrs with notagaccess := (((Sail.BitVec.extractLsb s2_attr 3 1) == 0b111#3) && (BEq.beq memattrs.tags MemTag_AllocationTagged)) }
  let memattrs : MemoryAttributes :=
    if ((s2_fnxs == 1#1) : Bool)
    then { memattrs with xs := 0#1 }
    else memattrs
  (pure { memattrs with shareability := (EffectiveShareability memattrs) })

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2TTBaseAddress (walkparams : S2TTWParams) (paspace : PASpace) (ttbr : (BitVec k_N)) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let levels := (FINAL_LEVEL -i startlevel)
  let tsize : Int := ((iasize -i ((levels *i stride) +i granulebits)) +i descsizelog2)
  let (tablebase, tsize) ← (( do
    (if (((← (Have56BitPAExt ())) && (walkparams.d128 == 1#1)) : Bool)
    then
      (do let tsize : Int := (Max.max tsize 5)
          let tablebase ← (( do
            (if ((BEq.beq paspace PAS_Secure) : Bool)
            then
              (do sail_assert (55 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26712.38-26712.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 (Sail.BitVec.extractLsb ttbr 55 5))))
            else
              (do sail_assert (87 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26715.38-26715.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 ((Sail.BitVec.extractLsb ttbr 87 80) +++ (Sail.BitVec.extractLsb ttbr 47 5)))))) ) : SailM (BitVec 56) )
          (pure (tablebase, tsize)))
    else
      (do let (tablebase, tsize) ← (( do
            (if (((((← (Have52BitPAExt ())) && (BEq.beq walkparams.tgx TGx_64KB)) && (walkparams.ps == 0b110#3)) || (walkparams.ds == 1#1)) : Bool)
            then
              (do let tsize : Int := (Max.max tsize 6)
                  sail_assert (5 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26720.33-26720.34"
                  sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26721.34-26721.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 51 6 ((Sail.BitVec.extractLsb ttbr 5 2) +++ (Sail.BitVec.extractLsb ttbr 47 6)))
                  (pure (tablebase, tsize)))
            else
              (do sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26724.34-26724.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 47 1 (Sail.BitVec.extractLsb ttbr 47 1))
                  (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
          (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
  let tsize := tsize
  (pure (Align_bits tablebase (_shl_int_general 1 tsize)))


end ArmASL.Functions
