import ArmASL.Part10

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def GCSSS2 (_ : Unit) : SailM (BitVec 64) := do
  let outgoing_pointer ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc_ld ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  let accdesc_st ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_STORE) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let incoming_pointer_name ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let outgoing_value ← (( do (Mem_read incoming_pointer_name 8 accdesc_ld) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb outgoing_value 2 0) == 0b101#3) : Bool)
  then
    (do let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 63 3 (BitVec.subInt (Sail.BitVec.extractLsb outgoing_value 63 3) 1))
        let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 2 0 0b000#3)
        let outgoing_value : (BitVec 64) := ((Sail.BitVec.extractLsb outgoing_pointer 63 12) +++ 0b000000000001#12)
        (Mem_set outgoing_pointer 8 accdesc_st outgoing_value)
        (SetCurrentGCSPointer (BitVec.addInt incoming_pointer_name 8))
        let _ : Unit := (GCSSynchronizationBarrier ())
        (pure outgoing_pointer))
  else
    (do (GCSDataCheckException GCSInstType_SS2)
        (pure outgoing_pointer)))

def GCSPOPM (_ : Unit) : SailM (BitVec 64) := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let entry ← (( do (Mem_read ptr 8 accdesc) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb entry 1 0) != 0b00#2) : Bool)
  then (do (GCSDataCheckException GCSInstType_POPM))
  else (do (pure ())))
  let ptr : (BitVec 64) := (BitVec.addInt ptr 8)
  (SetCurrentGCSPointer ptr)
  (pure entry)

def undefined_HFGITR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HFGITR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGITR_EL2_Type_DCZVA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def GetPendingPhysicalSError (_ : Unit) : SailM FaultRecord := do
  (__UNKNOWN_FaultRecord ())

def AArch32_PhysicalSErrorSyndrome (_ : Unit) : SailM (BitVec 16) := do
  let syndrome : (BitVec 32) := (Zeros (n := 32))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let syndrome ← (( do
    (if (((← readReg PSTATE).EL == EL2) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 11 10 (← (AArch32_EncodeAsyncErrorSyndrome errstate))))
          let syndrome : (BitVec 32) := (BitVec.update syndrome 9 (Bit fault.extflag))
          (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6)))
    else
      (do let long_format ← (( do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)) ) : SailM Bool )
          (AArch32_CommonFaultStatus fault long_format))) ) : SailM (BitVec 32) )
  (pure (Sail.BitVec.extractLsb syndrome 15 0))

def AArch64_EncodeAsyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 3) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b000#3)
  | .ErrorState_UEU => (pure 0b001#3)
  | .ErrorState_UEO => (pure 0b010#3)
  | .ErrorState_UER => (pure 0b011#3)
  | .ErrorState_CE => (pure 0b110#3)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 3))

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch64_PhysicalSErrorSyndrome (implicit_esb : Bool) : SailM (BitVec 25) := do
  let syndrome : (BitVec 25) := (Zeros (n := 25))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let errorstate ← (( do (AArch64_PEErrorState fault) ) : SailM ErrorState )
  (if ((BEq.beq errorstate ErrorState_Uncategorized) : Bool)
  then (do (pure (Zeros (n := 25))))
  else
    (do (if ((BEq.beq errorstate ErrorState_IMPDEF) : Bool)
        then
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 1#1))
              (pure (Sail.BitVec.updateSubrange syndrome 23 0 (← (__IMPDEF_bits 24 "IMPDEF ErrorState")))))
        else
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 0#1))
              let syndrome : (BitVec 25) :=
                (BitVec.update syndrome 13
                  (Bit
                    (if (implicit_esb : Bool)
                    then 1#1
                    else 0#1)))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 12 10 (← (AArch64_EncodeAsyncErrorSyndrome errorstate))))
              let syndrome : (BitVec 25) := (BitVec.update syndrome 9 (Bit fault.extflag))
              (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6))))))

def AArch64_PhysicalSErrorTarget (_ : Unit) : SailM (Bool × (BitVec 2)) := do
  let route_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el3 ← (( do
    (if (((← readReg PSTATE).EL != EL3) : Bool)
    then (do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))))
    else (do (pure false))) ) : SailM Bool )
  let route_to_el2 ← (( do
    (if ((←((pure (! route_to_el3)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)))
    else
      (do (if ((←((pure (! route_to_el3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then (do (pure (! (← (IsInHost ())))) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) != 0b00#2))))
          else (do (pure false))))) ) : SailM Bool )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let masked ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    (if ((questionMark == EL3) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 0#1)) <||> (do (pure ((← readReg PSTATE).A == 1#1))))
    else
      (do (if ((questionMark == EL2) : Bool)
          then (do (pure (! route_to_el3)) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) == 0b00#2)) <||> (do (pure ((← readReg PSTATE).A == 1#1)))))
          else
            (do (if ((questionMark == EL1) : Bool)
                then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                else
                  (do (if ((questionMark == EL0) : Bool)
                      then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                      else (do (pure masked))))))))) ) : SailM Bool )
  let masked ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let nmea_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let nmea_bit ← (( do
            let questionMark ← do (pure (← readReg PSTATE).EL)
            (if ((questionMark == EL3) : Bool)
            then (do (pure (_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3))))
            else
              (do (if ((questionMark == EL2) : Bool)
                  then
                    (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                        then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                        else (do (pure 0#1))))
                  else
                    (do (if ((questionMark == EL1) : Bool)
                        then
                          (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                              then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                              else (do (pure 0#1))))
                        else
                          (do (if ((questionMark == EL0) : Bool)
                              then
                                (do (if ((← (IsInHost ())) : Bool)
                                    then
                                      (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                                          else (do (pure 0#1))))
                                    else
                                      (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                                          else (do (pure 0#1))))))
                              else (do (pure nmea_bit))))))))) ) : SailM (BitVec 1) )
          (pure (masked && (nmea_bit == 0#1))))
    else
      (do (if ((←((HaveDoubleFaultExt ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL3))))) : Bool)
          then
            (do let nmea_bit ← (( do (pure ((_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3)) &&& (← (EffectiveEA ())))) ) : SailM (BitVec 1) )
                (pure (masked && (nmea_bit == 0#1))))
          else (do (pure masked))))) ) : SailM Bool )
  let route_masked_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_masked_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (route_masked_to_el2, route_masked_to_el3) ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let route_masked_to_el2 ← (pure ((← (EL2Enabled ())) && (! route_to_el3))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_TMEA (← readReg HCRX_EL2)) == 1#1))) <&&> (do (pure ((← readReg PSTATE).EL == EL1)) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked)) <&&> (do (pure (! (← (IsInHost ())))))))
          let route_masked_to_el3 ← (pure ((←((pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_TMEA (← readReg SCR_EL3)) == 1#1))))) && (! (route_to_el2 || route_masked_to_el2)))) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked))))
          (pure (route_masked_to_el2, route_masked_to_el3)))
    else
      (do let route_masked_to_el2 : Bool := false
          let route_masked_to_el3 : Bool := false
          (pure (route_masked_to_el2, route_masked_to_el3)))) ) : SailM (Bool × Bool) )
  let take_in_el3 ← (( do (pure (((← readReg PSTATE).EL == EL3) && (! masked))) ) : SailM Bool )
  let take_in_el2_0 ← (( do (pure (((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do (IsInHost ())))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let take_in_el1_0 ← (( do (pure ((((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (IsInHost ())))))))) && (! (route_to_el2 || route_masked_to_el2))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let (masked, target_el) ← (( do
    (if (((take_in_el3 || route_to_el3) || route_masked_to_el3) : Bool)
    then
      (do let masked : Bool := false
          let target_el : (BitVec 2) := EL3
          (pure (masked, target_el)))
    else
      (do let (masked, target_el) ← (( do
            (if (((take_in_el2_0 || route_to_el2) || route_masked_to_el2) : Bool)
            then
              (do let masked : Bool := false
                  let target_el : (BitVec 2) := EL2
                  (pure (masked, target_el)))
            else
              (do let (masked, target_el) ← (( do
                    (if (take_in_el1_0 : Bool)
                    then
                      (do let masked : Bool := false
                          let target_el : (BitVec 2) := EL1
                          (pure (masked, target_el)))
                    else
                      (do let masked : Bool := true
                          let target_el ← (__UNKNOWN_bits 2)
                          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
                  (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
  (pure (masked, target_el))

def undefined_DISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DISR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSESR_EL2_Type_IDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def undefined_DISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DISR_Type := value_name
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DISR r

def ExternalDebugInterruptsDisabled (target : (BitVec 2)) : SailM Bool := do
  let int_dis ← (( do (undefined_bool ()) ) : SailM Bool )
  let ss ← (( do (SecurityStateAtEL target) ) : SailM SecurityState )
  (if ((← (Havev8p4Debug ())) : Bool)
  then
    (do (if ((((BitVec.access (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) 0) : BitVec 1) == 1#1) : Bool)
        then
          (do match ss with
              | .SS_NonSecure => (do (ExternalInvasiveDebugEnabled ()))
              | .SS_Secure => (do (ExternalSecureInvasiveDebugEnabled ()))
              | .SS_Realm => (do (ExternalRealmInvasiveDebugEnabled ()))
              | .SS_Root => (do (ExternalRootInvasiveDebugEnabled ())))
        else (do (pure false))))
  else
    (do let questionMark := target
        (if ((questionMark == EL3) : Bool)
        then (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) == 0b11#2)) <&&> (do (ExternalSecureInvasiveDebugEnabled ())))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (do
                      let b__0 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                      (if (((Sail.BitVec.extractLsb b__0 1 1) == (1#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else (do (pure false)))) <&&> (do
                      (ExternalInvasiveDebugEnabled ())))
              else
                (do (if ((questionMark == EL1) : Bool)
                    then
                      (do (if ((BEq.beq ss SS_Secure) : Bool)
                          then
                            (do (do
                                  let b__1 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                                  (if (((Sail.BitVec.extractLsb b__1 1 1) == (1#1 : (BitVec 1))) : Bool)
                                  then (do (pure true))
                                  else (do (pure false)))) <&&> (do
                                  (ExternalSecureInvasiveDebugEnabled ())))
                          else (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) != 0b00#2)) <&&> (do (ExternalInvasiveDebugEnabled ())))))
                    else (do (pure int_dis)))))))))

def ClearPendingPhysicalSError (_ : Unit) : Unit :=
  ()

def IsSynchronizablePhysicalSErrorPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch64_ESBOperation (_ : Unit) : SailM Unit := do
  let implicit_esb ← (( do (undefined_bool ()) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let (masked, target_el) ← (( do
    let (tup__0, tup__1) ← do (AArch64_PhysicalSErrorTarget ())
    let masked : Bool := tup__0
    let target_el : (BitVec 2) := tup__1
    (pure (masked, target_el)) ) : SailM (Bool × (BitVec 2)) )
  let intdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled target_el)) ) : SailM Bool )
  let masked : Bool := (masked || intdis)
  (if ((←((pure masked) <&&> (do
       (IsSynchronizablePhysicalSErrorPending ())))) : Bool)
  then
    (do (if ((← (ELUsingAArch32 (← (S1TranslationRegime__1 ())))) : Bool)
        then
          (do let syndrome : (BitVec 32) := (Zeros (n := 32))
              let syndrome : (BitVec 32) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 15 0 (← (AArch32_PhysicalSErrorSyndrome ()))))
              (DISR_write (Mk_DISR_Type syndrome)))
        else
          (do let implicit_esb : Bool := false
              let syndrome : (BitVec 64) := (Zeros (n := 64))
              let syndrome : (BitVec 64) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 24 0 (← (AArch64_PhysicalSErrorSyndrome implicit_esb))))
              writeReg DISR_EL1 (Mk_DISR_EL1_Type syndrome)))
        (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))

def undefined_VDFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_VSESR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSESR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def VDFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VDFSR ) : SailM VDFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VSESR_EL2) 0 32)))

def undefined_VDISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VDISR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_VDISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def VDISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VDISR_Type := value_name
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VDISR r

def AArch64_vESBOperation (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33362.63-33362.64"
  let vSEI_enabled ← (( do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vSEI_pending ← (( do (pure vSEI_enabled) <&&> (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vintdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled EL1)) ) : SailM Bool )
  let vmasked ← (( do (pure vintdis) <||> (do (pure ((← readReg PSTATE).A == 1#1))) ) : SailM Bool )
  (if ((vSEI_pending && vmasked) : Bool)
  then
    (do (if ((← (ELUsingAArch32 EL1)) : Bool)
        then
          (do let target : (BitVec 32) := (Zeros (n := 32))
              let target : (BitVec 32) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 15 14 (Sail.BitVec.extractLsb (← (VDFSR_read ())) 15 14)))
              let target ← (pure (BitVec.update target 12 (Bit ((BitVec.access (← (VDFSR_read ())) 12) : BitVec 1))))
              let target ← (pure (BitVec.update target 9 (Bit (_get_TTBCR_Type_EAE (← (TTBCR_read ()))))))
              let target ← (( do
                (if (((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange target 5 0 0b010001#6)))
                else
                  (do let target : (BitVec 32) := (Sail.BitVec.updateSubrange target 10 10 (Sail.BitVec.extractLsb 0b10110#5 4 4))
                      (pure (Sail.BitVec.updateSubrange target 3 0 (Sail.BitVec.extractLsb 0b10110#5 3 0))))) ) : SailM (BitVec 32) )
              (VDISR_write (Mk_VDISR_Type target)))
        else
          (do let target : (BitVec 64) := (Zeros (n := 64))
              let target : (BitVec 64) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 24 0 (Sail.BitVec.extractLsb (← readReg VSESR_EL2) 24 0)))
              writeReg VDISR_EL2 (Mk_VDISR_EL2_Type target)))
        writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1))
  else (do (pure ())))

def undefined_RVBAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTEL0ACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTNSAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICONTROL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDAA32PFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDDFR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDHSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_TYPER2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_TYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_CLRLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INMIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INVALLR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_INVLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_ISENABLER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_PROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_SETLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_SYNCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VPENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VPROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VSGIPENDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VSGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_WAKER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CREADR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CWRITER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_SGIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_TYPER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_MCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCFGR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCGCR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMIIDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMMIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPCSCTL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMVCIDSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCFGR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCFGR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCFGR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCFGR ) : SailM AMCFGR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCFGR_EL0) 0 32)))

def AMCFGR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCFGR_Type := value_name
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCFGR r

def undefined_AMCGCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCGCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCGCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCGCR ) : SailM AMCGCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCGCR_EL0) 0 32)))

def AMCGCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCGCR_Type := value_name
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCGCR r

def undefined_AMCNTENCLR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR0 ) : SailM AMCNTENCLR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR0_EL0) 0 32)))

def AMCNTENCLR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR0_Type := value_name
  writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR0 r

def undefined_AMCNTENCLR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR1 ) : SailM AMCNTENCLR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR1_EL0) 0 32)))

def AMCNTENCLR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR1_Type := value_name
  writeReg AMCNTENCLR1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR1 r

def undefined_AMCNTENSET0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET0 ) : SailM AMCNTENSET0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET0_EL0) 0 32)))

def AMCNTENSET0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET0_Type := value_name
  writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET0 r

def undefined_AMCNTENSET1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET1 ) : SailM AMCNTENSET1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET1_EL0) 0 32)))

def AMCNTENSET1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET1_Type := value_name
  writeReg AMCNTENSET1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET1 r

def undefined_AMCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCR ) : SailM AMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCR_EL0) 0 32)))

def AMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCR_Type := value_name
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCR r

def undefined_AMUSERENR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMUSERENR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMUSERENR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMUSERENR ) : SailM AMUSERENR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMUSERENR_EL0) 0 32)))

def AMUSERENR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMUSERENR_Type := value_name
  writeReg AMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg AMUSERENR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMUSERENR r

def undefined_CCSIDR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR2 ) : SailM CCSIDR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR2_EL1) 0 32)))

def CCSIDR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR2_Type := value_name
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR2 r

def undefined_CCSIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR ) : SailM CCSIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR_EL1) 0 32)))

def CCSIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR_Type := value_name
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR r

def undefined_CNTHCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHCTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHCTL ) : SailM CNTHCTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHCTL_EL2) 0 32)))

def CNTHCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHCTL_Type := value_name
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHCTL r

def undefined_CNTHPS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHPS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHPS_CTL ) : SailM CNTHPS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHPS_CTL_EL2) 0 32)))

def CNTHPS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHPS_CTL_Type := value_name
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHPS_CTL r

def undefined_CNTHVS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHVS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHVS_CTL ) : SailM CNTHVS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHVS_CTL_EL2) 0 32)))

def CNTHVS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHVS_CTL_Type := value_name
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHVS_CTL r

def undefined_CNTHV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHV_CTL ) : SailM CNTHV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHV_CTL_EL2) 0 32)))

def CNTHV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHV_CTL_Type := value_name
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHV_CTL r

def CNTKCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTKCTL_Type := value_name
  writeReg CNTKCTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTKCTL_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTKCTL r

def undefined_CNTV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTV_CTL ) : SailM CNTV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTV_CTL_EL0) 0 32)))

def CNTV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTV_CTL_Type := value_name
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTV_CTL r

def CPACR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CPACR_Type := value_name
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CPACR r

def undefined_CSSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CSSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def CSSELR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CSSELR_NS ) : SailM CSSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CSSELR_EL1) 0 32)))

def CSSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CSSELR_Type ()) ) : SailM CSSELR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CSSELR_S)
  else (do (CSSELR_NS_read ())))

def CSSELR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  writeReg CSSELR_EL1 (Sail.BitVec.updateSubrange (← readReg CSSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CSSELR_NS r

def CSSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CSSELR_S r)
  else (do (CSSELR_NS_write r)))

def undefined_CTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CTR ) : SailM CTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CTR_EL0) 0 32)))

def CTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CTR_Type := value_name
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CTR r

def undefined_DBGAUTHSTATUS_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGAUTHSTATUS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGAUTHSTATUS ) : SailM DBGAUTHSTATUS_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGAUTHSTATUS_EL1) 0 32)))

def DBGAUTHSTATUS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGAUTHSTATUS_Type := value_name
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGAUTHSTATUS r

def undefined_DBGCLAIMCLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMCLR ) : SailM DBGCLAIMCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMCLR_EL1) 0 32)))

def DBGCLAIMCLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMCLR_Type := value_name
  writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMCLR r

def undefined_DBGCLAIMSET_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMSET_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMSET ) : SailM DBGCLAIMSET_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMSET_EL1) 0 32)))

def DBGCLAIMSET_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMSET_Type := value_name
  writeReg DBGCLAIMSET_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMSET_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMSET r

def undefined_MDCCINT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDCCINT_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGDCCINT_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDCCINT ) : SailM DBGDCCINT_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDCCINT_EL1) 0 32)))

def DBGDCCINT_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDCCINT_Type := value_name
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGDCCINT r

def undefined_MDRAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDRAR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def DBGDRAR_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _DBGDRAR ) : SailM DBGDRAR_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg MDRAR_EL1) 0 64)))

def DBGDRAR_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : DBGDRAR_Type := value_name
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _DBGDRAR r

def DBGOSDLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSDLR_Type := value_name
  writeReg OSDLR_EL1 (Sail.BitVec.updateSubrange (← readReg OSDLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSDLR r

def DBGOSLSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSLSR_Type := value_name
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSLSR r

def DBGPRCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGPRCR_Type := value_name
  writeReg DBGPRCR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGPRCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGPRCR r

def undefined_DBGVCR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGVCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGVCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGVCR ) : SailM DBGVCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGVCR32_EL2) 0 32)))

def DBGVCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGVCR_Type := value_name
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGVCR r

def DFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DFSR_NS ) : SailM DFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ESR_EL1) 0 32)))

def DFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_DFSR_Type ()) ) : SailM DFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg DFSR_S)
  else (do (DFSR_NS_read ())))

def DISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DISR ) : SailM DISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DISR_EL1) 0 32)))

def DSPSR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DSPSR2 ) : SailM DSPSR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DSPSR_EL0) 32 32)))

def EDECCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDECCR_Type := value_name
  writeReg OSECCR_EL1 (Sail.BitVec.updateSubrange (← readReg OSECCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _EDECCR r

def EDSCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDSCR2_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _EDSCR2 r

def undefined_ERRIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRIDR ) : SailM ERRIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRIDR_EL1) 0 32)))

def ERRIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRIDR_Type := value_name
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRIDR r

def undefined_ERRSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRSELR ) : SailM ERRSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRSELR_EL1) 0 32)))

def ERRSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRSELR_Type := value_name
  writeReg ERRSELR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRSELR r

def HCPTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCPTR_Type := value_name
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCPTR r

def HCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR2_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 63 32 (BitVec.slice r 0 32))
  writeReg _HCR2 r

def HDCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HDCR_Type := value_name
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HDCR r

def undefined_RMR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HRMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HRMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HRMR ) : SailM HRMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg RMR_EL2) 0 32)))

def HRMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HRMR_Type := value_name
  writeReg RMR_EL2 (Sail.BitVec.updateSubrange (← readReg RMR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HRMR r

def HSCTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSCTLR_Type := value_name
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSCTLR r

def undefined_HSTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HSTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HSTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HSTR ) : SailM HSTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HSTR_EL2) 0 32)))

def HSTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSTR_Type := value_name
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSTR r

def undefined_HTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTCR ) : SailM HTCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL2) 0 32)))

def HTCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTCR_Type := value_name
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTCR r

def undefined_TRFCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HTRFCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTRFCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTRFCR ) : SailM HTRFCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TRFCR_EL2) 0 32)))

def HTRFCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTRFCR_Type := value_name
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTRFCR r

def HVBAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HVBAR_Type := value_name
  writeReg VBAR_EL2 (Sail.BitVec.updateSubrange (← readReg VBAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HVBAR r

def undefined_ICC_ASGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_ASGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_ASGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_ASGI1R ) : SailM ICC_ASGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_ASGI1R_EL1) 0 64)))

def ICC_ASGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_ASGI1R_Type := value_name
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_ASGI1R r

def undefined_ICC_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR0 ) : SailM ICC_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR0_EL1) 0 32)))

def ICC_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR0_Type := value_name
  writeReg ICC_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR0 r

def undefined_ICC_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_NS ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_NS) 0 32)))

def ICC_BPR1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_S ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_S) 0 32)))

def ICC_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_BPR1_Type ()) ) : SailM ICC_BPR1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_read ()))
  else (do (ICC_BPR1_NS_read ())))

def ICC_BPR1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_NS r

def ICC_BPR1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_S r

def ICC_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_write r))
  else (do (ICC_BPR1_NS_write r)))

def undefined_ICC_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_CTLR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_NS ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_NS) 0 32)))

def ICC_CTLR_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_S ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_S) 0 32)))

def ICC_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_CTLR_Type ()) ) : SailM ICC_CTLR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_read ()))
  else (do (ICC_CTLR_NS_read ())))

def ICC_CTLR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_NS r

def ICC_CTLR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_S r

def ICC_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_write r))
  else (do (ICC_CTLR_NS_write r)))

def undefined_ICC_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_DIR ) : SailM ICC_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_DIR_EL1) 0 32)))

def ICC_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_DIR_Type := value_name
  writeReg ICC_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_DIR r

def undefined_ICC_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR0 ) : SailM ICC_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR0_EL1) 0 32)))

def ICC_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR0_Type := value_name
  writeReg ICC_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR0 r

def undefined_ICC_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR1 ) : SailM ICC_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR1_EL1) 0 32)))

def ICC_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR1_Type := value_name
  writeReg ICC_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR1 r

def undefined_ICC_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR0 ) : SailM ICC_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR0_EL1) 0 32)))

def ICC_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR0_Type := value_name
  writeReg ICC_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR0 r

def undefined_ICC_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR1 ) : SailM ICC_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR1_EL1) 0 32)))

def ICC_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR1_Type := value_name
  writeReg ICC_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR1 r

def undefined_ICC_SRE_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HSRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HSRE ) : SailM ICC_HSRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL2) 0 32)))

def ICC_HSRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HSRE_Type := value_name
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HSRE r

def undefined_ICC_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR0 ) : SailM ICC_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR0_EL1) 0 32)))

def ICC_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR0_Type := value_name
  writeReg ICC_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR0 r

def undefined_ICC_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR1 ) : SailM ICC_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR1_EL1) 0 32)))

def ICC_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR1_Type := value_name
  writeReg ICC_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR1 r

def undefined_ICC_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN0 ) : SailM ICC_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN0_EL1) 0 32)))

def ICC_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN0_Type := value_name
  writeReg ICC_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN0 r

def undefined_ICC_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_NS ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_NS) 0 32)))

def ICC_IGRPEN1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_S ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_S) 0 32)))

def ICC_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_IGRPEN1_Type ()) ) : SailM ICC_IGRPEN1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_read ()))
  else (do (ICC_IGRPEN1_NS_read ())))

def ICC_IGRPEN1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_NS r

def ICC_IGRPEN1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_S r

def ICC_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_write r))
  else (do (ICC_IGRPEN1_NS_write r)))

def undefined_ICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_PMR ) : SailM ICC_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_PMR_EL1) 0 32)))

def ICC_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_PMR_Type := value_name
  writeReg ICC_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_PMR r

def undefined_ICC_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_RPR ) : SailM ICC_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_RPR_EL1) 0 32)))

def ICC_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_RPR_Type := value_name
  writeReg ICC_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_RPR r

def undefined_ICC_SGI0R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI0R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI0R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI0R ) : SailM ICC_SGI0R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI0R_EL1) 0 64)))

def ICC_SGI0R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI0R_Type := value_name
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI0R r

def undefined_ICC_SGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI1R ) : SailM ICC_SGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI1R_EL1) 0 64)))

def ICC_SGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI1R_Type := value_name
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI1R r

def undefined_ICC_SRE_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_SRE_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_NS ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_NS) 0 32)))

def ICC_SRE_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_S ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_S) 0 32)))

def ICC_SRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_SRE_Type ()) ) : SailM ICC_SRE_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_read ()))
  else (do (ICC_SRE_NS_read ())))

def ICC_SRE_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_NS r

def ICC_SRE_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_S r

def ICC_SRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_write r))
  else (do (ICC_SRE_NS_write r)))

def undefined_ICH_EISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_EISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_EISR ) : SailM ICH_EISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_EISR_EL2) 0 32)))

def ICH_EISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_EISR_Type := value_name
  writeReg ICH_EISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_EISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_EISR r

def undefined_ICH_ELRSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_ELRSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_ELRSR ) : SailM ICH_ELRSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_ELRSR_EL2) 0 32)))

def ICH_ELRSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_ELRSR_Type := value_name
  writeReg ICH_ELRSR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_ELRSR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_ELRSR r

def undefined_ICH_HCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_HCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_HCR ) : SailM ICH_HCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_HCR_EL2) 0 32)))

def ICH_HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_HCR_Type := value_name
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_HCR r

def undefined_ICH_MISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_MISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_MISR ) : SailM ICH_MISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_MISR_EL2) 0 32)))

def ICH_MISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_MISR_Type := value_name
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_MISR r

def undefined_ICH_VMCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VMCR ) : SailM ICH_VMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VMCR_EL2) 0 32)))

def ICH_VMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VMCR_Type := value_name
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VMCR r

def undefined_ICH_VTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VTR ) : SailM ICH_VTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VTR_EL2) 0 32)))

def ICH_VTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VTR_Type := value_name
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VTR r

def undefined_ICV_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR0 ) : SailM ICV_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR0_EL1) 0 32)))

def ICV_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR0_Type := value_name
  writeReg ICV_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR0 r

def undefined_ICV_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR1 ) : SailM ICV_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR1_EL1) 0 32)))

def ICV_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR1_Type := value_name
  writeReg ICV_BPR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR1 r

def undefined_ICV_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_CTLR ) : SailM ICV_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_CTLR_EL1) 0 32)))

def ICV_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_CTLR_Type := value_name
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_CTLR r

def undefined_ICV_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_DIR ) : SailM ICV_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_DIR_EL1) 0 32)))

def ICV_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_DIR_Type := value_name
  writeReg ICV_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_DIR r

def undefined_ICV_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR0 ) : SailM ICV_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR0_EL1) 0 32)))

def ICV_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR0_Type := value_name
  writeReg ICV_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR0 r

def undefined_ICV_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR1 ) : SailM ICV_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR1_EL1) 0 32)))

def ICV_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR1_Type := value_name
  writeReg ICV_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR1 r

def undefined_ICV_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR0 ) : SailM ICV_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR0_EL1) 0 32)))

def ICV_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR0_Type := value_name
  writeReg ICV_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR0 r

def undefined_ICV_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR1 ) : SailM ICV_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR1_EL1) 0 32)))

def ICV_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR1_Type := value_name
  writeReg ICV_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR1 r

def undefined_ICV_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR0 ) : SailM ICV_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR0_EL1) 0 32)))

def ICV_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR0_Type := value_name
  writeReg ICV_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR0 r

def undefined_ICV_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR1 ) : SailM ICV_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR1_EL1) 0 32)))

def ICV_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR1_Type := value_name
  writeReg ICV_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR1 r

def undefined_ICV_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN0 ) : SailM ICV_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN0_EL1) 0 32)))

def ICV_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN0_Type := value_name
  writeReg ICV_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN0 r

def undefined_ICV_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN1 ) : SailM ICV_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN1_EL1) 0 32)))

def ICV_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN1_Type := value_name
  writeReg ICV_IGRPEN1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN1 r

def undefined_ICV_PMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_PMR ) : SailM ICV_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_PMR_EL1) 0 32)))

def ICV_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_PMR_Type := value_name
  writeReg ICV_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_PMR r

def undefined_ICV_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_RPR ) : SailM ICV_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_RPR_EL1) 0 32)))

def ICV_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_RPR_Type := value_name
  writeReg ICV_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_RPR r

def ID_AFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_AFR0 ) : SailM ID_AFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_AFR0_EL1) 0 32)))

def ID_AFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_AFR0_Type := value_name
  writeReg ID_AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_AFR0 r

def undefined_ID_DFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_DFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_DFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_DFR1 ) : SailM ID_DFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_DFR1_EL1) 0 32)))

def ID_DFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_DFR1_Type := value_name
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_DFR1 r

def undefined_ID_ISAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR0 ) : SailM ID_ISAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR0_EL1) 0 32)))

def ID_ISAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR0_Type := value_name
  writeReg ID_ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR0 r

def undefined_ID_ISAR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR5 ) : SailM ID_ISAR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR5_EL1) 0 32)))

def ID_ISAR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR5_Type := value_name
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR5 r

def undefined_ID_MMFR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR5 ) : SailM ID_MMFR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR5_EL1) 0 32)))

def ID_MMFR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR5_Type := value_name
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR5 r

def undefined_ID_PFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR2 ) : SailM ID_PFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR2_EL1) 0 32)))

def ID_PFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR2_Type := value_name
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR2 r

def IFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _IFSR_NS ) : SailM IFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg IFSR32_EL2) 0 32)))

def IFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_IFSR_Type ()) ) : SailM IFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg IFSR_S)
  else (do (IFSR_NS_read ())))

def undefined_ISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ISR ) : SailM ISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ISR_EL1) 0 32)))

def ISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ISR_Type := value_name
  writeReg ISR_EL1 (Sail.BitVec.updateSubrange (← readReg ISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ISR r

def undefined_MPIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MPIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MPIDR ) : SailM MPIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MPIDR_EL1) 0 32)))

def MPIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MPIDR_Type := value_name
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MPIDR r

def undefined_MVFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR2 ) : SailM MVFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR2_EL1) 0 32)))

def MVFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR2_Type := value_name
  writeReg MVFR2_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR2 r

def Mk_AMCFGR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCGCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENCLR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENCLR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENSET0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCNTENSET1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_AMUSERENR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CCSIDR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CCSIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHCTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHPS_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHVS_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTHV_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CNTV_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CSSELR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_CTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGAUTHSTATUS_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGCLAIMCLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGCLAIMSET_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGDCCINT_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_DBGDRAR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_DBGVCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ERRIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ERRSELR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HRMR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HSTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HTCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_HTRFCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_ASGI1R_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_BPR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_BPR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_CTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_DIR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_EOIR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_EOIR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_HPPIR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_HPPIR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_HSRE_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_IAR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_IAR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_IGRPEN0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_IGRPEN1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_PMR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_RPR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICC_SGI0R_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SGI1R_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SRE_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_EISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_ELRSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_HCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_MISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_VMCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICH_VTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_BPR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_BPR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_CTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_DIR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_EOIR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_EOIR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_HPPIR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_HPPIR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_IAR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_IAR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_IGRPEN0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_IGRPEN1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_PMR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ICV_RPR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_DFR1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_ISAR0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_ISAR5_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_MMFR5_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_PFR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_MPIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_MVFR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PAR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMCNTEN_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMINTEN_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMOVS_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSELR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMSWINC_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMUSERENR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PRRR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_RMR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_TRFCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_TTBCR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_VMPIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_VTCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_PAR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def PAR_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_PAR_Type ()) ) : SailM PAR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg PAR_S)
  else (do readReg PAR_NS))

def PAR_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : PAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg PAR_S r)
  else (do writeReg PAR_NS r))

def PMCCFILTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCCFILTR_Type := value_name
  writeReg PMCCFILTR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCCFILTR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCCFILTR r

def undefined_PMCNTEN_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def PMCNTEN_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _PMCNTEN ) : SailM PMCNTEN_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg PMCNTENSET_EL0) 0 64)))

def PMCNTEN_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMCNTEN_Type := value_name
  writeReg PMCNTENSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMCNTENSET_EL0) 63 0 (BitVec.slice r 0 64))
  writeReg _PMCNTEN r

def PMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCR_Type := value_name
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCR r

def undefined_PMINTENSET_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMINTEN_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def PMINTEN_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _PMINTEN ) : SailM PMINTEN_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg PMINTENSET_EL1) 0 64)))

def PMINTEN_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMINTEN_Type := value_name
  writeReg PMINTENSET_EL1 (Sail.BitVec.updateSubrange (← readReg PMINTENSET_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _PMINTEN r

def undefined_PMOVS_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def PMOVS_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _PMOVS ) : SailM PMOVS_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg PMOVSSET_EL0) 0 64)))

def PMOVS_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMOVS_Type := value_name
  writeReg PMOVSSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSSET_EL0) 63 0 (BitVec.slice r 0 64))
  writeReg _PMOVS r

def undefined_PMSELR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMSELR ) : SailM PMSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMSELR_EL0) 0 32)))

def PMSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMSELR_Type := value_name
  writeReg PMSELR_EL0 (Sail.BitVec.updateSubrange (← readReg PMSELR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMSELR r

def undefined_PMSWINC_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSWINC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMSWINC_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMSWINC ) : SailM PMSWINC_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMSWINC_EL0) 0 32)))

def PMSWINC_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMSWINC_Type := value_name
  writeReg PMSWINC_EL0 (Sail.BitVec.updateSubrange (← readReg PMSWINC_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMSWINC r

def undefined_PMUSERENR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMUSERENR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMUSERENR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMUSERENR ) : SailM PMUSERENR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMUSERENR_EL0) 0 32)))

def PMUSERENR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMUSERENR_Type := value_name
  writeReg PMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg PMUSERENR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMUSERENR r

def undefined_PRRR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PRRR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PRRR_NS ) : SailM PRRR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MAIR_EL1) 0 32)))

def PRRR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_PRRR_Type ()) ) : SailM PRRR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg PRRR_S)
  else (do (PRRR_NS_read ())))

def PRRR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PRRR_Type := value_name
  writeReg MAIR_EL1 (Sail.BitVec.updateSubrange (← readReg MAIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _PRRR_NS r

def PRRR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PRRR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg PRRR_S r)
  else (do (PRRR_NS_write r)))

def undefined_RMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_RMR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_RMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def RMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _RMR ) : SailM RMR_Type )
  (if ((HaveEL EL3) : Bool)
  then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg RMR_EL3) 0 32))))
  else (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg RMR_EL1) 0 32)))))

def RMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : RMR_Type := value_name
  (if ((HaveEL EL3) : Bool)
  then (do writeReg RMR_EL3 (Sail.BitVec.updateSubrange (← readReg RMR_EL3) 31 0 (BitVec.slice r 0 32)))
  else (do writeReg RMR_EL1 (Sail.BitVec.updateSubrange (← readReg RMR_EL1) 31 0 (BitVec.slice r 0 32))))
  writeReg _RMR r

def SCTLR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SCTLR_Type := value_name
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _SCTLR_NS r

def SCTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SCTLR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg SCTLR_S r)
  else (do (SCTLR_NS_write r)))

def SDER32_EL3_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : SDER32_EL3_Type := value_name
  writeReg SDER32_EL2 (Sail.BitVec.updateSubrange (← readReg SDER32_EL2) 63 0 (BitVec.slice r 0 64))
  writeReg _SDER32_EL3 r

def SDER_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SDER_Type := value_name
  (if ((HaveEL EL3) : Bool)
  then (do (SDER32_EL3_write (Mk_SDER32_EL3_Type (set_slice 32 (← (SDER32_EL3_read ())) 0 (BitVec.slice r 0 32)))))
  else (do writeReg SDER32_EL2 (Sail.BitVec.updateSubrange (← readReg SDER32_EL2) 31 0 (BitVec.slice r 0 32))))
  writeReg _SDER r

def undefined_TRFCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TRFCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def TRFCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _TRFCR ) : SailM TRFCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TRFCR_EL1) 0 32)))

def TRFCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : TRFCR_Type := value_name
  writeReg TRFCR_EL1 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _TRFCR r

def undefined_TTBCR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def TTBCR2_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _TTBCR2_NS ) : SailM TTBCR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL1) 32 32)))

def TTBCR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_TTBCR2_Type ()) ) : SailM TTBCR2_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBCR2_S)
  else (do (TTBCR2_NS_read ())))

def TTBCR2_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : TTBCR2_Type := value_name
  writeReg TCR_EL1 (Sail.BitVec.updateSubrange (← readReg TCR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _TTBCR2_NS r

def TTBCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : TTBCR2_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg TTBCR2_S r)
  else (do (TTBCR2_NS_write r)))

def TTBCR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : TTBCR_Type := value_name
  writeReg TCR_EL1 (Sail.BitVec.updateSubrange (← readReg TCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _TTBCR_NS r

def TTBCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : TTBCR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg TTBCR_S r)
  else (do (TTBCR_NS_write r)))

def TTBR0_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : TTBR0_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg TTBR0_S r)
  else (do writeReg TTBR0_NS r))

def TTBR1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : TTBR1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg TTBR1_S r)
  else (do writeReg TTBR1_NS r))

def VBAR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VBAR_Type := value_name
  writeReg VBAR_EL1 (Sail.BitVec.updateSubrange (← readReg VBAR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _VBAR_NS r

def VBAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VBAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg VBAR_S r)
  else (do (VBAR_NS_write r)))

def VDFSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VDFSR_Type := value_name
  writeReg VSESR_EL2 (Sail.BitVec.updateSubrange (← readReg VSESR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VDFSR r

def VDISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VDISR ) : SailM VDISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VDISR_EL2) 0 32)))

def undefined_VMPIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_VMPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def VMPIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VMPIDR ) : SailM VMPIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VMPIDR_EL2) 0 32)))

def VMPIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VMPIDR_Type := value_name
  writeReg VMPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VMPIDR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VMPIDR r

def undefined_VPIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_VPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def VPIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VPIDR ) : SailM VPIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VPIDR_EL2) 0 32)))

def VPIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VPIDR_Type := value_name
  writeReg VPIDR_EL2 (Sail.BitVec.updateSubrange (← readReg VPIDR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VPIDR r

def undefined_VTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def VTCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VTCR ) : SailM VTCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VTCR_EL2) 0 32)))

def VTCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VTCR_Type := value_name
  writeReg VTCR_EL2 (Sail.BitVec.updateSubrange (← readReg VTCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VTCR r

def _update_DBGCLAIMCLR_Type_CLAIM (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_DBGCLAIMSET_Type_CLAIM (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_DBGDCCINT_Type_RX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_DBGDCCINT_Type_TX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_HRMR_Type_RR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_HSTR_Type_T0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_HSTR_Type_T1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_HSTR_Type_T10 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_HSTR_Type_T11 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_HSTR_Type_T12 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_HSTR_Type_T13 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _update_HSTR_Type_T15 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_HSTR_Type_T2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_HSTR_Type_T3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_HSTR_Type_T5 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_HSTR_Type_T6 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_HSTR_Type_T7 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_HSTR_Type_T8 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_HSTR_Type_T9 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_HTRFCR_Type_E0HTRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_HTRFCR_Type_E2TRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICC_HSRE_Type_DFB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICC_HSRE_Type_DIB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICC_HSRE_Type_SRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICC_IGRPEN0_Type_Enable (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICC_IGRPEN1_Type_Enable (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICC_SRE_Type_DFB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICC_SRE_Type_DIB (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICC_SRE_Type_SRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICH_EISR_Type_Status0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICH_EISR_Type_Status1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICH_EISR_Type_Status10 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_ICH_EISR_Type_Status11 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_ICH_EISR_Type_Status12 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_ICH_EISR_Type_Status13 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _update_ICH_EISR_Type_Status14 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _update_ICH_EISR_Type_Status15 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_ICH_EISR_Type_Status2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICH_EISR_Type_Status3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_ICH_EISR_Type_Status4 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_ICH_EISR_Type_Status5 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_ICH_EISR_Type_Status6 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_ICH_EISR_Type_Status7 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_ICH_EISR_Type_Status8 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_ICH_EISR_Type_Status9 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_ICH_HCR_Type_EOIcount (v : (BitVec 32)) (x : (BitVec 5)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 27 x)

def _update_ICH_HCR_Type_En (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICH_HCR_Type_LRENPIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICH_HCR_Type_NPIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_ICH_HCR_Type_TALL0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_ICH_HCR_Type_TALL1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_ICH_HCR_Type_TDIR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _update_ICH_HCR_Type_TSEI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _update_ICH_HCR_Type_UIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICH_HCR_Type_VGrp0DIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_ICH_HCR_Type_VGrp0EIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_ICH_HCR_Type_VGrp1DIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_ICH_HCR_Type_VGrp1EIE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_ICH_HCR_Type_vSGIEOICount (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_ICH_MISR_Type_EOI (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICH_MISR_Type_LRENP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICH_MISR_Type_NP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_ICH_MISR_Type_VGrp0D (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_ICH_MISR_Type_VGrp0E (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_ICH_MISR_Type_VGrp1D (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _update_ICH_MISR_Type_VGrp1E (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_ICV_IGRPEN0_Type_Enable (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICV_IGRPEN1_Type_Enable (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_RMR_Type_RR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_TRFCR_Type_E0TRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_TRFCR_Type_E1TRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_VMPIDR_Type_Aff0 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_VMPIDR_Type_Aff1 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def _update_VMPIDR_Type_Aff2 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 16 x)

def _update_VPIDR_Type_Architecture (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_VPIDR_Type_Implementer (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 24 x)

def _update_VPIDR_Type_PartNum (v : (BitVec 32)) (x : (BitVec 12)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 4 x)

def _update_VPIDR_Type_Revision (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_VPIDR_Type_Variant (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)


end ArmASL.Functions
