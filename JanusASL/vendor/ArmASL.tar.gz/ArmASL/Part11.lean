import ArmASL.Part10

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def Mem_read__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) : SailM (BitVec (size * 8)) := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let halfsize := (Int.ediv size 2)
  let value_name ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
    then
      (do let lowhalf ← (( do (AArch64_MemSingle_read__1 address halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          let highhalf ← (( do (AArch64_MemSingle_read__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          (pure (highhalf +++ lowhalf)))
    else
      (do (if ((←((HaveLSE2Ext ()) <&&> (do
               (AllInAlignedQuantity address size 16)))) : Bool)
          then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
          else
            (do (if ((ispair && aligned) : Bool)
                then
                  (do sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28194.52-28194.53"
                      let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let (highhalf, lowhalf) ← (( do
                        (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                        then
                          (do let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))
                        else
                          (do let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))) ) : SailM ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) )
                      (pure (highhalf +++ lowhalf)))
                else
                  (do (if (aligned : Bool)
                      then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
                      else
                        (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28208.23-28208.24"
                            sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28209.52-28209.53"
                            let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                            then
                              (do let highhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_1 := highhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let highhalf := loop_vars_1
                                      loop_vars_1 ← do (pure (Sail.BitVec.updateSubrange highhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned))))
                                    (pure loop_vars_1) ) : SailM (BitVec (halfsize * 8)) )
                                  let lowhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_2 := lowhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let lowhalf := loop_vars_2
                                      loop_vars_2 ← do (pure (Sail.BitVec.updateSubrange lowhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                    (pure loop_vars_2) ) : SailM (BitVec (halfsize * 8)) )
                                  (pure (highhalf +++ lowhalf)))
                            else
                              (do let value_name ← (pure (Sail.BitVec.updateSubrange value_name 7 0 (← (AArch64_MemSingle_read address 1 accdesc aligned))))
                                  let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                  sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28223.63-28223.64"
                                  let aligned : Bool :=
                                    if ((BEq.beq c Constraint_NONE) : Bool)
                                    then true
                                    else aligned
                                  let loop_i_lower := 1
                                  let loop_i_upper := (size -i 1)
                                  let mut loop_vars := value_name
                                  for i in [loop_i_lower:loop_i_upper:1]i do
                                    let value_name := loop_vars
                                    loop_vars ← do (pure (Sail.BitVec.updateSubrange value_name ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                  (pure loop_vars))))))))))) ) : SailM (BitVec (size * 8)) )
  (if ((← (BigEndian accdesc.acctype)) : Bool)
  then (do (pure (reverse_endianness value_name)))
  else (do (pure value_name)))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_read (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) : SailM (BitVec (size * 8)) := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28168.48-28168.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_read__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) : SailM (BitVec (size * 8)) := do
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28174.48-28174.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let joinedpair ← (( do (undefined_bool ()) ) : SailM Bool )
  let halfsize := (Int.ediv size 2)
  let value_name : (BitVec (size * 8)) := value_in_name
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then
      (do sail_assert (((size *i 8) == 8) || (((size *i 8) == 16) || (((size *i 8) == 32) || (((size *i 8) == 64) || ((size *i 8) == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28271.116-28271.117"
          (pure (reverse_endianness value_name)))
    else (do (pure value_name))) ) : SailM (BitVec (size * 8)) )
  (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
  then
    (do sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28275.27-28275.28"
        let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
          let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 127 64)
          let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 63 0)
          (highhalf, lowhalf)
        (AArch64_MemSingle_set__1 address halfsize accdesc aligned ispair lowhalf)
        (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair highhalf))
  else
    (do (if ((←((HaveLSE2Ext ()) <&&> (do
             (AllInAlignedQuantity address size 16)))) : Bool)
        then
          (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28282.52-28282.53"
              (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
        else
          (do (if ((ispair && aligned) : Bool)
              then
                (do let joinedpair : Bool := false
                    sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28286.27-28286.28"
                    let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28289.69-28289.70"
                    let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                      let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                      let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                      (highhalf, lowhalf)
                    (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                    then
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28292.60-28292.61"
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf)
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf))
                    else
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28296.60-28296.61"
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf)
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf))))
              else
                (do (if (aligned : Bool)
                    then
                      (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28301.52-28301.53"
                          (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
                    else
                      (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28304.23-28304.24"
                          let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                          then
                            (do sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28308.73-28308.74"
                                let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                                  let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                                  let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                                  (highhalf, lowhalf)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_1 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_1
                                  loop_vars_1 ← do (AArch64_MemSingle_set (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned (Sail.BitVec.extractLsb highhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_1)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_2 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_2
                                  loop_vars_2 ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb lowhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_2))
                          else
                            (do (AArch64_MemSingle_set address 1 accdesc aligned (Sail.BitVec.extractLsb value_name 7 0))
                                let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28319.63-28319.64"
                                let aligned : Bool :=
                                  if ((BEq.beq c Constraint_NONE) : Bool)
                                  then true
                                  else aligned
                                let loop_i_lower := 1
                                let loop_i_upper := (size -i 1)
                                let mut loop_vars := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars
                                  loop_vars ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb value_name ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars)))))))))))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_set (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_size : Nat, k_size ≥ 0 -/
def MemAtomic (address : (BitVec 64)) (cmpoperand : (BitVec k_size)) (operand : (BitVec k_size)) (accdesc_in : AccessDescriptor) : SailM (BitVec k_size) := do
  sail_assert accdesc_in.atomicop "sail-arm/arm-v9.4-a/src/v8_base.sail:28335.30-28335.31"
  let bytes := (Int.ediv (Sail.BitVec.length operand) 8)
  sail_assert ((bytes == 1) || ((bytes == 2) || ((bytes == 4) || ((bytes == 8) || (bytes == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28337.74-28337.75"
  let newvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let oldvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let accdesc : AccessDescriptor := accdesc_in
  let aligned : Bool := (IsAligned__1 address bytes)
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address bytes)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned (Sail.BitVec.length operand)) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  let _ : Unit :=
    if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
    then (ClearExclusiveByAddress memaddrdesc.paddress (ProcessorID ()) (Sail.BitVec.length operand))
    else ()
  (if ((←((pure ((← (HaveMTE2Ext ())) && accdesc.tagchecked)) <&&> (do
       (pure (! (← (HaveMTEStoreOnlyExt ())))) <||> (do
         (pure (! (← (StoreOnlyTagCheckingEnabled accdesc.el)))))))) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert ((8 *i bytes) == (Sail.BitVec.length operand)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28363.42-28363.43"
  let (memstatus, oldvalue) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc bytes accdesc none)
    let memstatus : PhysMemRetStatus := tup__0
    let oldvalue : (BitVec k_size) := tup__1
    (pure (memstatus, oldvalue)) ) : SailM (PhysMemRetStatus × (BitVec k_size)) )
  (if ((IsFault__2 memstatus) : Bool)
  then (do (HandleExternalReadAbort memstatus memaddrdesc bytes accdesc))
  else (do (pure ())))
  let oldvalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (reverse_endianness oldvalue)))
    else (do (pure oldvalue))) ) : SailM (BitVec k_size) )
  let oldvalue := oldvalue
  let cmpfail : Bool := false
  let (cmpfail, newvalue) : (Bool × (BitVec k_size)) :=
    match accdesc.modop with
    | .MemAtomicOp_ADD =>
      (let newvalue : (BitVec k_size) := (oldvalue + operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_BIC =>
      (let newvalue : (BitVec k_size) := (oldvalue &&& (Complement.complement operand))
      (cmpfail, newvalue))
    | .MemAtomicOp_EOR =>
      (let newvalue : (BitVec k_size) := (oldvalue ^^^ operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_ORR =>
      (let newvalue : (BitVec k_size) := (oldvalue ||| operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SWP =>
      (let newvalue : (BitVec k_size) := operand
      (cmpfail, newvalue))
    | .MemAtomicOp_CAS =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
    | .MemAtomicOp_GCSSS1 =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
  let accdesc ← (( do
    (if ((←((HaveMTEStoreOnlyExt ()) <&&> (do
         (StoreOnlyTagCheckingEnabled accdesc.el)))) : Bool)
    then
      (do let accdesc ← (( do
            (if ((accdesc.tagchecked && cmpfail) : Bool)
            then (do (pure { accdesc with tagchecked := (← do (ConstrainUnpredictableBool Unpredictable_STOREONLYTAGCHECKEDCAS)) }))
            else (do (pure accdesc))) ) : SailM AccessDescriptor )
          (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
          then
            (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
                (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
                then
                  (do let accdesc : AccessDescriptor := { accdesc with read := false }
                      (AArch64_TagCheckFault address accdesc)
                      (pure accdesc))
                else (do (pure accdesc))))
          else (do (pure accdesc))))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((! cmpfail) : Bool)
  then
    (do let newvalue ← (( do
          (if ((← (BigEndian accdesc.acctype)) : Bool)
          then (do (pure (reverse_endianness newvalue)))
          else (do (pure newvalue))) ) : SailM (BitVec k_size) )
        let memstatus ← (( do (PhysMemWrite memaddrdesc bytes accdesc none newvalue) ) : SailM PhysMemRetStatus )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc bytes accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := false
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  (pure oldvalue)

def undefined_RCWMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def undefined_RCWSMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def AArch64_AllocationTagFromAddress (tagged_address : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb tagged_address 59 56)

def PhysMemTagWrite (desc : AddressDescriptor) (accdesc : AccessDescriptor) (data : (BitVec 4)) : SailM PhysMemRetStatus := do
  (undefined_PhysMemRetStatus ())

def undefined_VNCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

/-- Type quantifiers: size : Int -/
def AArch64_DataMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let accdesc : AccessDescriptor := accdesc_in
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagaccess) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked vaddress accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let aligned : Bool := true
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  let (memaddrdesc, memstatus) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (size -i 1)
    let mut loop_vars := (memaddrdesc, memstatus)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (memaddrdesc, memstatus) := loop_vars
      loop_vars ← do
        (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
        then
          (do let ptag : (BitVec 4) := (AArch64_PhysicalTag vaddress)
              (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
              then
                (do (if ((← (__IMPDEF_boolean "DC_ZVA tag fault reported with lowest faulting address")) : Bool)
                    then (do (AArch64_TagCheckFault vaddress accdesc))
                    else (do (AArch64_TagCheckFault regval accdesc))))
              else (do (pure ()))))
        else (do (pure ())))
        let memstatus ← (PhysMemWrite memaddrdesc 1 accdesc none (Zeros (n := 8)))
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
        else (do (pure ())))
        let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
        (pure (memaddrdesc, memstatus))
    (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
  (pure ())

/-- Type quantifiers: size : Int -/
def AArch64_TagMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert (accdesc_in.tagaccess && (! accdesc_in.tagchecked)) "sail-arm/arm-v9.4-a/src/v8_base.sail:29013.65-29013.66"
  let accdesc : AccessDescriptor := accdesc_in
  let count := (Int.shiftr size LOG2_TAG_GRANULE)
  let tag : (BitVec 4) := (AArch64_AllocationTagFromAddress vaddress)
  let aligned : Bool := (IsAligned__1 vaddress TAG_GRANULE)
  (if ((! aligned) : Bool)
  then (do (AArch64_Abort vaddress (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let accdesc ← (( do
    (if ((← (HaveMTE2Ext ())) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if (((! accdesc.tagaccess) || (bne memaddrdesc.memattrs.tags MemTag_AllocationTagged)) : Bool)
  then (do (pure ()))
  else
    (do let (memaddrdesc, memstatus) ← (( do
          let loop_i_lower := 0
          let loop_i_upper := (count -i 1)
          let mut loop_vars := (memaddrdesc, memstatus)
          for i in [loop_i_lower:loop_i_upper:1]i do
            let (memaddrdesc, memstatus) := loop_vars
            loop_vars ← do
              let memstatus ← (PhysMemTagWrite memaddrdesc accdesc tag)
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address TAG_GRANULE) } }
              (pure (memaddrdesc, memstatus))
          (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
        (pure ())))

/-- Type quantifiers: processorid : Int, size : Int -/
def AArch64_MarkExclusiveVA (address : (BitVec 64)) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveGlobal (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveLocal (paddress : FullAddress) (processorid : Int) (size : Int) : SailM Unit := do
  writeReg __janus_excl_valid true
  writeReg __janus_excl_addr paddress.address
  writeReg __janus_excl_size size

/-- Type quantifiers: size : Int -/
def AArch64_SetExclusiveMonitors (address : (BitVec 64)) (size : Int) : SailM Unit := do
  writeReg __ExclusiveMonitorSet true
  let acqrel : Bool := false
  let tagchecked : Bool := false
  let accdesc ← (( do (CreateAccDescExLDST MemOp_LOAD acqrel tagchecked) ) : SailM AccessDescriptor )
  let aligned : Bool := (IsAligned__1 address size)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (pure ()))
  else
    (do let _ : Unit :=
          if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
          then (MarkExclusiveGlobal memaddrdesc.paddress (ProcessorID ()) size)
          else ()
        (MarkExclusiveLocal memaddrdesc.paddress (ProcessorID ()) size)
        (pure (AArch64_MarkExclusiveVA address (ProcessorID ()) size))))

/-- Type quantifiers: processorid : Int, size : Int -/
def AArch64_IsExclusiveVA (address : (BitVec 64)) (processorid : Int) (size : Int) : Bool :=
  true

/-- Type quantifiers: processorid : Int, size : Int -/
def IsExclusiveGlobal (paddress : FullAddress) (processorid : Int) (size : Int) : Bool :=
  true

/-- Type quantifiers: processorid : Int, size : Int -/
def IsExclusiveLocal (paddress : FullAddress) (processorid : Int) (size : Int) : SailM Bool := do
  readReg __janus_excl_valid <&&> (do
    (pure ((← readReg __janus_excl_addr) == paddress.address)) <&&> (do
      (pure ((← readReg __janus_excl_size) == size))))

/-- Type quantifiers: size : Int -/
def AArch64_ExclusiveMonitorsPass (address : (BitVec 64)) (size : Int) : SailM Bool := do
  let acqrel : Bool := false
  let tagchecked : Bool := false
  let accdesc ← (( do (CreateAccDescExLDST MemOp_STORE acqrel tagchecked) ) : SailM AccessDescriptor )
  let aligned : Bool := (IsAligned__1 address size)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  (if ((! (AArch64_IsExclusiveVA address (ProcessorID ()) size)) : Bool)
  then (do (pure false))
  else
    (do let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
        (if ((IsFault memaddrdesc) : Bool)
        then (do (AArch64_Abort address memaddrdesc.fault))
        else (do (pure ())))
        let passed ← (( do (IsExclusiveLocal memaddrdesc.paddress (ProcessorID ()) size) ) : SailM Bool )
        (ClearExclusiveLocal (ProcessorID ()))
        (if ((passed && (bne memaddrdesc.memattrs.shareability Shareability_NSH)) : Bool)
        then (do (pure (IsExclusiveGlobal memaddrdesc.paddress (ProcessorID ()) size)))
        else (do (pure passed)))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPRecipStepFused (op1_in : (BitVec k_N)) (op2 : (BitVec k_N)) : SailM (BitVec k_N) := do
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:29114.41-29114.42"
  let op1 : (BitVec k_N) := op1_in
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let op1 ← (( do (FPNeg op1) ) : SailM (BitVec k_N) )
  let altfp ← (( do (pure ((← (HaveAltFP ())) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then
      (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 0 0 (Sail.BitVec.extractLsb 0b11#2 1 1))
      (Sail.BitVec.updateSubrange fpcr 24 24 (Sail.BitVec.extractLsb 0b11#2 0 0)))
    else fpcr
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then (Sail.BitVec.updateSubrange fpcr 23 22 0b00#2)
    else fpcr
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        (if (((inf1 && zero2) || (zero1 && inf2)) : Bool)
        then (do (FPTwo 0#1 (Sail.BitVec.length result)))
        else
          (do (if ((inf1 || inf2) : Bool)
              then (do (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result)))
              else
                (do let result_value : real := (add_real (2) (mult_real value1_name value2_name))
                    (if ((eq_real result_value (0)) : Bool)
                    then
                      (do let sign : (BitVec 1) :=
                            if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                            then 1#1
                            else 0#1
                          (FPZero sign (Sail.BitVec.length result)))
                    else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPRSqrtStepFused (op1_in : (BitVec k_N)) (op2 : (BitVec k_N)) : SailM (BitVec k_N) := do
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:29172.41-29172.42"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let op1 : (BitVec k_N) := op1_in
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let op1 ← (( do (FPNeg op1) ) : SailM (BitVec k_N) )
  let altfp ← (( do (pure ((← (HaveAltFP ())) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then
      (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 0 0 (Sail.BitVec.extractLsb 0b11#2 1 1))
      (Sail.BitVec.updateSubrange fpcr 24 24 (Sail.BitVec.extractLsb 0b11#2 0 0)))
    else fpcr
  let fpcr : (BitVec 64) :=
    if (altfp : Bool)
    then (Sail.BitVec.updateSubrange fpcr 23 22 0b00#2)
    else fpcr
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        (if (((inf1 && zero2) || (zero1 && inf2)) : Bool)
        then (do (FPOnePointFive 0#1 (Sail.BitVec.length result)))
        else
          (do (if ((inf1 || inf2) : Bool)
              then (do (FPInfinity (sign1 ^^^ sign2) (Sail.BitVec.length result)))
              else
                (do let result_value : real := (div_real (add_real (3) (mult_real value1_name value2_name)) (2))
                    (if ((eq_real result_value (0)) : Bool)
                    then
                      (do let sign : (BitVec 1) :=
                            if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                            then 1#1
                            else 0#1
                          (FPZero sign (Sail.BitVec.length result)))
                    else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))
  else (do (pure result)))

def AArch64_AdvSIMDFPAccessTrap (target_el : (BitVec 2)) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let vect_offset := (BitVec.toNat 0x0#4)
  let route_to_el2 ← (( do (pure (target_el == EL1)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  (if (route_to_el2 : Bool)
  then
    (do let except ← (( do (ExceptionSyndrome Exception_Uncategorized) ) : SailM ExceptionRecord )
        (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else
    (do let except ← (( (ExceptionSyndrome Exception_AdvSIMDFPAccessTrap) ) : SailM ExceptionRecord )
        let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) })
        (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def SMEAccessTrap (etype : SMEExceptionType) (target_el_in : (BitVec 2)) : SailM Unit := do
  let target_el : (BitVec 2) := target_el_in
  sail_assert ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)) "sail-arm/arm-v9.4-a/src/v8_base.sail:29351.45-29351.46"
  let target_el : (BitVec 2) :=
    if ((target_el == EL0) : Bool)
    then EL1
    else target_el
  let route_to_el2 ← (( do (pure (((← readReg PSTATE).EL == EL0) && (target_el == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let except ← (( do (ExceptionSyndrome Exception_SMEAccessTrap) ) : SailM ExceptionRecord )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except : ExceptionRecord :=
    match etype with
    | .SMEExceptionType_AccessTrap => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b000#3) }
    | .SMEExceptionType_Streaming => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b001#3) }
    | .SMEExceptionType_NotStreaming => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b010#3) }
    | .SMEExceptionType_InactiveZA => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b011#3) }
    | .SMEExceptionType_InaccessibleZT0 => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b100#3) }
  (if (route_to_el2 : Bool)
  then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else (do (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def CheckSMEAccess (_ : Unit) : SailM Unit := do
  let disabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let disabled ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
         (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
         (pure (! (← (IsInHost ()))))))) : Bool)
    then
      (do let disabled ← (( do
            let b__0 ← do (pure (_get_CPACR_EL1_Type_SMEN (← readReg CPACR_EL1)))
            (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
            then (do (pure true))
            else
              (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                  then (do (pure ((← readReg PSTATE).EL == EL0)))
                  else (do (pure false))))) ) : SailM Bool )
          (if (disabled : Bool)
          then (do (SMEAccessTrap SMEExceptionType_AccessTrap EL1))
          else (do (pure ())))
          (pure disabled))
    else (do (pure disabled))) ) : SailM Bool )
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
       (pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
       (EL2Enabled ())))) : Bool)
  then
    (do (if ((←((HaveVirtHostExt ()) <&&> (do
             (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
        then
          (do let disabled ← (( do
                let b__2 ← do (pure (_get_CPTR_EL2_Type_SMEN (← readReg CPTR_EL2)))
                (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                      then (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                      else (do (pure false))))) ) : SailM Bool )
              (if (disabled : Bool)
              then (do (SMEAccessTrap SMEExceptionType_AccessTrap EL2))
              else (do (pure ()))))
        else
          (do (if (((_get_CPTR_EL2_Type_TSM (← readReg CPTR_EL2)) == 1#1) : Bool)
              then (do (SMEAccessTrap SMEExceptionType_AccessTrap EL2))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do (if (((_get_CPTR_EL3_Type_ESM (← readReg CPTR_EL3)) == 0#1) : Bool)
        then (do (SMEAccessTrap SMEExceptionType_AccessTrap EL3))
        else (do (pure ()))))
  else (do (pure ())))

def ResetSMEState (_ : Unit) : SailM Unit := do
  let vectors_name := (Int.ediv MAX_VL 8)
  let loop_n_lower := 0
  let loop_n_upper := (vectors_name -i 1)
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do writeReg _ZA (vectorUpdate (← readReg _ZA) n (Zeros (n := MAX_VL)))
  (pure loop_vars)
  writeReg _ZT0 (Zeros (n := ZT0_LEN))

def SetPSTATE_SM (value_name : (BitVec 1)) : SailM Unit := do
  (if (((← readReg PSTATE).SM != value_name) : Bool)
  then
    (do (ResetSVEState ())
        writeReg PSTATE { (← readReg PSTATE) with SM := value_name })
  else (do (pure ())))

def SetPSTATE_ZA (value_name : (BitVec 1)) : SailM Unit := do
  (if (((← readReg PSTATE).ZA != value_name) : Bool)
  then
    (do (ResetSMEState ())
        writeReg PSTATE { (← readReg PSTATE) with ZA := value_name })
  else (do (pure ())))

/-- Type quantifiers: k_ex3347438_ : Bool, k_N : Nat, esize : Nat, List.elem k_N [8, 16, 32, 64, 128, 256, 512, 1024, 2048] ∧ List.elem esize [8, 16, 32, 64] ∧ k_N ≥ esize -/
partial def Reduce__1 (op : ReduceOp) (input : (BitVec k_N)) (esize : Nat) (altfp : Bool) : SailM (BitVec esize) := do
  sail_assert ((esize == 8) || ((esize == 16) || ((esize == 32) || (esize == 64)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:30829.63-30829.64"
  let result ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  (if (((Sail.BitVec.length input) == esize) : Bool)
  then (do (pure (Sail.BitVec.extractLsb input (esize -i 1) 0)))
  else
    (do let half := (Int.ediv (Sail.BitVec.length input) 2)
        let hi ← (( do (Reduce__1 op (Sail.BitVec.extractLsb input ((Sail.BitVec.length input) -i 1) half) esize altfp) ) : SailM (BitVec esize) )
        let lo ← (( do (Reduce__1 op (Sail.BitVec.extractLsb input (half -i 1) 0) esize altfp) ) : SailM (BitVec esize) )
        match op with
        | .ReduceOp_FMINNUM =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30839.51-30839.52"
            (FPMinNum lo hi (← (FPCR_read ()))))
        | .ReduceOp_FMAXNUM =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30843.51-30843.52"
            (FPMaxNum lo hi (← (FPCR_read ()))))
        | .ReduceOp_FMIN =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30847.51-30847.52"
            (FPMin__1 lo hi (← (FPCR_read ())) altfp))
        | .ReduceOp_FMAX =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30851.51-30851.52"
            (FPMax__1 lo hi (← (FPCR_read ())) altfp))
        | .ReduceOp_FADD =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30855.51-30855.52"
            (FPAdd lo hi (← (FPCR_read ()))))
        | .ReduceOp_ADD => (pure (lo + hi))))
termination_by (let (op, input, esize, altfp) := (op, input, esize, altfp)
(Sail.BitVec.length input)).toNat

/-- Type quantifiers: k_N : Nat, esize : Nat, List.elem k_N [8, 16, 32, 64, 128, 256, 512, 1024, 2048] ∧ List.elem esize [8, 16, 32, 64] ∧ k_N ≥ esize -/
def Reduce (op : ReduceOp) (input : (BitVec k_N)) (esize : Nat) : SailM (BitVec esize) := do
  let altfp ← (( do (HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))) <&&> (do (pure ((_get_FPCR_Type_AH (← readReg FPCR)) == 1#1))) ) : SailM Bool )
  (Reduce__1 op input esize altfp)

/-- Type quantifiers: M : Nat, k_immediate : Bool, M ≥ 0 -/
def DecodeBitMasks (immN : (BitVec 1)) (imms : (BitVec 6)) (immr : (BitVec 6)) (immediate : Bool) (M : Nat) : SailM ((BitVec M) × (BitVec M)) := do
  let len := (HighestSetBit (immN +++ (Complement.complement imms)))
  (if ((len <b 1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (M ≥b (Int.shiftl 1 len)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30900.26-30900.27"
  sail_assert (6 ≥b len) "sail-arm/arm-v9.4-a/src/v8_base.sail:30901.32-30901.33"
  let levels : (BitVec 6) := (Sail.BitVec.zeroExtend (Ones (n := len)) 6)
  (if ((immediate && ((imms &&& levels) == levels)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let s := (BitVec.toNat (imms &&& levels))
  let r := (BitVec.toNat (immr &&& levels))
  let diff := (s -i r)
  let esize := (Int.shiftl 1 len)
  let d := (BitVec.toNat (integer_subrange diff (len -i 1) 0))
  sail_assert (esize ≥b (s +i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30911.39-30911.40"
  let welem : (BitVec esize) := (Sail.BitVec.zeroExtend (Ones (n := (s +i 1))) esize)
  sail_assert (esize ≥b (d +i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30913.39-30913.40"
  let telem : (BitVec esize) := (Sail.BitVec.zeroExtend (Ones (n := (d +i 1))) esize)
  sail_assert ((esize *i (Int.ediv M esize)) == M) "sail-arm/arm-v9.4-a/src/v8_base.sail:30915.53-30915.54"
  let wmask : (BitVec M) := (BitVec.replicateBits (ROR welem r) (Int.ediv M esize))
  let tmask : (BitVec M) := (BitVec.replicateBits telem (Int.ediv M esize))
  (pure (wmask, tmask))

def HaveSVE2p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SVE2p1)

def HaveSME2p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME2p1)

def GCSSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def GCSPCREnabled (el : (BitVec 2)) : SailM Bool := do
  (GCSPCRSelected el) <&&> (do
    (GCSEnabled el))

def GCSReturnValueCheckEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do let questionMark := el
        (if ((questionMark == EL0) : Bool)
        then (do (pure ((_get_GCSCRE0_EL1_Type_RVCHKEN (← readReg GCSCRE0_EL1)) == 1#1)))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do (pure ((_get_GCSCR_EL1_Type_RVCHKEN (← readReg GCSCR_EL1)) == 1#1)))
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do (pure ((_get_GCSCR_EL2_Type_RVCHKEN (← readReg GCSCR_EL2)) == 1#1)))
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do (pure ((_get_GCSCR_EL3_Type_RVCHKEN (← readReg GCSCR_EL3)) == 1#1)))
                          else (do (undefined_bool ())))))))))))

def GetCurrentGCSPointer (_ : Unit) : SailM (BitVec 64) := do
  let ptr ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then (do (pure ((_get_GCSPR_EL0_Type_PTR (← readReg GCSPR_EL0)) +++ 0b000#3)))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do (pure ((_get_GCSPR_EL1_Type_PTR (← readReg GCSPR_EL1)) +++ 0b000#3)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (pure ((_get_GCSPR_EL2_Type_PTR (← readReg GCSPR_EL2)) +++ 0b000#3)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure ((_get_GCSPR_EL3_Type_PTR (← readReg GCSPR_EL3)) +++ 0b000#3)))
                    else (do (pure ptr)))))))))

def SetCurrentGCSPointer (ptr : (BitVec 64)) : SailM Unit := do
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then (do writeReg GCSPR_EL0 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL0) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do writeReg GCSPR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL1) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do writeReg GCSPR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL2) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do writeReg GCSPR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL3) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
                    else (do (pure ())))))))))

def AddGCSRecord (vaddress : (BitVec 64)) : SailM Unit := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_STORE) ) : SailM AccessDescriptor )
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  (Mem_set (BitVec.subInt ptr 8) 8 accdesc vaddress)
  let ptr : (BitVec 64) := (BitVec.subInt ptr 8)
  (SetCurrentGCSPointer ptr)

def GCSDataCheckException (gcsinst_type : GCSInstruction) : SailM Unit := do
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let rn_unknown : Bool := false
  let is_ret : Bool := false
  let target_el ← (( do
    (if (((← readReg PSTATE).EL == EL0) : Bool)
    then
      (do (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
          then (do (pure EL1))
          else (do (pure EL2))))
    else (do (pure (← readReg PSTATE).EL))) ) : SailM (BitVec 2) )
  let except ← (( do (ExceptionSyndrome Exception_GCSFail) ) : SailM ExceptionRecord )
  let (except, is_ret, rn_unknown) : (ExceptionRecord × Bool × Bool) :=
    match gcsinst_type with
    | .GCSInstType_PRET =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00000#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPM =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00001#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_PRETAA =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00010#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_PRETAB =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00011#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_SS1 =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00100#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_SS2 =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00101#5) }
      let rn_unknown : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPCX =>
      (let rn_unknown : Bool := true
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b01000#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPX =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b01001#5) }
      (except, is_ret, rn_unknown))
  let except ← (( do
    (if ((rn_unknown == true) : Bool)
    then (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (← (__UNKNOWN_bits 5))))) }))
    else
      (do (if ((is_ret == true) : Bool)
          then (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 9 5)))) }))
          else (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) }))))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 10 (Zeros (n := 15))) }
  let except ← (pure { except with vaddress := (← do (__UNKNOWN_bits 64)) })
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def LoadCheckGCSRecord (vaddress : (BitVec 64)) (gcsinst_type : GCSInstruction) : SailM (BitVec 64) := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let recorded_va ← (( do (Mem_read ptr 8 accdesc) ) : SailM (BitVec 64) )
  (if (((← (GCSReturnValueCheckEnabled (← readReg PSTATE).EL)) && (recorded_va != vaddress)) : Bool)
  then (do (GCSDataCheckException gcsinst_type))
  else (do (pure ())))
  (pure recorded_va)

def GCSSS2 (_ : Unit) : SailM (BitVec 64) := do
  let outgoing_pointer ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc_ld ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  let accdesc_st ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_STORE) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let incoming_pointer_name ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let outgoing_value ← (( do (Mem_read incoming_pointer_name 8 accdesc_ld) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb outgoing_value 2 0) == 0b101#3) : Bool)
  then
    (do let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 63 3 (BitVec.subInt (Sail.BitVec.extractLsb outgoing_value 63 3) 1))
        let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 2 0 0b000#3)
        let outgoing_value : (BitVec 64) := ((Sail.BitVec.extractLsb outgoing_pointer 63 12) +++ 0b000000000001#12)
        (Mem_set outgoing_pointer 8 accdesc_st outgoing_value)
        (SetCurrentGCSPointer (BitVec.addInt incoming_pointer_name 8))
        let _ : Unit := (GCSSynchronizationBarrier ())
        (pure outgoing_pointer))
  else
    (do (GCSDataCheckException GCSInstType_SS2)
        (pure outgoing_pointer)))

def GCSPOPM (_ : Unit) : SailM (BitVec 64) := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let entry ← (( do (Mem_read ptr 8 accdesc) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb entry 1 0) != 0b00#2) : Bool)
  then (do (GCSDataCheckException GCSInstType_POPM))
  else (do (pure ())))
  let ptr : (BitVec 64) := (BitVec.addInt ptr 8)
  (SetCurrentGCSPointer ptr)
  (pure entry)

def undefined_HFGITR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_HFGITR_EL2_Type_DCZVA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HFGITR_EL2_Type_SVC_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_HFGITR_EL2_Type_SVC_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def GetPendingPhysicalSError (_ : Unit) : SailM FaultRecord := do
  (__UNKNOWN_FaultRecord ())

def AArch32_PhysicalSErrorSyndrome (_ : Unit) : SailM (BitVec 16) := do
  let syndrome : (BitVec 32) := (Zeros (n := 32))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let syndrome ← (( do
    (if (((← readReg PSTATE).EL == EL2) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 11 10 (← (AArch32_EncodeAsyncErrorSyndrome errstate))))
          let syndrome : (BitVec 32) := (BitVec.update syndrome 9 (Bit fault.extflag))
          (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6)))
    else
      (do let long_format ← (( do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)) ) : SailM Bool )
          (AArch32_CommonFaultStatus fault long_format))) ) : SailM (BitVec 32) )
  (pure (Sail.BitVec.extractLsb syndrome 15 0))

def AArch64_EncodeAsyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 3) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b000#3)
  | .ErrorState_UEU => (pure 0b001#3)
  | .ErrorState_UEO => (pure 0b010#3)
  | .ErrorState_UER => (pure 0b011#3)
  | .ErrorState_CE => (pure 0b110#3)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 3))

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch64_PhysicalSErrorSyndrome (implicit_esb : Bool) : SailM (BitVec 25) := do
  let syndrome : (BitVec 25) := (Zeros (n := 25))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let errorstate ← (( do (AArch64_PEErrorState fault) ) : SailM ErrorState )
  (if ((BEq.beq errorstate ErrorState_Uncategorized) : Bool)
  then (do (pure (Zeros (n := 25))))
  else
    (do (if ((BEq.beq errorstate ErrorState_IMPDEF) : Bool)
        then
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 1#1))
              (pure (Sail.BitVec.updateSubrange syndrome 23 0 (← (__IMPDEF_bits 24 "IMPDEF ErrorState")))))
        else
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 0#1))
              let syndrome : (BitVec 25) :=
                (BitVec.update syndrome 13
                  (Bit
                    (if (implicit_esb : Bool)
                    then 1#1
                    else 0#1)))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 12 10 (← (AArch64_EncodeAsyncErrorSyndrome errorstate))))
              let syndrome : (BitVec 25) := (BitVec.update syndrome 9 (Bit fault.extflag))
              (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6))))))

def AArch64_PhysicalSErrorTarget (_ : Unit) : SailM (Bool × (BitVec 2)) := do
  let route_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el3 ← (( do
    (if (((← readReg PSTATE).EL != EL3) : Bool)
    then (do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))))
    else (do (pure false))) ) : SailM Bool )
  let route_to_el2 ← (( do
    (if ((←((pure (! route_to_el3)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)))
    else
      (do (if ((←((pure (! route_to_el3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then (do (pure (! (← (IsInHost ())))) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) != 0b00#2))))
          else (do (pure false))))) ) : SailM Bool )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let masked ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    (if ((questionMark == EL3) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 0#1)) <||> (do (pure ((← readReg PSTATE).A == 1#1))))
    else
      (do (if ((questionMark == EL2) : Bool)
          then (do (pure (! route_to_el3)) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) == 0b00#2)) <||> (do (pure ((← readReg PSTATE).A == 1#1)))))
          else
            (do (if ((questionMark == EL1) : Bool)
                then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                else
                  (do (if ((questionMark == EL0) : Bool)
                      then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                      else (do (pure masked))))))))) ) : SailM Bool )
  let masked ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let nmea_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let nmea_bit ← (( do
            let questionMark ← do (pure (← readReg PSTATE).EL)
            (if ((questionMark == EL3) : Bool)
            then (do (pure (_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3))))
            else
              (do (if ((questionMark == EL2) : Bool)
                  then
                    (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                        then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                        else (do (pure 0#1))))
                  else
                    (do (if ((questionMark == EL1) : Bool)
                        then
                          (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                              then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                              else (do (pure 0#1))))
                        else
                          (do (if ((questionMark == EL0) : Bool)
                              then
                                (do (if ((← (IsInHost ())) : Bool)
                                    then
                                      (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                                          else (do (pure 0#1))))
                                    else
                                      (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                                          else (do (pure 0#1))))))
                              else (do (pure nmea_bit))))))))) ) : SailM (BitVec 1) )
          (pure (masked && (nmea_bit == 0#1))))
    else
      (do (if ((←((HaveDoubleFaultExt ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL3))))) : Bool)
          then
            (do let nmea_bit ← (( do (pure ((_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3)) &&& (← (EffectiveEA ())))) ) : SailM (BitVec 1) )
                (pure (masked && (nmea_bit == 0#1))))
          else (do (pure masked))))) ) : SailM Bool )
  let route_masked_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_masked_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (route_masked_to_el2, route_masked_to_el3) ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let route_masked_to_el2 ← (pure ((← (EL2Enabled ())) && (! route_to_el3))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_TMEA (← readReg HCRX_EL2)) == 1#1))) <&&> (do (pure ((← readReg PSTATE).EL == EL1)) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked)) <&&> (do (pure (! (← (IsInHost ())))))))
          let route_masked_to_el3 ← (pure ((←((pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_TMEA (← readReg SCR_EL3)) == 1#1))))) && (! (route_to_el2 || route_masked_to_el2)))) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked))))
          (pure (route_masked_to_el2, route_masked_to_el3)))
    else
      (do let route_masked_to_el2 : Bool := false
          let route_masked_to_el3 : Bool := false
          (pure (route_masked_to_el2, route_masked_to_el3)))) ) : SailM (Bool × Bool) )
  let take_in_el3 ← (( do (pure (((← readReg PSTATE).EL == EL3) && (! masked))) ) : SailM Bool )
  let take_in_el2_0 ← (( do (pure (((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do (IsInHost ())))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let take_in_el1_0 ← (( do (pure ((((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (IsInHost ())))))))) && (! (route_to_el2 || route_masked_to_el2))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let (masked, target_el) ← (( do
    (if (((take_in_el3 || route_to_el3) || route_masked_to_el3) : Bool)
    then
      (do let masked : Bool := false
          let target_el : (BitVec 2) := EL3
          (pure (masked, target_el)))
    else
      (do let (masked, target_el) ← (( do
            (if (((take_in_el2_0 || route_to_el2) || route_masked_to_el2) : Bool)
            then
              (do let masked : Bool := false
                  let target_el : (BitVec 2) := EL2
                  (pure (masked, target_el)))
            else
              (do let (masked, target_el) ← (( do
                    (if (take_in_el1_0 : Bool)
                    then
                      (do let masked : Bool := false
                          let target_el : (BitVec 2) := EL1
                          (pure (masked, target_el)))
                    else
                      (do let masked : Bool := true
                          let target_el ← (__UNKNOWN_bits 2)
                          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
                  (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
  (pure (masked, target_el))

def undefined_DISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DISR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSESR_EL2_Type_IDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def undefined_DISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DISR_Type := value_name
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DISR r

def ExternalDebugInterruptsDisabled (target : (BitVec 2)) : SailM Bool := do
  let int_dis ← (( do (undefined_bool ()) ) : SailM Bool )
  let ss ← (( do (SecurityStateAtEL target) ) : SailM SecurityState )
  (if ((← (Havev8p4Debug ())) : Bool)
  then
    (do (if ((((BitVec.access (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) 0) : BitVec 1) == 1#1) : Bool)
        then
          (do match ss with
              | .SS_NonSecure => (do (ExternalInvasiveDebugEnabled ()))
              | .SS_Secure => (do (ExternalSecureInvasiveDebugEnabled ()))
              | .SS_Realm => (do (ExternalRealmInvasiveDebugEnabled ()))
              | .SS_Root => (do (ExternalRootInvasiveDebugEnabled ())))
        else (do (pure false))))
  else
    (do let questionMark := target
        (if ((questionMark == EL3) : Bool)
        then (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) == 0b11#2)) <&&> (do (ExternalSecureInvasiveDebugEnabled ())))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (do
                      let b__0 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                      (if (((Sail.BitVec.extractLsb b__0 1 1) == (1#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else (do (pure false)))) <&&> (do
                      (ExternalInvasiveDebugEnabled ())))
              else
                (do (if ((questionMark == EL1) : Bool)
                    then
                      (do (if ((BEq.beq ss SS_Secure) : Bool)
                          then
                            (do (do
                                  let b__1 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                                  (if (((Sail.BitVec.extractLsb b__1 1 1) == (1#1 : (BitVec 1))) : Bool)
                                  then (do (pure true))
                                  else (do (pure false)))) <&&> (do
                                  (ExternalSecureInvasiveDebugEnabled ())))
                          else (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) != 0b00#2)) <&&> (do (ExternalInvasiveDebugEnabled ())))))
                    else (do (pure int_dis)))))))))

def ClearPendingPhysicalSError (_ : Unit) : Unit :=
  ()

def IsSynchronizablePhysicalSErrorPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch64_ESBOperation (_ : Unit) : SailM Unit := do
  let implicit_esb ← (( do (undefined_bool ()) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let (masked, target_el) ← (( do
    let (tup__0, tup__1) ← do (AArch64_PhysicalSErrorTarget ())
    let masked : Bool := tup__0
    let target_el : (BitVec 2) := tup__1
    (pure (masked, target_el)) ) : SailM (Bool × (BitVec 2)) )
  let intdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled target_el)) ) : SailM Bool )
  let masked : Bool := (masked || intdis)
  (if ((←((pure masked) <&&> (do
       (IsSynchronizablePhysicalSErrorPending ())))) : Bool)
  then
    (do (if ((← (ELUsingAArch32 (← (S1TranslationRegime__1 ())))) : Bool)
        then
          (do let syndrome : (BitVec 32) := (Zeros (n := 32))
              let syndrome : (BitVec 32) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 15 0 (← (AArch32_PhysicalSErrorSyndrome ()))))
              (DISR_write (Mk_DISR_Type syndrome)))
        else
          (do let implicit_esb : Bool := false
              let syndrome : (BitVec 64) := (Zeros (n := 64))
              let syndrome : (BitVec 64) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 24 0 (← (AArch64_PhysicalSErrorSyndrome implicit_esb))))
              writeReg DISR_EL1 (Mk_DISR_EL1_Type syndrome)))
        (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))

def undefined_VDFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_VSESR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def VDFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VDFSR ) : SailM VDFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VSESR_EL2) 0 32)))

def undefined_VDISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VDISR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_VDISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def VDISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VDISR_Type := value_name
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VDISR r

def AArch64_vESBOperation (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33362.63-33362.64"
  let vSEI_enabled ← (( do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vSEI_pending ← (( do (pure vSEI_enabled) <&&> (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vintdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled EL1)) ) : SailM Bool )
  let vmasked ← (( do (pure vintdis) <||> (do (pure ((← readReg PSTATE).A == 1#1))) ) : SailM Bool )
  (if ((vSEI_pending && vmasked) : Bool)
  then
    (do (if ((← (ELUsingAArch32 EL1)) : Bool)
        then
          (do let target : (BitVec 32) := (Zeros (n := 32))
              let target : (BitVec 32) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 15 14 (Sail.BitVec.extractLsb (← (VDFSR_read ())) 15 14)))
              let target ← (pure (BitVec.update target 12 (Bit ((BitVec.access (← (VDFSR_read ())) 12) : BitVec 1))))
              let target ← (pure (BitVec.update target 9 (Bit (_get_TTBCR_Type_EAE (← (TTBCR_read ()))))))
              let target ← (( do
                (if (((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange target 5 0 0b010001#6)))
                else
                  (do let target : (BitVec 32) := (Sail.BitVec.updateSubrange target 10 10 (Sail.BitVec.extractLsb 0b10110#5 4 4))
                      (pure (Sail.BitVec.updateSubrange target 3 0 (Sail.BitVec.extractLsb 0b10110#5 3 0))))) ) : SailM (BitVec 32) )
              (VDISR_write (Mk_VDISR_Type target)))
        else
          (do let target : (BitVec 64) := (Zeros (n := 64))
              let target : (BitVec 64) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 24 0 (Sail.BitVec.extractLsb (← readReg VSESR_EL2) 24 0)))
              writeReg VDISR_EL2 (Mk_VDISR_EL2_Type target)))
        writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1))
  else (do (pure ())))

def undefined_RVBAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTEL0ACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTNSAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICONTROL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDAA32PFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDDFR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDHSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_TYPER2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_TYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_CLRLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INMIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INVALLR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_INVLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_ISENABLER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_PROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_SETLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_SYNCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VPENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VPROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VSGIPENDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VSGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_WAKER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CREADR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CWRITER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_SGIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_TYPER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_MCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCFGR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCGCR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMIIDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMMIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPCSCTL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMVCIDSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCFGR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCFGR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCFGR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCFGR ) : SailM AMCFGR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCFGR_EL0) 0 32)))

def AMCFGR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCFGR_Type := value_name
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCFGR r

def undefined_AMCGCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCGCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCGCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCGCR ) : SailM AMCGCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCGCR_EL0) 0 32)))

def AMCGCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCGCR_Type := value_name
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCGCR r

def undefined_AMCNTENCLR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR0 ) : SailM AMCNTENCLR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR0_EL0) 0 32)))

def AMCNTENCLR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR0_Type := value_name
  writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR0 r

def undefined_AMCNTENCLR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR1 ) : SailM AMCNTENCLR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR1_EL0) 0 32)))

def AMCNTENCLR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR1_Type := value_name
  writeReg AMCNTENCLR1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR1 r

def undefined_AMCNTENSET0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET0 ) : SailM AMCNTENSET0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET0_EL0) 0 32)))

def AMCNTENSET0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET0_Type := value_name
  writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET0 r

def undefined_AMCNTENSET1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET1 ) : SailM AMCNTENSET1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET1_EL0) 0 32)))

def AMCNTENSET1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET1_Type := value_name
  writeReg AMCNTENSET1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET1 r

def undefined_AMCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCR ) : SailM AMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCR_EL0) 0 32)))

def AMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCR_Type := value_name
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCR r

def undefined_AMUSERENR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMUSERENR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMUSERENR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMUSERENR ) : SailM AMUSERENR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMUSERENR_EL0) 0 32)))

def AMUSERENR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMUSERENR_Type := value_name
  writeReg AMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg AMUSERENR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMUSERENR r

def undefined_CCSIDR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR2 ) : SailM CCSIDR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR2_EL1) 0 32)))

def CCSIDR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR2_Type := value_name
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR2 r

def undefined_CCSIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR ) : SailM CCSIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR_EL1) 0 32)))

def CCSIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR_Type := value_name
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR r

def undefined_CNTHCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHCTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHCTL ) : SailM CNTHCTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHCTL_EL2) 0 32)))

def CNTHCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHCTL_Type := value_name
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHCTL r

def undefined_CNTHPS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHPS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHPS_CTL ) : SailM CNTHPS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHPS_CTL_EL2) 0 32)))

def CNTHPS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHPS_CTL_Type := value_name
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHPS_CTL r

def undefined_CNTHVS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHVS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHVS_CTL ) : SailM CNTHVS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHVS_CTL_EL2) 0 32)))

def CNTHVS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHVS_CTL_Type := value_name
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHVS_CTL r

def undefined_CNTHV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHV_CTL ) : SailM CNTHV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHV_CTL_EL2) 0 32)))

def CNTHV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHV_CTL_Type := value_name
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHV_CTL r

def CNTKCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTKCTL_Type := value_name
  writeReg CNTKCTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTKCTL_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTKCTL r

def undefined_CNTV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTV_CTL ) : SailM CNTV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTV_CTL_EL0) 0 32)))

def CNTV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTV_CTL_Type := value_name
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTV_CTL r

def CPACR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CPACR_Type := value_name
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CPACR r

def undefined_CSSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CSSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def CSSELR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CSSELR_NS ) : SailM CSSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CSSELR_EL1) 0 32)))

def CSSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CSSELR_Type ()) ) : SailM CSSELR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CSSELR_S)
  else (do (CSSELR_NS_read ())))

def CSSELR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  writeReg CSSELR_EL1 (Sail.BitVec.updateSubrange (← readReg CSSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CSSELR_NS r

def CSSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CSSELR_S r)
  else (do (CSSELR_NS_write r)))

def undefined_CTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CTR ) : SailM CTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CTR_EL0) 0 32)))

def CTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CTR_Type := value_name
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CTR r

def undefined_DBGAUTHSTATUS_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGAUTHSTATUS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGAUTHSTATUS ) : SailM DBGAUTHSTATUS_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGAUTHSTATUS_EL1) 0 32)))

def DBGAUTHSTATUS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGAUTHSTATUS_Type := value_name
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGAUTHSTATUS r

def undefined_DBGCLAIMCLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMCLR ) : SailM DBGCLAIMCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMCLR_EL1) 0 32)))

def DBGCLAIMCLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMCLR_Type := value_name
  writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMCLR r

def undefined_DBGCLAIMSET_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMSET_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMSET ) : SailM DBGCLAIMSET_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMSET_EL1) 0 32)))

def DBGCLAIMSET_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMSET_Type := value_name
  writeReg DBGCLAIMSET_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMSET_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMSET r

def undefined_MDCCINT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDCCINT_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGDCCINT_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDCCINT ) : SailM DBGDCCINT_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDCCINT_EL1) 0 32)))

def DBGDCCINT_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDCCINT_Type := value_name
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGDCCINT r

def undefined_MDRAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDRAR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def DBGDRAR_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _DBGDRAR ) : SailM DBGDRAR_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg MDRAR_EL1) 0 64)))

def DBGDRAR_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : DBGDRAR_Type := value_name
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _DBGDRAR r

def DBGOSDLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSDLR_Type := value_name
  writeReg OSDLR_EL1 (Sail.BitVec.updateSubrange (← readReg OSDLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSDLR r

def DBGOSLSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSLSR_Type := value_name
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSLSR r

def DBGPRCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGPRCR_Type := value_name
  writeReg DBGPRCR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGPRCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGPRCR r

def undefined_DBGVCR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGVCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGVCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGVCR ) : SailM DBGVCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGVCR32_EL2) 0 32)))

def DBGVCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGVCR_Type := value_name
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGVCR r

def DFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DFSR_NS ) : SailM DFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ESR_EL1) 0 32)))

def DFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_DFSR_Type ()) ) : SailM DFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg DFSR_S)
  else (do (DFSR_NS_read ())))

def DISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DISR ) : SailM DISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DISR_EL1) 0 32)))

def DSPSR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DSPSR2 ) : SailM DSPSR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DSPSR_EL0) 32 32)))

def EDECCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDECCR_Type := value_name
  writeReg OSECCR_EL1 (Sail.BitVec.updateSubrange (← readReg OSECCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _EDECCR r

def EDSCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDSCR2_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _EDSCR2 r

def undefined_ERRIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRIDR ) : SailM ERRIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRIDR_EL1) 0 32)))

def ERRIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRIDR_Type := value_name
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRIDR r

def undefined_ERRSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRSELR ) : SailM ERRSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRSELR_EL1) 0 32)))

def ERRSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRSELR_Type := value_name
  writeReg ERRSELR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRSELR r

def HCPTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCPTR_Type := value_name
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCPTR r

def HCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR2_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 63 32 (BitVec.slice r 0 32))
  writeReg _HCR2 r

def HDCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HDCR_Type := value_name
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HDCR r

def undefined_RMR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HRMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HRMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HRMR ) : SailM HRMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg RMR_EL2) 0 32)))

def HRMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HRMR_Type := value_name
  writeReg RMR_EL2 (Sail.BitVec.updateSubrange (← readReg RMR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HRMR r

def HSCTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSCTLR_Type := value_name
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSCTLR r

def undefined_HSTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HSTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HSTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HSTR ) : SailM HSTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HSTR_EL2) 0 32)))

def HSTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSTR_Type := value_name
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSTR r

def undefined_HTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTCR ) : SailM HTCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL2) 0 32)))

def HTCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTCR_Type := value_name
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTCR r

def undefined_TRFCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HTRFCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTRFCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTRFCR ) : SailM HTRFCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TRFCR_EL2) 0 32)))

def HTRFCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTRFCR_Type := value_name
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTRFCR r

def HVBAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HVBAR_Type := value_name
  writeReg VBAR_EL2 (Sail.BitVec.updateSubrange (← readReg VBAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HVBAR r

def undefined_ICC_ASGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_ASGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_ASGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_ASGI1R ) : SailM ICC_ASGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_ASGI1R_EL1) 0 64)))

def ICC_ASGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_ASGI1R_Type := value_name
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_ASGI1R r

def undefined_ICC_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR0 ) : SailM ICC_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR0_EL1) 0 32)))

def ICC_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR0_Type := value_name
  writeReg ICC_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR0 r

def undefined_ICC_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_NS ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_NS) 0 32)))

def ICC_BPR1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_S ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_S) 0 32)))

def ICC_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_BPR1_Type ()) ) : SailM ICC_BPR1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_read ()))
  else (do (ICC_BPR1_NS_read ())))

def ICC_BPR1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_NS r

def ICC_BPR1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_S r

def ICC_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_write r))
  else (do (ICC_BPR1_NS_write r)))

def undefined_ICC_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_CTLR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_NS ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_NS) 0 32)))

def ICC_CTLR_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_S ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_S) 0 32)))

def ICC_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_CTLR_Type ()) ) : SailM ICC_CTLR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_read ()))
  else (do (ICC_CTLR_NS_read ())))

def ICC_CTLR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_NS r

def ICC_CTLR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_S r

def ICC_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_write r))
  else (do (ICC_CTLR_NS_write r)))

def undefined_ICC_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_DIR ) : SailM ICC_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_DIR_EL1) 0 32)))

def ICC_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_DIR_Type := value_name
  writeReg ICC_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_DIR r

def undefined_ICC_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR0 ) : SailM ICC_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR0_EL1) 0 32)))

def ICC_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR0_Type := value_name
  writeReg ICC_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR0 r

def undefined_ICC_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_EOIR1 ) : SailM ICC_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_EOIR1_EL1) 0 32)))

def ICC_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_EOIR1_Type := value_name
  writeReg ICC_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_EOIR1 r

def undefined_ICC_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR0 ) : SailM ICC_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR0_EL1) 0 32)))

def ICC_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR0_Type := value_name
  writeReg ICC_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR0 r

def undefined_ICC_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HPPIR1 ) : SailM ICC_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_HPPIR1_EL1) 0 32)))

def ICC_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HPPIR1_Type := value_name
  writeReg ICC_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HPPIR1 r

def undefined_ICC_SRE_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_HSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_HSRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_HSRE ) : SailM ICC_HSRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL2) 0 32)))

def ICC_HSRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_HSRE_Type := value_name
  writeReg ICC_SRE_EL2 (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_HSRE r

def undefined_ICC_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR0 ) : SailM ICC_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR0_EL1) 0 32)))

def ICC_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR0_Type := value_name
  writeReg ICC_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR0 r

def undefined_ICC_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IAR1 ) : SailM ICC_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IAR1_EL1) 0 32)))

def ICC_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IAR1_Type := value_name
  writeReg ICC_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IAR1 r

def undefined_ICC_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN0 ) : SailM ICC_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN0_EL1) 0 32)))

def ICC_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN0_Type := value_name
  writeReg ICC_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN0 r

def undefined_ICC_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_IGRPEN1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_NS ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_NS) 0 32)))

def ICC_IGRPEN1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_IGRPEN1_S ) : SailM ICC_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_IGRPEN1_EL1_S) 0 32)))

def ICC_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_IGRPEN1_Type ()) ) : SailM ICC_IGRPEN1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_read ()))
  else (do (ICC_IGRPEN1_NS_read ())))

def ICC_IGRPEN1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_NS r

def ICC_IGRPEN1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  writeReg ICC_IGRPEN1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_IGRPEN1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_IGRPEN1_S r

def ICC_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_IGRPEN1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_IGRPEN1_S_write r))
  else (do (ICC_IGRPEN1_NS_write r)))

def undefined_ICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_PMR ) : SailM ICC_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_PMR_EL1) 0 32)))

def ICC_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_PMR_Type := value_name
  writeReg ICC_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_PMR r

def undefined_ICC_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_RPR ) : SailM ICC_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_RPR_EL1) 0 32)))

def ICC_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_RPR_Type := value_name
  writeReg ICC_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_RPR r

def undefined_ICC_SGI0R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI0R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI0R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI0R ) : SailM ICC_SGI0R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI0R_EL1) 0 64)))

def ICC_SGI0R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI0R_Type := value_name
  writeReg ICC_SGI0R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI0R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI0R r

def undefined_ICC_SGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_SGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_SGI1R ) : SailM ICC_SGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_SGI1R_EL1) 0 64)))

def ICC_SGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SGI1R_Type := value_name
  writeReg ICC_SGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_SGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_SGI1R r

def undefined_ICC_SRE_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_SRE_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_NS ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_NS) 0 32)))

def ICC_SRE_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_SRE_S ) : SailM ICC_SRE_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_SRE_EL1_S) 0 32)))

def ICC_SRE_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_SRE_Type ()) ) : SailM ICC_SRE_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_read ()))
  else (do (ICC_SRE_NS_read ())))

def ICC_SRE_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_NS r

def ICC_SRE_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  writeReg ICC_SRE_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_SRE_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_SRE_S r

def ICC_SRE_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_SRE_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_SRE_S_write r))
  else (do (ICC_SRE_NS_write r)))

def undefined_ICH_EISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_EISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_EISR ) : SailM ICH_EISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_EISR_EL2) 0 32)))

def ICH_EISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_EISR_Type := value_name
  writeReg ICH_EISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_EISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_EISR r

def undefined_ICH_ELRSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_ELRSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_ELRSR ) : SailM ICH_ELRSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_ELRSR_EL2) 0 32)))

def ICH_ELRSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_ELRSR_Type := value_name
  writeReg ICH_ELRSR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_ELRSR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_ELRSR r

def undefined_ICH_HCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_HCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_HCR ) : SailM ICH_HCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_HCR_EL2) 0 32)))

def ICH_HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_HCR_Type := value_name
  writeReg ICH_HCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_HCR r

def undefined_ICH_MISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_MISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_MISR ) : SailM ICH_MISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_MISR_EL2) 0 32)))

def ICH_MISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_MISR_Type := value_name
  writeReg ICH_MISR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_MISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_MISR r

def undefined_ICH_VMCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VMCR ) : SailM ICH_VMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VMCR_EL2) 0 32)))

def ICH_VMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VMCR_Type := value_name
  writeReg ICH_VMCR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VMCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VMCR r

def undefined_ICH_VTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICH_VTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICH_VTR ) : SailM ICH_VTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICH_VTR_EL2) 0 32)))

def ICH_VTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICH_VTR_Type := value_name
  writeReg ICH_VTR_EL2 (Sail.BitVec.updateSubrange (← readReg ICH_VTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ICH_VTR r

def undefined_ICV_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR0 ) : SailM ICV_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR0_EL1) 0 32)))

def ICV_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR0_Type := value_name
  writeReg ICV_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR0 r

def undefined_ICV_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_BPR1 ) : SailM ICV_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_BPR1_EL1) 0 32)))

def ICV_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_BPR1_Type := value_name
  writeReg ICV_BPR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_BPR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_BPR1 r

def undefined_ICV_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_CTLR ) : SailM ICV_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_CTLR_EL1) 0 32)))

def ICV_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_CTLR_Type := value_name
  writeReg ICV_CTLR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_CTLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_CTLR r

def undefined_ICV_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_DIR ) : SailM ICV_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_DIR_EL1) 0 32)))

def ICV_DIR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_DIR_Type := value_name
  writeReg ICV_DIR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_DIR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_DIR r

def undefined_ICV_EOIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR0 ) : SailM ICV_EOIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR0_EL1) 0 32)))

def ICV_EOIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR0_Type := value_name
  writeReg ICV_EOIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR0 r

def undefined_ICV_EOIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_EOIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_EOIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_EOIR1 ) : SailM ICV_EOIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_EOIR1_EL1) 0 32)))

def ICV_EOIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_EOIR1_Type := value_name
  writeReg ICV_EOIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_EOIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_EOIR1 r

def undefined_ICV_HPPIR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR0 ) : SailM ICV_HPPIR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR0_EL1) 0 32)))

def ICV_HPPIR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR0_Type := value_name
  writeReg ICV_HPPIR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR0 r

def undefined_ICV_HPPIR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_HPPIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_HPPIR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_HPPIR1 ) : SailM ICV_HPPIR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_HPPIR1_EL1) 0 32)))

def ICV_HPPIR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_HPPIR1_Type := value_name
  writeReg ICV_HPPIR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_HPPIR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_HPPIR1 r

def undefined_ICV_IAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR0 ) : SailM ICV_IAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR0_EL1) 0 32)))

def ICV_IAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR0_Type := value_name
  writeReg ICV_IAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR0 r

def undefined_ICV_IAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IAR1 ) : SailM ICV_IAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IAR1_EL1) 0 32)))

def ICV_IAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IAR1_Type := value_name
  writeReg ICV_IAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IAR1 r

def undefined_ICV_IGRPEN0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN0 ) : SailM ICV_IGRPEN0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN0_EL1) 0 32)))

def ICV_IGRPEN0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN0_Type := value_name
  writeReg ICV_IGRPEN0_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN0 r

def undefined_ICV_IGRPEN1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_IGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_IGRPEN1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_IGRPEN1 ) : SailM ICV_IGRPEN1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_IGRPEN1_EL1) 0 32)))

def ICV_IGRPEN1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_IGRPEN1_Type := value_name
  writeReg ICV_IGRPEN1_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_IGRPEN1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_IGRPEN1 r

def undefined_ICV_PMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_PMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_PMR ) : SailM ICV_PMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_PMR_EL1) 0 32)))

def ICV_PMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_PMR_Type := value_name
  writeReg ICV_PMR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_PMR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_PMR r

def undefined_ICV_RPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICV_RPR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICV_RPR ) : SailM ICV_RPR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICV_RPR_EL1) 0 32)))

def ICV_RPR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICV_RPR_Type := value_name
  writeReg ICV_RPR_EL1 (Sail.BitVec.updateSubrange (← readReg ICV_RPR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICV_RPR r

def ID_AFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_AFR0 ) : SailM ID_AFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_AFR0_EL1) 0 32)))

def ID_AFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_AFR0_Type := value_name
  writeReg ID_AFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_AFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_AFR0 r

def undefined_ID_DFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_DFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_DFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_DFR1 ) : SailM ID_DFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_DFR1_EL1) 0 32)))

def ID_DFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_DFR1_Type := value_name
  writeReg ID_DFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_DFR1 r

def undefined_ID_ISAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR0 ) : SailM ID_ISAR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR0_EL1) 0 32)))

def ID_ISAR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR0_Type := value_name
  writeReg ID_ISAR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR0 r

def undefined_ID_ISAR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR5 ) : SailM ID_ISAR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR5_EL1) 0 32)))

def ID_ISAR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR5_Type := value_name
  writeReg ID_ISAR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR5 r

def undefined_ID_MMFR5_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR5_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR5_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR5 ) : SailM ID_MMFR5_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR5_EL1) 0 32)))

def ID_MMFR5_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR5_Type := value_name
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR5 r

def undefined_ID_PFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR2 ) : SailM ID_PFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR2_EL1) 0 32)))

def ID_PFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR2_Type := value_name
  writeReg ID_PFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR2 r

def IFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _IFSR_NS ) : SailM IFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg IFSR32_EL2) 0 32)))

def IFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_IFSR_Type ()) ) : SailM IFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg IFSR_S)
  else (do (IFSR_NS_read ())))

def undefined_ISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ISR ) : SailM ISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ISR_EL1) 0 32)))

def ISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ISR_Type := value_name
  writeReg ISR_EL1 (Sail.BitVec.updateSubrange (← readReg ISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ISR r

def undefined_MPIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MPIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MPIDR ) : SailM MPIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MPIDR_EL1) 0 32)))

def MPIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MPIDR_Type := value_name
  writeReg MPIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MPIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MPIDR r

def undefined_MVFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)


end ArmASL.Functions
