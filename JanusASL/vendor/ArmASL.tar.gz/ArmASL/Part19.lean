import ArmASL.Part18

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def APDBKeyHi_EL1_SysRegWrite_dcaaae97706e7922 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APDBKey ← (( do (pure (_get_HFGWTR_EL2_Type_APDBKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APDBKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APDBKeyHi_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APDBKeyHi_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APDBKeyHi_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APDBKeyLo_EL1_SysRegWrite_e5f3a17864e0bd24 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APDBKey ← (( do (pure (_get_HFGWTR_EL2_Type_APDBKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APDBKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APDBKeyLo_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APDBKeyLo_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APDBKeyLo_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APGAKeyHi_EL1_SysRegWrite_5d36b28ead1bb298 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APGAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APGAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APGAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APGAKeyHi_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APGAKeyHi_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APGAKeyHi_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APGAKeyLo_EL1_SysRegWrite_8f5946d931efbfec (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APGAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APGAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APGAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APGAKeyLo_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APGAKeyLo_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APGAKeyLo_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APIAKeyHi_EL1_SysRegWrite_dd50986e83c65aba (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APIAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APIAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APIAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APIAKeyHi_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APIAKeyHi_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APIAKeyHi_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APIAKeyLo_EL1_SysRegWrite_19be32b7aee48c9e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APIAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APIAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APIAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APIAKeyLo_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APIAKeyLo_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APIAKeyLo_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APIBKeyHi_EL1_SysRegWrite_0d10c61af3148541 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APIBKey ← (( do (pure (_get_HFGWTR_EL2_Type_APIBKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APIBKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APIBKeyHi_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APIBKeyHi_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APIBKeyHi_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APIBKeyLo_EL1_SysRegWrite_7cc3f2a575353b80 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APIBKey ← (( do (pure (_get_HFGWTR_EL2_Type_APIBKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APIBKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APIBKeyLo_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APIBKeyLo_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APIBKeyLo_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBCR_EL1_SysRegWrite_bacf32e45cccac33 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x8E0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                       if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                       then true
                                       else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                                   if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                                   then true
                                                   else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg BRBCR_EL1 (Mk_BRBCR_EL1_Type (← (X_read t 64))))))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg BRBCR_EL1 (Mk_BRBCR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBCR_EL2_SysRegWrite_0f11184bdbd7fffd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBCTL ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBCTL (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBCTL == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                            then (do (NVMem_set (BitVec.toNat 0x8E0#12) (← (X_read t 64))))
                                            else (do writeReg BRBCR_EL1 (Mk_BRBCR_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                            then (do writeReg BRBCR_EL2 (Mk_BRBCR_EL2_Type (← (X_read t 64))))
                                            else (do writeReg BRBCR_EL1 (Mk_BRBCR_EL1_Type (← (X_read t 64))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg BRBCR_EL1 (Mk_BRBCR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBCR_EL2_SysRegWrite_df7df73141024675 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg BRBCR_EL2 (Mk_BRBCR_EL2_Type (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg BRBCR_EL2 (Mk_BRBCR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBFCR_EL1_SysRegWrite_feda6cd6c387772e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBCTL ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBCTL (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBCTL == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg BRBFCR_EL1 (Mk_BRBFCR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg BRBFCR_EL1 (Mk_BRBFCR_EL1_Type (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg BRBFCR_EL1 (Mk_BRBFCR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBINFINJ_EL1_SysRegWrite_9211713f1bfc2916 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBDATA ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBDATA (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBDATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBINFINJ_EL1 (Mk_BRBINFINJ_EL1_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBINFINJ_EL1 (Mk_BRBINFINJ_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_BRBINFINJ_EL1 (Mk_BRBINFINJ_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBSRCINJ_EL1_SysRegWrite_68622081934254f0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBDATA ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBDATA (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBDATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBSRCINJ_EL1 (Mk_BRBSRCINJ_EL1_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBSRCINJ_EL1 (Mk_BRBSRCINJ_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_BRBSRCINJ_EL1 (Mk_BRBSRCINJ_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBTGTINJ_EL1_SysRegWrite_3fc8f3855af3c754 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBDATA ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBDATA (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBDATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBTGTINJ_EL1 (Mk_BRBTGTINJ_EL1_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (__set_BRBTGTINJ_EL1 (Mk_BRBTGTINJ_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_BRBTGTINJ_EL1 (Mk_BRBTGTINJ_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def BRBTS_EL1_SysRegWrite_377bbfb5528b4be3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_SBRBE ← (( do (pure (_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3))) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_nBRBDATA ← (( do (pure (_get_HDFGWTR_EL2_Type_nBRBDATA (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__3 := __MDCR_EL3_SBRBE
                           if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                           then true
                           else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_nBRBDATA == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__2 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg BRBTS_EL1 (Mk_BRBTS_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                             (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (let b__1 := __MDCR_EL3_SBRBE
                                 if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                 then true
                                 else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if ((((HaveEL EL3) && (__MDCR_EL3_SBRBE != 0b11#2)) && (__SCR_EL3_NS == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((((HaveEL EL3) && (let b__0 := __MDCR_EL3_SBRBE
                                             if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                             then true
                                             else false : Bool)) && (__SCR_EL3_NS == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg BRBTS_EL1 (Mk_BRBTS_EL1_Type (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg BRBTS_EL1 (Mk_BRBTS_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTFRQ_EL0_SysRegWrite_f59bce36e5e3ca32 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg CNTFRQ_EL0 (← (X_read t 64)))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def CNTHCTL_EL2_SysRegWrite_c57f8627acf05dc2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do writeReg CNTKCTL_EL1 (Mk_CNTKCTL_EL1_Type (← (X_read t 64))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTHCTL_EL2 (Mk_CNTHCTL_EL2_Type (← (X_read t 64))))
                    else (do writeReg CNTKCTL_EL1 (Mk_CNTKCTL_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTKCTL_EL1 (Mk_CNTKCTL_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHCTL_EL2_SysRegWrite_ee82b0f294f84a10 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTHCTL_EL2 (Mk_CNTHCTL_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTHCTL_EL2 (Mk_CNTHCTL_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHPS_CTL_EL2_SysRegWrite_409af44f6007e1b5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0PTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0PTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PCEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PCEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0PTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b10#2))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0PTEN == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                                     (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                                then (do (__set_CNTHPS_CTL_EL2 (Mk_CNTHPS_CTL_EL2_Type (← (X_read t 64)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                           (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                      then (do (__set_CNTHP_CTL_EL2 (Mk_CNTHP_CTL_EL2_Type (← (X_read t 64)))))
                                      else (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x180#12) (← (X_read t 64))))
                          else (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do (__set_CNTHPS_CTL_EL2 (Mk_CNTHPS_CTL_EL2_Type (← (X_read t 64)))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do (__set_CNTHP_CTL_EL2 (Mk_CNTHP_CTL_EL2_Type (← (X_read t 64)))))
                          else (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHPS_CTL_EL2_SysRegWrite_c59654dd3579a2a6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (__set_CNTHPS_CTL_EL2 (Mk_CNTHPS_CTL_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (__set_CNTHPS_CTL_EL2 (Mk_CNTHPS_CTL_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHPS_CVAL_EL2_SysRegWrite_b8b5a6dbe1e48dd1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHPS_TVAL_EL2_SysRegWrite_f57d636a80644cd9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHP_CTL_EL2_SysRegWrite_52dddcddc87d9536 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (__set_CNTHP_CTL_EL2 (Mk_CNTHP_CTL_EL2_Type (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_CNTHP_CTL_EL2 (Mk_CNTHP_CTL_EL2_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHP_CVAL_EL2_SysRegWrite_52ce6fca4007d2da (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHP_CVAL_EL2_SysRegWrite_ead9355a45d8e73b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0PTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0PTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PCEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PCEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0PTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b10#2))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0PTEN == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                                     (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                                then (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type (← (X_read t 64))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                           (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                      then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type (← (X_read t 64))))
                                      else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x178#12) (← (X_read t 64))))
                          else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type (← (X_read t 64))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type (← (X_read t 64))))
                          else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHP_TVAL_EL2_SysRegWrite_7488d8357bdbd8b8 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHVS_CTL_EL2_SysRegWrite_9787f6cf7c77decc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (__set_CNTHVS_CTL_EL2 (Mk_CNTHVS_CTL_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (__set_CNTHVS_CTL_EL2 (Mk_CNTHVS_CTL_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHVS_CTL_EL2_SysRegWrite_e967874807c6082c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0VTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0VTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0VTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0VTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1TVT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1TVT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0VTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0VTEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                               (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                          then (do (__set_CNTHVS_CTL_EL2 (Mk_CNTHVS_CTL_EL2_Type (← (X_read t 64)))))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                then (do (__set_CNTHV_CTL_EL2 (Mk_CNTHV_CTL_EL2_Type (← (X_read t 64)))))
                                else (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x170#12) (← (X_read t 64))))
                    else (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do (__set_CNTHVS_CTL_EL2 (Mk_CNTHVS_CTL_EL2_Type (← (X_read t 64)))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do (__set_CNTHV_CTL_EL2 (Mk_CNTHV_CTL_EL2_Type (← (X_read t 64)))))
                          else (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHVS_CVAL_EL2_SysRegWrite_5acd4d20ee782a13 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHVS_TVAL_EL2_SysRegWrite_e71ca762af073cad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((! (← (IsCurrentSecurityState SS_Secure))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_EEL2 == 0#1) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHV_CTL_EL2_SysRegWrite_33f75e4b41646088 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (__set_CNTHV_CTL_EL2 (Mk_CNTHV_CTL_EL2_Type (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_CNTHV_CTL_EL2 (Mk_CNTHV_CTL_EL2_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHV_CVAL_EL2_SysRegWrite_16bd78456d53d9ab (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0VTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0VTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0VTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0VTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1TVT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1TVT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0VTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0VTEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                               (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                          then (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type (← (X_read t 64))))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type (← (X_read t 64))))
                                else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x168#12) (← (X_read t 64))))
                    else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type (← (X_read t 64))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type (← (X_read t 64))))
                          else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHV_CVAL_EL2_SysRegWrite_a0eabf75b26da37c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHV_TVAL_EL2_SysRegWrite_6e74ff633c511335 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTHV_TVAL_EL2_SysRegWrite_b6bfac5d17f766fc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0VTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0VTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0VTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0VTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1TVT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1TVT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0VTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0VTEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                               (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                          then (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                                else
                                  (do (if ((←((pure (HaveEL EL2)) <&&> (do
                                           (pure (! (← (EL2Enabled ())))) <||> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2)))))) : Bool)
                                      then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                                      else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__CNTHCTL_EL2_EL1TVT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((HaveEL EL2) : Bool)
                    then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                    else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do writeReg CNTHVS_CVAL_EL2 (Mk_CNTHVS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do writeReg CNTHV_CVAL_EL2 (Mk_CNTHV_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                          else
                            (do (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                                then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                                else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((←((pure (HaveEL EL2)) <&&> (do
                               (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
                          then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                          else
                            (do (if ((←((pure (HaveEL EL2)) <&&> (do
                                     (ELUsingAArch32 EL2)))) : Bool)
                                then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← (CNTVOFF_read ())))))
                                else (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTKCTL_EL1_SysRegWrite_b6b89671d5078ba5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTKCTL_EL1 (Mk_CNTKCTL_EL1_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CNTKCTL_EL1 (Mk_CNTKCTL_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTPOFF_EL2_SysRegWrite_daa2a43614202ee5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ECVEn ← (( do (pure (_get_SCR_EL3_Type_ECVEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x1A8#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ECVEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ECVEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg CNTPOFF_EL2 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTPOFF_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTPS_CTL_EL1_SysRegWrite_22bfd6d865a619e7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ST ← (( do (pure (_get_SCR_EL3_Type_ST (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__SCR_EL3_NS == 0#1)) : Bool)
              then
                (do (if ((__SCR_EL3_EEL2 == 1#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__SCR_EL3_ST == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do (__set_CNTPS_CTL_EL1 (Mk_CNTPS_CTL_EL1_Type (← (X_read t 64)))))))))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (__set_CNTPS_CTL_EL1 (Mk_CNTPS_CTL_EL1_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTPS_CVAL_EL1_SysRegWrite_0efe14958ca47dee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ST ← (( do (pure (_get_SCR_EL3_Type_ST (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__SCR_EL3_NS == 0#1)) : Bool)
              then
                (do (if ((__SCR_EL3_EEL2 == 1#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__SCR_EL3_ST == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg CNTPS_CVAL_EL1 (Mk_CNTPS_CVAL_EL1_Type (← (X_read t 64))))))))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTPS_CVAL_EL1 (Mk_CNTPS_CVAL_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTPS_TVAL_EL1_SysRegWrite_fed363b581c49e0d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_EEL2 ← (( do (pure (_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ST ← (( do (pure (_get_SCR_EL3_Type_ST (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ECVEn ← (( do (pure (_get_SCR_EL3_Type_ECVEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_ECV ← (( do (pure (_get_CNTHCTL_EL2_Type_ECV (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((HaveEL EL3) && (__SCR_EL3_NS == 0#1)) : Bool)
              then
                (do (if ((__SCR_EL3_EEL2 == 1#1) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__SCR_EL3_ST == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((((←((IsFeatureImplemented FEAT_ECV) <&&> (do
                                         (EL2Enabled ())))) && (__SCR_EL3_ECVEn == 1#1)) && (__CNTHCTL_EL2_ECV == 1#1)) : Bool)
                                then (do writeReg CNTPS_CVAL_EL1 (Mk_CNTPS_CVAL_EL1_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTPOFF_EL2))))
                                else (do writeReg CNTPS_CVAL_EL1 (Mk_CNTPS_CVAL_EL1_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTPS_CVAL_EL1 (Mk_CNTPS_CVAL_EL1_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTP_CTL_EL0_SysRegWrite_6000d5c756b25763 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTHCTL_EL2_EL1NVPCT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1NVPCT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1NVPCT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (NVMem_set (BitVec.toNat 0x180#12) (← (X_read t 64))))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do (__set_CNTP_CTL_EL0 (Mk_CNTP_CTL_EL0_Type (← (X_read t 64)))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTP_CVAL_EL0_SysRegWrite_226b60eb1c89b722 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTHCTL_EL2_EL1NVPCT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1NVPCT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1NVPCT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (NVMem_set (BitVec.toNat 0x178#12) (← (X_read t 64))))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTP_TVAL_EL0_SysRegWrite_4aac8466b90febf7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTP_TVAL_EL0_SysRegWrite_eccdee10d8c7f39e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTKCTL_EL1_EL0PTEN ← (( do (pure (_get_CNTKCTL_EL1_Type_EL0PTEN (← readReg CNTKCTL_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PCEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PCEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL1PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_EL0PTEN ← (( do (pure (_get_CNTHCTL_EL2_Type_EL0PTEN (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ECVEn ← (( do (pure (_get_SCR_EL3_Type_ECVEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __CNTHCTL_EL2_ECV ← (( do (pure (_get_CNTHCTL_EL2_Type_ECV (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((! (←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CNTKCTL_EL1_EL0PTEN == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b10#2))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CNTHCTL_EL2_EL0PTEN == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                     (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                                     (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                                then (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))) <&&> (do
                                           (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                                      then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                                      else
                                        (do (if ((←((pure (((←((IsFeatureImplemented FEAT_ECV) <&&> (do (EL2Enabled ())))) && (__SCR_EL3_ECVEn == 1#1)) && (__CNTHCTL_EL2_ECV == 1#1))) <&&> (do
                                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) : Bool)
                                            then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTPOFF_EL2))))
                                            else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))) && (__CNTHCTL_EL2_EL1PCEN == 0#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) && (__CNTHCTL_EL2_EL1PTEN == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((IsFeatureImplemented FEAT_ECV) <&&> (do
                                   (EL2Enabled ())))) && (__SCR_EL3_ECVEn == 1#1)) && (__CNTHCTL_EL2_ECV == 1#1)) : Bool)
                          then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTPOFF_EL2))))
                          else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                         (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 0#1))) <&&> (do
                         (IsFeatureImplemented FEAT_SEL2)))) : Bool)
                    then (do writeReg CNTHPS_CVAL_EL2 (Mk_CNTHPS_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else
                      (do (if ((←((pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)) <&&> (do
                               (pure ((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1))))) : Bool)
                          then (do writeReg CNTHP_CVAL_EL2 (Mk_CNTHP_CVAL_EL2_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                          else (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTP_CVAL_EL0 (Mk_CNTP_CVAL_EL0_Type ((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTVOFF_EL2_SysRegWrite_926108484bd738bb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x060#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CNTVOFF_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CNTVOFF_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTV_CTL_EL0_SysRegWrite_18ae5268f90eea09 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTHCTL_EL2_EL1NVVCT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1NVVCT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1NVVCT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (NVMem_set (BitVec.toNat 0x170#12) (← (X_read t 64))))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do (__set_CNTV_CTL_EL0 (Mk_CNTV_CTL_EL0_Type (← (X_read t 64)))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CNTV_CVAL_EL0_SysRegWrite_ad2fa653919bf7cc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __CNTHCTL_EL2_EL1NVVCT ← (( do (pure (_get_CNTHCTL_EL2_Type_EL1NVVCT (← readReg CNTHCTL_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) && (__CNTHCTL_EL2_EL1NVVCT == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (NVMem_set (BitVec.toNat 0x168#12) (← (X_read t 64))))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))


end ArmASL.Functions
