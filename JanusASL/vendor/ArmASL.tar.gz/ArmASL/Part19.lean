import ArmASL.Part18

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def _get_HDFGWTR2_EL2_Type_nSPMSELR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def __set_CNTHP_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHP_CTL_EL2_Type := value_name
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def undefined_SPMACCESSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __get_selected_SPMACCESSR_EL2_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL2) idx 2))

def Mk_PMZR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMICNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_IGRPEN1_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_LORSA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSWINC_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTV_CTL_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTV_CTL_EL0_Type := value_name
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 1 0 (BitVec.slice r 0 2))
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 63 3 (BitVec.slice r 3 61))

def undefined_PMIAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMIAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICH_VMCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_VMCR_EL2_Type_VBPR0 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 23 21)

def _get_ICH_VMCR_EL2_Type_VBPR1 (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 20 18)

def _get_ICH_VMCR_EL2_Type_VCBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_ICH_VMCR_EL2_Type_VENG0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICH_VMCR_EL2_Type_VENG1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICH_VMCR_EL2_Type_VEOIM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_ICH_VMCR_EL2_Type_VPMR (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def Mk_VPIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_CTLR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICC_CTLR_EL3_Type_nDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def __set_SCTLR_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : SCTLR_EL2_Type := value_name
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 6 0 (BitVec.slice r 0 7))
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 63 8 (BitVec.slice r 8 56))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_ITD")))) : Bool)
  then (do writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 7 7 (_get_SCTLR_EL2_Type_ITD r)))
  else (do (pure ())))

def Mk_ICC_SRE_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTPS_CTL_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTPS_CTL_EL1_Type := value_name
  writeReg CNTPS_CTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_CTL_EL1) 1 0 (BitVec.slice r 0 2))
  writeReg CNTPS_CTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTPS_CTL_EL1) 63 3 (BitVec.slice r 3 61))

def Mk_LORC_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_ASGI1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGRTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGWTR2_EL2_Type_nPFAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HFGWTR2_EL2_Type_nRCWSMASK_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def Mk_RMR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICH_HCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_HCR_EL2_Type_TALL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_ICH_HCR_EL2_Type_TALL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_ICH_HCR_EL2_Type_TDIR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def Mk_ICC_IGRPEN0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_EOIR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_PMCR_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMCR_EL0_Type := value_name
  writeReg PMCR_EL0 (BitVec.update (← readReg PMCR_EL0) 0 (Bit (BitVec.slice r 0 1)))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 15 3 (BitVec.slice r 3 13))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 63 32 (BitVec.slice r 32 32))
  (if ((! (! (← (IsFeatureImplemented FEAT_PMUv3p7)))) : Bool)
  then (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 31 24 (_get_PMCR_EL0_Type_IMP r)))
  else (do (pure ())))
  (if ((! ((_get_PMCR_EL0_Type_IMP (← readReg PMCR_EL0)) != 0b00000000#8)) : Bool)
  then (do writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 23 16 (_get_PMCR_EL0_Type_IDCODE r)))
  else (do (pure ())))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 2 2 (_get_PMCR_EL0_Type_C r))
  writeReg PMCR_EL0 (Sail.BitVec.updateSubrange (← readReg PMCR_EL0) 1 1 (_get_PMCR_EL0_Type_P r))

def Mk_HDFGRTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_VMPIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICH_VTR_EL2_Type_PREbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 28 26)

def __set_MDSELR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MDSELR_EL1_Type := value_name
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 3 0 (BitVec.slice r 0 4))
  writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 63 6 (BitVec.slice r 6 58))
  (if ((! (←((pure ((← readReg NUM_BREAKPOINTS) ≤b 16)) <&&> (do
         (pure ((← readReg NUM_WATCHPOINTS) ≤b 16)))))) : Bool)
  then (do writeReg MDSELR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSELR_EL1) 5 4 (_get_MDSELR_EL1_Type_BANK r)))
  else (do (pure ())))

def DBGDTR_EL0_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : DBGDTR_EL0_Type := value_name
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 32 32)))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 32 32)))
        else (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 32 32))))))
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 0 32)))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do writeReg DBGDTRRX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRRX_EL0) 31 0 (BitVec.slice r 0 32)))
        else (do writeReg DBGDTRTX_EL0 (Sail.BitVec.updateSubrange (← readReg DBGDTRTX_EL0) 31 0 (BitVec.slice r 0 32))))))
  writeReg _DBGDTR_EL0 r

def Mk_ICV_EOIR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RNDRRS_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_LORN_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_IGRPEN0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SMPRIMAP_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMPRIMAP_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RNDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGRTR_EL2_Type_DCZID_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def Mk_ICV_IGRPEN1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGWTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SGI1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SRE_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HDFGWTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR_EL2_Type_OSLAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HDFGWTR_EL2_Type_PMCR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_HDFGWTR_EL2_Type_PMSWINC_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_HDFGWTR_EL2_Type_TRFCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def undefined_ICV_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICV_AP1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_LOREA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_DIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_DBGCLAIMCLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPMACCESSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __get_selected_SPMACCESSR_EL3_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL3) idx 2))

def __set_CNTHV_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHV_CTL_EL2_Type := value_name
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def Mk_ICC_EOIR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CNTVOFF_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _CNTVOFF ) : SailM CNTVOFF_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg CNTVOFF_EL2) 0 64)))

def undefined_CNTV_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def __set_MPAM2_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM2_EL2_Type := value_name
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 53 0 (BitVec.slice r 0 54))
  writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 62 55 (BitVec.slice r 55 8))
  (if ((! (HaveEL EL3)) : Bool)
  then (do writeReg MPAM2_EL2 (Sail.BitVec.updateSubrange (← readReg MPAM2_EL2) 63 63 (_get_MPAM2_EL2_Type_MPAMEN r)))
  else (do (pure ())))

def __set_MPAM3_EL3 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM3_EL3_Type := value_name
  (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 63 (← (MPAM3_EL3_read ())) 0 (BitVec.slice r 0 63))))
  (MPAM3_EL3_write (_update_MPAM3_EL3_Type_MPAMEN (← (MPAM3_EL3_read ())) (_get_MPAM3_EL3_Type_MPAMEN r)))

def __set_MPAM1_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM1_EL1_Type := value_name
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 54 (← (MPAM1_EL1_read ())) 0 (BitVec.slice r 0 54))))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 5 (← (MPAM1_EL1_read ())) 55 (BitVec.slice r 55 5))))
  (MPAM1_EL1_write (Mk_MPAM1_EL1_Type (set_slice 2 (← (MPAM1_EL1_read ())) 61 (BitVec.slice r 61 2))))
  (if (((! (HaveEL EL3)) && (! (HaveEL EL2))) : Bool)
  then (do (MPAM1_EL1_write (_update_MPAM1_EL1_Type_MPAMEN (← (MPAM1_EL1_read ())) (_get_MPAM1_EL1_Type_MPAMEN r))))
  else (do (pure ())))

def undefined_AMEVCNTR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVCNTR1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVCNTR0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMEVCNTR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMCR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENSET0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENCLR0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENSET1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_AMCNTENCLR1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVCNTR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVCNTR0_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 4 -/
def AMEVCNTR0_EL0_set (n : Nat) (value_name : (BitVec 64)) : SailM Unit := do
  let r : AMEVCNTR0_EL0_Type := value_name
  writeReg AMEVCNTR0 (vectorUpdate (← readReg AMEVCNTR0) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg AMEVCNTR0) n) 63 0 (BitVec.slice r 0 64)))
  writeReg _AMEVCNTR0_EL0 (vectorUpdate (← readReg _AMEVCNTR0_EL0) n r)

def Mk_AMUSERENR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMEVTYPER1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_AMEVTYPER1_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_AMCGCR_EL0_Type_CG0NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def _get_AMCGCR_EL0_Type_CG1NC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 15 8)

def __set_PMSNEVFR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMSNEVFR_EL1_Type := value_name
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 63 is not implemented, or filtering on event 63 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 63 63 (_get_PMSNEVFR_EL1_Type_E63 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 62 is not implemented, or filtering on event 62 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 62 62 (_get_PMSNEVFR_EL1_Type_E62 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 61 is not implemented, or filtering on event 61 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 61 61 (_get_PMSNEVFR_EL1_Type_E61 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 60 is not implemented, or filtering on event 60 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 60 60 (_get_PMSNEVFR_EL1_Type_E60 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 59 is not implemented, or filtering on event 59 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 59 59 (_get_PMSNEVFR_EL1_Type_E59 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 58 is not implemented, or filtering on event 58 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 58 58 (_get_PMSNEVFR_EL1_Type_E58 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 57 is not implemented, or filtering on event 57 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 57 57 (_get_PMSNEVFR_EL1_Type_E57 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 56 is not implemented, or filtering on event 56 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 56 56 (_get_PMSNEVFR_EL1_Type_E56 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 55 is not implemented, or filtering on event 55 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 55 55 (_get_PMSNEVFR_EL1_Type_E55 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 54 is not implemented, or filtering on event 54 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 54 54 (_get_PMSNEVFR_EL1_Type_E54 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 53 is not implemented, or filtering on event 53 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 53 53 (_get_PMSNEVFR_EL1_Type_E53 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 52 is not implemented, or filtering on event 52 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 52 52 (_get_PMSNEVFR_EL1_Type_E52 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 51 is not implemented, or filtering on event 51 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 51 51 (_get_PMSNEVFR_EL1_Type_E51 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 50 is not implemented, or filtering on event 50 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 50 50 (_get_PMSNEVFR_EL1_Type_E50 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 49 is not implemented, or filtering on event 49 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 49 49 (_get_PMSNEVFR_EL1_Type_E49 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 48 is not implemented, or filtering on event 48 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 48 48 (_get_PMSNEVFR_EL1_Type_E48 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 31 is not implemented, or filtering on event 31 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 31 31 (_get_PMSNEVFR_EL1_Type_E31 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 30 is not implemented, or filtering on event 30 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 30 30 (_get_PMSNEVFR_EL1_Type_E30 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 29 is not implemented, or filtering on event 29 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 29 29 (_get_PMSNEVFR_EL1_Type_E29 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 28 is not implemented, or filtering on event 28 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 28 28 (_get_PMSNEVFR_EL1_Type_E28 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 27 is not implemented, or filtering on event 27 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 27 27 (_get_PMSNEVFR_EL1_Type_E27 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 26 is not implemented, or filtering on event 26 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 26 26 (_get_PMSNEVFR_EL1_Type_E26 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 25 is not implemented, or filtering on event 25 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 25 25 (_get_PMSNEVFR_EL1_Type_E25 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 24 is not implemented, or filtering on event 24 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 24 24 (_get_PMSNEVFR_EL1_Type_E24 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 15 is not implemented, or filtering on event 15 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 15 15 (_get_PMSNEVFR_EL1_Type_E15 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 14 is not implemented, or filtering on event 14 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 14 14 (_get_PMSNEVFR_EL1_Type_E14 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 13 is not implemented, or filtering on event 13 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 13 13 (_get_PMSNEVFR_EL1_Type_E13 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  let r ← (( do
    (if ((! (← (__IMPDEF_boolean "event 12 is not implemented, or filtering on event 12 is not supported"))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 12 12 (_get_PMSNEVFR_EL1_Type_E12 (← readReg PMSNEVFR_EL1)))))
    else (do (pure r))) ) : SailM (BitVec 64) )
  writeReg PMSNEVFR_EL1 r

def Mk_ERRSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ERXGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBINF_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBTGT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBSRC_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def __set_BRBSRCINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBSRCINJ_EL1_Type := value_name
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2)))))) : Bool)
  then (do writeReg BRBSRCINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBSRCINJ_EL1) 63 0 (_get_BRBSRCINJ_EL1_Type_ADDRESS r)))
  else (do (pure ())))

def __set_BRBINFINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBINFINJ_EL1_Type := value_name
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 4 0 (BitVec.slice r 0 5))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 15 14 (BitVec.slice r 14 2))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 31 18 (BitVec.slice r 18 14))
  writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 63 47 (BitVec.slice r 47 17))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 46 46 (_get_BRBINFINJ_EL1_Type_CCU r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_CCU (← readReg BRBINFINJ_EL1)) == 1#1)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 45 32 (_get_BRBINFINJ_EL1_Type_CC r)))
  else (do (pure ())))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 17 17 (_get_BRBINFINJ_EL1_Type_LASTFAILED r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 16 16 (_get_BRBINFINJ_EL1_Type_T r)))
  else (do (pure ())))
  (if ((! ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 13 8 (_get_BRBINFINJ_EL1_Type_TYPE r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b10#2)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 7 6 (_get_BRBINFINJ_EL1_Type_EL r)))
  else (do (pure ())))
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b01#2))) <||> (do
         (pure (((BitVec.access (_get_BRBINFINJ_EL1_Type_TYPE (← readReg BRBINFINJ_EL1)) 5) : BitVec 1) == 1#1)))))) : Bool)
  then (do writeReg BRBINFINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBINFINJ_EL1) 5 5 (_get_BRBINFINJ_EL1_Type_MPRED r)))
  else (do (pure ())))

def __set_BRBTGTINJ_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : BRBTGTINJ_EL1_Type := value_name
  (if ((! (←((pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b00#2)) <||> (do
         (pure ((_get_BRBINFINJ_EL1_Type_VALID (← readReg BRBINFINJ_EL1)) == 0b10#2)))))) : Bool)
  then (do writeReg BRBTGTINJ_EL1 (Sail.BitVec.updateSubrange (← readReg BRBTGTINJ_EL1) 63 0 (_get_BRBTGTINJ_EL1_Type_ADDRESS r)))
  else (do (pure ())))

def undefined_DBGDTRTXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP1R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_AP0R_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMINTENSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGOSECCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRRXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDTRTXint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICH_LRC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMEVTYPER1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def __get_PMCCFILTR_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMCCFILTR_EL0_Type := value_name
  (Mk_PMCCFILTR_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFF020FFFFF#64)))

def __get_DCZID_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : DCZID_EL0_Type := value_name
  (Mk_DCZID_EL0_Type (tmp &&& (Complement.complement 0xFFFFFFFFFFFFFFE0#64)))

def __get_PMEVTYPER_EL0 (value_name : (BitVec 64)) : (BitVec 64) :=
  let tmp : PMEVTYPER_EL0_Type := value_name
  (Mk_PMEVTYPER_EL0_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0xBFFF000000F0000#60 64))))

/-- Type quantifiers: crm : Int, crn : Int, op0 : Int, op1 : Int, op2 : Int -/
def AArch64_CheckNVCondsIfCurrentEL (op0 : Int) (op1 : Int) (crn : Int) (crm : Int) (op2 : Int) : SailM Bool := do
  let is_reg_current_el : Bool := (((((op0 == 3) && (op1 == 0)) && (crn == 4)) && (crm == 2)) && (op2 == 2))
  let have_nv_trap_conds ← (( do (HaveNVExt ()) <&&> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((BitVec.slice (← readReg HCR_EL2) 42 1) == 1#1))) ) : SailM Bool )
  (pure (is_reg_current_el && have_nv_trap_conds))

def ConstrainUnpredictableProcedure (which : Unpredictable) : Unit :=
  ()

def ConsumptionOfSpeculativeDataBarrier (_ : Unit) : Unit :=
  ()

def Hint_CLRBHB (_ : Unit) : Unit :=
  ()

def Hint_DGH (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: count : Int, length : Int, reuse : Int, stride : Int -/
def Hint_RangePrefetch (address : (BitVec 64)) (length : Int) (stride : Int) (count : Int) (reuse : Int) (operation : (BitVec 6)) : Unit :=
  ()

def Hint_Yield (_ : Unit) : Unit :=
  ()

def ProfilingSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def SendEvent (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToPA (_ : Unit) : Unit :=
  ()

def SpeculativeStoreBypassBarrierToVA (_ : Unit) : Unit :=
  ()

def AArch64_PendingUnmaskedVirtualInterrupts (mask_in : (BitVec 3)) : SailM (Bool × Bool × Bool) := do
  let allintmask ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let mask : (BitVec 3) := mask_in
  let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  let (mask, pending) ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
         (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
    then
      (do let pending ← (pure (((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_VI (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_VF (← readReg HCR_EL2)))) &&& ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))))))
          let mask ← (( do
            (if ((←((HaveFeatNMI ()) <&&> (do
                 (pure ((_get_SCTLRType_NMI (← (SCTLR_read__1 ()))) == 1#1))))) : Bool)
            then
              (do let allintmask ← (( do (pure ((← readReg PSTATE).ALLINT ||| ((← readReg PSTATE).SP &&& (_get_SCTLRType_SPINTMASK (← (SCTLR_read__1 ())))))) ) : SailM (BitVec 1) )
                  let mask ← (( do
                    (if ((←((IsHCRXEL2Enabled ()) <&&> (do
                         (pure (((← readReg PSTATE).EL == EL0) || (allintmask == 0#1)))))) : Bool)
                    then
                      (do let mask ← (( do
                            (if (((_get_HCRX_EL2_Type_VFNMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                            then (do (pure (BitVec.update mask 0 (Bit 0#1))))
                            else (do (pure mask))) ) : SailM (BitVec 3) )
                          (if (((_get_HCRX_EL2_Type_VINMI (← readReg HCRX_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 1 (Bit 0#1))))
                          else (do (pure mask))))
                    else (do (pure mask))) ) : SailM (BitVec 3) )
                  (if ((((← readReg PSTATE).EL == EL1) && (allintmask == 1#1)) : Bool)
                  then
                    (do let mask ← (( do
                          (if (((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1) : Bool)
                          then (do (pure (BitVec.update mask 0 (Bit 1#1))))
                          else (do (pure mask))) ) : SailM (BitVec 3) )
                        (if (((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1) : Bool)
                        then (do (pure (BitVec.update mask 1 (Bit 1#1))))
                        else (do (pure mask))))
                  else (do (pure mask))))
            else (do (pure mask))) ) : SailM (BitVec 3) )
          (pure (mask, pending)))
    else
      (do let pending : (BitVec 3) := 0b000#3
          (pure (mask, pending)))) ) : SailM ((BitVec 3) × (BitVec 3)) )
  let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
  (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))

def AArch32_PendingUnmaskedVirtualInterrupts (_ : Unit) : SailM (Bool × Bool × Bool) := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL2))))) <||> (do
       (pure (HaveEL EL3)) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3)))))))) : Bool)
  then (do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
  else
    (do let mask ← (( do (pure ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))) ) : SailM (BitVec 3) )
        let pending ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
        let pending ← (( do
          (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1))))) : Bool)
          then (do (pure (((_get_HCR_Type_VA (← (HCR_read ()))) +++ ((_get_HCR_Type_VI (← (HCR_read ()))) +++ (_get_HCR_Type_VF (← (HCR_read ()))))) &&& ((_get_HCR_Type_AMO (← (HCR_read ()))) +++ ((_get_HCR_Type_IMO (← (HCR_read ()))) +++ (_get_HCR_Type_FMO (← (HCR_read ()))))))))
          else (do (pure 0b000#3))) ) : SailM (BitVec 3) )
        let unmasked_pending : (BitVec 3) := (pending &&& (Complement.complement mask))
        (pure ((((BitVec.access unmasked_pending 2) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 1) : BitVec 1) == 1#1), (((BitVec.access unmasked_pending 0) : BitVec 1) == 1#1)))))

def TakePendingInterrupts (interrupt_req : InterruptReq) : SailM Bool := do
  let interrupt_pend ← (( do (undefined_bool ()) ) : SailM Bool )
  let interrupt_taken ← (( do (undefined_bool ()) ) : SailM Bool )
  let vAA ← (( do (undefined_bool ()) ) : SailM Bool )
  let vIRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let vSE ← (( do (undefined_bool ()) ) : SailM Bool )
  let vFIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let AA ← (( do (undefined_bool ()) ) : SailM Bool )
  let IRQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let FIQ ← (( do (undefined_bool ()) ) : SailM Bool )
  let SE ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let (vAA, vFIQ, vIRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedVirtualInterrupts ())
          let vAA : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vAA, vFIQ, vIRQ)) ) : SailM (Bool × Bool × Bool) )
        let (AA, FIQ, IRQ) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch32_PendingUnmaskedPhysicalInterrupts ())
          let AA : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (AA, FIQ, IRQ)) ) : SailM (Bool × Bool × Bool) )
        let AA : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else AA
        let vAA : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vAA
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let interrupt_taken : Bool :=
          if ((((((AA || FIQ) || IRQ) || vAA) || vFIQ) || vIRQ) : Bool)
          then true
          else false
        (if (vFIQ : Bool)
        then (do (AArch32_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch32_TakeVirtualIRQException ()))
              else
                (do (if (vAA : Bool)
                    then (do (AArch32_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch32_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch32_TakePhysicalIRQException ()))
                                else
                                  (do (if (AA : Bool)
                                      then (do (AArch32_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken))
  else
    (do let (vFIQ, vIRQ, vSE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let vSE : Bool := tup__0
          let vIRQ : Bool := tup__1
          let vFIQ : Bool := tup__2
          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
        let (FIQ, IRQ, SE) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))
          let SE : Bool := tup__0
          let IRQ : Bool := tup__1
          let FIQ : Bool := tup__2
          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
        let SE : Bool :=
          if ((! interrupt_req.take_SE) : Bool)
          then false
          else SE
        let vSE : Bool :=
          if ((! interrupt_req.take_vSE) : Bool)
          then false
          else vSE
        let IRQ : Bool :=
          if ((! interrupt_req.take_IRQ) : Bool)
          then false
          else IRQ
        let vIRQ : Bool :=
          if ((! interrupt_req.take_vIRQ) : Bool)
          then false
          else vIRQ
        let FIQ : Bool :=
          if ((! interrupt_req.take_FIQ) : Bool)
          then false
          else FIQ
        let vFIQ : Bool :=
          if ((! interrupt_req.take_vFIQ) : Bool)
          then false
          else vFIQ
        let (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE) ← (( do
          (if ((((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ) : Bool)
          then
            (do let (FIQ, IRQ, SE, vFIQ, vIRQ, vSE) ← (( do
                  (if ((←((HaveTME ()) <&&> (do
                       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
                  then
                    (do let (vFIQ, vIRQ, vSE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedVirtualInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let vSE : Bool := tup__0
                          let vIRQ : Bool := tup__1
                          let vFIQ : Bool := tup__2
                          (pure (vFIQ, vIRQ, vSE)) ) : SailM (Bool × Bool × Bool) )
                        let (FIQ, IRQ, SE) ← (( do
                          let (tup__0, tup__1, tup__2) ← do (AArch64_PendingUnmaskedPhysicalInterrupts ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F)))
                          let SE : Bool := tup__0
                          let IRQ : Bool := tup__1
                          let FIQ : Bool := tup__2
                          (pure (FIQ, IRQ, SE)) ) : SailM (Bool × Bool × Bool) )
                        let SE : Bool :=
                          if ((! interrupt_req.take_SE) : Bool)
                          then false
                          else SE
                        let vSE : Bool :=
                          if ((! interrupt_req.take_vSE) : Bool)
                          then false
                          else vSE
                        let IRQ : Bool :=
                          if ((! interrupt_req.take_IRQ) : Bool)
                          then false
                          else IRQ
                        let vIRQ : Bool :=
                          if ((! interrupt_req.take_vIRQ) : Bool)
                          then false
                          else vIRQ
                        let FIQ : Bool :=
                          if ((! interrupt_req.take_FIQ) : Bool)
                          then false
                          else FIQ
                        let vFIQ : Bool :=
                          if ((! interrupt_req.take_vFIQ) : Bool)
                          then false
                          else vFIQ
                        let interrupt_pend : Bool := (((((SE || FIQ) || IRQ) || vSE) || vFIQ) || vIRQ)
                        (FailTransaction__1 TMFailure_IMP interrupt_pend (! interrupt_pend) (Zeros (n := 15)))
                        (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))
                  else (do (pure (FIQ, IRQ, SE, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool) )
                let interrupt_taken : Bool := true
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))
          else
            (do let interrupt_taken : Bool := false
                (pure (FIQ, IRQ, SE, interrupt_taken, vFIQ, vIRQ, vSE)))) ) : SailM (Bool × Bool × Bool × Bool × Bool × Bool × Bool) )
        (if (vFIQ : Bool)
        then (do (AArch64_TakeVirtualFIQException ()))
        else
          (do (if (vIRQ : Bool)
              then (do (AArch64_TakeVirtualIRQException ()))
              else
                (do (if (vSE : Bool)
                    then (do (AArch64_TakeVirtualSErrorException ()))
                    else
                      (do (if (FIQ : Bool)
                          then (do (AArch64_TakePhysicalFIQException ()))
                          else
                            (do (if (IRQ : Bool)
                                then (do (AArch64_TakePhysicalIRQException ()))
                                else
                                  (do (if (SE : Bool)
                                      then (do (AArch64_TakePhysicalSErrorException interrupt_req.iesb_req))
                                      else (do (pure ())))))))))))))
        (pure interrupt_taken)))

def TakeUnmaskedSErrorInterrupts (_ : Unit) : SailM Unit := do
  let interrupt_req ← (( do (undefined_InterruptReq ()) ) : SailM InterruptReq )
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_FIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vFIQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_IRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_vIRQ := false }
  let interrupt_req : InterruptReq := { interrupt_req with iesb_req := false }
  let interrupt_req : InterruptReq := { interrupt_req with take_SE := true }
  let interrupt_req : InterruptReq := { interrupt_req with take_vSE := true }
  let interrupt_taken ← (( do (TakePendingInterrupts interrupt_req) ) : SailM Bool )
  (pure ())

def HaveFP16Ext (_ : Unit) : Bool :=
  true

def ExclusiveMonitorsStatus (_ : Unit) : (BitVec 1) :=
  0#1

/-- Type quantifiers: Rt : Int, k_acq_rel : Bool, k_sign_extend : Bool, k_sixty_four : Bool, size : Int -/
def AArch64_SetLSInstructionSyndrome (size : Int) (sign_extend : Bool) (Rt : Int) (sixty_four : Bool) (acq_rel : Bool) : Unit :=
  ()

def DataMemoryBarrier (domain : MBReqDomain) (types : MBReqTypes) : SailM Unit := do
  (sail_barrier
    (Barrier_DMB
      { domain := domain
        types := types
        nXS := false }))

/-- Type quantifiers: k_nXS : Bool -/
def DataSynchronizationBarrier (domain : MBReqDomain) (types : MBReqTypes) (nXS : Bool) : SailM Unit := do
  (sail_barrier
    (Barrier_DSB
      { domain := domain
        types := types
        nXS := nXS }))

def InstructionSynchronizationBarrier (_ : Unit) : SailM Unit := do
  (sail_barrier (Barrier_ISB ()))

/-- Type quantifiers: t : Int -/
def DCZID_EL0_SysRegRead_9bb2971f34b1558f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_DCZID_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_DCZID_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_DCZID_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (__get_DCZID_EL0 (← readReg DCZID_EL0))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def TPIDR_EL0_SysRegRead_512297cd575d98fa (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGRTR_EL2_TPIDR_EL0 ← (( do (pure (_get_HFGRTR_EL2_Type_TPIDR_EL0 (← readReg HFGRTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if ((((←((EL2Enabled ()) <&&> (do
                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                 (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
        then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
        else (do (X_set t 64 (← readReg TPIDR_EL0)))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((((←((EL2Enabled ()) <&&> (do
                       (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGRTR_EL2_TPIDR_EL0 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (X_set t 64 (← readReg TPIDR_EL0)))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do (X_set t 64 (← readReg TPIDR_EL0)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (X_set t 64 (← readReg TPIDR_EL0)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AArch64_AutoGen_SysRegRead (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HCR_EL2_SysRegRead_5224f361c75e16cb")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR2_EL1_SysRegRead_8d15523f6def058f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR4_EL1_SysRegRead_f8caea53c1015428")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64MMFR2_EL1_SysRegRead_cc8ba5aa21a8fd21")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VTCR_EL2_SysRegRead_f801b4fb3334c4c3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HDFGRTR_EL2_SysRegRead_2c14bf21b897a1bb")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICV_NMIAR1_EL1_SysRegRead_fc1b7cc86475bbcb")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_abt_SysRegRead_ced162955bfdf7d0")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_7b87e2c873df96d3")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_c81d0fe793ef58d2")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_f0dfb1b6bea2d67b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_acbe44db6613ec59")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_9bbb7ed062f56571")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_aea95b9712305e61")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_7b5788e0eea7d16d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_5892cb2908346b8f")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_4e742d1e920f7e6a")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_a618297619bdffa8")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_fa3ca488734d3bcc")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_77cba5409a6a519d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_6fc0cefa24d83ad7")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_699f2fe4ff960178")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_b2fb82f050f6bc86")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_LR_EL2_SysRegRead_760236e55a89ef60")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDCCINT_EL1_SysRegRead_8ab11d15362084e3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MVFR0_EL1_SysRegRead_dd15ac4d4e4917f3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded POR_EL2_SysRegRead_b9e6082fd3098e22")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded POR_EL2_SysRegRead_1719ba3e87a9ae64")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_HPPIR1_EL1_SysRegRead_49e183ca83eb8361")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded APIBKeyHi_EL1_SysRegRead_8d14ffa361259fa2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SP_EL2_SysRegRead_d604bd0fb0757c08")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP0R_EL1_SysRegRead_4af9bde7d3ab9efe")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP0R_EL1_SysRegRead_c718785136d493b9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP0R_EL1_SysRegRead_51434e4b9d244793")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP0R_EL1_SysRegRead_c5e122be1753fb85")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64DFR0_EL1_SysRegRead_2534c3350994a417")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCFGR_EL1_SysRegRead_3bbfca307eea028a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR2_EL2_SysRegRead_5dd157d2d7e53a90")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR2_EL2_SysRegRead_d12dd160e7a3b2d0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ESR_EL1_SysRegRead_00d45479b3791ebf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ESR_EL1_SysRegRead_a03e2d9d46c81b7f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ESR_EL1_SysRegRead_0503f2c5949dd1a4")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICV_BPR1_EL1_SysRegRead_3b949083543338aa")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR_EL3_SysRegRead_0d04522059172f43")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR2_EL1_SysRegRead_b7383eed8683183b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ALLINT_SysRegRead_ee53c92ec04c7280")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMECR_EL1_SysRegRead_701363aef834edcc")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AIDR_EL1_SysRegRead_3367279f59657745")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_PMR_EL1_SysRegRead_538510958f22076c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded RMR_EL1_SysRegRead_9adb359c4ff7cc32")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b111#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMSCR_EL1_SysRegRead_2d556bc720f0d5f6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMICFILTR_EL0_SysRegRead_b736a151969b8c3c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCNTENSET_EL0_SysRegRead_d76b56a27ec0166e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTVCT_EL0_SysRegRead_1d562372e622baf9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_HPPIR0_EL1_SysRegRead_03eb902d5ba703ac")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ELR_EL2_SysRegRead_98b7799847de6b3f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ELR_EL2_SysRegRead_cdeb265f6e920d74")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b110#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMROOTCR_EL3_SysRegRead_cc1acadd5685fbb1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHPS_CTL_EL2_SysRegRead_9ed12a041f4d5569")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHPS_CTL_EL2_SysRegRead_79f3fb88a16d36e6")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VMECID_A_EL2_SysRegRead_aa29d8316696b535")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded RVBAR_EL2_SysRegRead_4cac2371e78214e1")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECID_RL_A_EL3_SysRegRead_50a71cb28bab1988")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HSTR_EL2_SysRegRead_4e780f9f195cb950")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR_EL1_SysRegRead_66ca2d8fc428dd45")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR_EL1_SysRegRead_f6ee03bc53b980dd")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMOVSCLR_EL0_SysRegRead_c99057064f1c4d43")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HAFGRTR_EL2_SysRegRead_b9d391a626b7035e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded POR_EL3_SysRegRead_dd4204e711df2c15")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_BPR0_EL1_SysRegRead_b8c7d452ff7b9c66")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64DFR1_EL1_SysRegRead_efaff2fa63cea9e4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ACCDATA_EL1_SysRegRead_6deec7bc548bcc31")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIR_EL3_SysRegRead_1dc2ca24d5a22e66")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded OSDLR_EL1_SysRegRead_b4a733586ba54671")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR_EL1_SysRegRead_ce1d601189e8030e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR_EL1_SysRegRead_043383b392ab2b8a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PAN_SysRegRead_ffa7ce033244778f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded REVIDR_EL1_SysRegRead_ec0a78562653e4de")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSSCR_EL1_SysRegRead_a6c1e79f31190a60")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded LORID_EL1_SysRegRead_3eb3572baf1f9d7d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CONTEXTIDR_EL2_SysRegRead_dc0e6b987e373678")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CONTEXTIDR_EL2_SysRegRead_0a5ce1fa99f54107")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TPIDR_EL2_SysRegRead_840081a307f6cade")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded FPSR_SysRegRead_f0c8f9b942affbc0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTP_TVAL_EL0_SysRegRead_aa86b862886b57ac")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTP_TVAL_EL0_SysRegRead_65dd187dcad1babf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64ISAR1_EL1_SysRegRead_5f004fea0c608df9")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMICNTR_EL0_SysRegRead_468ebcab1dcb0580")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64MMFR4_EL1_SysRegRead_3578f169e732088b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ACTLR_EL2_SysRegRead_949275ba7f389456")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_EISR_EL2_SysRegRead_b94071bbed7793e6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MIDR_EL1_SysRegRead_5aac357d91bc3b98")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_RPR_EL1_SysRegRead_ed1234736c835707")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_ELRSR_EL2_SysRegRead_f3283fecb3432702")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VBAR_EL2_SysRegRead_369573c45c9746cf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VBAR_EL2_SysRegRead_025a01f041322eae")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGITR_EL2_SysRegRead_2ac6d936359d43d5")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded FPCR_SysRegRead_48b824e8174adfc0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHVS_CTL_EL2_SysRegRead_46708ffedf6618c4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHVS_CTL_EL2_SysRegRead_1d2ef372c8b0dab1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded APIAKeyLo_EL1_SysRegRead_7d4296cd57d27a5d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMACCESSR_EL1_SysRegRead_26644746ac7f02e9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b101#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMACCESSR_EL1_SysRegRead_c8d8e0186d23b218")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64PFR1_EL1_SysRegRead_99547bac83e88d23")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64PFR0_EL1_SysRegRead_f36f783e888272fe")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded FAR_EL3_SysRegRead_5f326570429f53a6")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP1R_EL2_SysRegRead_6e9c00e7ee655a1c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP1R_EL2_SysRegRead_30ea39c810423a08")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP1R_EL2_SysRegRead_7e396ec20ce46cc8")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP1R_EL2_SysRegRead_c149792475ac1b5e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SDER32_EL2_SysRegRead_6dbf529a9fc6ce3e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VSTCR_EL2_SysRegRead_15cf4d2aac84d328")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded RVBAR_EL3_SysRegRead_d57b9abefb0ea569")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_7d149b7cd797530b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_e9a366e0017307cb")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_4a27b429d70fb026")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_59a2849f7eb3b332")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_0219fbdb2658ca68")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_4c97fc2d1ca8cf1e")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_82c544942be55f96")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_9541923a3ae283ea")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_73e30fcdf9fe2edd")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_f925d17f40acee9c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_fda3561b105a2867")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_c0ae6177773c98b2")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_dcb2c17a0373111a")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_69c766eb655b6bd8")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_8418bd2288f058de")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_5646c848d2870ac9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_7000ac16a0f93cee")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_59dd9f25ebd351ac")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_3f5ceece7b1ab633")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_36f90261f51de7a4")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_bb81ca0d64a32b78")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_b5f18a055135ef08")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_384f3a84fabf1c68")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_ad118dbfadee9377")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_10cfea5393e5a113")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_ce304be785bc43da")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_d3fed862ea81087f")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_b1095a7af5788bf0")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_93e122dd4e325251")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_b7a27d9b684d8f1b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTSVR_EL1_SysRegRead_f8609d37ac8354cc")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64ISAR0_EL1_SysRegRead_bbc5747e80790ed5")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMMIR_EL1_SysRegRead_0052425c6ad862e6")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICV_IAR0_EL1_SysRegRead_8bcb4b4c3394a634")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_IGRPEN1_EL1_SysRegRead_91fcd06cccdfe885")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded GPTBR_EL3_SysRegRead_fe0f38a8cd7c60a9")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDCCSR_EL0_SysRegRead_01ce581683168bc2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_8c7e069d9db6465d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_d29d0353b14cc20b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_013cb2536335679a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_56d1d9f5e0f84f06")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_b7b783651f33ef8d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_8d4f3607df002a1e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_87ded94d106ff97e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_2199824cc2c1b975")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_ca2e4c8f2660e4c2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_6a3366c40ed33a8b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_9b069b7382cb8ace")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_67458b6de4d2f083")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_2014e793fb76aa0b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_bdb381032f2d5abe")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_c542f9553bc934d3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILTR_EL0_SysRegRead_2f720274e00b27d8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR5_EL1_SysRegRead_aa9b432015ad78b6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHV_CVAL_EL2_SysRegRead_7bb539c281c21387")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHV_CVAL_EL2_SysRegRead_aa1abdb084701418")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR0_EL3_SysRegRead_b3013f97ed37beea")))
  else (do (pure ())))
  (if ((((((CRm == 0b1111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_0eb0d62ea2fda071")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_cf52c5b94cb6cfbc")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_1e5042e13523fa5d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_25ce85c39c7f6fab")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_4aa6676517b46c9d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_4819f7c1472ce09b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_8ee7203ab64efc9b")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_cdb3eeaee7600974")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_92bc7c55fdf9f90f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_34c274725a4c52be")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_ee9d701f728184a3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_8fd16782f7a14e94")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_351735ec7986860c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_dfb30cff5c993bc8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_9b50139a1fa842ce")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBCR_EL1_SysRegRead_3fab4f560940f3bb")))
  else (do (pure ())))
  (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCCFILTR_EL0_SysRegRead_5ac92cf4fcc5c832")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b0111#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGCLAIMSET_EL1_SysRegRead_e478959c32681458")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCGCR_EL1_SysRegRead_529e10a6261e7d96")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCGCR_EL1_SysRegRead_529e10a6261e7d96")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_SRE_EL1_SysRegRead_66e16dcbec736265")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PM_SysRegRead_801ea1615b4051f7")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP0R_EL2_SysRegRead_52a53932b4c339f0")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP0R_EL2_SysRegRead_e9c19cba17805bc5")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP0R_EL2_SysRegRead_59f0de8946000971")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_AP0R_EL2_SysRegRead_5c5dde09d918dae7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CONTEXTIDR_EL1_SysRegRead_c6da578db1984530")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TPIDR_EL1_SysRegRead_cb207f415778832f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR4_EL1_SysRegRead_b41d0fd5cce0f813")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTVOFF_EL2_SysRegRead_f84a995c7f5f427c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR1_EL1_SysRegRead_659998c6404a0adc")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMUACR_EL1_SysRegRead_ce94146f70da9e11")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DSPSR_EL0_SysRegRead_e92e924519c42368")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ACTLR_EL1_SysRegRead_cc5a0755f0205a72")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded RMR_EL2_SysRegRead_0cc9a425a7ab6f44")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VNCR_EL2_SysRegRead_fd49e25478d53eb1")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMINTENCLR_EL1_SysRegRead_fb98bdd5aa053775")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSELR_EL0_SysRegRead_597778422a5e1e61")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_CTLR_EL1_SysRegRead_eb1de12df33d5c37")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_d0361acb26713433")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_d72b4e2f828258be")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_433638c7dd5d7f8c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_4309271c5c3f50c2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_a505a5c15b00753c")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_51af2efaff004e74")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_b92ce31d6b189d89")))
  else (do (pure ())))
  (if ((((((CRm == 0b0111#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_811ad3f997f59858")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_c26a621e717d6ec0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_becf2c3488c0840f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_310eb78ca3ffcdd5")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_dc68673c986189cc")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_0f60cc3cb4a8e9b3")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_3c202af9a88305f9")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_53e34bafcb1745bf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0110#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVFILT2R_EL0_SysRegRead_5f57fc70d1c81668")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR6_EL1_SysRegRead_c5d967e39ea7cb96")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP1R_EL1_SysRegRead_6535748ba14d930e")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP1R_EL1_SysRegRead_5a702399a390f8ec")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP1R_EL1_SysRegRead_39371d4468952849")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_AP1R_EL1_SysRegRead_a0d3f3e1a65fa7f7")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DAIF_SysRegRead_102c97f1f2780854")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTP_CTL_EL0_SysRegRead_15357e2547a6f65f")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_e5a283ed2b79bd84")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_32b4fcb392e5c312")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_53822901bce95688")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_593e15d8d87f3370")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_6eef6c9d0ea660a1")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_fccbe0710386c98a")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_bddfd936634ddadc")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_6d59e307d3cd7a1c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_748d6e2e7bd869de")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_e23b48b5ac325a95")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_6b9b795fff65a19d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_3fd74d86919a41a5")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_693e4ccc8252a9a7")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_ef3a8d2a7921c11c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_73ed225f0812fbfc")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_0d3db5f733fce750")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_c3ba32793ae88442")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_3cf749b2a6f0d8e8")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_1182d540f254acac")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_ca58b1e5989f1015")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_0593376102dfa06d")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_a360f253ceba1de0")))
  else (do (pure ())))
  (if ((((((CRm == 0b1001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_10f19f05478e0298")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_2a52665b668ba6a3")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_1ab539f73d82d8d9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_0fa6d9f54f3566c9")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_776dc50ca01e0285")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_3152dcccddae7402")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_2f26e246b6e98799")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_81c5bd2bbc23b640")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVCNTR_EL0_SysRegRead_ed4b4b8084b6d41d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGITR2_EL2_SysRegRead_9589905774d1f5d8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHV_TVAL_EL2_SysRegRead_42829873ebd7042d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHV_TVAL_EL2_SysRegRead_131a29f8b5d31ce1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_irq_SysRegRead_3f8614ad01700094")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMOVSSET_EL0_SysRegRead_5f97da0caf1e7976")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_MISR_EL2_SysRegRead_c4aa5214cb9e1506")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHP_CVAL_EL2_SysRegRead_5a841847b0720163")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHP_CVAL_EL2_SysRegRead_ed1c928371f03392")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b010#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CSSELR_EL1_SysRegRead_5913225fc951e4d2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PFAR_EL2_SysRegRead_b491a80fcabf31ea")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MFAR_EL3_SysRegRead_6520d659502d749b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_EL2_SysRegRead_f8dd5a5a3ce06a92")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_EL2_SysRegRead_c62428913c72a08e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR_EL1_SysRegRead_906af64cf526e3f6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR_EL1_SysRegRead_3c972cf7b788a8a1")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR2_EL1_SysRegRead_e0ec1b448b49d808")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR2_EL1_SysRegRead_90cdeb4a4ee1955f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded APDAKeyLo_EL1_SysRegRead_da997907626beb36")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ISR_EL1_SysRegRead_9452dc797f0bae53")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded NZCV_SysRegRead_66dd3f91dc048279")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR3_EL1_SysRegRead_e32f388e1b8f6c5e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR1_EL1_SysRegRead_3cf8f86fbb276328")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR1_EL1_SysRegRead_00f51d0e1b73738c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCCNTSVR_EL1_SysRegRead_1c4e4329b1d511c2")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECIDR_EL2_SysRegRead_22d6791638dc141a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_833b4e297c71de6a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_e7a481429e83f45a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_6b1045c77e27556f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_e24de41e0c3b53d0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_957f0f2e2a9b82fd")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_63f86d87692f2f5f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_c2de0f8c4622eee8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_4176d7bf912de1b6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_fa3705a120ccce47")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_12d4102729189c27")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_eff783e04019e7d0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_a31ff8f9d8fc694e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_99a60c759c66512d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_c0cff22e18b46a65")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_ec65f2c5c1f0aa41")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVTYPER_EL0_SysRegRead_75ed658b96b65c13")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMINTENSET_EL1_SysRegRead_84b31efb21c9f5ab")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMIDR_EL1_SysRegRead_35f7ac0cb705482a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGWTR_EL2_SysRegRead_efd0bbb67b091b14")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMPRI_EL1_SysRegRead_ce73dae3ecbf18f6")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMUSERENR_EL0_SysRegRead_4984184853b93fa2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SVCR_SysRegRead_bfac8039b65bb2b5")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR2_EL2_SysRegRead_4e11a5aa656bf495")))
  else (do (pure ())))
  (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMOVSSET_EL0_SysRegRead_6d3f79f9beba4196")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR2_EL2_SysRegRead_c6e17744cc03d54f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR2_EL2_SysRegRead_0f9ce6311b1205f6")))
  else (do (pure ())))
  (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHVS_CVAL_EL2_SysRegRead_e87d470dc26af07a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR_EL3_SysRegRead_6ae2b7096922ae74")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded VBAR_EL1_SysRegRead_f248fbb25db37a7b")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR0_EL3_SysRegRead_2d1994fbdbde12d8")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTFRQ_EL0_SysRegRead_aed619ec0d882dc5")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCNTENCLR_EL0_SysRegRead_1114ed6fac10af30")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded RVBAR_EL1_SysRegRead_c839c12def98ebc4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR1_EL2_SysRegRead_a12c342eb9f7885a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ELR_EL1_SysRegRead_a79af82b86a9e639")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECID_A0_EL2_SysRegRead_d1ae9fcf467da39c")))
  else (do (pure ())))
  (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICV_IAR1_EL1_SysRegRead_e78579ad210f1e05")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CPACR_EL1_SysRegRead_3ecedf6fe7690be4")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CPACR_EL1_SysRegRead_00e702278c481e13")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGDTRRX_EL0_SysRegRead_54d73d4619fa5dbf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b100#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded POR_EL1_SysRegRead_4e2353406e7396e0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_EL1_SysRegRead_563abdf3a232cd99")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded FPEXC32_EL2_SysRegRead_0bed2a86b1b2240d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR2_EL2_SysRegRead_88d9ce00117fb633")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR2_EL2_SysRegRead_64c24db4df3eb258")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDSCR_EL1_SysRegRead_cf631f2b4ddd25e0")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR_EL3_SysRegRead_3a3602f6f0c9e03f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSel_SysRegRead_40cc9773567bb9cf")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_fiq_SysRegRead_efae9f97878743e3")))
  else (do (pure ())))
  (if ((((((CRm == 0b1000#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECID_P0_EL2_SysRegRead_63d80c0de4f28c1a")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded GPCCR_EL3_SysRegRead_709f878e2648a87d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_PFR0_EL1_SysRegRead_51a48b3c62008265")))
  else (do (pure ())))
  (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCCNTR_EL0_SysRegRead_ec496c5d54ab7b85")))
  else (do (pure ())))
  (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded MVFR1_EL1_SysRegRead_ac66b9abd61faeb2")))
  else (do (pure ())))
  (if ((((((CRm == 0b0101#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded DLR_EL0_SysRegRead_635696e4f590448d")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded HDFGWTR2_EL2_SysRegRead_5781127e61739817")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b011#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR2_EL1_SysRegRead_c832348f3796463e")))
  else (do (pure ())))
  (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR0_EL1_SysRegRead_24c5894e067c2865")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPOFF_EL2_SysRegRead_bfece51207f46d78")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR0_EL1_SysRegRead_859cbb0383226d9f")))
  else (do (pure ())))
  (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR0_EL1_SysRegRead_58d465b1f7d8b040")))
  else (do (pure ())))
  (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
  then (do (DCZID_EL0_SysRegRead_9bb2971f34b1558f el op0 op1 CRn op2 CRm t))
  else
    (do (if ((((((CRm == 0b0110#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded VSTTBR_EL2_SysRegRead_5dcb8c3ead41869d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TRFCR_EL2_SysRegRead_adc3a07d7fc07643")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TRFCR_EL2_SysRegRead_3507a58ffe771821")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHP_CTL_EL2_SysRegRead_fc0ab47b2d1292cd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHVS_TVAL_EL2_SysRegRead_7b30facaa926411e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHP_TVAL_EL2_SysRegRead_ddcf2e9dd3ff2611")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMACCESSR_EL2_SysRegRead_aebb0159a0970aae")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHCTL_EL2_SysRegRead_25bfe781a33503e5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHCTL_EL2_SysRegRead_c39dc9ffb55dc488")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMICNTSVR_EL1_SysRegRead_1ebf8763b2140fc4")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDRAR_EL1_SysRegRead_9bbd6b527037e7d1")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded OSDTRRX_EL1_SysRegRead_ed7388c985c3d430")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PFAR_EL1_SysRegRead_edf49fc5ee95c8c2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PFAR_EL1_SysRegRead_648f6bc41e720a7a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded IFSR32_EL2_SysRegRead_bc5173df6fb29c65")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded FAR_EL2_SysRegRead_49254d82e8554d12")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded FAR_EL2_SysRegRead_7a873e0d64ef42a5")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMCR_EL0_SysRegRead_8d094d8673390ddf")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMINTENCLR_EL1_SysRegRead_6d6d9e36e779f16f")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_IGRPEN1_EL3_SysRegRead_36d699c35dbd8f69")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded S2PIR_EL2_SysRegRead_2ac98b74605e5456")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR1_EL1_SysRegRead_5bc0d8918ab34ceb")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMXEVTYPER_EL0_SysRegRead_822f8e38c465529c")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR2_EL1_SysRegRead_5817d7d1bdb094d0")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded LORSA_EL1_SysRegRead_eff0a73c3cb651d8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64MMFR1_EL1_SysRegRead_8e0c46321a1a5a47")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMOVSCLR_EL0_SysRegRead_f68ae6919a317d03")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_236e531d61e35213")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_9b436b8dcf826854")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_0d4001a88a9206f8")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_b7d3a0a1687ee605")))
        else (do (pure ())))
        (if ((((((CRm == 0b1011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_6ed96d96594172dd")))
        else (do (pure ())))
        (if ((((((CRm == 0b1010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_d6acb1282794050a")))
        else (do (pure ())))
        (if ((((((CRm == 0b1001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_732a44d59c35aeb3")))
        else (do (pure ())))
        (if ((((((CRm == 0b1000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_2c1cc2102bf556aa")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_7e97fa1e73481f2d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_74bf5d2a6cfe195c")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_81a0b83ef7c202d4")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_ab00b8f6b1bf63cc")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_d41ce14d142d5fc9")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_a0df5130cffc6ec3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_782b8628944ba11a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWCR_EL1_SysRegRead_aae6422db875ace5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCXTNUM_EL2_SysRegRead_8bf0422effd0ab20")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCXTNUM_EL2_SysRegRead_af67262612e5c00e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ESR_EL3_SysRegRead_ba1b08f3b6ea1fa7")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_82c0bc230c1e3204")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_6f9a48444f4b276b")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_3420cbf7b2d038f8")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_953a504769c668b0")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_cd99afc01b24bf2b")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_c8e002b2195e5a12")))
        else (do (pure ())))
        (if ((((((CRm == 0b1111#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_74117943f83c7293")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_13c3c0867de835a2")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_b06bc5007c474af3")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_187174725e559008")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_b63b7d8fea5e18df")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_c8e92c1375bb4b38")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_161a91be0c63b6f4")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_b777b07a1ab3a531")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_6096f129eb2ac985")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_d41d3960b7ebf0de")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_14beb5e8e42eceb3")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_073a4fe6d2f5a921")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_4d7b8571d7d827fa")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_50be283a37e4fd31")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_1f37321b901f8989")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_a6915f5d07275c6c")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_1a04be91449acb40")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_59df350d04568b64")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_12c2ea6445066d74")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_264c590d45142978")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_1dbe5107f25be020")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_49df7d27e017454d")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_c20edd6d6b9803a3")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_b0eea7edf1a1fecf")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMEVTYPER_EL0_SysRegRead_303aca4655281092")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTV_CTL_EL0_SysRegRead_23c5b36dc5cb110e")))
        else (do (pure ())))
        (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMIIDR_EL1_SysRegRead_895b44f480e2fb64")))
        else (do (pure ())))
        (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMIAR_EL1_SysRegRead_8a45c86d25fdd6b8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TPIDR_EL3_SysRegRead_165fa3219105298e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TRFCR_EL1_SysRegRead_346a67ae7b13428d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR0_EL1_SysRegRead_911dfac1545c3c44")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded OSDTRTX_EL1_SysRegRead_9df6f1b9434b173d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ELR_EL3_SysRegRead_48156757f03c05da")))
        else (do (pure ())))
        (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_VMCR_EL2_SysRegRead_7485c707cb4a586a")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded VPIDR_EL2_SysRegRead_c419b4414b36ba2e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ACTLR_EL3_SysRegRead_c20b5bca7bc57751")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_CTLR_EL3_SysRegRead_7a137fb26d669941")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR_EL2_SysRegRead_e3c3d9b65d84cd42")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR_EL2_SysRegRead_8a38edf51a31f5e0")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR_EL2_SysRegRead_e7d62050e609b077")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHPS_CVAL_EL2_SysRegRead_d2662865ff7936c3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded OSLSR_EL1_SysRegRead_ee8639dd7aebdefe")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded FAR_EL1_SysRegRead_4ac11836ed369460")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDCR_EL3_SysRegRead_fa75e32e1a0e4d27")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR_EL3_SysRegRead_098fd5c15cd15cd8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCTLR2_EL3_SysRegRead_87ae87d52be38631")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCNTENSET_EL0_SysRegRead_4d90af887d9c8c94")))
        else (do (pure ())))
        (if ((((((CRm == 0b1001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_SRE_EL2_SysRegRead_7b340e47907381fb")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b111#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPS_CTL_EL1_SysRegRead_b28f26339dbc713f")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DACR32_EL2_SysRegRead_7553854be98ecb11")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPCT_EL0_SysRegRead_30a0e264d583fe56")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR_EL2_SysRegRead_c37e0065b9939c9e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded LORC_EL1_SysRegRead_50b423e6e0102ba8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64PFR2_EL1_SysRegRead_c98524f93c119d97")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCXTNUM_EL1_SysRegRead_32a07f15f90850b2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCR_EL2_SysRegRead_424c76a4449d67b2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CCSIDR2_EL1_SysRegRead_7161997c851583ee")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CTR_EL0_SysRegRead_17103694dd49566e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_und_SysRegRead_ffbc14073ddb1072")))
        else (do (pure ())))
        (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64ISAR2_EL1_SysRegRead_c585336ab0c39b5d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SSBS_SysRegRead_2e7b32f98c2852d5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CPTR_EL3_SysRegRead_7b3995450955fa38")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded S2POR_EL1_SysRegRead_e4b7b03dbe33ccaa")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGRTR2_EL2_SysRegRead_e34348a8454b3058")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TPIDRRO_EL0_SysRegRead_914a0b925fac624e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTP_CVAL_EL0_SysRegRead_ea3c2820c47244b3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_ISAR5_EL1_SysRegRead_7b34ff950445f0bc")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded RMR_EL3_SysRegRead_412ca53e076c7a6e")))
        else (do (pure ())))
        (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_HCR_EL2_SysRegRead_2d127848d9701956")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_IGRPEN0_EL1_SysRegRead_5872e0ee48947240")))
        else (do (pure ())))
        (if ((((((CRm == 0b0101#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHPS_TVAL_EL2_SysRegRead_893c5b3a9908faeb")))
        else (do (pure ())))
        (if ((((((CRm == 0b1000#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECID_A1_EL2_SysRegRead_c4456c8d850c3339")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR_EL1_SysRegRead_9571f6fe9c5fe082")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCXTNUM_EL0_SysRegRead_73b90ab9431e2a86")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64MMFR0_EL1_SysRegRead_52d0be9703325603")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded TPIDR2_EL0_SysRegRead_71cf61d7c1b2b93d")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCR_EL0_SysRegRead_e26571c3d63ff1ee")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_6629043b009838f2")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_47746fabe04a4008")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_bcfc64cd2c6760f8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_ab354cbb8f86428d")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_dd0fbaf64169b322")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_17c3b03e92e863c8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_3e60f4578776ee77")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_2a5f7477440a0d8c")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_3bbdde355e317836")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_9efab29059e715cc")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_d23e4db3dd4c8878")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_7ed464eec50f477f")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_678889e62977a375")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_ab17ee4b9b9152f9")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_2a6f6484aeebace8")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMEVCNTR_EL0_SysRegRead_21440ea7cf979c85")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded HDFGRTR2_EL2_SysRegRead_fb9db770ba4c3bae")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGPRCR_EL1_SysRegRead_cbb37eb996d3a77c")))
        else (do (pure ())))
        (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCNTENCLR_EL0_SysRegRead_9c63b37a1be89728")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SDER32_EL3_SysRegRead_e8c9baf258d1c833")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded HPFAR_EL2_SysRegRead_9238fb9a3f4fb1bb")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded VMPIDR_EL2_SysRegRead_4d4e4e0bcb925136")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded VMPIDR_EL2_SysRegRead_6d0c680fdfd4837e")))
        else (do (pure ())))
        (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64MMFR3_EL1_SysRegRead_a84482354ffb3943")))
        else (do (pure ())))
        (if ((((((CRm == 0b1011#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICH_VTR_EL2_SysRegRead_35151b955e524a69")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_PFR1_EL1_SysRegRead_0333fe2887e1adfd")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDSELR_EL1_SysRegRead_793ed69a5a9eaab3")))
        else (do (pure ())))
        (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGDTR_EL0_SysRegRead_59f5860954a90673")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_DFR1_EL1_SysRegRead_de4a2c9fc10617db")))
        else (do (pure ())))
        (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded APIAKeyHi_EL1_SysRegRead_369091161dd81da7")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b111#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCXTNUM_EL3_SysRegRead_ad99c3bb5365f4d5")))
        else (do (pure ())))
        (if ((((((CRm == 0b0011#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded APGAKeyHi_EL1_SysRegRead_0a5b468704a60aab")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
        then (do sailThrow ((Error_ImplementationDefined "janus-excluded VBAR_EL3_SysRegRead_1921cc85b07f3896")))
        else (do (pure ())))
        (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
        then (do (TPIDR_EL0_SysRegRead_512297cd575d98fa el op0 op1 CRn op2 CRm t))
        else
          (do (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AFR0_EL1_SysRegRead_8cb989b34cb8a122")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MDCR_EL2_SysRegRead_b8f16b372834c035")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SP_EL1_SysRegRead_424b458c54382730")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded UAO_SysRegRead_4c61cdd9d285c8cc")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIR_EL1_SysRegRead_9dc8ce566aa0dbe0")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIR_EL1_SysRegRead_d6ac17cfc2f564cb")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTKCTL_EL1_SysRegRead_dfa3587117fd7e6d")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIR_EL2_SysRegRead_e7b38688c081b516")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded RNDRRS_SysRegRead_8cd65845e0b85be3")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded APIBKeyLo_EL1_SysRegRead_c29446436810902b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded LORN_EL1_SysRegRead_f1da155c7f7014b9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPSR_EL3_SysRegRead_df09fc431da6e372")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CCSIDR_EL1_SysRegRead_5f1582fb2f446af0")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded APDBKeyHi_EL1_SysRegRead_e38d9de67a6082a7")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded VMECID_P_EL2_SysRegRead_85067caadb2f69e9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMPRIMAP_EL2_SysRegRead_c09b27037a76a5c0")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded OSECCR_EL1_SysRegRead_2b476cb67a617cfe")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded RNDR_SysRegRead_cb03dcf786233956")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGVCR32_EL2_SysRegRead_6fe9bc763220955c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGRTR_EL2_SysRegRead_2d8c69ae2f7682c6")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_DFR0_EL1_SysRegRead_fd3ff6eac0bbb4f5")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CPTR_EL2_SysRegRead_70f3036b7ed095c4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CLIDR_EL1_SysRegRead_e5c2643fd321419d")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTV_CVAL_EL0_SysRegRead_e31d635daf585919")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded HCRX_EL2_SysRegRead_ac90b414dcf6527a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded POR_EL0_SysRegRead_b50bc065c1491be2")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SP_EL0_SysRegRead_83d763503fa7e549")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMXEVCNTR_EL0_SysRegRead_52bf82e65ceb6b97")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded HFGWTR2_EL2_SysRegRead_67317c38f0a466b6")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMINTENSET_EL1_SysRegRead_93608e9ab6758704")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIRE0_EL2_SysRegRead_77b4d92b42d1e381")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIRE0_EL2_SysRegRead_9885888a54ddcb18")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MECID_P1_EL2_SysRegRead_7875ab7fe28cd25b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded HACR_EL2_SysRegRead_d6fb34f6f0d841c4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPCT_EL0_SysRegRead_30a0e264d583fe56")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MVFR2_EL1_SysRegRead_56cfaa06768c8d8a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMSELR_EL0_SysRegRead_423f70f41ec02ca1")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b0111#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGAUTHSTATUS_EL1_SysRegRead_d85001e86a493d96")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR2_EL3_SysRegRead_3e5d4dd4506a8fae")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMDEVAFF_EL1_SysRegRead_14639bbf25c1b503")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DIT_SysRegRead_80b5d608e76aa495")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SCR_EL3_SysRegRead_b8dcdb7a98ef0967")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ICC_SRE_EL3_SysRegRead_7a177b6c72e9cd7e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR1_EL3_SysRegRead_bbfc01f9fd46f6c4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_MMFR3_EL1_SysRegRead_a9cd04d27834c148")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0011#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded HDFGWTR_EL2_SysRegRead_c6796c2a296d66f8")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded APGAKeyLo_EL1_SysRegRead_b90c447e3bdb3387")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded APDAKeyHi_EL1_SysRegRead_6f8bf97afb0e465f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCEID1_EL0_SysRegRead_88fe472f132d5d45")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b111#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPS_CVAL_EL1_SysRegRead_21e9c10a0f76a1d1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b111#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTPS_TVAL_EL1_SysRegRead_748a1753bd033377")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64AFR1_EL1_SysRegRead_1072eb4f153853b5")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MAIR2_EL3_SysRegRead_06e8ce86a19999af")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded LOREA_EL1_SysRegRead_c69af0a70feec9d7")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTV_TVAL_EL0_SysRegRead_f682815b8c52312a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded APDBKeyLo_EL1_SysRegRead_d57fe909b886c0fe")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMDEVARCH_EL1_SysRegRead_f379f5d64ab8b025")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b0111#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGCLAIMCLR_EL1_SysRegRead_ffbb497475eb383a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_d8b7590f7c00d19c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_c3ec1516735db5f7")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_d4c2dcc933af38a7")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_8a3cda8f4660427a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_351ab37f466f6889")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_8c3e53570d26ce7a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_ab88cca85ec0eca9")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_a18f410293f246c4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_755afa7df870d9ab")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_c5088163afaa4276")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_25b8861425ee4c26")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_9deb23233bdb8631")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_a6904466fe9c7a54")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_7e4c0d4f3367d780")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_08fe9aa719e4e44c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGBVR_EL1_SysRegRead_5ed77d081c253be3")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMCEID0_EL0_SysRegRead_f2e86782f8f3f9b7")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_419765ae001a7669")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_27540f902a0177f1")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_3ea4dd4eabbc6db1")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_3ad260c7658f264f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_6c69a5a56e08fe81")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_bfffa222b59a2eac")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_395e92ea6cb1cbd3")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_e481fcd4bbdbbbdd")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_fae261a7c3341309")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_469f2550ef085d68")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_5cfc3b8e8ae8a2a4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_dd3a55e2d9bbec8f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_9cebffd3d1c8ceeb")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_06f47f0db897fdec")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_695a90ac9c89a050")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b10#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded DBGWVR_EL1_SysRegRead_19cc269e021d29f0")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PIRE0_EL1_SysRegRead_1431908c1f187dd9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64AFR0_EL1_SysRegRead_d690252709f00b61")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AFSR0_EL2_SysRegRead_acffc015481d1ac8")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMAIR2_EL1_SysRegRead_961066b22ab5b10e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_PFR2_EL1_SysRegRead_d9584bfc0ea04005")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CurrentEL_SysRegRead_94be544516d41cc8")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b110#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SPMACCESSR_EL3_SysRegRead_04a853a73f22109c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTHV_CTL_EL2_SysRegRead_fe7c25cca2e88b3f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1110#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded CNTVCT_EL0_SysRegRead_1d562372e622baf9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64ZFR0_EL1_SysRegRead_dd573310e3efc3be")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ZCR_EL3_SysRegRead_db53f2dcbaed5b3a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ZCR_EL1_SysRegRead_f79acfc1d948e192")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ZCR_EL1_SysRegRead_ae33ffd6ee977eba")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ZCR_EL2_SysRegRead_e12f14b3f5451ee5")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMCR_EL3_SysRegRead_131f4d5255bb9624")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMCR_EL1_SysRegRead_924df8670c1f630f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMCR_EL1_SysRegRead_ea88aa9e02fbf3b4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded SMCR_EL2_SysRegRead_c0f6766b3afb8b13")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ID_AA64SMFR0_EL1_SysRegRead_8f4054d57f9da064")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM2_EL2_SysRegRead_cd39f13f6feef099")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM6_EL2_SysRegRead_a456f2178fffbd2a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM5_EL2_SysRegRead_b3b860d951143744")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMHCR_EL2_SysRegRead_29e51a9bb9c934dc")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMIDR_EL1_SysRegRead_e782b807b20cd739")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM7_EL2_SysRegRead_7f9fcda98e26326e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAM2_EL2_SysRegRead_f89d395320b0f023")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAM2_EL2_SysRegRead_8458d45c0c29ff85")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM1_EL2_SysRegRead_d5133d205dd80497")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM0_EL2_SysRegRead_0960f12de90321b6")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM3_EL2_SysRegRead_3655c8ba5ed54616")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAM3_EL3_SysRegRead_2770962b9f8f46c1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAM0_EL1_SysRegRead_26602bb382f28735")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMSM_EL1_SysRegRead_8b218aacc540b1cb")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPM4_EL2_SysRegRead_2c47261ee8f811ec")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAM1_EL1_SysRegRead_85039c69dab4c388")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded MPAMVPMV_EL2_SysRegRead_3717c7fd58152b67")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0000#4)) && (op0 == 0b11#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GMID_EL1_SysRegRead_df65333e6c977d08")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TFSR_EL3_SysRegRead_8cd0ca2e5d9daf2c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TFSRE0_EL1_SysRegRead_e7166fad237839bf")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TFSR_EL2_SysRegRead_c301d170f18e0e34")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TFSR_EL2_SysRegRead_5ac7c240abc0c535")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TFSR_EL1_SysRegRead_629d1d7950939eef")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded RGSR_EL1_SysRegRead_64fa1a7b4e06fd7e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCR_EL1_SysRegRead_62bd5315db9a2829")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0100#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TCO_SysRegRead_fec6636824256193")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_270554ed1cad7329")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_c7849b6a9ce28268")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_55e8473fc6bbc0d9")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_bf47e913d26baa8e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_9f7317df01644a85")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_be6aed1af9b22a58")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_ca529b74c1d7516d")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_34297951a57ea0ef")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_fb04d104547be6cf")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_e352be1aa751f006")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_11d34f68d6780256")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_8db93fe7c2515bf5")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_4784c0c277b5428d")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_bad34f14bd2fb39c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_7638ccb047de09f8")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR1_EL0_SysRegRead_0ca7d1c44e1352f0")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_32a7e4332477435d")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_0efd385ac3f50aa7")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_9967025452c01cd2")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_906fb8ee06808f75")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_bc26fe69d64e9fcd")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_fab3ea7a2072d326")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_fa89039688bc4bb9")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_9b9b8289286b389f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_8025c4d237ad3c30")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_6fb8f8a119c2917d")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_90b97336851e0b89")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_9c52ba86b79d6d1b")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_5616d16017b0ebad")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_e7b800151f349b69")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_48d575ae64c47181")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF0_EL2_SysRegRead_0058ecc12215fa39")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCR_EL0_SysRegRead_fe2573ba12b8cf16")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCNTENSET0_EL0_SysRegRead_df359e5215fe4ea4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCNTENCLR0_EL0_SysRegRead_21074600beb00df2")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER0_EL0_SysRegRead_0cc4dde298f89021")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER0_EL0_SysRegRead_4f032bbf168e91d3")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER0_EL0_SysRegRead_141bbfd1d5e601d1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER0_EL0_SysRegRead_109f5242c6f95a4b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCNTENSET1_EL0_SysRegRead_d259e0efa9006177")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCNTENCLR1_EL0_SysRegRead_4cb38b40de21160e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR0_EL0_SysRegRead_cc9416b67c23e421")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR0_EL0_SysRegRead_d036784f50549cc8")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR0_EL0_SysRegRead_f7357452cbdf2767")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTR0_EL0_SysRegRead_a4167a2ccc34a8ca")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCFGR_EL0_SysRegRead_ec6dd3c706fcda64")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_f1c1cecc05c57faa")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_63bf321dec6513c6")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_19a0030d7d85728c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_61ebab1c5fc330a2")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_14a05140a99b1d6a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_36fd38c66709d268")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_ab60ef2f0cd65aba")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_1a9e9a20154e0542")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_20dd4c2724a8f8a0")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_aba56e69378156c9")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_5d5ff9d73e486760")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_810c9c7ab8f85945")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_9ccfe31177eb70bf")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_89a7234b83ebc6eb")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_42fe0c3a8ef734f0")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVCNTVOFF1_EL2_SysRegRead_bc32b16140cabb5b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMUSERENR_EL0_SysRegRead_72607d8d9c634200")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCG1IDR_EL0_SysRegRead_0dbcfa52be452f1c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_4517fc1a9af5a349")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_378b824787ad2fa8")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_ace2a16645ca5a01")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_9fc9c2c315f2eddc")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_c06031c8baa68012")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_02ccdb3991a6241f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_d44d986d5aa5ac28")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_a53d76115c4ce8dd")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_c8256ab91500d7f3")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_4a0a6a309cab0296")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_b19d7fec0ca1e05a")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_b5481b68c98a55a0")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_130fc21a65e30919")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_04bf025f6505940b")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_50f740f5417b3e8c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMEVTYPER1_EL0_SysRegRead_b184c6ea62674df7")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded AMCGCR_EL0_SysRegRead_06267c37ea5fd2cb")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMBPTR_EL1_SysRegRead_fecbe9ae2e92d802")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSFCR_EL1_SysRegRead_6babf00bd8f977b2")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSIRR_EL1_SysRegRead_fb1e9f4098f84549")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSICR_EL1_SysRegRead_21061f53bd37d43f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSDSFR_EL1_SysRegRead_dbabfebdd50e6ad5")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSEVFR_EL1_SysRegRead_609a095fd2f44185")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMBLIMITR_EL1_SysRegRead_698047bfa5d212f3")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMBSR_EL1_SysRegRead_65583fd5eecf376d")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSCR_EL2_SysRegRead_7e9c76511198b62b")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSCR_EL2_SysRegRead_feca5252d10f1b6c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSCR_EL1_SysRegRead_feea919a1dc38dc5")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSIDR_EL1_SysRegRead_51ea9fe85c485c1f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSNEVFR_EL1_SysRegRead_be9e8b2bf9a915f4")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b111#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMBIDR_EL1_SysRegRead_48dfa0662916d0ce")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1001#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PMSLATFR_EL1_SysRegRead_84b6a2bf8c3de92b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded VDISR_EL2_SysRegRead_354cfd34639eb7c6")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1100#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded VDISR_EL2_SysRegRead_07ff39acd959bbaf")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXADDR_EL1_SysRegRead_e08903d0b9a89a31")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXMISC0_EL1_SysRegRead_9ea301ebf74aba67")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERRIDR_EL1_SysRegRead_1405fcd9adc2c3a9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXPFGCDN_EL1_SysRegRead_6e5dee0a1557f09c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXPFGF_EL1_SysRegRead_d0bdc4688b970c59")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERRSELR_EL1_SysRegRead_8615029c42903774")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXMISC1_EL1_SysRegRead_386d0719bc4739c7")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXCTLR_EL1_SysRegRead_e46adf59deec13d6")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXSTATUS_EL1_SysRegRead_ca7fd81b70f9297e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXFR_EL1_SysRegRead_f8186cd7f820b3af")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXGSR_EL1_SysRegRead_63b383efe8ec0d4f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXMISC3_EL1_SysRegRead_56f8ce5aebf1b5ec")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXMISC2_EL1_SysRegRead_6ed4c8d1911e048a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded VSESR_EL2_SysRegRead_dcbab774e333f499")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded ERXPFGCTL_EL1_SysRegRead_420b4fad4c0bef26")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_f576b69cab3c9e91")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_68f733837a85950e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_4ae3373d3e11ea10")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_ea333ab47e4a6f1e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_12a374a1337f2158")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_004189f53be4d3aa")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_956d322b1e39b0ab")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_6c58e23173be8c63")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_97b6117930948ca0")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_f0d2234cd65ac731")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_d553e16381f68050")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_b4a0ffb7768f7021")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_76723f8ffeba3316")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_167b0f9ad00f744c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_ca6fd21020d85edf")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b100#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_059543eab5e966b1")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_cd25feee447def98")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_1238ef792e876294")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_a11664a8ed6f4106")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_5328c51266b81007")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_d0c46fd015ceb879")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_0dff5d276a18ac1b")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_5d1dd861f0ff77ac")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_2c600906402c2b67")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_d6c042d579aad6ae")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_0b0a91ffc847ffa1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_923e32fe7fade07e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_48bbd285cc41ccf1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_f4230c6e2734deb4")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_e899a449a42d0451")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_06cfcedba145d8be")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINF_EL1_SysRegRead_ecdadc5359d94302")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_e84fec146c0ec53c")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_1f756e7f398b2913")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_ae456def5b2d3877")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_f716b6b4ae3bca3e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_4a26f7681cbb4b61")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_af7e58d50faba266")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_a1836a366d3770a4")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_39b283daffc26b48")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_0763623dddebed93")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_e6294ef271ec9fdd")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_d0b2b38c41380e27")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_78b71d697e3a7c27")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_523b8e4201ff85d3")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_f85da45410915871")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_3acb3c110dfc9028")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_d83abc0d01ceb716")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_901e3d710db08495")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_a19b60211eaf5d17")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_836220a18820905f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_6d006e7c7c1ea2f2")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_1af5178ad600d3a5")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_71b2c8fc1498b4b2")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_f2e343a383a585f8")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_b9c401f4aafa6cae")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_2323d292faaf2c52")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_0b4f89fe1c4542ef")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_a58bd53c7eda75fe")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_45c85163047bb4e9")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_c2018b407cd053ad")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_cea01bf612be4740")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_2def60c5cd956968")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGT_EL1_SysRegRead_61af63a696814dc5")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBCR_EL2_SysRegRead_3e399240c4f4d549")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBCR_EL2_SysRegRead_7a9e81b09ce79591")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_33c4b2eee9151575")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_629d83cb2c3319a3")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_d2ff5f8a61d06f9b")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_ef5027149f4fd69e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_66c1c459776c066e")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_561515c0c6afe1b8")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_832b319ba0979511")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_b1d7d5499745f113")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_2ff088f1ef08febc")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_1ffd06111e3a6e95")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_0b650e0ab6d1b44c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_1c94f14d1fd6245f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_3ce62e599c7c836c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_42de11a512022e40")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_6a646a8b097b9662")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b101#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_442e3527ac440384")))
              else (do (pure ())))
              (if ((((((CRm == 0b1111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_5b4b28442256ea43")))
              else (do (pure ())))
              (if ((((((CRm == 0b1110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_cf9b7af02d181adc")))
              else (do (pure ())))
              (if ((((((CRm == 0b1101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_52d32e2fdd778cdd")))
              else (do (pure ())))
              (if ((((((CRm == 0b1100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_843d617412783cba")))
              else (do (pure ())))
              (if ((((((CRm == 0b1011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_97cc6af3e6810121")))
              else (do (pure ())))
              (if ((((((CRm == 0b1010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_6c5c1f71c6436b80")))
              else (do (pure ())))
              (if ((((((CRm == 0b1001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_867cb054c07cff2f")))
              else (do (pure ())))
              (if ((((((CRm == 0b1000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_e1966593749d3d3f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0111#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_0343a6528d6efd4c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0110#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_7c36b32dfd995b27")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_4a79da6f3039aa0b")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_a985e159abb6644f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0011#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_54e43d4416534fcb")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_5dedf70f29c9772d")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_612f81995305025e")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1000#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRC_EL1_SysRegRead_995cc54bcb3d899c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBSRCINJ_EL1_SysRegRead_f235ffd98eed1805")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTS_EL1_SysRegRead_a92810602a111e63")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBFCR_EL1_SysRegRead_6dce71f1750cf1d1")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBINFINJ_EL1_SysRegRead_7c147e54f4ecbf52")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBCR_EL1_SysRegRead_e8e220b931609fe8")))
              else (do (pure ())))
              (if ((((((CRm == 0b0010#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBIDR0_EL1_SysRegRead_4134441fa4c3f5c2")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b1001#4)) && (op0 == 0b10#2)) && (op1 == 0b001#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded BRBTGTINJ_EL1_SysRegRead_0e58e4379b298df5")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPR_EL3_SysRegRead_3f6b8f8e31fb3882")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPR_EL1_SysRegRead_efbe68095a628d64")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPR_EL1_SysRegRead_474789c62224c972")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b110#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSCR_EL3_SysRegRead_f722c361b12a49bd")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSCR_EL1_SysRegRead_c10918a3ea4a2f5c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSCR_EL1_SysRegRead_a1c1abc2b55fb304")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPR_EL2_SysRegRead_9daadab9c1c453f3")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSCR_EL2_SysRegRead_cc7b26a3631eab6f")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b010#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSCRE0_EL1_SysRegRead_0250ee8c94b04721")))
              else (do (pure ())))
              (if ((((((CRm == 0b0101#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b011#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded GCSPR_EL0_SysRegRead_eb4ca18a2cca83d6")))
              else (do (pure ())))
              (if ((((((CRm == 0b0100#4) && (CRn == 0b0111#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded PAR_EL1_SysRegRead_8d8d0b85bc9f516c")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b011#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded RCWSMASK_EL1_SysRegRead_431036cb88e83e2a")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR1_EL1_SysRegRead_004ea76932891707")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR1_EL1_SysRegRead_b7baefd515331ebe")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR0_EL2_SysRegRead_46a02b83889584ea")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR0_EL2_SysRegRead_213283d6df4659a2")))
              else (do (pure ())))
              (if ((((((CRm == 0b0001#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded VTTBR_EL2_SysRegRead_1816600c5e2db377")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b101#3)) && (op2 == 0b000#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR0_EL1_SysRegRead_ea81bf619338bdf3")))
              else (do (pure ())))
              (if ((((((match CRm with
                         | b__0 => true : Bool) && (let b__1 := CRn
                         if ((((Sail.BitVec.extractLsb b__1 3 3) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__1 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                         then true
                         else false : Bool)) && (op0 == 0b11#2)) && (match op1 with
                     | b__2 => true : Bool)) && (match op2 with
                   | b__3 => true : Bool)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded S3_op1_Cn_Cm_op2_SysRegRead_9e206a297d1c5480")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b1101#4)) && (op0 == 0b11#2)) && (op1 == 0b000#3)) && (op2 == 0b110#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded RCWMASK_EL1_SysRegRead_5e28ff06021a9b89")))
              else (do (pure ())))
              (if ((((((CRm == 0b0000#4) && (CRn == 0b0010#4)) && (op0 == 0b11#2)) && (op1 == 0b100#3)) && (op2 == 0b001#3)) : Bool)
              then (do sailThrow ((Error_ImplementationDefined "janus-excluded TTBR1_EL2_SysRegRead_0c064c5f1843df74")))
              else (do (pure ())))
              sailThrow ((Error_ImplementationDefined "janus-excluded AArch64_AutoGen_SysRegRead"))))))

/-- Type quantifiers: t : Int -/
def ACCDATA_EL1_SysRegWrite_8e0ffec0877851f7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ADEn ← (( do (pure (_get_SCR_EL3_Type_ADEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nACCDATA_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nACCDATA_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ADEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nACCDATA_EL1 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL1_SysRegWrite_7b28af04d67b98b9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TACR ← (( do (pure (_get_HCR_EL2_Type_TACR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TACR == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x118#12) (← (X_read t 64))))
                    else (do writeReg ACTLR_EL1 (← (X_read t 64)))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg ACTLR_EL1 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL2_SysRegWrite_55fae67ae0a6faf2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg ACTLR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL3_SysRegWrite_32865ae0e6068940 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL1_SysRegWrite_be844a45265221f7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x128#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL1_SysRegWrite_bfb8a5c21b8a15cd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AFSR0_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AFSR0_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AFSR0_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x128#12) (← (X_read t 64))))
                          else (do writeReg AFSR0_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR0_EL2 (← (X_read t 64)))
                    else (do writeReg AFSR0_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL2_SysRegWrite_1b5a40d7cb8265ce (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AFSR0_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL3_SysRegWrite_1c6f9ccfd5716ce3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL1_SysRegWrite_358d58edce00a180 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x130#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL1_SysRegWrite_57c6bddf9a2482df (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AFSR1_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AFSR1_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AFSR1_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x130#12) (← (X_read t 64))))
                          else (do writeReg AFSR1_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR1_EL2 (← (X_read t 64)))
                    else (do writeReg AFSR1_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL2_SysRegWrite_a63eac436b30cded (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AFSR1_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL3_SysRegWrite_9124b1facd539906 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ALLINT_SysRegWrite_28e93c037c43b390 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCRX_EL2_TALLINT ← (( do (pure (_get_HCRX_EL2_Type_TALLINT (← readReg HCRX_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (IsHCRXEL2Enabled ())))) && (__HCRX_EL2_TALLINT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL1_SysRegWrite_15a11ef20a82181c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x288#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AMAIR2_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL2_SysRegWrite_1e7d4e25c1dcc572 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg AMAIR2_EL2 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL2_SysRegWrite_d6e02923e8c9c534 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nAMAIR2_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nAMAIR2_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nAMAIR2_EL1 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x288#12) (← (X_read t 64))))
                                      else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg AMAIR2_EL2 (← (X_read t 64)))
                                else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL3_SysRegWrite_2519753087e4450a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL1_SysRegWrite_88ac7594e16a57fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x148#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL2_SysRegWrite_3448b91e0a445f88 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AMAIR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AMAIR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AMAIR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x148#12) (← (X_read t 64))))
                          else (do writeReg AMAIR_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AMAIR_EL2 (← (X_read t 64)))
                    else (do writeReg AMAIR_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL2_SysRegWrite_4119e8051bae499e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AMAIR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL3_SysRegWrite_31ae559cd6a97a1f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMCNTENCLR0_EL0_SysRegWrite_87e21241643a862e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENCLR0_EL0 (Mk_AMCNTENCLR0_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENCLR1_EL0_SysRegWrite_c63fb61a666d3a21 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENCLR1_EL0 (Mk_AMCNTENCLR1_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENSET0_EL0_SysRegWrite_b4e12b5dd3b0738a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENSET0_EL0 (Mk_AMCNTENSET0_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENSET1_EL0_SysRegWrite_a3bee0219e2d4b9e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENSET1_EL0 (Mk_AMCNTENSET1_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCR_EL0_SysRegWrite_6a9019dd97aa8af1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCR_EL0 (Mk_AMCR_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_57776cdcd88bec7e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 2 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_a28bd21dde7b55b6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 1 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_ca5a4224a458ea03 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 0 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_df6bb2663cab03ed (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 3 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_2bb86c4004ef9258 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 0))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 0 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_2cb2cddc132a8d44 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 6))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 6 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_3743486d55da4508 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 1 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_44cf3260f4372341 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 5))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 5 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_4a152435dd65137a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 10))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 10 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_5139d9a03c76c81b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 3))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 3 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_59bacd045e260141 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 4))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 4 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_6bd5d306c662d714 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 2))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 2 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_887d0ce81624d210 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 15))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 15 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_909b4a89534d73e1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 9))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 9 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_9193b8497c20a5ba (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 14))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 14 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_cef156af264e97db (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 11))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 11 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_d8f3e0edb71c094d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 8))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 8 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_e45e9615b0ec1e8a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 12))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 12 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_f1dd22a5ecbcbc6b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 13))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 13 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_fe71412c61f10c5a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 7))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 7 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_0923dbc89132e313 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 3)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 3 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 3 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_16f386a96bc6f4d5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_1aa3b39d45f679b5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_31c0cdbd9c1a5aa3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_4c087411a832c41e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_7037d0a12cbf01ad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_74ccc6eecceec9f9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_972cb3f0c159a0b7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_9d4925d599bf21f3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_9dd8ffd73516d6df (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_a45d1ca97a349f4b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_ad5b87d3125380af (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_bbcf6bc1df66bebc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_c10f27e36cfd4438 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 2)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 2 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 2 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_c76c398d7598cd2b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_f6918a05ffc46bd6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 0)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 0 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 0 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_028cfcaff48c5d3b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 9))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 9)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 9 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 9 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_18b1c0f6609cfc70 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 8))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 8)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 8 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 8 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_1a046ba7336f9e16 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 12))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 12)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 12 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 12 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_21fc3e4e66b7bf2e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 4))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 4)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 4 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 4 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_2ba85b85b5072821 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 10))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 10)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 10 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 10 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_386268cd3029fb99 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 11))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 11)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 11 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 11 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_55f6fd2dd91b0e50 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 6))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 6)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 6 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 6 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_715140b6e1ae357e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 14))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 14)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 14 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 14 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_894c1ceeabf341e5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 13))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 13)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 13 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 13 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_a4b7dbcc8064b06d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 3))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 3)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 3 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 3 (← (X_read t 64))))
                          else (do (pure ())))))))))))


end ArmASL.Functions
