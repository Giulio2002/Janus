import ArmASL.Part27

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_22af59188966bea5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (14 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 14 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (14 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 14 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 14 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 14 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_23d83a8d84cf4328 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (25 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 25 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (25 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 25 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 25 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 25 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_29f48446776d7ca1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (30 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 30 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (30 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 30 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 30 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 30 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_30d204a558c459d3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (0 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 0 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (0 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 0 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 0 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 0 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_3665adeaa18329a1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (1 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 1 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (1 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 1 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 1 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 1 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_3e371a7e242c16d1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (5 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 5 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (5 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 5 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 5 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 5 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_4512e22da5c9c652 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (12 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 12 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (12 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 12 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 12 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 12 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_4a98a0a209c3826c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (29 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 29 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (29 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 29 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 29 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 29 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_4f241cdbcd0057d7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (24 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 24 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (24 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 24 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 24 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 24 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_544bb3207feb251f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (10 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 10 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (10 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 10 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 10 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 10 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_73822ad328f88229 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (8 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 8 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (8 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 8 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 8 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 8 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_83e6f39262ce431e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (15 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 15 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (15 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 15 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 15 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 15 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_91074e3d22d815e7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (20 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 20 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (20 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 20 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 20 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 20 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_983325f763a0f9db (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (26 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 26 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (26 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 26 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 26 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 26 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_99f3a73b00c28141 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (18 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 18 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (18 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 18 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 18 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 18 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_9ca8351299928290 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (3 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 3 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (3 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 3 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 3 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 3 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_bd30e84b2c72691b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (19 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 19 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (19 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 19 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 19 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 19 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_bee5b17c9678351b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (21 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 21 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (21 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 21 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 21 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 21 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_c1033a183cde77b2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (22 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 22 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (22 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 22 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 22 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 22 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_c66160ca506190dd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (7 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 7 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (7 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 7 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 7 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 7 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def PMEVTYPER_EL0_SysRegWrite_cac95f0b279e6d98 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TPM ← (( do (pure (_get_MDCR_EL3_Type_TPM (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __PMUSERENR_EL0_EN ← (( do (pure (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_PMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_TPM ← (( do (pure (_get_MDCR_EL2_Type_TPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((IsFeatureImplemented FEAT_PMUv3p9) <&&> (do
                   (pure (((_get_PMUSERENR_EL0_Type_UEN (← readReg PMUSERENR_EL0)) +++ (_get_PMUSERENR_EL0_Type_EN (← readReg PMUSERENR_EL0))) == 0b00#2))) <||> (do
                   (pure ((! (← (IsFeatureImplemented FEAT_PMUv3p9))) && (__PMUSERENR_EL0_EN == 0#1)))))) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (27 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 27 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_PMEVTYPERn_EL0 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_TPM == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (27 ≥b (← (AArch64_GetNumEventCountersAccessible ()))))))) : Bool)
                                then
                                  (do (if ((! (← (IsFeatureImplemented FEAT_FGT))) : Bool)
                                      then (do (pure (ConstrainUnpredictableProcedure Unpredictable_PMUEVENTCOUNTER)))
                                      else (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 27 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_TPM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 27 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PMEVTYPER_EL0 (vectorUpdate (← readReg PMEVTYPER_EL0) 27 (Mk_PMEVTYPER_EL0_Type (← (X_read t 64)))))
                    else (do (pure ())))))))))


end ArmASL.Functions
