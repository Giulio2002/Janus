import ArmASL.Part27

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_ldursw_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36825.113-36825.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36844.107-36844.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_prfum_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36915.113-36915.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:36934.107-36934.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_stur_gen_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37005.113-37005.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37024.107-37024.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_sturb_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37095.113-37095.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37114.107-37114.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

def decode_sturh_aarch64_instrs_memory_single_general_immediate_signed_offset_normal (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm9 : (BitVec 9)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := (sign_extend imm9 64)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37185.113-37185.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:37204.107-37204.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_signed_offset_normal datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: a : Nat, d : Nat, datasize : Nat, destsize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem destsize [32, 64] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (a : Nat) (d : Nat) (datasize : Nat) (destsize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (X_read a destsize) ) : SailM (BitVec destsize) )
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result : Int :=
    if (sub_op : Bool)
    then ((BitVec.toNat operand3) -i ((BitVec.toNat operand1) *i (BitVec.toNat operand2)))
    else ((BitVec.toNat operand3) +i ((BitVec.toNat operand1) *i (BitVec.toNat operand2)))
  let result := result
  (X_set d destsize (integer_subrange result (destsize -i 1) 0))

def decode_madd_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let datasize := destsize
  let sub_op : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub a d datasize destsize m n sub_op)

def decode_msub_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let datasize := destsize
  let sub_op : Bool := (o0 == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_uniform_add_sub a d datasize destsize m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_accum (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let product ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let product : (BitVec esize) := (integer_subrange ((BitVec.toNat element1) *i (BitVec.toNat element2)) (esize -i 1) 0)
        let result ← (( do
          (if (sub_op : Bool)
          then (do (Elem_set result e esize ((← (Elem_read operand3 e esize)) - product)))
          else (do (Elem_set result e esize ((← (Elem_read operand3 e esize)) + product)))) ) : SailM (BitVec datasize) )
        (pure (element1, element2, product, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_mla_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_accum d datasize elements esize m n sub_op)

def decode_mls_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_accum d datasize elements esize m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_int (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (pure (BitVec.toNat (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toNat (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let product : (BitVec esize) := (integer_subrange (element1 *i element2) (esize -i 1) 0)
        let result ← (( do
          (if (sub_op : Bool)
          then (do (Elem_set result e esize ((← (Elem_read operand3 e esize)) - product)))
          else (do (Elem_set result e esize ((← (Elem_read operand3 e esize)) + product)))) ) : SailM (BitVec datasize) )
        (pure (element1, product, result))
    (pure loop_vars) ) : SailM (Int × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_mla_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_int d datasize elements esize idxdsize index m n sub_op)

def decode_mls_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_int d datasize elements esize idxdsize index m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, pos : Nat, 0 ≤ pos ∧ pos ≤ 63 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_ins_ext_insert_movewide (d : Nat) (datasize : Nat) (imm : (BitVec 16)) (opcode : MoveWideOp) (pos : Nat) : SailM Unit := do
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    (if ((BEq.beq opcode MoveWideOp_K) : Bool)
    then (do (X_read d datasize))
    else (do (pure (Zeros (n := datasize))))) ) : SailM (BitVec datasize) )
  sail_assert ((pos +i 15) <b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:37506.44-37506.45"
  let result : (BitVec datasize) := (Sail.BitVec.updateSubrange result (pos +i 15) pos imm)
  let result : (BitVec datasize) :=
    if ((BEq.beq opcode MoveWideOp_N) : Bool)
    then (Complement.complement result)
    else result
  let result := result
  (X_set d datasize result)

def decode_movk_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

def decode_movn_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

def decode_movz_aarch64_instrs_integer_ins_ext_insert_movewide (Rd : (BitVec 5)) (imm16 : (BitVec 16)) (hw : (BitVec 2)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let imm : (BitVec 16) := imm16
  let opcode ← (( do (undefined_MoveWideOp ()) ) : SailM MoveWideOp )
  let opcode ← (( do
    match opc with
    | 0b00 => (pure MoveWideOp_N)
    | 0b10 => (pure MoveWideOp_Z)
    | 0b11 => (pure MoveWideOp_K)
    | _ => sailThrow ((Error_Undefined ())) ) : SailM MoveWideOp )
  let opcode := opcode
  (if (((sf == 0#1) && (((BitVec.access hw 1) : BitVec 1) == 1#1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let pos := (BitVec.toNat (hw +++ 0b0000#4))
  (execute_aarch64_instrs_integer_ins_ext_insert_movewide d datasize imm opcode pos)

/-- Type quantifiers: k_read : Bool, sys_crm : Nat, sys_crn : Nat, sys_op0 : Nat, sys_op1 : Nat, sys_op2 : Nat, t : Nat, 0 ≤ t ∧ t ≤ 31 ∧ List.elem sys_op2 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op1 [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem sys_op0 [2, 3] ∧ 0 ≤ sys_crn ∧ sys_crn ≤ 15 ∧ 0 ≤ sys_crm ∧ sys_crm ≤ 15 -/
def execute_aarch64_instrs_system_register_system (read : Bool) (sys_crm : Nat) (sys_crn : Nat) (sys_op0 : Nat) (sys_op1 : Nat) (sys_op2 : Nat) (t : Nat) : SailM Unit := do
  (if (read : Bool)
  then (do (AArch64_SysRegRead sys_op0 sys_op1 sys_crn sys_crm sys_op2 t))
  else (do (AArch64_SysRegWrite sys_op0 sys_op1 sys_crn sys_crm sys_op2 t)))

def decode_mrs_aarch64_instrs_system_register_system (Rt : (BitVec 5)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (CRn : (BitVec 4)) (op1 : (BitVec 3)) (o0 : (BitVec 1)) (L : (BitVec 1)) : SailM Unit := do
  (AArch64_CheckSystemAccess (1#1 +++ o0) op1 CRn CRm op2 Rt L)
  let t := (BitVec.toNat Rt)
  let sys_op0 := (2 +i (BitVec.toNat o0))
  let sys_op1 := (BitVec.toNat op1)
  let sys_op2 := (BitVec.toNat op2)
  let sys_crn := (BitVec.toNat CRn)
  let sys_crm := (BitVec.toNat CRm)
  let read : Bool := (L == 1#1)
  (execute_aarch64_instrs_system_register_system read sys_crm sys_crn sys_op0 sys_op1 sys_op2 t)

def decode_msr_reg_aarch64_instrs_system_register_system (Rt : (BitVec 5)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (CRn : (BitVec 4)) (op1 : (BitVec 3)) (o0 : (BitVec 1)) (L : (BitVec 1)) : SailM Unit := do
  (AArch64_CheckSystemAccess (1#1 +++ o0) op1 CRn CRm op2 Rt L)
  let t := (BitVec.toNat Rt)
  let sys_op0 := (2 +i (BitVec.toNat o0))
  let sys_op1 := (BitVec.toNat op1)
  let sys_op2 := (BitVec.toNat op2)
  let sys_crn := (BitVec.toNat CRn)
  let sys_crm := (BitVec.toNat CRm)
  let read : Bool := (L == 1#1)
  (execute_aarch64_instrs_system_register_system read sys_crm sys_crn sys_op0 sys_op1 sys_op2 t)

def execute_aarch64_instrs_system_register_cpsr (field : PSTATEField) (operand : (BitVec 4)) : SailM Unit := do
  match field with
  | .PSTATEField_SSBS => writeReg PSTATE { (← readReg PSTATE) with SSBS := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_SP => writeReg PSTATE { (← readReg PSTATE) with SP := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_DAIFSet =>
    (do
      writeReg PSTATE { (← readReg PSTATE) with D := (← do
        (pure ((← readReg PSTATE).D ||| ((BitVec.access operand 3) : BitVec 1)))) }
      writeReg PSTATE { (← readReg PSTATE) with A := (← do
        (pure ((← readReg PSTATE).A ||| ((BitVec.access operand 2) : BitVec 1)))) }
      writeReg PSTATE { (← readReg PSTATE) with I := (← do
        (pure ((← readReg PSTATE).I ||| ((BitVec.access operand 1) : BitVec 1)))) }
      writeReg PSTATE { (← readReg PSTATE) with F := (← do
        (pure ((← readReg PSTATE).F ||| ((BitVec.access operand 0) : BitVec 1)))) })
  | .PSTATEField_DAIFClr =>
    (do
      writeReg PSTATE { (← readReg PSTATE) with D := (← do
        (pure ((← readReg PSTATE).D &&& (Complement.complement ((BitVec.access operand 3) : BitVec 1))))) }
      writeReg PSTATE { (← readReg PSTATE) with A := (← do
        (pure ((← readReg PSTATE).A &&& (Complement.complement ((BitVec.access operand 2) : BitVec 1))))) }
      writeReg PSTATE { (← readReg PSTATE) with I := (← do
        (pure ((← readReg PSTATE).I &&& (Complement.complement ((BitVec.access operand 1) : BitVec 1))))) }
      writeReg PSTATE { (← readReg PSTATE) with F := (← do
        (pure ((← readReg PSTATE).F &&& (Complement.complement ((BitVec.access operand 0) : BitVec 1))))) })
  | .PSTATEField_PAN => writeReg PSTATE { (← readReg PSTATE) with PAN := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_UAO => writeReg PSTATE { (← readReg PSTATE) with UAO := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_DIT => writeReg PSTATE { (← readReg PSTATE) with DIT := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_TCO => writeReg PSTATE { (← readReg PSTATE) with TCO := ((BitVec.access operand 0) : BitVec 1) }
  | .PSTATEField_ALLINT =>
    (do
      (if (((←((pure ((← readReg PSTATE).EL == EL1)) <&&> (do
             (IsHCRXEL2Enabled ())) <&&> (do
             (pure ((_get_HCRX_EL2_Type_TALLINT (← readReg HCRX_EL2)) == 1#1))))) && (((BitVec.access operand 0) : BitVec 1) == 1#1)) : Bool)
      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
      else (do (pure ())))
      writeReg PSTATE { (← readReg PSTATE) with ALLINT := ((BitVec.access operand 0) : BitVec 1) })
  | .PSTATEField_SVCRSM =>
    (do
      (CheckSMEAccess ())
      (SetPSTATE_SM ((BitVec.access operand 0) : BitVec 1)))
  | .PSTATEField_SVCRZA =>
    (do
      (CheckSMEAccess ())
      (SetPSTATE_ZA ((BitVec.access operand 0) : BitVec 1)))
  | .PSTATEField_SVCRSMZA =>
    (do
      (CheckSMEAccess ())
      (SetPSTATE_SM ((BitVec.access operand 0) : BitVec 1))
      (SetPSTATE_ZA ((BitVec.access operand 0) : BitVec 1)))
  | .PSTATEField_PM => writeReg PSTATE { (← readReg PSTATE) with PM := ((BitVec.access operand 0) : BitVec 1) }

def decode_msr_imm_aarch64_instrs_system_register_cpsr (op2 : (BitVec 3)) (CRm : (BitVec 4)) (op1 : (BitVec 3)) : SailM Unit := do
  (if (((op1 == 0b000#3) && (op2 == 0b000#3)) : Bool)
  then (do sailThrow ((Error_See "CFINV")))
  else (do (pure ())))
  (if (((op1 == 0b000#3) && (op2 == 0b001#3)) : Bool)
  then (do sailThrow ((Error_See "XAFLAG")))
  else (do (pure ())))
  (if (((op1 == 0b000#3) && (op2 == 0b010#3)) : Bool)
  then (do sailThrow ((Error_See "AXFLAG")))
  else (do (pure ())))
  (AArch64_CheckSystemAccess 0b00#2 op1 0b0100#4 CRm op2 0b11111#5 0#1)
  let min_EL ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let need_secure : Bool := false
  let (min_EL, need_secure) ← (( do
    let b__0 := op1
    let (min_EL, need_secure) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 1) == (0b00#2 : (BitVec 2))) : Bool)
      then
        (do let min_EL : (BitVec 2) := EL1
            (pure (min_EL, need_secure)))
      else
        (do let (min_EL, need_secure) ← (( do
              (if ((b__0 == (0b010#3 : (BitVec 3))) : Bool)
              then
                (do let min_EL : (BitVec 2) := EL1
                    (pure (min_EL, need_secure)))
              else
                (do let (min_EL, need_secure) ← (( do
                      (if ((b__0 == (0b011#3 : (BitVec 3))) : Bool)
                      then
                        (do let min_EL : (BitVec 2) := EL0
                            (pure (min_EL, need_secure)))
                      else
                        (do let (min_EL, need_secure) ← (( do
                              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
                              then
                                (do let min_EL : (BitVec 2) := EL2
                                    (pure (min_EL, need_secure)))
                              else
                                (do let (min_EL, need_secure) ← (( do
                                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                                      then
                                        (do (if ((! (← (HaveVirtHostExt ()))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (pure ())))
                                            let min_EL : (BitVec 2) := EL2
                                            (pure (min_EL, need_secure)))
                                      else
                                        (do let (min_EL, need_secure) : ((BitVec 2) × Bool) :=
                                              if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                                              then
                                                (let min_EL : (BitVec 2) := EL3
                                                (min_EL, need_secure))
                                              else
                                                (let min_EL : (BitVec 2) := EL1
                                                let need_secure : Bool := true
                                                (min_EL, need_secure))
                                            (pure (min_EL, need_secure)))) ) : SailM ((BitVec 2) × Bool) )
                                    (pure (min_EL, need_secure)))) ) : SailM ((BitVec 2) × Bool) )
                            (pure (min_EL, need_secure)))) ) : SailM ((BitVec 2) × Bool) )
                    (pure (min_EL, need_secure)))) ) : SailM ((BitVec 2) × Bool) )
            (pure (min_EL, need_secure)))) ) : SailM ((BitVec 2) × Bool) )
    (pure (min_EL, need_secure)) ) : SailM ((BitVec 2) × Bool) )
  let min_EL := min_EL
  (if ((←((pure ((BitVec.toNat (← readReg PSTATE).EL) <b (BitVec.toNat min_EL))) <||> (do
       (pure need_secure) <&&> (do
         (pure (bne (← (CurrentSecurityState ())) SS_Secure)))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let operand : (BitVec 4) := CRm
  let field ← (( do (undefined_PSTATEField ()) ) : SailM PSTATEField )
  let field ← (( do
    match (op1 +++ op2) with
    | 0b000011 =>
      (do
        (if ((! (← (HaveUAOExt ()))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure PSTATEField_UAO))
    | 0b000100 =>
      (do
        (if ((! (← (HavePANExt ()))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure PSTATEField_PAN))
    | 0b000101 => (pure PSTATEField_SP)
    | 0b001000 =>
      (do
        let b__6 := CRm
        (if (((Sail.BitVec.extractLsb b__6 3 1) == (0b000#3 : (BitVec 3))) : Bool)
        then
          (do (if ((! (← (HaveFeatNMI ()))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (pure ())))
              (pure PSTATEField_ALLINT))
        else
          (do (if (((Sail.BitVec.extractLsb b__6 3 1) == (0b001#3 : (BitVec 3))) : Bool)
              then
                (do (if ((! (← (HaveFeatEBEP ()))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (pure ())))
                    (pure PSTATEField_PM))
              else (do sailThrow ((Error_Undefined ())))))))
    | 0b011010 =>
      (do
        (if ((! (← (HaveDITExt ()))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure PSTATEField_DIT))
    | 0b011011 =>
      (do
        let b__8 := CRm
        (if (((Sail.BitVec.extractLsb b__8 3 1) == (0b001#3 : (BitVec 3))) : Bool)
        then
          (do (if ((! (← (HaveSME ()))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else (do (pure ())))
              (pure PSTATEField_SVCRSM))
        else
          (do (if (((Sail.BitVec.extractLsb b__8 3 1) == (0b010#3 : (BitVec 3))) : Bool)
              then
                (do (if ((! (← (HaveSME ()))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else (do (pure ())))
                    (pure PSTATEField_SVCRZA))
              else
                (do (if (((Sail.BitVec.extractLsb b__8 3 1) == (0b011#3 : (BitVec 3))) : Bool)
                    then
                      (do (if ((! (← (HaveSME ()))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do (pure ())))
                          (pure PSTATEField_SVCRSMZA))
                    else (do sailThrow ((Error_Undefined ())))))))))
    | 0b011100 =>
      (do
        (if ((! (← (HaveMTEExt ()))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure PSTATEField_TCO))
    | 0b011110 => (pure PSTATEField_DAIFSet)
    | 0b011111 => (pure PSTATEField_DAIFClr)
    | 0b011001 =>
      (do
        (if ((! (← (HaveSSBSExt ()))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure PSTATEField_SSBS))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM PSTATEField )
  (if ((((← readReg PSTATE).EL == EL0) && ((BEq.beq field PSTATEField_DAIFSet) || (BEq.beq field PSTATEField_DAIFClr))) : Bool)
  then
    (do (if ((←((IsInHost ()) <||> (do
             (pure ((_get_SCTLR_EL1_Type_UMA (← readReg SCTLR_EL1)) == 0#1))))) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else (do (pure ()))))
  else (do (pure ())))
  (execute_aarch64_instrs_system_register_cpsr field operand)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_poly : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_product (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (poly : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let product ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let product : (BitVec esize) :=
          if (poly : Bool)
          then (Sail.BitVec.extractLsb (PolynomialMult element1 element2) (esize -i 1) 0)
          else (integer_subrange ((BitVec.toNat element1) *i (BitVec.toNat element2)) (esize -i 1) 0)
        let result ← (Elem_set result e esize product)
        (pure (element1, element2, product, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_mul_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((U == 1#1) && (size != 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let poly : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_product d datasize elements esize m n poly)

def decode_pmul_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((U == 1#1) && (size != 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let poly : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_product d datasize elements esize m n poly)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_int (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (pure (BitVec.toNat (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toNat (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let product : (BitVec esize) := (integer_subrange (element1 *i element2) (esize -i 1) 0)
        let result ← (Elem_set result e esize product)
        (pure (element1, product, result))
    (pure loop_vars) ) : SailM (Int × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_mul_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_int d datasize elements esize idxdsize index m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_not (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (Complement.complement element))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_not_advsimd_aarch64_instrs_vector_arithmetic_unary_not (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_not d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_poly (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (Elem_set result e (2 *i esize) (PolynomialMult element1 element2))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_pmull_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_mul_poly (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b01#2) || (size == 0b10#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((←((pure (size == 0b11#2)) <&&> (do
       (pure (! (← (HaveBit128PMULLExt ()))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_poly d datasize elements esize m n part)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_single_general_immediate_unsigned (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (regsize : Nat) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (if ((bne memop MemOp_PREFETCH) : Bool)
          then (do (CheckSPAlignment ()))
          else (do (pure ())))
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) false t (regsize == 64) false)
        else ()
      (Mem_set address (Int.ediv datasize 8) accdesc data))
  | .MemOp_LOAD =>
    (do
      let _ : Unit :=
        if ((! wback) : Bool)
        then (AArch64_SetLSInstructionSyndrome (Int.ediv datasize 8) is_signed t (regsize == 64) false)
        else ()
      let data ← (( do (Mem_read address (Int.ediv datasize 8) accdesc) ) : SailM (BitVec datasize) )
      (if (is_signed : Bool)
      then
        (do sail_assert ((datasize >b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:38562.72-38562.73"
            (X_set t regsize (sign_extend data regsize)))
      else
        (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:38565.73-38565.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | .MemOp_PREFETCH => (Prefetch address (integer_subrange t 4 0))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_prfm_imm_aarch64_instrs_memory_single_general_immediate_unsigned (Rt : (BitVec 5)) (Rn : (BitVec 5)) (imm12 : (BitVec 12)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let scale := (BitVec.toNat size)
  let offset : (BitVec 64) := ((Sail.BitVec.zeroExtend imm12 64) <<< scale)
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let nontemporal : Bool := false
  let memop ← (( do (undefined_MemOp ()) ) : SailM MemOp )
  let is_signed ← (( do (undefined_bool ()) ) : SailM Bool )
  let regsize : Int := 32
  let (is_signed, memop, regsize) ← (( do
    (if ((((BitVec.access opc 1) : BitVec 1) == 0#1) : Bool)
    then
      (do let memop : MemOp :=
            if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
            then MemOp_LOAD
            else MemOp_STORE
          let regsize : Int :=
            if ((size == 0b11#2) : Bool)
            then 64
            else 32
          let is_signed : Bool := false
          (pure (is_signed, memop, regsize)))
    else
      (do let (is_signed, memop, regsize) ← (( do
            (if ((size == 0b11#2) : Bool)
            then
              (do let memop : MemOp := MemOp_PREFETCH
                  (if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  (pure (is_signed, memop, regsize)))
            else
              (do let memop : MemOp := MemOp_LOAD
                  (if (((size == 0b10#2) && (((BitVec.access opc 0) : BitVec 1) == 1#1)) : Bool)
                  then (do sailThrow ((Error_Undefined ())))
                  else (do (pure ())))
                  let regsize : Int :=
                    if ((((BitVec.access opc 0) : BitVec 1) == 1#1) : Bool)
                    then 32
                    else 64
                  let is_signed : Bool := true
                  (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
          (pure (is_signed, memop, regsize)))) ) : SailM (Bool × MemOp × Int) )
  let regsize := regsize
  let datasize := (Int.shiftl 8 scale)
  let tagchecked : Bool := ((bne memop MemOp_PREFETCH) && (wback || (n != 31)))
  let wb_unknown : Bool := false
  let rt_unknown : Bool := false
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let (c, wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (ConstrainUnpredictable Unpredictable_WBOVERLAPLD)
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:38632.113-38632.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (c, wb_unknown, wback)))
    else (do (pure (c, wb_unknown, wback)))) ) : SailM (Constraint × Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && (n == t)) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:38651.107-38651.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  (execute_aarch64_instrs_memory_single_general_immediate_unsigned datasize memop n nontemporal offset postindex regsize rt_unknown is_signed t tagchecked wb_unknown wback)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3_rax1 (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vm ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let Vn ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  (V_set d 128 (Vn ^^^ ((← (ROL (Sail.BitVec.extractLsb Vm 127 64) 1)) +++ (← (ROL (Sail.BitVec.extractLsb Vm 63 0) 1)))))

def decode_rax1_advsimd_aarch64_instrs_vector_crypto_sha3_rax1 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA3Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha3_rax1 d m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ esize = 8 ∧ List.elem elements [8, 16] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_rbit (d : Nat) (datasize : Nat) (elements : Nat) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let rev ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result, rev) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, rev)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, rev) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let rev ← (( do
          let loop_i_lower := 0
          let loop_i_upper := (esize -i 1)
          let mut loop_vars_1 := rev
          for i in [loop_i_lower:loop_i_upper:1]i do
            let rev := loop_vars_1
            loop_vars_1 := (BitVec.update rev ((esize -i 1) -i i) (Bit ((BitVec.access element i) : BitVec 1)))
          (pure loop_vars_1) ) : SailM (BitVec esize) )
        let result ← (Elem_set result e esize rev)
        (pure (element, result, rev))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize) × (BitVec esize)) )
  (V_set d datasize result)

def decode_rbit_advsimd_aarch64_instrs_vector_arithmetic_unary_rbit (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := 8
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize 8)
  (execute_aarch64_instrs_vector_arithmetic_unary_rbit d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_rbit (d : Nat) (datasize : Nat) (n : Nat) : SailM Unit := do
  let operand ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (datasize -i 1)
    let mut loop_vars := result
    for i in [loop_i_lower:loop_i_upper:1]i do
      let result := loop_vars
      loop_vars := (BitVec.update result ((datasize -i 1) -i i) (Bit ((BitVec.access operand i) : BitVec 1)))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (X_set d datasize result)

def decode_rbit_int_aarch64_instrs_integer_arithmetic_rbit (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  (execute_aarch64_instrs_integer_arithmetic_rbit d datasize n)

/-- Type quantifiers: container_size : Nat, d : Nat, datasize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 ∧ List.elem container_size [16, 32, 64] -/
def execute_aarch64_instrs_integer_arithmetic_rev (container_size : Nat) (d : Nat) (datasize : Nat) (n : Nat) : SailM Unit := do
  let operand ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size 8)
  let index : Int := 0
  let rev_index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, result, rev_index) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := (containers -i 1)
    let mut loop_vars := (index, result, rev_index)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (index, result, rev_index) := loop_vars
      loop_vars ← do
        let rev_index : Int := (index +i ((elements_per_container -i 1) *i 8))
        let (index, result, rev_index) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements_per_container -i 1)
          let mut loop_vars_1 := (index, result, rev_index)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (index, result, rev_index) := loop_vars_1
            loop_vars_1 ← do
              let result ← (( do
                let rev_index := rev_index
                let index := index
                sail_assert ((0 ≤b rev_index) && ((rev_index +i 7) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:39688.83-39688.84"
                sail_assert ((0 ≤b index) && ((index +i 7) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:39689.75-39689.76"
                (pure (Sail.BitVec.updateSubrange result (rev_index +i 7) rev_index (Sail.BitVec.extractLsb operand (index +i 7) index))) ) : SailM (BitVec datasize) )
              let index : Int := (index +i 8)
              let rev_index : Int := (rev_index -i 8)
              (pure (index, result, rev_index))
          (pure loop_vars_1) ) : SailM (Int × (BitVec datasize) × Int) )
        (pure (index, result, rev_index))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Int) )
  (X_set d datasize result)

def decode_rev_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

def decode_rev16_int_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

def decode_rev32_int_aarch64_instrs_integer_arithmetic_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 2)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let container_size : Int := 16
  let container_size ← (( do
    match opc with
    | 0b00 =>
      (do
        (Unreachable ())
        (pure container_size))
    | 0b01 => (pure 16)
    | 0b10 => (pure 32)
    | _ =>
      (do
        (if ((sf == 0#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        (pure 64)) ) : SailM Int )
  let container_size := container_size
  (execute_aarch64_instrs_integer_arithmetic_rev container_size d datasize n)

/-- Type quantifiers: containers : Int, d : Nat, datasize : Nat, elements_per_container : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_rev (containers : Int) (d : Nat) (datasize : Nat) (elements_per_container : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element : Int := 0
  let rev_element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result, rev_element) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := (containers -i 1)
    let mut loop_vars := (element, result, rev_element)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (element, result, rev_element) := loop_vars
      loop_vars ← do
        let rev_element : Int := ((element +i elements_per_container) -i 1)
        let (element, result, rev_element) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements_per_container -i 1)
          let mut loop_vars_1 := (element, result, rev_element)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (element, result, rev_element) := loop_vars_1
            loop_vars_1 ← do
              let result ← (( do
                let rev_element := rev_element
                let element := element
                (Elem_set result rev_element esize (← (Elem_read operand element esize))) ) : SailM (BitVec datasize) )
              let element : Int := (element +i 1)
              let rev_element : Int := (rev_element -i 1)
              (pure (element, result, rev_element))
          (pure loop_vars_1) ) : SailM (Int × (BitVec datasize) × Int) )
        (pure (element, result, rev_element))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Int) )
  (V_set d datasize result)

def decode_rev16_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

def decode_rev32_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

def decode_rev64_advsimd_aarch64_instrs_vector_arithmetic_unary_rev (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o0 : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let op : (BitVec 2) := (o0 +++ U)
  (if ((((BitVec.toNat op) +i (BitVec.toNat size)) ≥b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let container_size : Int := 16
  let container_size : Int :=
    match op with
    | 0b10 => 16
    | 0b01 => 32
    | 0b00 => 64
    | _ => container_size
  let container_size := container_size
  let containers := (Int.ediv datasize container_size)
  let elements_per_container := (Int.ediv container_size esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_rev containers d datasize elements_per_container esize n)

/-- Type quantifiers: m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 -/
def execute_aarch64_instrs_memory_single_general_range (m : Nat) (n : Nat) (operation : (BitVec 6)) : SailM Unit := do
  let address ← (( do
    (if ((n == 31) : Bool)
    then (do (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let metadata ← (( do (X_read m 64) ) : SailM (BitVec 64) )
  let stride := (BitVec.toInt (Sail.BitVec.extractLsb metadata 59 38))
  let count := ((BitVec.toNat (Sail.BitVec.extractLsb metadata 37 22)) +i 1)
  let length := (BitVec.toInt (Sail.BitVec.extractLsb metadata 21 0))
  let reuse ← (( do (undefined_int ()) ) : SailM Int )
  let reuse : Int :=
    if (((Sail.BitVec.extractLsb metadata 63 60) == 0b0000#4) : Bool)
    then (Neg.neg 1)
    else (Int.shiftl 32768 (15 -i (BitVec.toNat (Sail.BitVec.extractLsb metadata 63 60))))
  let reuse := reuse
  (pure (Hint_RangePrefetch address length stride count reuse operation))

def decode_rprfm_reg_aarch64_instrs_memory_single_general_range (Rt : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (option_name : (BitVec 3)) (Rm : (BitVec 5)) (opc : (BitVec 2)) (size : (BitVec 2)) : SailM Unit := do
  let operation : (BitVec 6) := (((((BitVec.access option_name 2) : BitVec 1) +++ ((BitVec.access option_name 0) : BitVec 1)) +++ S) +++ (Sail.BitVec.extractLsb Rt 2 0))
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_memory_single_general_range m n operation)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_logical (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (BitVec.toNat (← (Elem_read operand e (2 *i esize)))) shift round) ) : SailM Int )
        let result ← (Elem_set result e esize (integer_subrange element (esize -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize)) )
  (Vpart_set d part datasize result)

def decode_rshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_logical (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:40070.51-40070.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_logical d datasize elements esize n part round shift)

def decode_shrn_advsimd_aarch64_instrs_vector_shift_right_narrow_logical (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:40102.51-40102.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_logical d datasize elements esize n part round shift)

/-- Type quantifiers: k_accumulate : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_diff (accumulate : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let absdiff ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let result ← (( do
    (if (accumulate : Bool)
    then (do (V_read d datasize))
    else (do (pure (Zeros (n := datasize))))) ) : SailM (BitVec datasize) )
  let (absdiff, element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (absdiff, element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (absdiff, element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let absdiff : (BitVec esize) := (integer_subrange (Int.natAbs (element1 -i element2)) (esize -i 1) 0)
        let result ← (Elem_set result e esize ((← (Elem_read result e esize)) + absdiff))
        (pure (absdiff, element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × Int × Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_saba_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let accumulate : Bool := (ac == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_diff accumulate d datasize elements esize m n is_unsigned)

def decode_sabd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let accumulate : Bool := (ac == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_diff accumulate d datasize elements esize m n is_unsigned)

def decode_uaba_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let accumulate : Bool := (ac == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_diff accumulate d datasize elements esize m n is_unsigned)

def decode_uabd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (ac : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let accumulate : Bool := (ac == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_diff accumulate d datasize elements esize m n is_unsigned)

/-- Type quantifiers: k_accumulate : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_diff (accumulate : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let absdiff ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let result ← (( do
    (if (accumulate : Bool)
    then (do (V_read d (2 *i datasize)))
    else (do (pure (Zeros (n := (2 *i datasize)))))) ) : SailM (BitVec (2 * datasize)) )
  let (absdiff, element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (absdiff, element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (absdiff, element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let absdiff : (BitVec (2 * esize)) := (integer_subrange (Int.natAbs (element1 -i element2)) ((2 *i esize) -i 1) 0)
        let result ← (Elem_set result e (2 *i esize) ((← (Elem_read result e (2 *i esize))) + absdiff))
        (pure (absdiff, element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × Int × Int × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_sabdl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let accumulate : Bool := (op == 0#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_diff accumulate d datasize elements esize m n part is_unsigned)

def decode_uabal_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let accumulate : Bool := (op == 0#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_diff accumulate d datasize elements esize m n part is_unsigned)

def decode_uabdl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_diff (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let accumulate : Bool := (op == 0#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_diff accumulate d datasize elements esize m n part is_unsigned)

/-- Type quantifiers: k_acc : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_add_pairwise (acc : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let sum ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let op1 ← (( do (undefined_int ()) ) : SailM Int )
  let op2 ← (( do (undefined_int ()) ) : SailM Int )
  let result ← (( do
    (if (acc : Bool)
    then (do (V_read d datasize))
    else (do (pure result))) ) : SailM (BitVec datasize) )
  let (op1, op2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (op1, op2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (op1, op2, result, sum) := loop_vars
      loop_vars ← do
        let op1 ← (( (asl_Int (← (Elem_read operand ((2 *i e) +i 0) esize)) is_unsigned) ) : SailM Int )
        let op2 ← (( (asl_Int (← (Elem_read operand ((2 *i e) +i 1) esize)) is_unsigned) ) : SailM Int )
        let sum : (BitVec (2 * esize)) := (integer_subrange (op1 +i op2) ((2 *i esize) -i 1) 0)
        let result ← (( do
          (if (acc : Bool)
          then (do (Elem_set result e (2 *i esize) ((← (Elem_read result e (2 *i esize))) + sum)))
          else (do (Elem_set result e (2 *i esize) sum))) ) : SailM (BitVec datasize) )
        (pure (op1, op2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × (BitVec (2 * esize))) )
  (V_set d datasize result)

def decode_sadalp_advsimd_aarch64_instrs_vector_arithmetic_unary_add_pairwise (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize (2 *i esize))
  let acc : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_pairwise acc d datasize elements esize n is_unsigned)

def decode_saddlp_advsimd_aarch64_instrs_vector_arithmetic_unary_add_pairwise (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize (2 *i esize))
  let acc : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_pairwise acc d datasize elements esize n is_unsigned)

def decode_uadalp_advsimd_aarch64_instrs_vector_arithmetic_unary_add_pairwise (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize (2 *i esize))
  let acc : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_pairwise acc d datasize elements esize n is_unsigned)

def decode_uaddlp_advsimd_aarch64_instrs_vector_arithmetic_unary_add_pairwise (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize (2 *i esize))
  let acc : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_add_pairwise acc d datasize elements esize n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int :=
          if (sub_op : Bool)
          then (element1 -i element2)
          else (element1 +i element2)
        let result ← (Elem_set result e (2 *i esize) (integer_subrange sum ((2 *i esize) -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * datasize)) × Int) )
  (V_set d (2 *i datasize) result)

def decode_saddl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long d datasize elements esize m n part sub_op is_unsigned)

def decode_ssubl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long d datasize elements esize m n part sub_op is_unsigned)

def decode_uaddl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long d datasize elements esize m n part sub_op is_unsigned)

def decode_usubl_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_long d datasize elements esize m n part sub_op is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_add_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let sum ← (( do (asl_Int (← (Elem_read operand 0 esize)) is_unsigned) ) : SailM Int )
  let sum ← (( do
    let loop_e_lower := 1
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := sum
    for e in [loop_e_lower:loop_e_upper:1]i do
      let sum := loop_vars
      loop_vars ← do (pure (sum +i (← (asl_Int (← (Elem_read operand e esize)) is_unsigned))))
    (pure loop_vars) ) : SailM Int )
  let sum := sum
  (V_set d (2 *i esize) (integer_subrange sum ((2 *i esize) -i 1) 0))

def decode_saddlv_advsimd_aarch64_instrs_vector_reduce_add_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_reduce_add_long d datasize elements esize n is_unsigned)

def decode_uaddlv_advsimd_aarch64_instrs_vector_reduce_add_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_reduce_add_long d datasize elements esize n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e (2 *i esize))) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int :=
          if (sub_op : Bool)
          then (element1 -i element2)
          else (element1 +i element2)
        let result ← (Elem_set result e (2 *i esize) (integer_subrange sum ((2 *i esize) -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * datasize)) × Int) )
  (V_set d (2 *i datasize) result)

def decode_saddw_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide d datasize elements esize m n part sub_op is_unsigned)

def decode_ssubw_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide d datasize elements esize m n part sub_op is_unsigned)

def decode_uaddw_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide d datasize elements esize m n part sub_op is_unsigned)

def decode_usubw_advsimd_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_add_sub_wide d datasize elements esize m n part sub_op is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, fracbits : Int, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_conv_int_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (fracbits : Int) (n : Nat) (rounding : FPRounding) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FixedToFP element fracbits is_unsigned fpcr rounding esize)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_scvtf_advsimd_fix_aarch64_instrs_vector_shift_conv_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize := esize
  let elements := 1
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding ← (( do (FPRoundingMode (← (FPCR_read ()))) ) : SailM FPRounding )
  (execute_aarch64_instrs_vector_shift_conv_int_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_scvtf_advsimd_fix_aarch64_instrs_vector_shift_conv_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding ← (( do (FPRoundingMode (← (FPCR_read ()))) ) : SailM FPRounding )
  (execute_aarch64_instrs_vector_shift_conv_int_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_ucvtf_advsimd_fix_aarch64_instrs_vector_shift_conv_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize := esize
  let elements := 1
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding ← (( do (FPRoundingMode (← (FPCR_read ()))) ) : SailM FPRounding )
  (execute_aarch64_instrs_vector_shift_conv_int_sisd d datasize elements esize fracbits n rounding is_unsigned)

def decode_ucvtf_advsimd_fix_aarch64_instrs_vector_shift_conv_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((let b__0 := immh
       if (((Sail.BitVec.extractLsb b__0 3 1) == (0b000#3 : (BitVec 3))) : Bool)
       then true
       else false : Bool) || ((let b__1 := immh
         if (((Sail.BitVec.extractLsb b__1 3 1) == (0b001#3 : (BitVec 3))) : Bool)
         then true
         else false : Bool) && (! (HaveFP16Ext ())))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize :=
    if ((let b__3 := immh
       if (((Sail.BitVec.extractLsb b__3 3 3) == (1#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then 64
    else
      (if ((let b__2 := immh
         if (((Sail.BitVec.extractLsb b__2 3 2) == (0b01#2 : (BitVec 2))) : Bool)
         then true
         else false : Bool) : Bool)
      then 32
      else 16)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let fracbits := ((esize *i 2) -i (BitVec.toNat (immh +++ immb)))
  let is_unsigned : Bool := (U == 1#1)
  let rounding ← (( do (FPRoundingMode (← (FPCR_read ()))) ) : SailM FPRounding )
  (execute_aarch64_instrs_vector_shift_conv_int_sisd d datasize elements esize fracbits n rounding is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_int_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FixedToFP element 0 is_unsigned fpcr rounding esize)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_scvtf_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_int_sisd d datasize elements esize n is_unsigned)

def decode_scvtf_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_int_sisd d datasize elements esize n is_unsigned)

def decode_ucvtf_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_int_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_int_sisd d datasize elements esize n is_unsigned)

def decode_ucvtf_advsimd_int_aarch64_instrs_vector_arithmetic_unary_float_conv_int_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_conv_int_sisd d datasize elements esize n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_div (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result ← (( do
    (if ((IsZero operand2) : Bool)
    then (do (pure 0))
    else (do (pure (RoundTowardsZero (div_real (to_real (← (asl_Int operand1 is_unsigned))) (to_real (← (asl_Int operand2 is_unsigned)))))))) ) : SailM Int )
  let result := result
  (X_set d datasize (integer_subrange result (datasize -i 1) 0))

def decode_sdiv_aarch64_instrs_integer_arithmetic_div (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let is_unsigned : Bool := (o1 == 0#1)
  (execute_aarch64_instrs_integer_arithmetic_div d datasize m n is_unsigned)

def decode_udiv_aarch64_instrs_integer_arithmetic_div (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (sf : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let datasize :=
    if ((sf == 1#1) : Bool)
    then 64
    else 32
  let is_unsigned : Bool := (o1 == 0#1)
  (execute_aarch64_instrs_integer_arithmetic_div d datasize m n is_unsigned)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_choose (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let x ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read n 32) ) : SailM (BitVec 32) )
  let w ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let t ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (t, x, y) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (t, x, y)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (t, x, y) := loop_vars
      loop_vars ← do
        let t : (BitVec 32) := (SHAchoose (Sail.BitVec.extractLsb x 63 32) (Sail.BitVec.extractLsb x 95 64) (Sail.BitVec.extractLsb x 127 96))
        let y ← (pure (((y + (← (ROL (Sail.BitVec.extractLsb x 31 0) 5))) + t) + (← (Elem_read w e 32))))
        let x ← (pure (Sail.BitVec.updateSubrange x 63 32 (← (ROL (Sail.BitVec.extractLsb x 63 32) 30))))
        let split_vec ← do (ROL (y +++ x) 32)
        let y : (BitVec 32) := (Sail.BitVec.extractLsb split_vec 159 128)
        let x : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 127 0)
        (pure (t, x, y))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 128) × (BitVec 32)) )
  (V_set d 128 x)

def decode_sha1c_advsimd_aarch64_instrs_vector_crypto_sha3op_sha1_hash_choose (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_choose d m n)

/-- Type quantifiers: d : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha2op_sha1_hash (d : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand ← (( do (V_read n 32) ) : SailM (BitVec 32) )
  (V_set d 32 (← (ROL operand 30)))

def decode_sha1h_advsimd_aarch64_instrs_vector_crypto_sha2op_sha1_hash (Rd : (BitVec 5)) (Rn : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha2op_sha1_hash d n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_majority (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let x ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read n 32) ) : SailM (BitVec 32) )
  let w ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let t ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (t, x, y) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (t, x, y)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (t, x, y) := loop_vars
      loop_vars ← do
        let t : (BitVec 32) := (SHAmajority (Sail.BitVec.extractLsb x 63 32) (Sail.BitVec.extractLsb x 95 64) (Sail.BitVec.extractLsb x 127 96))
        let y ← (pure (((y + (← (ROL (Sail.BitVec.extractLsb x 31 0) 5))) + t) + (← (Elem_read w e 32))))
        let x ← (pure (Sail.BitVec.updateSubrange x 63 32 (← (ROL (Sail.BitVec.extractLsb x 63 32) 30))))
        let split_vec ← do (ROL (y +++ x) 32)
        let y : (BitVec 32) := (Sail.BitVec.extractLsb split_vec 159 128)
        let x : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 127 0)
        (pure (t, x, y))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 128) × (BitVec 32)) )
  (V_set d 128 x)

def decode_sha1m_advsimd_aarch64_instrs_vector_crypto_sha3op_sha1_hash_majority (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_majority d m n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_parity (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let x ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read n 32) ) : SailM (BitVec 32) )
  let w ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let t ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (t, x, y) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (t, x, y)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (t, x, y) := loop_vars
      loop_vars ← do
        let t : (BitVec 32) := (SHAparity (Sail.BitVec.extractLsb x 63 32) (Sail.BitVec.extractLsb x 95 64) (Sail.BitVec.extractLsb x 127 96))
        let y ← (pure (((y + (← (ROL (Sail.BitVec.extractLsb x 31 0) 5))) + t) + (← (Elem_read w e 32))))
        let x ← (pure (Sail.BitVec.updateSubrange x 63 32 (← (ROL (Sail.BitVec.extractLsb x 63 32) 30))))
        let split_vec ← do (ROL (y +++ x) 32)
        let y : (BitVec 32) := (Sail.BitVec.extractLsb split_vec 159 128)
        let x : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 127 0)
        (pure (t, x, y))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 128) × (BitVec 32)) )
  (V_set d 128 x)

def decode_sha1p_advsimd_aarch64_instrs_vector_crypto_sha3op_sha1_hash_parity (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha3op_sha1_hash_parity d m n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha1_sched0 (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand1 ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let operand2 ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let operand3 ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let result : (BitVec 128) := ((Sail.BitVec.extractLsb operand2 63 0) +++ (Sail.BitVec.extractLsb operand1 127 64))
  let result : (BitVec 128) := ((result ^^^ operand1) ^^^ operand3)
  (V_set d 128 result)

def decode_sha1su0_advsimd_aarch64_instrs_vector_crypto_sha3op_sha1_sched0 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha3op_sha1_sched0 d m n)

/-- Type quantifiers: d : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha2op_sha1_sched1 (d : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand1 ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let operand2 ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let result ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let T : (BitVec 128) := (operand1 ^^^ (operand2 >>> 32))
  let result ← (pure (Sail.BitVec.updateSubrange result 31 0 (← (ROL (Sail.BitVec.extractLsb T 31 0) 1))))
  let result ← (pure (Sail.BitVec.updateSubrange result 63 32 (← (ROL (Sail.BitVec.extractLsb T 63 32) 1))))
  let result ← (pure (Sail.BitVec.updateSubrange result 95 64 (← (ROL (Sail.BitVec.extractLsb T 95 64) 1))))
  let result ← (pure (Sail.BitVec.updateSubrange result 127 96 ((← (ROL (Sail.BitVec.extractLsb T 127 96) 1)) ^^^ (← (ROL (Sail.BitVec.extractLsb T 31 0) 2)))))
  (V_set d 128 result)

def decode_sha1su1_advsimd_aarch64_instrs_vector_crypto_sha2op_sha1_sched1 (Rd : (BitVec 5)) (Rn : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveSHA1Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha2op_sha1_sched1 d n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, k_part1 : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha256_hash (d : Nat) (m : Nat) (n : Nat) (part1 : Bool) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let result ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let result ← (( do
    (if (part1 : Bool)
    then (do (SHA256hash (← (V_read d 128)) (← (V_read n 128)) (← (V_read m 128)) true))
    else (do (SHA256hash (← (V_read n 128)) (← (V_read d 128)) (← (V_read m 128)) false))) ) : SailM (BitVec 128) )
  (V_set d 128 result)

def decode_sha256h_advsimd_aarch64_instrs_vector_crypto_sha3op_sha256_hash (Rd : (BitVec 5)) (Rn : (BitVec 5)) (P : (BitVec 1)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA256Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let part1 : Bool := (P == 0#1)
  (execute_aarch64_instrs_vector_crypto_sha3op_sha256_hash d m n part1)

def decode_sha256h2_advsimd_aarch64_instrs_vector_crypto_sha3op_sha256_hash (Rd : (BitVec 5)) (Rn : (BitVec 5)) (P : (BitVec 1)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA256Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let part1 : Bool := (P == 0#1)
  (execute_aarch64_instrs_vector_crypto_sha3op_sha256_hash d m n part1)

/-- Type quantifiers: d : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha2op_sha256_sched0 (d : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand1 ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let operand2 ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let result ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let T : (BitVec 128) := ((Sail.BitVec.extractLsb operand2 31 0) +++ (Sail.BitVec.extractLsb operand1 127 32))
  let elt ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (elt, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (elt, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (elt, result) := loop_vars
      loop_vars ← do
        let elt ← (Elem_read T e 32)
        let elt : (BitVec 32) := (((ROR elt 7) ^^^ (ROR elt 18)) ^^^ (elt >>> 3))
        let result ← (Elem_set result e 32 (elt + (← (Elem_read operand1 e 32))))
        (pure (elt, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 128)) )
  (V_set d 128 result)

def decode_sha256su0_advsimd_aarch64_instrs_vector_crypto_sha2op_sha256_sched0 (Rd : (BitVec 5)) (Rn : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((! (← (HaveSHA256Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha2op_sha256_sched0 d n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha3op_sha256_sched1 (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let operand1 ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let operand2 ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let operand3 ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let result ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let T0 : (BitVec 128) := ((Sail.BitVec.extractLsb operand3 31 0) +++ (Sail.BitVec.extractLsb operand2 127 32))
  let elt ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let T1 : (BitVec 64) := (Sail.BitVec.extractLsb operand3 127 64)
  let (elt, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 1
    let mut loop_vars := (elt, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (elt, result) := loop_vars
      loop_vars ← do
        let elt ← (Elem_read T1 e 32)
        let elt : (BitVec 32) := (((ROR elt 17) ^^^ (ROR elt 19)) ^^^ (elt >>> 10))
        let elt ← (pure ((elt + (← (Elem_read operand1 e 32))) + (← (Elem_read T0 e 32))))
        let result ← (Elem_set result e 32 elt)
        (pure (elt, result))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 128)) )
  let T1 : (BitVec 64) := (Sail.BitVec.extractLsb result 63 0)
  let (elt, result) ← (( do
    let loop_e_lower := 2
    let loop_e_upper := 3
    let mut loop_vars_1 := (elt, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (elt, result) := loop_vars_1
      loop_vars_1 ← do
        let elt ← (Elem_read T1 (e -i 2) 32)
        let elt : (BitVec 32) := (((ROR elt 17) ^^^ (ROR elt 19)) ^^^ (elt >>> 10))
        let elt ← (pure ((elt + (← (Elem_read operand1 e 32))) + (← (Elem_read T0 e 32))))
        let result ← (Elem_set result e 32 elt)
        (pure (elt, result))
    (pure loop_vars_1) ) : SailM ((BitVec 32) × (BitVec 128)) )
  (V_set d 128 result)

def decode_sha256su1_advsimd_aarch64_instrs_vector_crypto_sha3op_sha256_sched1 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((! (← (HaveSHA256Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_crypto_sha3op_sha256_sched1 d m n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha512_sha512h (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vtmp ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let x ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let w ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let MSigma1 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb y 127 64) 14) ^^^ (ROR (Sail.BitVec.extractLsb y 127 64) 18)) ^^^ (ROR (Sail.BitVec.extractLsb y 127 64) 41))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 (((Sail.BitVec.extractLsb y 127 64) &&& (Sail.BitVec.extractLsb x 63 0)) ^^^ ((Complement.complement (Sail.BitVec.extractLsb y 127 64)) &&& (Sail.BitVec.extractLsb x 127 64))))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 (((Sail.BitVec.extractLsb Vtmp 127 64) + MSigma1) + (Sail.BitVec.extractLsb w 127 64)))
  let tmp : (BitVec 64) := ((Sail.BitVec.extractLsb Vtmp 127 64) + (Sail.BitVec.extractLsb y 63 0))
  let MSigma1 : (BitVec 64) := (((ROR tmp 14) ^^^ (ROR tmp 18)) ^^^ (ROR tmp 41))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 ((tmp &&& (Sail.BitVec.extractLsb y 127 64)) ^^^ ((Complement.complement tmp) &&& (Sail.BitVec.extractLsb x 63 0))))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 (((Sail.BitVec.extractLsb Vtmp 63 0) + MSigma1) + (Sail.BitVec.extractLsb w 63 0)))
  (V_set d 128 Vtmp)

def decode_sha512h_advsimd_aarch64_instrs_vector_crypto_sha512_sha512h (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA512Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha512_sha512h d m n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha512_sha512h2 (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vtmp ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let x ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let w ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let NSigma0 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb y 63 0) 28) ^^^ (ROR (Sail.BitVec.extractLsb y 63 0) 34)) ^^^ (ROR (Sail.BitVec.extractLsb y 63 0) 39))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 ((((Sail.BitVec.extractLsb x 63 0) &&& (Sail.BitVec.extractLsb y 127 64)) ^^^ ((Sail.BitVec.extractLsb x 63 0) &&& (Sail.BitVec.extractLsb y 63 0))) ^^^ ((Sail.BitVec.extractLsb y 127 64) &&& (Sail.BitVec.extractLsb y 63 0))))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 (((Sail.BitVec.extractLsb Vtmp 127 64) + NSigma0) + (Sail.BitVec.extractLsb w 127 64)))
  let NSigma0 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb Vtmp 127 64) 28) ^^^ (ROR (Sail.BitVec.extractLsb Vtmp 127 64) 34)) ^^^ (ROR (Sail.BitVec.extractLsb Vtmp 127 64) 39))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 ((((Sail.BitVec.extractLsb Vtmp 127 64) &&& (Sail.BitVec.extractLsb y 63 0)) ^^^ ((Sail.BitVec.extractLsb Vtmp 127 64) &&& (Sail.BitVec.extractLsb y 127 64))) ^^^ ((Sail.BitVec.extractLsb y 127 64) &&& (Sail.BitVec.extractLsb y 63 0))))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 (((Sail.BitVec.extractLsb Vtmp 63 0) + NSigma0) + (Sail.BitVec.extractLsb w 63 0)))
  (V_set d 128 Vtmp)

def decode_sha512h2_advsimd_aarch64_instrs_vector_crypto_sha512_sha512h2 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA512Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha512_sha512h2 d m n)

/-- Type quantifiers: d : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha512_sha512su0 (d : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vtmp ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let x ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let w ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let sig0 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb w 127 64) 1) ^^^ (ROR (Sail.BitVec.extractLsb w 127 64) 8)) ^^^ (0b0000000#7 +++ (Sail.BitVec.extractLsb w 127 71)))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 ((Sail.BitVec.extractLsb w 63 0) + sig0))
  let sig0 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb x 63 0) 1) ^^^ (ROR (Sail.BitVec.extractLsb x 63 0) 8)) ^^^ (0b0000000#7 +++ (Sail.BitVec.extractLsb x 63 7)))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 ((Sail.BitVec.extractLsb w 127 64) + sig0))
  (V_set d 128 Vtmp)

def decode_sha512su0_advsimd_aarch64_instrs_vector_crypto_sha512_sha512su0 (Rd : (BitVec 5)) (Rn : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA512Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (execute_aarch64_instrs_vector_crypto_sha512_sha512su0 d n)

/-- Type quantifiers: d : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_crypto_sha512_sha512su1 (d : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (AArch64_CheckFPAdvSIMDEnabled ())
  let Vtmp ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let x ← (( do (V_read n 128) ) : SailM (BitVec 128) )
  let y ← (( do (V_read m 128) ) : SailM (BitVec 128) )
  let w ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let sig1 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb x 127 64) 19) ^^^ (ROR (Sail.BitVec.extractLsb x 127 64) 61)) ^^^ (0b000000#6 +++ (Sail.BitVec.extractLsb x 127 70)))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 127 64 (((Sail.BitVec.extractLsb w 127 64) + sig1) + (Sail.BitVec.extractLsb y 127 64)))
  let sig1 : (BitVec 64) := (((ROR (Sail.BitVec.extractLsb x 63 0) 19) ^^^ (ROR (Sail.BitVec.extractLsb x 63 0) 61)) ^^^ (0b000000#6 +++ (Sail.BitVec.extractLsb x 63 6)))
  let Vtmp : (BitVec 128) := (Sail.BitVec.updateSubrange Vtmp 63 0 (((Sail.BitVec.extractLsb w 63 0) + sig1) + (Sail.BitVec.extractLsb y 63 0)))
  (V_set d 128 Vtmp)

def decode_sha512su1_advsimd_aarch64_instrs_vector_crypto_sha512_sha512su1 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) : SailM Unit := do
  (if ((! (← (HaveSHA512Ext ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (execute_aarch64_instrs_vector_crypto_sha512_sha512su1 d m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_truncating (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int := (Int.shiftr (element1 +i element2) 1)
        let result ← (Elem_set result e esize (integer_subrange sum (esize -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Int) )
  (V_set d datasize result)

def decode_shadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_truncating (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_truncating d datasize elements esize m n is_unsigned)

def decode_uhadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_truncating (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_truncating d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Int, elements : Int, esize : Int, n : Nat, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_sisd (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:42840.56-42840.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let result ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := result
    for e in [loop_e_lower:loop_e_upper:1]i do
      let result := loop_vars
      loop_vars ← do
        sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:42844.38-42844.39"
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:42845.179-42845.180"
        (Elem_set result e esize ((← (Elem_read operand e esize)) <<< shift))
    (pure loop_vars) ) : SailM (BitVec datasize) )
  (V_set d datasize result)


end ArmASL.Functions
