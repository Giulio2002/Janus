import ArmASL.Part04

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: idx : Int, increment_name : Int -/
def PMUEvent__2 (pmuevent : (BitVec 16)) (increment_name : Int) (idx : Int) : SailM Unit := do
  (if ((! (← (HavePMUv3 ()))) : Bool)
  then (do (pure ()))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then
          (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5380.50-5380.51"
              (if (((_get_PMEVTYPER_Type_evtCount (← (PMEVTYPER_read idx))) == pmuevent) : Bool)
              then (do writeReg PMUEventAccumulator (vectorUpdate (← readReg PMUEventAccumulator) idx ((GetElem?.getElem! (← readReg PMUEventAccumulator) idx) +i increment_name)))
              else (do (pure ()))))
        else
          (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5386.50-5386.51"
              (if (((_get_PMEVTYPER_EL0_Type_evtCount (GetElem?.getElem! (← readReg PMEVTYPER_EL0) idx)) == pmuevent) : Bool)
              then
                (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5388.54-5388.55"
                    writeReg PMUEventAccumulator (vectorUpdate (← readReg PMUEventAccumulator) idx ((GetElem?.getElem! (← readReg PMUEventAccumulator) idx) +i increment_name)))
              else (do (pure ())))))))

/-- Type quantifiers: increment_name : Int -/
def PMUEvent__1 (pmuevent : (BitVec 16)) (increment_name : Int) : SailM Unit := do
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPEEvent pmuevent))
  else (do (pure ())))
  (if ((←((pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 0#1)) <&&> (do
       (pure ((_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2)) == 0#1))))) : Bool)
  then (do (pure ()))
  else
    (do let counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
        (if ((counters != 0) : Bool)
        then
          (do let loop_idx_lower := 0
              let loop_idx_upper := (counters -i 1)
              let mut loop_vars := ()
              for idx in [loop_idx_lower:loop_idx_upper:1]i do
                let () := loop_vars
                loop_vars ← do (PMUEvent__2 pmuevent increment_name idx)
              (pure loop_vars))
        else (do (pure ())))
        (if (((←((HaveAArch64 ()) <&&> (do
               (HavePMUv3ICNTR ())))) && (pmuevent == PMU_EVENT_INST_RETIRED)) : Bool)
        then (do (IncrementInstructionCounter increment_name))
        else (do (pure ())))))

def PMUEvent (pmuevent : (BitVec 16)) : SailM Unit := do
  (PMUEvent__1 pmuevent 1)

def HavePMUv3TH (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3_TH)

/-- Type quantifiers: width : Nat, width ≥ 0 -/
def ConstrainUnpredictableBits (which : Unpredictable) (width : Nat) : SailM (Constraint × (BitVec width)) := do
  (pure ((← (undefined_Constraint ())), (← (undefined_bitvector width))))

def undefined_BRBCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBCR_EL1_Type_E0BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_BRBCR_EL1_Type_E1BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_BRBCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBCR_EL2_Type_E0HBRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_BRBCR_EL2_Type_E2BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_BRBFCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBFCR_EL1_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _get_MDSELR_EL1_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 5 4)

def _get_SPMSELR_EL0_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 1 0)

def _get_BRBFCR_EL1_Type_CONDDIR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_BRBFCR_EL1_Type_DIRCALL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_BRBFCR_EL1_Type_DIRECT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_BRBFCR_EL1_Type_EnI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_BRBFCR_EL1_Type_INDCALL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_BRBFCR_EL1_Type_INDIRECT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_BRBFCR_EL1_Type_PAUSED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_BRBFCR_EL1_Type_RTN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_BRBTS_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTS_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def PhysicalCountInt (_ : Unit) : SailM (BitVec 64) := do
  (pure (Sail.BitVec.extractLsb (← readReg PhysicalCount) 87 24))

def undefined_CNTHCTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHCTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CNTHCTL_EL2_Type_ECV (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CNTHCTL_EL2_Type_EL0PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_CNTKCTL_EL1_Type_EL0PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_CNTHCTL_EL2_Type_EL0VTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_CNTKCTL_EL1_Type_EL0VTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_CNTHCTL_EL2_Type_EL1NVPCT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_CNTHCTL_EL2_Type_EL1NVVCT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_CNTHCTL_EL2_Type_EL1PCEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_CNTHCTL_EL2_Type_EL1PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_CNTHCTL_EL2_Type_EL1TVT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def ImpDefBits (x : String) (N : Nat) : SailM (BitVec N) := do
  (if ((x == "Coresight timestamp") : Bool)
  then
    (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/impdefs.sail:759.54-759.55"
        (pure (Sail.BitVec.extractLsb (← (PhysicalCountInt ())) (N -i 1) 0)))
  else
    (do (if ((x == "Synchronous Error") : Bool)
        then
          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:762.53-762.54"
              (pure (Sail.BitVec.extractLsb 0b00#2 (N -i 1) 0)))
        else
          (do (if ((x == "Asynchronous Error") : Bool)
              then
                (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:765.53-765.54"
                    (pure (Sail.BitVec.extractLsb 0b11#2 (N -i 1) 0)))
              else
                (do (if ((x == "Virtual Asynchronous Abort ExT bit") : Bool)
                    then (do (pure (Zeros (n := N))))
                    else
                      (do (if ((x == "FPEXC.EN value when TGE==1 and RW==0") : Bool)
                          then
                            (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:770.38-770.39"
                                (pure (integer_subrange 1 (N -i 1) 0)))
                          else
                            (do (if ((x == "reset vector address") : Bool)
                                then
                                  (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/impdefs.sail:773.54-773.55"
                                      (pure (Sail.BitVec.extractLsb (← readReg CFG_RVBAR) (N -i 1) 0)))
                                else
                                  (do (if ((x == "TG0 encoded granule size") : Bool)
                                      then
                                        (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:776.53-776.54"
                                            (pure (Sail.BitVec.extractLsb (← readReg __impdef_TG0) (N -i 1) 0)))
                                      else
                                        (do (if ((x == "TG1 encoded granule size") : Bool)
                                            then
                                              (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:779.53-779.54"
                                                  (pure (Sail.BitVec.extractLsb (← readReg __impdef_TG1) (N -i 1) 0)))
                                            else
                                              (do (if ((x == "Reserved short descriptor AP encoding") : Bool)
                                                  then
                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:782.38-782.39"
                                                        (pure (integer_subrange (BitVec.toNat 0b101#3) (N -i 1) 0)))
                                                  else
                                                    (do (if ((x == "Non-Faulting PAR") : Bool)
                                                        then
                                                          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:785.53-785.54"
                                                              (pure (Sail.BitVec.extractLsb 0#1 (N -i 1) 0)))
                                                        else
                                                          (do (if ((x == "Faulting PAR") : Bool)
                                                              then (do (pure (Zeros (n := N))))
                                                              else
                                                                (do (if ((x == "SPE mask 10:8,4,2") : Bool)
                                                                    then
                                                                      (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 5)) "sail-arm/arm-v9.4-a/src/impdefs.sail:790.53-790.54"
                                                                          (pure (Sail.BitVec.extractLsb 0b11111#5 (N -i 1) 0)))
                                                                    else
                                                                      (do (if ((x == "MPAM version") : Bool)
                                                                          then
                                                                            (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:793.38-793.39"
                                                                                (pure (integer_subrange (BitVec.toNat (← readReg __mpam_major)) (N -i 1) 0)))
                                                                          else
                                                                            (do (if ((x == "MPAM maximum PARTID") : Bool)
                                                                                then
                                                                                  (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:796.38-796.39"
                                                                                      (pure (integer_subrange (BitVec.toNat (← readReg __mpam_partid_max)) (N -i 1) 0)))
                                                                                else
                                                                                  (do (if ((x == "MPAM maximum PMG") : Bool)
                                                                                      then
                                                                                        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:799.38-799.39"
                                                                                            (pure (integer_subrange (BitVec.toNat (← readReg __mpam_pmg_max)) (N -i 1) 0)))
                                                                                      else
                                                                                        (do (if ((x == "Has MPAMHCR_EL2") : Bool)
                                                                                            then
                                                                                              (do (if ((← readReg __mpam_has_hcr) : Bool)
                                                                                                  then
                                                                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:803.42-803.43"
                                                                                                        (pure (integer_subrange 1 (N -i 1) 0)))
                                                                                                  else (do (pure (Zeros (n := N))))))
                                                                                            else
                                                                                              (do (if ((x == "MPAM maximum VPMR") : Bool)
                                                                                                  then
                                                                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:807.38-807.39"
                                                                                                        (pure (integer_subrange (BitVec.toNat (← readReg __mpam_vpmr_max)) (N -i 1) 0)))
                                                                                                  else
                                                                                                    (do (if ((x == "SPE mask 63:48") : Bool)
                                                                                                        then (do (pure (Zeros (n := N))))
                                                                                                        else
                                                                                                          (do (if ((x == "SPE mask 31:24") : Bool)
                                                                                                              then (do (pure (Zeros (n := N))))
                                                                                                              else
                                                                                                                (do (if ((x == "SPE mask 15:12") : Bool)
                                                                                                                    then (do (pure (Zeros (n := N))))
                                                                                                                    else
                                                                                                                      (do (if ((x == "SPE EVENTS 63_48") : Bool)
                                                                                                                          then (do (pure (Zeros (n := N))))
                                                                                                                          else
                                                                                                                            (do (if ((x == "SPE EVENTS 31_24") : Bool)
                                                                                                                                then (do (pure (Zeros (n := N))))
                                                                                                                                else
                                                                                                                                  (do (if ((x == "SPE EVENTS 15_12") : Bool)
                                                                                                                                      then (do (pure (Zeros (n := N))))
                                                                                                                                      else
                                                                                                                                        (do (if ((x == "Default Memory Map XNX bit") : Bool)
                                                                                                                                            then
                                                                                                                                              (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:822.38-822.39"
                                                                                                                                                  (pure (integer_subrange 0 (N -i 1) 0)))
                                                                                                                                            else
                                                                                                                                              (do (if ((x == "0") : Bool)
                                                                                                                                                  then
                                                                                                                                                    (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:825.53-825.54"
                                                                                                                                                        (pure (Sail.BitVec.extractLsb 0#1 (N -i 1) 0)))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((x == "1") : Bool)
                                                                                                                                                        then
                                                                                                                                                          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:828.53-828.54"
                                                                                                                                                              (pure (Sail.BitVec.extractLsb 1#1 (N -i 1) 0)))
                                                                                                                                                        else
                                                                                                                                                          (do (if ((x == "IMPDEF ErrorState") : Bool)
                                                                                                                                                              then (do (pure (Zeros (n := N))))
                                                                                                                                                              else
                                                                                                                                                                (do (if ((x == "Virtual External abort type") : Bool)
                                                                                                                                                                    then (do (pure (Zeros (n := N))))
                                                                                                                                                                    else
                                                                                                                                                                      (do (if ((x == "Virtual SError syndrome") : Bool)
                                                                                                                                                                          then (do (pure (Zeros (n := N))))
                                                                                                                                                                          else
                                                                                                                                                                            (do let _ : Unit := (print_endline (String.append x " is not among the strings in the above list."))
                                                                                                                                                                                sail_assert false "sail-arm/arm-v9.4-a/src/impdefs.sail:838.20-838.21"
                                                                                                                                                                                throw Error.Exit))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def __IMPDEF_bits (N : Nat) (x : String) : SailM (BitVec N) := do
  (ImpDefBits x N)

def undefined_EDECR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_EDECR_Type_OSUCE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_CTIDEVCTL_Type_OSUCE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSSCR_EL1_Type_SS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def DLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DLR_Type := value_name
  writeReg DLR_EL0 (Sail.BitVec.updateSubrange (← readReg DLR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _DLR r

def undefined_DSPSR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DSPSR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_ID_PFR0_Type_DIT (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_PAN (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def undefined_DSPSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DSPSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DSPSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DSPSR_Type := value_name
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _DSPSR r

def undefined_DSPSR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DSPSR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DSPSR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DSPSR2_Type := value_name
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _DSPSR2 r

def EDSCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDSCR_Type := value_name
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 29 (BitVec.slice r 29 2))
  writeReg _EDSCR r

def ExternalRealmInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg RLPIDEN) Signal_High)))))

def ExternalRootInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (! (← (HaveSecureEL2Ext ())))) <||> (do (ExternalSecureInvasiveDebugEnabled ()))) <&&> (do (ExternalRealmInvasiveDebugEnabled ())) <&&> (do (pure (BEq.beq (← readReg RTPIDEN) Signal_High)))))

def HaveBRBEv1p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BRBEv1p1)

def BranchRecordAllowed (el : (BitVec 2)) : SailM Bool := do
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBFCR_EL1_Type_PAUSED (← readReg BRBFCR_EL1)) == 1#1) : Bool)
        then (do (pure false))
        else
          (do (if ((←((pure (el == EL3)) <&&> (do
                   (HaveBRBEv1p1 ())))) : Bool)
              then (do (pure ((_get_MDCR_EL3_Type_E3BREC (← readReg MDCR_EL3)) != (_get_MDCR_EL3_Type_E3BREW (← readReg MDCR_EL3)))))
              else
                (do (if ((←((pure (HaveEL EL3)) <&&> (do
                         (pure ((_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3)) == 0b00#2)) <||> (do
                           (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) <&&> (do
                             (pure ((_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3)) == 0b01#2))))))) : Bool)
                    then (do (pure false))
                    else
                      (do let questionMark := el
                          (if ((questionMark == EL3) : Bool)
                          then (do (pure false))
                          else
                            (do (if ((questionMark == EL2) : Bool)
                                then (do (pure ((_get_BRBCR_EL2_Type_E2BRE (← readReg BRBCR_EL2)) == 1#1)))
                                else
                                  (do (if ((questionMark == EL1) : Bool)
                                      then (do (pure ((_get_BRBCR_EL1_Type_E1BRE (← readReg BRBCR_EL1)) == 1#1)))
                                      else
                                        (do (if ((questionMark == EL0) : Bool)
                                            then
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
                                                  then (do (pure ((_get_BRBCR_EL2_Type_E0HBRE (← readReg BRBCR_EL2)) == 1#1)))
                                                  else (do (pure ((_get_BRBCR_EL1_Type_E0BRE (← readReg BRBCR_EL1)) == 1#1)))))
                                            else (do (undefined_bool ())))))))))))))))))

def ELIsInHost (el : (BitVec 2)) : SailM Bool := do
  (if ((←((pure (! (← (HaveVirtHostExt ())))) <||> (do
       (ELUsingAArch32 EL2)))) : Bool)
  then (do (pure false))
  else
    (do let questionMark := el
        (if ((questionMark == EL3) : Bool)
        then (do (pure false))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))
              else
                (do (if ((questionMark == EL1) : Bool)
                    then (do (pure false))
                    else
                      (do (if ((questionMark == EL0) : Bool)
                          then (do (EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))
                          else
                            (do (Unreachable ())
                                (undefined_bool ())))))))))))

def HavePACExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAuth)

def S1TranslationRegime (el : (BitVec 2)) : SailM (BitVec 2) := do
  (if ((el != EL0) : Bool)
  then (do (pure el))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (ELUsingAArch32 EL3)) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
        then (do (pure EL3))
        else
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (ELIsInHost el)))) : Bool)
              then (do (pure EL2))
              else (do (pure EL1)))))))

def S1TranslationRegime__1 (_ : Unit) : SailM (BitVec 2) := do
  (S1TranslationRegime (← readReg PSTATE).EL)

def undefined_TCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL1_Type_A1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _update_TTBCR_Type_A1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _get_TCR_EL2_Type_A1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_TCR_EL1_Type_AS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR_EL2_Type_AS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR_EL1_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_GICD_CTLR_Type_DS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_TCR_EL3_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_VTCR_EL2_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_TCR_EL1_Type_E0PD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_TCR_EL2_Type_E0PD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_TCR_EL1_Type_E0PD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_TCR_EL2_Type_E0PD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_TCR_EL1_Type_EPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_TTBCR_Type_EPD0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_TCR_EL2_Type_EPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_TCR_EL1_Type_EPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _update_TTBCR_Type_EPD1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _get_TCR_EL2_Type_EPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_TCR_EL1_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 39 39)

def _get_TCR_EL3_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_VTCR_EL2_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_TCR_EL1_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 40 40)

def _get_TCR_EL3_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_VTCR_EL2_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_TCR_EL1_Type_HPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_TCR_EL2_Type_HPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_TCR_EL1_Type_HPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR_EL2_Type_HPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR_EL1_Type_IPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 34 32)

def _get_TCR_EL2_Type_IPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 34 32)

def _get_TCR_EL1_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _update_HTCR_Type_IRGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _update_TTBCR_Type_IRGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _get_TCR_EL2_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_TCR_EL3_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_VTCR_EL2_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_TCR_EL1_Type_IRGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _update_TTBCR_Type_IRGN1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 24 x)

def _get_TCR_EL2_Type_IRGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _get_TCR_EL1_Type_MTX0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_TCR_EL2_Type_MTX0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_TCR_EL1_Type_MTX1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_TCR_EL2_Type_MTX1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_TCR_EL1_Type_NFD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_TCR_EL2_Type_NFD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_TCR_EL1_Type_NFD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_TCR_EL2_Type_NFD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_TCR_EL1_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _update_HTCR_Type_ORGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 10 x)

def _update_TTBCR_Type_ORGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 10 x)

def _get_TCR_EL2_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_TCR_EL3_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_VTCR_EL2_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_TCR_EL1_Type_ORGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 27 26)

def _update_TTBCR_Type_ORGN1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 26 x)

def _get_TCR_EL2_Type_ORGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 27 26)

def _get_TCR_EL1_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _update_HTCR_Type_SH0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 12 x)

def _update_TTBCR_Type_SH0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 12 x)

def _get_TCR_EL2_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_TCR_EL3_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_VTCR_EL2_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_TCR_EL1_Type_SH1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _update_TTBCR_Type_SH1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 28 x)

def _get_TCR_EL2_Type_SH1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _get_TCR_EL1_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _update_HTCR_Type_T0SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _update_TTBCR_Type_T0SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _get_TCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_TCR_EL3_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_VSTCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_VTCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_TCR_EL1_Type_T1SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 21 16)

def _update_TTBCR_Type_T1SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 16 x)

def _get_TCR_EL2_Type_T1SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 21 16)

def _get_TCR_EL1_Type_TBI0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR_EL2_Type_TBI0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR_EL1_Type_TBI1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL2_Type_TBI1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL1_Type_TBID0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_TCR_EL2_Type_TBID0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_TCR_EL1_Type_TBID1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_TCR_EL2_Type_TBID1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_TCR_EL1_Type_TCMA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_TCR_EL2_Type_TCMA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_TCR_EL1_Type_TCMA1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_TCR_EL2_Type_TCMA1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_TCR_EL1_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL3_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VSTCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VTCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL1_Type_TG1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_TCR_EL2_Type_TG1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def undefined_TCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL2_Type_HPD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _update_HTCR_Type_HPD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _get_TCR_EL3_Type_HPD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _update_HTCR_Type_HWU59 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _update_HTCR_Type_HWU60 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _update_HTCR_Type_HWU61 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _update_HTCR_Type_HWU62 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_TCR_EL2_Type_MTX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_TCR_EL3_Type_MTX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_TCR_EL2_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_TCR_EL3_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_VTCR_EL2_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_TCR_EL2_Type_TBI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_TCR_EL3_Type_TBI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_TCR_EL2_Type_TBID (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR_EL3_Type_TBID (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR_EL2_Type_TCMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_TCR_EL3_Type_TCMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def undefined_TCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL3_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR2_EL1_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_TCR2_EL2_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_TCR_EL3_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR2_EL1_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_TCR2_EL2_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_VTCR_EL2_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL3_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_TCR2_EL1_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_TCR2_EL2_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_TCR_EL3_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR2_EL1_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_TCR2_EL2_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_VTCR_EL2_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_TCR_EL3_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_TCR2_EL1_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_TCR2_EL2_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_TCR_EL3_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR2_EL1_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_TCR2_EL2_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_TCR_EL3_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_TCR2_EL1_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TCR2_EL2_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

/-- Type quantifiers: k_IsInstr : Bool -/
def EffectiveTBI (address : (BitVec 64)) (IsInstr : Bool) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let tbi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let tbid ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:6080.21-6080.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6082.43-6082.44"
  let (tbi, tbid) ← (( do
    let questionMark := regime
    let (tbi, tbid) ← (( do
      (if ((questionMark == EL1) : Bool)
      then
        (do let tbi ←
              (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
              then (do (pure (_get_TCR_EL1_Type_TBI1 (← readReg TCR_EL1))))
              else (do (pure (_get_TCR_EL1_Type_TBI0 (← readReg TCR_EL1)))))
            let tbid ← (( do
              (if ((← (HavePACExt ())) : Bool)
              then
                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                    then (do (pure (_get_TCR_EL1_Type_TBID1 (← readReg TCR_EL1))))
                    else (do (pure (_get_TCR_EL1_Type_TBID0 (← readReg TCR_EL1))))))
              else (do (pure tbid))) ) : SailM (BitVec 1) )
            (pure (tbi, tbid)))
      else
        (do let (tbi, tbid) ← (( do
              (if ((questionMark == EL2) : Bool)
              then
                (do let (tbi, tbid) ← (( do
                      (if ((←((HaveVirtHostExt ()) <&&> (do
                           (ELIsInHost el)))) : Bool)
                      then
                        (do let tbi ←
                              (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                              then (do (pure (_get_TCR_EL2_Type_TBI1 (← readReg TCR_EL2))))
                              else (do (pure (_get_TCR_EL2_Type_TBI0 (← readReg TCR_EL2)))))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then
                                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                                    then (do (pure (_get_TCR_EL2_Type_TBID1 (← readReg TCR_EL2))))
                                    else (do (pure (_get_TCR_EL2_Type_TBID0 (← readReg TCR_EL2))))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))
                      else
                        (do let tbi ← (pure (_get_TCR_EL2_Type_TBI (← readReg TCR_EL2)))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then (do (pure (_get_TCR_EL2_Type_TBID (← readReg TCR_EL2))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    (pure (tbi, tbid)))
              else
                (do let (tbi, tbid) ← (( do
                      (if ((questionMark == EL3) : Bool)
                      then
                        (do let tbi ← (pure (_get_TCR_EL3_Type_TBI (← readReg TCR_EL3)))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then (do (pure (_get_TCR_EL3_Type_TBID (← readReg TCR_EL3))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))
                      else (do (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
            (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
    (pure (tbi, tbid)) ) : SailM ((BitVec 1) × (BitVec 1)) )
  (if ((←((pure (tbi == 1#1)) <&&> (do
       (pure (((! (← (HavePACExt ()))) || (tbid == 0#1)) || (! IsInstr)))))) : Bool)
  then (do (pure 1#1))
  else (do (pure 0#1)))

/-- Type quantifiers: k_IsInstr : Bool -/
def AddrTop (address : (BitVec 64)) (IsInstr : Bool) (el : (BitVec 2)) : SailM Int := do
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:6128.21-6128.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  (if ((← (ELUsingAArch32 regime)) : Bool)
  then (do (pure 31))
  else
    (do (if (((← (EffectiveTBI address IsInstr el)) == 1#1) : Bool)
        then (do (pure 55))
        else (do (pure 63)))))

def IsInHost (_ : Unit) : SailM Bool := do
  (ELIsInHost (← readReg PSTATE).EL)

def AArch64_BranchAddr (vaddress : (BitVec 64)) (el : (BitVec 2)) : SailM (BitVec 64) := do
  sail_assert (! (← (UsingAArch32 ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6150.35-6150.36"
  let msbit ← (( do (AddrTop vaddress true el) ) : SailM Int )
  (if ((msbit == 63) : Bool)
  then (do (pure vaddress))
  else
    (do sail_assert ((0 ≤b msbit) && (msbit <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6155.54-6155.55"
        (if (((←((pure ((el == EL0) || (el == EL1))) <||> (do
               (IsInHost ())))) && (((BitVec.access vaddress msbit) : BitVec 1) == 1#1)) : Bool)
        then (do (pure (sign_extend (Sail.BitVec.extractLsb vaddress msbit 0) 64)))
        else (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb vaddress msbit 0) 64))))))

def BRBEMispredictAllowed (_ : Unit) : SailM Bool := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure ((_get_BRBCR_EL2_Type_MPRED (← readReg BRBCR_EL2)) == 0#1))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBCR_EL1_Type_MPRED (← readReg BRBCR_EL1)) == 0#1) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def BRBCycleCountingEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure ((_get_BRBCR_EL2_Type_CC (← readReg BRBCR_EL2)) == 0#1))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBCR_EL1_Type_CC (← readReg BRBCR_EL1)) == 0#1) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def BranchRawCycleCount (_ : Unit) : SailM Int := do
  let diff ← (( do (pure ((← readReg __cycle_count) -i (← readReg __last_cycle_count))) ) : SailM Int )
  writeReg __last_cycle_count (← readReg __cycle_count)
  (pure diff)


end ArmASL.Functions
