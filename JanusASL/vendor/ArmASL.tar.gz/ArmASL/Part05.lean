import ArmASL.Part04

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescLOR (memop : MemOp) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqsc := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with relsc := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with limitedordered := true }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescLDAcqPC (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqpc := true }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

def InStreamingMode (_ : Unit) : SailM Bool := do
  (HaveSME ()) <&&> (do
    (pure ((← readReg PSTATE).SM == 1#1)))

/-- Type quantifiers: k_nontemporal : Bool, k_tagchecked : Bool -/
def CreateAccDescASIMD (memop : MemOp) (nontemporal : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_ASIMD) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with nontemporal := nontemporal }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc ← (pure { accdesc with streamingsve := (← do (InStreamingMode ())) })
  let accdesc ← (( do
    (if ((←((pure accdesc.streamingsve) <&&> (do
         (__IMPDEF_boolean "No tag checking of SIMD&FP loads and stores in Streaming SVE mode")))) : Bool)
    then (do (pure { accdesc with tagchecked := false }))
    else (do (pure { accdesc with tagchecked := tagchecked }))) ) : SailM AccessDescriptor )
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescASIMDAcqRel (memop : MemOp) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_ASIMD) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqpc := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with relsc := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc ← (pure { accdesc with streamingsve := (← do (InStreamingMode ())) })
  let accdesc ← (( do
    (if ((←((pure accdesc.streamingsve) <&&> (do
         (__IMPDEF_boolean "No tag checking of SIMD&FP loads and stores in Streaming SVE mode")))) : Bool)
    then (do (pure { accdesc with tagchecked := false }))
    else (do (pure { accdesc with tagchecked := tagchecked }))) ) : SailM AccessDescriptor )
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagaccess : Bool, k_tagchecked : Bool -/
def CreateAccDescDCZero (tagaccess : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_DCZero) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with write := true }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  let accdesc : AccessDescriptor := { accdesc with tagaccess := tagaccess }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

def CreateAccDescTTEUpdate (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with atomicop := true }
  let accdesc : AccessDescriptor := { accdesc with modop := MemAtomicOp_CAS }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with write := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

/-- Type quantifiers: k_toplevel : Bool -/
def CreateAccDescS1TTW (toplevel : Bool) (varange : VARange) (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with toplevel := toplevel }
  let accdesc : AccessDescriptor := { accdesc with varange := varange }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescS2TTW (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescGPTW (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescGCS (el : (BitVec 2)) (memop : MemOp) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GCS) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := el }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  (pure { accdesc with write := (BEq.beq memop MemOp_STORE) })

def TranslationRegime (el : (BitVec 2)) : SailM Regime := do
  (if ((el == EL3) : Bool)
  then
    (do (if ((← (ELUsingAArch32 EL3)) : Bool)
        then (do (pure Regime_EL30))
        else (do (pure Regime_EL3))))
  else
    (do (if ((el == EL2) : Bool)
        then
          (do (if ((← (ELIsInHost EL2)) : Bool)
              then (do (pure Regime_EL20))
              else (do (pure Regime_EL2))))
        else
          (do (if ((el == EL1) : Bool)
              then (do (pure Regime_EL10))
              else
                (do (if ((el == EL0) : Bool)
                    then
                      (do (if ((←((pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) <&&> (do
                               (ELUsingAArch32 EL3)))) : Bool)
                          then (do (pure Regime_EL30))
                          else
                            (do (if ((← (ELIsInHost EL0)) : Bool)
                                then (do (pure Regime_EL20))
                                else (do (pure Regime_EL10))))))
                    else
                      (do (Unreachable ())
                          (undefined_Regime ())))))))))

def AlignmentEnforced (_ : Unit) : SailM Bool := do
  let regime ← (( do (TranslationRegime (← readReg PSTATE).EL) ) : SailM Regime )
  let A ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let A ← (( do
    match regime with
    | .Regime_EL3 => (do (pure (_get_SCTLR_EL3_Type_A (← readReg SCTLR_EL3))))
    | .Regime_EL30 => (do (pure (_get_SCTLR_Type_A (← (SCTLR_read__2 ())))))
    | .Regime_EL2 =>
      (do
        (if ((← (ELUsingAArch32 EL2)) : Bool)
        then (do (pure (_get_HSCTLR_Type_A (← (HSCTLR_read ())))))
        else (do (pure (_get_SCTLR_EL2_Type_A (← readReg SCTLR_EL2))))))
    | .Regime_EL20 => (do (pure (_get_SCTLR_EL2_Type_A (← readReg SCTLR_EL2))))
    | .Regime_EL10 =>
      (do
        (if ((← (ELUsingAArch32 EL1)) : Bool)
        then (do (pure (_get_SCTLR_Type_A (← (SCTLR_read__2 ())))))
        else (do (pure (_get_SCTLR_EL1_Type_A (← readReg SCTLR_EL1)))))) ) : SailM (BitVec 1) )
  (pure (A == 1#1))

def undefined_CLIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_CLIDR_Type_ICB (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 30 x)

def _update_CLIDR_Type_LoUIS (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 21 x)

def _update_CLIDR_Type_LoUU (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 27 x)

def HaveCRCExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CRC32)

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def BitReverse (data : (BitVec k_N)) : SailM (BitVec k_N) := do
  let result ← (( do (undefined_bitvector (Sail.BitVec.length data)) ) : SailM (BitVec k_N) )
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length result) -i 1)
  let mut loop_vars := result
  for i in [loop_i_lower:loop_i_upper:1]i do
    let result := loop_vars
    loop_vars := (BitVec.update result (((Sail.BitVec.length result) -i i) -i 1) (Bit ((BitVec.access data i) : BitVec 1)))
  (pure loop_vars)

/-- Type quantifiers: k_N : Nat, k_N > 32 -/
def Poly32Mod2 (data_in : (BitVec k_N)) (poly : (BitVec 32)) : SailM (BitVec 32) := do
  sail_assert ((Sail.BitVec.length data_in) >b 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:12544.18-12544.19"
  let data : (BitVec k_N) := data_in
  let data ← (( do
    let loop_i_lower := 32
    let loop_i_upper := ((Sail.BitVec.length data_in) -i 1)
    let mut loop_vars := data
    for i in [loop_i_upper:loop_i_lower:-1]i do
      let data := loop_vars
      loop_vars :=
        if ((((BitVec.access data i) : BitVec 1) == 1#1) : Bool)
        then (Sail.BitVec.updateSubrange data (i -i 1) 0 ((Sail.BitVec.extractLsb data (i -i 1) 0) ^^^ (poly +++ (Zeros (n := (i -i 32))))))
        else data
    (pure loop_vars) ) : SailM (BitVec k_N) )
  (pure (Sail.BitVec.extractLsb data 31 0))

def HaveAESExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AES)

def HaveBit128PMULLExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMULL)

def HaveSHA1Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SHA1)

def HaveSHA256Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SHA256)

def HaveSHA512Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SHA512)

def HaveSHA3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SHA3)

def HaveSM3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SM3)

def HaveSM4Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SM4)

/-- Type quantifiers: k_N : Nat, shift : Int, k_N ≥ 0 -/
def ROL (x : (BitVec k_N)) (shift : Int) : SailM (BitVec k_N) := do
  sail_assert ((shift ≥b 0) && (shift ≤b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/v8_base.sail:12606.35-12606.36"
  (if ((shift == 0) : Bool)
  then (do (pure x))
  else (do (pure (ROR x ((Sail.BitVec.length x) -i shift)))))

def AESShiftRows (op : (BitVec 128)) : (BitVec 128) :=
  ((((((((((((((((Sail.BitVec.extractLsb op 95 88) +++ (Sail.BitVec.extractLsb op 55 48)) +++ (Sail.BitVec.extractLsb op 15 8)) +++ (Sail.BitVec.extractLsb op 103 96)) +++ (Sail.BitVec.extractLsb op 63 56)) +++ (Sail.BitVec.extractLsb op 23 16)) +++ (Sail.BitVec.extractLsb op 111 104)) +++ (Sail.BitVec.extractLsb op 71 64)) +++ (Sail.BitVec.extractLsb op 31 24)) +++ (Sail.BitVec.extractLsb op 119 112)) +++ (Sail.BitVec.extractLsb op 79 72)) +++ (Sail.BitVec.extractLsb op 39 32)) +++ (Sail.BitVec.extractLsb op 127 120)) +++ (Sail.BitVec.extractLsb op 87 80)) +++ (Sail.BitVec.extractLsb op 47 40)) +++ (Sail.BitVec.extractLsb op 7 0))

def AESInvShiftRows (op : (BitVec 128)) : (BitVec 128) :=
  ((((((((((((((((Sail.BitVec.extractLsb op 31 24) +++ (Sail.BitVec.extractLsb op 55 48)) +++ (Sail.BitVec.extractLsb op 79 72)) +++ (Sail.BitVec.extractLsb op 103 96)) +++ (Sail.BitVec.extractLsb op 127 120)) +++ (Sail.BitVec.extractLsb op 23 16)) +++ (Sail.BitVec.extractLsb op 47 40)) +++ (Sail.BitVec.extractLsb op 71 64)) +++ (Sail.BitVec.extractLsb op 95 88)) +++ (Sail.BitVec.extractLsb op 119 112)) +++ (Sail.BitVec.extractLsb op 15 8)) +++ (Sail.BitVec.extractLsb op 39 32)) +++ (Sail.BitVec.extractLsb op 63 56)) +++ (Sail.BitVec.extractLsb op 87 80)) +++ (Sail.BitVec.extractLsb op 111 104)) +++ (Sail.BitVec.extractLsb op 7 0))

def AESSubBytes (op : (BitVec 128)) : SailM (BitVec 128) := do
  let GF2 : (BitVec 2048) := (((((((((((((((0x16BB54B00F2D99416842E6BF0D89A18C#128 +++ 0xDF2855CEE9871E9B948ED9691198F8E1#128) +++ 0x9E1DC186B95735610EF6034866B53E70#128) +++ 0x8A8BBD4B1F74DDE8C6B4A61C2E2578BA#128) +++ 0x08AE7A65EAF4566CA94ED58D6D37C8E7#128) +++ 0x79E4959162ACD3C25C2406490A3A32E0#128) +++ 0xDB0B5EDE14B8EE4688902A22DC4F8160#128) +++ 0x73195D643D7EA7C41744975FEC130CCD#128) +++ 0xD2F3FF1021DAB6BCF5389D928F40A351#128) +++ 0xA89F3C507F02F94585334D43FBAAEFD0#128) +++ 0xCF584C4A39BECB6A5BB1FC20ED00D153#128) +++ 0x842FE329B3D63B52A05A6E1B1A2C8309#128) +++ 0x75B227EBE28012079A059618C323C704#128) +++ 0x1531D871F1E5A534CCF73F362693FDB7#128) +++ 0xC072A49CAFA2D4ADF04759FA7DC982CA#128) +++ 0x76ABD7FE2B670130C56F6BF27B777C63#128)
  let out ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := out
  for i in [loop_i_lower:loop_i_upper:1]i do
    let out := loop_vars
    loop_vars := (set_slice 8 out (i *i 8) (BitVec.slice GF2 ((BitVec.toNat (BitVec.slice op (i *i 8) 8)) *i 8) 8))
  (pure loop_vars)

def AESInvSubBytes (op : (BitVec 128)) : SailM (BitVec 128) := do
  let GF2_inv : (BitVec 2048) := (((((((((((((((0x7D0C2155631469E126D677BA7E042B17#128 +++ 0x619953833CBBEBC8B0F52AAE4D3BE0A0#128) +++ 0xEF9CC9939F7AE52D0D4AB519A97F5160#128) +++ 0x5FEC8027591012B131C7078833A8DD1F#128) +++ 0xF45ACD78FEC0DB9A2079D2C64B3E56FC#128) +++ 0x1BBE18AA0E62B76F89C5291D711AF147#128) +++ 0x6EDF751CE837F9E28535ADE72274AC96#128) +++ 0x73E6B4F0CECFF297EADC674F4111913A#128) +++ 0x6B8A130103BDAFC1020F3FCA8F1E2CD0#128) +++ 0x0645B3B80558E4F70AD3BC8C00ABD890#128) +++ 0x849D8DA75746155EDAB9EDFD5048706C#128) +++ 0x92B6655DCC5CA4D41698688664F6F872#128) +++ 0x25D18B6D49A25B76B224D92866A12E08#128) +++ 0x4EC3FA420B954CEE3D23C2A632947B54#128) +++ 0xCBE9DEC444438E3487FF2F9B8239E37C#128) +++ 0xFBD7F3819EA340BF38A53630D56A0952#128)
  let out ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := out
  for i in [loop_i_lower:loop_i_upper:1]i do
    let out := loop_vars
    loop_vars := (set_slice 8 out (i *i 8) (BitVec.slice GF2_inv ((BitVec.toNat (BitVec.slice op (i *i 8) 8)) *i 8) 8))
  (pure loop_vars)

def FFmul02 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_02 : (BitVec 2048) := (((((((((((((((0xE5E7E1E3EDEFE9EBF5F7F1F3FDFFF9FB#128 +++ 0xC5C7C1C3CDCFC9CBD5D7D1D3DDDFD9DB#128) +++ 0xA5A7A1A3ADAFA9ABB5B7B1B3BDBFB9BB#128) +++ 0x858781838D8F898B959791939D9F999B#128) +++ 0x656761636D6F696B757771737D7F797B#128) +++ 0x454741434D4F494B555751535D5F595B#128) +++ 0x252721232D2F292B353731333D3F393B#128) +++ 0x050701030D0F090B151711131D1F191B#128) +++ 0xFEFCFAF8F6F4F2F0EEECEAE8E6E4E2E0#128) +++ 0xDEDCDAD8D6D4D2D0CECCCAC8C6C4C2C0#128) +++ 0xBEBCBAB8B6B4B2B0AEACAAA8A6A4A2A0#128) +++ 0x9E9C9A98969492908E8C8A8886848280#128) +++ 0x7E7C7A78767472706E6C6A6866646260#128) +++ 0x5E5C5A58565452504E4C4A4846444240#128) +++ 0x3E3C3A38363432302E2C2A2826242220#128) +++ 0x1E1C1A18161412100E0C0A0806040200#128)
  (BitVec.slice FFmul_02 ((BitVec.toNat b) *i 8) 8)

def FFmul03 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_03 : (BitVec 2048) := (((((((((((((((0x1A191C1F16151013020104070E0D080B#128 +++ 0x2A292C2F26252023323134373E3D383B#128) +++ 0x7A797C7F76757073626164676E6D686B#128) +++ 0x4A494C4F46454043525154575E5D585B#128) +++ 0xDAD9DCDFD6D5D0D3C2C1C4C7CECDC8CB#128) +++ 0xEAE9ECEFE6E5E0E3F2F1F4F7FEFDF8FB#128) +++ 0xBAB9BCBFB6B5B0B3A2A1A4A7AEADA8AB#128) +++ 0x8A898C8F86858083929194979E9D989B#128) +++ 0x818287848D8E8B88999A9F9C95969390#128) +++ 0xB1B2B7B4BDBEBBB8A9AAAFACA5A6A3A0#128) +++ 0xE1E2E7E4EDEEEBE8F9FAFFFCF5F6F3F0#128) +++ 0xD1D2D7D4DDDEDBD8C9CACFCCC5C6C3C0#128) +++ 0x414247444D4E4B48595A5F5C55565350#128) +++ 0x717277747D7E7B78696A6F6C65666360#128) +++ 0x212227242D2E2B28393A3F3C35363330#128) +++ 0x111217141D1E1B18090A0F0C05060300#128)
  (BitVec.slice FFmul_03 ((BitVec.toNat b) *i 8) 8)

def FFmul09 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_09 : (BitVec 2048) := (((((((((((((((0x464F545D626B70790E071C152A233831#128 +++ 0xD6DFC4CDF2FBE0E99E978C85BAB3A8A1#128) +++ 0x7D746F6659504B42353C272E1118030A#128) +++ 0xEDE4FFF6C9C0DBD2A5ACB7BE8188939A#128) +++ 0x3039222B141D060F78716A635C554E47#128) +++ 0xA0A9B2BB848D969FE8E1FAF3CCC5DED7#128) +++ 0x0B0219102F263D34434A5158676E757C#128) +++ 0x9B928980BFB6ADA4D3DAC1C8F7FEE5EC#128) +++ 0xAAA3B8B18E879C95E2EBF0F9C6CFD4DD#128) +++ 0x3A3328211E170C05727B6069565F444D#128) +++ 0x9198838AB5BCA7AED9D0CBC2FDF4EFE6#128) +++ 0x0108131A252C373E49405B526D647F76#128) +++ 0xDCD5CEC7F8F1EAE3949D868FB0B9A2AB#128) +++ 0x4C455E5768617A73040D161F2029323B#128) +++ 0xE7EEF5FCC3CAD1D8AFA6BDB48B829990#128) +++ 0x777E656C535A41483F362D241B120900#128)
  (BitVec.slice FFmul_09 ((BitVec.toNat b) *i 8) 8)

def FFmul0B (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0B : (BitVec 2048) := (((((((((((((((0xA3A8B5BE8F849992FBF0EDE6D7DCC1CA#128 +++ 0x1318050E3F3429224B405D56676C717A#128) +++ 0xD8D3CEC5F4FFE2E9808B969DACA7BAB1#128) +++ 0x68637E75444F5259303B262D1C170A01#128) +++ 0x555E434879726F640D061B10212A373C#128) +++ 0xE5EEF3F8C9C2DFD4BDB6ABA0919A878C#128) +++ 0x2E2538330209141F767D606B5A514C47#128) +++ 0x9E958883B2B9A4AFC6CDD0DBEAE1FCF7#128) +++ 0x545F424978736E650C071A11202B363D#128) +++ 0xE4EFF2F9C8C3DED5BCB7AAA1909B868D#128) +++ 0x2F2439320308151E777C616A5B504D46#128) +++ 0x9F948982B3B8A5AEC7CCD1DAEBE0FDF6#128) +++ 0xA2A9B4BF8E859893FAF1ECE7D6DDC0CB#128) +++ 0x1219040F3E3528234A415C57666D707B#128) +++ 0xD9D2CFC4F5FEE3E8818A979CADA6BBB0#128) +++ 0x69627F74454E5358313A272C1D160B00#128)
  (BitVec.slice FFmul_0B ((BitVec.toNat b) *i 8) 8)

def FFmul0D (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0D : (BitVec 2048) := (((((((((((((((0x979A8D80A3AEB9B4FFF2E5E8CBC6D1DC#128 +++ 0x474A5D50737E69642F2235381B16010C#128) +++ 0x2C21363B1815020F44495E53707D6A67#128) +++ 0xFCF1E6EBC8C5D2DF94998E83A0ADBAB7#128) +++ 0xFAF7E0EDCEC3D4D9929F8885A6ABBCB1#128) +++ 0x2A27303D1E130409424F5855767B6C61#128) +++ 0x414C5B5675786F622924333E1D10070A#128) +++ 0x919C8B86A5A8BFB2F9F4E3EECDC0D7DA#128) +++ 0x4D40575A7974636E25283F32111C0B06#128) +++ 0x9D90878AA9A4B3BEF5F8EFE2C1CCDBD6#128) +++ 0xF6FBECE1C2CFD8D59E938489AAA7B0BD#128) +++ 0x262B3C31121F08054E4354597A77606D#128) +++ 0x202D3A3714190E034845525F7C71666B#128) +++ 0xF0FDEAE7C4C9DED39895828FACA1B6BB#128) +++ 0x9B96818CAFA2B5B8F3FEE9E4C7CADDD0#128) +++ 0x4B46515C7F726568232E3934171A0D00#128)
  (BitVec.slice FFmul_0D ((BitVec.toNat b) *i 8) 8)

def FFmul0E (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0E : (BitVec 2048) := (((((((((((((((0x8D83919FB5BBA9A7FDF3E1EFC5CBD9D7#128 +++ 0x6D63717F555B49471D13010F252B3937#128) +++ 0x56584A446E60727C26283A341E10020C#128) +++ 0xB6B8AAA48E80929CC6C8DAD4FEF0E2EC#128) +++ 0x202E3C321816040A505E4C426866747A#128) +++ 0xC0CEDCD2F8F6E4EAB0BEACA28886949A#128) +++ 0xFBF5E7E9C3CDDFD18B859799B3BDAFA1#128) +++ 0x1B150709232D3F316B657779535D4F41#128) +++ 0xCCC2D0DEF4FAE8E6BCB2A0AE848A9896#128) +++ 0x2C22303E141A08065C52404E646A7876#128) +++ 0x17190B052F21333D67697B755F51434D#128) +++ 0xF7F9EBE5CFC1D3DD87899B95BFB1A3AD#128) +++ 0x616F7D735957454B111F0D032927353B#128) +++ 0x818F9D93B9B7A5ABF1FFEDE3C9C7D5DB#128) +++ 0xBAB4A6A8828C9E90CAC4D6D8F2FCEEE0#128) +++ 0x5A544648626C7E702A243638121C0E00#128)
  (BitVec.slice FFmul_0E ((BitVec.toNat b) *i 8) 8)

def AESMixColumns (op : (BitVec 128)) : SailM (BitVec 128) := do
  let in0 : (BitVec 32) := ((((BitVec.slice op 96 8) +++ (BitVec.slice op 64 8)) +++ (BitVec.slice op 32 8)) +++ (BitVec.slice op 0 8))
  let in1 : (BitVec 32) := ((((BitVec.slice op 104 8) +++ (BitVec.slice op 72 8)) +++ (BitVec.slice op 40 8)) +++ (BitVec.slice op 8 8))
  let in2 : (BitVec 32) := ((((BitVec.slice op 112 8) +++ (BitVec.slice op 80 8)) +++ (BitVec.slice op 48 8)) +++ (BitVec.slice op 16 8))
  let in3 : (BitVec 32) := ((((BitVec.slice op 120 8) +++ (BitVec.slice op 88 8)) +++ (BitVec.slice op 56 8)) +++ (BitVec.slice op 24 8))
  let out0 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out1 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out2 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out3 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (out0, out1, out2, out3) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := 3
    let mut loop_vars := (out0, out1, out2, out3)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (out0, out1, out2, out3) := loop_vars
      loop_vars :=
        let out0 : (BitVec 32) := (set_slice 8 out0 (c *i 8) ((((FFmul02 (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in1 (c *i 8) 8))) ^^^ (BitVec.slice in2 (c *i 8) 8)) ^^^ (BitVec.slice in3 (c *i 8) 8)))
        let out1 : (BitVec 32) := (set_slice 8 out1 (c *i 8) ((((FFmul02 (BitVec.slice in1 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in2 (c *i 8) 8))) ^^^ (BitVec.slice in3 (c *i 8) 8)) ^^^ (BitVec.slice in0 (c *i 8) 8)))
        let out2 : (BitVec 32) := (set_slice 8 out2 (c *i 8) ((((FFmul02 (BitVec.slice in2 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in3 (c *i 8) 8))) ^^^ (BitVec.slice in0 (c *i 8) 8)) ^^^ (BitVec.slice in1 (c *i 8) 8)))
        let out3 : (BitVec 32) := (set_slice 8 out3 (c *i 8) ((((FFmul02 (BitVec.slice in3 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in0 (c *i 8) 8))) ^^^ (BitVec.slice in1 (c *i 8) 8)) ^^^ (BitVec.slice in2 (c *i 8) 8)))
        (out0, out1, out2, out3)
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 32)) )
  (pure ((((((((((((((((BitVec.slice out3 (3 *i 8) 8) +++ (BitVec.slice out2 (3 *i 8) 8)) +++ (BitVec.slice out1 (3 *i 8) 8)) +++ (BitVec.slice out0 (3 *i 8) 8)) +++ (BitVec.slice out3 (2 *i 8) 8)) +++ (BitVec.slice out2 (2 *i 8) 8)) +++ (BitVec.slice out1 (2 *i 8) 8)) +++ (BitVec.slice out0 (2 *i 8) 8)) +++ (BitVec.slice out3 (1 *i 8) 8)) +++ (BitVec.slice out2 (1 *i 8) 8)) +++ (BitVec.slice out1 (1 *i 8) 8)) +++ (BitVec.slice out0 (1 *i 8) 8)) +++ (BitVec.slice out3 (0 *i 8) 8)) +++ (BitVec.slice out2 (0 *i 8) 8)) +++ (BitVec.slice out1 (0 *i 8) 8)) +++ (BitVec.slice out0 (0 *i 8) 8)))

def AESInvMixColumns (op : (BitVec 128)) : SailM (BitVec 128) := do
  let in0 : (BitVec 32) := ((((BitVec.slice op 96 8) +++ (BitVec.slice op 64 8)) +++ (BitVec.slice op 32 8)) +++ (BitVec.slice op 0 8))
  let in1 : (BitVec 32) := ((((BitVec.slice op 104 8) +++ (BitVec.slice op 72 8)) +++ (BitVec.slice op 40 8)) +++ (BitVec.slice op 8 8))
  let in2 : (BitVec 32) := ((((BitVec.slice op 112 8) +++ (BitVec.slice op 80 8)) +++ (BitVec.slice op 48 8)) +++ (BitVec.slice op 16 8))
  let in3 : (BitVec 32) := ((((BitVec.slice op 120 8) +++ (BitVec.slice op 88 8)) +++ (BitVec.slice op 56 8)) +++ (BitVec.slice op 24 8))
  let out0 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out1 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out2 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out3 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (out0, out1, out2, out3) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := 3
    let mut loop_vars := (out0, out1, out2, out3)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (out0, out1, out2, out3) := loop_vars
      loop_vars :=
        let out0 : (BitVec 32) := (set_slice 8 out0 (c *i 8) ((((FFmul0E (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0B (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0D (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul09 (BitVec.slice in3 (c *i 8) 8))))
        let out1 : (BitVec 32) := (set_slice 8 out1 (c *i 8) ((((FFmul09 (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0E (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0B (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0D (BitVec.slice in3 (c *i 8) 8))))
        let out2 : (BitVec 32) := (set_slice 8 out2 (c *i 8) ((((FFmul0D (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul09 (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0E (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0B (BitVec.slice in3 (c *i 8) 8))))
        let out3 : (BitVec 32) := (set_slice 8 out3 (c *i 8) ((((FFmul0B (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0D (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul09 (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0E (BitVec.slice in3 (c *i 8) 8))))
        (out0, out1, out2, out3)
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 32)) )
  (pure ((((((((((((((((BitVec.slice out3 (3 *i 8) 8) +++ (BitVec.slice out2 (3 *i 8) 8)) +++ (BitVec.slice out1 (3 *i 8) 8)) +++ (BitVec.slice out0 (3 *i 8) 8)) +++ (BitVec.slice out3 (2 *i 8) 8)) +++ (BitVec.slice out2 (2 *i 8) 8)) +++ (BitVec.slice out1 (2 *i 8) 8)) +++ (BitVec.slice out0 (2 *i 8) 8)) +++ (BitVec.slice out3 (1 *i 8) 8)) +++ (BitVec.slice out2 (1 *i 8) 8)) +++ (BitVec.slice out1 (1 *i 8) 8)) +++ (BitVec.slice out0 (1 *i 8) 8)) +++ (BitVec.slice out3 (0 *i 8) 8)) +++ (BitVec.slice out2 (0 *i 8) 8)) +++ (BitVec.slice out1 (0 *i 8) 8)) +++ (BitVec.slice out0 (0 *i 8) 8)))

def SHAchoose (x : (BitVec 32)) (y : (BitVec 32)) (z : (BitVec 32)) : (BitVec 32) :=
  (((y ^^^ z) &&& x) ^^^ z)

def SHAparity (x : (BitVec 32)) (y : (BitVec 32)) (z : (BitVec 32)) : (BitVec 32) :=
  ((x ^^^ y) ^^^ z)

def SHAmajority (x : (BitVec 32)) (y : (BitVec 32)) (z : (BitVec 32)) : (BitVec 32) :=
  ((x &&& y) ||| ((x ||| y) &&& z))

def SHAhashSIGMA0 (x : (BitVec 32)) : (BitVec 32) :=
  (((ROR x 2) ^^^ (ROR x 13)) ^^^ (ROR x 22))

def SHAhashSIGMA1 (x : (BitVec 32)) : (BitVec 32) :=
  (((ROR x 6) ^^^ (ROR x 11)) ^^^ (ROR x 25))

/-- Type quantifiers: k_part1 : Bool -/
def SHA256hash (x_in : (BitVec 128)) (y_in : (BitVec 128)) (w : (BitVec 128)) (part1 : Bool) : SailM (BitVec 128) := do
  let chs ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let maj ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let t ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let x : (BitVec 128) := x_in
  let y : (BitVec 128) := y_in
  let (chs, maj, t, x, y) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (chs, maj, t, x, y)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (chs, maj, t, x, y) := loop_vars
      loop_vars ← do
        let chs : (BitVec 32) := (SHAchoose (Sail.BitVec.extractLsb y 31 0) (Sail.BitVec.extractLsb y 63 32) (Sail.BitVec.extractLsb y 95 64))
        let maj : (BitVec 32) := (SHAmajority (Sail.BitVec.extractLsb x 31 0) (Sail.BitVec.extractLsb x 63 32) (Sail.BitVec.extractLsb x 95 64))
        let t ← (pure ((((Sail.BitVec.extractLsb y 127 96) + (SHAhashSIGMA1 (Sail.BitVec.extractLsb y 31 0))) + chs) + (← (Elem_read w e 32))))
        let x : (BitVec 128) := (Sail.BitVec.updateSubrange x 127 96 (t + (Sail.BitVec.extractLsb x 127 96)))
        let y : (BitVec 128) := (Sail.BitVec.updateSubrange y 127 96 ((t + (SHAhashSIGMA0 (Sail.BitVec.extractLsb x 31 0))) + maj))
        let split_vec ← do (ROL (y +++ x) 32)
        let y : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 255 128)
        let x : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 127 0)
        (pure (chs, maj, t, x, y))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 128) × (BitVec 128)) )
  (if (part1 : Bool)
  then (do (pure x))
  else (do (pure y)))

def Sbox (sboxin : (BitVec 8)) : (BitVec 8) :=
  let sboxstring : (BitVec 2048) := 0xD690E9FECCE13DB716B614C228FB2C052B679A762ABE04C3AA441326498606999C4250F491EF987A33540B43EDCFAC62E4B31CA9C908E89580DF94FA758F3FA64707A7FCF37317BA83593C19E6854FA8686B81B27164DA8BF8EB0F4B70569D351E240E5E6358D1A225227C3B01217887D40046579FD327524C3602E7A0C4C89EEABF8AD240C738B5A3F7F2CEF96115A1E0AE5DA49B341A55AD933230F58CB1E31DF6E22E8266CA60C02923AB0D534E6FD5DB3745DEFD8E2F03FF6A726D6C5B518D1BAF92BBDDBC7F11D95C411F105AD80AC13188A5CD7BBD2D74D012B8E5B4B08969974A0C96777E65B9F109C56EC68418F07DEC3ADC4D2079EE5F3ED7CB3948#2048
  let sboxin := (BitVec.toNat sboxin)
  (Sail.BitVec.extractLsb sboxstring (((255 -i sboxin) *i 8) +i 7) ((255 -i sboxin) *i 8))

def undefined_CONTEXTIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TTBCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_TTBCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_TTBCR_Type_EAE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_TTBCR_Type_EAE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_TTBCR_Type_PD0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_TTBCR_Type_PD1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def TTBCR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _TTBCR_NS ) : SailM TTBCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL1) 0 32)))

def TTBCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_TTBCR_Type ()) ) : SailM TTBCR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBCR_S)
  else (do (TTBCR_NS_read ())))

def undefined_CONTEXTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_TTBR0_EL1_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR0_EL2_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR1_EL1_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR1_EL2_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def undefined_TTBR0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GPTBR_EL3_Type_BADDR (v : (BitVec 64)) : (BitVec 40) :=
  (Sail.BitVec.extractLsb v 39 0)

def _get_TTBR0_EL1_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR0_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR0_EL3_Type_CnP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR1_EL1_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR1_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_VSTTBR_EL2_Type_CnP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_VTTBR_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GPCCR_EL3_Type_IRGN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def TTBR0_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_TTBR0_Type ()) ) : SailM TTBR0_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBR0_S)
  else (do readReg TTBR0_NS))

def undefined_TTBR0_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR0_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def _get_TTBR0_EL1_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR0_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR0_EL3_Type_SKL (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR1_EL1_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR1_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_VSTTBR_EL2_Type_SKL (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_VTTBR_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def TTBR0_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR0_EL1 ) : SailM TTBR0_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (TTBR0_read ())) 0 64)))

def undefined_HTTBR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TTBR0_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR0_EL2_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def TTBR0_EL2_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR0_EL2 ) : SailM TTBR0_EL2_Type )
  (pure (Sail.BitVec.updateSubrange r 47 1 (BitVec.slice (← readReg HTTBR) 1 47)))

def undefined_TTBR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def TTBR1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_TTBR1_Type ()) ) : SailM TTBR1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBR1_S)
  else (do readReg TTBR1_NS))

def undefined_TTBR1_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR1_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def TTBR1_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR1_EL1 ) : SailM TTBR1_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (TTBR1_read ())) 0 64)))

def undefined_TTBR1_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

/-- Type quantifiers: a_in : Int, k_increasedprecision_name : Bool -/
def RecipEstimate (a_in : Int) (increasedprecision_name : Bool) : SailM Int := do
  let a : Int := a_in
  let r ← (( do (undefined_int ()) ) : SailM Int )
  let r ← (( do
    (if ((! increasedprecision_name) : Bool)
    then
      (do sail_assert ((256 ≤b a) && (a <b 512)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13058.33-13058.34"
          let a := ((a *i 2) +i 1)
          let b := (fdiv_int (2 ^i 19) a)
          let r : Int := (fdiv_int (b +i 1) 2)
          sail_assert ((256 ≤b r) && (r <b 512)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13062.33-13062.34"
          (pure r))
    else
      (do sail_assert ((2048 ≤b a) && (a <b 4096)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13064.35-13064.36"
          let a := ((a *i 2) +i 1)
          let real_val : real := (div_real (to_real (2 ^i 25)) (to_real a))
          let r : Int := (round_down real_val)
          let error : real := (sub_real real_val (to_real r))
          let round_up : Bool := (gt_real error (1/2))
          let r : Int :=
            if (round_up : Bool)
            then (r +i 1)
            else r
          sail_assert ((4096 ≤b r) && (r <b 8192)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13073.35-13073.36"
          (pure r))) ) : SailM Int )
  let r := r
  (pure r)

/-- Type quantifiers: k_N : Nat, k_N = 32 -/
def UnsignedRecipEstimate (operand : (BitVec k_N)) : SailM (BitVec k_N) := do
  let estimate ← (( do (undefined_int ()) ) : SailM Int )
  let increasedprecision_name ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert ((Sail.BitVec.length operand) == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:13084.19-13084.20"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_N) )
  (if ((((BitVec.access operand ((Sail.BitVec.length result) -i 1)) : BitVec 1) == 0#1) : Bool)
  then (do (pure (Ones (n := (Sail.BitVec.length result)))))
  else
    (do let increasedprecision_name : Bool := false
        let estimate ← (( do (RecipEstimate (BitVec.toNat (Sail.BitVec.extractLsb operand 31 23)) increasedprecision_name) ) : SailM Int )
        (pure ((integer_subrange estimate 8 0) +++ (Zeros (n := ((Sail.BitVec.length result) -i 9)))))))

/-- Type quantifiers: a_in : Int, k_increasedprecision_name : Bool -/
def RecipSqrtEstimate (a_in : Int) (increasedprecision_name : Bool) : SailM Int := do
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let a : Int := a_in
  let r ← (( do (undefined_int ()) ) : SailM Int )
  let r ← (( do
    (if ((! increasedprecision_name) : Bool)
    then
      (do sail_assert ((128 ≤b a) && (a <b 512)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13104.33-13104.34"
          let a : Int :=
            if ((a <b 256) : Bool)
            then ((a *i 2) +i 1)
            else
              (let a : Int := (Int.shiftl (Int.shiftr a 1) 1)
              ((a +i 1) *i 2))
          let a := a
          let b : Int := 512
          let b ← (( do
            let mut loop_vars := b
            while (λ b => (((a *i (b +i 1)) *i (b +i 1)) <b (2 ^i 28))) loop_vars do
              let b := loop_vars
              loop_vars := ((b +i 1) : Int)
            (pure loop_vars) ) : SailM Int )
          let b := b
          let r : Int := (fdiv_int (b +i 1) 2)
          sail_assert ((256 ≤b r) && (r <b 512)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13118.33-13118.34"
          (pure r))
    else
      (do sail_assert ((1024 ≤b a) && (a <b 4096)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13120.35-13120.36"
          let real_val ← (( do (undefined_real ()) ) : SailM real )
          let real_val : real :=
            if ((a <b 2048) : Bool)
            then
              (let a := ((a *i 2) +i 1)
              (div_real (to_real a) (2)))
            else
              (let a : Int := (Int.shiftl (Int.shiftr a 1) 1)
              let a := (a +i 1)
              (to_real a))
          let real_val : real := (sqrt_real real_val)
          let real_val : real := (mult_real real_val (to_real (2 ^i 47)))
          let int_val : Int := (round_down real_val)
          let error : real := (sub_real real_val (to_real int_val))
          let round_up : Bool := (gt_real error (1/2))
          let int_val : Int :=
            if (round_up : Bool)
            then (int_val +i 1)
            else int_val
          let real_val : real := (div_real (to_real (2 ^i 65)) (to_real int_val))
          let int_val : Int := (round_down real_val)
          let error : real := (sub_real real_val (to_real int_val))
          let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_val 0) : BitVec 1) == 1#1)))
          let int_val : Int :=
            if (round_up : Bool)
            then (int_val +i 1)
            else int_val
          let int_val := int_val
          let r : Int := int_val
          sail_assert ((4096 ≤b r) && (r <b 8192)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13147.35-13147.36"
          (pure r))) ) : SailM Int )
  let r := r
  (pure r)

/-- Type quantifiers: k_N : Nat, k_N = 32 -/
def UnsignedRSqrtEstimate (operand : (BitVec k_N)) : SailM (BitVec k_N) := do
  let estimate ← (( do (undefined_int ()) ) : SailM Int )
  let increasedprecision_name ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert ((Sail.BitVec.length operand) == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:13158.19-13158.20"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_N) )
  (if (((Sail.BitVec.extractLsb operand ((Sail.BitVec.length result) -i 1) ((Sail.BitVec.length result) -i 2)) == 0b00#2) : Bool)
  then (do (pure (Ones (n := (Sail.BitVec.length result)))))
  else
    (do let increasedprecision_name : Bool := false
        let estimate ← (( do (RecipSqrtEstimate (BitVec.toNat (Sail.BitVec.extractLsb operand 31 23)) increasedprecision_name) ) : SailM Int )
        (pure ((integer_subrange estimate 8 0) +++ (Zeros (n := ((Sail.BitVec.length result) -i 9)))))))

/-- Type quantifiers: N : Nat, i : Int, 0 ≤ (N - 1) -/
def SignedSatQ (i : Int) (N : Nat) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let saturated ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, saturated) : (Int × Bool) :=
    if ((i >b ((2 ^i (N -i 1)) -i 1)) : Bool)
    then
      (let result : Int := ((2 ^i (N -i 1)) -i 1)
      let saturated : Bool := true
      (result, saturated))
    else
      (let (result, saturated) : (Int × Bool) :=
        if ((i <b (Neg.neg (2 ^i (N -i 1)))) : Bool)
        then
          (let result : Int := (Neg.neg (2 ^i (N -i 1)))
          let saturated : Bool := true
          (result, saturated))
        else
          (let result : Int := i
          let saturated : Bool := false
          (result, saturated))
      (result, saturated))
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), saturated))

/-- Type quantifiers: N : Nat, i : Int, 0 ≤ (N - 1) -/
def UnsignedSatQ (i : Int) (N : Nat) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let saturated ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, saturated) : (Int × Bool) :=
    if ((i >b ((2 ^i N) -i 1)) : Bool)
    then
      (let result : Int := ((2 ^i N) -i 1)
      let saturated : Bool := true
      (result, saturated))
    else
      (let (result, saturated) : (Int × Bool) :=
        if ((i <b 0) : Bool)
        then
          (let result : Int := 0
          let saturated : Bool := true
          (result, saturated))
        else
          (let result : Int := i
          let saturated : Bool := false
          (result, saturated))
      (result, saturated))
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), saturated))

/-- Type quantifiers: N : Nat, i : Int, k_is_unsigned : Bool, N ≥ 0 -/
def SatQ (i : Int) (N : Nat) (is_unsigned : Bool) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_bitvector N) ) : SailM (BitVec N) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, sat) ← (( do
    let (tup__0, tup__1) ← do
      (if (is_unsigned : Bool)
      then
        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13218.38-13218.39"
            (UnsignedSatQ i N))
      else
        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13221.38-13221.39"
            (SignedSatQ i N)))
    let result : (BitVec N) := tup__0
    let sat : Bool := tup__1
    (pure (result, sat)) ) : SailM ((BitVec N) × Bool) )
  (pure (result, sat))

def AdvSIMDExpandImm (op : (BitVec 1)) (cmode : (BitVec 4)) (imm8 : (BitVec 8)) : SailM (BitVec 64) := do
  let imm32 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let imm8a ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8b ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8c ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8d ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8e ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8f ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8g ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8h ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm64 ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  match (Sail.BitVec.extractLsb cmode 3 1) with
  | 0b000 => (pure (BitVec.replicateBits ((Zeros (n := 24)) +++ imm8) 2))
  | 0b001 => (pure (BitVec.replicateBits (((Zeros (n := 16)) +++ imm8) +++ (Zeros (n := 8))) 2))
  | 0b010 => (pure (BitVec.replicateBits (((Zeros (n := 8)) +++ imm8) +++ (Zeros (n := 16))) 2))
  | 0b011 => (pure (BitVec.replicateBits (imm8 +++ (Zeros (n := 24))) 2))
  | 0b100 => (pure (BitVec.replicateBits ((Zeros (n := 8)) +++ imm8) 4))
  | 0b101 => (pure (BitVec.replicateBits (imm8 +++ (Zeros (n := 8))) 4))
  | 0b110 =>
    ((if ((((BitVec.access cmode 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure (BitVec.replicateBits (((Zeros (n := 16)) +++ imm8) +++ (Ones (n := 8))) 2)))
    else (do (pure (BitVec.replicateBits (((Zeros (n := 8)) +++ imm8) +++ (Ones (n := 16))) 2)))))
  | _ =>
    (do
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 0#1) && (op == 0#1)) : Bool)
        then (BitVec.replicateBits imm8 8)
        else imm64
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 0#1) && (op == 1#1)) : Bool)
        then
          (let imm8a : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 7) : BitVec 1) 8)
          let imm8b : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 8)
          let imm8c : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 5) : BitVec 1) 8)
          let imm8d : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 4) : BitVec 1) 8)
          let imm8e : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 3) : BitVec 1) 8)
          let imm8f : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 2) : BitVec 1) 8)
          let imm8g : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 1) : BitVec 1) 8)
          let imm8h : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 0) : BitVec 1) 8)
          (((((((imm8a +++ imm8b) +++ imm8c) +++ imm8d) +++ imm8e) +++ imm8f) +++ imm8g) +++ imm8h))
        else imm64
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 1#1) && (op == 0#1)) : Bool)
        then
          (let imm32 : (BitVec 32) := ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 5)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 19)))
          (BitVec.replicateBits imm32 2))
        else imm64
      (if (((((BitVec.access cmode 0) : BitVec 1) == 1#1) && (op == 1#1)) : Bool)
      then
        (do (if ((← (UsingAArch32 ())) : Bool)
            then (do (ReservedEncoding ()))
            else (do (pure ())))
            (pure ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 8)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 48)))))
      else (do (pure imm64))))

/-- Type quantifiers: k_M : Nat, k_N : Nat, k_M ≥ 0 ∧ k_N ≥ 0 -/
def PolynomialMult (op1 : (BitVec k_M)) (op2 : (BitVec k_N)) : (BitVec (k_M + k_N)) := Id.run do
  let result : (BitVec (k_M + k_N)) := (Zeros (n := ((Sail.BitVec.length op1) +i (Sail.BitVec.length op2))))
  let extended_op2 : (BitVec (k_M + k_N)) := (Sail.BitVec.zeroExtend op2 ((Sail.BitVec.length op1) +i (Sail.BitVec.length op2)))
  let loop_i_lower := 0
  let loop_i_upper := ((Sail.BitVec.length op1) -i 1)
  let mut loop_vars := result
  for i in [loop_i_lower:loop_i_upper:1]i do
    let result := loop_vars
    loop_vars :=
      if ((((BitVec.access op1 i) : BitVec 1) == 1#1) : Bool)
      then (result ^^^ (extended_op2 <<< i))
      else result
  (pure loop_vars)

/-- Type quantifiers: k_N : Nat, k_op1_unsigned : Bool, k_op2_unsigned : Bool, k_N = 128 -/
def MatMulAdd (addend : (BitVec k_N)) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (op1_unsigned : Bool) (op2_unsigned : Bool) : SailM (BitVec k_N) := do
  sail_assert ((Sail.BitVec.length op2) == 128) "sail-arm/arm-v9.4-a/src/v8_base.sail:13317.20-13317.21"
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let sum ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let prod ← (( do (undefined_int ()) ) : SailM Int )
  let (prod, result, sum) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := 1
    let mut loop_vars := (prod, result, sum)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (prod, result, sum) := loop_vars
      loop_vars ← do
        let (prod, result, sum) ← (( do
          let loop_j_lower := 0
          let loop_j_upper := 1
          let mut loop_vars_1 := (prod, result, sum)
          for j in [loop_j_lower:loop_j_upper:1]i do
            let (prod, result, sum) := loop_vars_1
            loop_vars_1 ← do
              let sum ← (Elem_read addend ((2 *i i) +i j) 32)
              let (prod, sum) ← (( do
                let loop_k_lower := 0
                let loop_k_upper := 7
                let mut loop_vars_2 := (prod, sum)
                for k in [loop_k_lower:loop_k_upper:1]i do
                  let (prod, sum) := loop_vars_2
                  loop_vars_2 ← do
                    let prod ← (( (pure ((← (asl_Int (← (Elem_read op1 ((8 *i i) +i k) 8)) op1_unsigned)) *i (← (asl_Int (← (Elem_read op2 ((8 *i j) +i k) 8)) op2_unsigned)))) ) : SailM Int )
                    let sum : (BitVec 32) := (BitVec.addInt sum prod)
                    (pure (prod, sum))
                (pure loop_vars_2) ) : SailM (Int × (BitVec 32)) )
              let result ← (Elem_set result ((2 *i i) +i j) 32 sum)
              (pure (prod, result, sum))
          (pure loop_vars_1) ) : SailM (Int × (BitVec k_N) × (BitVec 32)) )
        (pure (prod, result, sum))
    (pure loop_vars) ) : SailM (Int × (BitVec k_N) × (BitVec 32)) )
  (pure result)

/-- Type quantifiers: k_N : Nat, k_N > 0 -/
def AddWithCarry (x : (BitVec k_N)) (y : (BitVec k_N)) (carry_in : (BitVec 1)) : ((BitVec k_N) × (BitVec 4)) :=
  let unsigned_sum := (((BitVec.toNat x) +i (BitVec.toNat y)) +i (BitVec.toNat carry_in))
  let signed_sum := (((BitVec.toInt x) +i (BitVec.toInt y)) +i (BitVec.toNat carry_in))
  let result : (BitVec k_N) := (integer_subrange unsigned_sum ((Sail.BitVec.length y) -i 1) 0)
  let n : (BitVec 1) := ((BitVec.access result ((Sail.BitVec.length y) -i 1)) : BitVec 1)
  let z : (BitVec 1) :=
    if ((IsZero result) : Bool)
    then 1#1
    else 0#1
  let c : (BitVec 1) :=
    if (((BitVec.toNat result) == unsigned_sum) : Bool)
    then 0#1
    else 1#1
  let v : (BitVec 1) :=
    if (((BitVec.toInt result) == signed_sum) : Bool)
    then 0#1
    else 1#1
  (result, (((n +++ z) +++ c) +++ v))

def HaveRASExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RAS)

def IsExternalSyncAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13362.35-13362.36"
  (pure ((BEq.beq statuscode Fault_SyncExternal) || ((BEq.beq statuscode Fault_SyncParity) || ((BEq.beq statuscode Fault_SyncExternalOnWalk) || (BEq.beq statuscode Fault_SyncParityOnWalk)))))

def IsExternalSyncAbort__1 (fault : FaultRecord) : SailM Bool := do
  (pure ((← (IsExternalSyncAbort fault.statuscode)) || (BEq.beq fault.gpcf.gpf GPCF_EABT)))

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def IsExternalAbortTakenSynchronously (memstatus : PhysMemRetStatus) (iswrite : Bool) (desc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Bool := do
  (__UNKNOWN_boolean ())

def PendSErrorInterrupt (fault : FaultRecord) : Unit :=
  ()

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def HandleExternalTTWAbort (memretstatus : PhysMemRetStatus) (iswrite : Bool) (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (size : Int) (input_fault : FaultRecord) : SailM FaultRecord := do
  let output_fault : FaultRecord := input_fault
  let output_fault : FaultRecord := { output_fault with extflag := memretstatus.extflag }
  let output_fault : FaultRecord := { output_fault with statuscode := memretstatus.statuscode }
  let output_fault ← (( do
    (if ((←((IsExternalSyncAbort__1 output_fault) <&&> (do
         (pure (! (← (IsExternalAbortTakenSynchronously memretstatus iswrite memaddrdesc size accdesc))))))) : Bool)
    then
      (do (if ((BEq.beq output_fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { output_fault with statuscode := Fault_AsyncParity }))
          else (do (pure { output_fault with statuscode := Fault_AsyncExternal }))))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  let output_fault ← (( do
    (if ((← (IsExternalSyncAbort__1 output_fault)) : Bool)
    then
      (do (if ((BEq.beq output_fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { output_fault with statuscode := Fault_SyncParityOnWalk }))
          else (do (pure { output_fault with statuscode := Fault_SyncExternalOnWalk }))))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  let output_fault ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure { output_fault with merrorstate := memretstatus.merrorstate }))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  (if ((! (← (IsExternalSyncAbort__1 output_fault))) : Bool)
  then
    (do let _ : Unit := (PendSErrorInterrupt output_fault)
        (pure { output_fault with statuscode := Fault_None }))
  else (do (pure output_fault)))

def AArch32_EncodeAsyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 2) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b00#2)
  | .ErrorState_UEU => (pure 0b01#2)
  | .ErrorState_UEO => (pure 0b10#2)
  | .ErrorState_UER => (pure 0b11#2)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 2))

def ActionRequired (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ErrorIsContained (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ErrorIsSynchronized (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUC (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUER (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUEU (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def StateIsRecoverable (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch32_PEErrorState (fault : FaultRecord) : SailM ErrorState := do
  (if ((←((pure (! (← (ErrorIsContained ())))) <||> (do
       (pure (! (← (ErrorIsSynchronized ())))) <&&> (do
         (pure (! (← (StateIsRecoverable ())))))) <||> (do
       (ReportErrorAsUC ())))) : Bool)
  then (do (pure ErrorState_UC))
  else
    (do (if ((←((pure (! (← (StateIsRecoverable ())))) <||> (do
             (ReportErrorAsUEU ())))) : Bool)
        then (do (pure ErrorState_UEU))
        else
          (do (if ((←((ActionRequired ()) <||> (do
                   (ReportErrorAsUER ())))) : Bool)
              then (do (pure ErrorState_UER))
              else (do (pure ErrorState_UEO)))))))

def Have52BitIPAAndPASpaceExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LPA2)

def Have56BitPAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_D128)

def HaveMTE2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE2)

/-- Type quantifiers: level : Int -/
def EncodeLDFSC (statuscode : Fault) (level : Int) : SailM (BitVec 6) := do
  let result ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
  (if ((level == (Neg.neg 2)) : Bool)
  then
    (do sail_assert (← (Have56BitPAExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13478.31-13478.32"
        match statuscode with
        | .Fault_AddressSize => (pure 0b101100#6)
        | .Fault_Translation => (pure 0b101010#6)
        | .Fault_SyncExternalOnWalk => (pure 0b010010#6)
        | .Fault_SyncParityOnWalk =>
          (do
            let result : (BitVec 6) := 0b011010#6
            sail_assert (! (← (HaveRASExt ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13491.43-13491.44"
            (pure result))
        | .Fault_GPCFOnWalk => (pure 0b100010#6)
        | _ =>
          (do
            (Unreachable ())
            (pure result)))
  else
    (do (if ((level == (Neg.neg 1)) : Bool)
        then
          (do sail_assert (← (Have52BitIPAAndPASpaceExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13503.42-13503.43"
              match statuscode with
              | .Fault_AddressSize => (pure 0b101001#6)
              | .Fault_Translation => (pure 0b101011#6)
              | .Fault_SyncExternalOnWalk => (pure 0b010011#6)
              | .Fault_SyncParityOnWalk =>
                (do
                  let result : (BitVec 6) := 0b011011#6
                  sail_assert (! (← (HaveRASExt ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13516.43-13516.44"
                  (pure result))
              | .Fault_GPCFOnWalk => (pure 0b100011#6)
              | _ =>
                (do
                  (Unreachable ())
                  (pure result)))
        else
          (do match statuscode with
              | .Fault_AddressSize =>
                (do
                  let result : (BitVec 6) := (0b0000#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13530.66-13530.67"
                  (pure result))
              | .Fault_AccessFlag =>
                (do
                  let result : (BitVec 6) := (0b0010#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13534.66-13534.67"
                  (pure result))
              | .Fault_Permission =>
                (do
                  let result : (BitVec 6) := (0b0011#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13538.66-13538.67"
                  (pure result))
              | .Fault_Translation =>
                (do
                  let result : (BitVec 6) := (0b0001#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13542.66-13542.67"
                  (pure result))
              | .Fault_SyncExternal => (pure 0b010000#6)
              | .Fault_SyncExternalOnWalk =>
                (do
                  let result : (BitVec 6) := (0b0101#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13549.66-13549.67"
                  (pure result))
              | .Fault_SyncParity => (pure 0b011000#6)
              | .Fault_SyncParityOnWalk =>
                (do
                  let result : (BitVec 6) := (0b0111#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13556.66-13556.67"
                  (pure result))
              | .Fault_AsyncParity => (pure 0b011001#6)
              | .Fault_AsyncExternal =>
                (do
                  let result : (BitVec 6) := 0b010001#6
                  sail_assert (← (UsingAArch32 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13563.31-13563.32"
                  (pure result))
              | .Fault_TagCheck =>
                (do
                  let result : (BitVec 6) := 0b010001#6
                  sail_assert (← (HaveMTE2Ext ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13567.30-13567.31"
                  (pure result))
              | .Fault_Alignment => (pure 0b100001#6)
              | .Fault_Debug => (pure 0b100010#6)
              | .Fault_GPCFOnWalk =>
                (do
                  let result : (BitVec 6) := (0b1001#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13577.66-13577.67"
                  (pure result))
              | .Fault_GPCFOnOutput => (pure 0b101000#6)
              | .Fault_TLBConflict => (pure 0b110000#6)
              | .Fault_HWUpdateAccessFlag => (pure 0b110001#6)
              | .Fault_Lockdown => (pure 0b110100#6)
              | .Fault_Exclusive => (pure 0b110101#6)
              | _ =>
                (do
                  (Unreachable ())
                  (pure result))))))

def IsAsyncAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13606.35-13606.36"
  (pure ((BEq.beq statuscode Fault_AsyncExternal) || (BEq.beq statuscode Fault_AsyncParity)))

def IsAsyncAbort__1 (fault : FaultRecord) : SailM Bool := do
  (IsAsyncAbort fault.statuscode)

def IsExternalAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13619.35-13619.36"
  (pure ((BEq.beq statuscode Fault_SyncExternal) || ((BEq.beq statuscode Fault_SyncParity) || ((BEq.beq statuscode Fault_SyncExternalOnWalk) || ((BEq.beq statuscode Fault_SyncParityOnWalk) || ((BEq.beq statuscode Fault_AsyncExternal) || (BEq.beq statuscode Fault_AsyncParity)))))))

def IsExternalAbort__1 (fault : FaultRecord) : SailM Bool := do
  (pure ((← (IsExternalAbort fault.statuscode)) || (BEq.beq fault.gpcf.gpf GPCF_EABT)))

def IsSecondStage (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13630.41-13630.42"
  (pure fault.secondstage)

def LSInstructionSyndrome (_ : Unit) : (BitVec 11) :=
  (Zeros (n := 11))

/-- Type quantifiers: k_d_side : Bool -/
def AArch32_FaultSyndrome (d_side : Bool) (fault : FaultRecord) : SailM (BitVec 25) := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13640.41-13640.42"
  let iss : (BitVec 25) := (Zeros (n := 25))
  let iss2 : (BitVec 24) := (Zeros (n := 24))
  let iss ← (( do
    (if ((←((HaveRASExt ()) <&&> (do
         (IsAsyncAbort__1 fault)))) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange iss 11 10 (← (AArch32_EncodeAsyncErrorSyndrome errstate)))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss ← (( do
    (if (d_side : Bool)
    then
      (do let iss ← (( do
            (if ((←((pure ((← (IsSecondStage fault)) && (! fault.s2fs1walk))) <&&> (do
                 (pure (! (← (IsExternalSyncAbort__1 fault)))) <||> (do
                   (pure ((! (← (HaveRASExt ()))) && (BEq.beq fault.access.acctype AccessType_TTW))) <&&> (do
                     (__IMPDEF_boolean "ISV on second stage translation table walk")))))) : Bool)
            then (do (pure (Sail.BitVec.updateSubrange iss 24 14 (LSInstructionSyndrome ()))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss : (BitVec 25) :=
            if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (BitVec.update iss 8 (Bit 1#1))
            else iss
          (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
          then (do (pure (BitVec.update iss 6 (Bit 1#1))))
          else
            (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
                then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                else
                  (do (if ((←((pure fault.access.atomicop) <&&> (do
                           (IsExternalAbort__1 fault)))) : Bool)
                      then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                      else
                        (do (pure (BitVec.update iss 6
                                (Bit
                                  (if (fault.write : Bool)
                                  then 1#1
                                  else 0#1)))))))))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update iss 9 (Bit fault.extflag))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss : (BitVec 25) :=
    (BitVec.update iss 7
      (Bit
        (if (fault.s2fs1walk : Bool)
        then 1#1
        else 0#1)))
  (pure (Sail.BitVec.updateSubrange iss 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))

def IPAValid (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13675.41-13675.42"
  (if ((bne fault.gpcf.gpf GPCF_None) : Bool)
  then (do (pure fault.secondstage))
  else
    (do (if (fault.s2fs1walk : Bool)
        then (do (pure ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Permission) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_AddressSize))))))
        else
          (do (if (fault.secondstage : Bool)
              then (do (pure ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_AddressSize)))))
              else (do (pure false)))))))

def AArch32_AbortSyndrome (exceptype : Exception) (fault : FaultRecord) (vaddress : (BitVec 32)) (target_el : (BitVec 2)) : SailM ExceptionRecord := do
  let except ← (( do (ExceptionSyndrome exceptype) ) : SailM ExceptionRecord )
  let d_side : Bool := (BEq.beq exceptype Exception_DataAbort)
  let except ← (pure { except with syndrome := (← do (AArch32_FaultSyndrome d_side fault)) })
  let except : ExceptionRecord := { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }
  (if ((← (IPAValid fault)) : Bool)
  then
    (do let except : ExceptionRecord := { except with ipavalid := true }
        let except : ExceptionRecord :=
          { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
            then 1#1
            else 0#1 }
        (pure { except with ipaddress := (Sail.BitVec.zeroExtend fault.ipaddress.address 56) }))
  else (do (pure { except with ipavalid := false })))

def AArch32_ExceptionClass (exceptype : Exception) : SailM (Int × (BitVec 1)) := do
  let il_is_valid : Bool := true
  let ec ← (( do (undefined_int ()) ) : SailM Int )
  let (ec, il_is_valid) ← (( do
    match exceptype with
    | .Exception_Uncategorized =>
      (let ec : Int := (BitVec.toNat 0x00#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_WFxTrap =>
      (let ec : Int := (BitVec.toNat 0x01#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP15RTTrap =>
      (let ec : Int := (BitVec.toNat 0x03#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP15RRTTrap =>
      (let ec : Int := (BitVec.toNat 0x04#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14RTTrap =>
      (let ec : Int := (BitVec.toNat 0x05#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14DTTrap =>
      (let ec : Int := (BitVec.toNat 0x06#8)
      (pure (ec, il_is_valid)))
    | .Exception_AdvSIMDFPAccessTrap =>
      (let ec : Int := (BitVec.toNat 0x07#8)
      (pure (ec, il_is_valid)))
    | .Exception_FPIDTrap =>
      (let ec : Int := (BitVec.toNat 0x08#8)
      (pure (ec, il_is_valid)))
    | .Exception_PACTrap =>
      (let ec : Int := (BitVec.toNat 0x09#8)
      (pure (ec, il_is_valid)))
    | .Exception_TSTARTAccessTrap =>
      (let ec : Int := (BitVec.toNat 0x1B#8)
      (pure (ec, il_is_valid)))
    | .Exception_GPC =>
      (let ec : Int := (BitVec.toNat 0x1E#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14RRTTrap =>
      (let ec : Int := (BitVec.toNat 0x0C#8)
      (pure (ec, il_is_valid)))
    | .Exception_BranchTarget =>
      (let ec : Int := (BitVec.toNat 0x0D#8)
      (pure (ec, il_is_valid)))
    | .Exception_IllegalState =>
      (let ec : Int := (BitVec.toNat 0x0E#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_SupervisorCall =>
      (let ec : Int := (BitVec.toNat 0x11#8)
      (pure (ec, il_is_valid)))
    | .Exception_HypervisorCall =>
      (let ec : Int := (BitVec.toNat 0x12#8)
      (pure (ec, il_is_valid)))
    | .Exception_MonitorCall =>
      (let ec : Int := (BitVec.toNat 0x13#8)
      (pure (ec, il_is_valid)))
    | .Exception_InstructionAbort =>
      (let ec : Int := (BitVec.toNat 0x20#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_PCAlignment =>
      (let ec : Int := (BitVec.toNat 0x22#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_DataAbort =>
      (let ec : Int := (BitVec.toNat 0x24#8)
      (pure (ec, il_is_valid)))
    | .Exception_NV2DataAbort =>
      (let ec : Int := (BitVec.toNat 0x25#8)
      (pure (ec, il_is_valid)))
    | .Exception_FPTrappedException =>
      (let ec : Int := (BitVec.toNat 0x28#8)
      (pure (ec, il_is_valid)))
    | _ =>
      (do
        (Unreachable ())
        (pure (ec, il_is_valid))) ) : SailM (Int × Bool) )
  let ec ← (( do
    (if ((←((pure ((ec == (BitVec.toNat 0x20#8)) || ((ec == (BitVec.toNat 0x24#8)) : Bool))) <&&> (do
         (pure ((← readReg PSTATE).EL == EL2))))) : Bool)
    then (do (pure (ec +i 1)))
    else (do (pure ec))) ) : SailM Int )
  let ec := ec
  let il ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let il ← (( do
    (if (il_is_valid : Bool)
    then
      (do (if (((← (ThisInstrLength ())) == 32) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))))
    else (do (pure 1#1))) ) : SailM (BitVec 1) )
  (pure (ec, il))

def HDFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HDFAR_Type := value_name
  writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HDFAR r

def HIFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HIFAR_Type := value_name
  writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 63 32 (BitVec.slice r 0 32))
  writeReg _HIFAR r

def undefined_HPFAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HPFAR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HPFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HPFAR ) : SailM HPFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HPFAR_EL2) 0 32)))

def HPFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HPFAR_Type := value_name
  writeReg HPFAR_EL2 (Sail.BitVec.updateSubrange (← readReg HPFAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HPFAR r

def undefined_HSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSR_Type := value_name
  writeReg ESR_EL2 (Sail.BitVec.updateSubrange (← readReg ESR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSR r

def AArch32_ReportHypEntry (except : ExceptionRecord) : SailM Unit := do
  let ec ← (( do (undefined_int ()) ) : SailM Int )
  let il ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let exceptype : Exception := except.exceptype
  let (ec, il) ← (( do
    let (tup__0, tup__1) ← do (AArch32_ExceptionClass exceptype)
    let ec : Int := tup__0
    let il : (BitVec 1) := tup__1
    (pure (ec, il)) ) : SailM (Int × (BitVec 1)) )
  let ec := ec
  let iss : (BitVec 25) := except.syndrome
  let iss2 : (BitVec 24) := except.syndrome2
  let il : (BitVec 1) :=
    if ((((ec == (BitVec.toNat 0x24#8)) || ((ec == (BitVec.toNat 0x25#8)) : Bool)) && (((BitVec.access iss 24) : BitVec 1) == 0#1)) : Bool)
    then 1#1
    else il
  let il := il
  (HSR_write (Mk_HSR_Type (((integer_subrange ec 5 0) +++ il) +++ iss)))
  (if (((BEq.beq exceptype Exception_InstructionAbort) || (BEq.beq exceptype Exception_PCAlignment)) : Bool)
  then
    (do (HIFAR_write (Sail.BitVec.extractLsb except.vaddress 31 0))
        (HDFAR_write (← (__UNKNOWN_bits 32))))
  else
    (do (if ((BEq.beq exceptype Exception_DataAbort) : Bool)
        then
          (do (HIFAR_write (← (__UNKNOWN_bits 32)))
              (HDFAR_write (Sail.BitVec.extractLsb except.vaddress 31 0)))
        else (do (pure ())))))
  (if (except.ipavalid : Bool)
  then (do (HPFAR_write (Mk_HPFAR_Type (Sail.BitVec.updateSubrange (← (HPFAR_read ())) 31 4 (Sail.BitVec.extractLsb except.ipaddress 39 12)))))
  else (do (HPFAR_write (Mk_HPFAR_Type (Sail.BitVec.updateSubrange (← (HPFAR_read ())) 31 4 (← (__UNKNOWN_bits 28)))))))

def ELR_hyp_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ELR_hyp_Type := value_name
  writeReg ELR_EL2 (Sail.BitVec.updateSubrange (← readReg ELR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ELR_hyp r

def AArch32_EnterHypModeInDebugState (except : ExceptionRecord) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL2)) <&&> (do
    (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))) <&&> (do
    (ELUsingAArch32 EL2)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13905.87-13905.88"
  (AArch32_ReportHypEntry except)
  (AArch32_WriteMode M32_Hyp)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (ELR_hyp_write (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def HVBAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HVBAR ) : SailM HVBAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VBAR_EL2) 0 32)))

/-- Type quantifiers: vect_offset : Int -/
def AArch32_EnterHypMode (except : ExceptionRecord) (preferred_exception_return : (BitVec 32)) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL2)) <&&> (do
    (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))) <&&> (do
    (ELUsingAArch32 EL2)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13942.87-13942.88"
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterHypModeInDebugState except))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if ((! ((BEq.beq except.exceptype Exception_IRQ) || (BEq.beq except.exceptype Exception_FIQ))) : Bool)
        then (do (AArch32_ReportHypEntry except))
        else (do (pure ())))
        (AArch32_WriteMode M32_Hyp)
        (SPSR_set (N := 32) spsr)
        (ELR_hyp_write preferred_exception_return)
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_HSCTLR_Type_TE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_EA (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with A := 1#1 })
        else (do (pure ())))
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_IRQ (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with I := 1#1 })
        else (do (pure ())))
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_FIQ (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with F := 1#1 })
        else (do (pure ())))
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_HSCTLR_Type_DSSBS (← (HSCTLR_read ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← (HVBAR_read ())) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

/-- Type quantifiers: n : Int -/
def Rmode_set (n : Int) (mode : (BitVec 5)) (value_name : (BitVec 32)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 14)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13980.27-13980.28"
  (if ((bne (← (CurrentSecurityState ())) SS_Secure) : Bool)
  then (do sail_assert (mode != M32_Monitor) "sail-arm/arm-v9.4-a/src/v8_base.sail:13982.34-13982.35")
  else (do (pure ())))
  sail_assert (! (← (BadMode mode))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13984.34-13984.35"
  (if ((mode == M32_Monitor) : Bool)
  then
    (do (if ((n == 13) : Bool)
        then (do writeReg SP_mon value_name)
        else
          (do (if ((n == 14) : Bool)
              then (do writeReg LR_mon value_name)
              else (do (set_R_bits n 31 0 value_name))))))
  else
    (do (if ((←((HaveAArch64 ()) <&&> (do
             (ConstrainUnpredictableBool Unpredictable_ZEROUPPER)))) : Bool)
        then (do (set_R (← (LookUpRIndex n mode)) (Sail.BitVec.zeroExtend value_name 64)))
        else (do (set_R_bits (← (LookUpRIndex n mode)) 31 0 value_name)))))

/-- Type quantifiers: n : Int -/
def R_set (n : Int) (value_name : (BitVec 32)) : SailM Unit := do
  (Rmode_set n (← readReg PSTATE).M value_name)

def AArch32_EnterModeInDebugState (target_mode : (BitVec 5)) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((ELUsingAArch32 EL1) <&&> (do
    (pure ((← readReg PSTATE).EL != EL2))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14014.49-14014.50"
  (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
  then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else (do (pure ())))
  (AArch32_WriteMode target_mode)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (R_set 14 (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((←((HavePANExt ()) <&&> (do
       (pure ((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1))))) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
  else (do (pure ())))
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def ExcVectorBase (_ : Unit) : SailM (BitVec 32) := do
  (if (((_get_SCTLR_Type_V (← (SCTLR_read__2 ()))) == 1#1) : Bool)
  then (do (pure ((Ones (n := 16)) +++ (Zeros (n := 16)))))
  else (do (pure ((Sail.BitVec.extractLsb (← (VBAR_read__2 ())) 31 5) +++ (Zeros (n := 5))))))

/-- Type quantifiers: lr_offset : Int, vect_offset : Int -/
def AArch32_EnterMode (target_mode : (BitVec 5)) (preferred_exception_return : (BitVec 32)) (lr_offset : Int) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((ELUsingAArch32 EL1) <&&> (do
    (pure ((← readReg PSTATE).EL != EL2))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14054.49-14054.50"
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterModeInDebugState target_mode))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
        then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
        else (do (pure ())))
        (AArch32_WriteMode target_mode)
        (SPSR_set (N := 32) spsr)
        (R_set 14 (BitVec.addInt preferred_exception_return lr_offset))
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        (if ((target_mode == M32_FIQ) : Bool)
        then
          (do writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) })
        else
          (do (if (((target_mode == M32_Abort) || (target_mode == M32_IRQ)) : Bool)
              then
                (do writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b11#2 1 1) }
                    writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b11#2 0 0) })
              else (do writeReg PSTATE { (← readReg PSTATE) with I := 1#1 }))))
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((←((HavePANExt ()) <&&> (do
             (pure ((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
        else (do (pure ())))
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_SCTLR_Type_DSSBS (← (SCTLR_read__2 ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← (ExcVectorBase ())) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

def AArch32_EnterMonitorModeInDebugState (_ : Unit) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL3)) <&&> (do
    (ELUsingAArch32 EL3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14094.44-14094.45"
  let from_secure ← (( do (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) ) : SailM Bool )
  (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
  then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else (do (pure ())))
  (AArch32_WriteMode M32_Monitor)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (R_set 14 (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((← (HavePANExt ())) : Bool)
  then
    (do (if ((! from_secure) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 0#1 })
        else
          (do (if (((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def undefined_MVBAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_MVBAR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

/-- Type quantifiers: lr_offset : Int, vect_offset : Int -/
def AArch32_EnterMonitorMode (preferred_exception_return : (BitVec 32)) (lr_offset : Int) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL3)) <&&> (do
    (ELUsingAArch32 EL3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14133.44-14133.45"
  let from_secure ← (( do (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) ) : SailM Bool )
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterMonitorModeInDebugState ()))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
        then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
        else (do (pure ())))
        (AArch32_WriteMode M32_Monitor)
        (SPSR_set (N := 32) spsr)
        (R_set 14 (BitVec.addInt preferred_exception_return lr_offset))
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((← (HavePANExt ())) : Bool)
        then
          (do (if ((! from_secure) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 0#1 })
              else
                (do (if (((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_SCTLR_Type_DSSBS (← (SCTLR_read__2 ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← readReg MVBAR) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

/-- Type quantifiers: level : Int -/
def EncodeSDFSC (statuscode : Fault) (level : Int) : SailM (BitVec 5) := do
  let result ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  match statuscode with
  | .Fault_AccessFlag =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14174.40-14174.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b00011#5))
      else (do (pure 0b00110#5))))
  | .Fault_Alignment => (pure 0b00001#5)
  | .Fault_Permission =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14181.40-14181.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01101#5))
      else (do (pure 0b01111#5))))
  | .Fault_Domain =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14185.40-14185.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01001#5))
      else (do (pure 0b01011#5))))
  | .Fault_Translation =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14189.40-14189.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b00101#5))
      else (do (pure 0b00111#5))))
  | .Fault_SyncExternal => (pure 0b01000#5)
  | .Fault_SyncExternalOnWalk =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14196.40-14196.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01100#5))
      else (do (pure 0b01110#5))))
  | .Fault_SyncParity => (pure 0b11001#5)
  | .Fault_SyncParityOnWalk =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14203.40-14203.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b11100#5))
      else (do (pure 0b11110#5))))
  | .Fault_AsyncParity => (pure 0b11000#5)
  | .Fault_AsyncExternal => (pure 0b10110#5)
  | .Fault_Debug => (pure 0b00010#5)
  | .Fault_TLBConflict => (pure 0b10000#5)
  | .Fault_Lockdown => (pure 0b10100#5)
  | .Fault_Exclusive => (pure 0b10101#5)
  | .Fault_ICacheMaint => (pure 0b00100#5)
  | _ =>
    (do
      (Unreachable ())
      (pure result))

/-- Type quantifiers: k_long_format : Bool -/
def AArch32_CommonFaultStatus (fault : FaultRecord) (long_format : Bool) : SailM (BitVec 32) := do
  let target : (BitVec 32) := (Zeros (n := 32))
  let target ← (( do
    (if ((←((HaveRASExt ()) <&&> (do
         (IsAsyncAbort__1 fault)))) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange target 15 14 (← (AArch32_EncodeAsyncErrorSyndrome errstate)))))
    else (do (pure target))) ) : SailM (BitVec 32) )
  let target ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update target 12 (Bit fault.extflag))))
    else (do (pure target))) ) : SailM (BitVec 32) )
  let target : (BitVec 32) :=
    (BitVec.update target 9
      (Bit
        (if (long_format : Bool)
        then 1#1
        else 0#1)))
  (if (long_format : Bool)
  then (do (pure (Sail.BitVec.updateSubrange target 5 0 (← (EncodeLDFSC fault.statuscode fault.level)))))
  else
    (do let split_vec ← do (EncodeSDFSC fault.statuscode fault.level)
        let target : (BitVec 32) := (Sail.BitVec.updateSubrange target 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
        (pure (Sail.BitVec.updateSubrange target 3 0 (Sail.BitVec.extractLsb split_vec 3 0)))))

def DFAR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  writeReg FAR_EL1 (Sail.BitVec.updateSubrange (← readReg FAR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DFAR_NS r

def HDFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HDFAR ) : SailM HDFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FAR_EL2) 0 32)))

def DFAR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  (HDFAR_write (set_slice 32 (← (HDFAR_read ())) 0 (BitVec.slice r 0 32)))
  writeReg _DFAR_S r

def DFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (DFAR_S_write r))
  else (do (DFAR_NS_write r)))

def undefined_DFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_VDFSR_Type_AET (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VSESR_EL2_Type_AET (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VDFSR_Type_ExT (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_VSESR_EL2_Type_ExT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def DFSR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFSR_Type := value_name
  writeReg ESR_EL1 (Sail.BitVec.updateSubrange (← readReg ESR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DFSR_NS r

def DFSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFSR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg DFSR_S r)
  else (do (DFSR_NS_write r)))

def undefined_IFSR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_IFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_IFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def IFSR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFSR_Type := value_name
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _IFSR_NS r

def IFSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFSR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg IFSR_S r)
  else (do (IFSR_NS_write r)))

/-- Type quantifiers: k_route_to_monitor : Bool -/
def AArch32_ReportDataAbort (route_to_monitor : Bool) (fault : FaultRecord) (vaddress : (BitVec 32)) : SailM Unit := do
  let long_format ← (( do (undefined_bool ()) ) : SailM Bool )
  let long_format ← (( do
    (if ((←((pure route_to_monitor) <&&> (do
         (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
    then (do (pure ((_get_TTBCR_Type_EAE (← readReg TTBCR_S)) == 1#1)) <||> (do (IsExternalSyncAbort__1 fault) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1))) <||> (do (pure fault.secondstage) <&&> (do (__IMPDEF_boolean "Report abort using Long-descriptor format"))))))
    else (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)))) ) : SailM Bool )
  let syndrome ← (( do (AArch32_CommonFaultStatus fault long_format) ) : SailM (BitVec 32) )
  let syndrome : (BitVec 32) :=
    if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then
      (let syndrome : (BitVec 32) := (BitVec.update syndrome 13 (Bit 1#1))
      (BitVec.update syndrome 11 (Bit 1#1)))
    else
      (BitVec.update syndrome 11
        (Bit
          (if (fault.write : Bool)
          then 1#1
          else 0#1)))
  let syndrome : (BitVec 32) :=
    if ((! long_format) : Bool)
    then (Sail.BitVec.updateSubrange syndrome 7 4 fault.domain)
    else syndrome
  let syndrome ← (( do
    (if ((BEq.beq fault.access.acctype AccessType_IC) : Bool)
    then
      (do let i_syndrome ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
          let (i_syndrome, syndrome) ← (( do
            (if ((←((pure (! long_format)) <&&> (do
                 (__IMPDEF_boolean "Report I-cache maintenance fault in IFSR")))) : Bool)
            then
              (do let i_syndrome : (BitVec 32) := syndrome
                  let split_vec ← do (EncodeSDFSC Fault_ICacheMaint 1)
                  let syndrome : (BitVec 32) := (Sail.BitVec.updateSubrange syndrome 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
                  let syndrome : (BitVec 32) := (Sail.BitVec.updateSubrange syndrome 3 0 (Sail.BitVec.extractLsb split_vec 3 0))
                  (pure (i_syndrome, syndrome)))
            else
              (do let i_syndrome ← (__UNKNOWN_bits 32)
                  (pure (i_syndrome, syndrome)))) ) : SailM ((BitVec 32) × (BitVec 32)) )
          (if (route_to_monitor : Bool)
          then (do writeReg IFSR_S (Mk_IFSR_Type i_syndrome))
          else (do (IFSR_write (Mk_IFSR_Type i_syndrome))))
          (pure syndrome))
    else (do (pure syndrome))) ) : SailM (BitVec 32) )
  (if (route_to_monitor : Bool)
  then
    (do writeReg DFSR_S (Mk_DFSR_Type syndrome)
        (DFAR_S_write vaddress))
  else
    (do (DFSR_write (Mk_DFSR_Type syndrome))
        (DFAR_write vaddress)))

def undefined_DBGDSCRext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGDSCRext_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_DBGDSCRext_Type_MDBGen (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_DBGDSCRext_Type_MOE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 2 x)

def _update_DBGDSCRext_Type_UDCCdis (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def undefined_DBGDSCRint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGDSCRint_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGDSCRint_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDSCRint ) : SailM DBGDSCRint_Type )
  let r ← (pure (Sail.BitVec.updateSubrange r 30 29 (BitVec.slice (← readReg MDCCSR_EL0) 29 2)))
  let r ← (pure (BitVec.update r 15 (Bit (BitVec.slice (← readReg MDSCR_EL1) 15 1))))
  let r ← (pure (BitVec.update r 12 (Bit (BitVec.slice (← readReg MDSCR_EL1) 12 1))))
  (pure (Sail.BitVec.updateSubrange r 5 2 (BitVec.slice (← readReg MDSCR_EL1) 2 4)))

def DBGDSCRext_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDSCRext ) : SailM DBGDSCRext_Type )
  let r ← (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDSCR_EL1) 0 32)))
  let r ← (pure (BitVec.update r 15 (Bit (BitVec.slice (← (DBGDSCRint_read ())) 15 1))))
  let r ← (pure (BitVec.update r 12 (Bit (BitVec.slice (← (DBGDSCRint_read ())) 12 1))))
  (pure (Sail.BitVec.updateSubrange r 5 2 (BitVec.slice (← (DBGDSCRint_read ())) 2 4)))

def DBGDSCRint_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDSCRint_Type := value_name
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 29 (BitVec.slice r 29 2))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 15 (Bit (BitVec.slice r 15 1)))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 12 (Bit (BitVec.slice r 12 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 5 2 (BitVec.slice r 2 4))
  writeReg _DBGDSCRint r

def DBGDSCRext_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDSCRext_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 31 0 (BitVec.slice r 0 32))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 1 (← (DBGDSCRint_read ())) 15 (BitVec.slice r 15 1))))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 1 (← (DBGDSCRint_read ())) 12 (BitVec.slice r 12 1))))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 4 (← (DBGDSCRint_read ())) 2 (BitVec.slice r 2 4))))
  writeReg _DBGDSCRext r

def undefined_HCR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HCR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCR2 ) : SailM HCR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HCR_EL2) 32 32)))

def IsDebugException (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:14522.41-14522.42"
  (pure (BEq.beq fault.statuscode Fault_Debug))

def AArch32_TakeDataAbortException (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))) <&&> (do (IsExternalAbort__1 fault)) ) : SailM Bool )
  let route_to_hyp ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR2_Type_TEA (← (HCR2_read ()))) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_HDCR_Type_TDE (← (HDCR_read ()))) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  (if ((← (IsDebugException fault)) : Bool)
  then (do (DBGDSCRext_write (_update_DBGDSCRext_Type_MOE (← (DBGDSCRext_read ())) fault.debugmoe)))
  else (do (pure ())))
  (if (route_to_monitor : Bool)
  then
    (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (AArch32_AbortSyndrome Exception_DataAbort fault vaddress EL2) ) : SailM ExceptionRecord )
              (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
              (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)))))

def IFAR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  writeReg FAR_EL1 (Sail.BitVec.updateSubrange (← readReg FAR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _IFAR_NS r

def HIFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HIFAR ) : SailM HIFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FAR_EL2) 32 32)))

def IFAR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  (if ((HaveEL EL2) : Bool)
  then (do writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 63 32 (BitVec.slice r 0 32)))
  else (do (HIFAR_write (set_slice 32 (← (HIFAR_read ())) 0 (BitVec.slice r 0 32)))))
  writeReg _IFAR_S r

def IFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (IFAR_S_write r))
  else (do (IFAR_NS_write r)))

/-- Type quantifiers: k_route_to_monitor : Bool -/
def AArch32_ReportPrefetchAbort (route_to_monitor : Bool) (fault : FaultRecord) (vaddress : (BitVec 32)) : SailM Unit := do
  let long_format : Bool := false
  let long_format ← (( do
    (if ((←((pure route_to_monitor) <&&> (do
         (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
    then (do (pure ((_get_TTBCR_Type_EAE (← readReg TTBCR_S)) == 1#1)) <||> (do (pure ((← readReg PSTATE).EL == EL2))) <||> (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1))))
    else (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)))) ) : SailM Bool )
  let fsr ← (( do (AArch32_CommonFaultStatus fault long_format) ) : SailM (BitVec 32) )
  (if (route_to_monitor : Bool)
  then
    (do writeReg IFSR_S (Mk_IFSR_Type fsr)
        (IFAR_S_write vaddress))
  else
    (do (IFSR_write (Mk_IFSR_Type fsr))
        (IFAR_write vaddress)))

def AArch32_TakePrefetchAbortException (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))) <&&> (do (IsExternalAbort__1 fault)) ) : SailM Bool )
  let route_to_hyp ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR2_Type_TEA (← (HCR2_read ()))) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_HDCR_Type_TDE (← (HDCR_read ()))) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x0C#8)
  let lr_offset := 4
  (if ((← (IsDebugException fault)) : Bool)
  then (do (DBGDSCRext_write (_update_DBGDSCRext_Type_MOE (← (DBGDSCRext_read ())) fault.debugmoe)))
  else (do (pure ())))
  (if (route_to_monitor : Bool)
  then
    (do (AArch32_ReportPrefetchAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do
                (if ((BEq.beq fault.statuscode Fault_Alignment) : Bool)
                then
                  (do let except ← (ExceptionSyndrome Exception_PCAlignment)
                      (pure { except with vaddress := (← do (ThisInstrAddr 64)) }))
                else (do (AArch32_AbortSyndrome Exception_InstructionAbort fault vaddress EL2))) ) : SailM ExceptionRecord )
              (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (AArch32_ReportPrefetchAbort route_to_monitor fault vaddress)
              (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)))))

def AArch64_EncodeSyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 2) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b10#2)
  | .ErrorState_UEO => (pure 0b11#2)
  | .ErrorState_UER => (pure 0b00#2)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 2))

def ExtAbortToA64 (fault : FaultRecord) : SailM Bool := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (IsSecondStage fault)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR_EL2_Type_TEA (← readReg HCR_EL2)) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCRType_EA (← (SCR_GEN_read ()))) == 1#1)) <&&> (do (IsExternalAbort__1 fault)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (pure route_to_aarch64) <&&> (do
    (IsExternalSyncAbort fault.statuscode))

def FaultIsCorrected (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsIMPDEF (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUncategorized (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch64_PEErrorState (fault : FaultRecord) : SailM ErrorState := SailME.run do
  (if ((←((pure (! (← (IsExternalSyncAbort__1 fault)))) <&&> (do
       (ExtAbortToA64 fault)))) : Bool)
  then
    (do (if ((← (ReportErrorAsUncategorized ())) : Bool)
        then (do SailME.throw (ErrorState_Uncategorized : ErrorState))
        else
          (do (if ((← (ReportErrorAsIMPDEF ())) : Bool)
              then (do SailME.throw (ErrorState_IMPDEF : ErrorState))
              else (do (pure ()))))))
  else (do (pure ())))
  sail_assert (! (← (FaultIsCorrected ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14707.39-14707.40"
  (if ((←((pure (! (← (ErrorIsContained ())))) <||> (do
       (pure (! (← (ErrorIsSynchronized ())))) <&&> (do
         (pure (! (← (StateIsRecoverable ())))))) <||> (do
       (ReportErrorAsUC ())))) : Bool)
  then (do (pure ErrorState_UC))
  else
    (do (if ((←((pure (! (← (StateIsRecoverable ())))) <||> (do
             (ReportErrorAsUEU ())))) : Bool)
        then
          (do (if ((← (IsExternalSyncAbort__1 fault)) : Bool)
              then (do (pure ErrorState_UC))
              else (do (pure ErrorState_UEU))))
        else
          (do (if ((←((ActionRequired ()) <||> (do
                   (ReportErrorAsUER ())))) : Bool)
              then (do (pure ErrorState_UER))
              else (do (pure ErrorState_UEO)))))))

def HaveFeatLS64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64)

def GetLoadStoreType (_ : Unit) : SailM (BitVec 2) := do
  (__UNKNOWN_bits 2)

def LS64InstructionSyndrome (_ : Unit) : SailM ((BitVec 24) × (BitVec 11)) := do
  (pure ((← (undefined_bitvector 24)), (← (undefined_bitvector 11))))

/-- Type quantifiers: k_d_side : Bool, k_pavalid : Bool -/
def AArch64_FaultSyndrome (d_side : Bool) (fault : FaultRecord) (pavalid : Bool) : SailM ((BitVec 25) × (BitVec 24)) := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:14736.41-14736.42"
  let iss : (BitVec 25) := (Zeros (n := 25))
  let iss2 : (BitVec 24) := (Zeros (n := 24))
  let iss ← (( do
    (if (((← (HaveRASExt ())) && (BEq.beq fault.statuscode Fault_SyncExternal)) : Bool)
    then
      (do let errstate ← (( do (AArch64_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange iss 12 11 (← (AArch64_EncodeSyncErrorSyndrome errstate)))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let (iss, iss2) ← (( do
    (if (d_side : Bool)
    then
      (do let iss2 : (BitVec 24) :=
            if ((BEq.beq fault.access.acctype AccessType_GCS) : Bool)
            then (BitVec.update iss2 8 (Bit 1#1))
            else iss2
          let (iss, iss2) ← (( do
            (if (((← (HaveFeatLS64 ())) && fault.access.ls64) : Bool)
            then
              (do let (iss, iss2) ← (( do
                    (if (((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_Permission))) : Bool)
                    then
                      (do let (tup__0, tup__1) ← do (LS64InstructionSyndrome ())
                          let iss2 : (BitVec 24) := tup__0
                          let iss : (BitVec 25) := (Sail.BitVec.updateSubrange iss 24 14 tup__1)
                          (pure (iss, iss2)))
                    else (do (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
                  (pure (iss, iss2)))
            else
              (do let iss ← (( do
                    (if ((←((pure ((← (IsSecondStage fault)) && (! fault.s2fs1walk))) <&&> (do
                         (pure (! (← (IsExternalSyncAbort__1 fault)))) <||> (do
                           (pure ((! (← (HaveRASExt ()))) && (BEq.beq fault.access.acctype AccessType_TTW))) <&&> (do
                             (__IMPDEF_boolean "ISV on second stage translation table walk")))))) : Bool)
                    then (do (pure (Sail.BitVec.updateSubrange iss 24 14 (LSInstructionSyndrome ()))))
                    else (do (pure iss))) ) : SailM (BitVec 25) )
                  (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
          let iss ← (( do
            (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
            then (do (pure (BitVec.update iss 13 (Bit 1#1))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss ← (( do
            (if (((← (HaveFeatLS64 ())) && ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_Permission)))) : Bool)
            then (do (pure (Sail.BitVec.updateSubrange iss 12 11 (← (GetLoadStoreType ())))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss : (BitVec 25) :=
            if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (BitVec.update iss 8 (Bit 1#1))
            else iss
          let iss ← (( do
            (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (do (pure (BitVec.update iss 6 (Bit 1#1))))
            else
              (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
                  then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                  else
                    (do (if ((←((pure fault.access.atomicop) <&&> (do
                             (IsExternalAbort__1 fault)))) : Bool)
                        then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                        else
                          (do (pure (BitVec.update iss 6
                                  (Bit
                                    (if (fault.write : Bool)
                                    then 1#1
                                    else 0#1)))))))))) ) : SailM (BitVec 25) )
          let (iss, iss2) : ((BitVec 25) × (BitVec 24)) :=
            if ((BEq.beq fault.statuscode Fault_Permission) : Bool)
            then
              (let iss2 : (BitVec 24) :=
                (BitVec.update iss2 5
                  (Bit
                    (if (fault.dirtybit : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 6
                  (Bit
                    (if (fault.overlay : Bool)
                    then 1#1
                    else 0#1)))
              let iss : (BitVec 25) :=
                if ((((BitVec.access iss 24) : BitVec 1) == 0#1) : Bool)
                then
                  (BitVec.update iss 21
                    (Bit
                      (if (fault.toplevel : Bool)
                      then 1#1
                      else 0#1)))
                else iss
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 7
                  (Bit
                    (if (fault.assuredonly : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 9
                  (Bit
                    (if (fault.tagaccess : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 10
                  (Bit
                    (if (fault.s1tagnotdata : Bool)
                    then 1#1
                    else 0#1)))
              (iss, iss2))
            else (iss, iss2)
          (pure (iss, iss2)))
    else
      (do let (iss, iss2) : ((BitVec 25) × (BitVec 24)) :=
            if (((BEq.beq fault.access.acctype AccessType_IFETCH) && (BEq.beq fault.statuscode Fault_Permission)) : Bool)
            then
              (let iss2 : (BitVec 24) :=
                (BitVec.update iss2 5
                  (Bit
                    (if (fault.dirtybit : Bool)
                    then 1#1
                    else 0#1)))
              let iss : (BitVec 25) :=
                (BitVec.update iss 21
                  (Bit
                    (if (fault.toplevel : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 7
                  (Bit
                    (if (fault.assuredonly : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 6
                  (Bit
                    (if (fault.overlay : Bool)
                    then 1#1
                    else 0#1)))
              (iss, iss2))
            else (iss, iss2)
          (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
  let iss ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update iss 9 (Bit fault.extflag))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss : (BitVec 25) :=
    (BitVec.update iss 7
      (Bit
        (if (fault.s2fs1walk : Bool)
        then 1#1
        else 0#1)))
  let iss ← (pure (Sail.BitVec.updateSubrange iss 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))
  (pure (iss, iss2))

def AArch64_AbortSyndrome (exceptype : Exception) (fault : FaultRecord) (vaddress : (BitVec 64)) (target_el : (BitVec 2)) : SailM ExceptionRecord := do
  let except ← (( do (ExceptionSyndrome exceptype) ) : SailM ExceptionRecord )
  let d_side : Bool := ((BEq.beq exceptype Exception_DataAbort) || ((BEq.beq exceptype Exception_NV2DataAbort) || ((BEq.beq exceptype Exception_Watchpoint) || (BEq.beq exceptype Exception_NV2Watchpoint))))
  let except ← (( do
    (if ((←((pure (! (← (HavePFAR ())))) <||> (do
         (pure (! (← (IsExternalSyncAbort__1 fault))))) <||> (do
         (pure ((←((EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))))) && (target_el == EL1)))))) : Bool)
    then (do (pure { except with pavalid := false }))
    else (do (pure { except with pavalid := (← do (__IMPDEF_boolean "PFAR_ELx is valid")) }))) ) : SailM ExceptionRecord )
  let except ← (( do
    let (tup__0, tup__1) ← do (AArch64_FaultSyndrome d_side fault except.pavalid)
    let except : ExceptionRecord := { except with syndrome := tup__0 }
    (pure { except with syndrome2 := tup__1 }) ) : SailM ExceptionRecord )
  let except ← (( do
    (if ((BEq.beq fault.statuscode Fault_TagCheck) : Bool)
    then
      (do (if ((← (HaveMTE4Ext ())) : Bool)
          then (do (pure { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }))
          else (do (pure { except with vaddress := (← do (pure ((← (__UNKNOWN_bits 4)) +++ (Sail.BitVec.extractLsb vaddress 59 0)))) }))))
    else (do (pure { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }))) ) : SailM ExceptionRecord )
  (if ((← (IPAValid fault)) : Bool)
  then
    (do let except : ExceptionRecord := { except with ipavalid := true }
        let except : ExceptionRecord :=
          { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
            then 1#1
            else 0#1 }
        (pure { except with ipaddress := fault.ipaddress.address }))
  else (do (pure { except with ipavalid := false })))

def AArch64_BreakpointException (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:14835.27-14835.28"
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
    then (do (pure EL2))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  let vaddress ← (( do (__UNKNOWN_bits 64) ) : SailM (BitVec 64) )
  let except ← (( do (AArch64_AbortSyndrome Exception_Breakpoint fault vaddress target_el) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def HaveDoubleFault2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleFault2)

def HaveFeatSCTLR2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SCTLR2)

def IsSCTLR2EL1Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatSCTLR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_SCTLR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_SCTLR2En (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (pure true)))))))

def IsSCTLR2EL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatSCTLR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_SCTLR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def undefined_SCTLR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SCTLR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_SCTLR2_EL2_Type_EMEC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR2_EL3_Type_EMEC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def AArch64_RouteToSErrorOffset (target_el : (BitVec 2)) : SailM Bool := do
  (if ((! (← (HaveDoubleFaultExt ()))) : Bool)
  then (do (pure false))
  else
    (do let ease_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let ease_bit ← (( do
          let questionMark := target_el
          (if ((questionMark == EL3) : Bool)
          then (do (pure (_get_SCR_EL3_Type_EASE (← readReg SCR_EL3))))
          else
            (do (if ((questionMark == EL2) : Bool)
                then
                  (do (if ((←((HaveDoubleFault2Ext ()) <&&> (do
                           (IsSCTLR2EL2Enabled ())))) : Bool)
                      then (do (pure (_get_SCTLR2_EL2_Type_EASE (← readReg SCTLR2_EL2))))
                      else (do (pure 0#1))))
                else
                  (do (if ((questionMark == EL1) : Bool)
                      then
                        (do (if ((←((HaveDoubleFault2Ext ()) <&&> (do
                                 (IsSCTLR2EL1Enabled ())))) : Bool)
                            then (do (pure (_get_SCTLR2_EL1_Type_EASE (← readReg SCTLR2_EL1))))
                            else (do (pure 0#1))))
                      else (do (pure ease_bit))))))) ) : SailM (BitVec 1) )
        (pure (ease_bit == 1#1))))

def AArch64_SyncExternalAbortTarget (fault : FaultRecord) : SailM (BitVec 2) := do
  let route_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el3 ← (( do
    (if (((← readReg PSTATE).EL != EL3) : Bool)
    then (do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))))
    else (do (pure false))) ) : SailM Bool )
  let tea_bit ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure (_get_HCR_EL2_Type_TEA (← readReg HCR_EL2))))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el2 ← (( do
    (if ((←((pure (! route_to_el3)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
    then (do (pure ((tea_bit == 1#1) || (BEq.beq fault.access.acctype AccessType_NV2))) <||> (do (IsSecondStage fault)))
    else
      (do (if ((←((pure (! route_to_el3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then (do (pure (! (← (IsInHost ())))) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1) || (tea_bit == 1#1))) <||> (do (IsSecondStage fault))))
          else (do (pure false))))) ) : SailM Bool )
  let route_masked_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_masked_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (route_masked_to_el2, route_masked_to_el3) ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let route_masked_to_el2 ← (pure ((← (EL2Enabled ())) && (! route_to_el3))) <&&> (do (pure ((← readReg PSTATE).EL == EL1)) <&&> (do (pure ((← readReg PSTATE).A == 1#1)))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_TMEA (← readReg HCRX_EL2)) == 1#1)))
          let route_masked_to_el3 ← (pure ((HaveEL EL3) && (! (route_to_el2 || route_masked_to_el2)))) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure ((← readReg PSTATE).A == 1#1)))) <&&> (do (pure ((_get_SCR_EL3_Type_TMEA (← readReg SCR_EL3)) == 1#1)))
          (pure (route_masked_to_el2, route_masked_to_el3)))
    else
      (do let route_masked_to_el2 : Bool := false
          let route_masked_to_el3 : Bool := false
          (pure (route_masked_to_el2, route_masked_to_el3)))) ) : SailM (Bool × Bool) )
  let take_in_el3 ← (( do (pure ((← readReg PSTATE).EL == EL3)) ) : SailM Bool )
  let take_in_el2_0 ← (( do (pure ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do (IsInHost ())))) && (! (route_to_el3 || route_masked_to_el3)))) ) : SailM Bool )
  let take_in_el1_0 ← (( do (pure (((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (IsInHost ())))))))) && (! (route_to_el2 || route_masked_to_el2))) && (! (route_to_el3 || route_masked_to_el3)))) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  (if (((take_in_el3 || route_to_el3) || route_masked_to_el3) : Bool)
  then (do (pure EL3))
  else
    (do (if (((take_in_el2_0 || route_to_el2) || route_masked_to_el2) : Bool)
        then (do (pure EL2))
        else
          (do (if (take_in_el1_0 : Bool)
              then (do (pure EL1))
              else
                (do sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:14970.20-14970.21"
                    throw Error.Exit))))))

def take_exception (fault : (Option FaultRecord)) : SailM Unit := do
  (sail_take_exception fault)

def AArch64_DataAbort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (AArch64_SyncExternalAbortTarget fault))
    else
      (do let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((← (HaveRME ())) && (BEq.beq fault.gpcf.gpf GPCF_Fail))) <&&> (do (pure ((_get_HCR_EL2_Type_GPF (← readReg HCR_EL2)) == 1#1)))) <||> (do (pure ((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL3) : Bool)
          then (do (pure EL3))
          else
            (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
                then (do (pure EL2))
                else (do (pure EL1))))))) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (AArch64_AbortSyndrome Exception_NV2DataAbort fault vaddress target_el))
    else (do (AArch64_AbortSyndrome Exception_DataAbort fault vaddress target_el))) ) : SailM ExceptionRecord )
  (take_exception (some fault))
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_InstructionAbort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (HaveDoubleFaultExt ())) : Bool)
  then (do sail_assert (bne fault.statuscode Fault_AsyncExternal) "sail-arm/arm-v9.4-a/src/v8_base.sail:15017.54-15017.55")
  else (do (pure ())))
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (AArch64_SyncExternalAbortTarget fault))
    else
      (do let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((← (HaveRME ())) && (BEq.beq fault.gpcf.gpf GPCF_Fail))) <&&> (do (pure ((_get_HCR_EL2_Type_GPF (← readReg HCR_EL2)) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL3) : Bool)
          then (do (pure EL3))
          else
            (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
                then (do (pure EL2))
                else (do (pure EL1))))))) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  let except ← (( do (AArch64_AbortSyndrome Exception_InstructionAbort fault vaddress target_el) ) : SailM ExceptionRecord )
  (take_exception (some fault))
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_VectorCatchException (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL2) "sail-arm/arm-v9.4-a/src/v8_base.sail:15048.27-15048.28"
  sail_assert (←((EL2Enabled ()) <&&> (do
    (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do
      (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15049.70-15049.71"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let vaddress ← (( do (__UNKNOWN_bits 64) ) : SailM (BitVec 64) )
  let except ← (( do (AArch64_AbortSyndrome Exception_VectorCatch fault vaddress EL2) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL2 except preferred_exception_return vect_offset)

def AArch64_WatchpointException (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:15060.27-15060.28"
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
    then (do (pure EL2))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (AArch64_AbortSyndrome Exception_NV2Watchpoint fault vaddress target_el))
    else (do (AArch64_AbortSyndrome Exception_Watchpoint fault vaddress target_el))) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def ReportAsGPCException (fault : FaultRecord) : SailM Bool := do
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15078.20-15078.21"
  sail_assert ((BEq.beq fault.statuscode Fault_GPCFOnWalk) || (BEq.beq fault.statuscode Fault_GPCFOnOutput)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15079.88-15079.89"
  sail_assert (bne fault.gpcf.gpf GPCF_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:15080.38-15080.39"
  match fault.gpcf.gpf with
  | .GPCF_Walk => (pure true)
  | .GPCF_AddressSize => (pure true)
  | .GPCF_EABT => (pure true)
  | .GPCF_Fail => (pure ((_get_SCR_EL3_Type_GPF (← readReg SCR_EL3)) == 1#1)) <&&> (do (pure ((← readReg PSTATE).EL != EL3)))
  | _ => (do (undefined_bool ()))

def EncodeGPCSC (gpcf : GPCFRecord) : SailM (BitVec 6) := do
  sail_assert ((gpcf.level == 0) || (gpcf.level == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15103.44-15103.45"
  match gpcf.gpf with
  | .GPCF_AddressSize => (pure (0b00000#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_Walk => (pure (0b00010#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_Fail => (pure (0b00110#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_EABT => (pure (0b01010#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | _ => (do (undefined_bitvector 6))

def HaveAccessFlagUpdateExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFDBS)

def HaveAtomicExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE)

def HaveDirtyBitModifierExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFDBS)

def TakeGPCException (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15144.20-15144.21"
  sail_assert (← (HaveAtomicExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15145.26-15145.27"
  sail_assert (← (HaveAccessFlagUpdateExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15146.36-15146.37"
  sail_assert (← (HaveDirtyBitModifierExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15147.36-15147.37"
  sail_assert (← (HaveDoubleFaultExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15148.31-15148.32"
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with exceptype := Exception_GPC }
  let except : ExceptionRecord := { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }
  let except : ExceptionRecord := { except with paddress := fault.paddress }
  let except : ExceptionRecord := { except with pavalid := true }
  let except ← (( do
    (if ((← (IPAValid fault)) : Bool)
    then
      (do let except : ExceptionRecord := { except with ipavalid := true }
          let except : ExceptionRecord :=
            { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
              then 1#1
              else 0#1 }
          (pure { except with ipaddress := fault.ipaddress.address }))
    else (do (pure { except with ipavalid := false }))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord :=
    if ((BEq.beq fault.access.acctype AccessType_GCS) : Bool)
    then { except with syndrome2 := (BitVec.update except.syndrome2 8 (Bit 1#1)) }
    else except
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 22 (Zeros (n := 3))) }
  let except : ExceptionRecord :=
    { except with syndrome := (BitVec.update except.syndrome 21
        (Bit
          (if (fault.gpcfs2walk : Bool)
          then 1#1
          else 0#1))) }
  let except : ExceptionRecord :=
    if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
    then { except with syndrome := (BitVec.update except.syndrome 20 (Bit 1#1)) }
    else { except with syndrome := (BitVec.update except.syndrome 20 (Bit 0#1)) }
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 19 14 (← (EncodeGPCSC fault.gpcf))))) })
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (pure { except with syndrome := (BitVec.update except.syndrome 13 (Bit 1#1)) }))
    else (do (pure { except with syndrome := (BitVec.update except.syndrome 13 (Bit 0#1)) }))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 12 11 0b00#2) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 10 9 0b00#2) }
  let except : ExceptionRecord :=
    if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then { except with syndrome := (BitVec.update except.syndrome 8 (Bit 1#1)) }
    else { except with syndrome := (BitVec.update except.syndrome 8 (Bit 0#1)) }
  let except : ExceptionRecord :=
    { except with syndrome := (BitVec.update except.syndrome 7
        (Bit
          (if (fault.s2fs1walk : Bool)
          then 1#1
          else 0#1))) }
  let except ← (( do
    (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then (do (pure { except with syndrome := (BitVec.update except.syndrome 6 (Bit 1#1)) }))
    else
      (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
          then (do (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 6 (Bit (← (__UNKNOWN_bit ())))))) }))
          else
            (do (if ((←((pure fault.access.atomicop) <&&> (do
                     (IsExternalAbort__1 fault)))) : Bool)
                then (do (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 6 (Bit (← (__UNKNOWN_bit ())))))) }))
                else
                  (do (pure { except with syndrome := (BitVec.update except.syndrome 6
                            (Bit
                              (if (fault.write : Bool)
                              then 1#1
                              else 0#1))) }))))))) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))) })
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let target_el : (BitVec 2) := EL3
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_Abort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  (if ((← (IsDebugException fault)) : Bool)
  then
    (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
        then
          (do (if (((← (UsingAArch32 ())) && (fault.debugmoe == DebugException_VectorCatch)) : Bool)
              then (do (AArch64_VectorCatchException fault))
              else (do (AArch64_BreakpointException fault))))
        else (do (AArch64_WatchpointException vaddress fault))))
  else
    (do (if ((←((pure (bne fault.gpcf.gpf GPCF_None)) <&&> (do
             (ReportAsGPCException fault)))) : Bool)
        then (do (TakeGPCException vaddress fault))
        else
          (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
              then (do (AArch64_InstructionAbort vaddress fault))
              else (do (AArch64_DataAbort vaddress fault)))))))

def AArch32_Abort (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (IsSecondStage fault)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR_EL2_Type_TEA (← readReg HCR_EL2)) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 1#1)) <&&> (do (IsExternalAbort__1 fault)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_Abort (Sail.BitVec.zeroExtend vaddress 64) fault))
  else
    (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
        then (do (AArch32_TakePrefetchAbortException vaddress fault))
        else (do (AArch32_TakeDataAbortException vaddress fault)))))

def GPCNoFault (_ : Unit) : SailM GPCFRecord := do
  let result ← (( do (undefined_GPCFRecord ()) ) : SailM GPCFRecord )
  (pure { result with gpf := GPCF_None })

def NoFault (_ : Unit) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault ← (pure { fault with access := (← do (__UNKNOWN_AccessDescriptor ())) })
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with dirtybit := false }
  let fault : FaultRecord := { fault with overlay := false }
  let fault : FaultRecord := { fault with toplevel := false }
  let fault : FaultRecord := { fault with assuredonly := false }
  let fault : FaultRecord := { fault with s1tagnotdata := false }
  let fault : FaultRecord := { fault with tagaccess := false }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

def NoFault__1 (accdesc : AccessDescriptor) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault : FaultRecord := { fault with access := accdesc }
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with dirtybit := false }
  let fault : FaultRecord := { fault with overlay := false }
  let fault : FaultRecord := { fault with toplevel := false }
  let fault : FaultRecord := { fault with assuredonly := false }
  let fault : FaultRecord := { fault with s1tagnotdata := false }
  let fault : FaultRecord := { fault with tagaccess := false }
  let fault : FaultRecord := { fault with write := ((! accdesc.read) && accdesc.write) }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def HandleExternalAbort (memretstatus : PhysMemRetStatus) (iswrite : Bool) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  sail_assert (←((pure ((BEq.beq memretstatus.statuscode Fault_SyncExternal) || (BEq.beq memretstatus.statuscode Fault_AsyncExternal))) <||> (do
    (pure ((! (← (HaveRASExt ()))) && ((BEq.beq memretstatus.statuscode Fault_SyncParity) || (BEq.beq memretstatus.statuscode Fault_AsyncParity))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15300.227-15300.228"
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := memretstatus.statuscode }
  let fault : FaultRecord := { fault with write := iswrite }
  let fault : FaultRecord := { fault with extflag := memretstatus.extflag }
  let fault ← (( do
    (if ((←((IsExternalSyncAbort__1 fault) <&&> (do
         (pure (! (← (IsExternalAbortTakenSynchronously memretstatus iswrite memaddrdesc size accdesc))))))) : Bool)
    then
      (do (if ((BEq.beq fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { fault with statuscode := Fault_AsyncParity }))
          else (do (pure { fault with statuscode := Fault_AsyncExternal }))))
    else (do (pure fault))) ) : SailM FaultRecord )
  let fault ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure { fault with merrorstate := memretstatus.merrorstate }))
    else (do (pure fault))) ) : SailM FaultRecord )
  (if ((← (IsExternalSyncAbort__1 fault)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (AArch32_Abort (Sail.BitVec.extractLsb memaddrdesc.vaddress 31 0) fault))
        else (do (AArch64_Abort memaddrdesc.vaddress fault))))
  else (do (pure (PendSErrorInterrupt fault))))

/-- Type quantifiers: size : Int -/
def HandleExternalReadAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := false
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

/-- Type quantifiers: size : Int -/
def HandleExternalWriteAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := true
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

def HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCR r

def ClearPendingVirtualSError (_ : Unit) : SailM Unit := do
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do (HCR_write (_update_HCR_Type_VA (← (HCR_read ())) 0#1)))
  else (do writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1)))

def IsSErrorEdgeTriggered (_ : Unit) : SailM Bool := do
  (if ((← (HaveDoubleFaultExt ())) : Bool)
  then (do (pure true))
  else (do (__IMPDEF_boolean "Edge-triggered SError")))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPInfinity (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15378.38-15378.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPMaxNormal (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15389.38-15389.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := ((Ones (n := (E -i 1))) +++ 0#1)
  let frac : (BitVec F) := (Ones (n := F))
  (pure ((sign +++ exp) +++ frac))

def AArch32_GeneralExceptionsToAArch64 (_ : Unit) : SailM Bool := do
  (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
    (pure (! (← (ELUsingAArch32 EL1))))) <||> (do
    (EL2Enabled ()) <&&> (do
      (pure (! (← (ELUsingAArch32 EL2))))) <&&> (do
      (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))

def AArch32_TakeUndefInstrException__1 (except : ExceptionRecord) : SailM Unit := do
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x04#8)
  let lr_offset ← (( do
    (if ((BEq.beq (← (CurrentInstrSet ())) InstrSet_A32) : Bool)
    then (do (pure 4))
    else (do (pure 2))) ) : SailM Int )
  (if (((← readReg PSTATE).EL == EL2) : Bool)
  then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
  else
    (do (if (route_to_hyp : Bool)
        then (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))
        else (do (AArch32_EnterMode M32_Undef preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeUndefInstrException (_ : Unit) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_Uncategorized) ) : SailM ExceptionRecord )
  (AArch32_TakeUndefInstrException__1 except)


end ArmASL.Functions
