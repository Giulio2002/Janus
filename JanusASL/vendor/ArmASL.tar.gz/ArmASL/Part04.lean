import ArmASL.Part03

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_N : Nat, k_conditional : Bool, k_is_isb : Bool, k_taken_flag : Bool, k_N ≥ 0 -/
def SPEBranch__1 (target : (BitVec k_N)) (branch_type : BranchType) (conditional : Bool) (taken_flag : Bool) (is_isb : Bool) : SailM Unit := do
  let is_direct ← (( do (undefined_bool ()) ) : SailM Bool )
  let collect_prev_br ← (( do (undefined_bool ()) ) : SailM Bool )
  let collect_prev_br_eret ← (( do (__IMPDEF_boolean "SPE prev br on eret") ) : SailM Bool )
  let collect_prev_br_exception ← (( do (__IMPDEF_boolean "SPE prev br on exception") ) : SailM Bool )
  let collect_prev_br_isb ← (( do (__IMPDEF_boolean "SPE prev br on isb") ) : SailM Bool )
  let collect_prev_br : Bool :=
    match branch_type with
    | .BranchType_EXCEPTION => collect_prev_br_exception
    | .BranchType_ERET => collect_prev_br_eret
    | _ => ((! is_isb) || collect_prev_br_isb)
  let collect_prev_br := collect_prev_br
  (if (((←((pure taken_flag) <&&> (do
         (pure (! (IsZero (_get_PMSIDR_EL1_Type_PBT (← readReg PMSIDR_EL1)))))) <&&> (do
         (StatisticalProfilingEnabled ())))) && collect_prev_br) : Bool)
  then
    (do (if ((← readReg SPESampleInFlight) : Bool)
        then
          (do let previous_target ← (( do readReg SPESamplePreviousBranchAddress ) : SailM (BitVec 64) )
              writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosPrevBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosPrevBranchTarget) 63 0 (Sail.BitVec.extractLsb previous_target 63 0)))
              let previous_branch_valid ← (( do readReg SPESamplePreviousBranchAddressValid ) : SailM Bool )
              writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosPrevBranchTarget previous_branch_valid))
        else (do (pure ())))
        sail_assert (55 <b (Sail.BitVec.length target)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6728.34-6728.35"
        writeReg SPESamplePreviousBranchAddress (Sail.BitVec.updateSubrange (← readReg SPESamplePreviousBranchAddress) 55 0 (Sail.BitVec.extractLsb target 55 0))
        let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let (ns, nse) ← (( do
          match (← (CurrentSecurityState ())) with
          | .SS_Secure =>
            (let ns : (BitVec 1) := 0#1
            let nse : (BitVec 1) := 0#1
            (pure (ns, nse)))
          | .SS_NonSecure =>
            (let ns : (BitVec 1) := 1#1
            let nse : (BitVec 1) := 0#1
            (pure (ns, nse)))
          | .SS_Realm =>
            (let ns : (BitVec 1) := 1#1
            let nse : (BitVec 1) := 1#1
            (pure (ns, nse)))
          | _ =>
            (do
              (Unreachable ())
              (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
        writeReg SPESamplePreviousBranchAddress (BitVec.update (← readReg SPESamplePreviousBranchAddress) 63 (Bit ns))
        writeReg SPESamplePreviousBranchAddress (BitVec.update (← readReg SPESamplePreviousBranchAddress) 60 (Bit nse))
        writeReg SPESamplePreviousBranchAddress (Sail.BitVec.updateSubrange (← readReg SPESamplePreviousBranchAddress) 62 61 (← readReg PSTATE).EL)
        writeReg SPESamplePreviousBranchAddressValid true)
  else (do (pure ())))
  (if ((! (← (StatisticalProfilingEnabled ()))) : Bool)
  then
    (do (if (taken_flag : Bool)
        then (do writeReg SPESamplePreviousBranchAddressValid false)
        else (do (pure ()))))
  else
    (do (if ((← readReg SPESampleInFlight) : Bool)
        then
          (do let is_direct : Bool := ((BEq.beq branch_type BranchType_DIR) || (BEq.beq branch_type BranchType_DIRCALL))
              writeReg SPESampleClass 0b10#2
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 1
                (Bit
                  (if (is_direct : Bool)
                  then 0#1
                  else 1#1)))
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
                (Bit
                  (if (conditional : Bool)
                  then 1#1
                  else 0#1)))
              writeReg SPESampleOpType OpType_Branch
              (if (taken_flag : Bool)
              then
                (do sail_assert (55 <b (Sail.BitVec.length target)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6767.38-6767.39"
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 55 0 (Sail.BitVec.extractLsb target 55 0)))
                    let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let (ns, nse) ← (( do
                      match (← (CurrentSecurityState ())) with
                      | .SS_Secure =>
                        (let ns : (BitVec 1) := 0#1
                        let nse : (BitVec 1) := 0#1
                        (pure (ns, nse)))
                      | .SS_NonSecure =>
                        (let ns : (BitVec 1) := 1#1
                        let nse : (BitVec 1) := 0#1
                        (pure (ns, nse)))
                      | .SS_Realm =>
                        (let ns : (BitVec 1) := 1#1
                        let nse : (BitVec 1) := 1#1
                        (pure (ns, nse)))
                      | _ =>
                        (do
                          (Unreachable ())
                          (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 63 (Bit ns)))
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 60 (Bit nse)))
                    writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosBranchTarget (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosBranchTarget) 62 61 (← readReg PSTATE).EL))
                    writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosBranchTarget true))
              else (do (pure ())))
              writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 6
                (Bit
                  (if ((! taken_flag) : Bool)
                  then 1#1
                  else 0#1))))
        else (do (pure ())))))

/-- Type quantifiers: k_N : Nat, k_conditional : Bool, k_taken_flag : Bool, k_N ≥ 0 -/
def SPEBranch (target : (BitVec k_N)) (branch_type : BranchType) (conditional : Bool) (taken_flag : Bool) : SailM Unit := do
  let is_isb : Bool := false
  (SPEBranch__1 target branch_type conditional taken_flag is_isb)

def Hint_Branch (hint : BranchType) : SailM Unit := do
  writeReg Branchtypetaken hint

/-- Type quantifiers: k_N : Nat, k_branch_conditional : Bool, k_N ≥ 0 -/
def BranchTo (target : (BitVec k_N)) (branch_type : BranchType) (branch_conditional : Bool) : SailM Unit := do
  (Hint_Branch branch_type)
  (if (((Sail.BitVec.length target) == 32) : Bool)
  then
    (do sail_assert (← (UsingAArch32 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:6804.29-6804.30"
        writeReg _PC (Sail.BitVec.zeroExtend target 64))
  else
    (do sail_assert (←((pure ((Sail.BitVec.length target) == 64)) <&&> (do
          (pure (! (← (UsingAArch32 ()))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6807.50-6807.51"
        let target_vaddress ← (( do (AArch64_BranchAddr (Sail.BitVec.extractLsb target 63 0) (← readReg PSTATE).EL) ) : SailM (BitVec 64) )
        (if (((← (HaveBRBExt ())) && ((BEq.beq branch_type BranchType_DIR) || ((BEq.beq branch_type BranchType_INDIR) || ((BEq.beq branch_type BranchType_DIRCALL) || ((BEq.beq branch_type BranchType_INDCALL) || (BEq.beq branch_type BranchType_RET)))))) : Bool)
        then (do (BRBEBranch branch_type branch_conditional target_vaddress))
        else (do (pure ())))
        let branch_taken : Bool := true
        (if ((← (HaveStatisticalProfiling ())) : Bool)
        then (do (SPEBranch target branch_type branch_conditional branch_taken))
        else (do (pure ())))
        let _ : Unit := (sail_branch_announce 64 target_vaddress)
        writeReg _PC target_vaddress))
  writeReg __BranchTaken true

/-- Type quantifiers: x : Int -/
def FloorPow2 (x : Int) : SailM Nat := do
  sail_assert (x ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:6832.17-6832.18"
  let n : Int := 1
  (if ((x == 0) : Bool)
  then (do (pure 0))
  else
    (do let n ← (( do
          let mut loop_vars := n
          while (λ n => (x ≥b (2 ^i n))) loop_vars do
            let n := loop_vars
            loop_vars := ((n +i 1) : Int)
          (pure loop_vars) ) : SailM Int )
        let n := n
        let r := (2 ^i (n -i 1))
        sail_assert (r ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:6842.17-6842.18"
        (pure r)))

/-- Type quantifiers: x : Int -/
def CeilPow2 (x : Int) : SailM Nat := do
  (if ((x == 0) : Bool)
  then (do (pure 0))
  else
    (do (if ((x == 1) : Bool)
        then (do (pure 2))
        else (do (pure ((← (FloorPow2 (x -i 1))) *i 2))))))

/-- Type quantifiers: x : Int -/
def IsPow2 (x : Int) : SailM Bool := do
  (if ((x ≤b 0) : Bool)
  then (do (pure false))
  else (do (pure ((← (FloorPow2 x)) == (← (CeilPow2 x))))))

def MaxImplementedVL (_ : Unit) : Int :=
  MAX_VL

/-- Type quantifiers: nbits_in : Int -/
def ImplementedSVEVectorLength (nbits_in : Int) : SailM Int := SailME.run do
  let maxbits := (MaxImplementedVL ())
  sail_assert (←((pure ((128 ≤b maxbits) && (maxbits ≤b 2048))) <&&> (do
    (IsPow2 maxbits)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6873.63-6873.64"
  let nbits : Int := (Min.min nbits_in maxbits)
  sail_assert (((128 ≤b nbits) && (nbits ≤b 2048)) && ((Align_int nbits 128) == nbits)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6875.70-6875.71"
  let nbits ← (( do
    let mut loop_vars := nbits
    while (λ nbits => (nbits >b 128)) loop_vars do
      let nbits := loop_vars
      loop_vars ← do
        (if ((← (IsPow2 nbits)) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6879.44-6879.45"
                  (pure nbits)))
        else (do (pure (nbits -i 128))))
    (pure loop_vars) ) : SailME Int Int )
  let nbits := nbits
  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6885.36-6885.37"
  (pure nbits)

def undefined_ZCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ZCR_EL1_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL1_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL2_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_SMCR_EL3_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ZCR_EL2_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ZCR_EL3_Type_LEN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def undefined_ZCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ZCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ZCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CurrentNSVL_read (_ : Unit) : SailM Int := do
  let vl ← (( do (undefined_int ()) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (pure (! (← (IsInHost ())))))))) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL1_Type_LEN (← readReg ZCR_EL1)))))
    else (do (pure vl))) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (IsInHost ()))))) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL2_Type_LEN (← readReg ZCR_EL2)))))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_ZCR_EL2_Type_LEN (← readReg ZCR_EL2))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl ← (( do
    (if (((← readReg PSTATE).EL == EL3) : Bool)
    then (do (pure (BitVec.toNat (_get_ZCR_EL3_Type_LEN (← readReg ZCR_EL3)))))
    else
      (do (if ((HaveEL EL3) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_ZCR_EL3_Type_LEN (← readReg ZCR_EL3))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl : Int := ((vl +i 1) *i 128)
  let vl ← (( do (ImplementedSVEVectorLength vl) ) : SailM Int )
  (pure vl)

def MaxImplementedSVL (_ : Unit) : SailM Int := do
  readReg __max_implemented_smeveclen

/-- Type quantifiers: nbits : Int -/
def SupportedPowerTwoSVL (nbits : Int) : Bool :=
  true

/-- Type quantifiers: nbits_in : Int -/
def ImplementedSMEVectorLength (nbits_in : Int) : SailM Int := SailME.run do
  let maxbits ← (( do (MaxImplementedSVL ()) ) : SailME Int Int )
  sail_assert (((((maxbits == 128) || (maxbits == 256)) || (maxbits == 512)) || (maxbits == 1024)) || (maxbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6932.38-6932.39"
  let nbits : Int := (Min.min nbits_in maxbits)
  sail_assert (((128 ≤b nbits) && (nbits ≤b 2048)) && ((Align_int nbits 128) == nbits)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6934.70-6934.71"
  let nbits ← (( do
    let mut loop_vars := nbits
    while (λ nbits => (nbits >b 128)) loop_vars do
      let nbits := loop_vars
      loop_vars ← do
        (if (((← (IsPow2 nbits)) && (SupportedPowerTwoSVL nbits)) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6938.44-6938.45"
                  (pure nbits)))
        else (do (pure (nbits -i 128))))
    (pure loop_vars) ) : SailME Int Int )
  let nbits : Int := 128
  let nbits ← (( do
    let mut loop_vars_1 := nbits
    while (λ nbits => (nbits <b maxbits)) loop_vars_1 do
      let nbits := loop_vars_1
      loop_vars_1 ← do
        (if ((SupportedPowerTwoSVL nbits) : Bool)
        then
          (do SailME.throw (← do
                  let nbits := nbits
                  sail_assert (((((nbits == 128) || (nbits == 256)) || (nbits == 512)) || (nbits == 1024)) || (nbits == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6947.44-6947.45"
                  (pure nbits)))
        else (do (pure (nbits *i 2))))
    (pure loop_vars_1) ) : SailME Int Int )
  (pure maxbits)

def undefined_SMCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SMCR_EL1_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SMCR_EL2_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SMCR_EL3_Type_FA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def undefined_SMCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SMCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SMCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CurrentSVL_read (_ : Unit) : SailM Int := do
  let vl ← (( do (undefined_int ()) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (pure (! (← (IsInHost ())))))))) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL1_Type_LEN (← readReg SMCR_EL1)))))
    else (do (pure vl))) ) : SailM Int )
  let vl ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
           (IsInHost ()))))) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL2_Type_LEN (← readReg SMCR_EL2)))))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
               (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
               (EL2Enabled ())))) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_SMCR_EL2_Type_LEN (← readReg SMCR_EL2))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl ← (( do
    (if (((← readReg PSTATE).EL == EL3) : Bool)
    then (do (pure (BitVec.toNat (_get_SMCR_EL3_Type_LEN (← readReg SMCR_EL3)))))
    else
      (do (if ((HaveEL EL3) : Bool)
          then (do (pure (Min.min vl (BitVec.toNat (_get_SMCR_EL3_Type_LEN (← readReg SMCR_EL3))))))
          else (do (pure vl))))) ) : SailM Int )
  let vl : Int := ((vl +i 1) *i 128)
  let vl ← (( do (ImplementedSMEVectorLength vl) ) : SailM Int )
  (pure vl)

def HaveSME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME)

def CurrentVL_read (_ : Unit) : SailM Int := do
  let SVL ← (( do (CurrentSVL_read ()) ) : SailM Int )
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))))) : Bool)
  then (do (pure SVL))
  else (do (CurrentNSVL_read ())))

/-- Type quantifiers: width : Nat, width ≥ 0 -/
def FFR_set (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert (width == (Int.ediv VL 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7006.30-7006.31"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _FFR (Sail.BitVec.zeroExtend value_name MAX_PL))
  else (do writeReg _FFR (Sail.BitVec.updateSubrange (← readReg _FFR) (width -i 1) 0 value_name)))

def undefined_GCSPR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GCSPR_EL0_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL1_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL2_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def _get_GCSPR_EL3_Type_PTR (v : (BitVec 64)) : (BitVec 61) :=
  (Sail.BitVec.extractLsb v 63 3)

def undefined_GCSPR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSPR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSPR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSPR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveGCS (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_GCS)

def undefined_CPACR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPACR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPACR_EL1_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_CPTR_EL2_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR2_EL1_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_TCR2_EL2_Type_E0POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_CPACR_EL1_Type_FPEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_CPTR_EL2_Type_FPEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_CPACR_EL1_Type_SMEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _get_CPTR_EL2_Type_SMEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _update_HCPTR_Type_TTA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _get_CPACR_EL1_Type_ZEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 17 16)

def _get_CPTR_EL2_Type_ZEN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 17 16)

def undefined_CPTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPTR_EL2_Type_TAM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _update_HCPTR_Type_TAM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_CPTR_EL3_Type_TAM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_CPTR_EL2_Type_TCPAC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_HCPTR_Type_TCPAC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_CPTR_EL3_Type_TCPAC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_CPTR_EL2_Type_TFP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_CPTR_EL3_Type_TFP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_CPTR_EL2_Type_TSM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CPTR_EL2_Type_TZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def undefined_CPTR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CPTR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CPTR_EL3_Type_ESM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CPTR_EL3_Type_EZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def AArch64_IsFPEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
       (pure (! (← (IsInHost ()))))))) : Bool)
  then
    (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
        let disabled ← (( do
          let b__0 ← do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1)))
          (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
          then (do (pure true))
          else
            (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure (el == EL0)))
                else (do (pure false))))) ) : SailME Bool Bool )
        let disabled := disabled
        (if (disabled : Bool)
        then (do SailME.throw (false : Bool))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
       (EL2Enabled ())))) : Bool)
  then
    (do (if ((←((HaveVirtHostExt ()) <&&> (do
             (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
              let disabled ← (( do
                let b__2 ← do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2)))
                (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                      then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                      else (do (pure false))))) ) : SailME Bool Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else
          (do (if (((_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2)) == 1#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
        then (do SailME.throw (false : Bool))
        else (do (pure ()))))
  else (do (pure ())))
  (pure true)

def undefined_CPACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CPACR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_CPACR_Type_ASEDIS (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_CPACR_Type_cp10 (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _update_CPACR_Type_cp10 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 20 x)

def _get_NSACR_Type_cp10 (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_CPACR_Type_cp11 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 22 x)

def CPACR_read__1 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CPACR ) : SailM CPACR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CPACR_EL1) 0 32)))

def undefined_HCPTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCPTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HCPTR_Type_TASE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _get_HCPTR_Type_TCP10 (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_HCPTR_Type_TCP10 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_HCPTR_Type_TCP11 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def HCPTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCPTR ) : SailM HCPTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CPTR_EL2) 0 32)))

def undefined_NSACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AArch32_IsFPEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  (if ((←((pure (el == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_IsFPEnabled el))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (ELUsingAArch32 EL3)) <&&> (do
             (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))))) : Bool)
        then
          (do (if (((_get_NSACR_Type_cp10 (← readReg NSACR)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if (((el == EL0) || (el == EL1)) : Bool)
        then
          (do let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
              let disabled ← (( do
                match (_get_CPACR_Type_cp10 (← (CPACR_read__1 ()))) with
                | 0b00 => (pure true)
                | 0b01 => (pure (el == EL0))
                | 0b10 => (do (ConstrainUnpredictableBool Unpredictable_RESCPACR))
                | _ => (pure false) ) : SailME Bool Bool )
              let disabled := disabled
              (if (disabled : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((! (← (ELUsingAArch32 EL2))) : Bool)
              then (do SailME.throw (← do (AArch64_IsFPEnabled EL2)))
              else
                (do (if (((_get_HCPTR_Type_TCP10 (← (HCPTR_read ()))) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3)) == 1#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsFPEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (AArch32_IsFPEnabled el))
  else (do (AArch64_IsFPEnabled el)))

def HaveSVE (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SVE)

def IsOriginalSVEEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do let disabled ← (( do
          (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
               (pure (! (← (IsInHost ()))))))) : Bool)
          then
            (do let disabled ← (( do
                  let b__0 ← do (pure (_get_CPACR_EL1_Type_ZEN (← readReg CPACR_EL1)))
                  (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                  then (do (pure true))
                  else
                    (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                        then (do (pure (el == EL0)))
                        else (do (pure false))))) ) : SailME Bool Bool )
                (if (disabled : Bool)
                then (do SailME.throw (false : Bool))
                else (do (pure ())))
                (pure disabled))
          else (do (pure disabled))) ) : SailME Bool Bool )
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then
                (do let disabled ← (( do
                      let b__2 ← do (pure (_get_CPTR_EL2_Type_ZEN (← readReg CPTR_EL2)))
                      (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                            then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                            else (do (pure false))))) ) : SailME Bool Bool )
                    (if (disabled : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))
              else
                (do (if (((_get_CPTR_EL2_Type_TZ (← readReg CPTR_EL2)) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_EZ (← readReg CPTR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsSMEEnabled (el : (BitVec 2)) : SailM Bool := SailME.run do
  let disabled ← (( do (undefined_bool ()) ) : SailME Bool Bool )
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do let disabled ← (( do
          (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
               (pure (! (← (IsInHost ()))))))) : Bool)
          then
            (do let disabled ← (( do
                  let b__0 ← do (pure (_get_CPACR_EL1_Type_SMEN (← readReg CPACR_EL1)))
                  (if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                  then (do (pure true))
                  else
                    (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
                        then (do (pure (el == EL0)))
                        else (do (pure false))))) ) : SailME Bool Bool )
                (if (disabled : Bool)
                then (do SailME.throw (false : Bool))
                else (do (pure ())))
                (pure disabled))
          else (do (pure disabled))) ) : SailME Bool Bool )
        (if ((←((pure ((el == EL0) || ((el == EL1) || (el == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))) : Bool)
              then
                (do let disabled ← (( do
                      let b__2 ← do (pure (_get_CPTR_EL2_Type_SMEN (← readReg CPTR_EL2)))
                      (if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((b__2 == (0b01#2 : (BitVec 2))) : Bool)
                            then (do (pure (el == EL0)) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))
                            else (do (pure false))))) ) : SailME Bool Bool )
                    (if (disabled : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))
              else
                (do (if (((_get_CPTR_EL2_Type_TSM (← readReg CPTR_EL2)) == 1#1) : Bool)
                    then (do SailME.throw (false : Bool))
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_CPTR_EL3_Type_ESM (← readReg CPTR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def IsSVEEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((←((HaveSME ()) <&&> (do
       (pure ((← readReg PSTATE).SM == 1#1))))) : Bool)
  then (do (IsSMEEnabled el))
  else
    (do (if ((← (HaveSVE ())) : Bool)
        then (do (IsOriginalSVEEnabled el))
        else (do (pure false)))))

/-- Type quantifiers: n : Int, width : Nat, width ≥ 0 -/
def P_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7362.27-7362.28"
  sail_assert (width == (Int.ediv VL 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7363.30-7363.31"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then
    (do sail_assert ((0 ≤b n) && (n <b 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7365.46-7365.47"
        writeReg _P (vectorUpdate (← readReg _P) n (Sail.BitVec.zeroExtend value_name MAX_PL)))
  else
    (do sail_assert ((0 ≤b n) && (n <b 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7368.46-7368.47"
        writeReg _P (vectorUpdate (← readReg _P) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _P) n) (width -i 1) 0 value_name))))

def SP_set (value_name : (BitVec 64)) : SailM Unit := do
  (if (((← readReg PSTATE).SP == 0#1) : Bool)
  then (do writeReg SP_EL0 value_name)
  else
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do writeReg SP_EL0 value_name)
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do writeReg SP_EL1 value_name)
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do writeReg SP_EL2 value_name)
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do writeReg SP_EL3 value_name)
                          else (do (pure ())))))))))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64, 128] -/
def V_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7420.27-7420.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || ((width == 64) || (width == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:7421.78-7421.79"
  let vlen ← (( do
    (if ((← (IsSVEEnabled (← readReg PSTATE).EL)) : Bool)
    then (do (pure VL))
    else (do (pure 128))) ) : SailM Int )
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.zeroExtend value_name MAX_VL)))
  else (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _Z) n) (vlen -i 1) 0 (Sail.BitVec.zeroExtend value_name vlen)))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [32, 64] -/
def X_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7435.27-7435.28"
  sail_assert ((width == 32) || (width == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7436.36-7436.37"
  (if ((n != 31) : Bool)
  then (do (set_R n (Sail.BitVec.zeroExtend value_name 64)))
  else (do (pure ())))

/-- Type quantifiers: n : Int, width : Nat, width ≥ 0 -/
def Z_set (n : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7448.27-7448.28"
  sail_assert (width == VL) "sail-arm/arm-v9.4-a/src/v8_base.sail:7449.22-7449.23"
  (if ((← (ConstrainUnpredictableBool Unpredictable_SVEZEROUPPER)) : Bool)
  then (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.zeroExtend value_name MAX_VL)))
  else (do writeReg _Z (vectorUpdate (← readReg _Z) n (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg _Z) n) (width -i 1) 0 value_name))))

/-- Type quantifiers: pl : Nat, vl : Nat, (is_VL vl) ∧ (is_PL pl) -/
def RestoreTransactionCheckpointParameterised (vl : Nat) (pl : Nat) : SailM Unit := do
  sail_assert ((((((((((((((((vl == 128) || (vl == 256)) || (vl == 384)) || (vl == 512)) || (vl == 640)) || (vl == 768)) || (vl == 896)) || (vl == 1024)) || (vl == 1152)) || (vl == 1280)) || (vl == 1408)) || (vl == 1536)) || (vl == 1664)) || (vl == 1792)) || (vl == 1920)) || (vl == 2048)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7461.237-7461.238"
  (SP_set (← readReg TSTATE).SP)
  writeReg ICC_PMR_EL1 (Mk_ICC_PMR_EL1_Type (← readReg TSTATE).ICC_PMR_EL1)
  let split_vec ← do (pure (← readReg TSTATE).nzcv)
  writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) }
  let split_vec ← do (pure ((← readReg TSTATE).D +++ ((← readReg TSTATE).A +++ ((← readReg TSTATE).I +++ (← readReg TSTATE).F))))
  writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  let loop_n_lower := 0
  let loop_n_upper := 30
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do (X_set n 64 (GetElem?.getElem! (← readReg TSTATE).X n))
  (pure loop_vars)
  (if ((← (IsFPEnabled (← readReg PSTATE).EL)) : Bool)
  then
    (do (if ((← (IsSVEEnabled (← readReg PSTATE).EL)) : Bool)
        then
          (do let loop_n_lower := 0
              let loop_n_upper := 31
              let mut loop_vars_2 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_2
                loop_vars_2 ← do (Z_set n vl (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).Z n) (vl -i 1) 0))
              (pure loop_vars_2)
              let loop_n_lower := 0
              let loop_n_upper := 15
              let mut loop_vars_3 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_3
                loop_vars_3 ← do (P_set n pl (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).P n) (pl -i 1) 0))
              (pure loop_vars_3)
              (FFR_set pl (Sail.BitVec.extractLsb (← readReg TSTATE).FFR (pl -i 1) 0)))
        else
          (do let loop_n_lower := 0
              let loop_n_upper := 31
              let mut loop_vars_1 := ()
              for n in [loop_n_lower:loop_n_upper:1]i do
                let () := loop_vars_1
                loop_vars_1 ← do (V_set n 128 (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg TSTATE).Z n) 127 0))
              (pure loop_vars_1)))
        writeReg FPCR (Mk_FPCR_Type (← readReg TSTATE).FPCR)
        writeReg FPSR (Mk_FPSR_Type (← readReg TSTATE).FPSR))
  else (do (pure ())))
  (if ((← (HaveGCS ())) : Bool)
  then
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do writeReg GCSPR_EL0 (Mk_GCSPR_EL0_Type (← readReg TSTATE).GCSPR_ELx))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do writeReg GCSPR_EL1 (Mk_GCSPR_EL1_Type (← readReg TSTATE).GCSPR_ELx))
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do writeReg GCSPR_EL2 (Mk_GCSPR_EL2_Type (← readReg TSTATE).GCSPR_ELx))
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do writeReg GCSPR_EL3 (Mk_GCSPR_EL3_Type (← readReg TSTATE).GCSPR_ELx))
                          else (do (pure ()))))))))))
  else (do (pure ())))

def RestoreTransactionCheckpoint (_ : Unit) : SailM Unit := do
  let VL ← (( do (CurrentVL_read ()) ) : SailM Int )
  let VL := VL
  match VL with
  | 128 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 256 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 512 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 1024 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | 2048 => (RestoreTransactionCheckpointParameterised VL (Int.ediv VL 8))
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:7561.22-7561.23"

/-- Type quantifiers: processorid : Int -/
def ClearExclusiveLocal (processorid : Int) : Unit :=
  ()

def DiscardTransactionalWrites (_ : Unit) : Unit :=
  ()

def ProcessorID (_ : Unit) : Int :=
  0

/-- Type quantifiers: k_interrupt : Bool, k_retry : Bool -/
def FailTransaction__1 (cause : TMFailure) (retry : Bool) (interrupt : Bool) (reason : (BitVec 15)) : SailM Unit := do
  sail_assert ((! retry) || (! interrupt)) "sail-arm/arm-v9.4-a/src/v8_base.sail:7577.48-7577.49"
  (if ((←((HaveBRBExt ()) <&&> (do
       (BranchRecordAllowed (← readReg PSTATE).EL)))) : Bool)
  then (do writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 1#1))
  else (do (pure ())))
  let _ : Unit := (DiscardTransactionalWrites ())
  (if ((bne cause TMFailure_TRIVIAL) : Bool)
  then (do (RestoreTransactionCheckpoint ()))
  else (do (pure ())))
  let _ : Unit := (ClearExclusiveLocal (ProcessorID ()))
  let result : (BitVec 64) := (Zeros (n := 64))
  let result : (BitVec 64) :=
    (BitVec.update result 23
      (Bit
        (if (interrupt : Bool)
        then 1#1
        else 0#1)))
  let result : (BitVec 64) :=
    (BitVec.update result 15
      (Bit
        (if ((retry && (! interrupt)) : Bool)
        then 1#1
        else 0#1)))
  let result : (BitVec 64) :=
    match cause with
    | .TMFailure_TRIVIAL => (BitVec.update result 24 (Bit 1#1))
    | .TMFailure_DBG => (BitVec.update result 22 (Bit 1#1))
    | .TMFailure_NEST => (BitVec.update result 21 (Bit 1#1))
    | .TMFailure_SIZE => (BitVec.update result 20 (Bit 1#1))
    | .TMFailure_ERR => (BitVec.update result 19 (Bit 1#1))
    | .TMFailure_IMP => (BitVec.update result 18 (Bit 1#1))
    | .TMFailure_MEM => (BitVec.update result 17 (Bit 1#1))
    | .TMFailure_CNCL =>
      (let result : (BitVec 64) := (BitVec.update result 16 (Bit 1#1))
      (Sail.BitVec.updateSubrange result 14 0 reason))
  writeReg TSTATE { (← readReg TSTATE) with depth := 0 }
  (X_set (← readReg TSTATE).Rt 64 result)
  let branch_conditional : Bool := false
  (BranchTo (← readReg TSTATE).nPC BranchType_TMFAIL branch_conditional)
  (EndOfInstruction ())

/-- Type quantifiers: k_retry : Bool -/
def FailTransaction (cause : TMFailure) (retry : Bool) : SailM Unit := do
  (FailTransaction__1 cause retry false (Zeros (n := 15)))

def HaveBTIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BTI)

def HaveDITExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DIT)

def HaveFeatNMI (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NMI)

def HaveMTEExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE)

def HavePANExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAN)

def HaveSSBSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SSBS)

def HaveUAOExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_UAO)

/-- Type quantifiers: N : Nat, List.elem N [32, 64] -/
def GetPSRFromPSTATE (targetELState : ExceptionalOccurrenceTargetState) (N : Nat) : SailM (BitVec N) := do
  (if (((← (UsingAArch32 ())) && (BEq.beq targetELState AArch32_NonDebugState)) : Bool)
  then (do sail_assert (N == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:7671.22-7671.23")
  else (do sail_assert (N == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:7673.22-7673.23"))
  let spsr : (BitVec N) := (Zeros (n := N))
  let spsr ← (pure (Sail.BitVec.updateSubrange spsr 31 28 ((← readReg PSTATE).N +++ ((← readReg PSTATE).Z +++ ((← readReg PSTATE).C +++ (← readReg PSTATE).V)))))
  let spsr ← (( do
    (if ((← (HavePANExt ())) : Bool)
    then (do (pure (BitVec.update spsr 22 (Bit (← readReg PSTATE).PAN))))
    else (do (pure spsr))) ) : SailM (BitVec N) )
  let spsr ← (pure (BitVec.update spsr 20 (Bit (← readReg PSTATE).IL)))
  (if (((← readReg PSTATE).nRW == 1#1) : Bool)
  then
    (do let spsr ← (pure (BitVec.update spsr 27 (Bit (← readReg PSTATE).Q)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 26 25 (Sail.BitVec.extractLsb (← readReg PSTATE).IT 1 0)))
        let spsr ← (( do
          (if ((← (HaveSSBSExt ())) : Bool)
          then (do (pure (BitVec.update spsr 23 (Bit (← readReg PSTATE).SSBS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveDITExt ())) : Bool)
          then
            (do (if ((BEq.beq targetELState AArch32_NonDebugState) : Bool)
                then (do (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).DIT))))
                else (do (pure (BitVec.update spsr 24 (Bit (← readReg PSTATE).DIT))))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if (((BEq.beq targetELState AArch64_NonDebugState) || (BEq.beq targetELState DebugState)) : Bool)
          then (do (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).SS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 19 16 (← readReg PSTATE).GE))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 15 10 (Sail.BitVec.extractLsb (← readReg PSTATE).IT 7 2)))
        let spsr ← (pure (BitVec.update spsr 9 (Bit (← readReg PSTATE).E)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 8 6 ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F))))
        let spsr ← (pure (BitVec.update spsr 5 (Bit (← readReg PSTATE).T)))
        sail_assert (((BitVec.access (← readReg PSTATE).M 4) : BitVec 1) == (← readReg PSTATE).nRW) "sail-arm/arm-v9.4-a/src/v8_base.sail:7702.42-7702.43"
        (pure (Sail.BitVec.updateSubrange spsr 4 0 (← readReg PSTATE).M)))
  else
    (do let spsr ← (( do
          (if ((← (HaveMTEExt ())) : Bool)
          then (do (pure (BitVec.update spsr 25 (Bit (← readReg PSTATE).TCO))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveGCS ())) : Bool)
          then
            (do sail_assert (34 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:7709.38-7709.39"
                (pure (BitVec.update spsr 34 (Bit (← readReg PSTATE).EXLOCK))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveDITExt ())) : Bool)
          then (do (pure (BitVec.update spsr 24 (Bit (← readReg PSTATE).DIT))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveUAOExt ())) : Bool)
          then (do (pure (BitVec.update spsr 23 (Bit (← readReg PSTATE).UAO))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (BitVec.update spsr 21 (Bit (← readReg PSTATE).SS)))
        let spsr ← (( do
          (if ((← (HaveFeatNMI ())) : Bool)
          then (do (pure (BitVec.update spsr 13 (Bit (← readReg PSTATE).ALLINT))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveSSBSExt ())) : Bool)
          then (do (pure (BitVec.update spsr 12 (Bit (← readReg PSTATE).SSBS))))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (( do
          (if ((← (HaveBTIExt ())) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange spsr 11 10 (← readReg PSTATE).BTYPE)))
          else (do (pure spsr))) ) : SailM (BitVec N) )
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 9 6 ((← readReg PSTATE).D +++ ((← readReg PSTATE).A +++ ((← readReg PSTATE).I +++ (← readReg PSTATE).F)))))
        let spsr ← (pure (BitVec.update spsr 4 (Bit (← readReg PSTATE).nRW)))
        let spsr ← (pure (Sail.BitVec.updateSubrange spsr 3 2 (← readReg PSTATE).EL))
        (pure (BitVec.update spsr 0 (Bit (← readReg PSTATE).SP)))))

def Havev8p9Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p9)

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def ThisInstrAddr (N : Nat) : SailM (BitVec N) := do
  sail_assert (←((pure (N == 64)) <||> (do
    (pure (N == 32)) <&&> (do
      (UsingAArch32 ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:7747.45-7747.46"
  (pure (Sail.BitVec.extractLsb (← readReg _PC) (N -i 1) 0))

def UpdateEDSCRFields (_ : Unit) : SailM Unit := do
  let ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (Halted ()))) : Bool)
  then
    (do (EDSCR_write (_update_EDSCR_Type_EL (← (EDSCR_read ())) 0b00#2))
        (if ((← (HaveRME ())) : Bool)
        then
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalRootInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1))))))
              let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
              let __tmp ← (( do
                let split_vec ← do (__UNKNOWN_bits 2)
                let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb split_vec 1 1))
                (pure (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb split_vec 0 0))) ) : SailM (BitVec 32) )
              (EDSCR_write __tmp))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalSecureInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1))))))
              (EDSCR_write (_update_EDSCR_Type_NS (← (EDSCR_read ())) (← (__UNKNOWN_bit ()))))))
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) 0b1111#4)))
  else
    (do (EDSCR_write (_update_EDSCR_Type_EL (← (EDSCR_read ())) (← readReg PSTATE).EL))
        let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
        (if ((← (HaveRME ())) : Bool)
        then
          (do match ss with
              | .SS_Secure =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b00#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b00#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_NonSecure =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b01#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b01#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_Root =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b10#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b10#2 0 0))
                  (EDSCR_write __tmp))
              | .SS_Realm =>
                (do
                  let __tmp ← (( do (EDSCR_read ()) ) : SailM EDSCR_Type )
                  let __tmp : (BitVec 32) :=
                    let __tmp : EDSCR_Type := (Sail.BitVec.updateSubrange __tmp 15 15 (Sail.BitVec.extractLsb 0b11#2 1 1))
                    (Sail.BitVec.updateSubrange __tmp 18 18 (Sail.BitVec.extractLsb 0b11#2 0 0))
                  (EDSCR_write __tmp)))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_NS (← (EDSCR_read ()))
                  (if ((BEq.beq ss SS_Secure) : Bool)
                  then 0#1
                  else 1#1)))))
        let RW ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
        let RW ←
          (pure (BitVec.update RW 1
              (Bit
                (← do
                  (if ((← (ELUsingAArch32 EL1)) : Bool)
                  then (do (pure 0#1))
                  else (do (pure 1#1)))))))
        let RW ← (( do
          (if (((← readReg PSTATE).EL != EL0) : Bool)
          then (do (pure (BitVec.update RW 0 (Bit ((BitVec.access RW 1) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 0
                    (Bit
                      (← do
                        (if ((← (UsingAArch32 ())) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((←((pure (! (HaveEL EL2))) <||> (do
               (pure (HaveEL EL3)) <&&> (do
                 (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 0#1))) <&&> (do
                 (pure (! (← (IsSecureEL2Enabled ())))))))) : Bool)
          then (do (pure (BitVec.update RW 2 (Bit ((BitVec.access RW 1) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 2
                    (Bit
                      (← do
                        (if ((← (ELUsingAArch32 EL2)) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((! (HaveEL EL3)) : Bool)
          then (do (pure (BitVec.update RW 3 (Bit ((BitVec.access RW 2) : BitVec 1)))))
          else
            (do (pure (BitVec.update RW 3
                    (Bit
                      (← do
                        (if ((← (ELUsingAArch32 EL3)) : Bool)
                        then (do (pure 0#1))
                        else (do (pure 1#1))))))))) ) : SailM (BitVec 4) )
        let RW ← (( do
          (if ((((BitVec.access RW 3) : BitVec 1) == 0#1) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange RW 2 0 (← (__UNKNOWN_bits 3)))))
          else
            (do (if ((((BitVec.access RW 2) : BitVec 1) == 0#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange RW 1 0 (← (__UNKNOWN_bits 2)))))
                else
                  (do (if ((((BitVec.access RW 1) : BitVec 1) == 0#1) : Bool)
                      then (do (pure (BitVec.update RW 0 (Bit (← (__UNKNOWN_bit ()))))))
                      else (do (pure RW))))))) ) : SailM (BitVec 4) )
        (EDSCR_write (_update_EDSCR_Type_RW (← (EDSCR_read ())) RW))))

def CTI_SignalEvent (id : CrossTriggerIn) : Unit :=
  ()

def StopInstructionPrefetchAndEnableITR (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: k_is_async : Bool -/
def Halt__1 (reason : (BitVec 6)) (is_async : Bool) : SailM Unit := do
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
  then (do (FailTransaction TMFailure_DBG false))
  else (do (pure ())))
  let _ : Unit := (CTI_SignalEvent CrossTriggerIn_CrossHalt)
  let preferred_restart_address ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let spsr ← (( do (GetPSRFromPSTATE DebugState 64) ) : SailM (BitVec 64) )
  let spsr ← (( do
    (if ((←((pure (((← (HaveBTIExt ())) && (! is_async)) && (! ((reason == DebugHalt_Step_Normal) || ((reason == DebugHalt_Step_Exclusive) || ((reason == DebugHalt_Step_NoSyndrome) || ((reason == DebugHalt_Breakpoint) || (reason == DebugHalt_HaltInstruction)))))))) <&&> (do
         (ConstrainUnpredictableBool Unpredictable_ZEROBTYPE)))) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange spsr 11 10 0b00#2)))
    else (do (pure spsr))) ) : SailM (BitVec 64) )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do (DLR_write (Sail.BitVec.extractLsb preferred_restart_address 31 0))
        (DSPSR_write (Mk_DSPSR_Type (Sail.BitVec.extractLsb spsr 31 0)))
        (if ((← (Havev8p9Debug ())) : Bool)
        then (do (DSPSR2_write (Mk_DSPSR2_Type (Sail.BitVec.extractLsb spsr 63 32))))
        else (do (pure ()))))
  else
    (do writeReg DLR_EL0 preferred_restart_address
        writeReg DSPSR_EL0 (Mk_DSPSR_EL0_Type spsr)))
  (EDSCR_write (_update_EDSCR_Type_ITE (← (EDSCR_read ())) 1#1))
  (EDSCR_write (_update_EDSCR_Type_ITO (← (EDSCR_read ())) 0#1))
  (if ((← (HaveRME ())) : Bool)
  then
    (do (if (((← readReg PSTATE).EL == EL3) : Bool)
        then (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 0#1)))
        else
          (do (EDSCR_write
                (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                  (← do
                    (if ((← (ExternalRootInvasiveDebugEnabled ())) : Bool)
                    then (do (pure 0#1))
                    else (do (pure 1#1)))))))))
  else
    (do (if ((BEq.beq (← (CurrentSecurityState ())) SS_Secure) : Bool)
        then (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 0#1)))
        else
          (do (if ((HaveEL EL3) : Bool)
              then
                (do (EDSCR_write
                      (_update_EDSCR_Type_SDD (← (EDSCR_read ()))
                        (← do
                          (if ((← (ExternalSecureInvasiveDebugEnabled ())) : Bool)
                          then (do (pure 0#1))
                          else (do (pure 1#1)))))))
              else (do (EDSCR_write (_update_EDSCR_Type_SDD (← (EDSCR_read ())) 1#1))))))))
  (EDSCR_write (_update_EDSCR_Type_MA (← (EDSCR_read ())) 0#1))
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let split_vec ← do (__UNKNOWN_bits 14)
        writeReg PSTATE { (← readReg PSTATE) with IT := (Sail.BitVec.extractLsb split_vec 13 6) }
        writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 5 5) }
        writeReg PSTATE { (← readReg PSTATE) with SSBS := (Sail.BitVec.extractLsb split_vec 4 4) }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with T := (Sail.BitVec.extractLsb split_vec 0 0) })
  else
    (do let split_vec ← do (__UNKNOWN_bits 6)
        writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 5 5) }
        writeReg PSTATE { (← readReg PSTATE) with SSBS := (Sail.BitVec.extractLsb split_vec 4 4) }
        writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
        writeReg PSTATE { (← readReg PSTATE) with TCO := 1#1 }
        writeReg PSTATE { (← readReg PSTATE) with BTYPE := 0b00#2 }))
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  let _ : Unit := (StopInstructionPrefetchAndEnableITR ())
  (EDSCR_write (_update_EDSCR_Type_STATUS (← (EDSCR_read ())) reason))
  (UpdateEDSCRFields ())
  (if ((! is_async) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))

def Halt (reason : (BitVec 6)) : SailM Unit := do
  let is_async : Bool := false
  (Halt__1 reason is_async)

def undefined_DBGOSDLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGOSDLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_DBGOSDLR_Type_DLK (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_DBGOSDLR_Type_DLK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_OSDLR_EL1_Type_DLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_OSDLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_OSDLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def DBGOSDLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGOSDLR ) : SailM DBGOSDLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSDLR_EL1) 0 32)))

def undefined_DBGPRCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGPRCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DBGPRCR_EL1_Type_CORENPDRQ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_DBGPRCR_Type_CORENPDRQ (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_DBGPRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGPRCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGPRCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGPRCR ) : SailM DBGPRCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGPRCR_EL1) 0 32)))

def HaveDoubleLock (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleLock)

def DoubleLockStatus (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveDoubleLock ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((← (ELUsingAArch32 EL1)) : Bool)
        then (do (pure ((_get_DBGOSDLR_Type_DLK (← (DBGOSDLR_read ()))) == 1#1)) <&&> (do (pure ((_get_DBGPRCR_Type_CORENPDRQ (← (DBGPRCR_read ()))) == 0#1))) <&&> (do (pure (! (← (Halted ()))))))
        else (do (pure ((_get_OSDLR_EL1_Type_DLK (← readReg OSDLR_EL1)) == 1#1)) <&&> (do (pure ((_get_DBGPRCR_EL1_Type_CORENPDRQ (← readReg DBGPRCR_EL1)) == 0#1))) <&&> (do (pure (! (← (Halted ())))))))))

def HaltingAllowed (_ : Unit) : SailM Bool := do
  (if ((←((Halted ()) <||> (do
       (DoubleLockStatus ())))) : Bool)
  then (do (pure false))
  else
    (do let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
        match ss with
        | .SS_NonSecure => (ExternalInvasiveDebugEnabled ())
        | .SS_Secure => (ExternalSecureInvasiveDebugEnabled ())
        | .SS_Root => (ExternalRootInvasiveDebugEnabled ())
        | .SS_Realm => (ExternalRealmInvasiveDebugEnabled ())))

/-- Type quantifiers: k_N : Nat, y : Int, k_N ≥ 0 -/
def IsAligned__1 (x : (BitVec k_N)) (y : Int) : Bool :=
  (x == (Align_bits x y))

/-- Type quantifiers: k_round : Bool, shift : Int, value_name : Int -/
def RShr (value_name : Int) (shift : Int) (round : Bool) : SailM Int := do
  sail_assert (shift >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:8066.20-8066.21"
  (if (round : Bool)
  then (do (pure (Int.shiftr (value_name +i (Int.shiftl 1 (shift -i 1))) shift)))
  else (do (pure (Int.shiftr value_name shift))))

def IsHighestEL (el : (BitVec 2)) : Bool :=
  ((HighestEL ()) == el)

def EffectiveSCR_EL3_NSE (_ : Unit) : SailM (BitVec 1) := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure 0#1))
  else (do (pure (_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)))))

def ELFromM32 (mode : (BitVec 5)) : SailM (Bool × (BitVec 2)) := do
  let el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let valid_name ← (( do (pure (! (← (BadMode mode)))) ) : SailM Bool )
  let effective_nse_ns ← (( do (pure ((← (EffectiveSCR_EL3_NSE ())) +++ (← (EffectiveSCR_EL3_NS ())))) ) : SailM (BitVec 2) )
  let (el, valid_name) ← (( do
    let questionMark := mode
    let (el, valid_name) ← (( do
      (if ((questionMark == M32_Monitor) : Bool)
      then
        (do let el : (BitVec 2) := EL3
            (pure (el, valid_name)))
      else
        (do let (el, valid_name) ← (( do
              (if ((questionMark == M32_Hyp) : Bool)
              then
                (do let el : (BitVec 2) := EL2
                    (pure (el, valid_name)))
              else
                (do let (el, valid_name) ← (( do
                      (if ((questionMark == M32_FIQ) : Bool)
                      then
                        (do let el ←
                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                              then (do (pure EL3))
                              else (do (pure EL1)))
                            (pure (el, valid_name)))
                      else
                        (do let (el, valid_name) ← (( do
                              (if ((questionMark == M32_IRQ) : Bool)
                              then
                                (do let el ←
                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                      then (do (pure EL3))
                                      else (do (pure EL1)))
                                    (pure (el, valid_name)))
                              else
                                (do let (el, valid_name) ← (( do
                                      (if ((questionMark == M32_Svc) : Bool)
                                      then
                                        (do let el ←
                                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                              then (do (pure EL3))
                                              else (do (pure EL1)))
                                            (pure (el, valid_name)))
                                      else
                                        (do let (el, valid_name) ← (( do
                                              (if ((questionMark == M32_Abort) : Bool)
                                              then
                                                (do let el ←
                                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                      then (do (pure EL3))
                                                      else (do (pure EL1)))
                                                    (pure (el, valid_name)))
                                              else
                                                (do let (el, valid_name) ← (( do
                                                      (if ((questionMark == M32_Undef) : Bool)
                                                      then
                                                        (do let el ←
                                                              (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                                   (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                              then (do (pure EL3))
                                                              else (do (pure EL1)))
                                                            (pure (el, valid_name)))
                                                      else
                                                        (do let (el, valid_name) ← (( do
                                                              (if ((questionMark == M32_System) : Bool)
                                                              then
                                                                (do let el ←
                                                                      (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                           (pure (! (← (HaveAArch64 ()))))) <&&> (do
                                                                           (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
                                                                      then (do (pure EL3))
                                                                      else (do (pure EL1)))
                                                                    (pure (el, valid_name)))
                                                              else
                                                                (do let (el, valid_name) : ((BitVec 2) × Bool) :=
                                                                      if ((questionMark == M32_User) : Bool)
                                                                      then
                                                                        (let el : (BitVec 2) := EL0
                                                                        (el, valid_name))
                                                                      else
                                                                        (let valid_name : Bool := false
                                                                        (el, valid_name))
                                                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
                    (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
            (pure (el, valid_name)))) ) : SailM ((BitVec 2) × Bool) )
    (pure (el, valid_name)) ) : SailM ((BitVec 2) × Bool) )
  let valid_name ← (( do
    (if ((←((pure ((valid_name && (el == EL2)) && (HaveEL EL3))) <&&> (do
         (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
    then (do (pure false))
    else
      (do (if (((←((pure valid_name) <&&> (do
                 (HaveRME ())))) && (effective_nse_ns == 0b10#2)) : Bool)
          then (do (pure false))
          else (do (pure valid_name))))) ) : SailM Bool )
  let el ← (( do
    (if ((! valid_name) : Bool)
    then (do (__UNKNOWN_bits 2))
    else (do (pure el))) ) : SailM (BitVec 2) )
  let el := el
  (pure (valid_name, el))

def undefined_GCSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GCSCR_EL1_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL2_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL3_Type_EXLOCKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_GCSCR_EL1_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCRE0_EL1_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL2_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL3_Type_PCRSEL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GCSCR_EL1_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCRE0_EL1_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCR_EL2_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_GCSCR_EL3_Type_RVCHKEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def undefined_GCSCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_GCSCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def GetCurrentEXLOCKEN (_ : Unit) : SailM Bool := do
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then
    (do (Unreachable ())
        (undefined_bool ()))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do (pure ((_get_GCSCR_EL1_Type_EXLOCKEN (← readReg GCSCR_EL1)) == 1#1)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (pure ((_get_GCSCR_EL2_Type_EXLOCKEN (← readReg GCSCR_EL2)) == 1#1)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure ((_get_GCSCR_EL3_Type_EXLOCKEN (← readReg GCSCR_EL3)) == 1#1)))
                    else (do (undefined_bool ())))))))))

def AArch32_WriteMode (mode : (BitVec 5)) : SailM Unit := do
  let el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let valid_name ← (( do (undefined_bool ()) ) : SailM Bool )
  let (el, valid_name) ← (( do
    let (tup__0, tup__1) ← do (ELFromM32 mode)
    let valid_name : Bool := tup__0
    let el : (BitVec 2) := tup__1
    (pure (el, valid_name)) ) : SailM ((BitVec 2) × Bool) )
  sail_assert valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:8277.21-8277.22"
  writeReg PSTATE { (← readReg PSTATE) with M := mode }
  writeReg PSTATE { (← readReg PSTATE) with EL := el }
  writeReg PSTATE { (← readReg PSTATE) with nRW := 1#1 }
  writeReg PSTATE { (← readReg PSTATE) with SP := if (((mode == M32_User) || (mode == M32_System)) : Bool)
    then 0#1
    else 1#1 }

def undefined_MDSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDSCR_EL1_Type_EHBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _update_EDSCR2_Type_EHBWE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_EDSCR2_Type_EHBWE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_MDSCR_EL1_Type_EMBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_MDSCR_EL1_Type_KDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_MDSCR_EL1_Type_MDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def undefined_OSLSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_OSLSR_EL1_Type_OSLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_DBGOSLSR_Type_OSLK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_OSLAR_EL1_Type_OSLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_DBGOSLSR_Type_OSLM (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange (Sail.BitVec.updateSubrange v 3 3 (Sail.BitVec.extractLsb x (2 -i 1) (((2 -i 1) -i ((3 -i 3) +i 1)) +i 1))) 0 0 (Sail.BitVec.extractLsb x ((2 -i 1) -i ((3 -i 3) +i 1)) ((((2 -i 1) -i ((3 -i 3) +i 1)) -i ((0 -i 0) +i 1)) +i 1)))

def AArch64_GenerateDebugExceptionsFrom (from_el : (BitVec 2)) (from_state : SecurityState) (mask : (BitVec 1)) : SailM Bool := do
  (if ((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1)) <||> (do
       (DoubleLockStatus ())) <||> (do
       (Halted ())))) : Bool)
  then (do (pure false))
  else
    (do let route_to_el2 ← (( do (pure (HaveEL EL2)) <&&> (do (pure (bne from_state SS_Secure)) <||> (do (IsSecureEL2Enabled ()))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
        let target : (BitVec 2) :=
          if (route_to_el2 : Bool)
          then EL2
          else EL1
        let enabled ← (( do (undefined_bool ()) ) : SailM Bool )
        let enabled ← (( do
          (if (((HaveEL EL3) && (BEq.beq from_state SS_Secure)) : Bool)
          then
            (do let enabled ← (pure ((_get_MDCR_EL3_Type_SDD (← readReg MDCR_EL3)) == 0#1))
                (if ((←((pure (from_el == EL0)) <&&> (do
                     (ELUsingAArch32 EL1)))) : Bool)
                then (do (pure enabled) <||> (do (pure ((_get_SDER32_EL3_Type_SUIDEN (← (SDER32_EL3_read ()))) == 1#1))))
                else (do (pure enabled))))
          else (do (pure true))) ) : SailM Bool )
        (if ((from_el == target) : Bool)
        then (do (pure ((←((pure enabled) <&&> (do (pure ((_get_MDSCR_EL1_Type_KDE (← readReg MDSCR_EL1)) == 1#1))))) && (mask == 0#1))))
        else (do (pure (enabled && (((BitVec.toNat target) >b (BitVec.toNat from_el)) : Bool)))))))

def undefined_DBGOSLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGOSLSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGOSLSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGOSLSR ) : SailM DBGOSLSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSLSR_EL1) 0 32)))

def undefined_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HCR_Type_TAC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _get_HCR_Type_VA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HCR_Type_VA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def HCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCR ) : SailM HCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HCR_EL2) 0 32)))

def AArch64_GenerateDebugExceptions (_ : Unit) : SailM Bool := do
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  (AArch64_GenerateDebugExceptionsFrom (← readReg PSTATE).EL ss (← readReg PSTATE).D)

def undefined_HSCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HSCTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HSCTLR_Type_LSMAOE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_SCTLR_Type_LSMAOE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_HSCTLR_Type_nTLSMD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_SCTLR_Type_nTLSMD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_SCTLR_EL1_Type_nTLSMD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_SCTLR_EL2_Type_nTLSMD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def undefined_SCTLR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCTLR_EL2_Type_ATA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_SCTLR_EL1_Type_ATA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_DBGBCR_EL1_Type_BT (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_SCTLR_EL2_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HCRX_EL2_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_SCTLR_EL1_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_SCTLR_EL2_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL1_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL3_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL2_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL1_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL3_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL2_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL1_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL3_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL2_Type_TCF0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 39 38)

def _get_SCTLR_EL1_Type_TCF0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 39 38)

def _get_SCTLR_EL2_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL1_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL3_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL2_Type_TCSO0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_SCTLR_EL1_Type_TCSO0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def HSCTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HSCTLR ) : SailM HSCTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SCTLR_EL2) 0 32)))

def undefined_SCTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SCTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_SCTLR_Type_AFE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_SCTLR_Type_TRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_SCTLR_Type_UNK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_SCTLR_Type_UWXN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def SCTLR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SCTLR_NS ) : SailM SCTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SCTLR_EL1) 0 32)))

def SCTLR_read__2 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_SCTLR_Type ()) ) : SailM SCTLR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then
    (do let r ← readReg SCTLR_S
        let r : SCTLR_Type := (BitVec.update r 11 (Bit 1#1))
        (pure (BitVec.update r 22 (Bit 1#1))))
  else
    (do let r ← (SCTLR_NS_read ())
        let r : SCTLR_Type := (BitVec.update r 11 (Bit 1#1))
        (pure (BitVec.update r 22 (Bit 1#1)))))

def SCTLR_read (regime : (BitVec 2)) : SailM (BitVec 64) := do
  let r ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let r ← (( do
    let questionMark := regime
    (if ((questionMark == EL1) : Bool)
    then (do readReg SCTLR_EL1)
    else
      (do (if ((questionMark == EL2) : Bool)
          then (do readReg SCTLR_EL2)
          else
            (do (if ((questionMark == EL3) : Bool)
                then (do readReg SCTLR_EL3)
                else
                  (do (Unreachable ())
                      (pure r))))))) ) : SailM (BitVec 64) )
  (pure (Mk_SCTLRType r))

def SCTLR_read__1 (_ : Unit) : SailM (BitVec 64) := do
  (SCTLR_read (← (S1TranslationRegime__1 ())))

def IsCurrentSecurityState (ss : SecurityState) : SailM Bool := do
  (pure (BEq.beq (← (CurrentSecurityState ())) ss))

def ConditionHolds (cond : (BitVec 4)) : SailM Bool := do
  let result ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do
    match (Sail.BitVec.extractLsb cond 3 1) with
    | 0b000 => (do (pure ((← readReg PSTATE).Z == 1#1)))
    | 0b001 => (do (pure ((← readReg PSTATE).C == 1#1)))
    | 0b010 => (do (pure ((← readReg PSTATE).N == 1#1)))
    | 0b011 => (do (pure ((← readReg PSTATE).V == 1#1)))
    | 0b100 => (do (pure ((← readReg PSTATE).C == 1#1)) <&&> (do (pure ((← readReg PSTATE).Z == 0#1))))
    | 0b101 => (do (pure ((← readReg PSTATE).N == (← readReg PSTATE).V)))
    | 0b110 => (do (pure ((← readReg PSTATE).N == (← readReg PSTATE).V)) <&&> (do (pure ((← readReg PSTATE).Z == 0#1))))
    | _ => (pure true) ) : SailM Bool )
  (if (((((BitVec.access cond 0) : BitVec 1) == 1#1) && (cond != 0b1111#4)) : Bool)
  then (do (pure (! result)))
  else (do (pure result)))

def ThisInstrLength (_ : Unit) : SailM Int := do
  (if ((BEq.beq (← readReg __ThisInstrEnc) __T16) : Bool)
  then (do (pure 16))
  else (do (pure 32)))

def undefined_ESR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ESR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ESR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_HPFAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HPFAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HavePFAR (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PFAR)

def undefined_MFAR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MFAR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PFAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PFAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PFAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PFAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveDoubleFaultExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleFault)

def ResetSVEState (_ : Unit) : SailM Unit := do
  let loop_n_lower := 0
  let loop_n_upper := 31
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do writeReg _Z (vectorUpdate (← readReg _Z) n (Zeros (n := MAX_VL)))
  (pure loop_vars)
  let loop_n_lower := 0
  let loop_n_upper := 15
  let mut loop_vars_1 := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars_1
    loop_vars_1 ← do writeReg _P (vectorUpdate (← readReg _P) n (Zeros (n := MAX_PL)))
  (pure loop_vars_1)
  writeReg _FFR (Zeros (n := MAX_PL))
  writeReg FPSR (Mk_FPSR_Type (Sail.BitVec.zeroExtend 0x0800009F#32 64))

def undefined_SPSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_abt_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_abt_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_fiq_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_fiq_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_hyp_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_hyp_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SPSR_hyp_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SPSR_hyp ) : SailM SPSR_hyp_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SPSR_EL2) 0 32)))

def SPSR_hyp_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SPSR_hyp_Type := value_name
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _SPSR_hyp r

def undefined_SPSR_irq_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_irq_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_mon_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_mon_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_SPSR_svc_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_svc_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SPSR_svc_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SPSR_svc ) : SailM SPSR_svc_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SPSR_EL1) 0 32)))

def SPSR_svc_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SPSR_svc_Type := value_name
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _SPSR_svc r

def undefined_SPSR_und_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_und_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def SPSR_set {N : _} (value_name : (BitVec N)) : SailM Unit := do
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do sail_assert (N == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:9811.22-9811.23"
        let questionMark ← do (pure (← readReg PSTATE).M)
        (if ((questionMark == M32_FIQ) : Bool)
        then (do writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
        else
          (do (if ((questionMark == M32_IRQ) : Bool)
              then (do writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
              else
                (do (if ((questionMark == M32_Svc) : Bool)
                    then (do (SPSR_svc_write (Mk_SPSR_svc_Type (Sail.BitVec.updateSubrange (← (SPSR_svc_read ())) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))))
                    else
                      (do (if ((questionMark == M32_Monitor) : Bool)
                          then (do writeReg SPSR_mon (Sail.BitVec.updateSubrange (← readReg SPSR_mon) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                          else
                            (do (if ((questionMark == M32_Abort) : Bool)
                                then (do writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                                else
                                  (do (if ((questionMark == M32_Hyp) : Bool)
                                      then (do (SPSR_hyp_write (Mk_SPSR_hyp_Type (Sail.BitVec.updateSubrange (← (SPSR_hyp_read ())) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))))
                                      else
                                        (do (if ((questionMark == M32_Undef) : Bool)
                                            then (do writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                                            else (do (Unreachable ()))))))))))))))))
  else
    (do sail_assert (N == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:9839.22-9839.23"
        let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL1) : Bool)
        then (do writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                    else (do (Unreachable ())))))))))

def SynchronizeContext (_ : Unit) : Unit :=
  ()

def SynchronizeErrors (_ : Unit) : Unit :=
  ()

def undefined_EDECCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDECCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_EDECCR_Type_NSE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_EDECCR_Type_NSE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_EDECCR_Type_NSR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_EDECCR_Type_NSR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _update_EDECCR_Type_NSR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _update_EDECCR_Type_RLE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _update_EDECCR_Type_RLE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_EDECCR_Type_RLR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _update_EDECCR_Type_RLR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _update_EDECCR_Type_RLR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _update_EDECCR_Type_SE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_EDECCR_Type_SE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_EDECCR_Type_SE3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_EDECCR_Type_SR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_EDECCR_Type_SR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_EDECCR_Type_SR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_EDECCR_Type_SR3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def undefined_OSECCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_OSECCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def EDECCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDECCR ) : SailM EDECCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSECCR_EL1) 0 32)))

def undefined_EDESR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HaveExtendedECDebugEvents (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def Havev8p8Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p8)

/-- Type quantifiers: k_exception_entry : Bool -/
def CheckExceptionCatch (exception_entry : Bool) : SailM Unit := do
  let ctrl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let exception_exit ← (( do (undefined_bool ()) ) : SailM Bool )
  let increment_name ← (( do (undefined_int ()) ) : SailM Int )
  let ss ← (( do (SecurityStateAtEL (← readReg PSTATE).EL) ) : SailM SecurityState )
  let base : Int := 0
  let base : Int :=
    match ss with
    | .SS_Secure => 0
    | .SS_NonSecure => 4
    | .SS_Realm => 16
    | .SS_Root => 0
  let base := base
  (if ((← (HaltingAllowed ())) : Bool)
  then
    (do let halt ← (( do (undefined_bool ()) ) : SailM Bool )
        let halt ← (( do
          (if ((← (HaveExtendedECDebugEvents ())) : Bool)
          then
            (do let exception_exit : Bool := (! exception_entry)
                let increment_name :=
                  if ((BEq.beq ss SS_Realm) : Bool)
                  then 4
                  else 8
                let ctrl ← (( do (pure (((BitVec.access (← (EDECCR_read ())) (((BitVec.toNat (← readReg PSTATE).EL) +i base) +i increment_name)) : BitVec 1) +++ ((BitVec.access (← (EDECCR_read ())) ((BitVec.toNat (← readReg PSTATE).EL) +i base)) : BitVec 1))) ) : SailM (BitVec 2) )
                match ctrl with
                | 0b00 => (pure false)
                | 0b01 => (pure true)
                | 0b10 => (pure (exception_exit == true))
                | _ => (pure (exception_entry == true)))
          else (do (pure (((BitVec.access (← (EDECCR_read ())) ((BitVec.toNat (← readReg PSTATE).EL) +i base)) : BitVec 1) == 1#1)))) ) : SailM Bool )
        (if (halt : Bool)
        then
          (do (if (((← (Havev8p8Debug ())) && exception_entry) : Bool)
              then (do writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 3 3 1#1))
              else (do (Halt DebugHalt_ExceptionCatch))))
        else (do (pure ()))))
  else (do (pure ())))

def HaveNV2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NV2)

def HaveNVExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NV)

def VBAR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VBAR_NS ) : SailM VBAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VBAR_EL1) 0 32)))

def VBAR_read__2 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_bitvector 32) ) : SailM VBAR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg VBAR_S)
  else (do (VBAR_NS_read ())))

/-- Type quantifiers: vect_offset_in : Int -/
def AArch64_TakeException (target_el : (BitVec 2)) (exception_in : ExceptionRecord) (preferred_exception_return : (BitVec 64)) (vect_offset_in : Int) : SailM Unit := do
  writeReg __janus_exc_taken true
  writeReg __janus_exc_target_el target_el
  writeReg __janus_exc_type exception_in.exceptype
  writeReg __janus_exc_syndrome exception_in.syndrome
  writeReg __janus_exc_vaddress exception_in.vaddress
  sailThrow ((Error_ExceptionTaken ()))

def ExceptionSyndrome (exceptype : Exception) : SailM ExceptionRecord := do
  let r ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let r : ExceptionRecord := { r with exceptype := exceptype }
  let r : ExceptionRecord := { r with syndrome := (Zeros (n := 25)) }
  let r : ExceptionRecord := { r with syndrome2 := (Zeros (n := 24)) }
  let r : ExceptionRecord := { r with vaddress := (Zeros (n := 64)) }
  let r : ExceptionRecord := { r with ipavalid := false }
  let r : ExceptionRecord := { r with NS := 0#1 }
  let r : ExceptionRecord := { r with ipaddress := (Zeros (n := 56)) }
  let r ← (pure { r with paddress := (← do (pure { r.paddress with paspace := (← do (__UNKNOWN_PASpace ())) })) })
  let r ← (pure { r with paddress := (← do (pure { r.paddress with address := (← do (__UNKNOWN_bits 56)) })) })
  (pure { r with trappedsyscallinst := false })

def AArch64_BranchTargetException (vaddress : (BitVec 52)) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_BranchTarget) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 1 0 (← readReg PSTATE).BTYPE))) })
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 2 (Zeros (n := 23))) }
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def ThisInstr (_ : Unit) : SailM (BitVec 32) := do
  readReg __ThisInstr

def AArch64_ExecutingBROrBLROrRetInstr (_ : Unit) : SailM Bool := do
  let opc ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((! (← (HaveBTIExt ()))) : Bool)
  then (do (pure false))
  else
    (do let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
        (if ((((Sail.BitVec.extractLsb instr 31 25) == 0b1101011#7) && ((Sail.BitVec.extractLsb instr 20 16) == 0b11111#5)) : Bool)
        then
          (do let opc : (BitVec 4) := (Sail.BitVec.extractLsb instr 24 21)
              (pure (opc != 0b0101#4)))
        else (do (pure false)))))

def AArch64_ExecutingBTIInstr (_ : Unit) : SailM Bool := do
  let CRm ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let op2 ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  (if ((! (← (HaveBTIExt ()))) : Bool)
  then (do (pure false))
  else
    (do let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
        (if (((((Sail.BitVec.extractLsb instr 31 22) == 0b1101010100#10) && ((Sail.BitVec.extractLsb instr 21 12) == 0b0000110010#10)) && ((Sail.BitVec.extractLsb instr 4 0) == 0b11111#5)) : Bool)
        then
          (do let CRm : (BitVec 4) := (Sail.BitVec.extractLsb instr 11 8)
              let op2 : (BitVec 3) := (Sail.BitVec.extractLsb instr 7 5)
              (pure ((CRm == 0b0100#4) && (((BitVec.access op2 0) : BitVec 1) == 0#1))))
        else (do (pure false)))))

def BranchTargetCheck (_ : Unit) : SailM Unit := do
  sail_assert (←((HaveBTIExt ()) <&&> (do
    (pure (! (← (UsingAArch32 ()))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:10588.50-10588.51"
  (if ((←(readReg InGuardedPage <&&> (do
       (pure ((← readReg PSTATE).BTYPE != 0b00#2))) <&&> (do
       (pure (! (← readReg BTypeCompatible)))) <&&> (do
       (pure (! (← (Halted ()))))))) : Bool)
  then
    (do let pc ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
        (AArch64_BranchTargetException (Sail.BitVec.extractLsb pc 51 0)))
  else (do (pure ())))
  let branch_instr ← (( do (AArch64_ExecutingBROrBLROrRetInstr ()) ) : SailM Bool )
  let bti_instr ← (( do (AArch64_ExecutingBTIInstr ()) ) : SailM Bool )
  (if ((! (branch_instr || bti_instr)) : Bool)
  then (do writeReg BTypeNext 0b00#2)
  else (do (pure ())))

def AArch32_CurrentCond (_ : Unit) : SailM (BitVec 4) := do
  readReg __currentCond

def ConditionSyndrome (_ : Unit) : SailM (BitVec 5) := do
  let cond ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let syndrome ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let cond ← (( do (AArch32_CurrentCond ()) ) : SailM (BitVec 4) )
        (if (((← readReg PSTATE).T == 0#1) : Bool)
        then
          (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
              (if ((←((ConditionHolds cond) <&&> (do
                   (ConstrainUnpredictableBool Unpredictable_ESRCONDPASS)))) : Bool)
              then (do (pure (Sail.BitVec.updateSubrange syndrome 3 0 0b1110#4)))
              else (do (pure (Sail.BitVec.updateSubrange syndrome 3 0 cond)))))
        else
          (do (if ((← (__IMPDEF_boolean "Condition valid for trapped T32")) : Bool)
              then
                (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
                    (pure (Sail.BitVec.updateSubrange syndrome 3 0 cond)))
              else
                (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 0#1))
                    (pure (Sail.BitVec.updateSubrange syndrome 3 0 (← (__UNKNOWN_bits 4)))))))))
  else
    (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
        (pure (Sail.BitVec.updateSubrange syndrome 3 0 0b1110#4))))

def AArch64_WFxTrap (wfxtype : WFxType) (target_el : (BitVec 2)) : SailM Unit := do
  sail_assert ((BitVec.toNat target_el) >b (BitVec.toNat (← readReg PSTATE).EL)) "sail-arm/arm-v9.4-a/src/v8_base.sail:10642.44-10642.45"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_WFxTrap) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) })
  let except ← (( do
    match wfxtype with
    | .WFxType_WFI => (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b00#2) })
    | .WFxType_WFE => (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b01#2) })
    | .WFxType_WFIT =>
      (do
        let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b10#2) }
        let except : ExceptionRecord := { except with syndrome := (BitVec.update except.syndrome 2 (Bit 1#1)) }
        (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) }))
    | .WFxType_WFET =>
      (do
        let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b11#2) }
        let except : ExceptionRecord := { except with syndrome := (BitVec.update except.syndrome 2 (Bit 1#1)) }
        (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) })) ) : SailM ExceptionRecord )
  (if ((←((pure (target_el == EL1)) <&&> (do
       (EL2Enabled ())) <&&> (do
       (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
  then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else (do (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def AArch64_CheckForWFxTrap (target_el : (BitVec 2)) (wfxtype : WFxType) : SailM Unit := do
  sail_assert (HaveEL target_el) "sail-arm/arm-v9.4-a/src/v8_base.sail:10675.28-10675.29"
  let is_wfe : Bool := ((BEq.beq wfxtype WFxType_WFE) || (BEq.beq wfxtype WFxType_WFET))
  let trap ← (( do (undefined_bool ()) ) : SailM Bool )
  let trap ← (( do
    let questionMark := target_el
    (if ((questionMark == EL1) : Bool)
    then
      (do (pure ((← do
                (if (is_wfe : Bool)
                then (do (pure (_get_SCTLRType_nTWE (← (SCTLR_read__1 ())))))
                else (do (pure (_get_SCTLRType_nTWI (← (SCTLR_read__1 ()))))))) == 0#1)))
    else
      (do (if ((questionMark == EL2) : Bool)
          then
            (do (pure ((← do
                      (if (is_wfe : Bool)
                      then (do (pure (_get_HCR_EL2_Type_TWE (← readReg HCR_EL2))))
                      else (do (pure (_get_HCR_EL2_Type_TWI (← readReg HCR_EL2)))))) == 1#1)))
          else
            (do (if ((questionMark == EL3) : Bool)
                then
                  (do (pure ((← do
                            (if (is_wfe : Bool)
                            then (do (pure (_get_SCR_EL3_Type_TWE (← readReg SCR_EL3))))
                            else (do (pure (_get_SCR_EL3_Type_TWI (← readReg SCR_EL3)))))) == 1#1)))
                else (do (pure trap))))))) ) : SailM Bool )
  (if (trap : Bool)
  then (do (AArch64_WFxTrap wfxtype target_el))
  else (do (pure ())))

def ClearEventRegister (_ : Unit) : SailM Unit := do
  writeReg EventRegister 0#1

def HaveFeatWFxT (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_WFxT)

def HaveTWEDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TWED)

def IsEventRegisterSet (_ : Unit) : SailM Bool := do
  (pure ((← readReg EventRegister) == 1#1))

def WFETrapDelay (target_el : (BitVec 2)) : SailM (Bool × Int) := do
  let delay_enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let delay ← (( do (undefined_int ()) ) : SailM Int )
  let (delay, delay_enabled) ← (( do
    let questionMark := target_el
    let (delay, delay_enabled) ← (( do
      (if ((questionMark == EL1) : Bool)
      then
        (do let (delay, delay_enabled) ← (( do
              (if ((! (← (IsInHost ()))) : Bool)
              then
                (do let delay_enabled ← (pure ((_get_SCTLR_EL1_Type_TWEDEn (← readReg SCTLR_EL1)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCTLR_EL1_Type_TWEDEL (← readReg SCTLR_EL1))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))
              else
                (do let delay_enabled ← (pure ((_get_SCTLR_EL2_Type_TWEDEn (← readReg SCTLR_EL2)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCTLR_EL2_Type_TWEDEL (← readReg SCTLR_EL2))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
            (pure (delay, delay_enabled)))
      else
        (do let (delay, delay_enabled) ← (( do
              (if ((questionMark == EL2) : Bool)
              then
                (do sail_assert (← (EL2Enabled ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:10740.29-10740.30"
                    let delay_enabled ← (pure ((_get_HCR_EL2_Type_TWEDEn (← readReg HCR_EL2)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_HCR_EL2_Type_TWEDEL (← readReg HCR_EL2))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))
              else
                (do let (delay, delay_enabled) ← (( do
                      (if ((questionMark == EL3) : Bool)
                      then
                        (do let delay_enabled ← (pure ((_get_SCR_EL3_Type_TWEDEn (← readReg SCR_EL3)) == 1#1))
                            let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCR_EL3_Type_TWEDEL (← readReg SCR_EL3))) +i 8))) ) : SailM Int )
                            (pure (delay, delay_enabled)))
                      else (do (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
                    (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
            (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
    (pure (delay, delay_enabled)) ) : SailM (Int × Bool) )
  let delay := delay
  (pure (delay_enabled, delay))

def EnterLowPowerState (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: localtimeout : Int -/
def LocalTimeoutEvent (localtimeout : Int) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: localtimeout : Int -/
def WaitForEvent (localtimeout : Int) : SailM Unit := do
  (if ((! (←((IsEventRegisterSet ()) <||> (do
         (HaveFeatWFxT ()) <&&> (do
           (LocalTimeoutEvent localtimeout)))))) : Bool)
  then
    (do writeReg IsWFEsleep true
        writeReg _DormantCtlReg (Sail.BitVec.updateSubrange (← readReg _DormantCtlReg) 10 10 1#1)
        (pure (EnterLowPowerState ())))
  else (do (pure ())))

/-- Type quantifiers: delay : Int, k_delay_enabled : Bool -/
def WaitForEventUntilDelay (delay_enabled : Bool) (delay : Int) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: localtimeout : Int -/
def Hint_WFE (localtimeout : Int) (wfxtype : WFxType) : SailM Unit := do
  let delay ← (( do (undefined_int ()) ) : SailM Int )
  let delay_enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let sctlr ← (( do (undefined_SCTLRType ()) ) : SailM SCTLRType )
  let trap ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (IsEventRegisterSet ())) : Bool)
  then (do (ClearEventRegister ()))
  else
    (do (if ((←((HaveFeatWFxT ()) <&&> (do
             (LocalTimeoutEvent localtimeout)))) : Bool)
        then (do (EndOfInstruction ()))
        else
          (do let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
              let trap : Bool := false
              let (target_el, trap) ← (( do
                (if (((← readReg PSTATE).EL == EL0) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let sctlr ← (( do (SCTLR_read__1 ()) ) : SailM SCTLRType )
                              let trap : Bool := ((_get_SCTLRType_nTWE sctlr) == 0#1)
                              let target_el : (BitVec 2) := EL1
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL1 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              let (target_el, trap) ← (( do
                (if ((←((pure (! trap)) <&&> (do
                     (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                       (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
                     (EL2Enabled ())) <&&> (do
                     (pure (! (← (IsInHost ()))))))) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let trap ← (pure ((_get_HCR_EL2_Type_TWE (← readReg HCR_EL2)) == 1#1))
                              let target_el : (BitVec 2) := EL2
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL2 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              let (target_el, trap) ← (( do
                (if ((←((pure ((! trap) && (HaveEL EL3))) <&&> (do
                     (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let trap ← (pure ((_get_SCR_EL3_Type_TWE (← readReg SCR_EL3)) == 1#1))
                              let target_el : (BitVec 2) := EL3
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL3 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              (if ((←((pure trap) <&&> (do
                   (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
              then
                (do let (delay, delay_enabled) ← (( do
                      let (tup__0, tup__1) ← do (WFETrapDelay target_el)
                      let delay_enabled : Bool := tup__0
                      let delay : Int := tup__1
                      (pure (delay, delay_enabled)) ) : SailM (Int × Bool) )
                    let delay := delay
                    (if ((! (← (WaitForEventUntilDelay delay_enabled delay))) : Bool)
                    then (do (AArch64_WFxTrap wfxtype target_el))
                    else (do (pure ()))))
              else (do (WaitForEvent localtimeout)))))))

def IsVirtualSErrorPending (_ : Unit) : SailM Bool := do
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do (pure ((_get_HCR_Type_VA (← (HCR_read ()))) == 1#1)))
  else (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1))))

def FIQPending (_ : Unit) : (Bool × Bool) :=
  (false, false)

def __GIC_InterruptPending (_ : Unit) : SailM Bool := do
  (pure (is_some (← readReg __GIC_Pending)))

def IRQPending (_ : Unit) : SailM (Bool × Bool) := do
  (pure ((← (__GIC_InterruptPending ())), false))

def IsPhysicalSErrorPending (_ : Unit) : Bool :=
  false

def VirtualFIQPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def VirtualIRQPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def InterruptPending (_ : Unit) : SailM Bool := do
  let fiq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let pending_virtual_interrupt : Bool := false
  let irq_pending ← (( do
    let (__tup_0, _) ← do (IRQPending ())
    (pure __tup_0) ) : SailM Bool )
  let fiq_pending : Bool :=
    let (__tup_0, _) := (FIQPending ())
    __tup_0
  let pending_physical_interrupt : Bool := ((irq_pending || fiq_pending) || (IsPhysicalSErrorPending ()))
  let pending_virtual_interrupt ← (( do
    (if ((←((EL2Enabled ()) <&&> (do
         (pure ((← readReg PSTATE).EL == EL0)) <||> (do
           (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
    then
      (do let virq_pending ← (( do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (VirtualIRQPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VI (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          let vfiq_pending ← (( do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (VirtualFIQPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VF (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          let vsei_pending ← (( do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (IsVirtualSErrorPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          (pure ((vsei_pending || virq_pending) || vfiq_pending)))
    else (do (pure pending_virtual_interrupt))) ) : SailM Bool )
  (pure (pending_physical_interrupt || pending_virtual_interrupt))

/-- Type quantifiers: localtimeout : Int -/
def WaitForInterrupt (localtimeout : Int) : SailM Unit := do
  (if ((! (←((HaveFeatWFxT ()) <&&> (do
         (LocalTimeoutEvent localtimeout))))) : Bool)
  then
    (do writeReg IsWFIsleep true
        writeReg _DormantCtlReg (Sail.BitVec.updateSubrange (← readReg _DormantCtlReg) 0 0 1#1)
        (pure (EnterLowPowerState ())))
  else (do (pure ())))

/-- Type quantifiers: localtimeout : Int -/
def Hint_WFI (localtimeout : Int) (wfxtype : WFxType) : SailM Unit := do
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
  then (do (FailTransaction TMFailure_ERR false))
  else (do (pure ())))
  (if ((←((InterruptPending ()) <||> (do
       (HaveFeatWFxT ()) <&&> (do
         (LocalTimeoutEvent localtimeout))))) : Bool)
  then (do (EndOfInstruction ()))
  else
    (do (if (((← readReg PSTATE).EL == EL0) : Bool)
        then (do (AArch64_CheckForWFxTrap EL1 wfxtype))
        else (do (pure ())))
        (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
             (EL2Enabled ())) <&&> (do
             (pure (! (← (IsInHost ()))))))) : Bool)
        then (do (AArch64_CheckForWFxTrap EL2 wfxtype))
        else (do (pure ())))
        (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
        then (do (AArch64_CheckForWFxTrap EL3 wfxtype))
        else (do (pure ())))
        (WaitForInterrupt localtimeout)))

def SendEventLocal (_ : Unit) : SailM Unit := do
  writeReg EventRegister 1#1

def EffectiveEA (_ : Unit) : SailM (BitVec 1) := do
  (if ((←((Halted ()) <&&> (do
       (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 0#1))))) : Bool)
  then (do (pure 0#1))
  else
    (do (if ((← (HaveAArch64 ())) : Bool)
        then (do (pure (_get_SCR_EL3_Type_EA (← readReg SCR_EL3))))
        else (do (pure (_get_SCR_Type_EA (← readReg SCR)))))))

def EL3SDDUndefPriority (_ : Unit) : SailM Bool := do
  (Halted ()) <&&> (do
    (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
    (__IMPDEF_boolean "EL3 trap priority when SDD == '1'"))

def EL3SDDUndef (_ : Unit) : SailM Bool := do
  (Halted ()) <&&> (do
    (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1)))

def undefined_GCSCRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCRE0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def GCSPCRSelected (el : (BitVec 2)) : SailM Bool := SailME.run do
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then (do SailME.throw (← do (pure ((_get_GCSCRE0_EL1_Type_PCRSEL (← readReg GCSCRE0_EL1)) == 1#1))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do SailME.throw (← do (pure ((_get_GCSCR_EL1_Type_PCRSEL (← readReg GCSCR_EL1)) == 1#1))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do SailME.throw (← do (pure ((_get_GCSCR_EL2_Type_PCRSEL (← readReg GCSCR_EL2)) == 1#1))))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do SailME.throw (← do (pure ((_get_GCSCR_EL3_Type_PCRSEL (← readReg GCSCR_EL3)) == 1#1))))
                    else (do (pure ())))))))))
  (Unreachable ())
  (pure true)

def undefined_HCRX_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HCRX_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HCRX_EL2_Type_FnXS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HCRX_EL2_Type_TALLINT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_HCRX_EL2_Type_VFNMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HCRX_EL2_Type_VINMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def HaveFeatHCX (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HCX)

def IsHCRXEL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatHCX ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_HXEn (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def GCSEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure ((HaveEL EL3) && (el != EL3))) <&&> (do
             (pure ((_get_SCR_EL3_Type_GCSEn (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
                   (EL2Enabled ())) <&&> (do
                   (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1)))) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_GCSEn (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (GCSPCRSelected el)))))))

def AArch64_ChkFeat (feat_select : (BitVec 64)) : SailM (BitVec 64) := do
  let feat_en : (BitVec 64) := (Zeros (n := 64))
  let feat_en ←
    (pure (BitVec.update feat_en 0
        (Bit
          (← do
            (if ((←((HaveGCS ()) <&&> (do
                 (GCSEnabled (← readReg PSTATE).EL)))) : Bool)
            then (do (pure 1#1))
            else (do (pure 0#1)))))))
  (pure (feat_select &&& (Complement.complement feat_en)))

def TAG_GRANULE : Nat := 16

def BigEndian (acctype : AccessType) : SailM Bool := do
  let bigend ← (( do (undefined_bool ()) ) : SailM Bool )
  (if (((← (HaveNV2Ext ())) && (BEq.beq acctype AccessType_NV2)) : Bool)
  then (do (pure ((_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)) == 1#1)))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (pure ((← readReg PSTATE).E != 0#1)))
        else
          (do (if (((← readReg PSTATE).EL == EL0) : Bool)
              then (do (pure ((_get_SCTLRType_E0E (← (SCTLR_read__1 ()))) != 0#1)))
              else (do (pure ((_get_SCTLRType_EE (← (SCTLR_read__1 ()))) != 0#1))))))))

def IsDataAccess (acctype : AccessType) : Bool :=
  (! ((BEq.beq acctype AccessType_IFETCH) || ((BEq.beq acctype AccessType_TTW) || ((BEq.beq acctype AccessType_DC) || ((BEq.beq acctype AccessType_IC) || (BEq.beq acctype AccessType_AT))))))

def EffectiveTCMA (address : (BitVec 64)) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let tcma ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:11075.21-11075.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:11077.43-11077.44"
  let questionMark := regime
  (if ((questionMark == EL1) : Bool)
  then
    (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
        then (do (pure (_get_TCR_EL1_Type_TCMA1 (← readReg TCR_EL1))))
        else (do (pure (_get_TCR_EL1_Type_TCMA0 (← readReg TCR_EL1))))))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (ELIsInHost el)))) : Bool)
              then
                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                    then (do (pure (_get_TCR_EL2_Type_TCMA1 (← readReg TCR_EL2))))
                    else (do (pure (_get_TCR_EL2_Type_TCMA0 (← readReg TCR_EL2))))))
              else (do (pure (_get_TCR_EL2_Type_TCMA (← readReg TCR_EL2))))))
        else
          (do (if ((questionMark == EL3) : Bool)
              then (do (pure (_get_TCR_EL3_Type_TCMA (← readReg TCR_EL3))))
              else (do (pure tcma)))))))

def HaveMTE4Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

/-- Type quantifiers: k_is_instr : Bool -/
def EffectiveMTX (address : (BitVec 64)) (is_instr : Bool) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let mtx ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:11109.21-11109.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:11111.43-11111.44"
  (if (((! (← (HaveMTE4Ext ()))) || is_instr) : Bool)
  then (do (pure 0#1))
  else
    (do let questionMark := regime
        (if ((questionMark == EL1) : Bool)
        then
          (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
              then (do (pure (_get_TCR_EL1_Type_MTX1 (← readReg TCR_EL1))))
              else (do (pure (_get_TCR_EL1_Type_MTX0 (← readReg TCR_EL1))))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((←((HaveVirtHostExt ()) <&&> (do
                         (ELIsInHost el)))) : Bool)
                    then
                      (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                          then (do (pure (_get_TCR_EL2_Type_MTX1 (← readReg TCR_EL2))))
                          else (do (pure (_get_TCR_EL2_Type_MTX0 (← readReg TCR_EL2))))))
                    else (do (pure (_get_TCR_EL2_Type_MTX (← readReg TCR_EL2))))))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure (_get_TCR_EL3_Type_MTX (← readReg TCR_EL3))))
                    else (do (pure mtx)))))))))

def undefined_MPAM2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAM2_EL2_Type_ALTSP_EL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_MPAM2_EL2_Type_ALTSP_HFC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_MPAM3_EL3_Type_ALTSP_HFC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_MPAM2_EL2_Type_EnMPAMSM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_MPAM2_EL2_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _update_MPAM1_EL1_Type_MPAMEN (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 63 63 x)

def _update_MPAM3_EL3_Type_MPAMEN (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 63 63 x)

def _get_MPAM1_EL1_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_MPAM3_EL3_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_MPAM2_EL2_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM0_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM1_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM3_EL3_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAMSM_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM2_EL2_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM0_EL1_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM1_EL1_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM3_EL3_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM2_EL2_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM0_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM1_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM3_EL3_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAMSM_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM2_EL2_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM0_EL1_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM1_EL1_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM3_EL3_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM2_EL2_Type_TRAPMPAM0EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_MPAM2_EL2_Type_TRAPMPAM1EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def undefined_MPAM3_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM3_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAM3_EL3_Type_ALTSP_EL3 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_MPAM3_EL3_Type_ALTSP_HEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_MPAM3_EL3_Type_FORCE_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_MPAM3_EL3_Type_RT_ALTSP_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_MPAM3_EL3_Type_SDEFLT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_MPAM3_EL3_Type_TRAPLOWER (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _update_MPAM3_EL3_Type_TRAPLOWER (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 62 62 x)

def MPAM3_EL3_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _MPAM3_EL3 ) : SailM MPAM3_EL3_Type )
  (pure (BitVec.update r 63 (Bit (BitVec.slice (← readReg MPAM2_EL2) 63 1))))

def undefined_MPAM1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def MPAM1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _MPAM1_EL1 ) : SailM MPAM1_EL1_Type )
  (if ((HaveEL EL3) : Bool)
  then (do (pure (BitVec.update r 63 (Bit (BitVec.slice (← (MPAM3_EL3_read ())) 63 1)))))
  else (do (pure (BitVec.update r 63 (Bit (BitVec.slice (← readReg MPAM2_EL2) 63 1))))))

def MPAMisEnabled (_ : Unit) : SailM Bool := do
  let el : (BitVec 2) := (HighestEL ())
  let questionMark := el
  (if ((questionMark == EL3) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_MPAMEN (← (MPAM3_EL3_read ()))) == 1#1)))
  else
    (do (if ((questionMark == EL2) : Bool)
        then (do (pure ((_get_MPAM2_EL2_Type_MPAMEN (← readReg MPAM2_EL2)) == 1#1)))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do (pure ((_get_MPAM1_EL1_Type_MPAMEN (← (MPAM1_EL1_read ()))) == 1#1)))
              else (do (undefined_bool ())))))))

def UsePrimarySpaceEL10 (_ : Unit) : SailM Bool := do
  (if (((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 0#1)))
  else (do (pure (! (← (MPAMisEnabled ())))) <||> (do (pure (! (← (EL2Enabled ()))))) <||> (do (pure ((_get_MPAM2_EL2_Type_ALTSP_HFC (← readReg MPAM2_EL2)) == 0#1)))))

def UsePrimarySpaceEL2 (_ : Unit) : SailM Bool := do
  (if (((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 0#1)))
  else (do (pure (! (← (MPAMisEnabled ())))) <||> (do (pure ((_get_MPAM2_EL2_Type_ALTSP_EL2 (← readReg MPAM2_EL2)) == 0#1)))))

def AltPIdRealm (el : (BitVec 2)) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  let PIdSpace : PARTIDspaceType := primaryPIdSpace
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then
    (do (if ((← (ELIsInHost EL0)) : Bool)
        then
          (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))
        else
          (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then
          (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (Unreachable ())
                    (pure PIdSpace)))))))

def AltPIdSecure (el : (BitVec 2)) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  let PIdSpace : PARTIDspaceType := primaryPIdSpace
  let el2en ← (( do (EL2Enabled ()) ) : SailM Bool )
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then
    (do (if (el2en : Bool)
        then
          (do (if ((← (ELIsInHost EL0)) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))))
        else
          (do (if ((←((pure ((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1)) <&&> (do
                   (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 1#1))))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then
          (do (if (el2en : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (if ((←((pure ((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1)) <&&> (do
                         (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 1#1))))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (Unreachable ())
                    (pure PIdSpace)))))))

def AltPARTIDspace (el : (BitVec 2)) (security : SecurityState) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  match security with
  | .SS_NonSecure =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11334.26-11334.27"
      (pure primaryPIdSpace))
  | .SS_Secure =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11338.26-11338.27"
      (if ((BEq.beq primaryPIdSpace PIdSpace_NonSecure) : Bool)
      then (do (pure primaryPIdSpace))
      else (do (AltPIdSecure el primaryPIdSpace))))
  | .SS_Root =>
    (do
      sail_assert (el == EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11345.26-11345.27"
      (if (((_get_MPAM3_EL3_Type_ALTSP_EL3 (← (MPAM3_EL3_read ()))) == 1#1) : Bool)
      then
        (do (if (((_get_MPAM3_EL3_Type_RT_ALTSP_NS (← (MPAM3_EL3_read ()))) == 1#1) : Bool)
            then (do (pure PIdSpace_NonSecure))
            else (do (pure PIdSpace_Secure))))
      else (do (pure primaryPIdSpace))))
  | .SS_Realm =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11357.26-11357.27"
      (AltPIdRealm el primaryPIdSpace))

def DefaultMPAMinfo (partidspace : PARTIDspaceType) : SailM MPAMinfo := do
  let DefaultInfo ← (( do (undefined_MPAMinfo ()) ) : SailM MPAMinfo )
  let DefaultInfo : MPAMinfo := { DefaultInfo with mpam_sp := partidspace }
  let DefaultInfo : MPAMinfo := { DefaultInfo with partid := DefaultPARTID }
  (pure { DefaultInfo with pmg := DefaultPMG })

def HaveMPAMv0p1Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAMv0p1)

def HaveMPAMv1p1Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAMv1p1)

def undefined_MPAMIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_MPAMIDR_EL1_Type_HAS_ALTSP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_MPAMIDR_EL1_Type_HAS_FORCE_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_MPAMIDR_EL1_Type_HAS_HCR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_MPAMIDR_EL1_Type_HAS_SDEFLT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_MPAMIDR_EL1_Type_PARTID_MAX (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAMIDR_EL1_Type_PMG_MAX (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAMIDR_EL1_Type_VPMR_MAX (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 20 18)

def PARTIDspaceFromSS (security : SecurityState) : PARTIDspaceType :=
  match security with
  | .SS_NonSecure => PIdSpace_NonSecure
  | .SS_Root => PIdSpace_Root
  | .SS_Realm => PIdSpace_Realm
  | .SS_Secure => PIdSpace_Secure

def undefined_MPAMHCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMHCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAMHCR_EL2_Type_EL0_VPMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_MPAMHCR_EL2_Type_EL1_VPMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_MPAMHCR_EL2_Type_GSTAPP_PLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def undefined_MPAMVPM0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPMV_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPMV_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM1_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM1_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM3_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM3_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM4_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM4_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM5_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM5_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM6_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM6_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM7_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM7_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: vpartid : Int -/
def mapvpmw (vpartid : Int) : SailM (BitVec 16) := do
  let vpmw ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let wd := (fdiv_int vpartid 4)
  let vpmw ← (( do
    match wd with
    | 0 => (do readReg MPAMVPM0_EL2)
    | 1 => (do readReg MPAMVPM1_EL2)
    | 2 => (do readReg MPAMVPM2_EL2)
    | 3 => (do readReg MPAMVPM3_EL2)
    | 4 => (do readReg MPAMVPM4_EL2)
    | 5 => (do readReg MPAMVPM5_EL2)
    | 6 => (do readReg MPAMVPM6_EL2)
    | 7 => (do readReg MPAMVPM7_EL2)
    | _ => (pure (Zeros (n := 64))) ) : SailM (BitVec 64) )
  let vpmw := vpmw
  let vpme_lsb := ((fmod_int vpartid 4) *i 16)
  (pure (BitVec.slice vpmw vpme_lsb 16))

def MAP_vPARTID (vpartid : (BitVec 16)) : SailM ((BitVec 16) × Bool) := do
  let ret ← (( do (undefined_bitvector 16) ) : SailM PARTIDtype )
  let err ← (( do (undefined_bool ()) ) : SailM Bool )
  let virt : Int := (BitVec.toNat vpartid)
  let vpmrmax ← (( do (pure (BitVec.toNat (_get_MPAMIDR_EL1_Type_VPMR_MAX (← readReg MPAMIDR_EL1)))) ) : SailM Int )
  let vpartid_max := ((Int.shiftl vpmrmax 2) +i 3)
  let virt : Int :=
    if (((BitVec.toNat vpartid) >b vpartid_max) : Bool)
    then (fmod_int virt (vpartid_max +i 1))
    else virt
  let virt := virt
  sail_assert ((0 ≤b virt) && (virt <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:11606.48-11606.49"
  let (err, ret) ← (( do
    (if ((((BitVec.access (← readReg MPAMVPMV_EL2) virt) : BitVec 1) == 1#1) : Bool)
    then
      (do let ret ← (mapvpmw virt)
          let err : Bool := false
          (pure (err, ret)))
    else
      (do let (err, ret) ← (( do
            (if ((((BitVec.access (← readReg MPAMVPMV_EL2) 0) : BitVec 1) == 1#1) : Bool)
            then
              (do let ret ← (pure (BitVec.slice (← readReg MPAMVPM0_EL2) 0 16))
                  let err : Bool := false
                  (pure (err, ret)))
            else
              (do let ret : PARTIDtype := DefaultPARTID
                  let err : Bool := true
                  (pure (err, ret)))) ) : SailM (Bool × (BitVec 16)) )
          (pure (err, ret)))) ) : SailM (Bool × (BitVec 16)) )
  let partid_max ← (( do (pure (BitVec.toNat (_get_MPAMIDR_EL1_Type_PARTID_MAX (← readReg MPAMIDR_EL1)))) ) : SailM Int )
  let (err, ret) : (Bool × (BitVec 16)) :=
    if (((BitVec.toNat ret) >b partid_max) : Bool)
    then
      (let ret : PARTIDtype := DefaultPARTID
      let err : Bool := true
      (err, ret))
    else (err, ret)
  let err := err
  let ret := ret
  (pure (ret, err))

def MPAMisVirtual (el : (BitVec 2)) : SailM Bool := do
  (pure ((_get_MPAMIDR_EL1_Type_HAS_HCR (← readReg MPAMIDR_EL1)) == 1#1)) <&&> (do
    (EL2Enabled ())) <&&> (do
    (pure (el == EL0)) <&&> (do
      (pure ((_get_MPAMHCR_EL2_Type_EL0_VPMEN (← readReg MPAMHCR_EL2)) == 1#1))) <&&> (do
      (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1)) <||> (do
        (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)))) <||> (do
      (pure (el == EL1)) <&&> (do
        (pure ((_get_MPAMHCR_EL2_Type_EL1_VPMEN (← readReg MPAMHCR_EL2)) == 1#1)))))

def undefined_MPAM0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMSM_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMSM_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def getMPAM_PARTID (MPAMn : (BitVec 2)) (InD : Bool) (InSM : Bool) : SailM (BitVec 16) := do
  let partid ← (( do (undefined_bitvector 16) ) : SailM PARTIDtype )
  let el2avail ← (( do (EL2Enabled ()) ) : SailM Bool )
  (if (InSM : Bool)
  then (do (pure (_get_MPAMSM_EL1_Type_PARTID_D (← readReg MPAMSM_EL1))))
  else
    (do (if (InD : Bool)
        then
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PARTID_I (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PARTID_I (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 16))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PARTID_I (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PARTID_I (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PARTIDtype ())))
        else
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PARTID_D (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PARTID_D (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 16))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PARTID_D (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PARTID_D (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PARTIDtype ()))))))

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def genPARTID (el : (BitVec 2)) (InD : Bool) (InSM : Bool) : SailM ((BitVec 16) × Bool) := do
  let partidel ← (( do (getMPAM_PARTID el InD InSM) ) : SailM PARTIDtype )
  let partid_max ← (( do (pure (_get_MPAMIDR_EL1_Type_PARTID_MAX (← readReg MPAMIDR_EL1))) ) : SailM PARTIDtype )
  (if (((BitVec.toNat partidel) >b (BitVec.toNat partid_max)) : Bool)
  then (do (pure (DefaultPARTID, true)))
  else
    (do (if ((← (MPAMisVirtual el)) : Bool)
        then (do (MAP_vPARTID partidel))
        else (do (pure (partidel, false))))))


end ArmASL.Functions
