import ArmASL.Part03

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def _update_HDCR_Type_HPMN (v : (BitVec 32)) (x : (BitVec 5)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 0 x)

def _get_MDCR_EL2_Type_HPMN (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _update_HDCR_Type_MTPME (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_HDCR_Type_TDA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_EDSCR_Type_TDA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _get_EDSCR_Type_TDA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_MDCR_EL2_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_MDCR_EL3_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_MDSCR_EL1_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _update_HDCR_Type_TDCC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _get_MDCR_EL2_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_MDCR_EL3_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_MDSCR_EL1_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDCR_Type_TDE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HDCR_Type_TDE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _get_MDCR_EL2_Type_TDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HDCR_Type_TDOSA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_MDCR_EL2_Type_TDOSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_MDCR_EL3_Type_TDOSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_HDCR_Type_TDRA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_HDCR_Type_TPM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_MDCR_EL2_Type_TPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_MDCR_EL3_Type_TPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _update_HDCR_Type_TPMCR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_MDCR_EL2_Type_TPMCR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_HDCR_Type_TTRF (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_MDCR_EL2_Type_TTRF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_MDCR_EL3_Type_TTRF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_MDCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDCR_EL2_Type_E2PB (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_MDCR_EL2_Type_EBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_MDCR_EL3_Type_EBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_MDCR_EL2_Type_EnSPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_MDSCR_EL1_Type_EnSPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_MDCR_EL2_Type_TPMS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def HDCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HDCR ) : SailM HDCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDCR_EL2) 0 32)))

def HaveFeatHPMN0 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HPMN0)

/-- Type quantifiers: high : Int, low : Int -/
def ConstrainUnpredictableInteger (low : Int) (high : Int) (which : Unpredictable) : SailM (Constraint × Int) := do
  (pure ((← (undefined_Constraint ())), (← (undefined_int ()))))

def AArch32_GetNumEventCountersAccessible (_ : Unit) : SailM Int := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let total_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let n ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0))) <&&> (do
         (EL2Enabled ())))) : Bool)
    then
      (do let n ← ((
            (pure (BitVec.toNat
                (← do
                  (if ((! (← (ELUsingAArch32 EL2))) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HPMN (← (HDCR_read ()))))))))) ) : SailM Int )
          (if ((←((pure (n >b total_counters)) <||> (do
               (pure ((! (← (HaveFeatHPMN0 ()))) && (n == 0)))))) : Bool)
          then
            (do let (_, __tup_1) ← do (ConstrainUnpredictableInteger 0 total_counters Unpredictable_PMUEVENTCOUNTER)
                (pure __tup_1))
          else (do (pure n))))
    else (do (pure total_counters))) ) : SailM Int )
  let n := n
  (pure n)

def AArch64_GetNumEventCountersAccessible (_ : Unit) : SailM Int := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let total_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let n ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0))) <&&> (do
         (EL2Enabled ())))) : Bool)
    then
      (do let n ← (( (pure (BitVec.toNat (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2)))) ) : SailM Int )
          (if ((←((pure (n >b total_counters)) <||> (do
               (pure ((! (← (HaveFeatHPMN0 ()))) && (n == 0)))))) : Bool)
          then
            (do let (_, __tup_1) ← do (ConstrainUnpredictableInteger 0 total_counters Unpredictable_PMUEVENTCOUNTER)
                (pure __tup_1))
          else (do (pure n))))
    else (do (pure total_counters))) ) : SailM Int )
  let n := n
  (pure n)

def HavePMUv3ICNTR (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3_ICNTR)

def HaveAArch32 (_ : Unit) : Bool :=
  true

def UsingAArch32 (_ : Unit) : SailM Bool := do
  let aarch32 ← (( do (pure ((← readReg PSTATE).nRW == 1#1)) ) : SailM Bool )
  (if ((! (HaveAArch32 ())) : Bool)
  then (do sail_assert (! aarch32) "sail-arm/arm-v9.4-a/src/v8_base.sail:4029.32-4029.33")
  else (do (pure ())))
  (if ((! (← (HaveAArch64 ()))) : Bool)
  then (do sail_assert aarch32 "sail-arm/arm-v9.4-a/src/v8_base.sail:4032.22-4032.23")
  else (do (pure ())))
  (pure aarch32)

def PMUCounterMask (_ : Unit) : SailM (BitVec 64) := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let n ← (( do
    (if ((← (UsingAArch32 ())) : Bool)
    then (do (AArch32_GetNumEventCountersAccessible ()))
    else (do (AArch64_GetNumEventCountersAccessible ()))) ) : SailM Int )
  let n := n
  sail_assert (n ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:4047.30-4047.31"
  sail_assert (64 ≥b n) "sail-arm/arm-v9.4-a/src/v8_base.sail:4048.31-4048.32"
  let mask : (BitVec 64) := (Sail.BitVec.zeroExtend (Ones (n := n)) 64)
  let mask : (BitVec 64) := (BitVec.update mask CYCLE_COUNTER_ID (Bit 1#1))
  (if ((←((HaveAArch64 ()) <&&> (do
       (HavePMUv3ICNTR ())))) : Bool)
  then (do (pure (BitVec.update mask INSTRUCTION_COUNTER_ID (Bit 1#1))))
  else (do (pure mask)))

def HavePMUv3 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3)

def HaveRME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RME)

def HaveSecureState (_ : Unit) : SailM Bool := do
  (if ((! (HaveEL EL3)) : Bool)
  then (do (SecureOnlyImplementation ()))
  else
    (do (if ((←((HaveRME ()) <&&> (do
             (pure (! (← (HaveSecureEL2Ext ()))))))) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def EffectiveSCR_EL3_NS (_ : Unit) : SailM (BitVec 1) := do
  (if ((! (← (HaveSecureState ()))) : Bool)
  then (do (pure 1#1))
  else
    (do (if ((! (HaveEL EL3)) : Bool)
        then (do (pure 0#1))
        else (do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3)))))))

def Unreachable (_ : Unit) : SailM Unit := do
  sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:4096.16-4096.17"

def SecurityStateAtEL (EL : (BitVec 2)) : SailM SecurityState := SailME.run do
  let effective_nse_ns ← (( do (undefined_bitvector 2) ) : SailME SecurityState (BitVec 2) )
  (if ((← (HaveRME ())) : Bool)
  then
    (do (if ((EL == EL3) : Bool)
        then (do SailME.throw (SS_Root : SecurityState))
        else
          (do let effective_nse_ns ← (( do (pure ((_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)) +++ (← (EffectiveSCR_EL3_NS ())))) ) : SailME SecurityState (BitVec 2) )
              match effective_nse_ns with
              | 0b00 =>
                (do
                  (if ((← (HaveSecureEL2Ext ())) : Bool)
                  then (do SailME.throw (SS_Secure : SecurityState))
                  else (do (Unreachable ()))))
              | 0b01 => SailME.throw (SS_NonSecure : SecurityState)
              | 0b11 => SailME.throw (SS_Realm : SecurityState)
              | _ => (Unreachable ()))))
  else (do (pure ())))
  (if ((! (HaveEL EL3)) : Bool)
  then
    (do (if ((← (SecureOnlyImplementation ())) : Bool)
        then (do (pure SS_Secure))
        else (do (pure SS_NonSecure))))
  else
    (do (if ((EL == EL3) : Bool)
        then (do (pure SS_Secure))
        else
          (do sail_assert (←((pure (EL != EL2)) <||> (do
                (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:4136.39-4136.40"
              (if ((! (← (ELUsingAArch32 EL3))) : Bool)
              then
                (do (if (((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1) : Bool)
                    then (do (pure SS_NonSecure))
                    else (do (pure SS_Secure))))
              else
                (do (if (((_get_SCR_Type_NS (← readReg SCR)) == 1#1) : Bool)
                    then (do (pure SS_NonSecure))
                    else (do (pure SS_Secure)))))))))

def CurrentSecurityState (_ : Unit) : SailM SecurityState := do
  (SecurityStateAtEL (← readReg PSTATE).EL)

def ExternalInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (pure (BEq.beq (← readReg DBGEN) Signal_High))

def HaveNoninvasiveDebugAuth (_ : Unit) : SailM Bool := do
  (pure (! (← (IsFeatureImplemented FEAT_Debugv8p4))))

def ExternalNoninvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (pure (! (← (HaveNoninvasiveDebugAuth ())))) <||> (do
    (ExternalInvasiveDebugEnabled ())) <||> (do
    (pure (BEq.beq (← readReg NIDEN) Signal_High)))

def ExternalSecureInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure (! (← (SecureOnlyImplementation ()))))))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg SPIDEN) Signal_High)))))

def ExternalSecureNoninvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure (! (← (SecureOnlyImplementation ()))))))) : Bool)
  then (do (pure false))
  else
    (do (if ((← (HaveNoninvasiveDebugAuth ())) : Bool)
        then (do (ExternalNoninvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg SPIDEN) Signal_High)) <||> (do (pure (BEq.beq (← readReg SPNIDEN) Signal_High)))))
        else (do (ExternalSecureInvasiveDebugEnabled ())))))

def undefined_EDSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDSCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_EDSCR_Type_ERR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_MDSCR_EL1_Type_ERR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_EDSCR_Type_HDE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _update_EDSCR_Type_HDE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _get_MDSCR_EL1_Type_HDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_EDSCR_Type_INTdis (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _update_EDSCR_Type_INTdis (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 22 x)

def _get_MDSCR_EL1_Type_INTdis (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _update_EDSCR_Type_ITE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_EDSCR_Type_ITO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_EDSCR_Type_MA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _update_EDSCR_Type_RXO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _get_MDSCR_EL1_Type_RXO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _update_EDSCR_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_DBGDSCRext_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_DBGDSCRint_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_MDSCR_EL1_Type_RXfull (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _update_EDSCR_Type_SC2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_MDSCR_EL1_Type_SC2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_EDSCR_Type_SDD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _update_EDSCR_Type_SDD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _get_MDCR_EL3_Type_SDD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_EDSCR_Type_STATUS (v : (BitVec 32)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _update_EDSCR_Type_STATUS (v : (BitVec 32)) (x : (BitVec 6)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 0 x)

def _update_EDSCR_Type_TFO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_MDSCR_EL1_Type_TFO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_EDSCR_Type_TXU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _get_MDSCR_EL1_Type_TXU (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _update_EDSCR_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_DBGDSCRext_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_DBGDSCRint_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_MDSCR_EL1_Type_TXfull (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def undefined_MDCCSR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def EDSCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDSCR ) : SailM EDSCR_Type )
  (pure (Sail.BitVec.updateSubrange r 30 29 (BitVec.slice (← readReg MDCCSR_EL0) 29 2)))

def Halted (_ : Unit) : SailM Bool := do
  (pure (! (←((pure ((_get_EDSCR_Type_STATUS (← (EDSCR_read ()))) == 0b000001#6)) <||> (do (pure ((_get_EDSCR_Type_STATUS (← (EDSCR_read ()))) == 0b000010#6)))))))

def HaveHPMDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p1)

def HaveNoSecurePMUDisableOverride (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def HavePMUv3p5 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p5)

def HavePMUv3p7 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p7)

def undefined_PMCNTENCLR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCNTENCLR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMCNTENSET_EL0_Type_F0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def undefined_PMCNTENCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCNTENCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCNTENCLR ) : SailM PMCNTENCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCNTENCLR_EL0) 0 32)))

def undefined_PMCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMCR_EL0_Type_D (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_PMCR_Type_D (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_PMCR_EL0_Type_DP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_ID_ISAR6_Type_DP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_PMCR_Type_DP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_PMCR_Type_DP (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_PMCR_EL0_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_PMCR_Type_E (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_DBGBCR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_DBGWCR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMBLIMITR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMCR_Type_E (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMCR_EL0_Type_FZO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_PMCR_Type_FZO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_PMCR_EL0_Type_IDCODE (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 23 16)

def _update_PMCR_Type_IDCODE (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 16 x)

def _get_PMCR_EL0_Type_IMP (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def _update_PMCR_Type_IMP (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 24 x)

def _get_PMCR_Type_IMP (v : (BitVec 32)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def _update_PMCR_Type_LP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_PMCR_EL0_Type_P (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_PMCCFILTR_Type_P (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_PMCR_Type_P (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_PMCR_Type_X (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def undefined_PMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_PMCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def PMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCR ) : SailM PMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCR_EL0) 0 32)))

def undefined_PMINTENCLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMINTENCLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMINTENCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMINTENCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMINTENCLR ) : SailM PMINTENCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMINTENCLR_EL1) 0 32)))

def undefined_PMOVSCLR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMOVSCLR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMOVSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMOVSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMOVSR ) : SailM PMOVSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMOVSCLR_EL0) 0 32)))

def ConstrainUnpredictableBool (which : Unpredictable) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: n : Int -/
def PMUCounterIsHyp (n : Int) : SailM Bool := do
  (if ((n == INSTRUCTION_COUNTER_ID) : Bool)
  then (do (pure false))
  else
    (do (if ((n == CYCLE_COUNTER_ID) : Bool)
        then (do (pure false))
        else
          (do let resvd_for_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
              (if ((HaveEL EL2) : Bool)
              then
                (do let hpmn_bits ← (( do
                      (if ((← (HaveAArch64 ())) : Bool)
                      then (do (pure (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2))))
                      else (do (pure (_get_HDCR_Type_HPMN (← (HDCR_read ())))))) ) : SailM (BitVec 5) )
                    let resvd_for_el2 : Bool := (n ≥b (BitVec.toNat hpmn_bits))
                    (if ((←((pure ((BitVec.toNat hpmn_bits) >b (← (GetNumEventCounters ())))) <||> (do
                         (pure ((! (← (HaveFeatHPMN0 ()))) && (IsZero hpmn_bits)))))) : Bool)
                    then (do (ConstrainUnpredictableBool Unpredictable_CounterReservedForEL2))
                    else (do (pure resvd_for_el2))))
              else (do (pure false)))))))

/-- Type quantifiers: k_check_cnten : Bool, k_check_e : Bool, k_check_inten : Bool, k_exclude_cyc : Bool, k_exclude_sync : Bool, k_include_hi_name : Bool, k_include_lo_name : Bool -/
def PMUOverflowCondition (check_e : Bool) (check_cnten : Bool) (check_inten : Bool) (include_hi_name : Bool) (include_lo_name : Bool) (exclude_cyc : Bool) (exclude_sync : Bool) : SailM Bool := do
  let counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let ovsf ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((← (HaveAArch64 ())) : Bool)
    then
      (do let ovsf ← readReg PMOVSCLR_EL0
          let ovsf : (BitVec 64) := (Sail.BitVec.updateSubrange ovsf 63 33 (Zeros (n := 31)))
          (if ((! (← (HavePMUv3ICNTR ()))) : Bool)
          then (do (pure (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit 0#1))))
          else (do (pure ovsf))))
    else (do (pure (Sail.BitVec.zeroExtend (← (PMOVSR_read ())) 64)))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((counters <b 31) : Bool)
    then
      (do sail_assert ((0 ≤b counters) && (counters ≤b 30)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4603.61-4603.62"
          (pure (Sail.BitVec.updateSubrange ovsf 30 counters (Zeros (n := (31 -i counters))))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    let loop_idx_lower := 0
    let loop_idx_upper := (counters -i 1)
    let mut loop_vars := ovsf
    for idx in [loop_idx_lower:loop_idx_upper:1]i do
      let ovsf := loop_vars
      loop_vars ← do
        let E ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let is_hyp ← (( do (PMUCounterIsHyp idx) ) : SailM Bool )
        let E ← (( do
          (if ((← (HaveAArch64 ())) : Bool)
          then
            (do (if (is_hyp : Bool)
                then (do (pure (_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2))))
                else (do (pure (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0))))))
          else
            (do (if (is_hyp : Bool)
                then (do (pure (_get_HDCR_Type_HPME (← (HDCR_read ())))))
                else (do (pure (_get_PMCR_Type_E (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
        let ovsf ← (( do
          (if (check_e : Bool)
          then
            (do sail_assert ((0 ≤b idx) && (idx <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4615.64-4615.65"
                (pure (BitVec.update ovsf idx (Bit (((BitVec.access ovsf idx) : BitVec 1) &&& E)))))
          else (do (pure ovsf))) ) : SailM (BitVec 64) )
        (if ((((! is_hyp) && (! include_lo_name)) || (is_hyp && (! include_hi_name))) : Bool)
        then
          (do sail_assert ((0 ≤b idx) && (idx <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4619.64-4619.65"
              (pure (BitVec.update ovsf idx (Bit 0#1))))
        else (do (pure ovsf)))
    (pure loop_vars) ) : SailM (BitVec 64) )
  let ovsf : (BitVec 64) :=
    if ((exclude_cyc || (! include_lo_name)) : Bool)
    then (BitVec.update ovsf CYCLE_COUNTER_ID (Bit 0#1))
    else ovsf
  let ovsf ← (( do
    (if (check_e : Bool)
    then (do (pure (BitVec.update ovsf CYCLE_COUNTER_ID (Bit (((BitVec.access ovsf CYCLE_COUNTER_ID) : BitVec 1) &&& (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)))))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((←((HaveAArch64 ()) <&&> (do
         (HavePMUv3ICNTR ())))) : Bool)
    then
      (do let ovsf : (BitVec 64) :=
            if ((! include_lo_name) : Bool)
            then (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit 0#1))
            else ovsf
          (if (check_e : Bool)
          then (do (pure (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit (((BitVec.access ovsf INSTRUCTION_COUNTER_ID) : BitVec 1) &&& (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)))))))
          else (do (pure ovsf))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if (check_cnten : Bool)
    then
      (do let cnten ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do readReg PMCNTENCLR_EL0)
            else (do (pure (Sail.BitVec.zeroExtend (← (PMCNTENCLR_read ())) 64)))) ) : SailM (BitVec 64) )
          (pure (ovsf &&& cnten)))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if (check_inten : Bool)
    then
      (do let inten ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do readReg PMINTENCLR_EL1)
            else (do (pure (Sail.BitVec.zeroExtend (← (PMINTENCLR_read ())) 64)))) ) : SailM (BitVec 64) )
          (pure (ovsf &&& inten)))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  (pure (! (IsZero ovsf)))

/-- Type quantifiers: k_resvd_for_el2 : Bool -/
def HiLoPMUOverflow (resvd_for_el2 : Bool) : SailM Bool := do
  let check_cnten : Bool := false
  let check_e : Bool := false
  let check_inten : Bool := false
  let include_lo_name : Bool := (! resvd_for_el2)
  let include_hi_name : Bool := resvd_for_el2
  let exclude_cyc : Bool := false
  let exclude_sync : Bool := false
  (PMUOverflowCondition check_e check_cnten check_inten include_hi_name include_lo_name exclude_cyc exclude_sync)

def undefined_MDCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDCR_EL3_Type_E3BREC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_MDCR_EL3_Type_E3BREW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_MDCR_EL3_Type_EnPM2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_MDCR_EL3_Type_EnPMS3 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_MDCR_EL3_Type_EnPMSN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_MDCR_EL3_Type_EnPMSS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_MDCR_EL3_Type_MCCD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_MDCR_EL3_Type_MPMX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_MDCR_EL3_Type_NSPB (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_MDCR_EL3_Type_NSPBE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_MDCR_EL3_Type_SBRBE (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 33 32)

def _get_MDCR_EL3_Type_SCCD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_SDCR_Type_SCCD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_MDCR_EL3_Type_SPME (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_SDCR_Type_SPME (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def undefined_PMCCFILTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCCFILTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_PMCCFILTR_Type_NSH (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _update_PMCCFILTR_Type_NSK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_PMCCFILTR_Type_NSU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_GPCCR_EL3_Type_SH (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _update_ICH_MISR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_MPIDR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_PMCCFILTR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_VMPIDR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def undefined_PMCCFILTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_PMCCFILTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def PMCCFILTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCCFILTR ) : SailM PMCCFILTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCCFILTR_EL0) 0 32)))

def undefined_PMCNTENSET_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCNTENSET_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMCNTENSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCNTENSET_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCNTENSET ) : SailM PMCNTENSET_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCNTENSET_EL0) 0 32)))

def undefined_PMEVTYPER_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMEVTYPER_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_MPIDR_Type_MT (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_VMPIDR_Type_MT (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_ICH_HCR_Type_TC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_ICH_HCR_EL2_Type_TC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_SCTLR_Type_TE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_HSCTLR_Type_TE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_Type_TE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_PMEVTYPER_EL0_Type_evtCount (v : (BitVec 64)) : (BitVec 16) :=
  ((Sail.BitVec.extractLsb v 15 10) +++ (Sail.BitVec.extractLsb v 9 0))

def _get_PMEVTYPER_Type_evtCount (v : (BitVec 32)) : (BitVec 16) :=
  ((Sail.BitVec.extractLsb v 15 10) +++ (Sail.BitVec.extractLsb v 9 0))

def undefined_PMEVTYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 31 -/
def PMEVTYPER_read (n : Nat) : SailM (BitVec 32) := do
  let r ← (( do (pure (GetElem?.getElem! (← readReg _PMEVTYPER) n)) ) : SailM PMEVTYPER_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (GetElem?.getElem! (← readReg PMEVTYPER_EL0) n) 0 32)))

def undefined_PMICFILTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMICFILTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SDCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_SDER32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SDER32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_SDER_Type_SUIDEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_SDER32_EL3_Type_SUIDEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_SDER_Type_SUNIDEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_SDER32_EL3_Type_SUNIDEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SDER_Type_SUNIDEN (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_SDER32_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SDER32_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def SDER32_EL3_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _SDER32_EL3 ) : SailM SDER32_EL3_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg SDER32_EL2) 0 64)))

def undefined_SDER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SDER_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SDER_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SDER ) : SailM SDER_Type )
  (if ((HaveEL EL3) : Bool)
  then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← (SDER32_EL3_read ())) 0 32))))
  else (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SDER32_EL2) 0 32)))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 32 -/
def CountPMUEvents (idx : Nat) : SailM Bool := do
  let dp ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let hccd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let hpmd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sccd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let num_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  sail_assert (←((pure ((idx == CYCLE_COUNTER_ID) || (idx <b num_counters))) <||> (do
    (pure (idx == INSTRUCTION_COUNTER_ID)) <&&> (do
      (HavePMUv3ICNTR ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:4945.108-4945.109"
  let enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let filtered ← (( do (undefined_bool ()) ) : SailM Bool )
  let E ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let debug ← (( do (Halted ()) ) : SailM Bool )
  let resvd_for_el2 ← (( do (PMUCounterIsHyp idx) ) : SailM Bool )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let enabled ← (( do
    let questionMark := idx
    (if ((questionMark == INSTRUCTION_COUNTER_ID) : Bool)
    then
      (do sail_assert (← (HaveAArch64 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:4954.30-4954.31"
          (pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 1#1)) <&&> (do
            (pure ((_get_PMCNTENSET_EL0_Type_F0 (← readReg PMCNTENSET_EL0)) == 1#1))))
    else
      (do (if ((questionMark == CYCLE_COUNTER_ID) : Bool)
          then
            (do (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 1#1)) <&&> (do (pure ((_get_PMCNTENSET_EL0_Type_C (← readReg PMCNTENSET_EL0)) == 1#1))))
                else (do (pure ((_get_PMCR_Type_E (← (PMCR_read ()))) == 1#1)) <&&> (do (pure ((_get_PMCNTENSET_Type_C (← (PMCNTENSET_read ()))) == 1#1))))))
          else
            (do let E ← (( do
                  (if (resvd_for_el2 : Bool)
                  then
                    (do (if ((← (HaveAArch64 ())) : Bool)
                        then (do (pure (_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2))))
                        else (do (pure (_get_HDCR_Type_HPME (← (HDCR_read ())))))))
                  else
                    (do (if ((← (HaveAArch64 ())) : Bool)
                        then (do (pure (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0))))
                        else (do (pure (_get_PMCR_Type_E (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
                (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure (E == 1#1)) <&&> (do (pure (((BitVec.access (← readReg PMCNTENSET_EL0) idx) : BitVec 1) == 1#1))))
                else
                  (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4973.56-4973.57"
                      (pure (E == 1#1)) <&&> (do
                        (pure (((BitVec.access (← (PMCNTENSET_read ())) idx) : BitVec 1) == 1#1))))))))) ) : SailM Bool )
  let prohibited : Bool := false
  let prohibited ← (( do
    (if (((HaveEL EL3) && (BEq.beq ss SS_Secure)) : Bool)
    then
      (do let prohibited ← (( do
            (if ((! (← (ELUsingAArch32 EL3))) : Bool)
            then (do (pure ((_get_MDCR_EL3_Type_SPME (← readReg MDCR_EL3)) == 0#1)) <&&> (do (HavePMUv3p7 ())) <&&> (do (pure ((_get_MDCR_EL3_Type_MPMX (← readReg MDCR_EL3)) == 0#1))))
            else (do (pure ((_get_SDCR_Type_SPME (← readReg SDCR)) == 0#1)))) ) : SailM Bool )
          (if ((←((pure prohibited) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then
            (do (if ((← (ELUsingAArch32 EL3)) : Bool)
                then (do (pure ((_get_SDER_Type_SUNIDEN (← (SDER_read ()))) == 0#1)))
                else
                  (do (if ((← (ELUsingAArch32 EL1)) : Bool)
                      then (do (pure ((_get_SDER32_EL3_Type_SUNIDEN (← (SDER32_EL3_read ()))) == 0#1)))
                      else (do (pure prohibited))))))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if ((←((pure (! prohibited)) <&&> (do
         (HavePMUv3p7 ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL3))) <&&> (do
         (HaveAArch64 ())))) : Bool)
    then (do (pure ((_get_MDCR_EL3_Type_MPMX (← readReg MDCR_EL3)) == 1#1)) <&&> (do (pure (((_get_MDCR_EL3_Type_SPME (← readReg MDCR_EL3)) == 0#1) || (! resvd_for_el2)))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if (((←((pure (! prohibited)) <&&> (do
           (pure ((← readReg PSTATE).EL == EL2))) <&&> (do
           (HaveHPMDExt ())))) && (! resvd_for_el2)) : Bool)
    then
      (do let hpmd ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do (pure (_get_MDCR_EL2_Type_HPMD (← readReg MDCR_EL2))))
            else (do (pure (_get_HDCR_Type_HPMD (← (HDCR_read ())))))) ) : SailM (BitVec 1) )
          (pure (hpmd == 1#1)))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if ((←((pure prohibited) <&&> (do
         (pure (! (← (HaveNoSecurePMUDisableOverride ()))))))) : Bool)
    then (do (pure (! (← (ExternalSecureNoninvasiveDebugEnabled ())))))
    else (do (pure prohibited))) ) : SailM Bool )
  let frozen : Bool := false
  let frozen ← (( do
    (if ((← (HavePMUv3p7 ())) : Bool)
    then
      (do let FZ ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let FZ ← (( do
            (if (resvd_for_el2 : Bool)
            then
              (do (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HPMFZO (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HPMFZO (← (HDCR_read ())))))))
            else
              (do (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_PMCR_EL0_Type_FZO (← readReg PMCR_EL0))))
                  else (do (pure (_get_PMCR_Type_FZO (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
          (pure (FZ == 1#1)) <&&> (do
            (HiLoPMUOverflow resvd_for_el2)))
    else (do (pure frozen))) ) : SailM Bool )
  let (enabled, frozen, prohibited) ← (( do
    (if (((prohibited || frozen) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do let dp ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do (pure (_get_PMCR_EL0_Type_DP (← readReg PMCR_EL0))))
            else (do (pure (_get_PMCR_Type_DP (← (PMCR_read ())))))) ) : SailM (BitVec 1) )
          let enabled : Bool := (enabled && (dp == 0#1))
          let prohibited : Bool := false
          let frozen : Bool := false
          (pure (enabled, frozen, prohibited)))
    else (do (pure (enabled, frozen, prohibited)))) ) : SailM (Bool × Bool × Bool) )
  let prohibited ← (( do
    (if (((← (HavePMUv3p5 ())) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do let prohibited ← (( do
            (if (((HaveEL EL3) && (BEq.beq ss SS_Secure)) : Bool)
            then
              (do let sccd ← (( do
                    (if ((← (HaveAArch64 ())) : Bool)
                    then (do (pure (_get_MDCR_EL3_Type_SCCD (← readReg MDCR_EL3))))
                    else (do (pure (_get_SDCR_Type_SCCD (← readReg SDCR))))) ) : SailM (BitVec 1) )
                  (if ((sccd == 1#1) : Bool)
                  then (do (pure true))
                  else (do (pure prohibited))))
            else (do (pure prohibited))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL2) : Bool)
          then
            (do let hccd ← (( do
                  (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HCCD (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HCCD (← (HDCR_read ())))))) ) : SailM (BitVec 1) )
                (if ((hccd == 1#1) : Bool)
                then (do (pure true))
                else (do (pure prohibited))))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if (((← (HavePMUv3p7 ())) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do (if ((←((pure ((← readReg PSTATE).EL == EL3)) <&&> (do
               (HaveAArch64 ())) <&&> (do
               (pure ((_get_MDCR_EL3_Type_MCCD (← readReg MDCR_EL3)) == 1#1))))) : Bool)
          then (do (pure true))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let filter ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let filter ← (( do
    let questionMark := idx
    (if ((questionMark == INSTRUCTION_COUNTER_ID) : Bool)
    then (do (pure (Sail.BitVec.extractLsb (← readReg PMICFILTR_EL0) 31 0)))
    else
      (do (if ((questionMark == CYCLE_COUNTER_ID) : Bool)
          then
            (do (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure (Sail.BitVec.extractLsb (← readReg PMCCFILTR_EL0) 31 0)))
                else (do (PMCCFILTR_read ()))))
          else
            (do (if ((← (HaveAArch64 ())) : Bool)
                then
                  (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5058.56-5058.57"
                      (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg PMEVTYPER_EL0) idx) 31 0)))
                else
                  (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5061.56-5061.57"
                      (PMEVTYPER_read idx))))))) ) : SailM (BitVec 32) )
  let filter := filter
  let P : (BitVec 1) := ((BitVec.access filter 31) : BitVec 1)
  let U : (BitVec 1) := ((BitVec.access filter 30) : BitVec 1)
  let NSK : (BitVec 1) :=
    if ((HaveEL EL3) : Bool)
    then ((BitVec.access filter 29) : BitVec 1)
    else 0#1
  let NSU : (BitVec 1) :=
    if ((HaveEL EL3) : Bool)
    then ((BitVec.access filter 28) : BitVec 1)
    else 0#1
  let NSH : (BitVec 1) :=
    if ((HaveEL EL2) : Bool)
    then ((BitVec.access filter 27) : BitVec 1)
    else 0#1
  let M ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (HaveAArch64 ())))) : Bool)
    then (do (pure ((BitVec.access filter 26) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let SH ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (HaveSecureEL2Ext ())))) : Bool)
    then (do (pure ((BitVec.access filter 24) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLK ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 22) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLU ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 21) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLH ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 20) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let filtered ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    (if ((questionMark == EL0) : Bool)
    then
      (do match ss with
          | .SS_NonSecure => (pure (U != NSU))
          | .SS_Secure => (pure (U == 1#1))
          | .SS_Realm => (pure (U != RLU))
          | _ => (pure filtered))
    else
      (do (if ((questionMark == EL1) : Bool)
          then
            (do match ss with
                | .SS_NonSecure => (pure (P != NSK))
                | .SS_Secure => (pure (P == 1#1))
                | .SS_Realm => (pure (P != RLK))
                | _ => (pure filtered))
          else
            (do (if ((questionMark == EL2) : Bool)
                then
                  (do match ss with
                      | .SS_NonSecure => (pure (NSH == 0#1))
                      | .SS_Secure => (pure (NSH == SH))
                      | .SS_Realm => (pure (NSH == RLH))
                      | _ => (pure filtered))
                else
                  (do (if ((questionMark == EL3) : Bool)
                      then
                        (do (if ((← (HaveAArch64 ())) : Bool)
                            then (do (pure (M != P)))
                            else (do (pure (P == 1#1)))))
                      else (do (pure filtered))))))))) ) : SailM Bool )
  (pure (((((! debug) && enabled) && (! prohibited)) && (! filtered)) && (! frozen)))

def undefined_PMICNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMICNTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMOVSSET_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMOVSSET_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: increment_name : Int -/
def IncrementInstructionCounter (increment_name : Int) : SailM Unit := do
  (if ((← (CountPMUEvents INSTRUCTION_COUNTER_ID)) : Bool)
  then
    (do let old_value ← (( do (pure (BitVec.toNat (← readReg PMICNTR_EL0))) ) : SailM Int )
        let new_value := (old_value +i increment_name)
        writeReg PMICNTR_EL0 (Mk_PMICNTR_EL0_Type (integer_subrange new_value 63 0))
        (if ((((integer_access old_value 64) : BitVec 1) != ((integer_access new_value 64) : BitVec 1)) : Bool)
        then
          (do writeReg PMOVSSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSSET_EL0) 32 32 1#1)
              writeReg PMOVSCLR_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSCLR_EL0) 32 32 1#1))
        else (do (pure ()))))
  else (do (pure ())))

def HaveStatisticalProfilingv1p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPEv1p1)

def HaveStatisticalProfilingv1p4 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPEv1p4)

def SPEEvent (pmuevent : (BitVec 16)) : SailM Unit := SailME.run do
  let questionMark := pmuevent
  (if ((questionMark == PMU_EVENT_DSNP_HIT_RD) : Bool)
  then
    (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 23 (Bit 1#1)))
        else (do (pure ()))))
  else
    (do (if ((questionMark == PMU_EVENT_L1D_LFB_HIT_RD) : Bool)
        then
          (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
              else (do (pure ()))))
        else
          (do (if ((questionMark == PMU_EVENT_L2D_LFB_HIT_RD) : Bool)
              then
                (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                    else (do (pure ()))))
              else
                (do (if ((questionMark == PMU_EVENT_L3D_LFB_HIT_RD) : Bool)
                    then
                      (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                          else (do (pure ()))))
                    else
                      (do (if ((questionMark == PMU_EVENT_LL_LFB_HIT_RD) : Bool)
                          then
                            (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                                else (do (pure ()))))
                          else
                            (do (if ((questionMark == PMU_EVENT_L1D_CACHE_HITM_RD) : Bool)
                                then
                                  (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                      else (do (pure ()))))
                                else
                                  (do (if ((questionMark == PMU_EVENT_L2D_CACHE_HITM_RD) : Bool)
                                      then
                                        (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                            else (do (pure ()))))
                                      else
                                        (do (if ((questionMark == PMU_EVENT_L3D_CACHE_HITM_RD) : Bool)
                                            then
                                              (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                                  else (do (pure ()))))
                                            else
                                              (do (if ((questionMark == PMU_EVENT_LL_CACHE_HITM_RD) : Bool)
                                                  then
                                                    (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                                        else (do (pure ()))))
                                                  else
                                                    (do (if ((questionMark == PMU_EVENT_L2D_CACHE_LMISS_RD) : Bool)
                                                        then
                                                          (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 20 (Bit 1#1)))
                                                              else (do (pure ()))))
                                                        else
                                                          (do (if ((questionMark == PMU_EVENT_L2D_CACHE_RD) : Bool)
                                                              then
                                                                (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 19 (Bit 1#1)))
                                                                    else (do (pure ()))))
                                                              else
                                                                (do (if ((questionMark == PMU_EVENT_SVE_PRED_EMPTY_SPEC) : Bool)
                                                                    then
                                                                      (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 18 (Bit 1#1)))
                                                                          else (do (pure ()))))
                                                                    else
                                                                      (do (if ((questionMark == PMU_EVENT_SVE_PRED_PARTIAL_SPEC) : Bool)
                                                                          then
                                                                            (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                                then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 17 (Bit 1#1)))
                                                                                else (do (pure ()))))
                                                                          else
                                                                            (do (if ((questionMark == PMU_EVENT_LDST_ALIGN_LAT) : Bool)
                                                                                then
                                                                                  (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 11 (Bit 1#1)))
                                                                                      else (do (pure ()))))
                                                                                else
                                                                                  (do (if ((questionMark == PMU_EVENT_REMOTE_ACCESS) : Bool)
                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 10 (Bit 1#1)))
                                                                                      else
                                                                                        (do (if ((questionMark == PMU_EVENT_LL_CACHE_MISS) : Bool)
                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 9 (Bit 1#1)))
                                                                                            else
                                                                                              (do (if ((questionMark == PMU_EVENT_LL_CACHE) : Bool)
                                                                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 8 (Bit 1#1)))
                                                                                                  else
                                                                                                    (do (if ((questionMark == PMU_EVENT_BR_MIS_PRED) : Bool)
                                                                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 7 (Bit 1#1)))
                                                                                                        else
                                                                                                          (do (if ((questionMark == PMU_EVENT_BR_MIS_PRED_RETIRED) : Bool)
                                                                                                              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 7 (Bit 1#1)))
                                                                                                              else
                                                                                                                (do (if ((questionMark == PMU_EVENT_DTLB_WALK) : Bool)
                                                                                                                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 5 (Bit 1#1)))
                                                                                                                    else
                                                                                                                      (do (if ((questionMark == PMU_EVENT_L1D_TLB) : Bool)
                                                                                                                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 4 (Bit 1#1)))
                                                                                                                          else
                                                                                                                            (do (if ((questionMark == PMU_EVENT_L1D_CACHE_REFILL) : Bool)
                                                                                                                                then
                                                                                                                                  (do (if ((! (← (HaveStatisticalProfilingv1p4 ()))) : Bool)
                                                                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 3 (Bit 1#1)))
                                                                                                                                      else (do (pure ()))))
                                                                                                                                else
                                                                                                                                  (do (if ((questionMark == PMU_EVENT_L1D_CACHE_LMISS_RD) : Bool)
                                                                                                                                      then
                                                                                                                                        (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 3 (Bit 1#1)))
                                                                                                                                            else (do (pure ()))))
                                                                                                                                      else
                                                                                                                                        (do (if ((questionMark == PMU_EVENT_L1D_CACHE) : Bool)
                                                                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 2 (Bit 1#1)))
                                                                                                                                            else
                                                                                                                                              (do (if ((questionMark == PMU_EVENT_INST_RETIRED) : Bool)
                                                                                                                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 1 (Bit 1#1)))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((questionMark == PMU_EVENT_EXC_TAKEN) : Bool)
                                                                                                                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 0 (Bit 1#1)))
                                                                                                                                                        else (do SailME.throw (() : Unit)))))))))))))))))))))))))))))))))))))))))))))))))))))


end ArmASL.Functions
