import ArmASL.Part17

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def DIT_SysRegWrite_cb82290c1722296d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with DIT := (← do (pure ((BitVec.access (← (X_read t 64)) 24) : BitVec 1))) })
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with DIT := (← do (pure ((BitVec.access (← (X_read t 64)) 24) : BitVec 1))) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with DIT := (← do (pure ((BitVec.access (← (X_read t 64)) 24) : BitVec 1))) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with DIT := (← do (pure ((BitVec.access (← (X_read t 64)) 24) : BitVec 1))) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def FPCR_SysRegWrite_b4b7f4f4f63e39e4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TFP ← (( do (pure (_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPACR_EL1_FPEN ← (( do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1))) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_FPEN ← (( do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TFP ← (( do (pure (_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (((! (←((EL2Enabled ()) <&&> (do
                       (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CPACR_EL1_FPEN != 0b11#2)) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x00#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CPTR_EL2_FPEN != 0b11#2)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__3 := __CPTR_EL2_FPEN
                               if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                               then true
                               else false : Bool)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (__set_FPCR (Mk_FPCR_Type (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((let b__2 := __CPACR_EL1_FPEN
                       if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                       then true
                       else false : Bool) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__1 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (__set_FPCR (Mk_FPCR_Type (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do (__set_FPCR (Mk_FPCR_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_TFP == 1#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))
                          else (do (__set_FPCR (Mk_FPCR_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def FPSR_SysRegWrite_d0a803d1b7d0c76d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TFP ← (( do (pure (_get_CPTR_EL3_Type_TFP (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPACR_EL1_FPEN ← (( do (pure (_get_CPACR_EL1_Type_FPEN (← readReg CPACR_EL1))) ) : SailM (BitVec 2) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_FPEN ← (( do (pure (_get_CPTR_EL2_Type_FPEN (← readReg CPTR_EL2))) ) : SailM (BitVec 2) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TFP ← (( do (pure (_get_CPTR_EL2_Type_TFP (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (((! (←((EL2Enabled ()) <&&> (do
                       (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2)))))) && (__CPACR_EL1_FPEN != 0b11#2)) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x00#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))))
              else
                (do (if (((←((EL2Enabled ()) <&&> (do
                           (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) && (__CPTR_EL2_FPEN != 0b11#2)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__3 := __CPTR_EL2_FPEN
                               if (((Sail.BitVec.extractLsb b__3 0 0) == (0#1 : (BitVec 1))) : Bool)
                               then true
                               else false : Bool)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do writeReg FPSR (Mk_FPSR_Type (← (X_read t 64))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((let b__2 := __CPACR_EL1_FPEN
                       if (((Sail.BitVec.extractLsb b__2 0 0) == (0#1 : (BitVec 1))) : Bool)
                       then true
                       else false : Bool) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x07#8)))
                    else
                      (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H != 1#1)) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if ((((← (EL2Enabled ())) && (__HCR_EL2_E2H == 1#1)) && (let b__1 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__1 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do writeReg FPSR (Mk_FPSR_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((__HCR_EL2_E2H == 0#1) && (__CPTR_EL2_TFP == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                          else
                            (do (if (((__HCR_EL2_E2H == 1#1) && (let b__0 := __CPTR_EL2_FPEN
                                     if (((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1))) : Bool)
                                     then true
                                     else false : Bool)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x07#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TFP == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))))
                                      else (do writeReg FPSR (Mk_FPSR_Type (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__CPTR_EL3_TFP == 1#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x07#8)))
                          else (do writeReg FPSR (Mk_FPSR_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def NZCV_SysRegWrite_a24ec14709a57410 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
        writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
        writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
              writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
              writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
                    writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
                    writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
                    writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
                    writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 31 28))
                          writeReg PSTATE { (← readReg PSTATE) with N := (Sail.BitVec.extractLsb split_vec 3 3) }
                          writeReg PSTATE { (← readReg PSTATE) with Z := (Sail.BitVec.extractLsb split_vec 2 2) }
                          writeReg PSTATE { (← readReg PSTATE) with C := (Sail.BitVec.extractLsb split_vec 1 1) }
                          writeReg PSTATE { (← readReg PSTATE) with V := (Sail.BitVec.extractLsb split_vec 0 0) })
                    else (do (pure ())))))))))


end ArmASL.Functions
