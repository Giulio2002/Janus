import ArmASL.Part17

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def DecodeShift (op : (BitVec 2)) : SailM ShiftType := do
  match op with
  | 0b00 => (pure ShiftType_LSL)
  | 0b01 => (pure ShiftType_LSR)
  | 0b10 => (pure ShiftType_ASR)
  | 0b11 => (pure ShiftType_ROR)
  | _ => (do (undefined_ShiftType ()))

/-- Type quantifiers: N : Nat, amount : Int, reg : Int, List.elem N [8, 16, 32, 64] -/
def ShiftReg (reg : Int) (shiftype : ShiftType) (amount : Int) (N : Nat) : SailM (BitVec N) := do
  let result ← (( do (X_read reg N) ) : SailM (BitVec N) )
  match shiftype with
  | .ShiftType_LSL => (pure (result <<< amount))
  | .ShiftType_LSR => (pure (result >>> amount))
  | .ShiftType_ASR => (pure (BitVec.sshiftRight result amount))
  | .ShiftType_ROR =>
    (do
      sail_assert ((N >b 0) && (amount ≥b 0)) "sail-arm/arm-v9.4-a/src/v8_base.sail:35864.52-35864.53"
      (pure (ROR result amount)))

/-- Type quantifiers: k_stream : Bool, target : Int -/
def Hint_Prefetch (address : (BitVec 64)) (hint : PrefetchHint) (target : Int) (stream : Bool) : Unit :=
  ()

def Prefetch (address : (BitVec 64)) (prfop : (BitVec 5)) : SailM Unit := SailME.run do
  let hint ← (( do (undefined_PrefetchHint ()) ) : SailME Unit PrefetchHint )
  let hint ← (( do
    match (Sail.BitVec.extractLsb prfop 4 3) with
    | 0b00 => (pure Prefetch_READ)
    | 0b01 => (pure Prefetch_EXEC)
    | 0b10 => (pure Prefetch_WRITE)
    | _ => SailME.throw (() : Unit) ) : SailME Unit PrefetchHint )
  let target := (BitVec.toNat (Sail.BitVec.extractLsb prfop 2 1))
  let stream : Bool := (((BitVec.access prfop 0) : BitVec 1) != 0#1)
  let _ : Unit := (Hint_Prefetch address hint target stream)
  (pure ())

def Mk_DCZID_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DCZID_EL0_Type_BS (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def AArch64_MemZero (regval : (BitVec 64)) (cachetype : CacheType) : SailM Unit := do
  let size ← (( do (pure (4 *i (2 ^i (BitVec.toNat (_get_DCZID_EL0_Type_BS (← readReg DCZID_EL0)))))) ) : SailM Nat )
  sail_assert (size ≤b MAX_ZERO_BLOCK_SIZE) "sail-arm/arm-v9.4-a/src/v8_base.sail:36724.38-36724.39"
  (if ((← (HaveMTE2Ext ())) : Bool)
  then (do sail_assert (size ≥b TAG_GRANULE) "sail-arm/arm-v9.4-a/src/v8_base.sail:36726.34-36726.35")
  else (do (pure ())))
  let vaddress : (BitVec 64) := (Align_bits regval size)
  let tagaccess : Bool := ((BEq.beq cachetype CacheType_Tag) || (BEq.beq cachetype CacheType_Data_Tag))
  let tagchecked : Bool := (BEq.beq cachetype CacheType_Data)
  let accdesc ← (( do (CreateAccDescDCZero tagaccess tagchecked) ) : SailM AccessDescriptor )
  (if (((BEq.beq cachetype CacheType_Tag) || (BEq.beq cachetype CacheType_Data_Tag)) : Bool)
  then (do (AArch64_TagMemZero regval vaddress accdesc size))
  else (do (pure ())))
  (if (((BEq.beq cachetype CacheType_Data) || (BEq.beq cachetype CacheType_Data_Tag)) : Bool)
  then (do (AArch64_DataMemZero regval vaddress accdesc size))
  else (do (pure ())))

def undefined_MAIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_MAIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_HMAIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_HMAIR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DACR32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def __IMPDEF_bit (x : String) : SailM (BitVec 1) := do
  (__UNKNOWN_bit ())

def undefined_DBGDTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGDTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def DBGDTR_EL0_read__1 (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _DBGDTR_EL0 ) : SailM DBGDTR_EL0_Type )
  let r ← (( do
    (if ((← (__IMPDEF_boolean "read")) : Bool)
    then (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32))))
    else
      (do (if ((← (__IMPDEF_boolean "read")) : Bool)
          then (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32))))
          else (do (pure (Sail.BitVec.updateSubrange r 63 32 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))))) ) : SailM (BitVec 64) )
  (if ((← (__IMPDEF_boolean "read")) : Bool)
  then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))
  else
    (do (if ((← (__IMPDEF_boolean "read")) : Bool)
        then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRRX_EL0) 0 32))))
        else (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGDTRTX_EL0) 0 32)))))))

def Mk_MDCCINT_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def CheckOSUnlockCatch (_ : Unit) : SailM Unit := do
  (if ((←((HaveDoPD ()) <&&> (do
       (pure ((_get_CTIDEVCTL_Type_OSUCE (← readReg CTIDEVCTL)) == 1#1))) <||> (do
       (pure (! (← (HaveDoPD ())))) <&&> (do
         (pure ((_get_EDECR_Type_OSUCE (← readReg EDECR)) == 1#1)))))) : Bool)
  then
    (do (if ((! (← (Halted ()))) : Bool)
        then (do writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 0 0 1#1))
        else (do (pure ()))))
  else (do (pure ())))

def Mk_TRFCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_TRFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def TraceSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def undefined_DBGBCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGBVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGBXVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGVCR32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DBGWCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGWVR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

/-- Type quantifiers: n : Int -/
def Q_set (n : Int) (value_name : (BitVec 128)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 15)) "sail-arm/arm-v9.4-a/src/v8_base.sail:42248.27-42248.28"
  (V_set n 128 value_name)

def AArch32_ResetGeneralRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 7
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (R_set i (← (__UNKNOWN_bits 32)))
  (pure loop_vars)
  let loop_i_lower := 8
  let loop_i_upper := 12
  let mut loop_vars_1 := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars_1
    loop_vars_1 ← do
      (Rmode_set i M32_User (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_FIQ (← (__UNKNOWN_bits 32)))
  (pure loop_vars_1)
  (if ((HaveEL EL2) : Bool)
  then (do (Rmode_set 13 M32_Hyp (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  let loop_i_lower := 13
  let loop_i_upper := 14
  let mut loop_vars_2 := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars_2
    loop_vars_2 ← do
      (Rmode_set i M32_User (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_FIQ (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_IRQ (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Svc (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Abort (← (__UNKNOWN_bits 32)))
      (Rmode_set i M32_Undef (← (__UNKNOWN_bits 32)))
      (if ((HaveEL EL3) : Bool)
      then (do (Rmode_set i M32_Monitor (← (__UNKNOWN_bits 32))))
      else (do (pure ())))
  (pure loop_vars_2)

def AArch32_ResetSIMDFPRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (Q_set i (← (__UNKNOWN_bits 128)))
  (pure loop_vars)

def AArch32_ResetSpecialRegisters (_ : Unit) : SailM Unit := do
  writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 31 0 (← (__UNKNOWN_bits 32)))
  writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 31 0 (← (__UNKNOWN_bits 32)))
  (SPSR_svc_write (Mk_SPSR_svc_Type (Sail.BitVec.updateSubrange (← (SPSR_svc_read ())) 31 0 (← (__UNKNOWN_bits 32)))))
  writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 31 0 (← (__UNKNOWN_bits 32)))
  writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 31 0 (← (__UNKNOWN_bits 32)))
  (if ((HaveEL EL2) : Bool)
  then
    (do (SPSR_hyp_write (Mk_SPSR_hyp_Type (← (__UNKNOWN_bits 32))))
        (ELR_hyp_write (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then (do writeReg SPSR_mon (Mk_SPSR_mon_Type (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch32_ResetControlRegisters (cold_reset : Bool) : SailM Unit := do
  writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
  (ResetControlRegisters cold_reset)
  (pure (_TLBInvalidate ()))

/-- Type quantifiers: k_cold_reset : Bool -/
def AArch32_TakeReset (cold_reset : Bool) : SailM Unit := do
  sail_assert (! (← (HaveAArch64 ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:42835.34-42835.35"
  (if ((HaveEL EL3) : Bool)
  then
    (do (AArch32_WriteMode M32_Svc)
        writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else
    (do (if ((HaveEL EL2) : Bool)
        then (do (AArch32_WriteMode M32_Hyp))
        else (do (AArch32_WriteMode M32_Svc)))))
  (AArch32_ResetControlRegisters cold_reset)
  (FPEXC_write (_update_FPEXC_Type_EN (← (FPEXC_read ())) 0#1))
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if (((HaveEL EL2) && (! (HaveEL EL3))) : Bool)
  then
    (do writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_HSCTLR_Type_TE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) })
  else
    (do writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }))
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  (AArch32_ResetGeneralRegisters ())
  (AArch32_ResetSIMDFPRegisters ())
  (AArch32_ResetSpecialRegisters ())
  (ResetExternalDebugRegisters cold_reset)
  let rv ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let rv ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do (if ((((BitVec.access (← readReg MVBAR) 0) : BitVec 1) == 1#1) : Bool)
          then (do (pure ((Sail.BitVec.extractLsb (← readReg MVBAR) 31 1) +++ 0#1)))
          else (do (__IMPDEF_bits 32 "reset vector address"))))
    else (do (pure ((Sail.BitVec.extractLsb (← readReg RVBAR) 31 1) +++ 0#1)))) ) : SailM (BitVec 32) )
  sail_assert (←((pure (((BitVec.access rv 0) : BitVec 1) == 0#1)) <&&> (do
    (pure (((← readReg PSTATE).T == 1#1) || (((BitVec.access rv 1) : BitVec 1) == 0#1)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:42870.62-42870.63"
  let branch_conditional : Bool := false
  (BranchTo rv BranchType_RESET branch_conditional)

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch32_TakePhysicalSErrorException (implicit_esb : Bool) : SailM Unit := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure (! (← (IsInHost ())))) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalSErrorException implicit_esb))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_EA (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if (route_to_monitor : Bool)
    then (do (pure EL3))
    else
      (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))) ) : SailM (BitVec 2) )
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let vaddress ← (( do (__UNKNOWN_bits 32) ) : SailM (BitVec 32) )
  let except ← (( do (AArch32_AbortSyndrome Exception_DataAbort fault vaddress target_el) ) : SailM ExceptionRecord )
  (if ((← (IsSErrorEdgeTriggered ())) : Bool)
  then (do (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))
  let questionMark := target_el
  (if ((questionMark == EL3) : Bool)
  then
    (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (if ((questionMark == EL1) : Bool)
              then
                (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
                    (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset))
              else (do (Unreachable ())))))))

def AArch32_TakeVirtualSErrorException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43224.63-43224.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_AMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43226.62-43226.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43228.56-43228.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualSErrorException ()))
  else (do (pure ())))
  let route_to_monitor : Bool := false
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  let vaddress ← (( do (__UNKNOWN_bits 32) ) : SailM (BitVec 32) )
  let parity : Bool := false
  let fault : Fault := Fault_AsyncExternal
  let level ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let fsr : (BitVec 32) := (Zeros (n := 32))
  let fsr ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then
      (do (if ((← (ELUsingAArch32 EL2)) : Bool)
          then
            (do let fsr ← (pure (Sail.BitVec.updateSubrange fsr 15 14 (_get_VDFSR_Type_AET (← (VDFSR_read ())))))
                (pure (BitVec.update fsr 12 (Bit (_get_VDFSR_Type_ExT (← (VDFSR_read ())))))))
          else
            (do let fsr ← (pure (Sail.BitVec.updateSubrange fsr 15 14 (_get_VSESR_EL2_Type_AET (← readReg VSESR_EL2))))
                (pure (BitVec.update fsr 12 (Bit (_get_VSESR_EL2_Type_ExT (← readReg VSESR_EL2))))))))
    else (do (pure (BitVec.update fsr 12 (Bit (← (__IMPDEF_bit "Virtual External abort type"))))))) ) : SailM (BitVec 32) )
  let fsr ← (( do
    (if (((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1) : Bool)
    then
      (do let fsr : (BitVec 32) := (BitVec.update fsr 9 (Bit 1#1))
          (pure (Sail.BitVec.updateSubrange fsr 5 0 (← (EncodeLDFSC fault level)))))
    else
      (do let fsr : (BitVec 32) := (BitVec.update fsr 9 (Bit 0#1))
          let split_vec ← do (EncodeSDFSC fault level)
          let fsr : (BitVec 32) := (Sail.BitVec.updateSubrange fsr 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
          (pure (Sail.BitVec.updateSubrange fsr 3 0 (Sail.BitVec.extractLsb split_vec 3 0))))) ) : SailM (BitVec 32) )
  (DFSR_write (Mk_DFSR_Type fsr))
  (DFAR_write (← (__UNKNOWN_bits 32)))
  (ClearPendingVirtualSError ())
  (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)

def AArch32_TakePhysicalIRQException (_ : Unit) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (pure (! (← (IsInHost ())))))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalIRQException ()))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_IRQ (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x18#8)
  let lr_offset := 4
  (if (route_to_monitor : Bool)
  then (do (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (ExceptionSyndrome Exception_IRQ) ) : SailM ExceptionRecord )
              (AArch32_EnterHypMode except preferred_exception_return vect_offset))
        else (do (AArch32_EnterMode M32_IRQ preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeVirtualIRQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43298.63-43298.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_IMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43300.62-43300.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43302.56-43302.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualIRQException ()))
  else (do (pure ())))
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x18#8)
  let lr_offset := 4
  (AArch32_EnterMode M32_IRQ preferred_exception_return lr_offset vect_offset)

def AArch32_TakePhysicalFIQException (_ : Unit) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (pure (! (← (IsInHost ())))))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3)) == 1#1)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_TakePhysicalFIQException ()))
  else (do (pure ())))
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_Type_FIQ (← readReg SCR)) == 1#1))) ) : SailM Bool )
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x1C#8)
  let lr_offset := 4
  (if (route_to_monitor : Bool)
  then (do (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (ExceptionSyndrome Exception_FIQ) ) : SailM ExceptionRecord )
              (AArch32_EnterHypMode except preferred_exception_return vect_offset))
        else (do (AArch32_EnterMode M32_FIQ preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeVirtualFIQException (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43345.63-43345.64"
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do sail_assert (←((pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 0#1)) <&&> (do (pure ((_get_HCR_Type_FMO (← (HCR_read ()))) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43347.62-43347.63")
  else (do sail_assert (←((pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:43349.56-43349.57"))
  (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
       (pure (! (← (ELUsingAArch32 EL1))))))) : Bool)
  then (do (AArch64_TakeVirtualFIQException ()))
  else (do (pure ())))
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x1C#8)
  let lr_offset := 4
  (AArch32_EnterMode M32_FIQ preferred_exception_return lr_offset vect_offset)

def undefined_PMOVSSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCCNTR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HDFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HDFGWTR_EL2_Type_DBGCLAIM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HDFGWTR_EL2_Type_DBGPRCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HDFGWTR_EL2_Type_DBGWCRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_HDFGWTR_EL2_Type_DBGWVRn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HDFGWTR_EL2_Type_MDSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HDFGWTR_EL2_Type_OSDLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HDFGWTR_EL2_Type_OSECCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_HDFGWTR_EL2_Type_PMBLIMITR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_HDFGWTR_EL2_Type_PMBPTR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_HDFGWTR_EL2_Type_PMBSR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_HDFGWTR_EL2_Type_PMCCFILTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_HDFGWTR_EL2_Type_PMCCNTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_HDFGWTR_EL2_Type_PMCNTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_HDFGWTR_EL2_Type_PMEVCNTRn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDFGWTR_EL2_Type_PMEVTYPERn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HDFGWTR_EL2_Type_PMINTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HDFGWTR_EL2_Type_PMOVS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_HDFGWTR_EL2_Type_PMSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_HDFGWTR_EL2_Type_PMSELR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HDFGWTR_EL2_Type_PMSEVFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_HDFGWTR_EL2_Type_PMSFCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_HDFGWTR_EL2_Type_PMSICR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_HDFGWTR_EL2_Type_PMSIRR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_HDFGWTR_EL2_Type_PMSLATFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HDFGWTR_EL2_Type_PMUSERENR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_HDFGWTR_EL2_Type_nBRBCTL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_HDFGWTR_EL2_Type_nBRBDATA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_HDFGWTR_EL2_Type_nPMSNEVFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def undefined_ICH_LR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_LR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_BPR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICV_BPR1_EL1_Type_BinaryPoint (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def _get_ICV_BPR0_EL1_Type_BinaryPoint (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def Mk_PMECR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_EOIR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_RMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_RMR_EL3_Type_AA64 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def Mk_OSLAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_CNTHPS_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHPS_CTL_EL2_Type := value_name
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def Mk_HAFGRTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_BPR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ACCDATA_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_SCTLR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : SCTLR_EL1_Type := value_name
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 4 0 (BitVec.slice r 0 5))
  writeReg SCTLR_EL1 (BitVec.update (← readReg SCTLR_EL1) 6 (Bit (BitVec.slice r 6 1)))
  writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 63 8 (BitVec.slice r 8 56))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_ITD")))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 7 7 (_get_SCTLR_EL1_Type_ITD r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_CP15BEN")))) : Bool)
  then (do writeReg SCTLR_EL1 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL1) 5 5 (_get_SCTLR_EL1_Type_CP15BEN r)))
  else (do (pure ())))

def Mk_PMSSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_PMSSCR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : PMSSCR_EL1_Type := value_name
  writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 63 1 (BitVec.slice r 1 63))
  (if ((! (← (__IMPDEF_boolean "Capture events are disabled"))) : Bool)
  then (do writeReg PMSSCR_EL1 (Sail.BitVec.updateSubrange (← readReg PMSSCR_EL1) 0 0 (_get_PMSSCR_EL1_Type_SS r)))
  else (do (pure ())))

def Mk_ICC_SGI0R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_FPCR (value_name : (BitVec 64)) : SailM Unit := do
  let r : FPCR_Type := value_name
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 7 0 (BitVec.slice r 0 8))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 14 13 (BitVec.slice r 13 2))
  writeReg FPCR (BitVec.update (← readReg FPCR) 19 (Bit (BitVec.slice r 19 1)))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 63 22 (BitVec.slice r 22 42))
  (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_FPSCR.LEN,STRIDE as RAZ"))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 21 20 (_get_FPCR_Type_Stride r)))
  else (do (pure ())))
  (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_FPSCR.LEN,STRIDE as RAZ"))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 18 16 (_get_FPCR_Type_length r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Input Denormal floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 15 15 (_get_FPCR_Type_IDE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Inexact floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 12 12 (_get_FPCR_Type_IXE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Underflow floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 11 11 (_get_FPCR_Type_UFE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Overflow floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 10 10 (_get_FPCR_Type_OFE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Divide by Zero floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 9 9 (_get_FPCR_Type_DZE r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Invalid Operation floating-point exceptions")))) : Bool)
  then (do writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 8 8 (_get_FPCR_Type_IOE r)))
  else (do (pure ())))

def __set_CNTHVS_CTL_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTHVS_CTL_EL2_Type := value_name
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 1 0 (BitVec.slice r 0 2))
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 63 3 (BitVec.slice r 3 61))

def undefined_SPMACCESSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPMACCESSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_SPMSELR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SPMSELR_EL0_Type_SYSPMUSEL (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 9 4)

def __get_selected_SPMACCESSR_EL1_field (_ : Unit) : SailM (BitVec 2) := do
  let idx ← (( do (pure ((BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) *i 2)) ) : SailM Int )
  (pure (BitVec.slice (← readReg SPMACCESSR_EL1) idx 2))

def undefined_ICH_AP1R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_AP1R_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_DIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMEVCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_ICC_SRE_EL2_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_ICC_SRE_EL3_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_ICV_IGRPEN0_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_IGRPEN1_EL1_Type_Enable (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def Mk_DBGCLAIMSET_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_ICC_SRE_EL1_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICC_SRE_EL2_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICC_SRE_EL3_Type_SRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def undefined_ICH_AP0R_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICH_AP0R_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMUACR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_RMR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMSELR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSELR_EL0_Type_SEL (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _get_ERRSELR_EL1_Type_SEL (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_ICC_CTLR_EL3_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_A3V (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_ICV_CTLR_EL1_Type_CBPR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_ICV_CTLR_EL1_Type_EOImode (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_ICC_CTLR_EL3_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICV_CTLR_EL1_Type_ExtRange (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_ICC_CTLR_EL3_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICV_CTLR_EL1_Type_IDbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 13 11)

def _get_ICC_CTLR_EL3_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICV_CTLR_EL1_Type_PRIbits (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 10 8)

def _get_ICC_CTLR_EL3_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_ICV_CTLR_EL1_Type_SEIS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def undefined_ICC_AP1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_AP1R_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: n : Int -/
def ICC_AP1R_EL1_set (n : Int) (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_AP1R_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then
    (do sail_assert ((0 ≤b n) && (n <b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:44781.45-44781.46"
        writeReg ICC_AP1R_EL1_S (vectorUpdate (← readReg ICC_AP1R_EL1_S) n r))
  else
    (do sail_assert ((0 ≤b n) && (n <b 4)) "sail-arm/arm-v9.4-a/src/v8_base.sail:44784.45-44784.46"
        writeReg ICC_AP1R_EL1_NS (vectorUpdate (← readReg ICC_AP1R_EL1_NS) n r)))

def __set_CNTP_CTL_EL0 (value_name : (BitVec 64)) : SailM Unit := do
  let r : CNTP_CTL_EL0_Type := value_name
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 1 0 (BitVec.slice r 0 2))
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 63 3 (BitVec.slice r 3 61))

def Mk_CSSELR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_PMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICV_BPR0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMCCNTSVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMINTENSET_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_HFGWTR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGWTR_EL2_Type_AFSR0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HFGWTR_EL2_Type_AFSR1_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HFGWTR_EL2_Type_AMAIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HFGWTR_EL2_Type_APDAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HFGWTR_EL2_Type_APDBKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HFGWTR_EL2_Type_APGAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_HFGWTR_EL2_Type_APIAKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HFGWTR_EL2_Type_APIBKey (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HFGWTR_EL2_Type_CONTEXTIDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HFGWTR_EL2_Type_CPACR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HFGWTR_EL2_Type_CSSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HFGWTR_EL2_Type_ERRSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_HFGWTR_EL2_Type_ERXADDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_HFGWTR_EL2_Type_ERXCTLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_HFGWTR_EL2_Type_ERXMISCn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 45 45)

def _get_HFGWTR_EL2_Type_ERXPFGCDN_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def _get_HFGWTR_EL2_Type_ERXPFGCTL_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 47 47)

def _get_HFGWTR_EL2_Type_ERXSTATUS_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_HFGWTR_EL2_Type_ESR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_HFGWTR_EL2_Type_FAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HFGWTR_EL2_Type_ICC_IGRPENn_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 39 39)

def _get_HFGWTR_EL2_Type_LORC_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HFGWTR_EL2_Type_LOREA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_HFGWTR_EL2_Type_LORN_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_HFGWTR_EL2_Type_LORSA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_HFGWTR_EL2_Type_MAIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_HFGWTR_EL2_Type_PAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_HFGWTR_EL2_Type_SCTLR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_HFGWTR_EL2_Type_SCXTNUM_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_HFGWTR_EL2_Type_SCXTNUM_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_HFGWTR_EL2_Type_TCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HFGWTR_EL2_Type_TPIDRRO_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_HFGWTR_EL2_Type_TPIDR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_HFGRTR_EL2_Type_TPIDR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_HFGWTR_EL2_Type_TPIDR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_HFGWTR_EL2_Type_TTBR0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_HFGWTR_EL2_Type_TTBR1_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_HFGWTR_EL2_Type_VBAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_HFGWTR_EL2_Type_nACCDATA_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_HFGWTR_EL2_Type_nAMAIR2_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_HFGWTR_EL2_Type_nGCS_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_HFGWTR_EL2_Type_nGCS_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_HFGWTR_EL2_Type_nMAIR2_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _get_HFGWTR_EL2_Type_nPIRE0_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_HFGWTR_EL2_Type_nPIR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_HFGWTR_EL2_Type_nPOR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_HFGWTR_EL2_Type_nPOR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_HFGWTR_EL2_Type_nRCWMASK_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_HFGWTR_EL2_Type_nS2POR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_HFGWTR_EL2_Type_nSMPRI_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_HFGWTR_EL2_Type_nTPIDR2_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def Mk_SMPRI_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PMUSERENR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMUSERENR_EL0_Type_ER (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_PMUSERENR_EL0_Type_UEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def Mk_ICV_CTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def __set_FPEXC32_EL2 (value_name : (BitVec 64)) : SailM Unit := do
  let r : FPEXC32_EL2_Type := value_name
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 6 5 (BitVec.slice r 5 2))
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 30 8 (BitVec.slice r 8 23))
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 63 32 (BitVec.slice r 32 32))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Input Denormal floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 7 7 (_get_FPEXC32_EL2_Type_IDF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Inexact floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 4 4 (_get_FPEXC32_EL2_Type_IXF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Underflow floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 3 3 (_get_FPEXC32_EL2_Type_UFF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Overflow floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 2 2 (_get_FPEXC32_EL2_Type_OFF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Divide by Zero floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 1 1 (_get_FPEXC32_EL2_Type_DZF r)))
  else (do (pure ())))
  (if ((! (! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Invalid Operation floating-point exceptions")))) : Bool)
  then (do writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 0 0 (_get_FPEXC32_EL2_Type_IOF r)))
  else (do (pure ())))

def __set_MDSCR_EL1 (value_name : (BitVec 64)) : SailM Unit := do
  let r : MDSCR_EL1_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 5 0 (BitVec.slice r 0 6))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 13 7 (BitVec.slice r 7 7))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 18 15 (BitVec.slice r 15 4))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 20 (Bit (BitVec.slice r 20 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 25 24 (BitVec.slice r 24 2))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 28 (Bit (BitVec.slice r 28 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 34 32 (BitVec.slice r 32 3))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 36 (BitVec.slice r 36 28))
  (if ((! ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 35 35 (_get_MDSCR_EL1_Type_EHBWE r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 31 31 (_get_MDSCR_EL1_Type_TFO r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 30 30 (_get_MDSCR_EL1_Type_RXfull r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 29 29 (_get_MDSCR_EL1_Type_TXfull r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 27 27 (_get_MDSCR_EL1_Type_RXO r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 26 26 (_get_MDSCR_EL1_Type_TXU r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 23 22 (_get_MDSCR_EL1_Type_INTdis r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 21 21 (_get_MDSCR_EL1_Type_TDA r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 19 19 (_get_MDSCR_EL1_Type_SC2 r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 14 14 (_get_MDSCR_EL1_Type_HDE r)))
  else (do (pure ())))
  (if (((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1) : Bool)
  then (do writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 6 6 (_get_MDSCR_EL1_Type_ERR r)))
  else (do (pure ())))

def __set_GPCCR_EL3 (value_name : (BitVec 64)) : SailM Unit := do
  let r : GPCCR_EL3_Type := value_name
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 19 0 (BitVec.slice r 0 20))
  writeReg GPCCR_EL3 (Sail.BitVec.updateSubrange (← readReg GPCCR_EL3) 63 24 (BitVec.slice r 24 40))

def Mk_HDFGWTR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HDFGWTR2_EL2_Type_nMDSELR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_HDFGWTR2_EL2_Type_nPMECR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_HDFGWTR2_EL2_Type_nPMIAR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_HDFGWTR2_EL2_Type_nPMICFILTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HDFGWTR2_EL2_Type_nPMICNTR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_HDFGWTR2_EL2_Type_nPMSDSFR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_HDFGWTR2_EL2_Type_nPMSSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HDFGWTR2_EL2_Type_nPMUACR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_HDFGWTR2_EL2_Type_nPMZR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_HDFGWTR2_EL2_Type_nSPMACCESSR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_HDFGWTR2_EL2_Type_nSPMCNTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_HDFGWTR2_EL2_Type_nSPMCR_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_HDFGWTR2_EL2_Type_nSPMEVCNTRn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_HDFGWTR2_EL2_Type_nSPMINTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDFGWTR2_EL2_Type_nSPMOVS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_HDFGWTR2_EL2_Type_nSPMSCR_EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)


end ArmASL.Functions
