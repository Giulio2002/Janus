import ArmASL.Part17

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def ACCDATA_EL1_SysRegWrite_8e0ffec0877851f7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_ADEn ← (( do (pure (_get_SCR_EL3_Type_ADEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nACCDATA_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nACCDATA_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ADEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nACCDATA_EL1 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_ADEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACCDATA_EL1 (Mk_ACCDATA_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL1_SysRegWrite_7b28af04d67b98b9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TACR ← (( do (pure (_get_HCR_EL2_Type_TACR (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TACR == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set (BitVec.toNat 0x118#12) (← (X_read t 64))))
                    else (do writeReg ACTLR_EL1 (← (X_read t 64)))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg ACTLR_EL1 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL2_SysRegWrite_55fae67ae0a6faf2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg ACTLR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ACTLR_EL3_SysRegWrite_32865ae0e6068940 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ACTLR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL1_SysRegWrite_be844a45265221f7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x128#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL1_SysRegWrite_bfb8a5c21b8a15cd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AFSR0_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AFSR0_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AFSR0_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x128#12) (← (X_read t 64))))
                          else (do writeReg AFSR0_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR0_EL2 (← (X_read t 64)))
                    else (do writeReg AFSR0_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL2_SysRegWrite_1b5a40d7cb8265ce (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AFSR0_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR0_EL3_SysRegWrite_1c6f9ccfd5716ce3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR0_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL1_SysRegWrite_358d58edce00a180 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x130#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL1_SysRegWrite_57c6bddf9a2482df (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AFSR1_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AFSR1_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AFSR1_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x130#12) (← (X_read t 64))))
                          else (do writeReg AFSR1_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AFSR1_EL2 (← (X_read t 64)))
                    else (do writeReg AFSR1_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL2_SysRegWrite_a63eac436b30cded (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AFSR1_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AFSR1_EL3_SysRegWrite_9124b1facd539906 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AFSR1_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ALLINT_SysRegWrite_28e93c037c43b390 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCRX_EL2_TALLINT ← (( do (pure (_get_HCRX_EL2_Type_TALLINT (← readReg HCRX_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((EL2Enabled ()) <&&> (do
                     (IsHCRXEL2Enabled ())))) && (__HCRX_EL2_TALLINT == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with ALLINT := (← do (pure ((BitVec.access (← (X_read t 64)) 13) : BitVec 1))) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL1_SysRegWrite_15a11ef20a82181c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x288#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AMAIR2_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL2_SysRegWrite_1e7d4e25c1dcc572 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg AMAIR2_EL2 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL2_SysRegWrite_d6e02923e8c9c534 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AIEn ← (( do (pure (_get_SCR_EL3_Type_AIEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_nAMAIR2_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_nAMAIR2_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_nAMAIR2_EL1 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x288#12) (← (X_read t 64))))
                                      else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_AIEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg AMAIR2_EL2 (← (X_read t 64)))
                                else (do writeReg AMAIR2_EL1 (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR2_EL3_SysRegWrite_2519753087e4450a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR2_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL1_SysRegWrite_88ac7594e16a57fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x148#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL2_SysRegWrite_3448b91e0a445f88 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_AMAIR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_AMAIR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_AMAIR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x148#12) (← (X_read t 64))))
                          else (do writeReg AMAIR_EL1 (← (X_read t 64)))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg AMAIR_EL2 (← (X_read t 64)))
                    else (do writeReg AMAIR_EL1 (← (X_read t 64)))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL2_SysRegWrite_4119e8051bae499e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg AMAIR_EL2 (← (X_read t 64)))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMAIR_EL3_SysRegWrite_31ae559cd6a97a1f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMAIR_EL3 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMCNTENCLR0_EL0_SysRegWrite_87e21241643a862e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENCLR0_EL0 (Mk_AMCNTENCLR0_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENCLR1_EL0_SysRegWrite_c63fb61a666d3a21 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENCLR1_EL0 (Mk_AMCNTENCLR1_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENSET0_EL0_SysRegWrite_b4e12b5dd3b0738a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENSET0_EL0 (Mk_AMCNTENSET0_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCNTENSET1_EL0_SysRegWrite_a3bee0219e2d4b9e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCNTENSET1_EL0 (Mk_AMCNTENSET1_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMCR_EL0_SysRegWrite_6a9019dd97aa8af1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do writeReg AMCR_EL0 (Mk_AMCR_EL0_Type (← (X_read t 64))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_57776cdcd88bec7e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 2 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_a28bd21dde7b55b6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 1 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_ca5a4224a458ea03 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 0 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR0_EL0_SysRegWrite_df6bb2663cab03ed (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
  then (do (AMEVCNTR0_EL0_set 3 (Mk_AMEVCNTR0_EL0_Type (← (X_read t 64)))))
  else (do sailThrow ((Error_Undefined ()))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_2bb86c4004ef9258 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 0))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 0 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_2cb2cddc132a8d44 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 6))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 6 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_3743486d55da4508 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 1 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_44cf3260f4372341 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 5))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 5 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_4a152435dd65137a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 10))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 10 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_5139d9a03c76c81b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 3))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 3 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_59bacd045e260141 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 4))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 4 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_6bd5d306c662d714 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 2))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 2 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_887d0ce81624d210 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 15))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 15 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_909b4a89534d73e1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 9))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 9 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_9193b8497c20a5ba (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 14))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 14 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_cef156af264e97db (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 11))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 11 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_d8f3e0edb71c094d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 8))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 8 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_e45e9615b0ec1e8a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 12))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 12 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_f1dd22a5ecbcbc6b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 13))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 13 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTR1_EL0_SysRegWrite_fe71412c61f10c5a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 7))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((IsHighestEL (← readReg PSTATE).EL) : Bool)
        then (do writeReg AMEVCNTR1_EL0 (vectorUpdate (← readReg AMEVCNTR1_EL0) 7 (Mk_AMEVCNTR1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_0923dbc89132e313 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 3)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 3 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 3 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_16f386a96bc6f4d5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_1aa3b39d45f679b5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_31c0cdbd9c1a5aa3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_4c087411a832c41e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_7037d0a12cbf01ad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_74ccc6eecceec9f9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_972cb3f0c159a0b7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_9d4925d599bf21f3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_9dd8ffd73516d6df (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_a45d1ca97a349f4b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_ad5b87d3125380af (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_bbcf6bc1df66bebc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_c10f27e36cfd4438 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 2)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 2 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 2 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_c76c398d7598cd2b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF0_EL2_SysRegWrite_f6918a05ffc46bd6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0xA00#12) +i (8 *i 0)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 0 (← (X_read t 64))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMEVCNTVOFF0_EL2 (vectorUpdate (← readReg AMEVCNTVOFF0_EL2) 0 (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_028cfcaff48c5d3b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 9))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 9)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 9 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 9 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_18b1c0f6609cfc70 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 8))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 8)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 8 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 8 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_1a046ba7336f9e16 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 12))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 12)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 12 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 12 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_21fc3e4e66b7bf2e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 4))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 4)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 4 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 4 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_2ba85b85b5072821 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 10))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 10)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 10 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 10 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_386268cd3029fb99 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 11))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 11)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 11 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 11 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_55f6fd2dd91b0e50 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 6))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 6)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 6 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 6 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_715140b6e1ae357e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 14))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 14)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 14 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 14 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_894c1ceeabf341e5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 13))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 13)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 13 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 13 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_a4b7dbcc8064b06d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 3))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 3)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 3 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 3 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_bcd39cd29daf1662 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 1)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 1 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 1 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_c6e6c9e8e68d2fab (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 0))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 0)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 0 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 0 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_e78a33d39c6749cb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 5))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 5)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 5 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 5 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_e7b42f6640c3913b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 2))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 2)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 2 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 2 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_f1ccc2e130743f64 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 15))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 15)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 15 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 15 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVCNTVOFF1_EL2_SysRegWrite_fe51081bae489e73 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_AMVOFFEN ← (( do (pure (_get_SCR_EL3_Type_AMVOFFEN (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((! (← (IsG1ActivityMonitorOffsetImplemented 7))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if ((←((EL2Enabled ()) <&&> (do
                         (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
                    then (do (NVMem_set ((BitVec.toNat 0xA80#12) +i (8 *i 7)) (← (X_read t 64))))
                    else
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do sailThrow ((Error_Undefined ())))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                       (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_AMVOFFEN == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 7 (← (X_read t 64))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg AMEVCNTVOFF1_EL2 (vectorUpdate (← readReg AMEVCNTVOFF1_EL2) 7 (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_017c244c296ed80f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 5))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 5 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_15f530ac1097257c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 13))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 13 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_3a4a4f972b395f75 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 12))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 12 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_622d8153064a03a6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 2))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 2 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_6269036dfbd59a24 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 9))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 9 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_7e132038a6af9b7c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 8))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 8 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_85fbd4e6563d2700 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 15))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 15 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_8b9bd86620491fc7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 11))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 11 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_a9e61442f4e1c8cd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 6))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 6 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_bc02f6fe6d8b784f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 7))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 7 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_be5c5b889ae5d0cb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 1))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 1 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_c43b886db277fa04 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 0))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 0 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_e549f9ca48c70852 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 14))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 14 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_ed2615d4120abbd7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 3))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 3 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_f55a7574a9b217fe (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 4))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 4 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMEVTYPER1_EL0_SysRegWrite_f744e58350c3c492 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  (if ((! (← (IsG1ActivityMonitorImplemented 10))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((←((pure (IsHighestEL (← readReg PSTATE).EL)) <&&> (do
             (pure (! (← (__IMPDEF_boolean "AMEVCNTR1_EL0[m] is fixed"))))))) : Bool)
        then (do writeReg AMEVTYPER1_EL0 (vectorUpdate (← readReg AMEVTYPER1_EL0) 10 (Mk_AMEVTYPER1_EL0_Type (← (X_read t 64)))))
        else (do sailThrow ((Error_Undefined ()))))))

/-- Type quantifiers: t : Int -/
def AMUSERENR_EL0_SysRegWrite_048ed8e6dc551988 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TAM ← (( do (pure (_get_CPTR_EL3_Type_TAM (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TAM ← (( do (pure (_get_CPTR_EL2_Type_TAM (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__CPTR_EL2_TAM == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg AMUSERENR_EL0 (Mk_AMUSERENR_EL0_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__CPTR_EL3_TAM == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg AMUSERENR_EL0 (Mk_AMUSERENR_EL0_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg AMUSERENR_EL0 (Mk_AMUSERENR_EL0_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APDAKeyHi_EL1_SysRegWrite_9127291587c7ea6e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APDAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APDAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APDAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APDAKeyHi_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APDAKeyHi_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APDAKeyHi_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def APDAKeyLo_EL1_SysRegWrite_0e1165080dd4ea81 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_APK ← (( do (pure (_get_SCR_EL3_Type_APK (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HCR_EL2_APK ← (( do (pure (_get_HCR_EL2_Type_APK (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_APDAKey ← (( do (pure (_get_HFGWTR_EL2_Type_APDAKey (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_APK == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_APDAKey == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg APDAKeyLo_EL1 (← (X_read t 64)))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_APK == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_APK == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg APDAKeyLo_EL1 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg APDAKeyLo_EL1 (← (X_read t 64)))
                    else (do (pure ())))))))))


end ArmASL.Functions
