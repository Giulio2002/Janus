import ArmASL.Part23

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_fminp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_1985 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_1985 d datasize elements esize m minimum n pair)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, k_minimum : Bool, n : Nat, k_pair : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_2008 (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (minimum : Bool) (n : Nat) (pair : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand2 +++ operand1)
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let (element1, element2) ← (( do
          (if (pair : Bool)
          then
            (do let element1 ← (Elem_read concat (2 *i e) esize)
                let element2 ← (Elem_read concat ((2 *i e) +i 1) esize)
                (pure (element1, element2)))
          else
            (do let element1 ← (Elem_read operand1 e esize)
                let element2 ← (Elem_read operand2 e esize)
                (pure (element1, element2)))) ) : SailM ((BitVec esize) × (BitVec esize)) )
        let result ← (( do
          (if (minimum : Bool)
          then (do (Elem_set result e esize (← (FPMinNum element1 element2 (← (FPCR_read ()))))))
          else (do (Elem_set result e esize (← (FPMaxNum element1 element2 (← (FPCR_read ()))))))) ) : SailM (BitVec datasize) )
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fmaxnm_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_2008 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_2008 d datasize elements esize m minimum n pair)

def decode_fmaxnmp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_2008 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_2008 d datasize elements esize m minimum n pair)

def decode_fminnm_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_2008 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_2008 d datasize elements esize m minimum n pair)

def decode_fminnmp_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp_2008 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let pair : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_fp16_2008 d datasize elements esize m minimum n pair)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_fp16_maxnm_sisd (d : Nat) (datasize : Nat) (esize : Nat) (n : Nat) (op : ReduceOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let altfp : Bool := false
  sail_assert (datasize ≥b esize) "sail-arm/arm-v9.4-a/src/instrs64.sail:17751.42-17751.43"
  (V_set d esize (← (Reduce__1 op operand esize altfp)))

def decode_fmaxnmp_advsimd_pair_aarch64_instrs_vector_reduce_fp_maxnm_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := (esize *i 2)
  let elements := 2
  let op : ReduceOp :=
    if ((o1 == 1#1) : Bool)
    then ReduceOp_FMINNUM
    else ReduceOp_FMAXNUM
  (execute_aarch64_instrs_vector_reduce_fp16_maxnm_sisd d datasize esize n op)

def decode_fminnmp_advsimd_pair_aarch64_instrs_vector_reduce_fp_maxnm_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := (esize *i 2)
  let elements := 2
  let op : ReduceOp :=
    if ((o1 == 1#1) : Bool)
    then ReduceOp_FMINNUM
    else ReduceOp_FMAXNUM
  (execute_aarch64_instrs_vector_reduce_fp16_maxnm_sisd d datasize esize n op)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_fp16_max_sisd (d : Nat) (datasize : Nat) (esize : Nat) (n : Nat) (op : ReduceOp) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  sail_assert (datasize ≥b esize) "sail-arm/arm-v9.4-a/src/instrs64.sail:17941.42-17941.43"
  (V_set d esize (← (Reduce op operand esize)))

def decode_fmaxp_advsimd_pair_aarch64_instrs_vector_reduce_fp_max_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := (esize *i 2)
  let elements := 2
  let op : ReduceOp :=
    if ((o1 == 1#1) : Bool)
    then ReduceOp_FMIN
    else ReduceOp_FMAX
  (execute_aarch64_instrs_vector_reduce_fp16_max_sisd d datasize esize n op)

def decode_fminp_advsimd_pair_aarch64_instrs_vector_reduce_fp_max_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (o1 : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := (esize *i 2)
  let elements := 2
  let op : ReduceOp :=
    if ((o1 == 1#1) : Bool)
    then ReduceOp_FMIN
    else ReduceOp_FMAX
  (execute_aarch64_instrs_vector_reduce_fp16_max_sisd d datasize esize n op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (Elem_read operand2 index esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element1 ← (( do
          (if (sub_op : Bool)
          then (do (FPNeg element1))
          else (do (pure element1))) ) : SailM (BitVec esize) )
        let result ← (Elem_set result e esize (← (FPMulAdd (← (Elem_read operand3 e esize)) element1 element2 fpcr)))
        (pure (element1, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fmla_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp16_sisd d datasize elements esize idxdsize index m n sub_op)

def decode_fmla_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp16_sisd d datasize elements esize idxdsize index m n sub_op)

def decode_fmls_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp16_sisd d datasize elements esize idxdsize index m n sub_op)

def decode_fmls_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_fp16_sisd d datasize elements esize idxdsize index m n sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_fused (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let element1 ← (( do
          (if (sub_op : Bool)
          then (do (FPNeg element1))
          else (do (pure element1))) ) : SailM (BitVec esize) )
        let result ← (Elem_set result e esize (← (FPMulAdd (← (Elem_read operand3 e esize)) element1 element2 (← (FPCR_read ())))))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fmla_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_fused (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_fused d datasize elements esize m n sub_op)

def decode_fmls_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_fused (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_fused d datasize elements esize m n sub_op)

/-- Type quantifiers: datasize : Nat, rd : Nat, 0 ≤ rd ∧ rd ≤ 31 ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_vector_fp16_movi (datasize : Nat) (imm : (BitVec datasize)) (rd : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  (V_set rd datasize imm)

def decode_fmov_advsimd_aarch64_instrs_vector_fp16_movi (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  (if ((! (HaveFP16Ext ())) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let imm8 : (BitVec 8) := (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)
  let imm16 : (BitVec 16) := ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 2)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 6)))
  let imm : (BitVec datasize) := (BitVec.replicateBits imm16 (Int.ediv datasize 16))
  (execute_aarch64_instrs_vector_fp16_movi datasize imm rd)

def decode_fmov_advsimd_aarch64_instrs_vector_logical (Rd : (BitVec 5)) (h : (BitVec 1)) (g : (BitVec 1)) (f : (BitVec 1)) (e : (BitVec 1)) (d : (BitVec 1)) (cmode : (BitVec 4)) (c : (BitVec 1)) (b : (BitVec 1)) (a : (BitVec 1)) (op : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let rd := (BitVec.toNat Rd)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let operation ← (( do (undefined_ImmediateOp ()) ) : SailM ImmediateOp )
  let operation ← (( do
    let b__0 := (cmode +++ op)
    (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
    then (do (pure ImmediateOp_MOVI))
    else
      (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
          then (do (pure ImmediateOp_MVNI))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                then (do (pure ImmediateOp_ORR))
                else
                  (do (if ((((Sail.BitVec.extractLsb b__0 4 4) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                      then (do (pure ImmediateOp_BIC))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b00#2 : (BitVec 2)))) : Bool)
                            then (do (pure ImmediateOp_MOVI))
                            else
                              (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
                                  then (do (pure ImmediateOp_MVNI))
                                  else
                                    (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                                        then (do (pure ImmediateOp_ORR))
                                        else
                                          (do (if ((((Sail.BitVec.extractLsb b__0 4 3) == (0b10#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2)))) : Bool)
                                              then (do (pure ImmediateOp_BIC))
                                              else
                                                (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                                                    then (do (pure ImmediateOp_MOVI))
                                                    else
                                                      (do (if ((((Sail.BitVec.extractLsb b__0 4 2) == (0b110#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                                                          then (do (pure ImmediateOp_MVNI))
                                                          else
                                                            (do (if (((Sail.BitVec.extractLsb b__0 4 1) == (0xE#4 : (BitVec 4))) : Bool)
                                                                then (do (pure ImmediateOp_MOVI))
                                                                else
                                                                  (do (if ((b__0 == (0b11110#5 : (BitVec 5))) : Bool)
                                                                      then (do (pure ImmediateOp_MOVI))
                                                                      else
                                                                        (do (if ((Q == 0#1) : Bool)
                                                                            then (do sailThrow ((Error_Undefined ())))
                                                                            else (do (pure ())))
                                                                            (pure ImmediateOp_MOVI))))))))))))))))))))))))) ) : SailM ImmediateOp )
  let operation := operation
  let imm64 ← (( do (AdvSIMDExpandImm op cmode (((((((a +++ b) +++ c) +++ d) +++ e) +++ f) +++ g) +++ h)) ) : SailM (BitVec 64) )
  let imm : (BitVec datasize) := (BitVec.replicateBits imm64 (Int.ediv datasize 64))
  (execute_aarch64_instrs_vector_fp16_movi datasize imm rd)

/-- Type quantifiers: d : Nat, datasize : Nat, List.elem datasize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_move_fp_imm (d : Nat) (datasize : Nat) (imm : (BitVec datasize)) : SailM Unit := do
  (CheckFPEnabled64 ())
  (V_set d datasize imm)

def decode_fmov_float_imm_aarch64_instrs_float_move_fp_imm (Rd : (BitVec 5)) (imm8 : (BitVec 8)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let datasize : Int := 16
  let datasize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let datasize := datasize
  let imm ← (( do (VFPExpandImm imm8 datasize) ) : SailM (BitVec datasize) )
  (execute_aarch64_instrs_float_move_fp_imm d datasize imm)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_product (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (Elem_set result e esize (← (FPMul element1 element2 (← (FPCR_read ())))))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fmul_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_product d datasize elements esize m n)

/-- Type quantifiers: d : Nat, esize : Nat, m : Nat, n : Nat, k_negated : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_mul_product (d : Nat) (esize : Nat) (m : Nat) (n : Nat) (negated : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let operand1 ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let operand2 ← (( do (V_read m esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let product ← (( do (FPMul operand1 operand2 fpcr) ) : SailM (BitVec esize) )
  let product ← (( do
    (if (negated : Bool)
    then (do (FPNeg product))
    else (do (pure product))) ) : SailM (BitVec esize) )
  let result ← (Elem_set result 0 esize product)
  (V_set d 128 result)

def decode_fmul_float_aarch64_instrs_float_arithmetic_mul_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let negated : Bool := (op == 1#1)
  (execute_aarch64_instrs_float_arithmetic_mul_product d esize m n negated)

def decode_fnmul_float_aarch64_instrs_float_arithmetic_mul_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (Rm : (BitVec 5)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let negated : Bool := (op == 1#1)
  (execute_aarch64_instrs_float_arithmetic_mul_product d esize m n negated)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, k_mulx_op : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (mulx_op : Bool) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (Elem_read operand2 index esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let result ← (( do
          (if (mulx_op : Bool)
          then (do (Elem_set result e esize (← (FPMulX element1 element2 fpcr))))
          else (do (Elem_set result e esize (← (FPMul element1 element2 fpcr))))) ) : SailM (BitVec 128) )
        (pure (element1, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fmul_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let mulx_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_fp16_sisd d datasize elements esize idxdsize index m mulx_op n)

def decode_fmul_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let mulx_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_fp16_sisd d datasize elements esize idxdsize index m mulx_op n)

def decode_fmulx_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_fp_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  let mulx_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_fp16_sisd d datasize elements esize idxdsize index m mulx_op n)

def decode_fmulx_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 3) ) : SailM Nat )
  let Rmhi : (BitVec 1) := M
  let index ← (( do
    let b__0 := (sz +++ L)
    (if (((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1))) : Bool)
    then (do (pure (BitVec.toNat (H +++ L))))
    else
      (do (if ((b__0 == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure (BitVec.toNat H)))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Nat )
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let mulx_op : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_fp16_sisd d datasize elements esize idxdsize index m mulx_op n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_extended_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (if ((elements == 1) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (Elem_set result e esize (← (FPMulX element1 element2 fpcr)))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_fmulx_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_extended_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_extended_sisd d datasize elements esize m n)

def decode_fmulx_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp_extended_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_fp16_extended_sisd d datasize elements esize m n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_recip_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (if ((elements == 1) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FPRecipEstimate element (← (FPCR_read ())))))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_frecpe_advsimd_aarch64_instrs_vector_arithmetic_unary_special_recip_float_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_unary_special_recip_fp16_sisd d datasize elements esize n)

def decode_frecpe_advsimd_aarch64_instrs_vector_arithmetic_unary_special_recip_float_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_recip_fp16_sisd d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_recps_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (if ((elements == 1) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (Elem_set result e esize (← (FPRecipStepFused element1 element2)))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_frecps_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_recps_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_recps_fp16_sisd d datasize elements esize m n)

def decode_frecps_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_recps_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_recps_fp16_sisd d datasize elements esize m n)

/-- Type quantifiers: d : Nat, esize : Nat, intsize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem intsize [32, 64] ∧ List.elem esize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_round_frint_32_64 (d : Nat) (esize : Nat) (intsize : Nat) (n : Nat) (rounding : FPRounding) : SailM Unit := do
  (CheckFPEnabled64 ())
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let operand ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let result ← (Elem_set result 0 esize (← (FPRoundIntN operand fpcr rounding intsize)))
  (V_set d 128 result)

def decode_frint32x_float_aarch64_instrs_float_arithmetic_round_frint_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveFrintExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 32
  let esize ← (( do
    let b__0 := ftype
    (if ((b__0 == (0b00#2 : (BitVec 2))) : Bool)
    then (do (pure 32))
    else
      (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
          then (do (pure 64))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Int )
  let esize := esize
  let intsize :=
    if ((((BitVec.access op 1) : BitVec 1) == 0#1) : Bool)
    then 32
    else 64
  let rounding ← (( do
    (if ((((BitVec.access op 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure FPRounding_ZERO))
    else (do (FPRoundingMode (← (FPCR_read ()))))) ) : SailM FPRounding )
  (execute_aarch64_instrs_float_arithmetic_round_frint_32_64 d esize intsize n rounding)

def decode_frint32z_float_aarch64_instrs_float_arithmetic_round_frint_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveFrintExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 32
  let esize ← (( do
    let b__0 := ftype
    (if ((b__0 == (0b00#2 : (BitVec 2))) : Bool)
    then (do (pure 32))
    else
      (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
          then (do (pure 64))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Int )
  let esize := esize
  let intsize :=
    if ((((BitVec.access op 1) : BitVec 1) == 0#1) : Bool)
    then 32
    else 64
  let rounding ← (( do
    (if ((((BitVec.access op 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure FPRounding_ZERO))
    else (do (FPRoundingMode (← (FPCR_read ()))))) ) : SailM FPRounding )
  (execute_aarch64_instrs_float_arithmetic_round_frint_32_64 d esize intsize n rounding)

def decode_frint64x_float_aarch64_instrs_float_arithmetic_round_frint_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveFrintExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 32
  let esize ← (( do
    let b__0 := ftype
    (if ((b__0 == (0b00#2 : (BitVec 2))) : Bool)
    then (do (pure 32))
    else
      (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
          then (do (pure 64))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Int )
  let esize := esize
  let intsize :=
    if ((((BitVec.access op 1) : BitVec 1) == 0#1) : Bool)
    then 32
    else 64
  let rounding ← (( do
    (if ((((BitVec.access op 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure FPRounding_ZERO))
    else (do (FPRoundingMode (← (FPCR_read ()))))) ) : SailM FPRounding )
  (execute_aarch64_instrs_float_arithmetic_round_frint_32_64 d esize intsize n rounding)

def decode_frint64z_float_aarch64_instrs_float_arithmetic_round_frint_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 2)) (ftype : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveFrintExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 32
  let esize ← (( do
    let b__0 := ftype
    (if ((b__0 == (0b00#2 : (BitVec 2))) : Bool)
    then (do (pure 32))
    else
      (do (if ((b__0 == (0b01#2 : (BitVec 2))) : Bool)
          then (do (pure 64))
          else (do sailThrow ((Error_Undefined ())))))) ) : SailM Int )
  let esize := esize
  let intsize :=
    if ((((BitVec.access op 1) : BitVec 1) == 0#1) : Bool)
    then 32
    else 64
  let rounding ← (( do
    (if ((((BitVec.access op 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure FPRounding_ZERO))
    else (do (FPRoundingMode (← (FPCR_read ()))))) ) : SailM FPRounding )
  (execute_aarch64_instrs_float_arithmetic_round_frint_32_64 d esize intsize n rounding)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_exact : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_fp16_round (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (exact : Bool) (n : Nat) (rounding : FPRounding) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FPRoundInt element (← (FPCR_read ())) rounding exact)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_frinta_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frinti_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frintm_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frintn_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frintp_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frintx_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

def decode_frintz_advsimd_aarch64_instrs_vector_arithmetic_unary_float_round (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (sz : (BitVec 1)) (o2 : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := ((U +++ o1) +++ o2)
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (o1 +++ o2))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_vector_arithmetic_unary_fp16_round d datasize elements esize exact n rounding)

/-- Type quantifiers: d : Nat, esize : Nat, k_exact : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_float_arithmetic_round_frint (d : Nat) (esize : Nat) (exact : Bool) (n : Nat) (rounding : FPRounding) : SailM Unit := do
  (CheckFPEnabled64 ())
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (IsMerging fpcr) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let operand ← (( do (V_read n esize) ) : SailM (BitVec esize) )
  let result ← (Elem_set result 0 esize (← (FPRoundInt operand fpcr rounding exact)))
  (V_set d 128 result)

def decode_frinta_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frinti_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frintm_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frintn_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frintp_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frintx_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

def decode_frintz_float_aarch64_instrs_float_arithmetic_round_frint (Rd : (BitVec 5)) (Rn : (BitVec 5)) (rmode : (BitVec 3)) (ftype : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize : Int := 16
  let esize ← (( do
    match ftype with
    | 0b00 => (pure 32)
    | 0b01 => (pure 64)
    | 0b10 => sailThrow ((Error_Undefined ()))
    | _ =>
      (do
        (if ((HaveFP16Ext ()) : Bool)
        then (do (pure 16))
        else (do sailThrow ((Error_Undefined ()))))) ) : SailM Int )
  let esize := esize
  let exact : Bool := false
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let (exact, rounding) ← (( do
    let b__0 := rmode
    let (exact, rounding) ← (( do
      (if (((Sail.BitVec.extractLsb b__0 2 2) == (0#1 : (BitVec 1))) : Bool)
      then
        (do let rounding ← (FPDecodeRounding (Sail.BitVec.extractLsb rmode 1 0))
            (pure (exact, rounding)))
      else
        (do let (exact, rounding) ← (( do
              (if ((b__0 == (0b100#3 : (BitVec 3))) : Bool)
              then
                (do let rounding : FPRounding := FPRounding_TIEAWAY
                    (pure (exact, rounding)))
              else
                (do let (exact, rounding) ← (( do
                      (if ((b__0 == (0b101#3 : (BitVec 3))) : Bool)
                      then (do sailThrow ((Error_Undefined ())))
                      else
                        (do let (exact, rounding) ← (( do
                              (if ((b__0 == (0b110#3 : (BitVec 3))) : Bool)
                              then
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    let exact : Bool := true
                                    (pure (exact, rounding)))
                              else
                                (do let rounding ← (FPRoundingMode (← (FPCR_read ())))
                                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
                    (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
            (pure (exact, rounding)))) ) : SailM (Bool × FPRounding) )
    (pure (exact, rounding)) ) : SailM (Bool × FPRounding) )
  let rounding := rounding
  (execute_aarch64_instrs_float_arithmetic_round_frint d esize exact n rounding)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) : SailM Unit := do
  (if ((elements == 1) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read d 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e esize)
        let result ← (Elem_set result e esize (← (FPRSqrtEstimate element fpcr)))
        (pure (element, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_frsqrte_advsimd_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_float_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_fp16_sisd d datasize elements esize n)

def decode_frsqrte_advsimd_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_float_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_special_sqrt_est_fp16_sisd d datasize elements esize n)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_rsqrts_fp16_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (if ((elements == 1) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let merge ← (( do (pure (elements == 1)) <&&> (do (IsMerging fpcr)) ) : SailM Bool )
  let result ← (( do
    (if (merge : Bool)
    then (do (V_read n 128))
    else (do (pure (Zeros (n := 128))))) ) : SailM (BitVec 128) )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let result ← (Elem_set result e esize (← (FPRSqrtStepFused element1 element2)))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec 128)) )
  (V_set d 128 result)

def decode_frsqrts_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_rsqrts_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize := esize
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_rsqrts_fp16_sisd d datasize elements esize m n)

def decode_frsqrts_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_rsqrts_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_rsqrts_fp16_sisd d datasize elements esize m n)

/-- Type quantifiers: k_abs : Bool, d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp16_simd (abs : Bool) (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let element2 ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let diff ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let fpcr ← (( do (FPCR_read ()) ) : SailM FPCRType )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let (diff, element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (diff, element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (diff, element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (Elem_read operand1 e esize)
        let element2 ← (Elem_read operand2 e esize)
        let diff ← (FPSub element1 element2 fpcr)
        let result ←
          (Elem_set result e esize
            (← do
              (if (abs : Bool)
              then (do (FPAbs diff))
              else (do (pure diff)))))
        (pure (diff, element1, element2, result))
    (pure loop_vars) ) : SailM ((BitVec esize) × (BitVec esize) × (BitVec esize) × (BitVec datasize)) )
  (V_set d datasize result)

def decode_fsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (sz : (BitVec 1)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((sz +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 32 (BitVec.toNat sz))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let abs : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_fp16_simd abs d datasize elements esize m n)

/-- Type quantifiers: d : Nat, dst_index : Int, esize : Nat, idxdsize : Nat, n : Nat, src_index : Int, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_vector_insert (d : Nat) (dst_index : Int) (esize : Nat) (idxdsize : Nat) (n : Nat) (src_index : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (V_read d 128) ) : SailM (BitVec 128) )
  let result ← (Elem_set result dst_index esize (← (Elem_read operand src_index esize)))
  (V_set d 128 result)

def decode_ins_advsimd_elt_aarch64_instrs_vector_transfer_vector_insert (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm4 : (BitVec 4)) (imm5 : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21570.37-21570.38"
  let dst_index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  sail_assert (0 ≤b size) "sail-arm/arm-v9.4-a/src/instrs64.sail:21572.33-21572.34"
  let src_index := (BitVec.toNat (Sail.BitVec.extractLsb imm4 3 size))
  let idxdsize :=
    if ((((BitVec.access imm4 3) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 size)
  match esize with
  | 8 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 8 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 8 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:21586.28-21586.29")
  | 16 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 16 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 16 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:21599.28-21599.29")
  | 32 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 32 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 32 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:21612.28-21612.29")
  | 64 =>
    (do
      match idxdsize with
      | 64 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 64 64 n src_index)
      | 128 => (execute_aarch64_instrs_vector_transfer_vector_insert d dst_index 64 128 n src_index)
      | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:21625.28-21625.29")
  | _ => sail_assert false "sail-arm/arm-v9.4-a/src/instrs64.sail:21656.22-21656.23"

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64, 128, 256] ∧ datasize = 128 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_insert (d : Nat) (datasize : Nat) (esize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21676.48-21676.49"
  let element ← (( do (X_read n esize) ) : SailM (BitVec esize) )
  let result ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (Elem_set result index esize element)
  (V_set d datasize result)

def decode_ins_advsimd_gen_aarch64_instrs_vector_transfer_integer_insert (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size := (LowestSetBit imm5)
  (if ((size >b 3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (0 ≤b (size +i 1)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21692.37-21692.38"
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let esize := (_shl_int_general 8 size)
  let datasize := 128
  sail_assert ((((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) || (esize == 128)) || (esize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21696.58-21696.59"
  (execute_aarch64_instrs_vector_transfer_integer_insert d datasize esize index n)

def execute_aarch64_instrs_system_barriers_isb (_ : Unit) : SailM Unit := do
  (InstructionSynchronizationBarrier ())
  (if ((←((HaveBRBExt ()) <&&> (do
       (BRBEBranchOnISB ())))) : Bool)
  then (do (BRBEISB ()))
  else (do (pure ())))
  (if ((← (HaveStatisticalProfiling ())) : Bool)
  then (do (SPEISB ()))
  else (do (pure ())))

def decode_isb_aarch64_instrs_system_barriers_isb (opc : (BitVec 2)) (CRm : (BitVec 4)) : SailM Unit := do
  (execute_aarch64_instrs_system_barriers_isb ())

/-- Type quantifiers: datasize : Nat, esize : Nat, index : Int, m : Int, n : Nat, k_nontemporal : Bool, k_replicate : Bool, selem : Nat, t__arg : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t__arg ∧ t__arg ≤ 31 ∧ List.elem selem [1, 2, 3, 4] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_memory_vector_single_no_wb (datasize : Nat) (esize : Nat) (index : Int) (m : Int) (memop : MemOp) (n : Nat) (nontemporal : Bool) (replicate : Bool) (selem : Nat) (t__arg : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let t : Int := t__arg
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rval ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let element ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let ebytes := (Int.ediv esize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let offs : (BitVec 64) := (Zeros (n := 64))
  let offs ← (( do
    (if (replicate : Bool)
    then
      (do let (element, offs, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars_1 := (element, offs, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (element, offs, t) := loop_vars_1
              loop_vars_1 ← do
                let element ← (Mem_read (address + offs) ebytes accdesc)
                (V_set t datasize (BitVec.replicateBits element (Int.ediv datasize esize)))
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (element, offs, t))
            (pure loop_vars_1) ) : SailM ((BitVec esize) × (BitVec 64) × Int) )
          (pure offs))
    else
      (do let (offs, rval, t) ← (( do
            let loop_s_lower := 0
            let loop_s_upper := (selem -i 1)
            let mut loop_vars := (offs, rval, t)
            for s in [loop_s_lower:loop_s_upper:1]i do
              let (offs, rval, t) := loop_vars
              loop_vars ← do
                let rval ← (V_read t 128)
                let rval ← (( do
                  (if ((BEq.beq memop MemOp_LOAD) : Bool)
                  then
                    (do let rval ← (Elem_set rval index esize (← (Mem_read (address + offs) ebytes accdesc)))
                        (V_set t 128 rval)
                        (pure rval))
                  else
                    (do (Mem_set (address + offs) ebytes accdesc (← (Elem_read rval index esize)))
                        (pure rval))) ) : SailM (BitVec 128) )
                let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                let t : Int := (fmod_int (t +i 1) 32)
                (pure (offs, rval, t))
            (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 128) × Int) )
          (pure offs))) ) : SailM (BitVec 64) )
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))
  (if (wback : Bool)
  then
    (do let offs ← (( do
          (if ((m != 31) : Bool)
          then (do (X_read m 64))
          else (do (pure offs))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set (address + offs)))
        else (do (X_set n 64 (address + offs)))))
  else (do (pure ())))

def decode_ld1_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21891.48-21891.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:21961.48-21961.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22031.48-22031.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld1r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22101.48-22101.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22171.48-22171.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22241.48-22241.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22311.48-22311.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld2r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22381.48-22381.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22451.48-22451.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22521.48-22521.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22591.48-22591.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld3r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22661.48-22661.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22731.48-22731.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22801.48-22801.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22871.48-22871.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_ld4r_advsimd_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22941.48-22941.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)


end ArmASL.Functions
