import ArmASL.Part23

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def HFGITR2_EL2_SysRegWrite_41576daf42281ba5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x310#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGITR2_EL2 (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGITR2_EL2 (← (X_read t 64)))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HFGITR_EL2_SysRegWrite_11b3edecdb0dbac6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x1C8#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGITR_EL2 (Mk_HFGITR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGITR_EL2 (Mk_HFGITR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HFGRTR2_EL2_SysRegWrite_31d517272a11cc63 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x2C0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGRTR2_EL2 (Mk_HFGRTR2_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGRTR2_EL2 (Mk_HFGRTR2_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HFGRTR_EL2_SysRegWrite_fa73b98f16c9efee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x1B8#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGRTR_EL2 (Mk_HFGRTR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGRTR_EL2 (Mk_HFGRTR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HFGWTR2_EL2_SysRegWrite_9115a08ec76ef20a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x2C8#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGWTR2_EL2 (Mk_HFGWTR2_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGWTR2_EL2 (Mk_HFGWTR2_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HFGWTR_EL2_SysRegWrite_f913499e5a0813f2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x1C0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__SCR_EL3_FGTEn == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg HFGWTR_EL2 (Mk_HFGWTR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HFGWTR_EL2 (Mk_HFGWTR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HPFAR_EL2_SysRegWrite_cc86ce0a0fcde19a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg HPFAR_EL2 (Mk_HPFAR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HPFAR_EL2 (Mk_HPFAR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def HSTR_EL2_SysRegWrite_bdeca187ad74c419 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x080#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg HSTR_EL2 (Mk_HSTR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg HSTR_EL2 (Mk_HSTR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_AP0R_EL1_SysRegWrite_1d272226dc8d2255 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_AP0R_EL1_SysRegWrite_2e8737fdf3d4b8b5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_AP0R_EL1_SysRegWrite_7622c42003c1547b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL0 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do writeReg ICV_AP0R_EL1 (vectorUpdate (← readReg ICV_AP0R_EL1) 0 (← (X_read t 64))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg ICC_AP0R_EL1 (vectorUpdate (← readReg ICC_AP0R_EL1) 0 (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_AP0R_EL1 (vectorUpdate (← readReg ICC_AP0R_EL1) 0 (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_AP0R_EL1 (vectorUpdate (← readReg ICC_AP0R_EL1) 0 (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_AP0R_EL1_SysRegWrite_a8bec11c8e53045a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_AP1R_EL1_SysRegWrite_0d9519f401c9d3ae (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_AP1R_EL1_SysRegWrite_27852b8ac573cdcd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_AP1R_EL1_SysRegWrite_58ad13edd90bb69b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                then (do writeReg ICV_AP1R_EL1 (vectorUpdate (← readReg ICV_AP1R_EL1) 0 (Mk_ICV_AP1R_EL1_Type (← (X_read t 64)))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if ((HaveEL EL3) : Bool)
                                            then
                                              (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                                  then (do writeReg ICC_AP1R_EL1_S (vectorUpdate (← readReg ICC_AP1R_EL1_S) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg ICC_AP1R_EL1_NS (vectorUpdate (← readReg ICC_AP1R_EL1_NS) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))))
                                            else (do (ICC_AP1R_EL1_set 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((HaveEL EL3) : Bool)
                                      then
                                        (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                            then (do writeReg ICC_AP1R_EL1_S (vectorUpdate (← readReg ICC_AP1R_EL1_S) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg ICC_AP1R_EL1_NS (vectorUpdate (← readReg ICC_AP1R_EL1_NS) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))))
                                      else (do (ICC_AP1R_EL1_set 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                then (do writeReg ICC_AP1R_EL1_S (vectorUpdate (← readReg ICC_AP1R_EL1_S) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))
                                else (do writeReg ICC_AP1R_EL1_NS (vectorUpdate (← readReg ICC_AP1R_EL1_NS) 0 (Mk_ICC_AP1R_EL1_Type (← (X_read t 64)))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_AP1R_EL1_SysRegWrite_a8824fb00a7f4207 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICC_ASGI1R_EL1_SysRegWrite_588d10b57224783c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                 (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg ICC_ASGI1R_EL1 (Mk_ICC_ASGI1R_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_ASGI1R_EL1 (Mk_ICC_ASGI1R_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_ASGI1R_EL1 (Mk_ICC_ASGI1R_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_BPR0_EL1_SysRegWrite_4ea118667d9d50cd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL0 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do writeReg ICV_BPR0_EL1 (Mk_ICV_BPR0_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg ICC_BPR0_EL1 (Mk_ICC_BPR0_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_BPR0_EL1 (Mk_ICC_BPR0_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_BPR0_EL1 (Mk_ICC_BPR0_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_CTLR_EL1_SysRegWrite_6b2222909cfe4181 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do writeReg ICV_CTLR_EL1 (Mk_ICV_CTLR_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do writeReg ICV_CTLR_EL1 (Mk_ICV_CTLR_EL1_Type (← (X_read t 64))))
                                      else
                                        (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                 (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if ((HaveEL EL3) : Bool)
                                                  then
                                                    (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                                        then (do writeReg ICC_CTLR_EL1_S (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))
                                                        else (do writeReg ICC_CTLR_EL1_NS (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))))
                                                  else (do (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (← (X_read t 64)))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((HaveEL EL3) : Bool)
                                      then
                                        (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                            then (do writeReg ICC_CTLR_EL1_S (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))
                                            else (do writeReg ICC_CTLR_EL1_NS (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))))
                                      else (do (ICC_CTLR_EL1_write (Mk_ICC_CTLR_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                then (do writeReg ICC_CTLR_EL1_S (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))
                                else (do writeReg ICC_CTLR_EL1_NS (Mk_ICC_CTLR_EL1_Type (← (X_read t 64))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_CTLR_EL3_SysRegWrite_032d9412ecb7b900 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_CTLR_EL3 (Mk_ICC_CTLR_EL3_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_DIR_EL1_SysRegWrite_956e5112d301f88c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TDIR ← (( do (pure (_get_ICH_HCR_EL2_Type_TDIR (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TDIR == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                      then (do writeReg ICV_DIR_EL1 (Mk_ICV_DIR_EL1_Type (← (X_read t 64))))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                            then (do writeReg ICV_DIR_EL1 (Mk_ICV_DIR_EL1_Type (← (X_read t 64))))
                                            else
                                              (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                       (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                                  then
                                                    (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else (do writeReg ICC_DIR_EL1 (Mk_ICC_DIR_EL1_Type (← (X_read t 64))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_DIR_EL1 (Mk_ICC_DIR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_DIR_EL1 (Mk_ICC_DIR_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_IGRPEN0_EL1_SysRegWrite_dcea5bb07e468846 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_ICC_IGRPENn_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_ICC_IGRPENn_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_ICC_IGRPENn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL0 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                      then (do writeReg ICV_IGRPEN0_EL1 (Mk_ICV_IGRPEN0_EL1_Type (← (X_read t 64))))
                                      else
                                        (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg ICC_IGRPEN0_EL1 (Mk_ICC_IGRPEN0_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_IGRPEN0_EL1 (Mk_ICC_IGRPEN0_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_IGRPEN0_EL1 (Mk_ICC_IGRPEN0_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_IGRPEN1_EL1_SysRegWrite_a249f92f5cac95a3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_ICC_IGRPENn_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_ICC_IGRPENn_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_ICC_IGRPENn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL1 == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do writeReg ICV_IGRPEN1_EL1 (Mk_ICV_IGRPEN1_EL1_Type (← (X_read t 64))))
                                      else
                                        (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else
                                              (do (if ((HaveEL EL3) : Bool)
                                                  then
                                                    (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                                        then (do writeReg ICC_IGRPEN1_EL1_S (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))
                                                        else (do writeReg ICC_IGRPEN1_EL1_NS (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))))
                                                  else (do (ICC_IGRPEN1_EL1_write (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64)))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((HaveEL EL3) : Bool)
                                      then
                                        (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                            then (do writeReg ICC_IGRPEN1_EL1_S (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))
                                            else (do writeReg ICC_IGRPEN1_EL1_NS (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))))
                                      else (do (ICC_IGRPEN1_EL1_write (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                then (do writeReg ICC_IGRPEN1_EL1_S (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))
                                else (do writeReg ICC_IGRPEN1_EL1_NS (Mk_ICC_IGRPEN1_EL1_Type (← (X_read t 64))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_IGRPEN1_EL3_SysRegWrite_b957139b0969fa79 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_IGRPEN1_EL3 (Mk_ICC_IGRPEN1_EL3_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_PMR_EL1_SysRegWrite_4d3a3fb3d6e1e44e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do writeReg ICV_PMR_EL1 (Mk_ICV_PMR_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do writeReg ICV_PMR_EL1 (Mk_ICV_PMR_EL1_Type (← (X_read t 64))))
                                      else
                                        (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                 (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg ICC_PMR_EL1 (Mk_ICC_PMR_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_PMR_EL1 (Mk_ICC_PMR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_PMR_EL1 (Mk_ICC_PMR_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_SGI0R_EL1_SysRegWrite_97ea36eebda9c84c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                 (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg ICC_SGI0R_EL1 (Mk_ICC_SGI0R_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_SGI0R_EL1 (Mk_ICC_SGI0R_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_SGI0R_EL1 (Mk_ICC_SGI0R_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_SGI1R_EL1_SysRegWrite_bd688469b6075cd1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TC ← (( do (pure (_get_ICH_HCR_EL2_Type_TC (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TC == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                 (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                            then
                                              (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                                  then (do sailThrow ((Error_Undefined ())))
                                                  else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                            else (do writeReg ICC_SGI1R_EL1 (Mk_ICC_SGI1R_EL1_Type (← (X_read t 64))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                     (pure (((_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3)) +++ (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) == 0b11#2))))) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_SGI1R_EL1 (Mk_ICC_SGI1R_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_SGI1R_EL1 (Mk_ICC_SGI1R_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_SRE_EL1_SysRegWrite_b4fd95205f21b2e7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_Enable ← (( do (pure (_get_ICC_SRE_EL3_Type_Enable (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_Enable ← (( do (pure (_get_ICC_SRE_EL2_Type_Enable (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__ICC_SRE_EL2_Enable == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((HaveEL EL3) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((HaveEL EL3) : Bool)
                                then
                                  (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                      then (do writeReg ICC_SRE_EL1_S (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))
                                      else (do writeReg ICC_SRE_EL1_NS (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))))
                                else (do (ICC_SRE_EL1_write (Mk_ICC_SRE_EL1_Type (← (X_read t 64)))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((HaveEL EL3) : Bool)
                                then
                                  (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                      then (do writeReg ICC_SRE_EL1_S (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))
                                      else (do writeReg ICC_SRE_EL1_NS (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))))
                                else (do (ICC_SRE_EL1_write (Mk_ICC_SRE_EL1_Type (← (X_read t 64)))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                          then (do writeReg ICC_SRE_EL1_S (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))
                          else (do writeReg ICC_SRE_EL1_NS (Mk_ICC_SRE_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_SRE_EL2_SysRegWrite_84bc0d6cdc7c9072 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_Enable ← (( do (pure (_get_ICC_SRE_EL3_Type_Enable (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__ICC_SRE_EL3_Enable == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg ICC_SRE_EL2 (Mk_ICC_SRE_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((! (← (EL2Enabled ()))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else (do writeReg ICC_SRE_EL2 (Mk_ICC_SRE_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICC_SRE_EL3_SysRegWrite_b650b212ede313fc (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg ICC_SRE_EL3 (Mk_ICC_SRE_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_AP0R_EL2_SysRegWrite_1b21d2434fab897a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP0R_EL2_SysRegWrite_78fe7c56d4742066 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x480#12) +i (8 *i 0)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_AP0R_EL2 (vectorUpdate (← readReg ICH_AP0R_EL2) 0 (Mk_ICH_AP0R_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_AP0R_EL2 (vectorUpdate (← readReg ICH_AP0R_EL2) 0 (Mk_ICH_AP0R_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_AP0R_EL2_SysRegWrite_be89bf34888417e0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP0R_EL2_SysRegWrite_ed1ffcaf90ab8639 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP1R_EL2_SysRegWrite_20248cc458e10785 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP1R_EL2_SysRegWrite_9327d1291a4f4958 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP1R_EL2_SysRegWrite_b4a60e153456008a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  sailThrow ((Error_Undefined ()))

/-- Type quantifiers: t : Int -/
def ICH_AP1R_EL2_SysRegWrite_d831d83b4ca8a5a2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x4A0#12) +i (8 *i 0)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_AP1R_EL2 (vectorUpdate (← readReg ICH_AP1R_EL2) 0 (Mk_ICH_AP1R_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_AP1R_EL2 (vectorUpdate (← readReg ICH_AP1R_EL2) 0 (Mk_ICH_AP1R_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_HCR_EL2_SysRegWrite_d09a9dfdfbf35716 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x4C0#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_HCR_EL2 (Mk_ICH_HCR_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_HCR_EL2 (Mk_ICH_HCR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_1726583f5c5d911a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 7)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 7 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 7 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_377d2c4427bc7a74 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 11)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 11 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 11 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_3b6fa0a247977dad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 14)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 14 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 14 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_3b8d5d6ae4931c55 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 9)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 9 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 9 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_3ca439f034b85455 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 3)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 3 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 3 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_60f29686bdc4ef5f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 4)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 4 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 4 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_7f74a03659a9be73 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 13)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 13 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 13 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_8674efc2931dff61 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 5)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 5 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 5 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_88b3b2552632aea7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 1)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 1 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 1 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_899098384db50f2b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 6)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 6 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 6 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_8e2173d5288ec9f6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 0)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 0 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 0 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_ada04edc200eb7de (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 12)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 12 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 12 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_af9b8f005bb45cf2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 15)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 15 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 15 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_ce3f5174c2a18c3b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 2)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 2 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 2 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_d4cc97ca4abc2b38 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 8)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 8 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 8 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_LR_EL2_SysRegWrite_fd7b4774b600f5ba (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set ((BitVec.toNat 0x400#12) +i (8 *i 10)) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 10 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_LR_EL2 (vectorUpdate (← readReg ICH_LR_EL2) 10 (Mk_ICH_LR_EL2_Type (← (X_read t 64)))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICH_VMCR_EL2_SysRegWrite_dff88313df61ad5f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) == 0b11#2))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x4C8#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do writeReg ICH_VMCR_EL2 (Mk_ICH_VMCR_EL2_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICH_VMCR_EL2 (Mk_ICH_VMCR_EL2_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICV_BPR1_EL1_SysRegWrite_cf350ee97c59e5e0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_NS ← (( do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                then (do writeReg ICV_BPR1_EL1 (Mk_ICV_BPR1_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if ((HaveEL EL3) : Bool)
                                            then
                                              (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                                  then (do writeReg ICC_BPR1_EL1_S (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))
                                                  else (do writeReg ICC_BPR1_EL1_NS (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))))
                                            else (do (ICC_BPR1_EL1_write (Mk_ICC_BPR1_EL1_Type (← (X_read t 64)))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((HaveEL EL3) : Bool)
                                      then
                                        (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                            then (do writeReg ICC_BPR1_EL1_S (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))
                                            else (do writeReg ICC_BPR1_EL1_NS (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))))
                                      else (do (ICC_BPR1_EL1_write (Mk_ICC_BPR1_EL1_Type (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((__SCR_EL3_NS == 0#1) : Bool)
                                then (do writeReg ICC_BPR1_EL1_S (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))
                                else (do writeReg ICC_BPR1_EL1_NS (Mk_ICC_BPR1_EL1_Type (← (X_read t 64))))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICV_EOIR0_EL1_SysRegWrite_4d99677932f49dc7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FIQ ← (( do (pure (_get_SCR_EL3_Type_FIQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL0 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL0 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_FMO ← (( do (pure (_get_HCR_EL2_Type_FMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL0 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_FMO == 1#1)) : Bool)
                                then (do writeReg ICV_EOIR0_EL1 (Mk_ICV_EOIR0_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg ICC_EOIR0_EL1 (Mk_ICC_EOIR0_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_FIQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_EOIR0_EL1 (Mk_ICC_EOIR0_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_EOIR0_EL1 (Mk_ICC_EOIR0_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def ICV_EOIR1_EL1_SysRegWrite_a2fbace49f2a9362 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __SCR_EL3_IRQ ← (( do (pure (_get_SCR_EL3_Type_IRQ (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL1_SRE ← (( do (pure (_get_ICC_SRE_EL1_Type_SRE (← (ICC_SRE_EL1_read ())))) ) : SailM (BitVec 1) )
  let __ICH_HCR_EL2_TALL1 ← (( do (pure (_get_ICH_HCR_EL2_Type_TALL1 (← readReg ICH_HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_IMO ← (( do (pure (_get_HCR_EL2_Type_IMO (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL2_SRE ← (( do (pure (_get_ICC_SRE_EL2_Type_SRE (← readReg ICC_SRE_EL2))) ) : SailM (BitVec 1) )
  let __ICC_SRE_EL3_SRE ← (( do (pure (_get_ICC_SRE_EL3_Type_SRE (← readReg ICC_SRE_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__ICC_SRE_EL1_SRE == 0#1) : Bool)
                    then (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((← (EL2Enabled ())) && (__ICH_HCR_EL2_TALL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_IMO == 1#1)) : Bool)
                                then (do writeReg ICV_EOIR1_EL1 (Mk_ICV_EOIR1_EL1_Type (← (X_read t 64))))
                                else
                                  (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do writeReg ICC_EOIR1_EL1 (Mk_ICC_EOIR1_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((__ICC_SRE_EL2_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__SCR_EL3_IRQ == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg ICC_EOIR1_EL1 (Mk_ICC_EOIR1_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if ((__ICC_SRE_EL3_SRE == 0#1) : Bool)
                          then (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))
                          else (do writeReg ICC_EOIR1_EL1 (Mk_ICC_EOIR1_EL1_Type (← (X_read t 64))))))
                    else (do (pure ())))))))))


end ArmASL.Functions
