import Sail
import ArmASL.Defs

namespace ArmASL

/- JanusASL: Sail's `real` as an exact rational (Lean core `Rat`), not `Float`.
   The upstream file used `Float`: ASL computes SDIV/UDIV as RoundTowardsZero(Real(a) / Real(b)),
   which a 53-bit mantissa gets wrong for 64-bit operands, and `round_down` was
   `x.toUInt64.toNat`, which maps every negative value to 0. `sqrt_real` is the round-to-odd
   approximation below (JanusASL/sail/fakereal_sqrt.py). -/
abbrev real := Rat

-- val "neg_real" : real -> real
def neg_real (x : real) : real := -x

-- val "mult_real" : (real, real) -> real
def mult_real (x y : real) : real := x * y

-- val "sub_real" : (real, real) -> real
def sub_real (x y : real) : real := x - y

-- val "add_real" : (real, real) -> real
def add_real (x y : real) : real := x + y

-- val "div_real" : (real, real) -> real
def div_real (x y : real) : real := x / y

-- val sqrt = pure "sqrt_real" : real -> real
-- JanusASL (JanusASL/sail/fakereal_sqrt.py): round-to-odd at absolute precision 2^-1100, so
-- that FPRound of it equals FPRound of the exact square root for binary16/32/64.
def sqrt_real (x : real) : real :=
  if x ≤ 0 then 0 else
  let k : Nat := 1100
  let y : Nat := (x.num.toNat * 4 ^ k) / x.den
  let m : Nat := Nat.sqrt y
  if m * m * x.den = x.num.toNat * 4 ^ k then (m : Rat) / (2 ^ k : Nat)
  else ((2 * m + 1 : Nat) : Rat) / (2 ^ (k + 1) : Nat)

-- val "abs_real" : real -> real
def abs_real (x : real) : real := if x < 0 then -x else x

-- val floor = pure "round_down" : real -> int
def round_down (x : real) : Int := x.floor

-- val ceil = pure "round_up" : real -> int
def round_up (x : real) : Int := x.ceil

-- val "to_real" : int -> real
def to_real (x : Int) : real := Rat.ofInt x

-- val "eq_real" : (real, real) -> bool
def eq_real (x y : real) : Bool := x == y

-- val "lt_real" : (real, real) -> bool
def lt_real (x y : real) : Bool := decide (x < y)

-- val "gt_real" : (real, real) -> bool
def gt_real (x y : real) : Bool := decide (x > y)

-- val "lteq_real" : (real, real) -> bool
def lteq_real (x y : real) : Bool := decide (x ≤ y)

-- val "gteq_real" : (real, real) -> bool
def gteq_real (x y : real) : Bool := decide (x ≥ y)

-- val pow_real = pure "real_power" : (real, int) -> real
def real_power (x : real) (n : Int) : real := x ^ n

-- val "print_real" : (string, real) -> unit
def print_real (_ : String) (_ : real) : Unit := ()

-- val "prerr_real" : (string, real) -> unit
def prerr_real (_ : String) (_ : real) : Unit := ()

-- val "random_real" : unit -> real
def random_real (_ : Unit) : real := 34

def undefined_real (_ : Unit) : SailM real := return default
