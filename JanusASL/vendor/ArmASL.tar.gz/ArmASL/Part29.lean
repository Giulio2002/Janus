import ArmASL.Part28

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_shl_advsimd_aarch64_instrs_vector_shift_left_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  (execute_aarch64_instrs_vector_shift_left_sisd d datasize elements esize n shift)

def decode_shl_advsimd_aarch64_instrs_vector_shift_left_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  (execute_aarch64_instrs_vector_shift_left_sisd d datasize elements esize n shift)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, shift : Nat, List.elem shift [8, 16, 32, 64] ∧ List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_shift (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (shift : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let (element, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result) := loop_vars
      loop_vars ← do
        let element ← (( (pure (Int.shiftl (← (asl_Int (← (Elem_read operand e esize)) is_unsigned)) shift)) ) : SailM Int )
        let result ← (Elem_set result e (2 *i esize) (integer_subrange element ((2 *i esize) -i 1) 0))
        (pure (element, result))
    (pure loop_vars) ) : SailM (Int × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_shll_advsimd_aarch64_instrs_vector_arithmetic_unary_shift (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let shift := esize
  let is_unsigned : Bool := false
  (execute_aarch64_instrs_vector_arithmetic_unary_shift d datasize elements esize n part shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_int (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let diff ← (( do (undefined_int ()) ) : SailM Int )
  let (diff, element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (diff, element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (diff, element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let diff : Int := (Int.shiftr (element1 -i element2) 1)
        let result ← (Elem_set result e esize (integer_subrange diff (esize -i 1) 0))
        (pure (diff, element1, element2, result))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_shsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_int d datasize elements esize m n is_unsigned)

def decode_uhsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_int (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_int d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Int, elements : Int, esize : Int, n : Nat, shift : Int, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_insert_sisd (d : Nat) (datasize : Int) (elements : Int) (esize : Int) (n : Nat) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:43026.56-43026.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read d datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  sail_assert (esize ≥b 0) "sail-arm/arm-v9.4-a/src/instrs64.sail:43030.34-43030.35"
  let mask : (BitVec esize) := ((Ones (n := esize)) <<< shift)
  let shifted ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  let (result, shifted) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (result, shifted)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (result, shifted) := loop_vars
      loop_vars ← do
        sail_assert (((e *i esize) ≤b (((e *i esize) +i esize) -i 1)) || ((! ((e ≥b 0) && (((e +i 1) *i esize) ≤b datasize))) || ((! (esize ≥b 0)) || (! (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)))))) "sail-arm/arm-v9.4-a/src/instrs64.sail:43034.198-43034.199"
        let shifted ← (pure ((← (Elem_read operand e esize)) <<< shift))
        let result ← (Elem_set result e esize (((← (Elem_read operand2 e esize)) &&& (Complement.complement mask)) ||| shifted))
        (pure (result, shifted))
    (pure loop_vars) ) : SailM ((BitVec datasize) × (BitVec esize)) )
  (V_set d datasize result)

def decode_sli_advsimd_aarch64_instrs_vector_shift_left_insert_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((((BitVec.access immh 3) : BitVec 1) != 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 3)
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  (execute_aarch64_instrs_vector_shift_left_insert_sisd d datasize elements esize n shift)

def decode_sli_advsimd_aarch64_instrs_vector_shift_left_insert_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  (execute_aarch64_instrs_vector_shift_left_insert_sisd d datasize elements esize n shift)

/-- Type quantifiers: a : Nat, d : Nat, datasize : Nat, destsize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, k_sub_op : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ destsize = 64 ∧ datasize = 32 ∧ 0 ≤ d ∧ d ≤ 31 ∧ 0 ≤ a ∧ a ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_mul_widening_32_64 (a : Nat) (d : Nat) (datasize : Nat) (destsize : Nat) (m : Nat) (n : Nat) (sub_op : Bool) (is_unsigned : Bool) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (X_read a destsize) ) : SailM (BitVec destsize) )
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result ← (( do
    (if (sub_op : Bool)
    then (do (pure ((← (asl_Int operand3 is_unsigned)) -i ((← (asl_Int operand1 is_unsigned)) *i (← (asl_Int operand2 is_unsigned))))))
    else (do (pure ((← (asl_Int operand3 is_unsigned)) +i ((← (asl_Int operand1 is_unsigned)) *i (← (asl_Int operand2 is_unsigned))))))) ) : SailM Int )
  let result := result
  (X_set d 64 (integer_subrange result 63 0))

def decode_smaddl_aarch64_instrs_integer_arithmetic_mul_widening_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := 32
  let sub_op : Bool := (o0 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_32_64 a d datasize destsize m n sub_op is_unsigned)

def decode_smsubl_aarch64_instrs_integer_arithmetic_mul_widening_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := 32
  let sub_op : Bool := (o0 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_32_64 a d datasize destsize m n sub_op is_unsigned)

def decode_umaddl_aarch64_instrs_integer_arithmetic_mul_widening_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := 32
  let sub_op : Bool := (o0 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_32_64 a d datasize destsize m n sub_op is_unsigned)

def decode_umsubl_aarch64_instrs_integer_arithmetic_mul_widening_32_64 (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (o0 : (BitVec 1)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := 32
  let sub_op : Bool := (o0 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_32_64 a d datasize destsize m n sub_op is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, k_minimum : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (minimum : Bool) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let maxmin ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, maxmin, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, maxmin, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, maxmin, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let maxmin : Int :=
          if (minimum : Bool)
          then (Min.min element1 element2)
          else (Max.max element1 element2)
        let result ← (Elem_set result e esize (integer_subrange maxmin (esize -i 1) 0))
        (pure (element1, element2, maxmin, result))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_smax_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single d datasize elements esize m minimum n is_unsigned)

def decode_smin_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single d datasize elements esize m minimum n is_unsigned)

def decode_umax_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single d datasize elements esize m minimum n is_unsigned)

def decode_umin_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_single d datasize elements esize m minimum n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, k_minimum : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (minimum : Bool) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let concat : (BitVec (2 * datasize)) := (operand2 +++ operand1)
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let maxmin ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, maxmin, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, maxmin, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, maxmin, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read concat (2 *i e) esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read concat ((2 *i e) +i 1) esize)) is_unsigned) ) : SailM Int )
        let maxmin : Int :=
          if (minimum : Bool)
          then (Min.min element1 element2)
          else (Max.max element1 element2)
        let result ← (Elem_set result e esize (integer_subrange maxmin (esize -i 1) 0))
        (pure (element1, element2, maxmin, result))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize)) )
  (V_set d datasize result)

def decode_smaxp_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair d datasize elements esize m minimum n is_unsigned)

def decode_sminp_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair d datasize elements esize m minimum n is_unsigned)

def decode_umaxp_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair d datasize elements esize m minimum n is_unsigned)

def decode_uminp_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let minimum : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_max_min_pair d datasize elements esize m minimum n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, k_min : Bool, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_reduce_int_max (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (min : Bool) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let maxmin ← (( do (asl_Int (← (Elem_read operand 0 esize)) is_unsigned) ) : SailM Int )
  let (element, maxmin) ← (( do
    let loop_e_lower := 1
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, maxmin)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, maxmin) := loop_vars
      loop_vars ← do
        let element ← (( (asl_Int (← (Elem_read operand e esize)) is_unsigned) ) : SailM Int )
        let maxmin : Int :=
          if (min : Bool)
          then (Min.min maxmin element)
          else (Max.max maxmin element)
        (pure (element, maxmin))
    (pure loop_vars) ) : SailM (Int × Int) )
  let maxmin := maxmin
  (V_set d esize (integer_subrange maxmin (esize -i 1) 0))

def decode_smaxv_advsimd_aarch64_instrs_vector_reduce_int_max (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let min : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_reduce_int_max d datasize elements esize min n is_unsigned)

def decode_sminv_advsimd_aarch64_instrs_vector_reduce_int_max (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let min : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_reduce_int_max d datasize elements esize min n is_unsigned)

def decode_umaxv_advsimd_aarch64_instrs_vector_reduce_int_max (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let min : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_reduce_int_max d datasize elements esize min n is_unsigned)

def decode_uminv_advsimd_aarch64_instrs_vector_reduce_int_max (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b100#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let min : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_reduce_int_max d datasize elements esize min n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let accum ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let (accum, element1, element2, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, element2, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, element2, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let product : (BitVec (2 * esize)) := (integer_subrange (element1 *i element2) ((2 *i esize) -i 1) 0)
        let accum ← (( do
          (if (sub_op : Bool)
          then (do (pure ((← (Elem_read operand3 e (2 *i esize))) - product)))
          else (do (pure ((← (Elem_read operand3 e (2 *i esize))) + product)))) ) : SailM (BitVec (2 * esize)) )
        let result ← (Elem_set result e (2 *i esize) accum)
        (pure (accum, element1, element2, product, result))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_smlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum d datasize elements esize m n part sub_op is_unsigned)

def decode_smlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum d datasize elements esize m n part sub_op is_unsigned)

def decode_umlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum d datasize elements esize m n part sub_op is_unsigned)

def decode_umlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_accum d datasize elements esize m n part sub_op is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let operand3 ← (( do (V_read d (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let element2 ← (( do (asl_Int (← (Elem_read operand2 index esize)) is_unsigned) ) : SailM Int )
  let (element1, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let product : (BitVec (2 * esize)) := (integer_subrange (element1 *i element2) ((2 *i esize) -i 1) 0)
        let result ← (( do
          (if (sub_op : Bool)
          then (do (Elem_set result e (2 *i esize) ((← (Elem_read operand3 e (2 *i esize))) - product)))
          else (do (Elem_set result e (2 *i esize) ((← (Elem_read operand3 e (2 *i esize))) + product)))) ) : SailM (BitVec (2 * datasize)) )
        (pure (element1, product, result))
    (pure loop_vars) ) : SailM (Int × (BitVec (2 * esize)) × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_smlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long d datasize elements esize idxdsize index m n part sub_op is_unsigned)

def decode_smlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long d datasize elements esize idxdsize index m n part sub_op is_unsigned)

def decode_umlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long d datasize elements esize idxdsize index m n part sub_op is_unsigned)

def decode_umlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_long d datasize elements esize idxdsize index m n part sub_op is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, esize : Nat, idxdsize : Nat, index : Int, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32] ∧ List.elem datasize [32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_transfer_integer_move_signed (d : Nat) (datasize : Nat) (esize : Nat) (idxdsize : Nat) (index : Int) (n : Nat) : SailM Unit := do
  (if ((index == 0) : Bool)
  then (do (CheckFPEnabled64 ()))
  else (do (CheckFPAdvSIMDEnabled64 ())))
  let operand ← (( do (V_read n idxdsize) ) : SailM (BitVec idxdsize) )
  (X_set d datasize (sign_extend (← (Elem_read operand index esize)) datasize))

def decode_smov_advsimd_aarch64_instrs_vector_transfer_integer_move_signed (Rd : (BitVec 5)) (Rn : (BitVec 5)) (imm5 : (BitVec 5)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let size : Int := 0
  let size ← (( do
    let b__0 := (Q +++ imm5)
    (if (((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1))) : Bool)
    then (do (pure 0))
    else
      (do (if (((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2))) : Bool)
          then (do (pure 1))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 5 5) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 2 0) == (0b100#3 : (BitVec 3)))) : Bool)
                then (do (pure 2))
                else (do sailThrow ((Error_Undefined ())))))))) ) : SailM Int )
  let size := size
  let idxdsize :=
    if ((((BitVec.access imm5 4) : BitVec 1) == 1#1) : Bool)
    then 128
    else 64
  let index := (BitVec.toNat (Sail.BitVec.extractLsb imm5 4 (size +i 1)))
  let esize := (Int.shiftl 8 size)
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 64
    else 32
  sail_assert (((esize == 8) || (esize == 16)) || (esize == 32)) "sail-arm/arm-v9.4-a/src/instrs64.sail:44633.44-44633.45"
  (execute_aarch64_instrs_vector_transfer_integer_move_signed d datasize esize idxdsize index n)

/-- Type quantifiers: d : Nat, datasize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_integer_arithmetic_mul_widening_64_128hi (d : Nat) (datasize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  let operand1 ← (( do (X_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (X_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (pure ((← (asl_Int operand1 is_unsigned)) *i (← (asl_Int operand2 is_unsigned)))) ) : SailM Int )
  (X_set d 64 (integer_subrange result 127 64))

def decode_smulh_aarch64_instrs_integer_arithmetic_mul_widening_64_128hi (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := destsize
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_64_128hi d datasize m n is_unsigned)

def decode_umulh_aarch64_instrs_integer_arithmetic_mul_widening_64_128hi (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Ra : (BitVec 5)) (Rm : (BitVec 5)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let a := (BitVec.toNat Ra)
  let destsize := 64
  let datasize := destsize
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_integer_arithmetic_mul_widening_64_128hi d datasize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_product (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let result ← (Elem_set result e (2 *i esize) (integer_subrange (element1 *i element2) ((2 *i esize) -i 1) 0))
        (pure (element1, element2, result))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_smull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_product d datasize elements esize m n part is_unsigned)

def decode_umull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_product (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_product d datasize elements esize m n part is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ datasize = 64 ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_long (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (part : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let element2 ← (( do (asl_Int (← (Elem_read operand2 index esize)) is_unsigned) ) : SailM Int )
  let (element1, product, result) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let product : (BitVec (2 * esize)) := (integer_subrange (element1 *i element2) ((2 *i esize) -i 1) 0)
        let result ← (Elem_set result e (2 *i esize) product)
        (pure (element1, product, result))
    (pure loop_vars) ) : SailM (Int × (BitVec (2 * esize)) × (BitVec (2 * datasize))) )
  (V_set d (2 *i datasize) result)

def decode_smull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_long d datasize elements esize idxdsize index m n part is_unsigned)

def decode_umull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_long (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_long d datasize elements esize idxdsize index m n part is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, k_neg : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (neg : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (pure (BitVec.toInt (← (Elem_read operand e esize)))) ) : SailM Int )
        let element : Int :=
          if (neg : Bool)
          then (Neg.neg element)
          else (Int.natAbs element)
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ element esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqabs_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd d datasize elements esize n neg)

def decode_sqabs_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd d datasize elements esize n neg)

def decode_sqneg_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd d datasize elements esize n neg)

def decode_sqneg_advsimd_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let neg : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_diff_neg_sat_sisd d datasize elements esize n neg)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, result, sat, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sat, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sat, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int := (element1 +i element2)
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ sum esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, element2, result, sat, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool × Int) )
  (V_set d datasize result)

def decode_sqadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_sqadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqadd_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_saturating_sisd d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let operand3 ← (( do (V_read d (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let accum ← (( do (undefined_int ()) ) : SailM Int )
  let sat1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let sat2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (accum, element1, product, result, sat1, sat2) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, product, result, sat1, sat2)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, product, result, sat1, sat2) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let (product, sat1) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat1 : Bool := tup__1
          (pure (product, sat1)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let accum ← (( do
          (if (sub_op : Bool)
          then (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) -i (BitVec.toInt product))))
          else (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) +i (BitVec.toInt product))))) ) : SailM Int )
        let (result, sat2) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ accum (2 *i esize))
          let result ← (Elem_set result e (2 *i esize) __tup_0)
          let sat2 : Bool := __tup_1
          (pure (result, sat2)) ) : SailM ((BitVec (2 * datasize)) × Bool) )
        (if ((sat1 || sat2) : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (accum, element1, product, result, sat1, sat2))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlal_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

def decode_sqdmlsl_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (o2 : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o2 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_acc_double_sisd d datasize elements esize idxdsize index m n part sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, k_sub_op : Bool, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) (sub_op : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let operand3 ← (( do (V_read d (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let accum ← (( do (undefined_int ()) ) : SailM Int )
  let sat1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let sat2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (accum, element1, element2, product, result, sat1, sat2) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (accum, element1, element2, product, result, sat1, sat2)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (accum, element1, element2, product, result, sat1, sat2) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let (product, sat1) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat1 : Bool := tup__1
          (pure (product, sat1)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let accum ← (( do
          (if (sub_op : Bool)
          then (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) -i (BitVec.toInt product))))
          else (do (pure ((BitVec.toInt (← (Elem_read operand3 e (2 *i esize)))) +i (BitVec.toInt product))))) ) : SailM Int )
        let (result, sat2) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ accum (2 *i esize))
          let result ← (Elem_set result e (2 *i esize) __tup_0)
          let sat2 : Bool := __tup_1
          (pure (result, sat2)) ) : SailM ((BitVec (2 * datasize)) × Bool) )
        (if ((sat1 || sat2) : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (accum, element1, element2, product, result, sat1, sat2))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlal_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

def decode_sqdmlsl_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (o1 : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let sub_op : Bool := (o1 == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_dmacc_sisd d datasize elements esize m n part sub_op)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, k_rounding : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rounding : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let product : Int := ((2 *i element1) *i element2)
        let product ← (( (RShr product esize rounding) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ product esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, element2, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqrdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

def decode_sqrdmulh_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b11#2) || (size == 0b00#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let rounding : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_mul_int_doubling_sisd d datasize elements esize m n rounding)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, k_round : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (round : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let product : Int := ((2 *i element1) *i element2)
        let product ← (( (RShr product esize round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SignedSatQ product esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqrdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

def decode_sqrdmulh_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_high_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (op : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let round : Bool := (op == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_high_sisd d datasize elements esize idxdsize index m n round)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (Vpart_read m part datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element1, element2, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let element2 ← (( (pure (BitVec.toInt (← (Elem_read operand2 e esize)))) ) : SailM Int )
        let (product, sat) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat : Bool := tup__1
          (pure (product, sat)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let result ← (Elem_set result e (2 *i esize) product)
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, element2, product, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd d datasize elements esize m n part)

def decode_sqdmull_advsimd_vec_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size == 0b00#2) || (size == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_disparate_mul_double_sisd d datasize elements esize m n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, idxdsize : Nat, index : Nat, m : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem index [0, 1, 2, 3, 4, 5, 6, 7] ∧ List.elem idxdsize [64, 128] ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (idxdsize : Nat) (index : Nat) (m : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (Vpart_read n part datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m idxdsize) ) : SailM (BitVec idxdsize) )
  let result ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let product ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let element2 ← (( do (pure (BitVec.toInt (← (Elem_read operand2 index esize)))) ) : SailM Int )
  let (element1, product, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, product, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, product, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (pure (BitVec.toInt (← (Elem_read operand1 e esize)))) ) : SailM Int )
        let (product, sat) ← (( do
          let (tup__0, tup__1) ← do (SignedSatQ ((2 *i element1) *i element2) (2 *i esize))
          let product : (BitVec (2 * esize)) := tup__0
          let sat : Bool := tup__1
          (pure (product, sat)) ) : SailM ((BitVec (2 * esize)) × Bool) )
        let result ← (Elem_set result e (2 *i esize) product)
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element1, product, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec (2 * esize)) × (BitVec (2 * datasize)) × Bool) )
  (V_set d (2 *i datasize) result)

def decode_sqdmull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let part := 0
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd d datasize elements esize idxdsize index m n part)

def decode_sqdmull_advsimd_elt_aarch64_instrs_vector_arithmetic_binary_element_mul_double_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (H : (BitVec 1)) (Rm : (BitVec 4)) (M : (BitVec 1)) (L : (BitVec 1)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let idxdsize :=
    if ((H == 1#1) : Bool)
    then 128
    else 64
  let index ← (( do (undefined_range 0 7) ) : SailM Nat )
  let Rmhi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (Rmhi, index) ← (( do
    match size with
    | 0b01 =>
      (let index : Nat := (BitVec.toNat ((H +++ L) +++ M))
      let Rmhi : (BitVec 1) := 0#1
      (pure (Rmhi, index)))
    | 0b10 =>
      (let index : Nat := (BitVec.toNat (H +++ L))
      let Rmhi : (BitVec 1) := M
      (pure (Rmhi, index)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM ((BitVec 1) × Nat) )
  let Rmhi := Rmhi
  let index := index
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat (Rmhi +++ Rm))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_binary_element_mul_double_sisd d datasize elements esize idxdsize index m n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, k_rounding : Bool, k_saturating : Bool, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (rounding : Bool) (saturating : Bool) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (result, sat) := loop_vars
      loop_vars ← do
        let element ← (( do (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let shift ← (( do (pure (BitVec.toInt (Sail.BitVec.extractLsb (← (Elem_read operand2 e esize)) 7 0))) ) : SailM Int )
        let element ← (( do
          (if ((shift ≥b 0) : Bool)
          then (do (pure (_shl_int_general element shift)))
          else
            (do let shift := (Neg.neg shift)
                (RShr element shift rounding))) ) : SailM Int )
        let element := element
        let (result, sat) ← (( do
          (if (saturating : Bool)
          then
            (do let (result, sat) ← (( do
                  let (__tup_0, __tup_1) ← do (SatQ element esize is_unsigned)
                  let result ← (Elem_set result e esize __tup_0)
                  let sat : Bool := __tup_1
                  (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
                (if (sat : Bool)
                then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
                else (do (pure ())))
                (pure (result, sat)))
          else
            (do let result ← (Elem_set result e esize (integer_subrange element (esize -i 1) 0))
                (pure (result, sat)))) ) : SailM ((BitVec datasize) × Bool) )
        (pure (result, sat))
    (pure loop_vars) ) : SailM ((BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_srshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_srshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_sshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqrshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_uqshl_advsimd_reg_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_urshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_urshl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_ushl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (if (((S == 0#1) && (size != 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

def decode_ushl_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_shift_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (S : (BitVec 1)) (R : (BitVec 1)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  let rounding : Bool := (R == 1#1)
  let saturating : Bool := (S == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_shift_sisd d datasize elements esize m n rounding saturating is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (← (asl_Int (← (Elem_read operand e (2 *i esize))) is_unsigned)) shift round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ element esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:46972.87-46972.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47005.51-47005.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47039.87-47039.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_sqshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47072.51-47072.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47106.87-47106.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

def decode_uqrshrn_advsimd_aarch64_instrs_vector_shift_right_narrow_uniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  let is_unsigned : Bool := (U == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47139.51-47139.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_uniform_sisd d datasize elements esize n part round shift is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, k_round : Bool, shift : Int, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (round : Bool) (shift : Int) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (datasize *i 2)) ) : SailM (BitVec (datasize * 2)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (RShr (BitVec.toInt (← (Elem_read operand e (2 *i esize)))) shift round) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (UnsignedSatQ element esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqrshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47253.87-47253.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqrshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47284.51-47284.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let part := 0
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && (((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47316.87-47316.88"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

def decode_sqshrun_advsimd_aarch64_instrs_vector_shift_right_narrow_nonuniform_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if ((((BitVec.access immh 3) : BitVec 1) == 1#1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (fdiv_int datasize esize)
  let shift := ((2 *i esize) -i (BitVec.toNat (immh +++ immb)))
  let round : Bool := (op == 1#1)
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47347.51-47347.52"
  (execute_aarch64_instrs_vector_shift_right_narrow_nonuniform_sisd d datasize elements esize n part round shift)

/-- Type quantifiers: d : Nat, datasize : Nat, k_dst_unsigned : Bool, elements : Int, esize : Nat, n : Nat, shift : Int, k_src_unsigned : Bool, 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [4, 8, 16, 32, 64] ∧ List.elem datasize [4, 8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_shift_left_sat_sisd (d : Nat) (datasize : Nat) (dst_unsigned : Bool) (elements : Int) (esize : Nat) (n : Nat) (shift : Int) (src_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47368.56-47368.57"
  let operand ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (( (pure (_shl_int_general (← (asl_Int (← (Elem_read operand e esize)) src_unsigned)) shift)) ) : SailM Int )
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ element esize dst_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM (Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47423.92-47423.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47474.51-47474.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshlu_advsimd_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47523.92-47523.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_sqshlu_advsimd_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47574.51-47574.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_uqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize := esize
  let elements := 1
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert ((((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) && ((((((datasize == 4) || (datasize == 8)) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128))) "sail-arm/arm-v9.4-a/src/instrs64.sail:47623.92-47623.93"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

def decode_uqshl_advsimd_imm_aarch64_instrs_vector_shift_left_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (op : (BitVec 1)) (immb : (BitVec 3)) (immh : (BitVec 4)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((immh == 0b0000#4) : Bool)
  then (do sailThrow ((Error_See "asimdimm")))
  else (do (pure ())))
  (if (((((BitVec.access immh 3) : BitVec 1) +++ Q) == 0b10#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (_shl_int_general 8 (HighestSetBit immh))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (fdiv_int datasize esize)
  let shift := ((BitVec.toNat (immh +++ immb)) -i esize)
  let src_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let dst_unsigned ← (( do (undefined_bool ()) ) : SailM Bool )
  let (dst_unsigned, src_unsigned) ← (( do
    match (op +++ U) with
    | 0b00 => sailThrow ((Error_Undefined ()))
    | 0b01 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned)))
    | 0b10 =>
      (let src_unsigned : Bool := false
      let dst_unsigned : Bool := false
      (pure (dst_unsigned, src_unsigned)))
    | _ =>
      (let src_unsigned : Bool := true
      let dst_unsigned : Bool := true
      (pure (dst_unsigned, src_unsigned))) ) : SailM (Bool × Bool) )
  let dst_unsigned := dst_unsigned
  let src_unsigned := src_unsigned
  sail_assert (((((esize == 4) || (esize == 8)) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:47674.51-47674.52"
  (execute_aarch64_instrs_vector_shift_left_sat_sisd d datasize dst_unsigned elements esize n shift src_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let diff ← (( do (undefined_int ()) ) : SailM Int )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (diff, element1, element2, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (diff, element1, element2, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (diff, element1, element2, result, sat) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let diff : Int := (element1 -i element2)
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ diff esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (diff, element1, element2, result, sat))
    (pure loop_vars) ) : SailM (Int × Int × Int × (BitVec datasize) × Bool) )
  (V_set d datasize result)

def decode_sqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_sqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

def decode_uqsub_advsimd_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (Rm : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  (if (((size +++ Q) == 0b110#3) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_binary_uniform_sub_saturating_sisd d datasize elements esize m n is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (SatQ (← (asl_Int element is_unsigned)) esize is_unsigned)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_sqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_uqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

def decode_uqxtn_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sat_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (U : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  let is_unsigned : Bool := (U == 1#1)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sat_sisd d datasize elements esize n part is_unsigned)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, n : Nat, part : Nat, List.elem part [0, 1] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (n : Nat) (part : Nat) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand ← (( do (V_read n (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element ← (( do (undefined_bitvector (2 *i esize)) ) : SailM (BitVec (2 * esize)) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (element, result, sat) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element, result, sat)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element, result, sat) := loop_vars
      loop_vars ← do
        let element ← (Elem_read operand e (2 *i esize))
        let (result, sat) ← (( do
          let (__tup_0, __tup_1) ← do (UnsignedSatQ (BitVec.toInt element) esize)
          let result ← (Elem_set result e esize __tup_0)
          let sat : Bool := __tup_1
          (pure (result, sat)) ) : SailM ((BitVec datasize) × Bool) )
        (if (sat : Bool)
        then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 27 27 1#1))
        else (do (pure ())))
        (pure (element, result, sat))
    (pure loop_vars) ) : SailM ((BitVec (2 * esize)) × (BitVec datasize) × Bool) )
  (Vpart_set d part datasize result)

def decode_sqxtun_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := esize
  let part := 0
  let elements := 1
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd d datasize elements esize n part)

def decode_sqxtun_advsimd_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_simd (Rd : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (Q : (BitVec 1)) : SailM Unit := do
  let d := (BitVec.toNat Rd)
  let n := (BitVec.toNat Rn)
  (if ((size == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let datasize := 64
  let part := (BitVec.toNat Q)
  let elements := (Int.ediv datasize esize)
  (execute_aarch64_instrs_vector_arithmetic_unary_extract_sqxtun_sisd d datasize elements esize n part)

/-- Type quantifiers: d : Nat, datasize : Nat, elements : Int, esize : Nat, k_is_unsigned : Bool, m : Nat, n : Nat, 0 ≤ n ∧ n ≤ 31 ∧ 0 ≤ m ∧ m ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] ∧ 0 ≤ d ∧ d ≤ 31 -/
def execute_aarch64_instrs_vector_arithmetic_binary_uniform_add_halving_rounding (d : Nat) (datasize : Nat) (elements : Int) (esize : Nat) (m : Nat) (n : Nat) (is_unsigned : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let operand1 ← (( do (V_read n datasize) ) : SailM (BitVec datasize) )
  let operand2 ← (( do (V_read m datasize) ) : SailM (BitVec datasize) )
  let result ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let element1 ← (( do (undefined_int ()) ) : SailM Int )
  let element2 ← (( do (undefined_int ()) ) : SailM Int )
  let sum ← (( do (undefined_int ()) ) : SailM Int )
  let (element1, element2, result, sum) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := (elements -i 1)
    let mut loop_vars := (element1, element2, result, sum)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (element1, element2, result, sum) := loop_vars
      loop_vars ← do
        let element1 ← (( (asl_Int (← (Elem_read operand1 e esize)) is_unsigned) ) : SailM Int )
        let element2 ← (( (asl_Int (← (Elem_read operand2 e esize)) is_unsigned) ) : SailM Int )
        let sum : Int := (Int.shiftr ((element1 +i element2) +i 1) 1)
        let result ← (Elem_set result e esize (integer_subrange sum (esize -i 1) 0))
        (pure (element1, element2, result, sum))
    (pure loop_vars) ) : SailM (Int × Int × (BitVec datasize) × Int) )
  (V_set d datasize result)


end ArmASL.Functions
