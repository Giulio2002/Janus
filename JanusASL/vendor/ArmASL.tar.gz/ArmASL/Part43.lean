import ArmASL.Part42

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def decode_st3_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22656.48-22656.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st3_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22726.48-22726.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st4_advsimd_sngl_aarch64_instrs_memory_vector_single_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (o2 : (BitVec 1)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22796.48-22796.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

def decode_st4_advsimd_sngl_aarch64_instrs_memory_vector_single_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (S : (BitVec 1)) (opcode : (BitVec 3)) (Rm : (BitVec 5)) (R : (BitVec 1)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let init_scale := (BitVec.toNat (Sail.BitVec.extractLsb opcode 2 1))
  let scale : Int := init_scale
  let selem := ((BitVec.toNat (((BitVec.access opcode 0) : BitVec 1) +++ R)) +i 1)
  let replicate : Bool := false
  let index ← (( do (undefined_int ()) ) : SailM Int )
  let (index, replicate, scale) ← (( do
    match scale with
    | 3 =>
      (do
        (if (((L == 0#1) || (S == 1#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let scale : Int := (BitVec.toNat size)
        let replicate : Bool := true
        (pure (index, replicate, scale)))
    | 0 =>
      (let index : Int := (BitVec.toNat ((Q +++ S) +++ size))
      (pure (index, replicate, scale)))
    | 1 =>
      (do
        (if ((((BitVec.access size 0) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let index : Int := (BitVec.toNat ((Q +++ S) +++ ((BitVec.access size 1) : BitVec 1)))
        (pure (index, replicate, scale)))
    | 2 =>
      (do
        (if ((((BitVec.access size 1) : BitVec 1) == 1#1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else (do (pure ())))
        let (index, scale) ← (( do
          (if ((((BitVec.access size 0) : BitVec 1) == 0#1) : Bool)
          then
            (do let index : Int := (BitVec.toNat (Q +++ S))
                (pure (index, scale)))
          else
            (do (if ((S == 1#1) : Bool)
                then (do sailThrow ((Error_Undefined ())))
                else (do (pure ())))
                let index : Int := (BitVec.toNat Q)
                let scale : Int := 3
                (pure (index, scale)))) ) : SailM (Int × Int) )
        (pure (index, replicate, scale)))
    | _ => (pure (index, replicate, scale)) ) : SailM (Int × Bool × Int) )
  let scale := scale
  let index := index
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (_shl_int_general 8 scale)
  sail_assert ((((esize == 8) || (esize == 16)) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:22866.48-22866.49"
  (execute_aarch64_instrs_memory_vector_single_no_wb datasize esize index m memop n nontemporal replicate selem t tagchecked wback)

/-- Type quantifiers: datasize : Nat, elements : Int, esize : Nat, m : Int, n : Nat, k_nontemporal : Bool, rpt : Nat, selem : Nat, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem selem [1, 2, 3, 4] ∧ List.elem rpt [1, 2, 3, 4] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem esize [8, 16, 32, 64] ∧ List.elem datasize [64, 128] -/
def execute_aarch64_instrs_memory_vector_multiple_no_wb (datasize : Nat) (elements : Int) (esize : Nat) (m : Int) (memop : MemOp) (n : Nat) (nontemporal : Bool) (rpt : Nat) (selem : Nat) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPAdvSIMDEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let rval ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let tt ← (( do (undefined_int ()) ) : SailM Int )
  let ebytes := (Int.ediv esize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let offs : (BitVec 64) := (Zeros (n := 64))
  let (offs, rval, tt) ← (( do
    let loop_r_lower := 0
    let loop_r_upper := (rpt -i 1)
    let mut loop_vars := (offs, rval, tt)
    for r in [loop_r_lower:loop_r_upper:1]i do
      let (offs, rval, tt) := loop_vars
      loop_vars ← do
        let (offs, rval, tt) ← (( do
          let loop_e_lower := 0
          let loop_e_upper := (elements -i 1)
          let mut loop_vars_1 := (offs, rval, tt)
          for e in [loop_e_lower:loop_e_upper:1]i do
            let (offs, rval, tt) := loop_vars_1
            loop_vars_1 ← do
              let tt : Int := (Nat.mod (t +i r) 32)
              let (offs, rval, tt) ← (( do
                let loop_s_lower := 0
                let loop_s_upper := (selem -i 1)
                let mut loop_vars_2 := (offs, rval, tt)
                for s in [loop_s_lower:loop_s_upper:1]i do
                  let (offs, rval, tt) := loop_vars_2
                  loop_vars_2 ← do
                    let rval ← (( do
                      let tt := tt
                      (V_read tt datasize) ) : SailM (BitVec datasize) )
                    let rval ← (( do
                      let tt := tt
                      (if ((BEq.beq memop MemOp_LOAD) : Bool)
                      then
                        (do let rval ← (Elem_set rval e esize (← (Mem_read (address + offs) ebytes accdesc)))
                            (V_set tt datasize rval)
                            (pure rval))
                      else
                        (do (Mem_set (address + offs) ebytes accdesc (← (Elem_read rval e esize)))
                            (pure rval))) ) : SailM (BitVec datasize) )
                    let offs : (BitVec 64) := (BitVec.addInt offs ebytes)
                    let tt : Int := (fmod_int (tt +i 1) 32)
                    (pure (offs, rval, tt))
                (pure loop_vars_2) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
              (pure (offs, rval, tt))
          (pure loop_vars_1) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
        (pure (offs, rval, tt))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec datasize) × Int) )
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))
  (if (wback : Bool)
  then
    (do let offs ← (( do
          (if ((m != 31) : Bool)
          then (do (X_read m 64))
          else (do (pure offs))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set (address + offs)))
        else (do (X_set n 64 (address + offs)))))
  else (do (pure ())))

def decode_ld1_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld1_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld2_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld2_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld3_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld3_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld4_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_ld4_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st1_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st1_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st2_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st2_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st3_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st3_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st4_advsimd_mult_aarch64_instrs_memory_vector_multiple_no_wb (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m ← (( do (__UNKNOWN_integer ()) ) : SailM Int )
  let wback : Bool := false
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

def decode_st4_advsimd_mult_aarch64_instrs_memory_vector_multiple_post_inc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (size : (BitVec 2)) (opcode : (BitVec 4)) (Rm : (BitVec 5)) (L : (BitVec 1)) (Q : (BitVec 1)) : SailM Unit := do
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let m := (BitVec.toNat Rm)
  let wback : Bool := true
  let nontemporal : Bool := false
  let tagchecked : Bool := (wback || (n != 31))
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let datasize :=
    if ((Q == 1#1) : Bool)
    then 128
    else 64
  let esize := (Int.shiftl 8 (BitVec.toNat size))
  let elements := (Int.ediv datasize esize)
  let rpt : Int := 1
  let selem : Int := 1
  let (rpt, selem) ← (( do
    match opcode with
    | 0b0000 =>
      (let rpt : Int := 1
      let selem : Int := 4
      (pure (rpt, selem)))
    | 0b0010 =>
      (let rpt : Int := 4
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0100 =>
      (let rpt : Int := 1
      let selem : Int := 3
      (pure (rpt, selem)))
    | 0b0110 =>
      (let rpt : Int := 3
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b0111 =>
      (let rpt : Int := 1
      let selem : Int := 1
      (pure (rpt, selem)))
    | 0b1000 =>
      (let rpt : Int := 1
      let selem : Int := 2
      (pure (rpt, selem)))
    | 0b1010 =>
      (let rpt : Int := 2
      let selem : Int := 1
      (pure (rpt, selem)))
    | _ => sailThrow ((Error_Undefined ())) ) : SailM (Int × Int) )
  let selem := selem
  let rpt := rpt
  (if ((((size +++ Q) == 0b110#3) && (selem != 1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  (execute_aarch64_instrs_memory_vector_multiple_no_wb datasize elements esize m memop n nontemporal rpt selem t tagchecked wback)

/-- Type quantifiers: k_acquire : Bool, datasize : Nat, k_is_load : Bool, n : Nat, regsize : Nat, k_release : Bool, s : Nat, t : Nat, k_tagchecked : Bool, 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_atomicops_ld (acquire : Bool) (datasize : Nat) (is_load : Bool) (n : Nat) (op : MemAtomicOp) (regsize : Nat) (release : Bool) (s : Nat) (t : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescAtomicOp op acquire release tagchecked) ) : SailM AccessDescriptor )
  let value_name ← (( do (X_read s datasize) ) : SailM (BitVec datasize) )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let comparevalue ← (( do (__UNKNOWN_bits datasize) ) : SailM (BitVec datasize) )
  let data ← (( do (MemAtomic address comparevalue value_name accdesc) ) : SailM (BitVec datasize) )
  (if ((t != 31) : Bool)
  then
    (do sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:24090.67-24090.68"
        (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if ((acquire || release) : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 1#1
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldadd_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldaddb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldaddh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclr_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclrb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldclrh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeor_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeorb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldeorh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldset_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsetb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldseth_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmax_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmaxb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmaxh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsmin_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsminb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldsminh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumax_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumaxb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumaxh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_ldumin_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_lduminb_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

def decode_lduminh_aarch64_instrs_memory_atomicops_ld (Rt : (BitVec 5)) (Rn : (BitVec 5)) (opc : (BitVec 3)) (Rs : (BitVec 5)) (R : (BitVec 1)) (A : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  (if ((! (← (HaveAtomicExt ()))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let t := (BitVec.toNat Rt)
  let n := (BitVec.toNat Rn)
  let s := (BitVec.toNat Rs)
  let datasize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((datasize == 64) : Bool)
    then 64
    else 32
  let acquire : Bool := ((A == 1#1) && (Rt != 0b11111#5))
  let is_load : Bool := (Rt != 0b11111#5)
  let release : Bool := (R == 1#1)
  let op ← (( do (undefined_MemAtomicOp ()) ) : SailM MemAtomicOp )
  let op : MemAtomicOp :=
    match opc with
    | 0b000 => MemAtomicOp_ADD
    | 0b001 => MemAtomicOp_BIC
    | 0b010 => MemAtomicOp_EOR
    | 0b011 => MemAtomicOp_ORR
    | 0b100 => MemAtomicOp_SMAX
    | 0b101 => MemAtomicOp_SMIN
    | 0b110 => MemAtomicOp_UMAX
    | _ => MemAtomicOp_UMIN
  let op := op
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_atomicops_ld acquire datasize is_load n op regsize release s t tagchecked)

/-- Type quantifiers: datasize : Nat, n : Nat, offset : Nat, regsize : Nat, t : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ List.elem offset [0, 1, 2, 4, 8] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_ordered_rcpc (datasize : Nat) (n : Nat) (offset : Nat) (regsize : Nat) (t : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescLDAcqPC tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
  sail_assert (regsize ≥b datasize) "sail-arm/arm-v9.4-a/src/instrs64.sail:25686.44-25686.45"
  (X_set t regsize (Sail.BitVec.zeroExtend data regsize))
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else (do (pure (BitVec.addInt address offset)))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) := 1#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := true
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldapr_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

def decode_ldaprb_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

def decode_ldaprh_aarch64_instrs_memory_ordered_rcpc (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rs : (BitVec 5)) (size : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let offset := 0
  let wb_unknown : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let s := (BitVec.toNat Rs)
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered_rcpc datasize n offset regsize t tagchecked wb_unknown wback)

/-- Type quantifiers: datasize : Nat, k_limitedordered : Bool, n : Nat, offset : Int, regsize : Nat, k_rt_unknown : Bool, t : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t ∧ t ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [8, 16, 32, 64] -/
def execute_aarch64_instrs_memory_ordered (datasize : Nat) (limitedordered : Bool) (memop : MemOp) (n : Nat) (offset : Int) (regsize : Nat) (rt_unknown : Bool) (t : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (undefined_AccessDescriptor ()) ) : SailM AccessDescriptor )
  let accdesc ← (( do
    (if (limitedordered : Bool)
    then (do (CreateAccDescLOR memop tagchecked))
    else (do (CreateAccDescAcqRel memop tagchecked))) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  match memop with
  | .MemOp_STORE =>
    (do
      let address : (BitVec 64) := (BitVec.addInt address offset)
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let _ : Unit := (AArch64_SetLSInstructionSyndrome dbytes false t (regsize == 64) true)
      (Mem_set address dbytes accdesc data)
      (if (wback : Bool)
      then
        (do (if ((n == 31) : Bool)
            then (do (SP_set address))
            else (do (X_set n 64 address))))
      else (do (pure ()))))
  | .MemOp_LOAD =>
    (do
      let _ : Unit := (AArch64_SetLSInstructionSyndrome dbytes false t (regsize == 64) true)
      let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
      sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:26765.69-26765.70"
      (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) := 1#1
        let excl : (BitVec 1) := 0#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := (BEq.beq memop MemOp_LOAD)
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldar_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_ldarb_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_ldarh_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_stlr_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_stlrb_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

def decode_stlrh_aarch64_instrs_memory_ordered (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let wback : Bool := false
  let offset := 0
  let rt_unknown : Bool := false
  let limitedordered : Bool := (o0 == 0#1)
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize := elsize
  let tagchecked : Bool := (n != 31)
  (execute_aarch64_instrs_memory_ordered datasize limitedordered memop n offset regsize rt_unknown t tagchecked wback)

/-- Type quantifiers: k_acqrel : Bool, datasize : Nat, elsize : Nat, n : Nat, k_pair : Bool, regsize : Nat, k_rn_unknown : Bool, k_rt_unknown : Bool, s : Nat, t : Nat, t2 : Nat, k_tagchecked : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ s ∧ s ≤ 31 ∧ List.elem regsize [32, 64] ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem elsize [8, 16, 32, 64] ∧ List.elem datasize [8, 16, 32, 64, 128] -/
def execute_aarch64_instrs_memory_exclusive_single (acqrel : Bool) (datasize : Nat) (elsize : Nat) (memop : MemOp) (n : Nat) (pair : Bool) (regsize : Nat) (rn_unknown : Bool) (rt_unknown : Bool) (s : Nat) (t : Nat) (t2 : Nat) (tagchecked : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescExLDST memop acqrel tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else
      (do (if (rn_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else (do (X_read n 64))))) ) : SailM (BitVec 64) )
  match memop with
  | .MemOp_STORE =>
    (do
      let data ← (( do
        (if (rt_unknown : Bool)
        then (do (__UNKNOWN_bits datasize))
        else
          (do (if (pair : Bool)
              then
                (do sail_assert (((Int.ediv datasize 2) == 8) || (((Int.ediv datasize 2) == 16) || (((Int.ediv datasize 2) == 32) || ((Int.ediv datasize 2) == 64)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27578.135-27578.136"
                    let el1 ← (( do (X_read t (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    let el2 ← (( do (X_read t2 (Int.ediv datasize 2)) ) : SailM (BitVec (datasize / 2)) )
                    (if ((← (BigEndian accdesc.acctype)) : Bool)
                    then (do (pure (el1 +++ el2)))
                    else (do (pure (el2 +++ el1)))))
              else
                (do sail_assert ((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27583.61-27583.62"
                    (X_read t datasize))))) ) : SailM (BitVec datasize) )
      let status : (BitVec 1) := 1#1
      let status ← (( do
        (if ((← (AArch64_ExclusiveMonitorsPass address dbytes)) : Bool)
        then
          (do (Mem_set address dbytes accdesc data)
              (pure (ExclusiveMonitorsStatus ())))
        else
          (do (if ((← readReg SPESampleInFlight) : Bool)
              then (do (SPESetDataVirtualAddress address))
              else (do (pure ())))
              (pure status))) ) : SailM (BitVec 1) )
      (X_set s 32 (Sail.BitVec.zeroExtend status 32)))
  | .MemOp_LOAD =>
    (do
      (AArch64_SetExclusiveMonitors address dbytes)
      (if (pair : Bool)
      then
        (do (if (rt_unknown : Bool)
            then
              (do sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27599.58-27599.59"
                  (X_set t datasize (← (__UNKNOWN_bits datasize))))
            else
              (do (if ((elsize == 32) : Bool)
                  then
                    (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
                        (if ((← (BigEndian accdesc.acctype)) : Bool)
                        then
                          (do sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27604.110-27604.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27605.96-27605.97"
                              (X_set t (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize))
                              (X_set t2 elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0)))
                        else
                          (do sail_assert ((0 ≤b (elsize -i 1)) && ((elsize -i 1) <b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27609.85-27609.86"
                              (X_set t elsize (Sail.BitVec.extractLsb data (elsize -i 1) 0))
                              sail_assert ((0 ≤b elsize) && ((elsize ≤b (datasize -i 1)) && ((datasize -i 1) <b datasize))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27611.110-27611.111"
                              sail_assert (((datasize -i elsize) == 32) || ((datasize -i elsize) == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27612.96-27612.97"
                              (X_set t2 (datasize -i elsize) (Sail.BitVec.extractLsb data (datasize -i 1) elsize)))))
                  else
                    (do (if ((! (IsAligned__1 address dbytes)) : Bool)
                        then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
                        else (do (pure ())))
                        (X_set t 64 (← (Mem_read (BitVec.addInt address 0) 8 accdesc)))
                        (X_set t2 64 (← (Mem_read (BitVec.addInt address 8) 8 accdesc))))))))
      else
        (do let data ← (( do (Mem_read address dbytes accdesc) ) : SailM (BitVec datasize) )
            sail_assert ((datasize ≥b 0) && (regsize ≥b datasize)) "sail-arm/arm-v9.4-a/src/instrs64.sail:27624.73-27624.74"
            (X_set t regsize (Sail.BitVec.zeroExtend data regsize)))))
  | _ => (pure ())
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let ar : (BitVec 1) :=
          if (acqrel : Bool)
          then 1#1
          else 0#1
        let excl : (BitVec 1) := 1#1
        let at' : (BitVec 1) := 0#1
        let is_load : Bool := (BEq.beq memop MemOp_LOAD)
        (SPESampleExtendedLoadStore ar excl at' is_load))
  else (do (pure ())))

def decode_ldaxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27658.84-27658.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27675.88-27675.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27691.88-27691.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldaxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27744.84-27744.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27761.88-27761.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27777.88-27777.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldaxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27830.84-27830.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27847.88-27847.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27863.88-27863.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxr_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27916.84-27916.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27933.88-27933.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:27949.88-27949.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxrb_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28002.84-28002.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28019.88-28019.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28035.88-28035.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

def decode_ldxrh_aarch64_instrs_memory_exclusive_single (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (o0 : (BitVec 1)) (Rs : (BitVec 5)) (L : (BitVec 1)) (size : (BitVec 2)) : SailM Unit := do
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let s := (BitVec.toNat Rs)
  let acqrel : Bool := (o0 == 1#1)
  let pair : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  let elsize := (Int.shiftl 8 (BitVec.toNat size))
  let regsize :=
    if ((elsize == 64) : Bool)
    then 64
    else 32
  let datasize :=
    if (pair : Bool)
    then (elsize *i 2)
    else elsize
  let tagchecked : Bool := (n != 31)
  let rt_unknown : Bool := false
  let rn_unknown : Bool := false
  let rt_unknown ← (( do
    (if ((((BEq.beq memop MemOp_LOAD) && pair) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28088.84-28088.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let (rn_unknown, rt_unknown) ← (( do
    (if ((BEq.beq memop MemOp_STORE) : Bool)
    then
      (do let rt_unknown ← (( do
            (if (((s == t) || (pair && (s == t2))) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_DATAOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28105.88-28105.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rt_unknown))
                  | _ => (pure rt_unknown))
            else (do (pure rt_unknown))) ) : SailM Bool )
          let rn_unknown ← (( do
            (if (((s == n) && (n != 31)) : Bool)
            then
              (do let c ← (( do (ConstrainUnpredictable Unpredictable_BASEOVERLAP) ) : SailM Constraint )
                  sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:28121.88-28121.89"
                  match c with
                  | .Constraint_UNKNOWN => (pure true)
                  | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
                  | .Constraint_NOP =>
                    (do
                      (EndOfInstruction ())
                      (pure rn_unknown))
                  | _ => (pure rn_unknown))
            else (do (pure rn_unknown))) ) : SailM Bool )
          (pure (rn_unknown, rt_unknown)))
    else (do (pure (rn_unknown, rt_unknown)))) ) : SailM (Bool × Bool) )
  (execute_aarch64_instrs_memory_exclusive_single acqrel datasize elsize memop n pair regsize rn_unknown rt_unknown s t t2 tagchecked)

/-- Type quantifiers: datasize : Nat, n : Nat, k_nontemporal : Bool, k_postindex : Bool, k_rt_unknown : Bool, t : Nat, t2 : Nat, k_tagchecked : Bool, k_wback : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64, 128, 256] -/
def execute_aarch64_instrs_memory_pair_simdfp_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (rt_unknown : Bool) (t : Nat) (t2 : Nat) (tagchecked : Bool) (wback : Bool) : SailM Unit := do
  (CheckFPEnabled64 ())
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let data2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let accdesc ← (( do (CreateAccDescASIMD memop nontemporal tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29263.62-29263.63"
      let data1 ← (( do (V_read t datasize) ) : SailM (BitVec datasize) )
      let data2 ← (( do (V_read t2 datasize) ) : SailM (BitVec datasize) )
      (Mem_set (BitVec.addInt address 0) dbytes accdesc data1)
      (Mem_set (BitVec.addInt address dbytes) dbytes accdesc data2))
  | .MemOp_LOAD =>
    (do
      let data1 ← (( (Mem_read (BitVec.addInt address 0) dbytes accdesc) ) : SailM (BitVec datasize) )
      let data2 ← (( (Mem_read (BitVec.addInt address dbytes) dbytes accdesc) ) : SailM (BitVec datasize) )
      let (data1, data2) ← (( do
        (if (rt_unknown : Bool)
        then
          (do let data1 ← (__UNKNOWN_bits datasize)
              let data2 ← (__UNKNOWN_bits datasize)
              (pure (data1, data2)))
        else (do (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      sail_assert (((((datasize == 8) || (datasize == 16)) || (datasize == 32)) || (datasize == 64)) || (datasize == 128)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29276.62-29276.63"
      (V_set t datasize data1)
      (V_set t2 datasize data2))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address : (BitVec 64) :=
          if (postindex : Bool)
          then (address + offset)
          else address
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleSIMDFPLoadStore ()))
  else (do (pure ())))

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29318.84-29318.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29332.54-29332.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29367.84-29367.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29381.54-29381.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_ldp_fpsimd_aarch64_instrs_memory_pair_simdfp_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29416.84-29416.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29430.54-29430.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29465.84-29465.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29479.54-29479.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29514.84-29514.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29528.54-29528.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

def decode_stp_fpsimd_aarch64_instrs_memory_pair_simdfp_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((opc == 0b11#2) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let scale := (2 +i (BitVec.toNat opc))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29563.84-29563.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((((datasize == 32) || (datasize == 64)) || (datasize == 128)) || (datasize == 256)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29577.54-29577.55"
  (execute_aarch64_instrs_memory_pair_simdfp_post_idx datasize memop n nontemporal offset postindex rt_unknown t t2 tagchecked wback)

/-- Type quantifiers: datasize : Nat, k_is_signed : Bool, n : Nat, k_nontemporal : Bool, k_postindex : Bool, k_rt_unknown : Bool, t : Nat, t2 : Nat, k_tagchecked : Bool, k_wb_unknown : Bool, k_wback : Bool, 0 ≤ t2 ∧ t2 ≤ 31 ∧ 0 ≤ t ∧ t ≤ 31 ∧ 0 ≤ n ∧ n ≤ 31 ∧ List.elem datasize [32, 64] -/
def execute_aarch64_instrs_memory_pair_general_post_idx (datasize : Nat) (memop : MemOp) (n : Nat) (nontemporal : Bool) (offset : (BitVec 64)) (postindex : Bool) (rt_unknown : Bool) (is_signed : Bool) (t : Nat) (t2 : Nat) (tagchecked : Bool) (wb_unknown : Bool) (wback : Bool) : SailM Unit := do
  let address ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let data1 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let data2 ← (( do (undefined_bitvector datasize) ) : SailM (BitVec datasize) )
  let dbytes := (Int.ediv datasize 8)
  let privileged ← (( do (pure ((← readReg PSTATE).EL != EL0)) ) : SailM Bool )
  let accdesc ← (( do (CreateAccDescGPR memop nontemporal privileged tagchecked) ) : SailM AccessDescriptor )
  let address ← (( do
    (if ((n == 31) : Bool)
    then
      (do (CheckSPAlignment ())
          (SP_read ()))
    else (do (X_read n 64))) ) : SailM (BitVec 64) )
  let address : (BitVec 64) :=
    if ((! postindex) : Bool)
    then (address + offset)
    else address
  match memop with
  | .MemOp_STORE =>
    (do
      let data1 ← (( do
        (if ((rt_unknown && (t == n)) : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t datasize))) ) : SailM (BitVec datasize) )
      let data2 ← (( do
        (if ((rt_unknown && (t2 == n)) : Bool)
        then (do (__UNKNOWN_bits datasize))
        else (do (X_read t2 datasize))) ) : SailM (BitVec datasize) )
      (if ((← (HaveLSE2Ext ())) : Bool)
      then
        (do let full_data ← (( do (undefined_bitvector (2 *i datasize)) ) : SailM (BitVec (2 * datasize)) )
            let full_data ← (( do
              (if ((← (BigEndian accdesc.acctype)) : Bool)
              then (do (pure (data1 +++ data2)))
              else (do (pure (data2 +++ data1)))) ) : SailM (BitVec (2 * datasize)) )
            let ispair : Bool := true
            (Mem_set__1 address (2 *i dbytes) accdesc ispair full_data))
      else
        (do (Mem_set (BitVec.addInt address 0) dbytes accdesc data1)
            (Mem_set (BitVec.addInt address dbytes) dbytes accdesc data2))))
  | .MemOp_LOAD =>
    (do
      let (data1, data2) ← (( do
        (if (((← (HaveLSE2Ext ())) && (! is_signed)) : Bool)
        then
          (do let ispair : Bool := true
              let full_data ← (( do (Mem_read__1 address (2 *i dbytes) accdesc ispair) ) : SailM (BitVec (2 * datasize)) )
              let (data1, data2) ← (( do
                (if ((← (BigEndian accdesc.acctype)) : Bool)
                then
                  (do let data2 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data (datasize -i 1) 0)
                      let data1 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data ((2 *i datasize) -i 1) datasize)
                      (pure (data1, data2)))
                else
                  (do let data1 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data (datasize -i 1) 0)
                      let data2 : (BitVec datasize) := (Sail.BitVec.extractLsb full_data ((2 *i datasize) -i 1) datasize)
                      (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
              (pure (data1, data2)))
        else
          (do let data1 ← (Mem_read (BitVec.addInt address 0) dbytes accdesc)
              let data2 ← (Mem_read (BitVec.addInt address dbytes) dbytes accdesc)
              (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      let (data1, data2) ← (( do
        (if (rt_unknown : Bool)
        then
          (do let data1 ← (__UNKNOWN_bits datasize)
              let data2 ← (__UNKNOWN_bits datasize)
              (pure (data1, data2)))
        else (do (pure (data1, data2)))) ) : SailM ((BitVec datasize) × (BitVec datasize)) )
      (if (is_signed : Bool)
      then
        (do (X_set t 64 (sign_extend data1 64))
            (X_set t2 64 (sign_extend data2 64)))
      else
        (do (X_set t datasize data1)
            (X_set t2 datasize data2))))
  | _ => (pure ())
  (if (wback : Bool)
  then
    (do let address ← (( do
          (if (wb_unknown : Bool)
          then (do (__UNKNOWN_bits 64))
          else
            (do (if (postindex : Bool)
                then (do (pure (address + offset)))
                else (do (pure address))))) ) : SailM (BitVec 64) )
        (if ((n == 31) : Bool)
        then (do (SP_set address))
        else (do (X_set n 64 address))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPESampleGeneralPurposeLoadStore ()))
  else (do (pure ())))

def decode_ldp_gen_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29707.113-29707.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29726.107-29726.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29745.84-29745.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29759.44-29759.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldp_gen_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29796.113-29796.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29815.107-29815.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29834.84-29834.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29848.44-29848.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldp_gen_aarch64_instrs_memory_pair_general_offset (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := false
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29885.113-29885.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29904.107-29904.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29923.84-29923.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:29937.44-29937.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldpsw_aarch64_instrs_memory_pair_general_post_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := true
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29974.113-29974.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:29993.107-29993.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30012.84-30012.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30026.44-30026.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)

def decode_ldpsw_aarch64_instrs_memory_pair_general_pre_idx (Rt : (BitVec 5)) (Rn : (BitVec 5)) (Rt2 : (BitVec 5)) (imm7 : (BitVec 7)) (L : (BitVec 1)) (opc : (BitVec 2)) : SailM Unit := do
  let wback : Bool := true
  let postindex : Bool := false
  let n := (BitVec.toNat Rn)
  let t := (BitVec.toNat Rt)
  let t2 := (BitVec.toNat Rt2)
  let nontemporal : Bool := false
  let memop : MemOp :=
    if ((L == 1#1) : Bool)
    then MemOp_LOAD
    else MemOp_STORE
  (if ((((L +++ ((BitVec.access opc 0) : BitVec 1)) == 0b01#2) || (opc == 0b11#2)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let is_signed : Bool := (((BitVec.access opc 0) : BitVec 1) != 0#1)
  let scale := (2 +i (BitVec.toNat ((BitVec.access opc 1) : BitVec 1)))
  let datasize := (Int.shiftl 8 scale)
  let offset : (BitVec 64) := ((sign_extend imm7 64) <<< scale)
  let tagchecked : Bool := (wback || (n != 31))
  let rt_unknown : Bool := false
  let wb_unknown : Bool := false
  let (wb_unknown, wback) ← (( do
    (if (((((BEq.beq memop MemOp_LOAD) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPLD) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_WBSUPPRESS) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30063.113-30063.114"
          let (wb_unknown, wback) ← (( do
            match c with
            | .Constraint_WBSUPPRESS =>
              (let wback : Bool := false
              (pure (wb_unknown, wback)))
            | .Constraint_UNKNOWN =>
              (let wb_unknown : Bool := true
              (pure (wb_unknown, wback)))
            | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
            | .Constraint_NOP =>
              (do
                (EndOfInstruction ())
                (pure (wb_unknown, wback)))
            | _ => (pure (wb_unknown, wback)) ) : SailM (Bool × Bool) )
          (pure (wb_unknown, wback)))
    else (do (pure (wb_unknown, wback)))) ) : SailM (Bool × Bool) )
  let rt_unknown ← (( do
    (if (((((BEq.beq memop MemOp_STORE) && wback) && ((t == n) || (t2 == n))) && (n != 31)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_WBOVERLAPST) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_NONE) || ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP)))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30082.107-30082.108"
          match c with
          | .Constraint_NONE => (pure false)
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  let rt_unknown ← (( do
    (if (((BEq.beq memop MemOp_LOAD) && (t == t2)) : Bool)
    then
      (do let c ← (( do (ConstrainUnpredictable Unpredictable_LDPOVERLAP) ) : SailM Constraint )
          sail_assert ((BEq.beq c Constraint_UNKNOWN) || ((BEq.beq c Constraint_UNDEF) || (BEq.beq c Constraint_NOP))) "sail-arm/arm-v9.4-a/src/instrs64.sail:30101.84-30101.85"
          match c with
          | .Constraint_UNKNOWN => (pure true)
          | .Constraint_UNDEF => sailThrow ((Error_Undefined ()))
          | .Constraint_NOP =>
            (do
              (EndOfInstruction ())
              (pure rt_unknown))
          | _ => (pure rt_unknown))
    else (do (pure rt_unknown))) ) : SailM Bool )
  sail_assert ((datasize == 32) || (datasize == 64)) "sail-arm/arm-v9.4-a/src/instrs64.sail:30115.44-30115.45"
  (execute_aarch64_instrs_memory_pair_general_post_idx datasize memop n nontemporal offset postindex rt_unknown is_signed t t2 tagchecked wb_unknown wback)


end ArmASL.Functions
