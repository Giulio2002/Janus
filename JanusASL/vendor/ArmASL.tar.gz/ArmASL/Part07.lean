import ArmASL.Part06

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PSTATEField
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPSub__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17770.41-17770.42"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) && (sign1 == sign2)) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((inf1 && (sign1 == 0#1)) || (inf2 && (sign2 == 1#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((inf1 && (sign1 == 1#1)) || (inf2 && (sign2 == 0#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zero1 && zero2) && (sign1 == (Complement.complement sign2))) : Bool)
                            then (do (FPZero sign1 (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (sub_real value1_name value2_name)
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (fpexc : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPSub (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPSub__1 op1 op2 fpcr fpexc)

/-- Type quantifiers: M : Nat, k_N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem k_N [16, 32, 64] ∧ List.elem M [16, 32, 64] -/
def FPToFixed (op : (BitVec k_N)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (M : Nat) : SailM (BitVec M) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let overflow ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17844.41-17844.42"
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17845.38-17845.39"
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:17846.21-17846.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17847.37-17847.38"
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, value_name)) ) : SailM (FPType × real) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else (do (pure ())))
  let value_name : real := (mult_real value_name (real_power (2) fbits))
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let round_up : Bool :=
    match rounding with
    | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
    | .FPRounding_POSINF => (bne error (0))
    | .FPRounding_NEGINF => false
    | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
    | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
    | _ => round_up
  let int_result : Int :=
    if (round_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let (overflow, result) ← (( do
    let (tup__0, tup__1) ← do (SatQ int_result M is_unsigned)
    let result : (BitVec M) := tup__0
    let overflow : Bool := tup__1
    (pure (overflow, result)) ) : SailM (Bool × (BitVec M)) )
  (if (overflow : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else
    (do (if ((bne error (0)) : Bool)
        then (do (FPProcessException FPExc_Inexact fpcr))
        else (do (pure ())))))
  (pure result)

/-- Type quantifiers: k_Is64 : Bool, k_M : Nat, N : Nat, k_M = 64 ∧ N = 32 -/
def FPToFixedJS (op : (BitVec k_M)) (fpcr : (BitVec 64)) (Is64 : Bool) (N : Nat) : SailM ((BitVec N) × (BitVec 1)) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 64) && (N == 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17897.29-17897.30"
  let fpexc_idenorm ← (( do (pure (! ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1)))) ) : SailM Bool )
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc_idenorm)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let z : (BitVec 1) := 1#1
  let z ← (( do
    (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else (do (pure z))) ) : SailM (BitVec 1) )
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_it_up : Bool := ((bne error (0)) && (int_result <b 0))
  let int_result : Int :=
    if (round_it_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result : Int :=
    if ((int_result <b 0) : Bool)
    then (int_result -i ((2 ^i 32) *i (round_up (div_real (to_real int_result) (to_real (2 ^i 32))))))
    else (int_result -i ((2 ^i 32) *i (round_down (div_real (to_real int_result) (to_real (2 ^i 32))))))
  let z ← (( do
    (if (((int_result <b (Neg.neg (2 ^i 31))) || (int_result >b ((2 ^i 31) -i 1))) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else
      (do (if ((bne error (0)) : Bool)
          then
            (do (FPProcessException FPExc_Inexact fpcr)
                (pure 0#1))
          else
            (do (if (((sign == 1#1) && (eq_real value_name (0))) : Bool)
                then (do (pure 0#1))
                else
                  (do (if ((((sign == 0#1) && (eq_real value_name (0))) && (! (IsZero (Sail.BitVec.extractLsb op 51 0)))) : Bool)
                      then (do (pure 0#1))
                      else (do (pure z))))))))) ) : SailM (BitVec 1) )
  let result : Int :=
    if ((BEq.beq fptype FPType_Infinity) : Bool)
    then 0
    else result
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), z))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def VFPExpandImm (imm8 : (BitVec 8)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17939.38-17939.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := ((N -i E) -i 1)
  let sign : (BitVec 1) := ((BitVec.access imm8 7) : BitVec 1)
  let exp : (BitVec (1 + (E - 3) + 2)) := (((Complement.complement ((BitVec.access imm8 6) : BitVec 1)) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) (E -i 3))) +++ (Sail.BitVec.extractLsb imm8 5 4))
  let frac : (BitVec (4 + (F - 4))) := ((Sail.BitVec.extractLsb imm8 3 0) +++ (Zeros (n := (F -i 4))))
  (pure ((sign +++ exp) +++ frac))

def IsFault (addrdesc : AddressDescriptor) : Bool :=
  (bne addrdesc.fault.statuscode Fault_None)

def IsFault__1 (fault : Fault) : Bool :=
  (bne fault Fault_None)

def IsFault__2 (retstatus : PhysMemRetStatus) : Bool :=
  (bne retstatus.statuscode Fault_None)

def undefined_CNTHP_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_CNTHP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTV_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def undefined_CNTHP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTHP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTHP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHP_CTL ) : SailM CNTHP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHP_CTL_EL2) 0 32)))

def CNTHP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHP_CTL_Type := value_name
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHP_CTL r

def undefined_CNTHP_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTP_CTL_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTP_CTL_NS ) : SailM CNTP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTP_CTL_EL0) 0 32)))

def CNTP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CNTP_CTL_Type ()) ) : SailM CNTP_CTL_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CNTP_CTL_S)
  else (do (CNTP_CTL_NS_read ())))

def CNTP_CTL_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTP_CTL_NS r

def CNTP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CNTP_CTL_S r)
  else (do (CNTP_CTL_NS_write r)))

def undefined_CNTP_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHPS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHPS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHVS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHVS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHV_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHV_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTPS_CTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTPS_CVAL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HaveCNTSCExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CNTSC)

def undefined_CNTKCTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def HaveMPAMExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAM)

def Have16bitVMID (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_VMID16)

def AArch64_HaveHPDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HPDS)

def HaveQRDMLAHExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RDM)

def HaveCommonNotPrivateTransExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TTCNP)

def HaveExtendedExecuteNeverExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_XNX)

def Have52BitVAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LVA)

def Have52BitPAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LPA)

def HaveV82Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def HaveTrapLoadStoreMultipleDeviceExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSMAOC)

def HaveFJCVTZSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_JSCVT)

def HaveFCADDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FCMA)

def HaveDOTPExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DotProd)

def HaveSmallTranslationTableExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TTST)

def HaveLSE2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE2)

def HaveFP16MulNoRoundingToFP32Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FHM)

def HaveSelfHostedTrace (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TRF)

def HaveBlockBBM (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BBM)

def Havev8p4Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p4)

def HaveStage2MemAttrControl (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2FWB)

def HaveIDSExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_IDST)

def HaveFrintExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FRINTTS)

def HaveE0PDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_E0PD)

def HaveGTGExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_GTG)

def HaveMTEAsyncExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

def HaveMTEPermExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE_PERM)

def HaveDGHExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DGH)

def HaveFGTExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FGT)

def HaveInt8MatMulExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_I8MM)

def HavePMUv3p4 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p4)

def HaveDoPD (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoPD)

def Have56BitVAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LVA3)

def Have128BitDescriptorExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_D128)

def HaveAIEExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AIE)

def HaveFeatTCR2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TCR2)

def HavePAN3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAN3)

def HaveMTEAsymFaultExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

def HaveFeatLS64_V (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64_V)

def HaveFeatLS64_ACCDATA (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64_ACCDATA)

def HaveFeatXS (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_XS)

def HaveFeatEBEP (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_EBEP)

def HaveFeatTIDCP1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TIDCP1)

def HaveFeatCMOW (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CMOW)

def HaveLRCPC3Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LRCPC3)

def HaveMTEStoreOnlyExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE_STORE_ONLY)

def HaveS1PIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S1PIE)

def HaveS1POExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S1POE)

def HaveS2PIExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2PIE)

def HaveS2POExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_S2POE)

def HaveFeatCLRBHB (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CLRBHB)

def HaveTHExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_THE)

def HaveLSE128 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE128)

def HaveRASv2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RASv2)

def HaveFeatMEC (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MEC)

def HaveAccessFlagUpdateForTableExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFT)

def HaveFeatABLE (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_ABLE)

def ConstrainUnpredictable (which : Unpredictable) : SailM Constraint := do
  (__UNKNOWN_Constraint ())

def DecodeShareability (sh : (BitVec 2)) : SailM Shareability := do
  match sh with
  | 0b10 => (pure Shareability_OSH)
  | 0b11 => (pure Shareability_ISH)
  | 0b00 => (pure Shareability_NSH)
  | _ =>
    (do
      match (← (ConstrainUnpredictable Unpredictable_Shareability)) with
      | .Constraint_OSH => (pure Shareability_OSH)
      | .Constraint_ISH => (pure Shareability_ISH)
      | .Constraint_NSH => (pure Shareability_NSH)
      | _ => (do (undefined_Shareability ())))

def S2CombineS1Shareability (s1_shareability : Shareability) (s2_shareability : Shareability) : Shareability :=
  if (((BEq.beq s1_shareability Shareability_OSH) || (BEq.beq s2_shareability Shareability_OSH)) : Bool)
  then Shareability_OSH
  else
    (if (((BEq.beq s1_shareability Shareability_ISH) || (BEq.beq s2_shareability Shareability_ISH)) : Bool)
    then Shareability_ISH
    else Shareability_NSH)

def EffectiveShareability (memattrs : MemoryAttributes) : Shareability :=
  if (((BEq.beq memattrs.memtype MemType_Device) || ((memattrs.inner.attrs == MemAttr_NC) && (memattrs.outer.attrs == MemAttr_NC))) : Bool)
  then Shareability_OSH
  else memattrs.shareability

def DecodeDevice (device : (BitVec 2)) : SailM DeviceType := do
  match device with
  | 0b00 => (pure DeviceType_nGnRnE)
  | 0b01 => (pure DeviceType_nGnRE)
  | 0b10 => (pure DeviceType_nGRE)
  | 0b11 => (pure DeviceType_GRE)
  | _ => (do (undefined_DeviceType ()))

def S2CombineS1Device (s1_device : DeviceType) (s2_device : DeviceType) : DeviceType :=
  if (((BEq.beq s1_device DeviceType_nGnRnE) || (BEq.beq s2_device DeviceType_nGnRnE)) : Bool)
  then DeviceType_nGnRnE
  else
    (if (((BEq.beq s1_device DeviceType_nGnRE) || (BEq.beq s2_device DeviceType_nGnRE)) : Bool)
    then DeviceType_nGnRE
    else
      (if (((BEq.beq s1_device DeviceType_nGRE) || (BEq.beq s2_device DeviceType_nGRE)) : Bool)
      then DeviceType_nGRE
      else DeviceType_GRE))

def DecodeSDFAttr (rgn : (BitVec 2)) : SailM MemAttrHints := do
  let sdfattr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let sdfattr : MemAttrHints :=
    match rgn with
    | 0b00 => { sdfattr with attrs := MemAttr_NC }
    | 0b01 =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WB }
      { sdfattr with hints := MemHint_RWA })
    | 0b10 =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WT }
      { sdfattr with hints := MemHint_RA })
    | _ =>
      (let sdfattr : MemAttrHints := { sdfattr with attrs := MemAttr_WB }
      { sdfattr with hints := MemHint_RA })
  (pure { sdfattr with transient := false })

def DecodeLDFAttr (attr : (BitVec 4)) : SailM MemAttrHints := do
  let ldfattr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let ldfattr ← (( do
    (if ((let b__1 := attr
       if (((Sail.BitVec.extractLsb b__1 2 2) == (0#1 : (BitVec 1))) : Bool)
       then true
       else false : Bool) : Bool)
    then (do (pure { ldfattr with attrs := MemAttr_WT }))
    else
      (do (if ((attr == 0b0100#4) : Bool)
          then (do (pure { ldfattr with attrs := MemAttr_NC }))
          else
            (do (if ((let b__0 := attr
                   if (((Sail.BitVec.extractLsb b__0 2 2) == (1#1 : (BitVec 1))) : Bool)
                   then true
                   else false : Bool) : Bool)
                then (do (pure { ldfattr with attrs := MemAttr_WB }))
                else
                  (do (Unreachable ())
                      (pure ldfattr))))))) ) : SailM MemAttrHints )
  let ldfattr : MemAttrHints :=
    if ((ldfattr.attrs != MemAttr_NC) : Bool)
    then
      (match (Sail.BitVec.extractLsb attr 1 0) with
      | 0b00 => { ldfattr with hints := MemHint_No }
      | 0b01 => { ldfattr with hints := MemHint_WA }
      | 0b10 => { ldfattr with hints := MemHint_RA }
      | _ => { ldfattr with hints := MemHint_RWA })
    else ldfattr
  (if (((ldfattr.attrs != MemAttr_NC) && (ldfattr.hints != MemHint_No)) : Bool)
  then (do (pure { ldfattr with transient := (((BitVec.access attr 3) : BitVec 1) == 0#1) }))
  else (do (pure ldfattr)))

def S2DecodeCacheability (attr : (BitVec 2)) : SailM MemAttrHints := do
  let s2attr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let s2attr ← (( do
    match attr with
    | 0b01 => (pure { s2attr with attrs := MemAttr_NC })
    | 0b10 => (pure { s2attr with attrs := MemAttr_WT })
    | 0b11 => (pure { s2attr with attrs := MemAttr_WB })
    | _ =>
      (do
        match (← (ConstrainUnpredictable Unpredictable_S2RESMEMATTR)) with
        | .Constraint_NC => (pure { s2attr with attrs := MemAttr_NC })
        | .Constraint_WT => (pure { s2attr with attrs := MemAttr_WT })
        | .Constraint_WB => (pure { s2attr with attrs := MemAttr_WB })
        | _ => (pure s2attr)) ) : SailM MemAttrHints )
  let s2attr ← (pure { s2attr with hints := (← do (__UNKNOWN_bits 2)) })
  (pure { s2attr with transient := (← do (__UNKNOWN_boolean ())) })

def S2CombineS1AttrHints (s1_attrhints : MemAttrHints) (s2_attrhints : MemAttrHints) : SailM MemAttrHints := do
  let attrhints ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let attrhints : MemAttrHints :=
    if (((s1_attrhints.attrs == MemAttr_NC) || (s2_attrhints.attrs == MemAttr_NC)) : Bool)
    then { attrhints with attrs := MemAttr_NC }
    else
      (if (((s1_attrhints.attrs == MemAttr_WT) || (s2_attrhints.attrs == MemAttr_WT)) : Bool)
      then { attrhints with attrs := MemAttr_WT }
      else { attrhints with attrs := MemAttr_WB })
  (if ((attrhints.attrs != MemAttr_NC) : Bool)
  then
    (do let attrhints : MemAttrHints := { attrhints with hints := s1_attrhints.hints }
        (pure { attrhints with transient := s1_attrhints.transient }))
  else (do (pure attrhints)))

def WalkMemAttrs (sh : (BitVec 2)) (irgn : (BitVec 2)) (orgn : (BitVec 2)) : SailM MemoryAttributes := do
  let walkmemattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let walkmemattrs : MemoryAttributes := { walkmemattrs with memtype := MemType_Normal }
  let walkmemattrs ← (pure { walkmemattrs with shareability := (← do (DecodeShareability sh)) })
  let walkmemattrs ← (pure { walkmemattrs with inner := (← do (DecodeSDFAttr irgn)) })
  let walkmemattrs ← (pure { walkmemattrs with outer := (← do (DecodeSDFAttr orgn)) })
  let walkmemattrs : MemoryAttributes := { walkmemattrs with tags := MemTag_Untagged }
  let walkmemattrs : MemoryAttributes :=
    if (((walkmemattrs.inner.attrs == MemAttr_WB) && (walkmemattrs.outer.attrs == MemAttr_WB)) : Bool)
    then { walkmemattrs with xs := 0#1 }
    else { walkmemattrs with xs := 1#1 }
  (pure { walkmemattrs with notagaccess := false })

def NormalNCMemAttr (_ : Unit) : SailM MemoryAttributes := do
  let non_cacheable ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
  let non_cacheable : MemAttrHints := { non_cacheable with attrs := MemAttr_NC }
  let nc_memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let nc_memattrs : MemoryAttributes := { nc_memattrs with memtype := MemType_Normal }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with outer := non_cacheable }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with inner := non_cacheable }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with shareability := Shareability_OSH }
  let nc_memattrs : MemoryAttributes := { nc_memattrs with tags := MemTag_Untagged }
  (pure { nc_memattrs with notagaccess := false })

/-- Type quantifiers: k_s1aarch64 : Bool -/
def S1ConstrainUnpredictableRESMAIR (attr : (BitVec 8)) (s1aarch64 : Bool) : SailM Bool := do
  let b__0 := attr
  (if ((((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b01#2 : (BitVec 2)))) : Bool)
  then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
  else
    (do (if (((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) : Bool)
        then (do (pure ((Sail.BitVec.extractLsb attr 1 0) != 0b00#2)))
        else
          (do (if ((b__0 == (0x40#8 : (BitVec 8))) : Bool)
              then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
              else
                (do (if ((b__0 == (0xA0#8 : (BitVec 8))) : Bool)
                    then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveFeatXS ())))))))
                    else
                      (do (if ((b__0 == (0xF0#8 : (BitVec 8))) : Bool)
                          then (do (pure (! (←((pure s1aarch64) <&&> (do (HaveMTE2Ext ())))))))
                          else
                            (do (if (((Sail.BitVec.extractLsb b__0 3 0) == (0x0#4 : (BitVec 4))) : Bool)
                                then (do (pure true))
                                else (do (pure false)))))))))))))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def S1DecodeMemAttrs (attr_in : (BitVec 8)) (sh : (BitVec 2)) (s1aarch64 : Bool) (walkparams : S1TTWParams) : SailM MemoryAttributes := do
  let attr : (BitVec 8) := attr_in
  let attr ← (( do
    (if ((← (S1ConstrainUnpredictableRESMAIR attr s1aarch64)) : Bool)
    then
      (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESMAIR 8)
          (pure __tup_1))
    else (do (pure attr))) ) : SailM (BitVec 8) )
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    let b__0 := attr
    (if (((Sail.BitVec.extractLsb b__0 7 4) == (0x0#4 : (BitVec 4))) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          let memattrs ← (pure { memattrs with device := (← do (DecodeDevice (Sail.BitVec.extractLsb attr 3 2))) })
          (pure { memattrs with xs := if (s1aarch64 : Bool)
              then (Complement.complement ((BitVec.access attr 0) : BitVec 1))
              else 1#1 }))
    else
      (do (if ((b__0 == (0x40#8 : (BitVec 8))) : Bool)
          then
            (do sail_assert (←((pure s1aarch64) <&&> (do
                  (HaveFeatXS ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19262.41-19262.42"
                let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_NC } }
                let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_NC } }
                (pure { memattrs with xs := 0#1 }))
          else
            (do (if ((b__0 == (0xA0#8 : (BitVec 8))) : Bool)
                then
                  (do sail_assert (←((pure s1aarch64) <&&> (do
                        (HaveFeatXS ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19269.41-19269.42"
                      let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WT } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RA } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with transient := false } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WT } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RA } }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with transient := false } }
                      (pure { memattrs with xs := 0#1 }))
                else
                  (do (if ((b__0 == (0xF0#8 : (BitVec 8))) : Bool)
                      then
                        (do sail_assert (←((pure s1aarch64) <&&> (do
                              (HaveMTE2Ext ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19280.42-19280.43"
                            let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WB } }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RWA } }
                            let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with transient := false } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WB } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RWA } }
                            let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with transient := false } }
                            (pure { memattrs with xs := 0#1 }))
                      else
                        (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs ← (pure { memattrs with outer := (← do (DecodeLDFAttr (Sail.BitVec.extractLsb attr 7 4))) })
                            let memattrs ← (pure { memattrs with inner := (← do (DecodeLDFAttr (Sail.BitVec.extractLsb attr 3 0))) })
                            (if (((memattrs.inner.attrs == MemAttr_WB) && (memattrs.outer.attrs == MemAttr_WB)) : Bool)
                            then (do (pure { memattrs with xs := 0#1 }))
                            else (do (pure { memattrs with xs := 1#1 }))))))))))) ) : SailM MemoryAttributes )
  let memattrs : MemoryAttributes :=
    if ((s1aarch64 && (attr == 0b11110000#8)) : Bool)
    then { memattrs with tags := MemTag_AllocationTagged }
    else
      (if ((s1aarch64 && (walkparams.mtx == 1#1)) : Bool)
      then { memattrs with tags := MemTag_CanonicallyTagged }
      else { memattrs with tags := MemTag_Untagged })
  let memattrs : MemoryAttributes := { memattrs with notagaccess := false }
  (pure { memattrs with shareability := (← do (DecodeShareability sh)) })

def S2MemTagType (s2_memattrs : MemoryAttributes) (s1_tagtype : MemTagType) : SailM MemTagType := do
  (if ((! (← (HaveMTE2Ext ()))) : Bool)
  then (do (pure MemTag_Untagged))
  else
    (do (if (((((((((BEq.beq s1_tagtype MemTag_AllocationTagged) && (BEq.beq s2_memattrs.memtype MemType_Normal)) && (s2_memattrs.inner.attrs == MemAttr_WB)) && (s2_memattrs.inner.hints == MemHint_RWA)) && (! s2_memattrs.inner.transient)) && (s2_memattrs.outer.attrs == MemAttr_WB)) && (s2_memattrs.outer.hints == MemHint_RWA)) && (! s2_memattrs.outer.transient)) : Bool)
        then (do (pure MemTag_AllocationTagged))
        else
          (do (if ((bne s1_tagtype MemTag_AllocationTagged) : Bool)
              then (do (pure s1_tagtype))
              else (do (pure MemTag_Untagged)))))))

/-- Type quantifiers: k_s2aarch64 : Bool -/
def S2DecodeMemAttrs (attr : (BitVec 4)) (sh : (BitVec 2)) (s2aarch64 : Bool) : SailM MemoryAttributes := do
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    let b__0 := attr
    (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          (pure { memattrs with device := (← do (DecodeDevice (Sail.BitVec.extractLsb attr 1 0))) }))
    else
      (do (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
          then
            (do (if ((←((pure s2aarch64) <&&> (do
                     (HaveMTEPermExt ())))) : Bool)
                then
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability 0b11#2)) })
                      (pure { memattrs with inner := (← do (S2DecodeCacheability 0b11#2)) }))
                else
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 3 2))) })
                      (pure { memattrs with inner := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 1 0))) }))))
          else
            (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 3 2))) })
                (pure { memattrs with inner := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 1 0))) }))))) ) : SailM MemoryAttributes )
  let memattrs ← (pure { memattrs with shareability := (← do (DecodeShareability sh)) })
  (if ((←((pure s2aarch64) <&&> (do
       (HaveMTEPermExt ())))) : Bool)
  then (do (pure { memattrs with notagaccess := (attr == 0b0100#4) }))
  else (do (pure { memattrs with notagaccess := false })))

/-- Type quantifiers: k_s2aarch64 : Bool -/
def S2CombineS1MemAttrs (s1_memattrs : MemoryAttributes) (s2_memattrs : MemoryAttributes) (s2aarch64 : Bool) : SailM MemoryAttributes := do
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    (if (((BEq.beq s1_memattrs.memtype MemType_Device) && (BEq.beq s2_memattrs.memtype MemType_Device)) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          (pure { memattrs with device := (S2CombineS1Device s1_memattrs.device s2_memattrs.device) }))
    else
      (do (if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
          then (do (pure s1_memattrs))
          else
            (do (if ((BEq.beq s2_memattrs.memtype MemType_Device) : Bool)
                then (do (pure s2_memattrs))
                else
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with inner := (← do (S2CombineS1AttrHints s1_memattrs.inner s2_memattrs.inner)) })
                      (pure { memattrs with outer := (← do (S2CombineS1AttrHints s1_memattrs.outer s2_memattrs.outer)) }))))))) ) : SailM MemoryAttributes )
  let memattrs ← (pure { memattrs with tags := (← do (S2MemTagType memattrs s1_memattrs.tags)) })
  let memattrs ← (( do
    (if ((! (← (HaveMTEPermExt ()))) : Bool)
    then (do (pure { memattrs with notagaccess := false }))
    else (do (pure { memattrs with notagaccess := (s2_memattrs.notagaccess && (BEq.beq s1_memattrs.tags MemTag_AllocationTagged)) }))) ) : SailM MemoryAttributes )
  let memattrs : MemoryAttributes := { memattrs with shareability := (S2CombineS1Shareability s1_memattrs.shareability s2_memattrs.shareability) }
  let memattrs : MemoryAttributes :=
    if ((((BEq.beq memattrs.memtype MemType_Normal) && (memattrs.inner.attrs == MemAttr_WB)) && (memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then { memattrs with xs := 0#1 }
    else
      (if (s2aarch64 : Bool)
      then { memattrs with xs := (s2_memattrs.xs &&& s1_memattrs.xs) }
      else { memattrs with xs := s1_memattrs.xs })
  (pure { memattrs with shareability := (EffectiveShareability memattrs) })

def undefined_GPCCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_GPCCR_EL3_Type_GPC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_GPCCR_EL3_Type_L0GPTSZ (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_GPCCR_EL3_Type_ORGN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_GPCCR_EL3_Type_PGS (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_GPCCR_EL3_Type_PPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def DecodePPS (_ : Unit) : SailM Int := do
  match (_get_GPCCR_EL3_Type_PPS (← readReg GPCCR_EL3)) with
  | 0b000 => (pure 32)
  | 0b001 => (pure 36)
  | 0b010 => (pure 40)
  | 0b011 => (pure 42)
  | 0b100 => (pure 44)
  | 0b101 => (pure 48)
  | 0b110 => (pure 52)
  | _ =>
    (do
      (Unreachable ())
      (undefined_int ()))

def AbovePPS (address : (BitVec 56)) : SailM Bool := do
  let pps ← (( do (DecodePPS ()) ) : SailM Int )
  (if ((pps ≥b 56) : Bool)
  then (do (pure false))
  else (do (pure (! (is_zero_subrange address 55 pps)))))

/-- Type quantifiers: level : Int -/
def GPCFault (gpf : GPCF) (level : Int) : SailM GPCFRecord := do
  let fault ← (( do (undefined_GPCFRecord ()) ) : SailM GPCFRecord )
  let fault : GPCFRecord := { fault with gpf := gpf }
  (pure { fault with level := level })

def AArch64_PAMax (_ : Unit) : SailM Int := do
  let pamax ← (( do (__IMPDEF_integer "Maximum Physical Address Size") ) : SailM Int )
  sail_assert ((pamax == 32) || ((pamax == 36) || ((pamax == 40) || ((pamax == 42) || ((pamax == 44) || ((pamax == 48) || ((pamax == 52) || (pamax == 56)))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19468.120-19468.121"
  (pure pamax)

def GPCRegistersConsistent (_ : Unit) : SailM Bool := do
  (if ((←((pure ((_get_GPCCR_EL3_Type_PPS (← readReg GPCCR_EL3)) == 0b111#3)) <||> (do
       (pure ((← (DecodePPS ())) >b (← (AArch64_PAMax ()))))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)) == 0b11#2) : Bool)
        then (do (pure false))
        else
          (do (if (((_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) == 0b01#2) : Bool)
              then (do (pure false))
              else
                (do (if ((←((pure (((_get_GPCCR_EL3_Type_ORGN (← readReg GPCCR_EL3)) +++ (_get_GPCCR_EL3_Type_IRGN (← readReg GPCCR_EL3))) == 0b0000#4)) <&&> (do
                         (pure ((_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) != 0b10#2))))) : Bool)
                    then (do (pure false))
                    else (do (pure true)))))))))

def GPICheck (paspace : PASpace) (gpi : (BitVec 4)) : SailM Bool := do
  let questionMark := gpi
  (if ((questionMark == GPT_NoAccess) : Bool)
  then (do (pure false))
  else
    (do (if ((questionMark == GPT_Secure) : Bool)
        then
          (do sail_assert (← (HaveSecureEL2Ext ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:19498.35-19498.36"
              (pure (BEq.beq paspace PAS_Secure)))
        else
          (do (if ((questionMark == GPT_NonSecure) : Bool)
              then (do (pure (BEq.beq paspace PAS_NonSecure)))
              else
                (do (if ((questionMark == GPT_Root) : Bool)
                    then (do (pure (BEq.beq paspace PAS_Root)))
                    else
                      (do (if ((questionMark == GPT_Realm) : Bool)
                          then (do (pure (BEq.beq paspace PAS_Realm)))
                          else
                            (do (if ((questionMark == GPT_Any) : Bool)
                                then (do (pure true))
                                else
                                  (do (Unreachable ())
                                      (undefined_bool ())))))))))))))

def undefined_GPTBR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def GPIValid (gpi : (BitVec 4)) : SailM Bool := do
  (if ((gpi == GPT_Secure) : Bool)
  then (do (HaveSecureEL2Ext ()))
  else (do (pure ((gpi == GPT_NoAccess) || ((gpi == GPT_NonSecure) || ((gpi == GPT_Root) || ((gpi == GPT_Realm) || (gpi == GPT_Any))))))))

def GPTL0Size (_ : Unit) : SailM Int := SailME.run do
  match (_get_GPCCR_EL3_Type_L0GPTSZ (← readReg GPCCR_EL3)) with
  | 0b0000 => SailME.throw (GPTRange_1GB : Int)
  | 0b0100 => SailME.throw (GPTRange_16GB : Int)
  | 0b0110 => SailME.throw (GPTRange_64GB : Int)
  | 0b1001 => SailME.throw (GPTRange_512GB : Int)
  | _ => (Unreachable ())
  (pure 30)

def DecodeGPTBlock (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Block) "sail-arm/arm-v9.4-a/src/v8_base.sail:19559.37-19559.38"
  let result ← (( do (undefined_GPTEntry ()) ) : SailM GPTEntry )
  (if ((! (IsZero (Sail.BitVec.extractLsb entry 63 8))) : Bool)
  then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ())))))
  else
    (do (if ((! (← (GPIValid (Sail.BitVec.extractLsb entry 7 4)))) : Bool)
        then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ())))))
        else
          (do let result : GPTEntry := { result with gpi := (Sail.BitVec.extractLsb entry 7 4) }
              let result : GPTEntry := { result with level := 0 }
              let result : GPTEntry :=
                match pgs with
                | .PGS_4KB => { result with size := GPTRange_4KB }
                | .PGS_16KB => { result with size := GPTRange_16KB }
                | .PGS_64KB => { result with size := GPTRange_64KB }
              let result ← (pure { result with contig_size := (← do (GPTL0Size ())) })
              (pure (GPCF_None, result))))))

def DecodeGPTContiguous (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := SailME.run do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Contig) "sail-arm/arm-v9.4-a/src/v8_base.sail:19590.38-19590.39"
  let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCF × GPTEntry) GPTEntry )
  (if ((! (IsZero (Sail.BitVec.extractLsb entry 63 10))) : Bool)
  then (do (pure (GPCF_Walk, result)))
  else
    (do let result : GPTEntry := { result with gpi := (Sail.BitVec.extractLsb entry 7 4) }
        (if ((! (← (GPIValid result.gpi))) : Bool)
        then (do (pure (GPCF_Walk, result)))
        else
          (do let result : GPTEntry :=
                match pgs with
                | .PGS_4KB => { result with size := GPTRange_4KB }
                | .PGS_16KB => { result with size := GPTRange_16KB }
                | .PGS_64KB => { result with size := GPTRange_64KB }
              let result ← (( do
                match (Sail.BitVec.extractLsb entry 9 8) with
                | 0b01 => (pure { result with contig_size := GPTRange_2MB })
                | 0b10 => (pure { result with contig_size := GPTRange_32MB })
                | 0b11 => (pure { result with contig_size := GPTRange_512MB })
                | _ => SailME.throw (← do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ()))))) ) : SailME (GPCF × GPTEntry) GPTEntry )
              let result : GPTEntry := { result with level := 1 }
              (pure (GPCF_None, result))))))

/-- Type quantifiers: index : Int -/
def DecodeGPTGranules (pgs : PGSe) (index : Int) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := SailME.run do
  let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCF × GPTEntry) GPTEntry )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((! (← (GPIValid (BitVec.slice entry (i *i 4) 4)))) : Bool)
      then (do SailME.throw ((GPCF_Walk, result) : (GPCF × GPTEntry)))
      else (do (pure ())))
  (pure loop_vars)
  let result : GPTEntry := { result with gpi := (BitVec.slice entry (index *i 4) 4) }
  let result : GPTEntry :=
    match pgs with
    | .PGS_4KB => { result with size := GPTRange_4KB }
    | .PGS_16KB => { result with size := GPTRange_16KB }
    | .PGS_64KB => { result with size := GPTRange_64KB }
  let result : GPTEntry := { result with contig_size := result.size }
  let result : GPTEntry := { result with level := 1 }
  (pure (GPCF_None, result))

def DecodeGPTTable (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTTable) := do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Table) "sail-arm/arm-v9.4-a/src/v8_base.sail:19665.37-19665.38"
  let result ← (( do (undefined_GPTTable ()) ) : SailM GPTTable )
  (if ((! (IsZero ((Sail.BitVec.extractLsb entry 63 52) +++ (Sail.BitVec.extractLsb entry 11 4)))) : Bool)
  then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTTable ())))))
  else
    (do let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
        let p : Int := 12
        let p : Int :=
          match pgs with
          | .PGS_4KB => 12
          | .PGS_16KB => 14
          | .PGS_64KB => 16
        let p := p
        (if ((! (is_zero_subrange entry ((l0sz -i p) -i 2) 12)) : Bool)
        then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTTable ())))))
        else
          (do let result : GPTTable :=
                match pgs with
                | .PGS_4KB => { result with address := ((Sail.BitVec.extractLsb entry 55 17) +++ (Zeros (n := 17))) }
                | .PGS_16KB => { result with address := ((Sail.BitVec.extractLsb entry 55 15) +++ (Zeros (n := 15))) }
                | .PGS_64KB => { result with address := ((Sail.BitVec.extractLsb entry 55 13) +++ (Zeros (n := 13))) }
              (if ((← (AbovePPS result.address)) : Bool)
              then (do (pure (GPCF_AddressSize, (← (__UNKNOWN_GPTTable ())))))
              else (do (pure (GPCF_None, result))))))))

def DecodePGS (pgs : (BitVec 2)) : SailM PGSe := do
  match pgs with
  | 0b00 => (pure PGS_4KB)
  | 0b10 => (pure PGS_16KB)
  | 0b01 => (pure PGS_64KB)
  | _ =>
    (do
      (Unreachable ())
      (undefined_PGSe ()))

def GPIIndex (pa : (BitVec 56)) : SailM Int := do
  match (← (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)))) with
  | .PGS_4KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 15 12)))
  | .PGS_16KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 17 14)))
  | .PGS_64KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 19 16)))

def GPTLevel0Index (pa : (BitVec 56)) : SailM Int := do
  let pps ← (( do (DecodePPS ()) ) : SailM Int )
  let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
  (if ((pps ≤b l0sz) : Bool)
  then (do (pure 0))
  else
    (do sail_assert ((0 ≤b l0sz) && ((pps -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19758.51-19758.52"
        (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (pps -i 1) l0sz)))))

def GPTLevel1Index (pa : (BitVec 56)) : SailM Int := do
  let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
  match (← (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)))) with
  | .PGS_4KB =>
    (do
      sail_assert ((16 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19768.63-19768.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 16))))
  | .PGS_16KB =>
    (do
      sail_assert ((18 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19772.63-19772.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 18))))
  | .PGS_64KB =>
    (do
      sail_assert ((20 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19776.63-19776.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 20))))

def GPTTLBCache (pgs : PGSe) (gpt_entry : GPTEntry) : Unit :=
  ()

def GPTTLBLookup (pa : (BitVec 56)) (pgs : PGSe) : SailM GPTTLBLine := do
  (__UNKNOWN_GPTTLBLine ())

def CreatePhysMemRetStatus (fault : Fault) : PhysMemRetStatus :=
  { statuscode := fault
    extflag := 0#1
    merrorstate := ErrorState_Uncategorized
    store64bstatus := (Zeros (n := 64)) }

def undefined_GICC_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def GIC_PENDING_NONE : (BitVec 32) := 0x000003FF#32

def __GIC_InterruptID (intid : InterruptID) : (BitVec 32) :=
  let PPI_OFFSET := 16
  match intid with
  | .InterruptID_CNTP => (BitVec.addInt 0x0000000D#32 PPI_OFFSET)
  | .InterruptID_CNTHP => (BitVec.addInt 0x0000000A#32 PPI_OFFSET)
  | .InterruptID_CNTV => (BitVec.addInt 0x0000000B#32 PPI_OFFSET)
  | _ => GIC_PENDING_NONE

def __GIC_AcknowledgeInterrupt (_ : Unit) : SailM (BitVec 32) := do
  match (← readReg __GIC_Pending) with
  | .some intid =>
    (do
      writeReg __GIC_Pending none
      writeReg __GIC_Active (some intid)
      (pure (__GIC_InterruptID intid)))
  | none => (pure GIC_PENDING_NONE)

def AccessDescriptor_to_Access_kind (accdesc : AccessDescriptor) : (Access_kind arm_acc_type) :=
  match accdesc.acctype with
  | .AccessType_IFETCH => (AK_ifetch ())
  | .AccessType_GPR =>
    (let variety :=
      if (accdesc.exclusive : Bool)
      then AV_exclusive
      else
        (if (accdesc.atomicop : Bool)
        then AV_atomic_rmw
        else AV_plain)
    let strength :=
      if (accdesc.acqpc : Bool)
      then AS_acq_rcpc
      else
        (if ((accdesc.acqsc || accdesc.relsc) : Bool)
        then AS_rel_or_acq
        else AS_normal)
    (AK_explicit
      { variety := variety
        strength := strength }))
  | .AccessType_TTW => (AK_ttw ())
  | .AccessType_ASIMD => (AK_arch (SAcc_ASIMD accdesc.streamingsve))
  | .AccessType_SVE => (AK_arch (SAcc_SVE accdesc.streamingsve))
  | .AccessType_SME => (AK_arch (SAcc_SME accdesc.streamingsve))
  | .AccessType_IC => (AK_arch (SAcc_IC ()))
  | .AccessType_DC => (AK_arch (SAcc_DC ()))
  | .AccessType_DCZero => (AK_arch (SAcc_DCZero ()))
  | .AccessType_AT => (AK_arch (SAcc_AT ()))
  | .AccessType_NV2 => (AK_arch (SAcc_NV2 ()))
  | .AccessType_SPE => (AK_arch (SAcc_SPE ()))
  | .AccessType_GCS => (AK_arch (SAcc_GCS ()))
  | .AccessType_GPTW => (AK_arch (SAcc_GPTW ()))

/-- Type quantifiers: size : Nat, size > 0 -/
def read_request (accdesc : AccessDescriptor) (ti : (Option TranslationInfo)) (size : Nat) (va : (BitVec 64)) (pa : (BitVec 56)) : (Mem_read_request size 64 (BitVec 56) (Option TranslationInfo) arm_acc_type) :=
  { access_kind := (AccessDescriptor_to_Access_kind accdesc)
    va := (some va)
    pa := pa
    translation := ti
    size := size
    tag := false }

def GIC_BASE := 0x2C00#16

def gic_read_ram (offset : (BitVec 16)) : SailM (BitVec 32) := do
  let accdesc ← do (CreateAccDescGPR MemOp_LOAD false true false)
  let pa := (Sail.BitVec.zeroExtend (GIC_BASE +++ offset) 56)
  match (← (sail_mem_read (read_request accdesc none 4 (Sail.BitVec.zeroExtend pa 64) pa))) with
  | .Ok (value, _) => (pure value)
  | .Err _ =>
    (do
      sail_assert false "sail-arm/arm-v9.4-a/src/devices.sail:134.18-134.19"
      throw Error.Exit)

def __GICC_IIDR := 0x0002043B#32

def __GICD_TYPER := (Sail.BitVec.updateSubrange (Sail.BitVec.updateSubrange (Zeros (n := 32)) 10 10 1#1) 4 0 0b00111#5)

def __ReadGIC (offset : (BitVec 16)) : SailM (BitVec 32) := do
  match offset with
  | 0x1004 => (pure __GICD_TYPER)
  | 0x1800 => (pure 0xFFFFFFFF#32)
  | 0x1C04 =>
    (do
      (pure (prerr_bits "[GIC] Read 1C04: " (← (gic_read_ram 0x1C04#16))))
      (gic_read_ram 0x1C04#16))
  | 0x2000 =>
    (do
      (pure (prerr_bits "[GIC] Read GICC_CTLR " (← readReg GICC_CTLR)))
      readReg GICC_CTLR)
  | 0x200C =>
    (do
      let intid ← (( do (__GIC_AcknowledgeInterrupt ()) ) : SailM (BitVec 32) )
      let _ : Unit := (prerr_bits "[GIC] Acknowledged interrupt " intid)
      (pure intid))
  | 0x20FC => (pure __GICC_IIDR)
  | _ =>
    (let _ : Unit := (prerr_bits "[GIC] Read offset: " offset)
    (pure (Zeros (n := 32))))

/-- Type quantifiers: n : Nat, n > 0 -/
def __ReadUART (offset : (BitVec 16)) (n : Nat) : (BitVec (8 * n)) :=
  match offset with
  | _ =>
    (let _ : Unit := (prerr_bits "[UART] Unknown read offset: " offset)
    (Zeros (n := (8 *i n))))

def UART_BASE := 0x3C00#16

/-- Type quantifiers: size : Nat, size > 0 -/
def PhysMemRead (desc : AddressDescriptor) (size : Nat) (accdesc : AccessDescriptor) (translation_info : (Option TranslationInfo)) : SailM (PhysMemRetStatus × (BitVec (8 * size))) := do
  let paddress := desc.paddress.address
  (if (((size ≥b 4) && ((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) GIC_BASE))) : Bool)
  then (do (pure ((CreatePhysMemRetStatus Fault_None), (Sail.BitVec.zeroExtend (← (__ReadGIC (Sail.BitVec.extractLsb paddress 15 0))) (8 *i size)))))
  else
    (do (if (((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) UART_BASE)) : Bool)
        then (do (pure ((CreatePhysMemRetStatus Fault_None), (__ReadUART (Sail.BitVec.extractLsb paddress 15 0) size))))
        else
          (do match (← (sail_mem_read (read_request accdesc translation_info size desc.vaddress desc.paddress.address))) with
              | .Ok (value, _) => (pure ((CreatePhysMemRetStatus Fault_None), value))
              | .Err statuscode => (pure ((CreatePhysMemRetStatus statuscode), (BitVec.zero (8 *i size))))))))

def GPTWalk (pa : (BitVec 56)) (accdesc : AccessDescriptor) : SailM (GPCFRecord × GPTEntry) := SailME.run do
  let gpi_index ← (( do (undefined_int ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let gpttlbline ← (( do (undefined_GPTTLBLine ()) ) : SailME (GPCFRecord × GPTEntry) GPTTLBLine )
  let pgs ← (( do (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3))) ) : SailME (GPCFRecord × GPTEntry) PGSe )
  (if ((← readReg __tlb_enabled) : Bool)
  then
    (do let gpttlbline ← (( do (GPTTLBLookup pa pgs) ) : SailME (GPCFRecord × GPTEntry) GPTTLBLine )
        (if (gpttlbline.valid_name : Bool)
        then (do SailME.throw (← do (pure ((← (GPCNoFault ())), gpttlbline.gpt_entry))))
        else (do (pure ()))))
  else (do (pure ())))
  let base ← (( do (pure (Sail.BitVec.zeroExtend ((_get_GPTBR_EL3_Type_BADDR (← readReg GPTBR_EL3)) +++ (Zeros (n := 12))) 56)) ) : SailME (GPCFRecord × GPTEntry) (BitVec 56) )
  let pps ← (( do (DecodePPS ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let l0sz ← (( do (GPTL0Size ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let alignment := (Max.max ((pps -i l0sz) +i 3) 12)
  sail_assert (56 ≥b alignment) "sail-arm/arm-v9.4-a/src/v8_base.sail:19809.39-19809.40"
  let base : (BitVec 56) := (base &&& (Complement.complement (Sail.BitVec.zeroExtend (Ones (n := alignment)) 56)))
  let gptaccdesc ← (( do (CreateAccDescGPTW accdesc) ) : SailME (GPCFRecord × GPTEntry) AccessDescriptor )
  let gptaddrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailME (GPCFRecord × GPTEntry) AddressDescriptor )
  let gptaddrdesc ← (pure { gptaddrdesc with memattrs := (← do (WalkMemAttrs (_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) (_get_GPCCR_EL3_Type_ORGN (← readReg GPCCR_EL3)) (_get_GPCCR_EL3_Type_IRGN (← readReg GPCCR_EL3)))) })
  let gptaddrdesc ← (pure { gptaddrdesc with fault := (← do (NoFault__1 gptaccdesc)) })
  let gptaddrdesc : AddressDescriptor := { gptaddrdesc with paddress := { gptaddrdesc.paddress with paspace := PAS_Root } }
  let gptaddrdesc ← (pure { gptaddrdesc with paddress := (← do (pure { gptaddrdesc.paddress with address := (← do (pure (BitVec.addInt base ((← (GPTLevel0Index pa)) *i 8)))) })) })
  let level_0_entry ← (( do (undefined_bitvector 64) ) : SailME (GPCFRecord × GPTEntry) (BitVec 64) )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailME (GPCFRecord × GPTEntry) PhysMemRetStatus )
  let (level_0_entry, memstatus) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead gptaddrdesc 8 gptaccdesc none)
    let memstatus : PhysMemRetStatus := tup__0
    let level_0_entry : (BitVec 64) := tup__1
    (pure (level_0_entry, memstatus)) ) : SailME (GPCFRecord × GPTEntry) ((BitVec 64) × PhysMemRetStatus) )
  (if ((IsFault__2 memstatus) : Bool)
  then (do (pure ((← (GPCFault GPCF_EABT 0)), (← (__UNKNOWN_GPTEntry ())))))
  else
    (do let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCFRecord × GPTEntry) GPTEntry )
        let table ← (( do (undefined_GPTTable ()) ) : SailME (GPCFRecord × GPTEntry) GPTTable )
        let gpf ← (( do (undefined_GPCF ()) ) : SailME (GPCFRecord × GPTEntry) GPCF )
        let (gpf, result, table) ← (( do
          let questionMark := (Sail.BitVec.extractLsb level_0_entry 3 0)
          let (gpf, result, table) ← (( do
            (if ((questionMark == GPT_Block) : Bool)
            then
              (do let a__1749 ← (( do
                    let (gpf, result) ← (( do
                      let (tup__0, tup__1) ← do (DecodeGPTBlock pgs level_0_entry)
                      let gpf : GPCF := tup__0
                      let result : GPTEntry := tup__1
                      (pure (gpf, result)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
                    let result : GPTEntry := { result with pa := pa }
                    (if (((← readReg __tlb_enabled) && (BEq.beq gpf GPCF_None)) : Bool)
                    then (do (pure (GPTTLBCache pgs result)))
                    else (do (pure ())))
                    (pure ((← (GPCFault gpf 0)), result)) ) : SailME (GPCFRecord × GPTEntry) (GPCFRecord × GPTEntry) )
                  SailME.throw a__1749)
            else
              (do let (gpf, table) ← (( do
                    (if ((questionMark == GPT_Table) : Bool)
                    then
                      (do let (gpf, table) ← (( do
                            let (tup__0, tup__1) ← do (DecodeGPTTable pgs level_0_entry)
                            let gpf : GPCF := tup__0
                            let table : GPTTable := tup__1
                            (pure (gpf, table)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTTable) )
                          (if ((bne gpf GPCF_None) : Bool)
                          then (do SailME.throw (← do (pure ((← (GPCFault gpf 0)), (← (__UNKNOWN_GPTEntry ()))))))
                          else (do (pure ())))
                          (pure (gpf, table)))
                    else (do SailME.throw (← do (pure ((← (GPCFault GPCF_Walk 0)), (← (__UNKNOWN_GPTEntry ()))))))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTTable) )
                  (pure (gpf, result, table)))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry × GPTTable) )
          (pure (gpf, result, table)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry × GPTTable) )
        sail_assert ((Sail.BitVec.extractLsb level_0_entry 3 0) == GPT_Table) "sail-arm/arm-v9.4-a/src/v8_base.sail:19846.45-19846.46"
        let offset ← (( do (pure ((← (GPTLevel1Index pa)) *i 8)) ) : SailME (GPCFRecord × GPTEntry) Int )
        let gptaddrdesc : AddressDescriptor := { gptaddrdesc with paddress := { gptaddrdesc.paddress with address := (BitVec.addInt table.address offset) } }
        let level_1_entry ← (( do (undefined_bitvector 64) ) : SailME (GPCFRecord × GPTEntry) (BitVec 64) )
        let (level_1_entry, memstatus) ← (( do
          let (tup__0, tup__1) ← do (PhysMemRead gptaddrdesc 8 gptaccdesc none)
          let memstatus : PhysMemRetStatus := tup__0
          let level_1_entry : (BitVec 64) := tup__1
          (pure (level_1_entry, memstatus)) ) : SailME (GPCFRecord × GPTEntry) ((BitVec 64) × PhysMemRetStatus) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (pure ((← (GPCFault GPCF_EABT 1)), (← (__UNKNOWN_GPTEntry ())))))
        else
          (do let (gpf, result) ← (( do
                let questionMark := (Sail.BitVec.extractLsb level_1_entry 3 0)
                let (gpf, result) ← (( do
                  (if ((questionMark == GPT_Contig) : Bool)
                  then
                    (do let (tup__0, tup__1) ← do (DecodeGPTContiguous pgs level_1_entry)
                        let gpf : GPCF := tup__0
                        let result : GPTEntry := tup__1
                        (pure (gpf, result)))
                  else
                    (do let gpi_index ← (( do (GPIIndex pa) ) : SailME (GPCFRecord × GPTEntry) Int )
                        let (tup__0, tup__1) ← do (DecodeGPTGranules pgs gpi_index level_1_entry)
                        let gpf : GPCF := tup__0
                        let result : GPTEntry := tup__1
                        (pure (gpf, result)))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
                (pure (gpf, result)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
              (if ((bne gpf GPCF_None) : Bool)
              then (do (pure ((← (GPCFault gpf 1)), (← (__UNKNOWN_GPTEntry ())))))
              else
                (do let result : GPTEntry := { result with pa := pa }
                    (if ((← readReg __tlb_enabled) : Bool)
                    then (do (pure (GPTTLBCache pgs result)))
                    else (do (pure ())))
                    (pure ((← (GPCNoFault ())), result))))))))

/-- Type quantifiers: gpt_range : Int -/
def SetTLBIncludesGPT (context : TLBContext) (gpt_range : Int) : Unit :=
  ()

def TLBIncludesGPT (context : TLBContext) : SailM Bool := do
  (__UNKNOWN_boolean ())

def GranuleProtectionCheck (addrdesc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM GPCFRecord := SailME.run do
  let gpcf ← (( do (undefined_GPCFRecord ()) ) : SailME GPCFRecord GPCFRecord )
  let gpt_entry ← (( do (undefined_GPTEntry ()) ) : SailME GPCFRecord GPTEntry )
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:19882.20-19882.21"
  (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
  then
    (do (if ((← (TLBIncludesGPT addrdesc.tlbcontext)) : Bool)
        then (do SailME.throw (← do (GPCNoFault ())))
        else (do (pure ()))))
  else (do (pure ())))
  let address : FullAddress := addrdesc.paddress
  (if (((_get_GPCCR_EL3_Type_GPC (← readReg GPCCR_EL3)) == 0#1) : Bool)
  then
    (do (if ((← readReg __tlb_enabled) : Bool)
        then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext 56)))
        else (do (pure ())))
        (GPCNoFault ()))
  else
    (do (if ((! (← (GPCRegistersConsistent ()))) : Bool)
        then (do (GPCFault GPCF_Walk 0))
        else
          (do (if ((← (AbovePPS address.address)) : Bool)
              then
                (do (if ((BEq.beq address.paspace PAS_NonSecure) : Bool)
                    then
                      (do (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
                          then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext 56)))
                          else (do (pure ())))
                          (GPCNoFault ()))
                    else (do (GPCFault GPCF_Fail 0))))
              else
                (do let gpt_base ← (( do (pure (Sail.BitVec.zeroExtend ((_get_GPTBR_EL3_Type_BADDR (← readReg GPTBR_EL3)) +++ (Zeros (n := 12))) 56)) ) : SailME GPCFRecord (BitVec 56) )
                    (if ((← (AbovePPS gpt_base)) : Bool)
                    then (do (GPCFault GPCF_AddressSize 0))
                    else
                      (do let (gpcf, gpt_entry) ← (( do
                            let (tup__0, tup__1) ← do (GPTWalk address.address accdesc)
                            let gpcf : GPCFRecord := tup__0
                            let gpt_entry : GPTEntry := tup__1
                            (pure (gpcf, gpt_entry)) ) : SailME GPCFRecord (GPCFRecord × GPTEntry) )
                          (if ((bne gpcf.gpf GPCF_None) : Bool)
                          then (do (pure gpcf))
                          else
                            (do let permitted ← (( do (GPICheck address.paspace gpt_entry.gpi) ) : SailME GPCFRecord Bool )
                                (if ((! permitted) : Bool)
                                then (do (GPCFault GPCF_Fail gpt_entry.level))
                                else
                                  (do (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
                                      then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext gpt_entry.contig_size)))
                                      else (do (pure ())))
                                      (GPCNoFault ())))))))))))))

/-- Type quantifiers: N : Nat, List.elem N [32, 64, 128] -/
def FetchDescriptor (ee : (BitVec 1)) (walkaddress : AddressDescriptor) (walkaccess : AccessDescriptor) (fault_in : FaultRecord) (N : Nat) (translation_info : TranslationInfo) : SailM (FaultRecord × (BitVec N)) := SailME.run do
  sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19932.41-19932.42"
  let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × (BitVec N)) (BitVec N) )
  let fault : FaultRecord := fault_in
  let fault ← (( do
    (if ((← (HaveRME ())) : Bool)
    then
      (do let fault ← (pure { fault with gpcf := (← do (GranuleProtectionCheck walkaddress walkaccess)) })
          (if ((bne fault.gpcf.gpf GPCF_None) : Bool)
          then
            (do let a__1737 ← (( do
                  let fault : FaultRecord := { fault with statuscode := Fault_GPCFOnWalk }
                  let fault : FaultRecord := { fault with paddress := walkaddress.paddress }
                  let fault : FaultRecord := { fault with gpcfs2walk := fault.secondstage }
                  (pure (fault, (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × (BitVec N)) (FaultRecord × (BitVec N)) )
                SailME.throw a__1737)
          else (do (pure fault))))
    else (do (pure fault))) ) : SailME (FaultRecord × (BitVec N)) FaultRecord )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailME (FaultRecord × (BitVec N)) PhysMemRetStatus )
  let (descriptor, memstatus) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead walkaddress (Int.ediv N 8) walkaccess (some translation_info))
    let memstatus : PhysMemRetStatus := tup__0
    let descriptor : (BitVec N) := tup__1
    (pure (descriptor, memstatus)) ) : SailME (FaultRecord × (BitVec N)) ((BitVec N) × PhysMemRetStatus) )
  let fault ← (( do
    (if ((IsFault__2 memstatus) : Bool)
    then
      (do let iswrite : Bool := false
          let fault ← (HandleExternalTTWAbort memstatus iswrite walkaddress walkaccess (Int.ediv N 8) fault)
          (if ((IsFault__1 fault.statuscode) : Bool)
          then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_bits N))))))
          else (do (pure ())))
          (pure fault))
    else (do (pure fault))) ) : SailME (FaultRecord × (BitVec N)) FaultRecord )
  let descriptor : (BitVec N) :=
    if ((ee == 1#1) : Bool)
    then (reverse_endianness descriptor)
    else descriptor
  let descriptor := descriptor
  (pure (fault, descriptor))

/-- Type quantifiers: level : Int -/
def ContiguousSize (d128 : (BitVec 1)) (tgx : TGx) (level : Int) : SailM Int := do
  (if ((d128 == 1#1) : Bool)
  then
    (do match tgx with
        | .TGx_4KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19968.57-19968.58"
            (if ((level == 1) : Bool)
            then (do (pure 2))
            else (do (pure 4))))
        | .TGx_16KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19972.57-19972.58"
            (if ((level == 1) : Bool)
            then (do (pure 2))
            else
              (do (if ((level == 2) : Bool)
                  then (do (pure 4))
                  else (do (pure 6))))))
        | .TGx_64KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19982.44-19982.45"
            (if ((level == 2) : Bool)
            then (do (pure 6))
            else (do (pure 4)))))
  else
    (do match tgx with
        | .TGx_4KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19992.57-19992.58"
            (pure 4))
        | .TGx_16KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19996.44-19996.45"
            (if ((level == 2) : Bool)
            then (do (pure 5))
            else (do (pure 7))))
        | .TGx_64KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20000.44-20000.45"
            (pure 5))))

def TGxGranuleBits (tgx : TGx) : Int :=
  match tgx with
  | .TGx_4KB => 12
  | .TGx_16KB => 14
  | .TGx_64KB => 16

/-- Type quantifiers: level : Int -/
def TranslationSize (d128 : (BitVec 1)) (tgx : TGx) (level : Int) : Int :=
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let blockbits := ((FINAL_LEVEL -i level) *i (granulebits -i descsizelog2))
  (granulebits +i blockbits)

def StageOA (ia : (BitVec 64)) (d128 : (BitVec 1)) (tgx : TGx) (walkstate : TTWState) : SailM FullAddress := do
  let oa ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let csize ← (( do (undefined_int ()) ) : SailM Int )
  let tsize := (TranslationSize d128 tgx walkstate.level)
  let csize ← (( do
    (if ((walkstate.contiguous == 1#1) : Bool)
    then (do (ContiguousSize d128 tgx walkstate.level))
    else (do (pure 0))) ) : SailM Int )
  let csize := csize
  let ia_msb := (tsize +i csize)
  let oa : FullAddress := { oa with paspace := walkstate.baseaddress.paspace }
  sail_assert ((0 ≤b ia_msb) && (ia_msb ≤b 55)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20052.53-20052.54"
  sail_assert (0 ≤b (ia_msb -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20053.39-20053.40"
  (pure { oa with address := ((Sail.BitVec.extractLsb walkstate.baseaddress.address 55 ia_msb) +++ (Sail.BitVec.extractLsb ia (ia_msb -i 1) 0)) })

def DecodePASpace (nse : (BitVec 1)) (ns : (BitVec 1)) : SailM PASpace := do
  match (nse +++ ns) with
  | 0b00 => (pure PAS_Secure)
  | 0b01 => (pure PAS_NonSecure)
  | 0b10 => (pure PAS_Root)
  | 0b11 => (pure PAS_Realm)
  | _ => (do (undefined_PASpace ()))

def HasUnprivileged (regime : Regime) : Bool :=
  ((BEq.beq regime Regime_EL20) || ((BEq.beq regime Regime_EL30) || (BEq.beq regime Regime_EL10)))

def CreateAddressDescriptor (va : (BitVec 64)) (pa : FullAddress) (memattrs : MemoryAttributes) : SailM AddressDescriptor := do
  let addrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let addrdesc : AddressDescriptor := { addrdesc with paddress := pa }
  let addrdesc : AddressDescriptor := { addrdesc with vaddress := va }
  let addrdesc : AddressDescriptor := { addrdesc with memattrs := memattrs }
  let addrdesc ← (pure { addrdesc with fault := (← do (NoFault ())) })
  (pure { addrdesc with s1assured := false })

def CreateFaultyAddressDescriptor (va : (BitVec 64)) (fault : FaultRecord) : SailM AddressDescriptor := do
  let addrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let addrdesc : AddressDescriptor := { addrdesc with vaddress := va }
  (pure { addrdesc with fault := fault })

def AlignmentFault (accdesc : AccessDescriptor) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_Alignment }
  let fault : FaultRecord := { fault with access := accdesc }
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with write := ((! accdesc.read) && accdesc.write) }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

def AArch64_MaxTxSZ (tgx : TGx) : SailM Int := do
  (if ((← (HaveSmallTranslationTableExt ())) : Bool)
  then
    (do match tgx with
        | .TGx_4KB => (pure 48)
        | .TGx_16KB => (pure 48)
        | .TGx_64KB => (pure 47))
  else (do (pure 39)))

def AArch64_S1MinTxSZ (regime : Regime) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) : SailM Int := do
  (if (((← (Have56BitVAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do (if ((HasUnprivileged regime) : Bool)
        then (do (pure 9))
        else (do (pure 8))))
  else
    (do (if ((((← (Have52BitVAExt ())) && (BEq.beq tgx TGx_64KB)) || (ds == 1#1)) : Bool)
        then (do (pure 12))
        else (do (pure 16)))))

def AArch64_S1TxSZFaults (regime : Regime) (walkparams : S1TTWParams) : SailM Bool := do
  let mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailM Int )
  let maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailM Int )
  (if (((BitVec.toNat walkparams.txsz) <b mintxsz) : Bool)
  then (do (Have52BitVAExt ()) <||> (do (__IMPDEF_boolean "Fault on TxSZ value below minimum")))
  else
    (do (if (((BitVec.toNat walkparams.txsz) >b maxtxsz) : Bool)
        then (do (__IMPDEF_boolean "Fault on TxSZ value above maximum"))
        else (do (pure false)))))

def AArch64_PACEffectiveTxSZ (regime : Regime) (walkparams : S1TTWParams) : SailM (BitVec 6) := SailME.run do
  let s1maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (BitVec 6) Int )
  let s1mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailME (BitVec 6) Int )
  (if ((← (AArch64_S1TxSZFaults regime walkparams)) : Bool)
  then
    (do (if ((BEq.beq (← (ConstrainUnpredictable Unpredictable_RESTnSZ)) Constraint_FORCE) : Bool)
        then
          (do (if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
              then (do SailME.throw ((integer_subrange s1mintxsz 5 0) : (BitVec 6)))
              else
                (do (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
                    then (do SailME.throw ((integer_subrange s1maxtxsz 5 0) : (BitVec 6)))
                    else (do (pure ()))))))
        else (do (pure ()))))
  else
    (do (if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
        then (do SailME.throw ((integer_subrange s1mintxsz 5 0) : (BitVec 6)))
        else
          (do (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
              then (do SailME.throw ((integer_subrange s1maxtxsz 5 0) : (BitVec 6)))
              else (do (pure ())))))))
  (pure walkparams.txsz)

def AArch64_GetVARange (va : (BitVec 64)) : VARange :=
  if ((((BitVec.access va 55) : BitVec 1) == 0#1) : Bool)
  then VARange_LOWER
  else VARange_UPPER

def AArch64_HaveS1TG (tgx : TGx) : SailM Bool := do
  match tgx with
  | .TGx_4KB => (__IMPDEF_boolean "Has 4K Translation Granule")
  | .TGx_16KB => (__IMPDEF_boolean "Has 16K Translation Granule")
  | .TGx_64KB => (__IMPDEF_boolean "Has 64K Translation Granule")

def AArch64_S1DecodeTG0 (tg0_in : (BitVec 2)) : SailM TGx := do
  let tg0 : (BitVec 2) := tg0_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg0 ← (( do
    (if ((tg0 == 0b11#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG0 encoded granule size"))
    else (do (pure tg0))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg0 with
    | 0b00 => TGx_4KB
    | 0b01 => TGx_64KB
    | 0b10 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS1TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG0 encoded granule size")) with
        | 0b00 => (pure TGx_4KB)
        | 0b01 => (pure TGx_64KB)
        | 0b10 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def AArch64_S1DecodeTG1 (tg1_in : (BitVec 2)) : SailM TGx := do
  let tg1 : (BitVec 2) := tg1_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg1 ← (( do
    (if ((tg1 == 0b00#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG1 encoded granule size"))
    else (do (pure tg1))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg1 with
    | 0b10 => TGx_4KB
    | 0b11 => TGx_64KB
    | 0b01 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS1TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG1 encoded granule size")) with
        | 0b10 => (pure TGx_4KB)
        | 0b11 => (pure TGx_64KB)
        | 0b01 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def IsTCR2EL1Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatTCR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_TCR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_TCR2En (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (pure true)))))))

def undefined_MAIR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MAIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TCR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_TCR2_EL1_Type_DisCH1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_TCR2_EL2_Type_DisCH1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def AArch64_S1TTWParamsEL10 (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL1_Type_D128 (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL1_Type_TG0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T0SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI0 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL1_Type_SKL (← (TTBR0_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH0 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL1_Type_TG1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T1SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI1 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL1_Type_SKL (← (TTBR1_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH1 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL1)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL1Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL1_Type_AIE (← readReg TCR2_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL1_Type_WXN (← readReg SCTLR_EL1)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL1_Type_IPS (← readReg TCR_EL1)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL1_Type_EE (← readReg SCTLR_EL1)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with dc := (← do (pure (_get_HCR_EL2_Type_DC (← readReg HCR_EL2)))) })
          (pure { walkparams with dct := (← do
              (if ((← (HaveMTE2Ext ())) : Bool)
              then (do (pure (_get_HCR_EL2_Type_DCT (← readReg HCR_EL2))))
              else (do (pure 0#1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL1_Type_nTLSMD (← readReg SCTLR_EL1)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do (if ((((_get_HCR_EL2_Type_NV (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2))) == 0b01#2) : Bool)
          then
            (do match (← (ConstrainUnpredictable Unpredictable_NVNV1)) with
                | .Constraint_NVNV1_00 => (pure { walkparams with nv1 := 0#1 })
                | .Constraint_NVNV1_01 => (pure { walkparams with nv1 := 1#1 })
                | .Constraint_NVNV1_11 => (pure { walkparams with nv1 := 1#1 })
                | _ => (pure walkparams))
          else (do (pure { walkparams with nv1 := (← do (pure (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)))) }))))
    else (do (pure { walkparams with nv1 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL1_Type_CMOW (← readReg SCTLR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HA (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HD (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL1_Type_DS (← readReg TCR_EL1)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL1Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_PIE (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL1)))) })
          (if ((walkparams.nv1 != 1#1) : Bool)
          then (do (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL1)))) }))
          else (do (pure walkparams))))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EPAN (← readReg SCTLR_EL1))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL1_Type_PnCH (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL1_Type_HAFT (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((←((HaveFeatMEC ()) <&&> (do
           (IsSCTLR2EL2Enabled ())))) : Bool)
      then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
      else (do (pure 0#1)))) })

def IsTCR2EL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatTCR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_TCR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def undefined_MAIR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MAIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TCR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_TCR2_EL2_Type_AMEC0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_TCR2_EL2_Type_AMEC1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def AArch64_S1TTWParamsEL2 (ss : SecurityState) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_PS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_TBID (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_HPD (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with pie := (← do
        (if ((←((HaveS1PIExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_MTX (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with pnch := (← do
        (if ((←((HaveTHExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then (do (pure { walkparams with amec := (← do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2)))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_PIRE0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def AArch64_S1TTWParamsEL20 (ss : SecurityState) (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL2_Type_D128 (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI0 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL2_Type_SKL (← (TTBR0_EL2_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH0 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL2_Type_TG1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T1SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI1 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL2_Type_SKL (← readReg TTBR1_EL2))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH1 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_IPS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL2_Type_nTLSMD (← readReg SCTLR_EL2)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL2_Type_CMOW (← readReg SCTLR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL2Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) })
          (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL2_Type_EPAN (← readReg SCTLR_EL2))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then
    (do (pure { walkparams with amec := (← do
            (if ((BEq.beq varange VARange_LOWER) : Bool)
            then (do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2))))
            else (do (pure (_get_TCR2_EL2_Type_AMEC1 (← readReg TCR2_EL2)))))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_MAIR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MAIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SCTLR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TTBR0_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def AArch64_S1TTWParamsEL3 (_ : Unit) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL3_Type_TG0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL3_Type_T0SZ (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL3_Type_PS (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL3_Type_IRGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL3_Type_ORGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL3_Type_SH0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL3_Type_TBI (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL3)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((← (HaveAIEExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_AIE (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL3_Type_WXN (← readReg SCTLR_EL3)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL3_Type_EE (← readReg SCTLR_EL3)))) })
  let walkparams ←
    (pure { walkparams with sif := (← do
        (if ((←((pure (! (← (HaveRME ())))) <||> (do
             (HaveSecureEL2Ext ())))) : Bool)
        then (do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_TBID (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HPD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HA (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL3_Type_DS (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_D128 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with skl := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TTBR0_EL3_Type_SKL (← readReg TTBR0_EL3))))
        else (do (pure 0b00#2)))) })
  let walkparams ←
    (pure { walkparams with disch := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TCR_EL3_Type_DisCH0 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((← (HaveS1PIExt ())) : Bool)
              then (do (pure (_get_TCR_EL3_Type_PIE (← readReg TCR_EL3))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_MTX (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 == 0#1)) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR_EL3_Type_PnCH (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR_EL3_Type_HAFT (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((← (HaveFeatMEC ())) : Bool)
      then (do (pure (_get_SCTLR2_EL3_Type_EMEC (← readReg SCTLR2_EL3))))
      else (do (pure 0#1)))) })

def AArch64_GetS1TTWParams (regime : Regime) (ss : SecurityState) (va : (BitVec 64)) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL3 => (do (AArch64_S1TTWParamsEL3 ()))
  | .Regime_EL2 => (do (AArch64_S1TTWParamsEL2 ss))
  | .Regime_EL20 => (do (AArch64_S1TTWParamsEL20 ss varange))
  | .Regime_EL10 => (do (AArch64_S1TTWParamsEL10 varange))
  | _ => (pure walkparams)

def CalculateBottomPACBit (top_bit : (BitVec 1)) : SailM Int := do
  let regime ← (( do (TranslationRegime (← readReg PSTATE).EL) ) : SailM Regime )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let walkparams ← (( do (AArch64_GetS1TTWParams regime ss (BitVec.replicateBits top_bit 64)) ) : SailM S1TTWParams )
  let bottom_PAC_bit ← (( do (pure (64 -i (BitVec.toNat (← (AArch64_PACEffectiveTxSZ regime walkparams))))) ) : SailM Int )
  (pure bottom_PAC_bit)

def HaveEnhancedPAC2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAuth2)

def HaveFPAC (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPAC)

def HaveFPACCombined (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPACCOMBINE)

def HavePACQARMA3Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA3Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA5Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACQARMA5Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACIMPGeneric (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def HavePACIMPAuth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def PACCellInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACCellShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 43 40))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 19 16))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACInvSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | _ => Toutput
  (pure loop_vars)

/-- Type quantifiers: amount : Nat, 0 ≤ (4 - amount) ∧ (7 - amount) < 8 -/
def RotCell (incell_name : (BitVec 4)) (amount : Nat) : SailM (BitVec 4) := do
  let tmp ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let tmp : (BitVec 8) := (Sail.BitVec.updateSubrange tmp 7 0 ((Sail.BitVec.extractLsb incell_name 3 0) +++ (Sail.BitVec.extractLsb incell_name 3 0)))
  (pure (Sail.BitVec.extractLsb tmp (7 -i amount) (4 -i amount)))

def PACMult (Sinput : (BitVec 64)) : SailM (BitVec 64) := do
  let t0 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t1 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t2 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t3 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let Soutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let (Soutput, t0, t1, t2, t3) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := 3
    let mut loop_vars := (Soutput, t0, t1, t2, t3)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (Soutput, t0, t1, t2, t3) := loop_vars
      loop_vars ← do
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 2)))))
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((Sail.BitVec.extractLsb t0 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((Sail.BitVec.extractLsb t1 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 2)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 2)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((Sail.BitVec.extractLsb t2 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 2)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((Sail.BitVec.extractLsb t3 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i i) +i 3) (4 *i i) (Sail.BitVec.extractLsb t3 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4)) (Sail.BitVec.extractLsb t2 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8)) (Sail.BitVec.extractLsb t1 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12)) (Sail.BitVec.extractLsb t0 3 0))
        (pure (Soutput, t0, t1, t2, t3))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 4) × (BitVec 4) × (BitVec 4) × (BitVec 4)) )
  (pure Soutput)

def PACSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | _ => Toutput
  (pure loop_vars)

def PACSub1 (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | _ => Toutput
  (pure loop_vars)

def TweakCellInvRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 1) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 0) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 3) : BitVec 1)))))

def TweakInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 3 0 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 51 48)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 27 24 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 11 8)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 35 32 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 31 28)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 39 36 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 43 40 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 59 56)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 19 16)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 47 44)))))

def TweakCellRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 1) : BitVec 1))))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 3) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit ((BitVec.access incell_name 1) : BitVec 1))))

def TweakShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 23 20))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 11 8 (← (TweakCellRot (Sail.BitVec.extractLsb indata 27 24)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 31 28))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 19 16 (← (TweakCellRot (Sail.BitVec.extractLsb indata 47 44)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 31 28 (← (TweakCellRot (Sail.BitVec.extractLsb indata 35 32)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 51 48 (← (TweakCellRot (Sail.BitVec.extractLsb indata 3 0)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 59 56 (← (TweakCellRot (Sail.BitVec.extractLsb indata 43 40)))))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellRot (Sail.BitVec.extractLsb indata 39 36)))))

/-- Type quantifiers: k_isqarma3 : Bool -/
def ComputePACQARMA (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isqarma3 : Bool) : SailM (BitVec 64) := do
  let roundkey ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let Alpha : (BitVec 64) := 0xC0AC29B7C97C50DD#64
  let iterations : Int := 2
  writeReg RC (vectorUpdate (← readReg RC) 0 0x0000000000000000#64)
  writeReg RC (vectorUpdate (← readReg RC) 1 0x13198A2E03707344#64)
  writeReg RC (vectorUpdate (← readReg RC) 2 0xA4093822299F31D0#64)
  let iterations ← (( do
    (if (isqarma3 : Bool)
    then (do (pure 2))
    else
      (do let iterations : Int := 4
          writeReg RC (vectorUpdate (← readReg RC) 3 0x082EFA98EC4E6C89#64)
          writeReg RC (vectorUpdate (← readReg RC) 4 0x452821E638D01377#64)
          (pure iterations))) ) : SailM Int )
  let iterations := iterations
  let modk0 : (BitVec 64) := ((((BitVec.access key0 0) : BitVec 1) +++ (Sail.BitVec.extractLsb key0 63 2)) +++ (((BitVec.access key0 63) : BitVec 1) ^^^ ((BitVec.access key0 1) : BitVec 1)))
  let runningmod : (BitVec 64) := modifier
  let workingval : (BitVec 64) := (data ^^^ key0)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars
      loop_vars ← do
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) i)))
        let workingval ← (( do
          (if ((i >b 0) : Bool)
          then
            (do let workingval ← (PACCellShuffle workingval)
                (PACMult workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACSub workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  let roundkey : (BitVec 64) := (modk0 ^^^ runningmod)
  let workingval : (BitVec 64) := (workingval ^^^ roundkey)
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (key1 ^^^ workingval)
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (workingval ^^^ key0)
  let workingval : (BitVec 64) := (workingval ^^^ runningmod)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars_1 := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars_1
      loop_vars_1 ← do
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if ((i <b iterations) : Bool)
          then
            (do let workingval ← (PACMult workingval)
                (PACCellInvShuffle workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakInvShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) (iterations -i i))))
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval : (BitVec 64) := (workingval ^^^ Alpha)
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars_1) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  (pure (workingval ^^^ modk0))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACIMP (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACIMPGeneric ()))
  else (do (HavePACIMPAuth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA3 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA3Generic ()))
  else (do (HavePACQARMA3Auth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA5 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA5Generic ()))
  else (do (HavePACQARMA5Auth ())))

def ComputePACIMPDEF (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) : SailM (BitVec 64) := do
  (__UNKNOWN_bits 64)

/-- Type quantifiers: k_isgeneric : Bool -/
def ComputePAC (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isgeneric : Bool) : SailM (BitVec 64) := do
  (if ((← (UsePACIMP isgeneric)) : Bool)
  then (do (ComputePACIMPDEF data modifier key0 key1))
  else
    (do (if ((← (UsePACQARMA3 isgeneric)) : Bool)
        then
          (do let isqarma3 : Bool := true
              (ComputePACQARMA data modifier key0 key1 isqarma3))
        else
          (do (if ((← (UsePACQARMA5 isgeneric)) : Bool)
              then
                (do let isqarma3 : Bool := false
                    (ComputePACQARMA data modifier key0 key1 isqarma3))
              else (do (undefined_bitvector 64)))))))

def AArch64_PACFailException (syndrome : (BitVec 2)) : SailM Unit := do
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_PACFail) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 syndrome) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 2 (Zeros (n := 23))) }
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL0)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))


end ArmASL.Functions
