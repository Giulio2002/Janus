import ArmASL.Part06

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def AArch64_S1TTWParamsEL10 (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL1_Type_D128 (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL1_Type_TG0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T0SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI0 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL1_Type_SKL (← (TTBR0_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH0 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL1_Type_TG1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T1SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI1 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL1_Type_SKL (← (TTBR1_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH1 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL1)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL1Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL1_Type_AIE (← readReg TCR2_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL1_Type_WXN (← readReg SCTLR_EL1)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL1_Type_IPS (← readReg TCR_EL1)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL1_Type_EE (← readReg SCTLR_EL1)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with dc := (← do (pure (_get_HCR_EL2_Type_DC (← readReg HCR_EL2)))) })
          (pure { walkparams with dct := (← do
              (if ((← (HaveMTE2Ext ())) : Bool)
              then (do (pure (_get_HCR_EL2_Type_DCT (← readReg HCR_EL2))))
              else (do (pure 0#1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL1_Type_nTLSMD (← readReg SCTLR_EL1)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do (if ((((_get_HCR_EL2_Type_NV (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2))) == 0b01#2) : Bool)
          then
            (do match (← (ConstrainUnpredictable Unpredictable_NVNV1)) with
                | .Constraint_NVNV1_00 => (pure { walkparams with nv1 := 0#1 })
                | .Constraint_NVNV1_01 => (pure { walkparams with nv1 := 1#1 })
                | .Constraint_NVNV1_11 => (pure { walkparams with nv1 := 1#1 })
                | _ => (pure walkparams))
          else (do (pure { walkparams with nv1 := (← do (pure (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)))) }))))
    else (do (pure { walkparams with nv1 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL1_Type_CMOW (← readReg SCTLR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HA (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HD (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL1_Type_DS (← readReg TCR_EL1)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL1Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_PIE (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL1)))) })
          (if ((walkparams.nv1 != 1#1) : Bool)
          then (do (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL1)))) }))
          else (do (pure walkparams))))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EPAN (← readReg SCTLR_EL1))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL1_Type_PnCH (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL1_Type_HAFT (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((←((HaveFeatMEC ()) <&&> (do
           (IsSCTLR2EL2Enabled ())))) : Bool)
      then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
      else (do (pure 0#1)))) })

def IsTCR2EL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatTCR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_TCR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def undefined_MAIR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MAIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TCR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR2_EL2_Type_AMEC0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_TCR2_EL2_Type_AMEC1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def AArch64_S1TTWParamsEL2 (ss : SecurityState) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_PS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_TBID (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_HPD (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with pie := (← do
        (if ((←((HaveS1PIExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_MTX (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with pnch := (← do
        (if ((←((HaveTHExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then (do (pure { walkparams with amec := (← do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2)))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_PIRE0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIRE0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1TTWParamsEL20 (ss : SecurityState) (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL2_Type_D128 (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI0 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL2_Type_SKL (← (TTBR0_EL2_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH0 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL2_Type_TG1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T1SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI1 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL2_Type_SKL (← readReg TTBR1_EL2))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH1 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_IPS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL2_Type_nTLSMD (← readReg SCTLR_EL2)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL2_Type_CMOW (← readReg SCTLR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL2Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) })
          (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL2_Type_EPAN (← readReg SCTLR_EL2))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then
    (do (pure { walkparams with amec := (← do
            (if ((BEq.beq varange VARange_LOWER) : Bool)
            then (do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2))))
            else (do (pure (_get_TCR2_EL2_Type_AMEC1 (← readReg TCR2_EL2)))))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_MAIR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR2_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MAIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR2_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TTBR0_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR0_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1TTWParamsEL3 (_ : Unit) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL3_Type_TG0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL3_Type_T0SZ (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL3_Type_PS (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL3_Type_IRGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL3_Type_ORGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL3_Type_SH0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL3_Type_TBI (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL3)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((← (HaveAIEExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_AIE (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL3_Type_WXN (← readReg SCTLR_EL3)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL3_Type_EE (← readReg SCTLR_EL3)))) })
  let walkparams ←
    (pure { walkparams with sif := (← do
        (if ((←((pure (! (← (HaveRME ())))) <||> (do
             (HaveSecureEL2Ext ())))) : Bool)
        then (do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_TBID (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HPD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HA (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL3_Type_DS (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_D128 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with skl := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TTBR0_EL3_Type_SKL (← readReg TTBR0_EL3))))
        else (do (pure 0b00#2)))) })
  let walkparams ←
    (pure { walkparams with disch := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TCR_EL3_Type_DisCH0 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((← (HaveS1PIExt ())) : Bool)
              then (do (pure (_get_TCR_EL3_Type_PIE (← readReg TCR_EL3))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_MTX (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 == 0#1)) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR_EL3_Type_PnCH (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR_EL3_Type_HAFT (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((← (HaveFeatMEC ())) : Bool)
      then (do (pure (_get_SCTLR2_EL3_Type_EMEC (← readReg SCTLR2_EL3))))
      else (do (pure 0#1)))) })

def AArch64_GetS1TTWParams (regime : Regime) (ss : SecurityState) (va : (BitVec 64)) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL3 => (do (AArch64_S1TTWParamsEL3 ()))
  | .Regime_EL2 => (do (AArch64_S1TTWParamsEL2 ss))
  | .Regime_EL20 => (do (AArch64_S1TTWParamsEL20 ss varange))
  | .Regime_EL10 => (do (AArch64_S1TTWParamsEL10 varange))
  | _ => (pure walkparams)

def CalculateBottomPACBit (top_bit : (BitVec 1)) : SailM Int := do
  let regime ← (( do (TranslationRegime (← readReg PSTATE).EL) ) : SailM Regime )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let walkparams ← (( do (AArch64_GetS1TTWParams regime ss (BitVec.replicateBits top_bit 64)) ) : SailM S1TTWParams )
  let bottom_PAC_bit ← (( do (pure (64 -i (BitVec.toNat (← (AArch64_PACEffectiveTxSZ regime walkparams))))) ) : SailM Int )
  (pure bottom_PAC_bit)

def HaveEnhancedPAC2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAuth2)

def HaveFPAC (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPAC)

def HaveFPACCombined (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPACCOMBINE)

def HavePACQARMA3Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA3Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA5Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACQARMA5Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACIMPGeneric (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def HavePACIMPAuth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def PACCellInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACCellShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 43 40))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 19 16))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACInvSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | _ => Toutput
  (pure loop_vars)

/-- Type quantifiers: amount : Nat, 0 ≤ (4 - amount) ∧ (7 - amount) < 8 -/
def RotCell (incell_name : (BitVec 4)) (amount : Nat) : SailM (BitVec 4) := do
  let tmp ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let tmp : (BitVec 8) := (Sail.BitVec.updateSubrange tmp 7 0 ((Sail.BitVec.extractLsb incell_name 3 0) +++ (Sail.BitVec.extractLsb incell_name 3 0)))
  (pure (Sail.BitVec.extractLsb tmp (7 -i amount) (4 -i amount)))

def PACMult (Sinput : (BitVec 64)) : SailM (BitVec 64) := do
  let t0 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t1 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t2 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t3 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let Soutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let (Soutput, t0, t1, t2, t3) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := 3
    let mut loop_vars := (Soutput, t0, t1, t2, t3)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (Soutput, t0, t1, t2, t3) := loop_vars
      loop_vars ← do
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 2)))))
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((Sail.BitVec.extractLsb t0 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((Sail.BitVec.extractLsb t1 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 2)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 2)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((Sail.BitVec.extractLsb t2 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 2)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((Sail.BitVec.extractLsb t3 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i i) +i 3) (4 *i i) (Sail.BitVec.extractLsb t3 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4)) (Sail.BitVec.extractLsb t2 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8)) (Sail.BitVec.extractLsb t1 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12)) (Sail.BitVec.extractLsb t0 3 0))
        (pure (Soutput, t0, t1, t2, t3))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 4) × (BitVec 4) × (BitVec 4) × (BitVec 4)) )
  (pure Soutput)

def PACSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | _ => Toutput
  (pure loop_vars)

def PACSub1 (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | _ => Toutput
  (pure loop_vars)

def TweakCellInvRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 1) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 0) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 3) : BitVec 1)))))

def TweakInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 3 0 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 51 48)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 27 24 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 11 8)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 35 32 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 31 28)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 39 36 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 43 40 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 59 56)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 19 16)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 47 44)))))

def TweakCellRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 1) : BitVec 1))))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 3) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit ((BitVec.access incell_name 1) : BitVec 1))))

def TweakShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 23 20))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 11 8 (← (TweakCellRot (Sail.BitVec.extractLsb indata 27 24)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 31 28))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 19 16 (← (TweakCellRot (Sail.BitVec.extractLsb indata 47 44)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 31 28 (← (TweakCellRot (Sail.BitVec.extractLsb indata 35 32)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 51 48 (← (TweakCellRot (Sail.BitVec.extractLsb indata 3 0)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 59 56 (← (TweakCellRot (Sail.BitVec.extractLsb indata 43 40)))))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellRot (Sail.BitVec.extractLsb indata 39 36)))))

/-- Type quantifiers: k_isqarma3 : Bool -/
def ComputePACQARMA (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isqarma3 : Bool) : SailM (BitVec 64) := do
  let roundkey ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let Alpha : (BitVec 64) := 0xC0AC29B7C97C50DD#64
  let iterations : Int := 2
  writeReg RC (vectorUpdate (← readReg RC) 0 0x0000000000000000#64)
  writeReg RC (vectorUpdate (← readReg RC) 1 0x13198A2E03707344#64)
  writeReg RC (vectorUpdate (← readReg RC) 2 0xA4093822299F31D0#64)
  let iterations ← (( do
    (if (isqarma3 : Bool)
    then (do (pure 2))
    else
      (do let iterations : Int := 4
          writeReg RC (vectorUpdate (← readReg RC) 3 0x082EFA98EC4E6C89#64)
          writeReg RC (vectorUpdate (← readReg RC) 4 0x452821E638D01377#64)
          (pure iterations))) ) : SailM Int )
  let iterations := iterations
  let modk0 : (BitVec 64) := ((((BitVec.access key0 0) : BitVec 1) +++ (Sail.BitVec.extractLsb key0 63 2)) +++ (((BitVec.access key0 63) : BitVec 1) ^^^ ((BitVec.access key0 1) : BitVec 1)))
  let runningmod : (BitVec 64) := modifier
  let workingval : (BitVec 64) := (data ^^^ key0)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars
      loop_vars ← do
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) i)))
        let workingval ← (( do
          (if ((i >b 0) : Bool)
          then
            (do let workingval ← (PACCellShuffle workingval)
                (PACMult workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACSub workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  let roundkey : (BitVec 64) := (modk0 ^^^ runningmod)
  let workingval : (BitVec 64) := (workingval ^^^ roundkey)
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (key1 ^^^ workingval)
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (workingval ^^^ key0)
  let workingval : (BitVec 64) := (workingval ^^^ runningmod)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars_1 := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars_1
      loop_vars_1 ← do
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if ((i <b iterations) : Bool)
          then
            (do let workingval ← (PACMult workingval)
                (PACCellInvShuffle workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakInvShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) (iterations -i i))))
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval : (BitVec 64) := (workingval ^^^ Alpha)
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars_1) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  (pure (workingval ^^^ modk0))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACIMP (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACIMPGeneric ()))
  else (do (HavePACIMPAuth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA3 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA3Generic ()))
  else (do (HavePACQARMA3Auth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA5 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA5Generic ()))
  else (do (HavePACQARMA5Auth ())))

def ComputePACIMPDEF (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) : SailM (BitVec 64) := do
  (__UNKNOWN_bits 64)

/-- Type quantifiers: k_isgeneric : Bool -/
def ComputePAC (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isgeneric : Bool) : SailM (BitVec 64) := do
  (if ((← (UsePACIMP isgeneric)) : Bool)
  then (do (ComputePACIMPDEF data modifier key0 key1))
  else
    (do (if ((← (UsePACQARMA3 isgeneric)) : Bool)
        then
          (do let isqarma3 : Bool := true
              (ComputePACQARMA data modifier key0 key1 isqarma3))
        else
          (do (if ((← (UsePACQARMA5 isgeneric)) : Bool)
              then
                (do let isqarma3 : Bool := false
                    (ComputePACQARMA data modifier key0 key1 isqarma3))
              else (do (undefined_bitvector 64)))))))

def AArch64_PACFailException (syndrome : (BitVec 2)) : SailM Unit := do
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_PACFail) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 syndrome) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 2 (Zeros (n := 23))) }
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL0)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

/-- Type quantifiers: k_data : Bool, k_is_combined : Bool -/
def Auth (ptr : (BitVec 64)) (modifier : (BitVec 64)) (K : (BitVec 128)) (data : Bool) (key_number : (BitVec 1)) (is_combined : Bool) : SailM (BitVec 64) := do
  let result ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let original_ptr ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let error_code ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let isgeneric : Bool := false
  let tbi ← (( do (pure ((← (EffectiveTBI ptr (! data) (← readReg PSTATE).EL)) == 1#1)) ) : SailM Bool )
  let mtx ← (( do (pure ((← (EffectiveMTX ptr (! data) (← readReg PSTATE).EL)) == 1#1)) ) : SailM Bool )
  let bottom_PAC_bit ← (( do (CalculateBottomPACBit ((BitVec.access ptr 55) : BitVec 1)) ) : SailM Int )
  let extfield : (BitVec 64) := (BitVec.replicateBits ((BitVec.access ptr 55) : BitVec 1) 64)
  (if ((tbi && (bottom_PAC_bit ≥b 55)) : Bool)
  then (do (pure ptr))
  else
    (do let original_ptr ← (( do
          (if (tbi : Bool)
          then
            (do sail_assert ((0 ≤b ((56 -i bottom_PAC_bit) -i 1)) && (((56 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21616.90-21616.91"
                sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21617.80-21617.81"
                (pure (((Sail.BitVec.extractLsb ptr 63 56) +++ (Sail.BitVec.extractLsb extfield ((56 -i bottom_PAC_bit) -i 1) 0)) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))
          else
            (do (if (mtx : Bool)
                then
                  (do sail_assert ((0 ≤b ((56 -i bottom_PAC_bit) -i 1)) && (((56 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21620.90-21620.91"
                      sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21621.80-21621.81"
                      (pure ((((Sail.BitVec.extractLsb extfield 63 60) +++ (Sail.BitVec.extractLsb ptr 59 56)) +++ (Sail.BitVec.extractLsb extfield ((56 -i bottom_PAC_bit) -i 1) 0)) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))
                else
                  (do sail_assert ((0 ≤b ((64 -i bottom_PAC_bit) -i 1)) && (((64 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21624.90-21624.91"
                      sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21625.80-21625.81"
                      (pure ((Sail.BitVec.extractLsb extfield ((64 -i bottom_PAC_bit) -i 1) 0) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))))) ) : SailM (BitVec 64) )
        let PAC ← (( do (ComputePAC original_ptr modifier (Sail.BitVec.extractLsb K 127 64) (Sail.BitVec.extractLsb K 63 0) isgeneric) ) : SailM (BitVec 64) )
        (if (tbi : Bool)
        then
          (do (if ((! (← (HaveEnhancedPAC2 ()))) : Bool)
              then
                (do sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21631.77-21631.78"
                    (if (((Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit) == (Sail.BitVec.extractLsb ptr 54 bottom_PAC_bit)) : Bool)
                    then (do (pure original_ptr))
                    else
                      (do let error_code : (BitVec 2) := (key_number +++ (Complement.complement key_number))
                          (pure (((Sail.BitVec.extractLsb original_ptr 63 55) +++ error_code) +++ (Sail.BitVec.extractLsb original_ptr 52 0))))))
              else
                (do let result : (BitVec 64) := ptr
                    sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21640.77-21640.78"
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                    (if ((←((HaveFPACCombined ()) <||> (do
                         (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                    then
                      (do (if (((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (55 -i bottom_PAC_bit))) : Bool)
                          then
                            (do let error_code : (BitVec 2) :=
                                  ((if (data : Bool)
                                    then 1#1
                                    else 0#1) +++ key_number)
                                (AArch64_PACFailException error_code))
                          else (do (pure ()))))
                    else (do (pure ())))
                    (pure result))))
        else
          (do (if (mtx : Bool)
              then
                (do sail_assert (← (HaveEnhancedPAC2 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:21652.33-21652.34"
                    let result : (BitVec 64) := ptr
                    sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21654.73-21654.74"
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 63 60 ((Sail.BitVec.extractLsb result 63 60) ^^^ (Sail.BitVec.extractLsb PAC 63 60)))
                    (if ((←((HaveFPACCombined ()) <||> (do
                         (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                    then
                      (do (if ((((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (55 -i bottom_PAC_bit))) || ((Sail.BitVec.extractLsb result 63 60) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) 4))) : Bool)
                          then
                            (do let error_code : (BitVec 2) :=
                                  ((if (data : Bool)
                                    then 1#1
                                    else 0#1) +++ key_number)
                                (AArch64_PACFailException error_code))
                          else (do (pure ()))))
                    else (do (pure ())))
                    (pure result))
              else
                (do (if ((! (← (HaveEnhancedPAC2 ()))) : Bool)
                    then
                      (do sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21667.77-21667.78"
                          (if ((((Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit) == (Sail.BitVec.extractLsb ptr 54 bottom_PAC_bit)) && ((Sail.BitVec.extractLsb PAC 63 56) == (Sail.BitVec.extractLsb ptr 63 56))) : Bool)
                          then (do (pure original_ptr))
                          else
                            (do let error_code : (BitVec 2) := (key_number +++ (Complement.complement key_number))
                                (pure ((((BitVec.access original_ptr 63) : BitVec 1) +++ error_code) +++ (Sail.BitVec.extractLsb original_ptr 60 0))))))
                    else
                      (do let result : (BitVec 64) := ptr
                          sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21676.77-21676.78"
                          let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                          let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 63 56 ((Sail.BitVec.extractLsb result 63 56) ^^^ (Sail.BitVec.extractLsb PAC 63 56)))
                          (if ((←((HaveFPACCombined ()) <||> (do
                               (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                          then
                            (do (if (((Sail.BitVec.extractLsb result 63 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (64 -i bottom_PAC_bit))) : Bool)
                                then
                                  (do let error_code : (BitVec 2) :=
                                        ((if (data : Bool)
                                          then 1#1
                                          else 0#1) +++ key_number)
                                      (AArch64_PACFailException error_code))
                                else (do (pure ()))))
                          else (do (pure ())))
                          (pure result)))))))))

def TrapPACUse (target_el : (BitVec 2)) : SailM Unit := do
  sail_assert (←((pure ((HaveEL target_el) && (target_el != EL0))) <&&> (do
    (pure ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:21695.86-21695.87"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := 0
  let except ← (( do (ExceptionSyndrome Exception_PACTrap) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

/-- Type quantifiers: k_is_combined : Bool -/
def AuthIA (x : (BitVec 64)) (y : (BitVec 64)) (is_combined : Bool) : SailM (BitVec 64) := do
  let TrapEL2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let TrapEL3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let Enable ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let APIAKey_EL1 ← (( do (pure ((Sail.BitVec.extractLsb (← readReg APIAKeyHi_EL1) 63 0) +++ (Sail.BitVec.extractLsb (← readReg APIAKeyLo_EL1) 63 0))) ) : SailM (BitVec 128) )
  let (Enable, TrapEL2, TrapEL3) ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    let (Enable, TrapEL2, TrapEL3) ← (( do
      (if ((questionMark == EL0) : Bool)
      then
        (do let IsEL1Regime ← (( do (pure ((← (S1TranslationRegime__1 ())) == EL1)) ) : SailM Bool )
            let Enable ←
              (if (IsEL1Regime : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EnIA (← readReg SCTLR_EL1))))
              else (do (pure (_get_SCTLR_EL2_Type_EnIA (← readReg SCTLR_EL2)))))
            let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
            (pure (Enable, TrapEL2, TrapEL3)))
      else
        (do let (Enable, TrapEL2, TrapEL3) ← (( do
              (if ((questionMark == EL1) : Bool)
              then
                (do let Enable ← (pure (_get_SCTLR_EL1_Type_EnIA (← readReg SCTLR_EL1)))
                    let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1)))
                    let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                    (pure (Enable, TrapEL2, TrapEL3)))
              else
                (do let (Enable, TrapEL2, TrapEL3) ← (( do
                      (if ((questionMark == EL2) : Bool)
                      then
                        (do let Enable ← (pure (_get_SCTLR_EL2_Type_EnIA (← readReg SCTLR_EL2)))
                            let TrapEL2 : Bool := false
                            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                            (pure (Enable, TrapEL2, TrapEL3)))
                      else
                        (do let (Enable, TrapEL2, TrapEL3) ← (( do
                              (if ((questionMark == EL3) : Bool)
                              then
                                (do let Enable ← (pure (_get_SCTLR_EL3_Type_EnIA (← readReg SCTLR_EL3)))
                                    let TrapEL2 : Bool := false
                                    let TrapEL3 : Bool := false
                                    (pure (Enable, TrapEL2, TrapEL3)))
                              else (do (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                    (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
    (pure (Enable, TrapEL2, TrapEL3)) ) : SailM ((BitVec 1) × Bool × Bool) )
  (if ((Enable == 0#1) : Bool)
  then (do (pure x))
  else
    (do (if ((←((pure TrapEL3) <&&> (do
             (EL3SDDUndefPriority ())))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (TrapEL2 : Bool)
              then
                (do (TrapPACUse EL2)
                    (undefined_bitvector 64))
              else
                (do (if (TrapEL3 : Bool)
                    then
                      (do (if ((← (EL3SDDUndef ())) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (TrapPACUse EL3)
                                (undefined_bitvector 64))))
                    else (do (Auth x y APIAKey_EL1 false 0#1 is_combined)))))))))

/-- Type quantifiers: k_is_combined : Bool -/
def AuthIB (x : (BitVec 64)) (y : (BitVec 64)) (is_combined : Bool) : SailM (BitVec 64) := do
  let TrapEL2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let TrapEL3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let Enable ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let APIBKey_EL1 ← (( do (pure ((Sail.BitVec.extractLsb (← readReg APIBKeyHi_EL1) 63 0) +++ (Sail.BitVec.extractLsb (← readReg APIBKeyLo_EL1) 63 0))) ) : SailM (BitVec 128) )
  let (Enable, TrapEL2, TrapEL3) ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    let (Enable, TrapEL2, TrapEL3) ← (( do
      (if ((questionMark == EL0) : Bool)
      then
        (do let IsEL1Regime ← (( do (pure ((← (S1TranslationRegime__1 ())) == EL1)) ) : SailM Bool )
            let Enable ←
              (if (IsEL1Regime : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EnIB (← readReg SCTLR_EL1))))
              else (do (pure (_get_SCTLR_EL2_Type_EnIB (← readReg SCTLR_EL2)))))
            let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
            (pure (Enable, TrapEL2, TrapEL3)))
      else
        (do let (Enable, TrapEL2, TrapEL3) ← (( do
              (if ((questionMark == EL1) : Bool)
              then
                (do let Enable ← (pure (_get_SCTLR_EL1_Type_EnIB (← readReg SCTLR_EL1)))
                    let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1)))
                    let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                    (pure (Enable, TrapEL2, TrapEL3)))
              else
                (do let (Enable, TrapEL2, TrapEL3) ← (( do
                      (if ((questionMark == EL2) : Bool)
                      then
                        (do let Enable ← (pure (_get_SCTLR_EL2_Type_EnIB (← readReg SCTLR_EL2)))
                            let TrapEL2 : Bool := false
                            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                            (pure (Enable, TrapEL2, TrapEL3)))
                      else
                        (do let (Enable, TrapEL2, TrapEL3) ← (( do
                              (if ((questionMark == EL3) : Bool)
                              then
                                (do let Enable ← (pure (_get_SCTLR_EL3_Type_EnIB (← readReg SCTLR_EL3)))
                                    let TrapEL2 : Bool := false
                                    let TrapEL3 : Bool := false
                                    (pure (Enable, TrapEL2, TrapEL3)))
                              else (do (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                    (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
    (pure (Enable, TrapEL2, TrapEL3)) ) : SailM ((BitVec 1) × Bool × Bool) )
  (if ((Enable == 0#1) : Bool)
  then (do (pure x))
  else
    (do (if ((←((pure TrapEL3) <&&> (do
             (EL3SDDUndefPriority ())))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (TrapEL2 : Bool)
              then
                (do (TrapPACUse EL2)
                    (undefined_bitvector 64))
              else
                (do (if (TrapEL3 : Bool)
                    then
                      (do (if ((← (EL3SDDUndef ())) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (TrapPACUse EL3)
                                (undefined_bitvector 64))))
                    else (do (Auth x y APIBKey_EL1 false 1#1 is_combined)))))))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64] -/
def X_read (n : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22319.27-22319.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || (width == 64)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:22320.63-22320.64"
  (if ((n != 31) : Bool)
  then (do (pure (Sail.BitVec.extractLsb (← (get_R n)) (width -i 1) 0)))
  else (do (pure (Zeros (n := width)))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64, 128] -/
def V_read (n : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22333.27-22333.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || ((width == 64) || (width == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:22334.78-22334.79"
  (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg _Z) n) (width -i 1) 0))

/-- Type quantifiers: n : Int, part : Int, width : Nat, width ≥ 0 -/
def Vpart_read (n : Int) (part : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22343.27-22343.28"
  sail_assert ((part == 0) || (part == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22344.32-22344.33"
  (if ((part == 0) : Bool)
  then
    (do sail_assert (width <b 128) "sail-arm/arm-v9.4-a/src/v8_base.sail:22346.26-22346.27"
        sail_assert (((((width == 8) || (width == 16)) || (width == 32)) || (width == 64)) || (width == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22347.57-22347.58"
        (V_read n width))
  else
    (do sail_assert ((width == 32) || (width == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22350.40-22350.41"
        let vreg ← (( do (V_read n 128) ) : SailM (BitVec 128) )
        (pure (Sail.BitVec.extractLsb vreg ((width *i 2) -i 1) width))))

/-- Type quantifiers: n : Int, part : Int, width : Nat, width ≥ 0 -/
def Vpart_set (n : Int) (part : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22361.27-22361.28"
  sail_assert ((part == 0) || (part == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22362.32-22362.33"
  (if ((part == 0) : Bool)
  then
    (do sail_assert (width <b 128) "sail-arm/arm-v9.4-a/src/v8_base.sail:22364.26-22364.27"
        sail_assert (((((width == 8) || (width == 16)) || (width == 32)) || (width == 64)) || (width == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22365.57-22365.58"
        (V_set n width value_name))
  else
    (do sail_assert (width == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:22368.26-22368.27"
        let vreg ← (( do (V_read n 64) ) : SailM (BitVec 64) )
        (V_set n 128 ((Sail.BitVec.extractLsb value_name 63 0) +++ vreg))))

def AArch64_ResetGeneralRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 30
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (X_set i 64 (← (__UNKNOWN_bits 64)))
  (pure loop_vars)

def AArch64_ResetSIMDFPRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 31
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (V_set i 128 (← (__UNKNOWN_bits 128)))
  (pure loop_vars)

def AArch64_ResetSpecialRegisters (_ : Unit) : SailM Unit := do
  writeReg SP_EL0 (← (__UNKNOWN_bits 64))
  writeReg SP_EL1 (← (__UNKNOWN_bits 64))
  writeReg SPSR_EL1 (Mk_SPSR_EL1_Type (← (__UNKNOWN_bits 64)))
  writeReg ELR_EL1 (← (__UNKNOWN_bits 64))
  (if ((HaveEL EL2) : Bool)
  then
    (do writeReg SP_EL2 (← (__UNKNOWN_bits 64))
        writeReg SPSR_EL2 (Mk_SPSR_EL2_Type (← (__UNKNOWN_bits 64)))
        writeReg ELR_EL2 (← (__UNKNOWN_bits 64)))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do writeReg SP_EL3 (← (__UNKNOWN_bits 64))
        writeReg SPSR_EL3 (Mk_SPSR_EL3_Type (← (__UNKNOWN_bits 64)))
        writeReg ELR_EL3 (← (__UNKNOWN_bits 64)))
  else (do (pure ())))
  (if ((HaveAArch32EL EL1) : Bool)
  then
    (do writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 31 0 (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  writeReg DLR_EL0 (← (__UNKNOWN_bits 64))
  writeReg DSPSR_EL0 (Mk_DSPSR_EL0_Type (← (__UNKNOWN_bits 64)))

def undefined_CNTKCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTKCTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTKCTL_read__1 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTKCTL ) : SailM CNTKCTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTKCTL_EL1) 0 32)))

def CheckTransactionalSystemAccess (op0 : (BitVec 2)) (op1 : (BitVec 3)) (crn : (BitVec 4)) (crm : (BitVec 4)) (op2 : (BitVec 3)) (read : (BitVec 1)) : SailM Bool := do
  let b__0 := (((((read +++ op0) +++ op1) +++ crn) +++ crm) +++ op2)
  (if ((((Sail.BitVec.extractLsb b__0 16 7) == (0b0000110100#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb b__0 2 1) == (0b11#2 : (BitVec 2)))) : Bool)
  then (do (pure true))
  else
    (do (if ((b__0 == (0b00101101110100001#17 : (BitVec 17))) : Bool)
        then (do (pure true))
        else
          (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x6D08#16 : (BitVec 16))) : Bool)
              then (do (pure true))
              else
                (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x6D10#16 : (BitVec 16))) : Bool)
                    then (do (pure true))
                    else
                      (do (if ((b__0 == (0b01100001000110000#17 : (BitVec 17))) : Bool)
                          then (do (pure true))
                          else
                            (do (if ((b__0 == (0b01101110011100100#17 : (BitVec 17))) : Bool)
                                then (do (pure true))
                                else
                                  (do (if ((b__0 == (0b11101100100101001#17 : (BitVec 17))) : Bool)
                                      then (do (pure ((← readReg PSTATE).EL == EL0)))
                                      else
                                        (do (if ((b__0 == (0b11100000100101001#17 : (BitVec 17))) : Bool)
                                            then (do (pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL2)) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)))))
                                            else
                                              (do (if ((b__0 == (0b11110000100101001#17 : (BitVec 17))) : Bool)
                                                  then (do (pure ((← readReg PSTATE).EL == EL2)) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
                                                  else
                                                    (do (if ((b__0 == (0b11111000100101001#17 : (BitVec 17))) : Bool)
                                                        then (do (pure ((← readReg PSTATE).EL == EL3)))
                                                        else
                                                          (do (if ((b__0 == (0b00101101110111000#17 : (BitVec 17))) : Bool)
                                                              then (do (pure true))
                                                              else
                                                                (do (if ((b__0 == (0b10101101110111001#17 : (BitVec 17))) : Bool)
                                                                    then (do (pure true))
                                                                    else
                                                                      (do (if ((b__0 == (0b00101101110111010#17 : (BitVec 17))) : Bool)
                                                                          then (do (pure true))
                                                                          else
                                                                            (do (if ((b__0 == (0b10101101110111011#17 : (BitVec 17))) : Bool)
                                                                                then (do (pure true))
                                                                                else
                                                                                  (do (if ((b__0 == (0b00100001110111110#17 : (BitVec 17))) : Bool)
                                                                                      then (do (pure true))
                                                                                      else
                                                                                        (do (if ((b__0 == (0b11110100100101001#17 : (BitVec 17))) : Bool)
                                                                                            then (do (pure false))
                                                                                            else
                                                                                              (do (if ((b__0 == (0b11100000100101010#17 : (BitVec 17))) : Bool)
                                                                                                  then (do (pure false))
                                                                                                  else
                                                                                                    (do (if ((b__0 == (0b11100000100101000#17 : (BitVec 17))) : Bool)
                                                                                                        then (do (pure false))
                                                                                                        else
                                                                                                          (do (if ((b__0 == (0b11110100100101000#17 : (BitVec 17))) : Bool)
                                                                                                              then (do (pure false))
                                                                                                              else
                                                                                                                (do (if ((b__0 == (0b11110000100101000#17 : (BitVec 17))) : Bool)
                                                                                                                    then (do (pure false))
                                                                                                                    else
                                                                                                                      (do (if ((b__0 == (0b11111000100101000#17 : (BitVec 17))) : Bool)
                                                                                                                          then (do (pure false))
                                                                                                                          else
                                                                                                                            (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 10) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                                                then (do (pure true))
                                                                                                                                else
                                                                                                                                  (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 8) == (0b100#3 : (BitVec 3)))) : Bool)
                                                                                                                                      then (do (pure true))
                                                                                                                                      else
                                                                                                                                        (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xA#4 : (BitVec 4)))) : Bool)
                                                                                                                                            then (do (pure true))
                                                                                                                                            else
                                                                                                                                              (do (if ((((Sail.BitVec.extractLsb b__0 16 6) == (0b11100011001#11 : (BitVec 11))) && ((Sail.BitVec.extractLsb b__0 4 0) == (0b00010#5 : (BitVec 5)))) : Bool)
                                                                                                                                                  then (do (pure true))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((b__0 == (0b11100011001011011#17 : (BitVec 17))) : Bool)
                                                                                                                                                        then (do (pure true))
                                                                                                                                                        else
                                                                                                                                                          (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xD#4 : (BitVec 4)))) : Bool)
                                                                                                                                                              then (do (pure true))
                                                                                                                                                              else
                                                                                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xE#4 : (BitVec 4)))) : Bool)
                                                                                                                                                                    then (do (pure true))
                                                                                                                                                                    else
                                                                                                                                                                      (do (if ((b__0 == (0b00101101110011111#17 : (BitVec 17))) : Bool)
                                                                                                                                                                          then (do (pure true))
                                                                                                                                                                          else
                                                                                                                                                                            (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x2DCE#16 : (BitVec 16))) : Bool)
                                                                                                                                                                                then (do (pure true))
                                                                                                                                                                                else
                                                                                                                                                                                  (do (if ((((Sail.BitVec.extractLsb b__0 15 14) == (0b11#2 : (BitVec 2))) && (((Sail.BitVec.extractLsb b__0 10 10) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 8 7) == (0b11#2 : (BitVec 2))))) : Bool)
                                                                                                                                                                                      then (do (__IMPDEF_boolean ""))
                                                                                                                                                                                      else (do (pure false)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

def AArch64_CheckSystemAccess (op0 : (BitVec 2)) (op1 : (BitVec 3)) (crn : (BitVec 4)) (crm : (BitVec 4)) (op2 : (BitVec 3)) (rt : (BitVec 5)) (read : (BitVec 1)) : SailM Unit := do
  (if ((← (HaveBTIExt ())) : Bool)
  then (do (BranchTargetCheck ()))
  else (do (pure ())))
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))) <&&> (do
       (pure (! (← (CheckTransactionalSystemAccess op0 op1 crn crm op2 read))))))) : Bool)
  then (do (FailTransaction TMFailure_ERR false))
  else (do (pure ())))

/-- Type quantifiers: k_guardedpage : Bool -/
def SetInGuardedPage (guardedpage : Bool) : SailM Unit := do
  writeReg InGuardedPage guardedpage

def BTypeCompatible_BTI (hintcode : (BitVec 2)) : SailM Bool := do
  match hintcode with
  | 0b00 => (pure false)
  | 0b01 => (pure ((← readReg PSTATE).BTYPE != 0b11#2))
  | 0b10 => (pure ((← readReg PSTATE).BTYPE != 0b10#2))
  | 0b11 => (pure true)
  | _ => (do (undefined_bool ()))

/-- Type quantifiers: k_x : Bool -/
def SetBTypeCompatible (x : Bool) : SailM Unit := do
  writeReg BTypeCompatible x

def SetBTypeNext (x : (BitVec 2)) : SailM Unit := do
  writeReg BTypeNext x

def AArch64_AllocationTagAccessIsEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((((_get_SCR_EL3_Type_ATA (← readReg SCR_EL3)) == 0#1) && ((el == EL0) || ((el == EL1) || (el == EL2)))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (((_get_HCR_EL2_Type_ATA (← readReg HCR_EL2)) == 0#1) && ((el == EL0) || (el == EL1)))) <&&> (do
             (EL2Enabled ())) <&&> (do
             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) : Bool)
        then (do (pure false))
        else
          (do let regime ← (( do (TranslationRegime el) ) : SailM Regime )
              match regime with
              | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_ATA (← readReg SCTLR_EL3)) == 1#1))
              | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1))
              | .Regime_EL20 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL2_Type_ATA0 (← readReg SCTLR_EL2)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1)))))
              | .Regime_EL10 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL1_Type_ATA0 (← readReg SCTLR_EL1)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL1_Type_ATA (← readReg SCTLR_EL1)) == 1#1)))))
              | _ =>
                (do
                  (Unreachable ())
                  (undefined_bool ()))))))

def undefined_GCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RGSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: alignment : Int, size : Int -/
def AllInAlignedQuantity (address : (BitVec 64)) (size : Int) (alignment : Int) : SailM Bool := do
  sail_assert (size ≤b alignment) "sail-arm/arm-v9.4-a/src/v8_base.sail:22735.28-22735.29"
  (pure ((Align_bits (BitVec.subInt (BitVec.addInt address size) 1) alignment) == (Align_bits address alignment)))

def AArch64_SPAlignmentFault (_ : Unit) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_SPAlignment) ) : SailM ExceptionRecord )
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((EL2Enabled ()) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def SP_read (_ : Unit) : SailM (BitVec 64) := do
  (if (((← readReg PSTATE).SP == 0#1) : Bool)
  then (do readReg SP_EL0)
  else
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do readReg SP_EL0)
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do readReg SP_EL1)
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do readReg SP_EL2)
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do readReg SP_EL3)
                          else (do (undefined_bitvector 64)))))))))))

def CheckSPAlignment (_ : Unit) : SailM Unit := do
  let sp ← (( do (SP_read ()) ) : SailM (BitVec 64) )
  let stack_align_check ← (( do (undefined_bool ()) ) : SailM Bool )
  let stack_align_check ← (( do
    (if (((← readReg PSTATE).EL == EL0) : Bool)
    then (do (pure ((_get_SCTLRType_SA0 (← (SCTLR_read__1 ()))) != 0#1)))
    else (do (pure ((_get_SCTLRType_SA (← (SCTLR_read__1 ()))) != 0#1)))) ) : SailM Bool )
  (if ((stack_align_check && (sp != (Align_bits sp 16))) : Bool)
  then (do (AArch64_SPAlignmentFault ()))
  else (do (pure ())))

/-- Type quantifiers: size : Int -/
def AArch64_UnalignedAccessFaults (accdesc : AccessDescriptor) (address : (BitVec 64)) (size : Int) : SailM Bool := do
  (if ((← (AlignmentEnforced ())) : Bool)
  then (do (pure true))
  else
    (do (if ((BEq.beq accdesc.acctype AccessType_GCS) : Bool)
        then (do (pure true))
        else
          (do (if (accdesc.rcw : Bool)
              then (do (pure true))
              else
                (do (if (accdesc.ls64 : Bool)
                    then (do (pure true))
                    else
                      (do (if ((accdesc.exclusive || accdesc.atomicop) : Bool)
                          then (do (pure (! (← (HaveLSE2Ext ())))) <||> (do (pure (! (← (AllInAlignedQuantity address size 16))))))
                          else
                            (do (if (((accdesc.acqsc || accdesc.acqpc) || accdesc.relsc) : Bool)
                                then (do (pure (! (← (HaveLSE2Ext ())))) <||> (do (pure ((_get_SCTLRType_nAA (← (SCTLR_read__1 ()))) == 0#1)) <&&> (do (pure (! (← (AllInAlignedQuantity address size 16)))))))
                                else (do (pure false)))))))))))))

def StoreOnlyTagCheckingEnabled (el : (BitVec 2)) : SailM Bool := do
  sail_assert (← (HaveMTEStoreOnlyExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:22820.32-22820.33"
  let tcso ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let tcso ← (( do
    let questionMark := el
    (if ((questionMark == EL0) : Bool)
    then
      (do (if ((! (← (ELIsInHost el))) : Bool)
          then (do (pure (_get_SCTLR_EL1_Type_TCSO0 (← readReg SCTLR_EL1))))
          else (do (pure (_get_SCTLR_EL2_Type_TCSO0 (← readReg SCTLR_EL2))))))
    else
      (do (if ((questionMark == EL1) : Bool)
          then (do (pure (_get_SCTLR_EL1_Type_TCSO (← readReg SCTLR_EL1))))
          else
            (do (if ((questionMark == EL2) : Bool)
                then (do (pure (_get_SCTLR_EL2_Type_TCSO (← readReg SCTLR_EL2))))
                else (do (pure (_get_SCTLR_EL3_Type_TCSO (← readReg SCTLR_EL3))))))))) ) : SailM (BitVec 1) )
  (pure (tcso == 1#1))

def AArch64_AccessIsTagChecked (vaddr : (BitVec 64)) (accdesc : AccessDescriptor) : SailM Bool := do
  sail_assert accdesc.tagchecked "sail-arm/arm-v9.4-a/src/v8_base.sail:22846.29-22846.30"
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do let is_instr : Bool := false
        (if ((←((pure ((← (EffectiveMTX vaddr is_instr (← readReg PSTATE).EL)) == 0#1)) <&&> (do
             (pure ((← (EffectiveTBI vaddr is_instr (← readReg PSTATE).EL)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((((← (EffectiveTCMA vaddr (← readReg PSTATE).EL)) == 1#1) && (((Sail.BitVec.extractLsb vaddr 59 55) == 0b00000#5) || ((Sail.BitVec.extractLsb vaddr 59 55) == 0b11111#5))) : Bool)
              then (do (pure false))
              else
                (do (if ((! (← (AArch64_AllocationTagAccessIsEnabled accdesc.el))) : Bool)
                    then (do (pure false))
                    else
                      (do (if (((← readReg PSTATE).TCO == 1#1) : Bool)
                          then (do (pure false))
                          else
                            (do (if ((←((pure ((← (HaveMTEStoreOnlyExt ())) && (! accdesc.write))) <&&> (do
                                     (StoreOnlyTagCheckingEnabled accdesc.el)))) : Bool)
                                then (do (pure false))
                                else (do (pure true)))))))))))))

def PhysMemTagRead (desc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM (PhysMemRetStatus × (BitVec 4)) := do
  (pure ((← (undefined_PhysMemRetStatus ())), (← (undefined_bitvector 4))))

def AArch64_AllocationTagCheck (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (ptag : (BitVec 4)) : SailM Bool := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let readtag ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_AllocationTagged) : Bool)
  then
    (do let (memstatus, readtag) ← (( do
          let (tup__0, tup__1) ← do (PhysMemTagRead memaddrdesc accdesc)
          let memstatus : PhysMemRetStatus := tup__0
          let readtag : (BitVec 4) := tup__1
          (pure (memstatus, readtag)) ) : SailM (PhysMemRetStatus × (BitVec 4)) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalReadAbort memstatus memaddrdesc 1 accdesc))
        else (do (pure ())))
        (pure (ptag == readtag)))
  else (do (pure true)))

def AArch64_CanonicalTagCheck (memaddrdesc : AddressDescriptor) (ptag : (BitVec 4)) : Bool :=
  let expected_tag : (BitVec 4) :=
    if ((((BitVec.access memaddrdesc.vaddress 55) : BitVec 1) == 0#1) : Bool)
    then 0b0000#4
    else 0b1111#4
  (ptag == expected_tag)

def AArch64_CheckTag (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (ptag : (BitVec 4)) : SailM Bool := do
  (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_AllocationTagged) : Bool)
  then (do (AArch64_AllocationTagCheck memaddrdesc accdesc ptag))
  else
    (do (if ((BEq.beq memaddrdesc.memattrs.tags MemTag_CanonicallyTagged) : Bool)
        then (do (pure (AArch64_CanonicalTagCheck memaddrdesc ptag)))
        else (do (pure true)))))

def AArch64_PhysicalTag (vaddr : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb vaddr 59 56)

def AArch64_EffectiveTCF (el : (BitVec 2)) : SailM (BitVec 2) := do
  let tcf ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let regime ← (( do (TranslationRegime el) ) : SailM Regime )
  let tcf ← (( do
    match regime with
    | .Regime_EL3 => (do (pure (_get_SCTLR_EL3_Type_TCF (← readReg SCTLR_EL3))))
    | .Regime_EL2 => (do (pure (_get_SCTLR_EL2_Type_TCF (← readReg SCTLR_EL2))))
    | .Regime_EL20 =>
      (do
        (if ((el == EL0) : Bool)
        then (do (pure (_get_SCTLR_EL2_Type_TCF0 (← readReg SCTLR_EL2))))
        else (do (pure (_get_SCTLR_EL2_Type_TCF (← readReg SCTLR_EL2))))))
    | .Regime_EL10 =>
      (do
        (if ((el == EL0) : Bool)
        then (do (pure (_get_SCTLR_EL1_Type_TCF0 (← readReg SCTLR_EL1))))
        else (do (pure (_get_SCTLR_EL1_Type_TCF (← readReg SCTLR_EL1))))))
    | _ =>
      (do
        (Unreachable ())
        (pure tcf)) ) : SailM (BitVec 2) )
  (if ((tcf == 0b11#2) : Bool)
  then
    (do (if ((! (← (HaveMTEAsymFaultExt ()))) : Bool)
        then
          (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESTCF 2)
              (pure __tup_1))
        else (do (pure tcf))))
  else (do (pure tcf)))

def AArch64_RaiseTagCheckFault (va : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  let except ← (( do (AArch64_AbortSyndrome Exception_DataAbort fault va target_el) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def undefined_TFSRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSRE0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TFSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TFSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_ReportTagCheckFault (el : (BitVec 2)) (ttbr : (BitVec 1)) : SailM Unit := do
  let questionMark := el
  (if ((questionMark == EL3) : Bool)
  then
    (do sail_assert (ttbr == 0#1) "sail-arm/arm-v9.4-a/src/v8_base.sail:22983.28-22983.29"
        writeReg TFSR_EL3 (Sail.BitVec.updateSubrange (← readReg TFSR_EL3) 0 0 1#1))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if ((ttbr == 0#1) : Bool)
              then (do writeReg TFSR_EL2 (Sail.BitVec.updateSubrange (← readReg TFSR_EL2) 0 0 1#1))
              else (do writeReg TFSR_EL2 (Sail.BitVec.updateSubrange (← readReg TFSR_EL2) 1 1 1#1))))
        else
          (do (if ((questionMark == EL1) : Bool)
              then
                (do (if ((ttbr == 0#1) : Bool)
                    then (do writeReg TFSR_EL1 (Sail.BitVec.updateSubrange (← readReg TFSR_EL1) 0 0 1#1))
                    else (do writeReg TFSR_EL1 (Sail.BitVec.updateSubrange (← readReg TFSR_EL1) 1 1 1#1))))
              else
                (do (if ((questionMark == EL0) : Bool)
                    then
                      (do (if ((ttbr == 0#1) : Bool)
                          then (do writeReg TFSRE0_EL1 (Sail.BitVec.updateSubrange (← readReg TFSRE0_EL1) 0 0 1#1))
                          else (do writeReg TFSRE0_EL1 (Sail.BitVec.updateSubrange (← readReg TFSRE0_EL1) 1 1 1#1))))
                    else (do (pure ())))))))))

def AArch64_TagCheckFault (vaddress : (BitVec 64)) (accdesc : AccessDescriptor) : SailM Unit := do
  let tcf ← (( do (AArch64_EffectiveTCF accdesc.el) ) : SailM (BitVec 2) )
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_TagCheck }
  match tcf with
  | 0b00 => (pure ())
  | 0b01 => (AArch64_RaiseTagCheckFault vaddress fault)
  | 0b10 =>
    (do
      (if ((← (HaveMTEAsyncExt ())) : Bool)
      then (do (AArch64_ReportTagCheckFault accdesc.el ((BitVec.access vaddress 55) : BitVec 1)))
      else (do (pure ()))))
  | _ =>
    (do
      (if ((← (HaveMTEAsymFaultExt ())) : Bool)
      then
        (do (if (accdesc.read : Bool)
            then (do (AArch64_RaiseTagCheckFault vaddress fault))
            else (do (AArch64_ReportTagCheckFault accdesc.el ((BitVec.access vaddress 55) : BitVec 1)))))
      else (do (pure ()))))

def NumBreakpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of breakpoints")

def NumContextAwareBreakpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of context-aware breakpoints")

/-- Type quantifiers: n : Int -/
def AArch64_ReservedBreakpointType (n : Int) (bt2_in : (BitVec 1)) (bt_in : (BitVec 4)) : SailM (Constraint × (BitVec 1) × (BitVec 4)) := SailME.run do
  let bt2 : (BitVec 1) := bt2_in
  let bt : (BitVec 4) := bt_in
  let reserved : Bool := false
  let context_aware ← (( do (pure (n ≥b ((← (NumBreakpointsImplemented ())) -i (← (NumContextAwareBreakpointsImplemented ()))))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
  let reserved ← (( do
    (if ((bt2 == 0#1) : Bool)
    then
      (do let reserved : Bool :=
            if (((! (let b__1 := bt
                   if ((((Sail.BitVec.extractLsb b__1 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__1 1 1) == (0#1 : (BitVec 1)))) : Bool)
                   then true
                   else false : Bool)) && (! context_aware)) : Bool)
            then true
            else reserved
          let reserved : Bool :=
            if (((let b__2 := bt
                 if (((Sail.BitVec.extractLsb b__2 3 3) == (1#1 : (BitVec 1))) : Bool)
                 then true
                 else false : Bool) && (! (HaveEL EL2))) : Bool)
            then true
            else reserved
          let reserved ← (( do
            (if ((←((pure (let b__3 := bt
                 if (((Sail.BitVec.extractLsb b__3 3 1) == (0b011#3 : (BitVec 3))) : Bool)
                 then true
                 else
                   (if (((Sail.BitVec.extractLsb b__3 3 2) == (0b11#2 : (BitVec 2))) : Bool)
                   then true
                   else false) : Bool)) <&&> (do
                 (pure (! (← (HaveVirtHostExt ()))))) <&&> (do
                 (pure (! (← (HaveV82Debug ()))))))) : Bool)
            then (do (pure true))
            else (do (pure reserved))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
          (if (((←((pure (let b__5 := bt
                 if (((Sail.BitVec.extractLsb b__5 3 1) == (0b010#3 : (BitVec 3))) : Bool)
                 then true
                 else false : Bool)) <&&> (do
                 (pure (! (← (HaveFeatABLE ()))))))) && (! (HaveAArch32EL EL1))) : Bool)
          then (do (pure true))
          else (do (pure reserved))))
    else
      (do (if ((! (let b__0 := bt
               if ((((Sail.BitVec.extractLsb b__0 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 1 1) == (0#1 : (BitVec 1)))) : Bool)
               then true
               else false : Bool)) : Bool)
          then (do (pure true))
          else (do (pure reserved))))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Bool )
  let (bt, bt2) ← (( do
    (if (reserved : Bool)
    then
      (do let c ← (( do (undefined_Constraint ()) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) Constraint )
          let (bt, bt2, c) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableBits Unpredictable_RESBPTYPE 5)
            let c : Constraint := tup__0
            let bt2 : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 4 4)
            let bt : (BitVec 4) := (Sail.BitVec.extractLsb tup__1 3 0)
            (pure (bt, bt2, c)) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) ((BitVec 4) × (BitVec 1) × Constraint) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23104.65-23104.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw (← do (pure (c, (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bits 4))))))
          else (do (pure ())))
          (pure (bt, bt2)))
    else (do (pure (bt, bt2)))) ) : SailME (Constraint × (BitVec 1) × (BitVec 4)) ((BitVec 4) × (BitVec 1)) )
  (pure (Constraint_NONE, bt2, bt))

def undefined_CONTEXTIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CONTEXTIDR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_DBGBCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGBCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_DBGBCR_EL1_Type_BAS (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 8 5)

def _get_DBGWCR_EL1_Type_BAS (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 12 5)

def _get_DBGBCR_EL1_Type_BT2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_DBGBCR_EL1_Type_HMC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_DBGWCR_EL1_Type_HMC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_DBGBCR_EL1_Type_LBN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _get_DBGWCR_EL1_Type_LBN (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _get_DBGBCR_EL1_Type_LBNX (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_DBGWCR_EL1_Type_LBNX (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_DBGBCR_EL1_Type_MASK (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 28 24)

def _get_DBGWCR_EL1_Type_MASK (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 28 24)

def _get_DBGBCR_EL1_Type_PMC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_DBGBCR_EL1_Type_SSC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_DBGWCR_EL1_Type_SSC (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_DBGBCR_EL1_Type_SSCE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_DBGWCR_EL1_Type_SSCE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def undefined_DBGBVR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DBGBVR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTTBR_EL2_Type_VMID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_VTTBR_Type_VMID (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 55 48)

def DebugAddrTop (_ : Unit) : SailM Int := do
  (if ((← (Have56BitVAExt ())) : Bool)
  then (do (pure 55))
  else
    (do (if ((← (Have52BitVAExt ())) : Bool)
        then (do (pure 52))
        else (do (pure 48)))))

def undefined_EDSCR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDSCR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def EDSCR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDSCR2 ) : SailM EDSCR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDSCR_EL1) 32 32)))

def HaltOnBreakpointOrWatchpoint (_ : Unit) : SailM Bool := do
  (HaltingAllowed ()) <&&> (do
    (pure ((_get_EDSCR_Type_HDE (← (EDSCR_read ()))) == 1#1))) <&&> (do
    (pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)))

def NumWatchpointsImplemented (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of watchpoints")

def SelfHostedExtendedBPWPEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure ((← (NumBreakpointsImplemented ())) ≤b 16)) <&&> (do
       (pure ((← (NumWatchpointsImplemented ())) ≤b 16))))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_MDCR_EL3_Type_EBWE (← readReg MDCR_EL3)) == 0#1))) <||> (do
             (EL2Enabled ()) <&&> (do
               (pure ((_get_MDCR_EL2_Type_EBWE (← readReg MDCR_EL2)) == 0#1)))))) : Bool)
        then (do (pure false))
        else (do (pure ((_get_MDSCR_EL1_Type_EMBWE (← readReg MDSCR_EL1)) == 1#1))))))

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 64 -/
def IsBreakpointEnabled (n : Nat) : SailM Bool := do
  (if ((←((pure (n >b 15)) <&&> (do
       (pure (! (← (HaltOnBreakpointOrWatchpoint ())))) <&&> (do
         (pure (! (← (SelfHostedExtendedBPWPEnabled ()))))) <||> (do
         (HaltOnBreakpointOrWatchpoint ()) <&&> (do
           (pure ((_get_EDSCR2_Type_EHBWE (← (EDSCR2_read ()))) == 0#1))))))) : Bool)
  then (do (pure false))
  else (do (pure ((_get_DBGBCR_EL1_Type_E (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) == 1#1))))

def undefined_VTCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VTCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTCR_EL2_Type_GCSH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 40 40)

def _get_VTCR_EL2_Type_NSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_VTCR_EL2_Type_NSW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_VTCR_EL2_Type_S2PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_VTCR_EL2_Type_S2POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_VTCR_EL2_Type_SL0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_VSTCR_EL2_Type_SL0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_VTCR_EL2_Type_SL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_VSTCR_EL2_Type_SL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_VTCR_EL2_Type_TL0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_VTCR_EL2_Type_TL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_VTCR_EL2_Type_VS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_VTTBR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_VTTBR_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_VTTBR_EL2_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def VTTBR_EL2_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _VTTBR_EL2 ) : SailM VTTBR_EL2_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg VTTBR) 0 64)))

/-- Type quantifiers: k_isbreakpnt : Bool, k_linked_to : Bool, n_in : Int -/
def AArch64_BreakpointValueMatch (n_in : Int) (vaddress : (BitVec 64)) (linked_to : Bool) (isbreakpnt : Bool) : SailM (Bool × Bool) := SailME.run do
  let n : Int := n_in
  let c ← (( do (undefined_Constraint ()) ) : SailME (Bool × Bool) Constraint )
  let (c, n) ← (( do
    (if ((n ≥b (← (NumBreakpointsImplemented ()))) : Bool)
    then
      (do let (c, n) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger 0 ((← (NumBreakpointsImplemented ())) -i 1) Unpredictable_BPNOTIMPL)
            let c : Constraint := tup__0
            let n : Int := tup__1
            (pure (c, n)) ) : SailME (Bool × Bool) (Constraint × Int) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23258.65-23258.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw ((false, false) : (Bool × Bool)))
          else (do (pure ())))
          (pure (c, n)))
    else (do (pure (c, n)))) ) : SailME (Bool × Bool) (Constraint × Int) )
  let n := n
  sail_assert ((0 ≤b n) && (n <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23265.42-23265.43"
  (if ((! (← (IsBreakpointEnabled n))) : Bool)
  then (do (pure (false, false)))
  else
    (do let dbgtype ← (( do (pure (_get_DBGBCR_EL1_Type_BT (GetElem?.getElem! (← readReg DBGBCR_EL1) n))) ) : SailME (Bool × Bool) (BitVec 4) )
        let bt2 ← (( do
          (if ((← (HaveFeatABLE ())) : Bool)
          then (do (pure (_get_DBGBCR_EL1_Type_BT2 (GetElem?.getElem! (← readReg DBGBCR_EL1) n))))
          else (do (pure 0#1))) ) : SailME (Bool × Bool) (BitVec 1) )
        let (bt2, c, dbgtype) ← (( do
          let (tup__0, tup__1, tup__2) ← do (AArch64_ReservedBreakpointType n bt2 dbgtype)
          let c : Constraint := tup__0
          let bt2 : (BitVec 1) := tup__1
          let dbgtype : (BitVec 4) := tup__2
          (pure (bt2, c, dbgtype)) ) : SailME (Bool × Bool) ((BitVec 1) × Constraint × (BitVec 4)) )
        (if ((BEq.beq c Constraint_DISABLED) : Bool)
        then (do (pure (false, false)))
        else
          (do let match_addr : Bool :=
                (let b__8 := dbgtype
                if ((((Sail.BitVec.extractLsb b__8 3 3) == (0#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__8 1 1) == (0#1 : (BitVec 1)))) : Bool)
                then true
                else false : Bool)
              let mismatch : Bool :=
                (let b__7 := dbgtype
                if (((Sail.BitVec.extractLsb b__7 3 1) == (0b010#3 : (BitVec 3))) : Bool)
                then true
                else false : Bool)
              let match_vmid : Bool :=
                (let b__6 := dbgtype
                if (((Sail.BitVec.extractLsb b__6 3 2) == (0b10#2 : (BitVec 2))) : Bool)
                then true
                else false : Bool)
              let match_cid : Bool :=
                (let b__5 := dbgtype
                if (((Sail.BitVec.extractLsb b__5 3 1) == (0b001#3 : (BitVec 3))) : Bool)
                then true
                else false : Bool)
              let match_cid1 : Bool :=
                (let b__3 := dbgtype
                if (((Sail.BitVec.extractLsb b__3 3 1) == (0b101#3 : (BitVec 3))) : Bool)
                then true
                else
                  (if (((Sail.BitVec.extractLsb b__3 2 1) == (0b11#2 : (BitVec 2))) : Bool)
                  then true
                  else false) : Bool)
              let match_cid2 : Bool :=
                (let b__2 := dbgtype
                if (((Sail.BitVec.extractLsb b__2 3 2) == (0b11#2 : (BitVec 2))) : Bool)
                then true
                else false : Bool)
              let linking_enabled : Bool :=
                ((let b__0 := dbgtype
                  if (((Sail.BitVec.extractLsb b__0 1 0) == (0b11#2 : (BitVec 2))) : Bool)
                  then true
                  else
                    (if ((((Sail.BitVec.extractLsb b__0 3 3) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
                    then true
                    else false) : Bool) || (bt2 == 1#1))
              (if ((linked_to && (! linking_enabled)) : Bool)
              then (do (pure (false, false)))
              else
                (do (if ((((! linked_to) && linking_enabled) && (! match_addr)) : Bool)
                    then (do (pure (false, false)))
                    else
                      (do (if (((linked_to && match_addr) && isbreakpnt) : Bool)
                          then
                            (do (if ((! (← (ConstrainUnpredictableBool Unpredictable_BPLINKEDADDRMATCH))) : Bool)
                                then (do SailME.throw ((false, false) : (Bool × Bool)))
                                else (do (pure ()))))
                          else (do (pure ())))
                          (if ((←((pure mismatch) <&&> (do
                               (UsingAArch32 ())))) : Bool)
                          then (do (pure (false, false)))
                          else
                            (do let bvr_match : Bool := false
                                let bxvr_match : Bool := false
                                let mask ← (( do (undefined_int ()) ) : SailME (Bool × Bool) Int )
                                let mask ← (( do
                                  (if ((← (HaveFeatABLE ())) : Bool)
                                  then
                                    (do let mask ← (( (pure (BitVec.toNat (_get_DBGBCR_EL1_Type_MASK (GetElem?.getElem! (← readReg DBGBCR_EL1) n)))) ) : SailME (Bool × Bool) Int )
                                        let mask ← (( do
                                          (if (((mask == 1) || (mask == 2)) : Bool)
                                          then
                                            (do let (c, mask) ← (( do
                                                  let (tup__0, tup__1) ← do (ConstrainUnpredictableInteger 3 31 Unpredictable_RESBPMASK)
                                                  let c : Constraint := tup__0
                                                  let mask : Int := tup__1
                                                  (pure (c, mask)) ) : SailME (Bool × Bool) (Constraint × Int) )
                                                sail_assert ((BEq.beq c Constraint_DISABLED) || ((BEq.beq c Constraint_NONE) || (BEq.beq c Constraint_UNKNOWN))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23327.92-23327.93"
                                                match c with
                                                | .Constraint_DISABLED => SailME.throw ((false, false) : (Bool × Bool))
                                                | .Constraint_NONE => (pure 0)
                                                | _ => (pure mask))
                                          else (do (pure mask))) ) : SailME (Bool × Bool) Int )
                                        (if ((mask != 0) : Bool)
                                        then
                                          (do (if ((←((pure ((match_cid || match_cid1) || match_cid2)) <||> (do
                                                   (pure (((_get_DBGBCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) != 0b1111#4) && (HaveAArch32 ())))))) : Bool)
                                              then
                                                (do (if ((! (← (ConstrainUnpredictableBool Unpredictable_BPMASK))) : Bool)
                                                    then (do SailME.throw ((false, false) : (Bool × Bool)))
                                                    else (do (pure ()))))
                                              else (do (pure ()))))
                                        else
                                          (do (if (mismatch : Bool)
                                              then (do SailME.throw ((false, false) : (Bool × Bool)))
                                              else (do (pure ())))))
                                        (pure mask))
                                  else (do (pure 0))) ) : SailME (Bool × Bool) Int )
                                let mask := mask
                                let bvr_match ← (( do
                                  (if (match_addr : Bool)
                                  then
                                    (do let byte_select_match ← (( do (undefined_bool ()) ) : SailME (Bool × Bool) Bool )
                                        let byte := (BitVec.toNat (Sail.BitVec.extractLsb vaddress 1 0))
                                        let byte_select_match ← (( do
                                          (if ((HaveAArch32 ()) : Bool)
                                          then
                                            (do sail_assert ((byte == 0) || (byte == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23360.40-23360.41"
                                                (pure (((BitVec.access (_get_DBGBCR_EL1_Type_BAS (GetElem?.getElem! (← readReg DBGBCR_EL1) n)) byte) : BitVec 1) == 1#1)))
                                          else
                                            (do sail_assert (byte == 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:23363.28-23363.29"
                                                (pure true))) ) : SailME (Bool × Bool) Bool )
                                        let top ← (( do (DebugAddrTop ()) ) : SailME (Bool × Bool) Int )
                                        let bottom := 2
                                        let top ← (( do
                                          (if ((←((pure (top <b 55)) <&&> (do
                                               (pure (! (is_ones_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 top)))) <&&> (do
                                               (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 top)))) <&&> (do
                                               (ConstrainUnpredictableBool Unpredictable_DBGxVR_RESS)))) : Bool)
                                          then (do (pure 63))
                                          else (do (pure top))) ) : SailME (Bool × Bool) Int )
                                        let top := top
                                        (if ((mask >b bottom) : Bool)
                                        then
                                          (do sail_assert ((0 ≤b mask) && ((mask ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23373.71-23373.72"
                                              let bvr_match ← (pure (((Sail.BitVec.extractLsb vaddress top mask) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) top mask)) && byte_select_match))
                                              (if ((←((pure bvr_match) <&&> (do
                                                   (pure (! (is_zero_subrange (GetElem?.getElem! (← readReg DBGBVR_EL1) n) (mask -i 1) bottom)))))) : Bool)
                                              then (do (ConstrainUnpredictableBool Unpredictable_BPMASKEDBITS))
                                              else (do (pure bvr_match))))
                                        else
                                          (do sail_assert ((0 ≤b bottom) && ((bottom ≤b top) && (top <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:23380.75-23380.76"
                                              (pure (((Sail.BitVec.extractLsb vaddress top bottom) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) top bottom)) && byte_select_match)))))
                                  else
                                    (do (if (match_cid : Bool)
                                        then
                                          (do (if ((← (IsInHost ())) : Bool)
                                              then (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL2) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0))))
                                              else (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL1) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0)))))))
                                        else
                                          (do (if (match_cid1 : Bool)
                                              then (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure (! (← (IsInHost ()))))) <&&> (do (pure ((Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL1) 31 0) == (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 31 0)))))
                                              else (do (pure bvr_match))))))) ) : SailME (Bool × Bool) Bool )
                                let bxvr_match ← (( do
                                  (if (match_vmid : Bool)
                                  then
                                    (do let vmid ← (( do (undefined_bitvector 16) ) : SailME (Bool × Bool) (BitVec 16) )
                                        let bvr_vmid ← (( do (undefined_bitvector 16) ) : SailME (Bool × Bool) (BitVec 16) )
                                        let (bvr_vmid, vmid) ← (( do
                                          (if ((←((pure (! (← (Have16bitVMID ())))) <||> (do
                                               (pure ((_get_VTCR_EL2_Type_VS (← readReg VTCR_EL2)) == 0#1))))) : Bool)
                                          then
                                            (do let vmid ← (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ()))) 7 0) 16))
                                                let bvr_vmid ← (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 39 32) 16))
                                                (pure (bvr_vmid, vmid)))
                                          else
                                            (do let vmid ← (pure (_get_VTTBR_EL2_Type_VMID (← (VTTBR_EL2_read ()))))
                                                let bvr_vmid ← (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 47 32))
                                                (pure (bvr_vmid, vmid)))) ) : SailME (Bool × Bool) ((BitVec 16) × (BitVec 16)) )
                                        (pure ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure (! (← (IsInHost ()))))))) && (vmid == bvr_vmid))))
                                  else
                                    (do (if (match_cid2 : Bool)
                                        then (do (pure ((← readReg PSTATE).EL != EL3)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg DBGBVR_EL1) n) 63 32) == (Sail.BitVec.extractLsb (← readReg CONTEXTIDR_EL2) 31 0)))))
                                        else (do (pure bxvr_match))))) ) : SailME (Bool × Bool) Bool )
                                let bvr_match_valid : Bool := ((match_addr || match_cid) || match_cid1)
                                let bxvr_match_valid : Bool := (match_vmid || match_cid2)
                                let value_match_name : Bool := (((! bxvr_match_valid) || bxvr_match) && ((! bvr_match_valid) || bvr_match))
                                (pure (value_match_name, mismatch))))))))))))

/-- Type quantifiers: k_isbreakpnt : Bool -/
def CheckValidStateMatch (ssc_in : (BitVec 2)) (ssce_in : (BitVec 1)) (hmc_in : (BitVec 1)) (pxc_in : (BitVec 2)) (isbreakpnt : Bool) : SailM (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) := SailME.run do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do sail_assert (ssce_in == 0#1) "sail-arm/arm-v9.4-a/src/v8_base.sail:23417.29-23417.30")
  else (do (pure ())))
  let reserved : Bool := false
  let ssc : (BitVec 2) := ssc_in
  let ssce : (BitVec 1) := ssce_in
  let hmc : (BitVec 1) := hmc_in
  let pxc : (BitVec 2) := pxc_in
  let reserved ← (( do
    let b__0 := (((hmc +++ ssce) +++ ssc) +++ pxc)
    (if ((b__0 == (0b001110#6 : (BitVec 6))) : Bool)
    then (do (pure true))
    else
      (do (if (((Sail.BitVec.extractLsb b__0 5 3) == (0b001#3 : (BitVec 3))) : Bool)
          then (do (pure (! (← (HaveSecureState ())))))
          else
            (do (if ((((Sail.BitVec.extractLsb b__0 5 2) == (0x8#4 : (BitVec 4))) && ((Sail.BitVec.extractLsb b__0 0 0) == (0#1 : (BitVec 1)))) : Bool)
                then (do (pure true))
                else
                  (do (if ((b__0 == (0b100110#6 : (BitVec 6))) : Bool)
                      then (do (pure true))
                      else
                        (do (if ((((Sail.BitVec.extractLsb b__0 5 3) == (0b101#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 1 0) == (0b10#2 : (BitVec 2)))) : Bool)
                            then (do (pure true))
                            else
                              (do (if (((Sail.BitVec.extractLsb b__0 4 4) == (1#1 : (BitVec 1))) : Bool)
                                  then (do (pure ((ssc != 0b01#2) || (((hmc +++ pxc) == 0b000#3) || ((hmc +++ pxc) == 0b110#3)))))
                                  else (do (pure false))))))))))))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let reserved : Bool :=
    if (((((! isbreakpnt) || (! (HaveAArch32EL EL1))) && ((hmc +++ pxc) == 0b000#3)) && (ssc != 0b11#2)) : Bool)
    then true
    else reserved
  let reserved : Bool :=
    if ((((! (HaveEL EL3)) && (! (HaveEL EL2))) && ((hmc != 0#1) || (ssc != 0b00#2))) : Bool)
    then true
    else reserved
  let reserved : Bool :=
    if ((((! (HaveEL EL3)) && ((ssc == 0b01#2) || (ssc == 0b10#2))) && (((hmc +++ ssc) +++ pxc) != 0b10100#5)) : Bool)
    then true
    else reserved
  let reserved ← (( do
    (if (((←((pure (! (HaveEL EL3))) <||> (do
           (pure (! (← (HaveAArch64 ()))))))) && (((hmc +++ ssc) +++ pxc) == 0b11000#5)) : Bool)
    then (do (pure true))
    else (do (pure reserved))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let reserved : Bool :=
    if (((! (HaveEL EL2)) && (((hmc +++ ssc) +++ pxc) == 0b11100#5)) : Bool)
    then true
    else reserved
  let reserved ← (( do
    (if (((! (← (HaveSecureEL2Ext ()))) && (let b__6 := ((hmc +++ ssc) +++ pxc)
         if ((b__6 == (0b01100#5 : (BitVec 5))) : Bool)
         then true
         else
           (if ((b__6 == (0b10100#5 : (BitVec 5))) : Bool)
           then true
           else
             (if ((((Sail.BitVec.extractLsb b__6 3 2) == (0b11#2 : (BitVec 2))) && ((Sail.BitVec.extractLsb b__6 0 0) == (1#1 : (BitVec 1)))) : Bool)
             then true
             else false)) : Bool)) : Bool)
    then (do (pure true))
    else (do (pure reserved))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Bool )
  let (hmc, pxc, ssc, ssce) ← (( do
    (if (reserved : Bool)
    then
      (do let c ← (( do (undefined_Constraint ()) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) Constraint )
          let (c, hmc, pxc, ssc, ssce) ← (( do
            let (tup__0, tup__1) ← do (ConstrainUnpredictableBits Unpredictable_RESBPWPCTRL 6)
            let c : Constraint := tup__0
            let hmc : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 5 5)
            let ssc : (BitVec 2) := (Sail.BitVec.extractLsb tup__1 4 3)
            let ssce : (BitVec 1) := (Sail.BitVec.extractLsb tup__1 2 2)
            let pxc : (BitVec 2) := (Sail.BitVec.extractLsb tup__1 1 0)
            (pure (c, hmc, pxc, ssc, ssce)) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) (Constraint × (BitVec 1) × (BitVec 2) × (BitVec 2) × (BitVec 1)) )
          sail_assert ((BEq.beq c Constraint_DISABLED) || (BEq.beq c Constraint_UNKNOWN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:23473.65-23473.66"
          (if ((BEq.beq c Constraint_DISABLED) : Bool)
          then (do SailME.throw (← do (pure (c, (← (__UNKNOWN_bits 2)), (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bit ())), (← (__UNKNOWN_bits 2))))))
          else (do (pure ())))
          (pure (hmc, pxc, ssc, ssce)))
    else (do (pure (hmc, pxc, ssc, ssce)))) ) : SailME (Constraint × (BitVec 2) × (BitVec 1) × (BitVec 1) × (BitVec 2)) ((BitVec 1) × (BitVec 2) × (BitVec 2) × (BitVec 1)) )
  (pure (Constraint_NONE, ssc, ssce, hmc, pxc))

def ContextMatchingBreakpointRange (_ : Unit) : SailM (Int × Int) := do
  let b ← (( do (NumBreakpointsImplemented ()) ) : SailM Int )
  let c ← (( do (NumContextAwareBreakpointsImplemented ()) ) : SailM Int )
  (if ((b ≤b 16) : Bool)
  then (do (pure ((b -i c), (b -i 1))))
  else
    (do (if ((c ≤b 16) : Bool)
        then (do (pure ((16 -i c), 15)))
        else (do (pure (0, (c -i 1)))))))

/-- Type quantifiers: n : Int -/
def IsContextMatchingBreakpoint (n : Int) : SailM Bool := do
  let lower ← (( do (undefined_int ()) ) : SailM Int )
  let upper ← (( do (undefined_int ()) ) : SailM Int )
  let (lower, upper) ← (( do
    let (tup__0, tup__1) ← do (ContextMatchingBreakpointRange ())
    let lower : Int := tup__0
    let upper : Int := tup__1
    (pure (lower, upper)) ) : SailM (Int × Int) )
  let upper := upper
  let lower := lower
  (pure ((n ≥b lower) && (n ≤b upper)))


end ArmASL.Functions
