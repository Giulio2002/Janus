import ArmASL.Part06

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_s2aarch64 : Bool -/
def S2DecodeMemAttrs (attr : (BitVec 4)) (sh : (BitVec 2)) (s2aarch64 : Bool) : SailM MemoryAttributes := do
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    let b__0 := attr
    (if (((Sail.BitVec.extractLsb b__0 3 2) == (0b00#2 : (BitVec 2))) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          (pure { memattrs with device := (← do (DecodeDevice (Sail.BitVec.extractLsb attr 1 0))) }))
    else
      (do (if ((b__0 == (0x4#4 : (BitVec 4))) : Bool)
          then
            (do (if ((←((pure s2aarch64) <&&> (do
                     (HaveMTEPermExt ())))) : Bool)
                then
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability 0b11#2)) })
                      (pure { memattrs with inner := (← do (S2DecodeCacheability 0b11#2)) }))
                else
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 3 2))) })
                      (pure { memattrs with inner := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 1 0))) }))))
          else
            (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                let memattrs ← (pure { memattrs with outer := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 3 2))) })
                (pure { memattrs with inner := (← do (S2DecodeCacheability (Sail.BitVec.extractLsb attr 1 0))) }))))) ) : SailM MemoryAttributes )
  let memattrs ← (pure { memattrs with shareability := (← do (DecodeShareability sh)) })
  (if ((←((pure s2aarch64) <&&> (do
       (HaveMTEPermExt ())))) : Bool)
  then (do (pure { memattrs with notagaccess := (attr == 0b0100#4) }))
  else (do (pure { memattrs with notagaccess := false })))

/-- Type quantifiers: k_s2aarch64 : Bool -/
def S2CombineS1MemAttrs (s1_memattrs : MemoryAttributes) (s2_memattrs : MemoryAttributes) (s2aarch64 : Bool) : SailM MemoryAttributes := do
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let memattrs ← (( do
    (if (((BEq.beq s1_memattrs.memtype MemType_Device) && (BEq.beq s2_memattrs.memtype MemType_Device)) : Bool)
    then
      (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          (pure { memattrs with device := (S2CombineS1Device s1_memattrs.device s2_memattrs.device) }))
    else
      (do (if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
          then (do (pure s1_memattrs))
          else
            (do (if ((BEq.beq s2_memattrs.memtype MemType_Device) : Bool)
                then (do (pure s2_memattrs))
                else
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs ← (pure { memattrs with inner := (← do (S2CombineS1AttrHints s1_memattrs.inner s2_memattrs.inner)) })
                      (pure { memattrs with outer := (← do (S2CombineS1AttrHints s1_memattrs.outer s2_memattrs.outer)) }))))))) ) : SailM MemoryAttributes )
  let memattrs ← (pure { memattrs with tags := (← do (S2MemTagType memattrs s1_memattrs.tags)) })
  let memattrs ← (( do
    (if ((! (← (HaveMTEPermExt ()))) : Bool)
    then (do (pure { memattrs with notagaccess := false }))
    else (do (pure { memattrs with notagaccess := (s2_memattrs.notagaccess && (BEq.beq s1_memattrs.tags MemTag_AllocationTagged)) }))) ) : SailM MemoryAttributes )
  let memattrs : MemoryAttributes := { memattrs with shareability := (S2CombineS1Shareability s1_memattrs.shareability s2_memattrs.shareability) }
  let memattrs : MemoryAttributes :=
    if ((((BEq.beq memattrs.memtype MemType_Normal) && (memattrs.inner.attrs == MemAttr_WB)) && (memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then { memattrs with xs := 0#1 }
    else
      (if (s2aarch64 : Bool)
      then { memattrs with xs := (s2_memattrs.xs &&& s1_memattrs.xs) }
      else { memattrs with xs := s1_memattrs.xs })
  (pure { memattrs with shareability := (EffectiveShareability memattrs) })

def undefined_GPCCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GPCCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GPCCR_EL3_Type_GPC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_GPCCR_EL3_Type_L0GPTSZ (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_GPCCR_EL3_Type_ORGN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_GPCCR_EL3_Type_PGS (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_GPCCR_EL3_Type_PPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 2 0)

def DecodePPS (_ : Unit) : SailM Int := do
  match (_get_GPCCR_EL3_Type_PPS (← readReg GPCCR_EL3)) with
  | 0b000 => (pure 32)
  | 0b001 => (pure 36)
  | 0b010 => (pure 40)
  | 0b011 => (pure 42)
  | 0b100 => (pure 44)
  | 0b101 => (pure 48)
  | 0b110 => (pure 52)
  | _ =>
    (do
      (Unreachable ())
      (undefined_int ()))

def AbovePPS (address : (BitVec 56)) : SailM Bool := do
  let pps ← (( do (DecodePPS ()) ) : SailM Int )
  (if ((pps ≥b 56) : Bool)
  then (do (pure false))
  else (do (pure (! (is_zero_subrange address 55 pps)))))

/-- Type quantifiers: level : Int -/
def GPCFault (gpf : GPCF) (level : Int) : SailM GPCFRecord := do
  let fault ← (( do (undefined_GPCFRecord ()) ) : SailM GPCFRecord )
  let fault : GPCFRecord := { fault with gpf := gpf }
  (pure { fault with level := level })

def AArch64_PAMax (_ : Unit) : SailM Int := do
  let pamax ← (( do (__IMPDEF_integer "Maximum Physical Address Size") ) : SailM Int )
  sail_assert ((pamax == 32) || ((pamax == 36) || ((pamax == 40) || ((pamax == 42) || ((pamax == 44) || ((pamax == 48) || ((pamax == 52) || (pamax == 56)))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19468.120-19468.121"
  (pure pamax)

def GPCRegistersConsistent (_ : Unit) : SailM Bool := do
  (if ((←((pure ((_get_GPCCR_EL3_Type_PPS (← readReg GPCCR_EL3)) == 0b111#3)) <||> (do
       (pure ((← (DecodePPS ())) >b (← (AArch64_PAMax ()))))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)) == 0b11#2) : Bool)
        then (do (pure false))
        else
          (do (if (((_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) == 0b01#2) : Bool)
              then (do (pure false))
              else
                (do (if ((←((pure (((_get_GPCCR_EL3_Type_ORGN (← readReg GPCCR_EL3)) +++ (_get_GPCCR_EL3_Type_IRGN (← readReg GPCCR_EL3))) == 0b0000#4)) <&&> (do
                         (pure ((_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) != 0b10#2))))) : Bool)
                    then (do (pure false))
                    else (do (pure true)))))))))

def GPICheck (paspace : PASpace) (gpi : (BitVec 4)) : SailM Bool := do
  let questionMark := gpi
  (if ((questionMark == GPT_NoAccess) : Bool)
  then (do (pure false))
  else
    (do (if ((questionMark == GPT_Secure) : Bool)
        then
          (do sail_assert (← (HaveSecureEL2Ext ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:19498.35-19498.36"
              (pure (BEq.beq paspace PAS_Secure)))
        else
          (do (if ((questionMark == GPT_NonSecure) : Bool)
              then (do (pure (BEq.beq paspace PAS_NonSecure)))
              else
                (do (if ((questionMark == GPT_Root) : Bool)
                    then (do (pure (BEq.beq paspace PAS_Root)))
                    else
                      (do (if ((questionMark == GPT_Realm) : Bool)
                          then (do (pure (BEq.beq paspace PAS_Realm)))
                          else
                            (do (if ((questionMark == GPT_Any) : Bool)
                                then (do (pure true))
                                else
                                  (do (Unreachable ())
                                      (undefined_bool ())))))))))))))

def undefined_GPTBR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GPTBR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def GPIValid (gpi : (BitVec 4)) : SailM Bool := do
  (if ((gpi == GPT_Secure) : Bool)
  then (do (HaveSecureEL2Ext ()))
  else (do (pure ((gpi == GPT_NoAccess) || ((gpi == GPT_NonSecure) || ((gpi == GPT_Root) || ((gpi == GPT_Realm) || (gpi == GPT_Any))))))))

def GPTL0Size (_ : Unit) : SailM Int := SailME.run do
  match (_get_GPCCR_EL3_Type_L0GPTSZ (← readReg GPCCR_EL3)) with
  | 0b0000 => SailME.throw (GPTRange_1GB : Int)
  | 0b0100 => SailME.throw (GPTRange_16GB : Int)
  | 0b0110 => SailME.throw (GPTRange_64GB : Int)
  | 0b1001 => SailME.throw (GPTRange_512GB : Int)
  | _ => (Unreachable ())
  (pure 30)

def DecodeGPTBlock (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Block) "sail-arm/arm-v9.4-a/src/v8_base.sail:19559.37-19559.38"
  let result ← (( do (undefined_GPTEntry ()) ) : SailM GPTEntry )
  (if ((! (IsZero (Sail.BitVec.extractLsb entry 63 8))) : Bool)
  then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ())))))
  else
    (do (if ((! (← (GPIValid (Sail.BitVec.extractLsb entry 7 4)))) : Bool)
        then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ())))))
        else
          (do let result : GPTEntry := { result with gpi := (Sail.BitVec.extractLsb entry 7 4) }
              let result : GPTEntry := { result with level := 0 }
              let result : GPTEntry :=
                match pgs with
                | .PGS_4KB => { result with size := GPTRange_4KB }
                | .PGS_16KB => { result with size := GPTRange_16KB }
                | .PGS_64KB => { result with size := GPTRange_64KB }
              let result ← (pure { result with contig_size := (← do (GPTL0Size ())) })
              (pure (GPCF_None, result))))))

def DecodeGPTContiguous (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := SailME.run do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Contig) "sail-arm/arm-v9.4-a/src/v8_base.sail:19590.38-19590.39"
  let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCF × GPTEntry) GPTEntry )
  (if ((! (IsZero (Sail.BitVec.extractLsb entry 63 10))) : Bool)
  then (do (pure (GPCF_Walk, result)))
  else
    (do let result : GPTEntry := { result with gpi := (Sail.BitVec.extractLsb entry 7 4) }
        (if ((! (← (GPIValid result.gpi))) : Bool)
        then (do (pure (GPCF_Walk, result)))
        else
          (do let result : GPTEntry :=
                match pgs with
                | .PGS_4KB => { result with size := GPTRange_4KB }
                | .PGS_16KB => { result with size := GPTRange_16KB }
                | .PGS_64KB => { result with size := GPTRange_64KB }
              let result ← (( do
                match (Sail.BitVec.extractLsb entry 9 8) with
                | 0b01 => (pure { result with contig_size := GPTRange_2MB })
                | 0b10 => (pure { result with contig_size := GPTRange_32MB })
                | 0b11 => (pure { result with contig_size := GPTRange_512MB })
                | _ => SailME.throw (← do (pure (GPCF_Walk, (← (__UNKNOWN_GPTEntry ()))))) ) : SailME (GPCF × GPTEntry) GPTEntry )
              let result : GPTEntry := { result with level := 1 }
              (pure (GPCF_None, result))))))

/-- Type quantifiers: index : Int -/
def DecodeGPTGranules (pgs : PGSe) (index : Int) (entry : (BitVec 64)) : SailM (GPCF × GPTEntry) := SailME.run do
  let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCF × GPTEntry) GPTEntry )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do
      (if ((! (← (GPIValid (BitVec.slice entry (i *i 4) 4)))) : Bool)
      then (do SailME.throw ((GPCF_Walk, result) : (GPCF × GPTEntry)))
      else (do (pure ())))
  (pure loop_vars)
  let result : GPTEntry := { result with gpi := (BitVec.slice entry (index *i 4) 4) }
  let result : GPTEntry :=
    match pgs with
    | .PGS_4KB => { result with size := GPTRange_4KB }
    | .PGS_16KB => { result with size := GPTRange_16KB }
    | .PGS_64KB => { result with size := GPTRange_64KB }
  let result : GPTEntry := { result with contig_size := result.size }
  let result : GPTEntry := { result with level := 1 }
  (pure (GPCF_None, result))

def DecodeGPTTable (pgs : PGSe) (entry : (BitVec 64)) : SailM (GPCF × GPTTable) := do
  sail_assert ((Sail.BitVec.extractLsb entry 3 0) == GPT_Table) "sail-arm/arm-v9.4-a/src/v8_base.sail:19665.37-19665.38"
  let result ← (( do (undefined_GPTTable ()) ) : SailM GPTTable )
  (if ((! (IsZero ((Sail.BitVec.extractLsb entry 63 52) +++ (Sail.BitVec.extractLsb entry 11 4)))) : Bool)
  then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTTable ())))))
  else
    (do let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
        let p : Int := 12
        let p : Int :=
          match pgs with
          | .PGS_4KB => 12
          | .PGS_16KB => 14
          | .PGS_64KB => 16
        let p := p
        (if ((! (is_zero_subrange entry ((l0sz -i p) -i 2) 12)) : Bool)
        then (do (pure (GPCF_Walk, (← (__UNKNOWN_GPTTable ())))))
        else
          (do let result : GPTTable :=
                match pgs with
                | .PGS_4KB => { result with address := ((Sail.BitVec.extractLsb entry 55 17) +++ (Zeros (n := 17))) }
                | .PGS_16KB => { result with address := ((Sail.BitVec.extractLsb entry 55 15) +++ (Zeros (n := 15))) }
                | .PGS_64KB => { result with address := ((Sail.BitVec.extractLsb entry 55 13) +++ (Zeros (n := 13))) }
              (if ((← (AbovePPS result.address)) : Bool)
              then (do (pure (GPCF_AddressSize, (← (__UNKNOWN_GPTTable ())))))
              else (do (pure (GPCF_None, result))))))))

def DecodePGS (pgs : (BitVec 2)) : SailM PGSe := do
  match pgs with
  | 0b00 => (pure PGS_4KB)
  | 0b10 => (pure PGS_16KB)
  | 0b01 => (pure PGS_64KB)
  | _ =>
    (do
      (Unreachable ())
      (undefined_PGSe ()))

def GPIIndex (pa : (BitVec 56)) : SailM Int := do
  match (← (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)))) with
  | .PGS_4KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 15 12)))
  | .PGS_16KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 17 14)))
  | .PGS_64KB => (pure (BitVec.toNat (Sail.BitVec.extractLsb pa 19 16)))

def GPTLevel0Index (pa : (BitVec 56)) : SailM Int := do
  let pps ← (( do (DecodePPS ()) ) : SailM Int )
  let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
  (if ((pps ≤b l0sz) : Bool)
  then (do (pure 0))
  else
    (do sail_assert ((0 ≤b l0sz) && ((pps -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19758.51-19758.52"
        (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (pps -i 1) l0sz)))))

def GPTLevel1Index (pa : (BitVec 56)) : SailM Int := do
  let l0sz ← (( do (GPTL0Size ()) ) : SailM Int )
  match (← (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3)))) with
  | .PGS_4KB =>
    (do
      sail_assert ((16 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19768.63-19768.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 16))))
  | .PGS_16KB =>
    (do
      sail_assert ((18 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19772.63-19772.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 18))))
  | .PGS_64KB =>
    (do
      sail_assert ((20 ≤b (l0sz -i 1)) && ((l0sz -i 1) <b 56)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19776.63-19776.64"
      (pure (BitVec.toNat (Sail.BitVec.extractLsb pa (l0sz -i 1) 20))))

def GPTTLBCache (pgs : PGSe) (gpt_entry : GPTEntry) : Unit :=
  ()

def GPTTLBLookup (pa : (BitVec 56)) (pgs : PGSe) : SailM GPTTLBLine := do
  (__UNKNOWN_GPTTLBLine ())

def CreatePhysMemRetStatus (fault : Fault) : PhysMemRetStatus :=
  { statuscode := fault
    extflag := 0#1
    merrorstate := ErrorState_Uncategorized
    store64bstatus := (Zeros (n := 64)) }

def undefined_GICC_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def GIC_PENDING_NONE : (BitVec 32) := 0x000003FF#32

def __GIC_InterruptID (intid : InterruptID) : (BitVec 32) :=
  let PPI_OFFSET := 16
  match intid with
  | .InterruptID_CNTP => (BitVec.addInt 0x0000000D#32 PPI_OFFSET)
  | .InterruptID_CNTHP => (BitVec.addInt 0x0000000A#32 PPI_OFFSET)
  | .InterruptID_CNTV => (BitVec.addInt 0x0000000B#32 PPI_OFFSET)
  | _ => GIC_PENDING_NONE

def __GIC_AcknowledgeInterrupt (_ : Unit) : SailM (BitVec 32) := do
  match (← readReg __GIC_Pending) with
  | .some intid =>
    (do
      writeReg __GIC_Pending none
      writeReg __GIC_Active (some intid)
      (pure (__GIC_InterruptID intid)))
  | none => (pure GIC_PENDING_NONE)

def AccessDescriptor_to_Access_kind (accdesc : AccessDescriptor) : (Access_kind arm_acc_type) :=
  match accdesc.acctype with
  | .AccessType_IFETCH => (AK_ifetch ())
  | .AccessType_GPR =>
    (let variety :=
      if (accdesc.exclusive : Bool)
      then AV_exclusive
      else
        (if (accdesc.atomicop : Bool)
        then AV_atomic_rmw
        else AV_plain)
    let strength :=
      if (accdesc.acqpc : Bool)
      then AS_acq_rcpc
      else
        (if ((accdesc.acqsc || accdesc.relsc) : Bool)
        then AS_rel_or_acq
        else AS_normal)
    (AK_explicit
      { variety := variety
        strength := strength }))
  | .AccessType_TTW => (AK_ttw ())
  | .AccessType_ASIMD => (AK_arch (SAcc_ASIMD accdesc.streamingsve))
  | .AccessType_SVE => (AK_arch (SAcc_SVE accdesc.streamingsve))
  | .AccessType_SME => (AK_arch (SAcc_SME accdesc.streamingsve))
  | .AccessType_IC => (AK_arch (SAcc_IC ()))
  | .AccessType_DC => (AK_arch (SAcc_DC ()))
  | .AccessType_DCZero => (AK_arch (SAcc_DCZero ()))
  | .AccessType_AT => (AK_arch (SAcc_AT ()))
  | .AccessType_NV2 => (AK_arch (SAcc_NV2 ()))
  | .AccessType_SPE => (AK_arch (SAcc_SPE ()))
  | .AccessType_GCS => (AK_arch (SAcc_GCS ()))
  | .AccessType_GPTW => (AK_arch (SAcc_GPTW ()))

/-- Type quantifiers: size : Nat, size > 0 -/
def read_request (accdesc : AccessDescriptor) (ti : (Option TranslationInfo)) (size : Nat) (va : (BitVec 64)) (pa : (BitVec 56)) : (Mem_read_request size 64 (BitVec 56) (Option TranslationInfo) arm_acc_type) :=
  { access_kind := (AccessDescriptor_to_Access_kind accdesc)
    va := (some va)
    pa := pa
    translation := ti
    size := size
    tag := false }

def GIC_BASE := 0x2C00#16

def gic_read_ram (offset : (BitVec 16)) : SailM (BitVec 32) := do
  let accdesc ← do (CreateAccDescGPR MemOp_LOAD false true false)
  let pa := (Sail.BitVec.zeroExtend (GIC_BASE +++ offset) 56)
  match (← (sail_mem_read (read_request accdesc none 4 (Sail.BitVec.zeroExtend pa 64) pa))) with
  | .Ok (value, _) => (pure value)
  | .Err _ =>
    (do
      sail_assert false "sail-arm/arm-v9.4-a/src/devices.sail:134.18-134.19"
      throw Error.Exit)

def __GICC_IIDR := 0x0002043B#32

def __GICD_TYPER := (Sail.BitVec.updateSubrange (Sail.BitVec.updateSubrange (Zeros (n := 32)) 10 10 1#1) 4 0 0b00111#5)

def __ReadGIC (offset : (BitVec 16)) : SailM (BitVec 32) := do
  match offset with
  | 0x1004 => (pure __GICD_TYPER)
  | 0x1800 => (pure 0xFFFFFFFF#32)
  | 0x1C04 =>
    (do
      (pure (prerr_bits "[GIC] Read 1C04: " (← (gic_read_ram 0x1C04#16))))
      (gic_read_ram 0x1C04#16))
  | 0x2000 =>
    (do
      (pure (prerr_bits "[GIC] Read GICC_CTLR " (← readReg GICC_CTLR)))
      readReg GICC_CTLR)
  | 0x200C =>
    (do
      let intid ← (( do (__GIC_AcknowledgeInterrupt ()) ) : SailM (BitVec 32) )
      let _ : Unit := (prerr_bits "[GIC] Acknowledged interrupt " intid)
      (pure intid))
  | 0x20FC => (pure __GICC_IIDR)
  | _ =>
    (let _ : Unit := (prerr_bits "[GIC] Read offset: " offset)
    (pure (Zeros (n := 32))))

/-- Type quantifiers: n : Nat, n > 0 -/
def __ReadUART (offset : (BitVec 16)) (n : Nat) : (BitVec (8 * n)) :=
  match offset with
  | _ =>
    (let _ : Unit := (prerr_bits "[UART] Unknown read offset: " offset)
    (Zeros (n := (8 *i n))))

def UART_BASE := 0x3C00#16

/-- Type quantifiers: size : Nat, size > 0 -/
def PhysMemRead (desc : AddressDescriptor) (size : Nat) (accdesc : AccessDescriptor) (translation_info : (Option TranslationInfo)) : SailM (PhysMemRetStatus × (BitVec (8 * size))) := do
  let paddress := desc.paddress.address
  (if (((size ≥b 4) && ((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) GIC_BASE))) : Bool)
  then (do (pure ((CreatePhysMemRetStatus Fault_None), (Sail.BitVec.zeroExtend (← (__ReadGIC (Sail.BitVec.extractLsb paddress 15 0))) (8 *i size)))))
  else
    (do (if (((Sail.BitVec.extractLsb paddress ((Sail.BitVec.length paddress) -i 1) 16) == (ZeroExtend1 (m := (((56 -i 1) -i 16) +i 1)) UART_BASE)) : Bool)
        then (do (pure ((CreatePhysMemRetStatus Fault_None), (__ReadUART (Sail.BitVec.extractLsb paddress 15 0) size))))
        else
          (do match (← (sail_mem_read (read_request accdesc translation_info size desc.vaddress desc.paddress.address))) with
              | .Ok (value, _) => (pure ((CreatePhysMemRetStatus Fault_None), value))
              | .Err statuscode => (pure ((CreatePhysMemRetStatus statuscode), (BitVec.zero (8 *i size))))))))

def GPTWalk (pa : (BitVec 56)) (accdesc : AccessDescriptor) : SailM (GPCFRecord × GPTEntry) := SailME.run do
  let gpi_index ← (( do (undefined_int ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let gpttlbline ← (( do (undefined_GPTTLBLine ()) ) : SailME (GPCFRecord × GPTEntry) GPTTLBLine )
  let pgs ← (( do (DecodePGS (_get_GPCCR_EL3_Type_PGS (← readReg GPCCR_EL3))) ) : SailME (GPCFRecord × GPTEntry) PGSe )
  (if ((← readReg __tlb_enabled) : Bool)
  then
    (do let gpttlbline ← (( do (GPTTLBLookup pa pgs) ) : SailME (GPCFRecord × GPTEntry) GPTTLBLine )
        (if (gpttlbline.valid_name : Bool)
        then (do SailME.throw (← do (pure ((← (GPCNoFault ())), gpttlbline.gpt_entry))))
        else (do (pure ()))))
  else (do (pure ())))
  let base ← (( do (pure (Sail.BitVec.zeroExtend ((_get_GPTBR_EL3_Type_BADDR (← readReg GPTBR_EL3)) +++ (Zeros (n := 12))) 56)) ) : SailME (GPCFRecord × GPTEntry) (BitVec 56) )
  let pps ← (( do (DecodePPS ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let l0sz ← (( do (GPTL0Size ()) ) : SailME (GPCFRecord × GPTEntry) Int )
  let alignment := (Max.max ((pps -i l0sz) +i 3) 12)
  sail_assert (56 ≥b alignment) "sail-arm/arm-v9.4-a/src/v8_base.sail:19809.39-19809.40"
  let base : (BitVec 56) := (base &&& (Complement.complement (Sail.BitVec.zeroExtend (Ones (n := alignment)) 56)))
  let gptaccdesc ← (( do (CreateAccDescGPTW accdesc) ) : SailME (GPCFRecord × GPTEntry) AccessDescriptor )
  let gptaddrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailME (GPCFRecord × GPTEntry) AddressDescriptor )
  let gptaddrdesc ← (pure { gptaddrdesc with memattrs := (← do (WalkMemAttrs (_get_GPCCR_EL3_Type_SH (← readReg GPCCR_EL3)) (_get_GPCCR_EL3_Type_ORGN (← readReg GPCCR_EL3)) (_get_GPCCR_EL3_Type_IRGN (← readReg GPCCR_EL3)))) })
  let gptaddrdesc ← (pure { gptaddrdesc with fault := (← do (NoFault__1 gptaccdesc)) })
  let gptaddrdesc : AddressDescriptor := { gptaddrdesc with paddress := { gptaddrdesc.paddress with paspace := PAS_Root } }
  let gptaddrdesc ← (pure { gptaddrdesc with paddress := (← do (pure { gptaddrdesc.paddress with address := (← do (pure (BitVec.addInt base ((← (GPTLevel0Index pa)) *i 8)))) })) })
  let level_0_entry ← (( do (undefined_bitvector 64) ) : SailME (GPCFRecord × GPTEntry) (BitVec 64) )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailME (GPCFRecord × GPTEntry) PhysMemRetStatus )
  let (level_0_entry, memstatus) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead gptaddrdesc 8 gptaccdesc none)
    let memstatus : PhysMemRetStatus := tup__0
    let level_0_entry : (BitVec 64) := tup__1
    (pure (level_0_entry, memstatus)) ) : SailME (GPCFRecord × GPTEntry) ((BitVec 64) × PhysMemRetStatus) )
  (if ((IsFault__2 memstatus) : Bool)
  then (do (pure ((← (GPCFault GPCF_EABT 0)), (← (__UNKNOWN_GPTEntry ())))))
  else
    (do let result ← (( do (undefined_GPTEntry ()) ) : SailME (GPCFRecord × GPTEntry) GPTEntry )
        let table ← (( do (undefined_GPTTable ()) ) : SailME (GPCFRecord × GPTEntry) GPTTable )
        let gpf ← (( do (undefined_GPCF ()) ) : SailME (GPCFRecord × GPTEntry) GPCF )
        let (gpf, result, table) ← (( do
          let questionMark := (Sail.BitVec.extractLsb level_0_entry 3 0)
          let (gpf, result, table) ← (( do
            (if ((questionMark == GPT_Block) : Bool)
            then
              (do let a__11280 ← (( do
                    let (gpf, result) ← (( do
                      let (tup__0, tup__1) ← do (DecodeGPTBlock pgs level_0_entry)
                      let gpf : GPCF := tup__0
                      let result : GPTEntry := tup__1
                      (pure (gpf, result)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
                    let result : GPTEntry := { result with pa := pa }
                    (if (((← readReg __tlb_enabled) && (BEq.beq gpf GPCF_None)) : Bool)
                    then (do (pure (GPTTLBCache pgs result)))
                    else (do (pure ())))
                    (pure ((← (GPCFault gpf 0)), result)) ) : SailME (GPCFRecord × GPTEntry) (GPCFRecord × GPTEntry) )
                  SailME.throw a__11280)
            else
              (do let (gpf, table) ← (( do
                    (if ((questionMark == GPT_Table) : Bool)
                    then
                      (do let (gpf, table) ← (( do
                            let (tup__0, tup__1) ← do (DecodeGPTTable pgs level_0_entry)
                            let gpf : GPCF := tup__0
                            let table : GPTTable := tup__1
                            (pure (gpf, table)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTTable) )
                          (if ((bne gpf GPCF_None) : Bool)
                          then (do SailME.throw (← do (pure ((← (GPCFault gpf 0)), (← (__UNKNOWN_GPTEntry ()))))))
                          else (do (pure ())))
                          (pure (gpf, table)))
                    else (do SailME.throw (← do (pure ((← (GPCFault GPCF_Walk 0)), (← (__UNKNOWN_GPTEntry ()))))))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTTable) )
                  (pure (gpf, result, table)))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry × GPTTable) )
          (pure (gpf, result, table)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry × GPTTable) )
        sail_assert ((Sail.BitVec.extractLsb level_0_entry 3 0) == GPT_Table) "sail-arm/arm-v9.4-a/src/v8_base.sail:19846.45-19846.46"
        let offset ← (( do (pure ((← (GPTLevel1Index pa)) *i 8)) ) : SailME (GPCFRecord × GPTEntry) Int )
        let gptaddrdesc : AddressDescriptor := { gptaddrdesc with paddress := { gptaddrdesc.paddress with address := (BitVec.addInt table.address offset) } }
        let level_1_entry ← (( do (undefined_bitvector 64) ) : SailME (GPCFRecord × GPTEntry) (BitVec 64) )
        let (level_1_entry, memstatus) ← (( do
          let (tup__0, tup__1) ← do (PhysMemRead gptaddrdesc 8 gptaccdesc none)
          let memstatus : PhysMemRetStatus := tup__0
          let level_1_entry : (BitVec 64) := tup__1
          (pure (level_1_entry, memstatus)) ) : SailME (GPCFRecord × GPTEntry) ((BitVec 64) × PhysMemRetStatus) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (pure ((← (GPCFault GPCF_EABT 1)), (← (__UNKNOWN_GPTEntry ())))))
        else
          (do let (gpf, result) ← (( do
                let questionMark := (Sail.BitVec.extractLsb level_1_entry 3 0)
                let (gpf, result) ← (( do
                  (if ((questionMark == GPT_Contig) : Bool)
                  then
                    (do let (tup__0, tup__1) ← do (DecodeGPTContiguous pgs level_1_entry)
                        let gpf : GPCF := tup__0
                        let result : GPTEntry := tup__1
                        (pure (gpf, result)))
                  else
                    (do let gpi_index ← (( do (GPIIndex pa) ) : SailME (GPCFRecord × GPTEntry) Int )
                        let (tup__0, tup__1) ← do (DecodeGPTGranules pgs gpi_index level_1_entry)
                        let gpf : GPCF := tup__0
                        let result : GPTEntry := tup__1
                        (pure (gpf, result)))) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
                (pure (gpf, result)) ) : SailME (GPCFRecord × GPTEntry) (GPCF × GPTEntry) )
              (if ((bne gpf GPCF_None) : Bool)
              then (do (pure ((← (GPCFault gpf 1)), (← (__UNKNOWN_GPTEntry ())))))
              else
                (do let result : GPTEntry := { result with pa := pa }
                    (if ((← readReg __tlb_enabled) : Bool)
                    then (do (pure (GPTTLBCache pgs result)))
                    else (do (pure ())))
                    (pure ((← (GPCNoFault ())), result))))))))

/-- Type quantifiers: gpt_range : Int -/
def SetTLBIncludesGPT (context : TLBContext) (gpt_range : Int) : Unit :=
  ()

def TLBIncludesGPT (context : TLBContext) : SailM Bool := do
  (__UNKNOWN_boolean ())

def GranuleProtectionCheck (addrdesc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM GPCFRecord := SailME.run do
  let gpcf ← (( do (undefined_GPCFRecord ()) ) : SailME GPCFRecord GPCFRecord )
  let gpt_entry ← (( do (undefined_GPTEntry ()) ) : SailME GPCFRecord GPTEntry )
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:19882.20-19882.21"
  (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
  then
    (do (if ((← (TLBIncludesGPT addrdesc.tlbcontext)) : Bool)
        then (do SailME.throw (← do (GPCNoFault ())))
        else (do (pure ()))))
  else (do (pure ())))
  let address : FullAddress := addrdesc.paddress
  (if (((_get_GPCCR_EL3_Type_GPC (← readReg GPCCR_EL3)) == 0#1) : Bool)
  then
    (do (if ((← readReg __tlb_enabled) : Bool)
        then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext 56)))
        else (do (pure ())))
        (GPCNoFault ()))
  else
    (do (if ((! (← (GPCRegistersConsistent ()))) : Bool)
        then (do (GPCFault GPCF_Walk 0))
        else
          (do (if ((← (AbovePPS address.address)) : Bool)
              then
                (do (if ((BEq.beq address.paspace PAS_NonSecure) : Bool)
                    then
                      (do (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
                          then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext 56)))
                          else (do (pure ())))
                          (GPCNoFault ()))
                    else (do (GPCFault GPCF_Fail 0))))
              else
                (do let gpt_base ← (( do (pure (Sail.BitVec.zeroExtend ((_get_GPTBR_EL3_Type_BADDR (← readReg GPTBR_EL3)) +++ (Zeros (n := 12))) 56)) ) : SailME GPCFRecord (BitVec 56) )
                    (if ((← (AbovePPS gpt_base)) : Bool)
                    then (do (GPCFault GPCF_AddressSize 0))
                    else
                      (do let (gpcf, gpt_entry) ← (( do
                            let (tup__0, tup__1) ← do (GPTWalk address.address accdesc)
                            let gpcf : GPCFRecord := tup__0
                            let gpt_entry : GPTEntry := tup__1
                            (pure (gpcf, gpt_entry)) ) : SailME GPCFRecord (GPCFRecord × GPTEntry) )
                          (if ((bne gpcf.gpf GPCF_None) : Bool)
                          then (do (pure gpcf))
                          else
                            (do let permitted ← (( do (GPICheck address.paspace gpt_entry.gpi) ) : SailME GPCFRecord Bool )
                                (if ((! permitted) : Bool)
                                then (do (GPCFault GPCF_Fail gpt_entry.level))
                                else
                                  (do (if (((← readReg __tlb_enabled) && (bne accdesc.acctype AccessType_TTW)) : Bool)
                                      then (do (pure (SetTLBIncludesGPT addrdesc.tlbcontext gpt_entry.contig_size)))
                                      else (do (pure ())))
                                      (GPCNoFault ())))))))))))))

/-- Type quantifiers: N : Nat, List.elem N [32, 64, 128] -/
def FetchDescriptor (ee : (BitVec 1)) (walkaddress : AddressDescriptor) (walkaccess : AccessDescriptor) (fault_in : FaultRecord) (N : Nat) (translation_info : TranslationInfo) : SailM (FaultRecord × (BitVec N)) := SailME.run do
  sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19932.41-19932.42"
  let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × (BitVec N)) (BitVec N) )
  let fault : FaultRecord := fault_in
  let fault ← (( do
    (if ((← (HaveRME ())) : Bool)
    then
      (do let fault ← (pure { fault with gpcf := (← do (GranuleProtectionCheck walkaddress walkaccess)) })
          (if ((bne fault.gpcf.gpf GPCF_None) : Bool)
          then
            (do let a__11268 ← (( do
                  let fault : FaultRecord := { fault with statuscode := Fault_GPCFOnWalk }
                  let fault : FaultRecord := { fault with paddress := walkaddress.paddress }
                  let fault : FaultRecord := { fault with gpcfs2walk := fault.secondstage }
                  (pure (fault, (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × (BitVec N)) (FaultRecord × (BitVec N)) )
                SailME.throw a__11268)
          else (do (pure fault))))
    else (do (pure fault))) ) : SailME (FaultRecord × (BitVec N)) FaultRecord )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailME (FaultRecord × (BitVec N)) PhysMemRetStatus )
  let (descriptor, memstatus) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead walkaddress (Int.ediv N 8) walkaccess (some translation_info))
    let memstatus : PhysMemRetStatus := tup__0
    let descriptor : (BitVec N) := tup__1
    (pure (descriptor, memstatus)) ) : SailME (FaultRecord × (BitVec N)) ((BitVec N) × PhysMemRetStatus) )
  let fault ← (( do
    (if ((IsFault__2 memstatus) : Bool)
    then
      (do let iswrite : Bool := false
          let fault ← (HandleExternalTTWAbort memstatus iswrite walkaddress walkaccess (Int.ediv N 8) fault)
          (if ((IsFault__1 fault.statuscode) : Bool)
          then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_bits N))))))
          else (do (pure ())))
          (pure fault))
    else (do (pure fault))) ) : SailME (FaultRecord × (BitVec N)) FaultRecord )
  let descriptor : (BitVec N) :=
    if ((ee == 1#1) : Bool)
    then (reverse_endianness descriptor)
    else descriptor
  let descriptor := descriptor
  (pure (fault, descriptor))

/-- Type quantifiers: level : Int -/
def ContiguousSize (d128 : (BitVec 1)) (tgx : TGx) (level : Int) : SailM Int := do
  (if ((d128 == 1#1) : Bool)
  then
    (do match tgx with
        | .TGx_4KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19968.57-19968.58"
            (if ((level == 1) : Bool)
            then (do (pure 2))
            else (do (pure 4))))
        | .TGx_16KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19972.57-19972.58"
            (if ((level == 1) : Bool)
            then (do (pure 2))
            else
              (do (if ((level == 2) : Bool)
                  then (do (pure 4))
                  else (do (pure 6))))))
        | .TGx_64KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19982.44-19982.45"
            (if ((level == 2) : Bool)
            then (do (pure 6))
            else (do (pure 4)))))
  else
    (do match tgx with
        | .TGx_4KB =>
          (do
            sail_assert ((level == 1) || ((level == 2) || (level == 3))) "sail-arm/arm-v9.4-a/src/v8_base.sail:19992.57-19992.58"
            (pure 4))
        | .TGx_16KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:19996.44-19996.45"
            (if ((level == 2) : Bool)
            then (do (pure 5))
            else (do (pure 7))))
        | .TGx_64KB =>
          (do
            sail_assert ((level == 2) || (level == 3)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20000.44-20000.45"
            (pure 5))))

def TGxGranuleBits (tgx : TGx) : Int :=
  match tgx with
  | .TGx_4KB => 12
  | .TGx_16KB => 14
  | .TGx_64KB => 16

/-- Type quantifiers: level : Int -/
def TranslationSize (d128 : (BitVec 1)) (tgx : TGx) (level : Int) : Int :=
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let blockbits := ((FINAL_LEVEL -i level) *i (granulebits -i descsizelog2))
  (granulebits +i blockbits)

def StageOA (ia : (BitVec 64)) (d128 : (BitVec 1)) (tgx : TGx) (walkstate : TTWState) : SailM FullAddress := do
  let oa ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let csize ← (( do (undefined_int ()) ) : SailM Int )
  let tsize := (TranslationSize d128 tgx walkstate.level)
  let csize ← (( do
    (if ((walkstate.contiguous == 1#1) : Bool)
    then (do (ContiguousSize d128 tgx walkstate.level))
    else (do (pure 0))) ) : SailM Int )
  let csize := csize
  let ia_msb := (tsize +i csize)
  let oa : FullAddress := { oa with paspace := walkstate.baseaddress.paspace }
  sail_assert ((0 ≤b ia_msb) && (ia_msb ≤b 55)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20052.53-20052.54"
  sail_assert (0 ≤b (ia_msb -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:20053.39-20053.40"
  (pure { oa with address := ((Sail.BitVec.extractLsb walkstate.baseaddress.address 55 ia_msb) +++ (Sail.BitVec.extractLsb ia (ia_msb -i 1) 0)) })

def DecodePASpace (nse : (BitVec 1)) (ns : (BitVec 1)) : SailM PASpace := do
  match (nse +++ ns) with
  | 0b00 => (pure PAS_Secure)
  | 0b01 => (pure PAS_NonSecure)
  | 0b10 => (pure PAS_Root)
  | 0b11 => (pure PAS_Realm)
  | _ => (do (undefined_PASpace ()))

def HasUnprivileged (regime : Regime) : Bool :=
  ((BEq.beq regime Regime_EL20) || ((BEq.beq regime Regime_EL30) || (BEq.beq regime Regime_EL10)))

def CreateAddressDescriptor (va : (BitVec 64)) (pa : FullAddress) (memattrs : MemoryAttributes) : SailM AddressDescriptor := do
  let addrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let addrdesc : AddressDescriptor := { addrdesc with paddress := pa }
  let addrdesc : AddressDescriptor := { addrdesc with vaddress := va }
  let addrdesc : AddressDescriptor := { addrdesc with memattrs := memattrs }
  let addrdesc ← (pure { addrdesc with fault := (← do (NoFault ())) })
  (pure { addrdesc with s1assured := false })

def CreateFaultyAddressDescriptor (va : (BitVec 64)) (fault : FaultRecord) : SailM AddressDescriptor := do
  let addrdesc ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let addrdesc : AddressDescriptor := { addrdesc with vaddress := va }
  (pure { addrdesc with fault := fault })

def AlignmentFault (accdesc : AccessDescriptor) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_Alignment }
  let fault : FaultRecord := { fault with access := accdesc }
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with write := ((! accdesc.read) && accdesc.write) }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

def AArch64_MaxTxSZ (tgx : TGx) : SailM Int := do
  (if ((← (HaveSmallTranslationTableExt ())) : Bool)
  then
    (do match tgx with
        | .TGx_4KB => (pure 48)
        | .TGx_16KB => (pure 48)
        | .TGx_64KB => (pure 47))
  else (do (pure 39)))

def AArch64_S1MinTxSZ (regime : Regime) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) : SailM Int := do
  (if (((← (Have56BitVAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do (if ((HasUnprivileged regime) : Bool)
        then (do (pure 9))
        else (do (pure 8))))
  else
    (do (if ((((← (Have52BitVAExt ())) && (BEq.beq tgx TGx_64KB)) || (ds == 1#1)) : Bool)
        then (do (pure 12))
        else (do (pure 16)))))

def AArch64_S1TxSZFaults (regime : Regime) (walkparams : S1TTWParams) : SailM Bool := do
  let mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailM Int )
  let maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailM Int )
  (if (((BitVec.toNat walkparams.txsz) <b mintxsz) : Bool)
  then (do (Have52BitVAExt ()) <||> (do (__IMPDEF_boolean "Fault on TxSZ value below minimum")))
  else
    (do (if (((BitVec.toNat walkparams.txsz) >b maxtxsz) : Bool)
        then (do (__IMPDEF_boolean "Fault on TxSZ value above maximum"))
        else (do (pure false)))))

def AArch64_PACEffectiveTxSZ (regime : Regime) (walkparams : S1TTWParams) : SailM (BitVec 6) := SailME.run do
  let s1maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (BitVec 6) Int )
  let s1mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailME (BitVec 6) Int )
  (if ((← (AArch64_S1TxSZFaults regime walkparams)) : Bool)
  then
    (do (if ((BEq.beq (← (ConstrainUnpredictable Unpredictable_RESTnSZ)) Constraint_FORCE) : Bool)
        then
          (do (if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
              then (do SailME.throw ((integer_subrange s1mintxsz 5 0) : (BitVec 6)))
              else
                (do (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
                    then (do SailME.throw ((integer_subrange s1maxtxsz 5 0) : (BitVec 6)))
                    else (do (pure ()))))))
        else (do (pure ()))))
  else
    (do (if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
        then (do SailME.throw ((integer_subrange s1mintxsz 5 0) : (BitVec 6)))
        else
          (do (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
              then (do SailME.throw ((integer_subrange s1maxtxsz 5 0) : (BitVec 6)))
              else (do (pure ())))))))
  (pure walkparams.txsz)

def AArch64_GetVARange (va : (BitVec 64)) : VARange :=
  if ((((BitVec.access va 55) : BitVec 1) == 0#1) : Bool)
  then VARange_LOWER
  else VARange_UPPER

def AArch64_HaveS1TG (tgx : TGx) : SailM Bool := do
  match tgx with
  | .TGx_4KB => (__IMPDEF_boolean "Has 4K Translation Granule")
  | .TGx_16KB => (__IMPDEF_boolean "Has 16K Translation Granule")
  | .TGx_64KB => (__IMPDEF_boolean "Has 64K Translation Granule")

def AArch64_S1DecodeTG0 (tg0_in : (BitVec 2)) : SailM TGx := do
  let tg0 : (BitVec 2) := tg0_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg0 ← (( do
    (if ((tg0 == 0b11#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG0 encoded granule size"))
    else (do (pure tg0))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg0 with
    | 0b00 => TGx_4KB
    | 0b01 => TGx_64KB
    | 0b10 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS1TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG0 encoded granule size")) with
        | 0b00 => (pure TGx_4KB)
        | 0b01 => (pure TGx_64KB)
        | 0b10 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def AArch64_S1DecodeTG1 (tg1_in : (BitVec 2)) : SailM TGx := do
  let tg1 : (BitVec 2) := tg1_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg1 ← (( do
    (if ((tg1 == 0b00#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG1 encoded granule size"))
    else (do (pure tg1))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg1 with
    | 0b10 => TGx_4KB
    | 0b11 => TGx_64KB
    | 0b01 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS1TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG1 encoded granule size")) with
        | 0b10 => (pure TGx_4KB)
        | 0b11 => (pure TGx_64KB)
        | 0b01 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def IsTCR2EL1Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatTCR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_TCR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_TCR2En (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (pure true)))))))

def undefined_MAIR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR2_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MAIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIRE0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TCR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR2_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR2_EL1_Type_DisCH1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_TCR2_EL2_Type_DisCH1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def AArch64_S1TTWParamsEL10 (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL1_Type_D128 (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL1_Type_TG0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T0SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH0 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI0 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX0 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL1_Type_SKL (← (TTBR0_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH0 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL1_Type_TG1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL1_Type_T1SZ (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL1_Type_IRGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL1_Type_ORGN1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL1_Type_SH1 (← readReg TCR_EL1)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL1_Type_TBI1 (← readReg TCR_EL1)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL1_Type_NFD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_TBID1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_E0PD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_HPD1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL1_Type_MTX1 (← readReg TCR_EL1))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL1_Type_SKL (← (TTBR1_EL1_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_DisCH1 (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL1)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL1Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL1_Type_AIE (← readReg TCR2_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL1_Type_WXN (← readReg SCTLR_EL1)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL1_Type_IPS (← readReg TCR_EL1)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL1_Type_EE (← readReg SCTLR_EL1)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with dc := (← do (pure (_get_HCR_EL2_Type_DC (← readReg HCR_EL2)))) })
          (pure { walkparams with dct := (← do
              (if ((← (HaveMTE2Ext ())) : Bool)
              then (do (pure (_get_HCR_EL2_Type_DCT (← readReg HCR_EL2))))
              else (do (pure 0#1)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL1_Type_nTLSMD (← readReg SCTLR_EL1)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (EL2Enabled ())) : Bool)
    then
      (do (if ((((_get_HCR_EL2_Type_NV (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2))) == 0b01#2) : Bool)
          then
            (do match (← (ConstrainUnpredictable Unpredictable_NVNV1)) with
                | .Constraint_NVNV1_00 => (pure { walkparams with nv1 := 0#1 })
                | .Constraint_NVNV1_01 => (pure { walkparams with nv1 := 1#1 })
                | .Constraint_NVNV1_11 => (pure { walkparams with nv1 := 1#1 })
                | _ => (pure walkparams))
          else (do (pure { walkparams with nv1 := (← do (pure (_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)))) }))))
    else (do (pure { walkparams with nv1 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL1_Type_CMOW (← readReg SCTLR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HA (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL1_Type_HD (← readReg TCR_EL1))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL1_Type_DS (← readReg TCR_EL1)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL1Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL1_Type_PIE (← readReg TCR2_EL1))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL1)))) })
          (if ((walkparams.nv1 != 1#1) : Bool)
          then (do (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL1)))) }))
          else (do (pure walkparams))))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EPAN (← readReg SCTLR_EL1))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL1_Type_PnCH (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL1Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL1_Type_HAFT (← readReg TCR2_EL1)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((←((HaveFeatMEC ()) <&&> (do
           (IsSCTLR2EL2Enabled ())))) : Bool)
      then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
      else (do (pure 0#1)))) })

def IsTCR2EL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatTCR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_TCR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def undefined_MAIR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MAIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TCR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR2_EL2_Type_AMEC0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_TCR2_EL2_Type_AMEC1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def AArch64_S1TTWParamsEL2 (ss : SecurityState) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_PS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_TBID (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_HPD (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with pie := (← do
        (if ((←((HaveS1PIExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL2_Type_MTX (← readReg TCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with pnch := (← do
        (if ((←((HaveTHExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then (do (pure { walkparams with amec := (← do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2)))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_PIRE0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIRE0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1TTWParamsEL20 (ss : SecurityState) (varange : VARange) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((Have128BitDescriptorExt ()) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with d128 := (← do (pure (_get_TCR2_EL2_Type_D128 (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with d128 := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((BEq.beq varange VARange_LOWER) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL2_Type_TG0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T0SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH0 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI0 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX0 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR0_EL2_Type_SKL (← (TTBR0_EL2_read ())))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH0 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))
    else
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG1 (_get_TCR_EL2_Type_TG1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL2_Type_T1SZ (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL2_Type_IRGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL2_Type_ORGN1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL2_Type_SH1 (← readReg TCR_EL2)))) })
          let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL2_Type_TBI1 (← readReg TCR_EL2)))) })
          let walkparams ←
            (pure { walkparams with nfd := (← do
                (if ((←((HaveSVE ()) <||> (do
                     (HaveTME ())))) : Bool)
                then (do (pure (_get_TCR_EL2_Type_NFD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with tbid := (← do
                (if ((← (HavePACExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_TBID1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with e0pd := (← do
                (if ((← (HaveE0PDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_E0PD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with hpd := (← do
                (if ((← (AArch64_HaveHPDExt ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_HPD1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with mtx := (← do
                (if ((← (HaveMTE4Ext ())) : Bool)
                then (do (pure (_get_TCR_EL2_Type_MTX1 (← readReg TCR_EL2))))
                else (do (pure 0#1)))) })
          let walkparams ←
            (pure { walkparams with skl := (← do
                (if ((walkparams.d128 == 1#1) : Bool)
                then (do (pure (_get_TTBR1_EL2_Type_SKL (← readReg TTBR1_EL2))))
                else (do (pure 0b00#2)))) })
          (pure { walkparams with disch := (← do
              (if ((walkparams.d128 == 1#1) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_DisCH1 (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL2)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((←((HaveAIEExt ()) <&&> (do
             (IsTCR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_TCR2_EL2_Type_AIE (← readReg TCR2_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL2_Type_WXN (← readReg SCTLR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL2_Type_IPS (← readReg TCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (pure (! (← (HaveRME ())))) <||> (do
           (HaveSecureEL2Ext ()))))) : Bool)
    then (do (pure { walkparams with sif := (← do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3)))) }))
    else (do (pure { walkparams with sif := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveTrapLoadStoreMultipleDeviceExt ())) : Bool)
    then (do (pure { walkparams with ntlsmd := (← do (pure (_get_SCTLR_EL2_Type_nTLSMD (← readReg SCTLR_EL2)))) }))
    else (do (pure { walkparams with ntlsmd := 1#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((← (HaveFeatCMOW ())) : Bool)
        then (do (pure (_get_SCTLR_EL2_Type_CMOW (← readReg SCTLR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 21))
                    else (do (pure 39)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then
          (do (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 22))
                    else (do (pure 40)))) 1)))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then
      (do (pure { walkparams with ds := (← do
              (pure (BitVec.slice (← readReg TCR_EL2)
                  (← do
                    (if (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1) : Bool)
                    then (do (pure 32))
                    else (do (pure 59)))) 1))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((←((HaveS1PIExt ()) <&&> (do
                   (IsTCR2EL2Enabled ())))) : Bool)
              then (do (pure (_get_TCR2_EL2_Type_PIE (← readReg TCR2_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then
      (do let walkparams ← (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL2)))) })
          (pure { walkparams with pire0 := (← do (pure (Mk_S1PIRType (← readReg PIRE0_EL2)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HavePAN3Ext ())) : Bool)
    then
      (do (pure { walkparams with epan := (← do
              (if ((walkparams.pie == 0#1) : Bool)
              then (do (pure (_get_SCTLR_EL2_Type_EPAN (← readReg SCTLR_EL2))))
              else (do (pure 1#1)))) }))
    else (do (pure { walkparams with epan := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveTHExt ())) && (walkparams.d128 == 0#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR2_EL2_Type_PnCH (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((←((pure ((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1))) <&&> (do
         (IsTCR2EL2Enabled ())))) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR2_EL2_Type_HAFT (← readReg TCR2_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with emec := (← do
        (if ((←((HaveFeatMEC ()) <&&> (do
             (IsSCTLR2EL2Enabled ())))) : Bool)
        then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
        else (do (pure 0#1)))) })
  (if ((←((pure ((← (HaveFeatMEC ())) && (BEq.beq ss SS_Realm))) <&&> (do
       (IsTCR2EL2Enabled ())))) : Bool)
  then
    (do (pure { walkparams with amec := (← do
            (if ((BEq.beq varange VARange_LOWER) : Bool)
            then (do (pure (_get_TCR2_EL2_Type_AMEC0 (← readReg TCR2_EL2))))
            else (do (pure (_get_TCR2_EL2_Type_AMEC1 (← readReg TCR2_EL2)))))) }))
  else (do (pure { walkparams with amec := 0#1 })))

def undefined_MAIR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR2_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MAIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MAIR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PIR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PIR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR2_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR2_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TTBR0_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR0_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S1TTWParamsEL3 (_ : Unit) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S1DecodeTG0 (_get_TCR_EL3_Type_TG0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_TCR_EL3_Type_T0SZ (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_TCR_EL3_Type_PS (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_TCR_EL3_Type_IRGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_TCR_EL3_Type_ORGN0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_TCR_EL3_Type_SH0 (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with tbi := (← do (pure (_get_TCR_EL3_Type_TBI (← readReg TCR_EL3)))) })
  let walkparams ← (pure { walkparams with mair := (← do (pure (Mk_MAIRType (← readReg MAIR_EL3)))) })
  let walkparams ← (( do
    (if ((← (HaveAIEExt ())) : Bool)
    then (do (pure { walkparams with mair2 := (← do (pure (Mk_MAIRType (← readReg MAIR2_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with aie := (← do
        (if ((← (HaveAIEExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_AIE (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (pure { walkparams with wxn := (← do (pure (_get_SCTLR_EL3_Type_WXN (← readReg SCTLR_EL3)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL3_Type_EE (← readReg SCTLR_EL3)))) })
  let walkparams ←
    (pure { walkparams with sif := (← do
        (if ((←((pure (! (← (HaveRME ())))) <||> (do
             (HaveSecureEL2Ext ())))) : Bool)
        then (do (pure (_get_SCR_EL3_Type_SIF (← readReg SCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tbid := (← do
        (if ((← (HavePACExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_TBID (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hpd := (← do
        (if ((← (AArch64_HaveHPDExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HPD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HA (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_HD (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_TCR_EL3_Type_DS (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_D128 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with skl := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TTBR0_EL3_Type_SKL (← readReg TTBR0_EL3))))
        else (do (pure 0b00#2)))) })
  let walkparams ←
    (pure { walkparams with disch := (← do
        (if ((walkparams.d128 == 1#1) : Bool)
        then (do (pure (_get_TCR_EL3_Type_DisCH0 (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with pie := 1#1 }))
    else
      (do (pure { walkparams with pie := (← do
              (if ((← (HaveS1PIExt ())) : Bool)
              then (do (pure (_get_TCR_EL3_Type_PIE (← readReg TCR_EL3))))
              else (do (pure 0#1)))) }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if ((← (HaveS1PIExt ())) : Bool)
    then (do (pure { walkparams with pir := (← do (pure (Mk_S1PIRType (← readReg PIR_EL3)))) }))
    else (do (pure walkparams))) ) : SailM S1TTWParams )
  let walkparams ←
    (pure { walkparams with mtx := (← do
        (if ((← (HaveMTE4Ext ())) : Bool)
        then (do (pure (_get_TCR_EL3_Type_MTX (← readReg TCR_EL3))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 == 0#1)) : Bool)
    then (do (pure { walkparams with pnch := (← do (pure (_get_TCR_EL3_Type_PnCH (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with pnch := 0#1 }))) ) : SailM S1TTWParams )
  let walkparams ← (( do
    (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_TCR_EL3_Type_HAFT (← readReg TCR_EL3)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S1TTWParams )
  (pure { walkparams with emec := (← do
      (if ((← (HaveFeatMEC ())) : Bool)
      then (do (pure (_get_SCTLR2_EL3_Type_EMEC (← readReg SCTLR2_EL3))))
      else (do (pure 0#1)))) })

def AArch64_GetS1TTWParams (regime : Regime) (ss : SecurityState) (va : (BitVec 64)) : SailM S1TTWParams := do
  let walkparams ← (( do (undefined_S1TTWParams ()) ) : SailM S1TTWParams )
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL3 => (do (AArch64_S1TTWParamsEL3 ()))
  | .Regime_EL2 => (do (AArch64_S1TTWParamsEL2 ss))
  | .Regime_EL20 => (do (AArch64_S1TTWParamsEL20 ss varange))
  | .Regime_EL10 => (do (AArch64_S1TTWParamsEL10 varange))
  | _ => (pure walkparams)

def CalculateBottomPACBit (top_bit : (BitVec 1)) : SailM Int := do
  let regime ← (( do (TranslationRegime (← readReg PSTATE).EL) ) : SailM Regime )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let walkparams ← (( do (AArch64_GetS1TTWParams regime ss (BitVec.replicateBits top_bit 64)) ) : SailM S1TTWParams )
  let bottom_PAC_bit ← (( do (pure (64 -i (BitVec.toNat (← (AArch64_PACEffectiveTxSZ regime walkparams))))) ) : SailM Int )
  (pure bottom_PAC_bit)

def HaveEnhancedPAC2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAuth2)

def HaveFPAC (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPAC)

def HaveFPACCombined (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_FPACCOMBINE)

def HavePACQARMA3Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA3Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA3)

def HavePACQARMA5Generic (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACQARMA5Auth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACQARMA5)

def HavePACIMPGeneric (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def HavePACIMPAuth (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PACIMP)

def PACCellInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACCellShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 47 44))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 31 28))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 7 4))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 43 40))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 15 12))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 47 44 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 19 16))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (Sail.BitVec.extractLsb indata 63 60)))

def PACInvSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | _ => Toutput
  (pure loop_vars)

/-- Type quantifiers: amount : Nat, 0 ≤ (4 - amount) ∧ (7 - amount) < 8 -/
def RotCell (incell_name : (BitVec 4)) (amount : Nat) : SailM (BitVec 4) := do
  let tmp ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let tmp : (BitVec 8) := (Sail.BitVec.updateSubrange tmp 7 0 ((Sail.BitVec.extractLsb incell_name 3 0) +++ (Sail.BitVec.extractLsb incell_name 3 0)))
  (pure (Sail.BitVec.extractLsb tmp (7 -i amount) (4 -i amount)))

def PACMult (Sinput : (BitVec 64)) : SailM (BitVec 64) := do
  let t0 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t1 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t2 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let t3 ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let Soutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let (Soutput, t0, t1, t2, t3) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := 3
    let mut loop_vars := (Soutput, t0, t1, t2, t3)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (Soutput, t0, t1, t2, t3) := loop_vars
      loop_vars ← do
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 2)))))
        let t0 ← (pure (Sail.BitVec.updateSubrange t0 3 0 ((Sail.BitVec.extractLsb t0 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let t1 ← (pure (Sail.BitVec.updateSubrange t1 3 0 ((Sail.BitVec.extractLsb t1 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 2)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 2)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 1)))))
        let t2 ← (pure (Sail.BitVec.updateSubrange t2 3 0 ((Sail.BitVec.extractLsb t2 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i i) +i 3) (4 *i i)) 1)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12))) 1)) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8))) 2)))))
        let t3 ← (pure (Sail.BitVec.updateSubrange t3 3 0 ((Sail.BitVec.extractLsb t3 3 0) ^^^ (← (RotCell (Sail.BitVec.extractLsb Sinput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4))) 1)))))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i i) +i 3) (4 *i i) (Sail.BitVec.extractLsb t3 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 4)) +i 3) (4 *i (i +i 4)) (Sail.BitVec.extractLsb t2 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 8)) +i 3) (4 *i (i +i 8)) (Sail.BitVec.extractLsb t1 3 0))
        let Soutput : (BitVec 64) := (Sail.BitVec.updateSubrange Soutput ((4 *i (i +i 12)) +i 3) (4 *i (i +i 12)) (Sail.BitVec.extractLsb t0 3 0))
        (pure (Soutput, t0, t1, t2, t3))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 4) × (BitVec 4) × (BitVec 4) × (BitVec 4)) )
  (pure Soutput)

def PACSub (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | _ => Toutput
  (pure loop_vars)

def PACSub1 (Tinput : (BitVec 64)) : SailM (BitVec 64) := do
  let Toutput ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := Toutput
  for i in [loop_i_lower:loop_i_upper:1]i do
    let Toutput := loop_vars
    loop_vars :=
      let nibble : (BitVec 4) := (BitVec.slice Tinput (4 *i i) 4)
      match nibble with
      | 0b0000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1010#4)
      | 0b0001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1101#4)
      | 0b0010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1110#4)
      | 0b0011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0110#4)
      | 0b0100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1111#4)
      | 0b0101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0111#4)
      | 0b0110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0011#4)
      | 0b0111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0101#4)
      | 0b1000 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1001#4)
      | 0b1001 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1000#4)
      | 0b1010 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0000#4)
      | 0b1011 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1100#4)
      | 0b1100 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b1011#4)
      | 0b1101 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0001#4)
      | 0b1110 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0010#4)
      | 0b1111 => (Sail.BitVec.updateSubrange Toutput ((4 *i i) +i 3) (4 *i i) 0b0100#4)
      | _ => Toutput
  (pure loop_vars)

def TweakCellInvRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 1) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 0) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 3) : BitVec 1)))))

def TweakInvShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 3 0 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 51 48)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 11 8 (Sail.BitVec.extractLsb indata 23 20))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 27 24))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 19 16 (Sail.BitVec.extractLsb indata 3 0))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 27 24 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 11 8)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 31 28 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 35 32 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 31 28)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 39 36 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 43 40 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 59 56)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 19 16)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 51 48 (Sail.BitVec.extractLsb indata 35 32))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 39 36))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 59 56 (Sail.BitVec.extractLsb indata 43 40))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellInvRot (Sail.BitVec.extractLsb indata 47 44)))))

def TweakCellRot (incell_name : (BitVec 4)) : SailM (BitVec 4) := do
  let outcell ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let outcell : (BitVec 4) := (BitVec.update outcell 3 (Bit (((BitVec.access incell_name 0) : BitVec 1) ^^^ ((BitVec.access incell_name 1) : BitVec 1))))
  let outcell : (BitVec 4) := (BitVec.update outcell 2 (Bit ((BitVec.access incell_name 3) : BitVec 1)))
  let outcell : (BitVec 4) := (BitVec.update outcell 1 (Bit ((BitVec.access incell_name 2) : BitVec 1)))
  (pure (BitVec.update outcell 0 (Bit ((BitVec.access incell_name 1) : BitVec 1))))

def TweakShuffle (indata : (BitVec 64)) : SailM (BitVec 64) := do
  let outdata ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 3 0 (Sail.BitVec.extractLsb indata 19 16))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 7 4 (Sail.BitVec.extractLsb indata 23 20))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 11 8 (← (TweakCellRot (Sail.BitVec.extractLsb indata 27 24)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 15 12 (Sail.BitVec.extractLsb indata 31 28))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 19 16 (← (TweakCellRot (Sail.BitVec.extractLsb indata 47 44)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 23 20 (Sail.BitVec.extractLsb indata 11 8))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 27 24 (Sail.BitVec.extractLsb indata 15 12))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 31 28 (← (TweakCellRot (Sail.BitVec.extractLsb indata 35 32)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 35 32 (Sail.BitVec.extractLsb indata 51 48))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 39 36 (Sail.BitVec.extractLsb indata 55 52))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 43 40 (Sail.BitVec.extractLsb indata 59 56))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 47 44 (← (TweakCellRot (Sail.BitVec.extractLsb indata 63 60)))))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 51 48 (← (TweakCellRot (Sail.BitVec.extractLsb indata 3 0)))))
  let outdata : (BitVec 64) := (Sail.BitVec.updateSubrange outdata 55 52 (Sail.BitVec.extractLsb indata 7 4))
  let outdata ← (pure (Sail.BitVec.updateSubrange outdata 59 56 (← (TweakCellRot (Sail.BitVec.extractLsb indata 43 40)))))
  (pure (Sail.BitVec.updateSubrange outdata 63 60 (← (TweakCellRot (Sail.BitVec.extractLsb indata 39 36)))))

/-- Type quantifiers: k_isqarma3 : Bool -/
def ComputePACQARMA (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isqarma3 : Bool) : SailM (BitVec 64) := do
  let roundkey ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let Alpha : (BitVec 64) := 0xC0AC29B7C97C50DD#64
  let iterations : Int := 2
  writeReg RC (vectorUpdate (← readReg RC) 0 0x0000000000000000#64)
  writeReg RC (vectorUpdate (← readReg RC) 1 0x13198A2E03707344#64)
  writeReg RC (vectorUpdate (← readReg RC) 2 0xA4093822299F31D0#64)
  let iterations ← (( do
    (if (isqarma3 : Bool)
    then (do (pure 2))
    else
      (do let iterations : Int := 4
          writeReg RC (vectorUpdate (← readReg RC) 3 0x082EFA98EC4E6C89#64)
          writeReg RC (vectorUpdate (← readReg RC) 4 0x452821E638D01377#64)
          (pure iterations))) ) : SailM Int )
  let iterations := iterations
  let modk0 : (BitVec 64) := ((((BitVec.access key0 0) : BitVec 1) +++ (Sail.BitVec.extractLsb key0 63 2)) +++ (((BitVec.access key0 63) : BitVec 1) ^^^ ((BitVec.access key0 1) : BitVec 1)))
  let runningmod : (BitVec 64) := modifier
  let workingval : (BitVec 64) := (data ^^^ key0)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars
      loop_vars ← do
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) i)))
        let workingval ← (( do
          (if ((i >b 0) : Bool)
          then
            (do let workingval ← (PACCellShuffle workingval)
                (PACMult workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACSub workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  let roundkey : (BitVec 64) := (modk0 ^^^ runningmod)
  let workingval : (BitVec 64) := (workingval ^^^ roundkey)
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (key1 ^^^ workingval)
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval ← (( do
    (if (isqarma3 : Bool)
    then (do (PACSub1 workingval))
    else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
  let workingval ← (( (PACMult workingval) ) : SailM (BitVec 64) )
  let workingval ← (( (PACCellInvShuffle workingval) ) : SailM (BitVec 64) )
  let workingval : (BitVec 64) := (workingval ^^^ key0)
  let workingval : (BitVec 64) := (workingval ^^^ runningmod)
  let (roundkey, runningmod, workingval) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := iterations
    let mut loop_vars_1 := (roundkey, runningmod, workingval)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (roundkey, runningmod, workingval) := loop_vars_1
      loop_vars_1 ← do
        let workingval ← (( do
          (if (isqarma3 : Bool)
          then (do (PACSub1 workingval))
          else (do (PACInvSub workingval))) ) : SailM (BitVec 64) )
        let workingval ← (( do
          (if ((i <b iterations) : Bool)
          then
            (do let workingval ← (PACMult workingval)
                (PACCellInvShuffle workingval))
          else (do (pure workingval))) ) : SailM (BitVec 64) )
        let runningmod ← (TweakInvShuffle (Sail.BitVec.extractLsb runningmod 63 0))
        let roundkey : (BitVec 64) := (key1 ^^^ runningmod)
        let workingval ← (pure (workingval ^^^ (GetElem?.getElem! (← readReg RC) (iterations -i i))))
        let workingval : (BitVec 64) := (workingval ^^^ roundkey)
        let workingval : (BitVec 64) := (workingval ^^^ Alpha)
        (pure (roundkey, runningmod, workingval))
    (pure loop_vars_1) ) : SailM ((BitVec 64) × (BitVec 64) × (BitVec 64)) )
  (pure (workingval ^^^ modk0))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACIMP (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACIMPGeneric ()))
  else (do (HavePACIMPAuth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA3 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA3Generic ()))
  else (do (HavePACQARMA3Auth ())))

/-- Type quantifiers: k_isgeneric : Bool -/
def UsePACQARMA5 (isgeneric : Bool) : SailM Bool := do
  (if (isgeneric : Bool)
  then (do (HavePACQARMA5Generic ()))
  else (do (HavePACQARMA5Auth ())))

def ComputePACIMPDEF (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) : SailM (BitVec 64) := do
  (__UNKNOWN_bits 64)

/-- Type quantifiers: k_isgeneric : Bool -/
def ComputePAC (data : (BitVec 64)) (modifier : (BitVec 64)) (key0 : (BitVec 64)) (key1 : (BitVec 64)) (isgeneric : Bool) : SailM (BitVec 64) := do
  (if ((← (UsePACIMP isgeneric)) : Bool)
  then (do (ComputePACIMPDEF data modifier key0 key1))
  else
    (do (if ((← (UsePACQARMA3 isgeneric)) : Bool)
        then
          (do let isqarma3 : Bool := true
              (ComputePACQARMA data modifier key0 key1 isqarma3))
        else
          (do (if ((← (UsePACQARMA5 isgeneric)) : Bool)
              then
                (do let isqarma3 : Bool := false
                    (ComputePACQARMA data modifier key0 key1 isqarma3))
              else (do (undefined_bitvector 64)))))))

def AArch64_PACFailException (syndrome : (BitVec 2)) : SailM Unit := do
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_PACFail) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 syndrome) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 2 (Zeros (n := 23))) }
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL0)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

/-- Type quantifiers: k_data : Bool, k_is_combined : Bool -/
def Auth (ptr : (BitVec 64)) (modifier : (BitVec 64)) (K : (BitVec 128)) (data : Bool) (key_number : (BitVec 1)) (is_combined : Bool) : SailM (BitVec 64) := do
  let result ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let original_ptr ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let error_code ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let isgeneric : Bool := false
  let tbi ← (( do (pure ((← (EffectiveTBI ptr (! data) (← readReg PSTATE).EL)) == 1#1)) ) : SailM Bool )
  let mtx ← (( do (pure ((← (EffectiveMTX ptr (! data) (← readReg PSTATE).EL)) == 1#1)) ) : SailM Bool )
  let bottom_PAC_bit ← (( do (CalculateBottomPACBit ((BitVec.access ptr 55) : BitVec 1)) ) : SailM Int )
  let extfield : (BitVec 64) := (BitVec.replicateBits ((BitVec.access ptr 55) : BitVec 1) 64)
  (if ((tbi && (bottom_PAC_bit ≥b 55)) : Bool)
  then (do (pure ptr))
  else
    (do let original_ptr ← (( do
          (if (tbi : Bool)
          then
            (do sail_assert ((0 ≤b ((56 -i bottom_PAC_bit) -i 1)) && (((56 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21616.90-21616.91"
                sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21617.80-21617.81"
                (pure (((Sail.BitVec.extractLsb ptr 63 56) +++ (Sail.BitVec.extractLsb extfield ((56 -i bottom_PAC_bit) -i 1) 0)) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))
          else
            (do (if (mtx : Bool)
                then
                  (do sail_assert ((0 ≤b ((56 -i bottom_PAC_bit) -i 1)) && (((56 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21620.90-21620.91"
                      sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21621.80-21621.81"
                      (pure ((((Sail.BitVec.extractLsb extfield 63 60) +++ (Sail.BitVec.extractLsb ptr 59 56)) +++ (Sail.BitVec.extractLsb extfield ((56 -i bottom_PAC_bit) -i 1) 0)) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))
                else
                  (do sail_assert ((0 ≤b ((64 -i bottom_PAC_bit) -i 1)) && (((64 -i bottom_PAC_bit) -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21624.90-21624.91"
                      sail_assert ((0 ≤b (bottom_PAC_bit -i 1)) && ((bottom_PAC_bit -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21625.80-21625.81"
                      (pure ((Sail.BitVec.extractLsb extfield ((64 -i bottom_PAC_bit) -i 1) 0) +++ (Sail.BitVec.extractLsb ptr (bottom_PAC_bit -i 1) 0))))))) ) : SailM (BitVec 64) )
        let PAC ← (( do (ComputePAC original_ptr modifier (Sail.BitVec.extractLsb K 127 64) (Sail.BitVec.extractLsb K 63 0) isgeneric) ) : SailM (BitVec 64) )
        (if (tbi : Bool)
        then
          (do (if ((! (← (HaveEnhancedPAC2 ()))) : Bool)
              then
                (do sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21631.77-21631.78"
                    (if (((Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit) == (Sail.BitVec.extractLsb ptr 54 bottom_PAC_bit)) : Bool)
                    then (do (pure original_ptr))
                    else
                      (do let error_code : (BitVec 2) := (key_number +++ (Complement.complement key_number))
                          (pure (((Sail.BitVec.extractLsb original_ptr 63 55) +++ error_code) +++ (Sail.BitVec.extractLsb original_ptr 52 0))))))
              else
                (do let result : (BitVec 64) := ptr
                    sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21640.77-21640.78"
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                    (if ((←((HaveFPACCombined ()) <||> (do
                         (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                    then
                      (do (if (((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (55 -i bottom_PAC_bit))) : Bool)
                          then
                            (do let error_code : (BitVec 2) :=
                                  ((if (data : Bool)
                                    then 1#1
                                    else 0#1) +++ key_number)
                                (AArch64_PACFailException error_code))
                          else (do (pure ()))))
                    else (do (pure ())))
                    (pure result))))
        else
          (do (if (mtx : Bool)
              then
                (do sail_assert (← (HaveEnhancedPAC2 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:21652.33-21652.34"
                    let result : (BitVec 64) := ptr
                    sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21654.73-21654.74"
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                    let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 63 60 ((Sail.BitVec.extractLsb result 63 60) ^^^ (Sail.BitVec.extractLsb PAC 63 60)))
                    (if ((←((HaveFPACCombined ()) <||> (do
                         (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                    then
                      (do (if ((((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (55 -i bottom_PAC_bit))) || ((Sail.BitVec.extractLsb result 63 60) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) 4))) : Bool)
                          then
                            (do let error_code : (BitVec 2) :=
                                  ((if (data : Bool)
                                    then 1#1
                                    else 0#1) +++ key_number)
                                (AArch64_PACFailException error_code))
                          else (do (pure ()))))
                    else (do (pure ())))
                    (pure result))
              else
                (do (if ((! (← (HaveEnhancedPAC2 ()))) : Bool)
                    then
                      (do sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21667.77-21667.78"
                          (if ((((Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit) == (Sail.BitVec.extractLsb ptr 54 bottom_PAC_bit)) && ((Sail.BitVec.extractLsb PAC 63 56) == (Sail.BitVec.extractLsb ptr 63 56))) : Bool)
                          then (do (pure original_ptr))
                          else
                            (do let error_code : (BitVec 2) := (key_number +++ (Complement.complement key_number))
                                (pure ((((BitVec.access original_ptr 63) : BitVec 1) +++ error_code) +++ (Sail.BitVec.extractLsb original_ptr 60 0))))))
                    else
                      (do let result : (BitVec 64) := ptr
                          sail_assert ((0 ≤b bottom_PAC_bit) && (bottom_PAC_bit ≤b 54)) "sail-arm/arm-v9.4-a/src/v8_base.sail:21676.77-21676.78"
                          let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 54 bottom_PAC_bit ((Sail.BitVec.extractLsb result 54 bottom_PAC_bit) ^^^ (Sail.BitVec.extractLsb PAC 54 bottom_PAC_bit)))
                          let result : (BitVec 64) := (Sail.BitVec.updateSubrange result 63 56 ((Sail.BitVec.extractLsb result 63 56) ^^^ (Sail.BitVec.extractLsb PAC 63 56)))
                          (if ((←((HaveFPACCombined ()) <||> (do
                               (pure ((← (HaveFPAC ())) && (! is_combined)))))) : Bool)
                          then
                            (do (if (((Sail.BitVec.extractLsb result 63 bottom_PAC_bit) != (BitVec.replicateBits ((BitVec.access result 55) : BitVec 1) (64 -i bottom_PAC_bit))) : Bool)
                                then
                                  (do let error_code : (BitVec 2) :=
                                        ((if (data : Bool)
                                          then 1#1
                                          else 0#1) +++ key_number)
                                      (AArch64_PACFailException error_code))
                                else (do (pure ()))))
                          else (do (pure ())))
                          (pure result)))))))))

def TrapPACUse (target_el : (BitVec 2)) : SailM Unit := do
  sail_assert (←((pure ((HaveEL target_el) && (target_el != EL0))) <&&> (do
    (pure ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:21695.86-21695.87"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := 0
  let except ← (( do (ExceptionSyndrome Exception_PACTrap) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

/-- Type quantifiers: k_is_combined : Bool -/
def AuthIA (x : (BitVec 64)) (y : (BitVec 64)) (is_combined : Bool) : SailM (BitVec 64) := do
  let TrapEL2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let TrapEL3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let Enable ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let APIAKey_EL1 ← (( do (pure ((Sail.BitVec.extractLsb (← readReg APIAKeyHi_EL1) 63 0) +++ (Sail.BitVec.extractLsb (← readReg APIAKeyLo_EL1) 63 0))) ) : SailM (BitVec 128) )
  let (Enable, TrapEL2, TrapEL3) ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    let (Enable, TrapEL2, TrapEL3) ← (( do
      (if ((questionMark == EL0) : Bool)
      then
        (do let IsEL1Regime ← (( do (pure ((← (S1TranslationRegime__1 ())) == EL1)) ) : SailM Bool )
            let Enable ←
              (if (IsEL1Regime : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EnIA (← readReg SCTLR_EL1))))
              else (do (pure (_get_SCTLR_EL2_Type_EnIA (← readReg SCTLR_EL2)))))
            let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
            (pure (Enable, TrapEL2, TrapEL3)))
      else
        (do let (Enable, TrapEL2, TrapEL3) ← (( do
              (if ((questionMark == EL1) : Bool)
              then
                (do let Enable ← (pure (_get_SCTLR_EL1_Type_EnIA (← readReg SCTLR_EL1)))
                    let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1)))
                    let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                    (pure (Enable, TrapEL2, TrapEL3)))
              else
                (do let (Enable, TrapEL2, TrapEL3) ← (( do
                      (if ((questionMark == EL2) : Bool)
                      then
                        (do let Enable ← (pure (_get_SCTLR_EL2_Type_EnIA (← readReg SCTLR_EL2)))
                            let TrapEL2 : Bool := false
                            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                            (pure (Enable, TrapEL2, TrapEL3)))
                      else
                        (do let (Enable, TrapEL2, TrapEL3) ← (( do
                              (if ((questionMark == EL3) : Bool)
                              then
                                (do let Enable ← (pure (_get_SCTLR_EL3_Type_EnIA (← readReg SCTLR_EL3)))
                                    let TrapEL2 : Bool := false
                                    let TrapEL3 : Bool := false
                                    (pure (Enable, TrapEL2, TrapEL3)))
                              else (do (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                    (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
    (pure (Enable, TrapEL2, TrapEL3)) ) : SailM ((BitVec 1) × Bool × Bool) )
  (if ((Enable == 0#1) : Bool)
  then (do (pure x))
  else
    (do (if ((←((pure TrapEL3) <&&> (do
             (EL3SDDUndefPriority ())))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (TrapEL2 : Bool)
              then
                (do (TrapPACUse EL2)
                    (undefined_bitvector 64))
              else
                (do (if (TrapEL3 : Bool)
                    then
                      (do (if ((← (EL3SDDUndef ())) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (TrapPACUse EL3)
                                (undefined_bitvector 64))))
                    else (do (Auth x y APIAKey_EL1 false 0#1 is_combined)))))))))

/-- Type quantifiers: k_is_combined : Bool -/
def AuthIB (x : (BitVec 64)) (y : (BitVec 64)) (is_combined : Bool) : SailM (BitVec 64) := do
  let TrapEL2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let TrapEL3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let Enable ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let APIBKey_EL1 ← (( do (pure ((Sail.BitVec.extractLsb (← readReg APIBKeyHi_EL1) 63 0) +++ (Sail.BitVec.extractLsb (← readReg APIBKeyLo_EL1) 63 0))) ) : SailM (BitVec 128) )
  let (Enable, TrapEL2, TrapEL3) ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    let (Enable, TrapEL2, TrapEL3) ← (( do
      (if ((questionMark == EL0) : Bool)
      then
        (do let IsEL1Regime ← (( do (pure ((← (S1TranslationRegime__1 ())) == EL1)) ) : SailM Bool )
            let Enable ←
              (if (IsEL1Regime : Bool)
              then (do (pure (_get_SCTLR_EL1_Type_EnIB (← readReg SCTLR_EL1))))
              else (do (pure (_get_SCTLR_EL2_Type_EnIB (← readReg SCTLR_EL2)))))
            let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
            (pure (Enable, TrapEL2, TrapEL3)))
      else
        (do let (Enable, TrapEL2, TrapEL3) ← (( do
              (if ((questionMark == EL1) : Bool)
              then
                (do let Enable ← (pure (_get_SCTLR_EL1_Type_EnIB (← readReg SCTLR_EL1)))
                    let TrapEL2 ← (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_API (← readReg HCR_EL2)) == 0#1)))
                    let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                    (pure (Enable, TrapEL2, TrapEL3)))
              else
                (do let (Enable, TrapEL2, TrapEL3) ← (( do
                      (if ((questionMark == EL2) : Bool)
                      then
                        (do let Enable ← (pure (_get_SCTLR_EL2_Type_EnIB (← readReg SCTLR_EL2)))
                            let TrapEL2 : Bool := false
                            let TrapEL3 ← (pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_API (← readReg SCR_EL3)) == 0#1)))
                            (pure (Enable, TrapEL2, TrapEL3)))
                      else
                        (do let (Enable, TrapEL2, TrapEL3) ← (( do
                              (if ((questionMark == EL3) : Bool)
                              then
                                (do let Enable ← (pure (_get_SCTLR_EL3_Type_EnIB (← readReg SCTLR_EL3)))
                                    let TrapEL2 : Bool := false
                                    let TrapEL3 : Bool := false
                                    (pure (Enable, TrapEL2, TrapEL3)))
                              else (do (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
                    (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
            (pure (Enable, TrapEL2, TrapEL3)))) ) : SailM ((BitVec 1) × Bool × Bool) )
    (pure (Enable, TrapEL2, TrapEL3)) ) : SailM ((BitVec 1) × Bool × Bool) )
  (if ((Enable == 0#1) : Bool)
  then (do (pure x))
  else
    (do (if ((←((pure TrapEL3) <&&> (do
             (EL3SDDUndefPriority ())))) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if (TrapEL2 : Bool)
              then
                (do (TrapPACUse EL2)
                    (undefined_bitvector 64))
              else
                (do (if (TrapEL3 : Bool)
                    then
                      (do (if ((← (EL3SDDUndef ())) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (TrapPACUse EL3)
                                (undefined_bitvector 64))))
                    else (do (Auth x y APIBKey_EL1 false 1#1 is_combined)))))))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64] -/
def X_read (n : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22319.27-22319.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || (width == 64)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:22320.63-22320.64"
  (if ((n != 31) : Bool)
  then (do (pure (Sail.BitVec.extractLsb (← (get_R n)) (width -i 1) 0)))
  else (do (pure (Zeros (n := width)))))

/-- Type quantifiers: n : Int, width : Nat, List.elem width [8, 16, 32, 64, 128] -/
def V_read (n : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22333.27-22333.28"
  sail_assert ((width == 8) || ((width == 16) || ((width == 32) || ((width == 64) || (width == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:22334.78-22334.79"
  (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg _Z) n) (width -i 1) 0))

/-- Type quantifiers: n : Int, part : Int, width : Nat, width ≥ 0 -/
def Vpart_read (n : Int) (part : Int) (width : Nat) : SailM (BitVec width) := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22343.27-22343.28"
  sail_assert ((part == 0) || (part == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22344.32-22344.33"
  (if ((part == 0) : Bool)
  then
    (do sail_assert (width <b 128) "sail-arm/arm-v9.4-a/src/v8_base.sail:22346.26-22346.27"
        sail_assert (((((width == 8) || (width == 16)) || (width == 32)) || (width == 64)) || (width == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22347.57-22347.58"
        (V_read n width))
  else
    (do sail_assert ((width == 32) || (width == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22350.40-22350.41"
        let vreg ← (( do (V_read n 128) ) : SailM (BitVec 128) )
        (pure (Sail.BitVec.extractLsb vreg ((width *i 2) -i 1) width))))

/-- Type quantifiers: n : Int, part : Int, width : Nat, width ≥ 0 -/
def Vpart_set (n : Int) (part : Int) (width : Nat) (value_name : (BitVec width)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22361.27-22361.28"
  sail_assert ((part == 0) || (part == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22362.32-22362.33"
  (if ((part == 0) : Bool)
  then
    (do sail_assert (width <b 128) "sail-arm/arm-v9.4-a/src/v8_base.sail:22364.26-22364.27"
        sail_assert (((((width == 8) || (width == 16)) || (width == 32)) || (width == 64)) || (width == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:22365.57-22365.58"
        (V_set n width value_name))
  else
    (do sail_assert (width == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:22368.26-22368.27"
        let vreg ← (( do (V_read n 64) ) : SailM (BitVec 64) )
        (V_set n 128 ((Sail.BitVec.extractLsb value_name 63 0) +++ vreg))))

def AArch64_ResetGeneralRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 30
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (X_set i 64 (← (__UNKNOWN_bits 64)))
  (pure loop_vars)

def AArch64_ResetSIMDFPRegisters (_ : Unit) : SailM Unit := do
  let loop_i_lower := 0
  let loop_i_upper := 31
  let mut loop_vars := ()
  for i in [loop_i_lower:loop_i_upper:1]i do
    let () := loop_vars
    loop_vars ← do (V_set i 128 (← (__UNKNOWN_bits 128)))
  (pure loop_vars)

def AArch64_ResetSpecialRegisters (_ : Unit) : SailM Unit := do
  writeReg SP_EL0 (← (__UNKNOWN_bits 64))
  writeReg SP_EL1 (← (__UNKNOWN_bits 64))
  writeReg SPSR_EL1 (Mk_SPSR_EL1_Type (← (__UNKNOWN_bits 64)))
  writeReg ELR_EL1 (← (__UNKNOWN_bits 64))
  (if ((HaveEL EL2) : Bool)
  then
    (do writeReg SP_EL2 (← (__UNKNOWN_bits 64))
        writeReg SPSR_EL2 (Mk_SPSR_EL2_Type (← (__UNKNOWN_bits 64)))
        writeReg ELR_EL2 (← (__UNKNOWN_bits 64)))
  else (do (pure ())))
  (if ((HaveEL EL3) : Bool)
  then
    (do writeReg SP_EL3 (← (__UNKNOWN_bits 64))
        writeReg SPSR_EL3 (Mk_SPSR_EL3_Type (← (__UNKNOWN_bits 64)))
        writeReg ELR_EL3 (← (__UNKNOWN_bits 64)))
  else (do (pure ())))
  (if ((HaveAArch32EL EL1) : Bool)
  then
    (do writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) 31 0 (← (__UNKNOWN_bits 32)))
        writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) 31 0 (← (__UNKNOWN_bits 32))))
  else (do (pure ())))
  writeReg DLR_EL0 (← (__UNKNOWN_bits 64))
  writeReg DSPSR_EL0 (Mk_DSPSR_EL0_Type (← (__UNKNOWN_bits 64)))

def undefined_CNTKCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTKCTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTKCTL_read__1 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTKCTL ) : SailM CNTKCTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTKCTL_EL1) 0 32)))

def CheckTransactionalSystemAccess (op0 : (BitVec 2)) (op1 : (BitVec 3)) (crn : (BitVec 4)) (crm : (BitVec 4)) (op2 : (BitVec 3)) (read : (BitVec 1)) : SailM Bool := do
  let b__0 := (((((read +++ op0) +++ op1) +++ crn) +++ crm) +++ op2)
  (if ((((Sail.BitVec.extractLsb b__0 16 7) == (0b0000110100#10 : (BitVec 10))) && ((Sail.BitVec.extractLsb b__0 2 1) == (0b11#2 : (BitVec 2)))) : Bool)
  then (do (pure true))
  else
    (do (if ((b__0 == (0b00101101110100001#17 : (BitVec 17))) : Bool)
        then (do (pure true))
        else
          (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x6D08#16 : (BitVec 16))) : Bool)
              then (do (pure true))
              else
                (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x6D10#16 : (BitVec 16))) : Bool)
                    then (do (pure true))
                    else
                      (do (if ((b__0 == (0b01100001000110000#17 : (BitVec 17))) : Bool)
                          then (do (pure true))
                          else
                            (do (if ((b__0 == (0b01101110011100100#17 : (BitVec 17))) : Bool)
                                then (do (pure true))
                                else
                                  (do (if ((b__0 == (0b11101100100101001#17 : (BitVec 17))) : Bool)
                                      then (do (pure ((← readReg PSTATE).EL == EL0)))
                                      else
                                        (do (if ((b__0 == (0b11100000100101001#17 : (BitVec 17))) : Bool)
                                            then (do (pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL2)) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1)))))
                                            else
                                              (do (if ((b__0 == (0b11110000100101001#17 : (BitVec 17))) : Bool)
                                                  then (do (pure ((← readReg PSTATE).EL == EL2)) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1))))
                                                  else
                                                    (do (if ((b__0 == (0b11111000100101001#17 : (BitVec 17))) : Bool)
                                                        then (do (pure ((← readReg PSTATE).EL == EL3)))
                                                        else
                                                          (do (if ((b__0 == (0b00101101110111000#17 : (BitVec 17))) : Bool)
                                                              then (do (pure true))
                                                              else
                                                                (do (if ((b__0 == (0b10101101110111001#17 : (BitVec 17))) : Bool)
                                                                    then (do (pure true))
                                                                    else
                                                                      (do (if ((b__0 == (0b00101101110111010#17 : (BitVec 17))) : Bool)
                                                                          then (do (pure true))
                                                                          else
                                                                            (do (if ((b__0 == (0b10101101110111011#17 : (BitVec 17))) : Bool)
                                                                                then (do (pure true))
                                                                                else
                                                                                  (do (if ((b__0 == (0b00100001110111110#17 : (BitVec 17))) : Bool)
                                                                                      then (do (pure true))
                                                                                      else
                                                                                        (do (if ((b__0 == (0b11110100100101001#17 : (BitVec 17))) : Bool)
                                                                                            then (do (pure false))
                                                                                            else
                                                                                              (do (if ((b__0 == (0b11100000100101010#17 : (BitVec 17))) : Bool)
                                                                                                  then (do (pure false))
                                                                                                  else
                                                                                                    (do (if ((b__0 == (0b11100000100101000#17 : (BitVec 17))) : Bool)
                                                                                                        then (do (pure false))
                                                                                                        else
                                                                                                          (do (if ((b__0 == (0b11110100100101000#17 : (BitVec 17))) : Bool)
                                                                                                              then (do (pure false))
                                                                                                              else
                                                                                                                (do (if ((b__0 == (0b11110000100101000#17 : (BitVec 17))) : Bool)
                                                                                                                    then (do (pure false))
                                                                                                                    else
                                                                                                                      (do (if ((b__0 == (0b11111000100101000#17 : (BitVec 17))) : Bool)
                                                                                                                          then (do (pure false))
                                                                                                                          else
                                                                                                                            (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 10) == (0#1 : (BitVec 1)))) : Bool)
                                                                                                                                then (do (pure true))
                                                                                                                                else
                                                                                                                                  (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 8) == (0b100#3 : (BitVec 3)))) : Bool)
                                                                                                                                      then (do (pure true))
                                                                                                                                      else
                                                                                                                                        (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xA#4 : (BitVec 4)))) : Bool)
                                                                                                                                            then (do (pure true))
                                                                                                                                            else
                                                                                                                                              (do (if ((((Sail.BitVec.extractLsb b__0 16 6) == (0b11100011001#11 : (BitVec 11))) && ((Sail.BitVec.extractLsb b__0 4 0) == (0b00010#5 : (BitVec 5)))) : Bool)
                                                                                                                                                  then (do (pure true))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((b__0 == (0b11100011001011011#17 : (BitVec 17))) : Bool)
                                                                                                                                                        then (do (pure true))
                                                                                                                                                        else
                                                                                                                                                          (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xD#4 : (BitVec 4)))) : Bool)
                                                                                                                                                              then (do (pure true))
                                                                                                                                                              else
                                                                                                                                                                (do (if ((((Sail.BitVec.extractLsb b__0 16 14) == (0b111#3 : (BitVec 3))) && ((Sail.BitVec.extractLsb b__0 10 7) == (0xE#4 : (BitVec 4)))) : Bool)
                                                                                                                                                                    then (do (pure true))
                                                                                                                                                                    else
                                                                                                                                                                      (do (if ((b__0 == (0b00101101110011111#17 : (BitVec 17))) : Bool)
                                                                                                                                                                          then (do (pure true))
                                                                                                                                                                          else
                                                                                                                                                                            (do (if (((Sail.BitVec.extractLsb b__0 16 1) == (0x2DCE#16 : (BitVec 16))) : Bool)
                                                                                                                                                                                then (do (pure true))
                                                                                                                                                                                else
                                                                                                                                                                                  (do (if ((((Sail.BitVec.extractLsb b__0 15 14) == (0b11#2 : (BitVec 2))) && (((Sail.BitVec.extractLsb b__0 10 10) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 8 7) == (0b11#2 : (BitVec 2))))) : Bool)
                                                                                                                                                                                      then (do (__IMPDEF_boolean ""))
                                                                                                                                                                                      else (do (pure false)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

def AArch64_CheckSystemAccess (op0 : (BitVec 2)) (op1 : (BitVec 3)) (crn : (BitVec 4)) (crm : (BitVec 4)) (op2 : (BitVec 3)) (rt : (BitVec 5)) (read : (BitVec 1)) : SailM Unit := do
  (if ((← (HaveBTIExt ())) : Bool)
  then (do (BranchTargetCheck ()))
  else (do (pure ())))
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))) <&&> (do
       (pure (! (← (CheckTransactionalSystemAccess op0 op1 crn crm op2 read))))))) : Bool)
  then (do (FailTransaction TMFailure_ERR false))
  else (do (pure ())))

/-- Type quantifiers: k_guardedpage : Bool -/
def SetInGuardedPage (guardedpage : Bool) : SailM Unit := do
  writeReg InGuardedPage guardedpage

def BTypeCompatible_BTI (hintcode : (BitVec 2)) : SailM Bool := do
  match hintcode with
  | 0b00 => (pure false)
  | 0b01 => (pure ((← readReg PSTATE).BTYPE != 0b11#2))
  | 0b10 => (pure ((← readReg PSTATE).BTYPE != 0b10#2))
  | 0b11 => (pure true)
  | _ => (do (undefined_bool ()))

/-- Type quantifiers: k_x : Bool -/
def SetBTypeCompatible (x : Bool) : SailM Unit := do
  writeReg BTypeCompatible x

def SetBTypeNext (x : (BitVec 2)) : SailM Unit := do
  writeReg BTypeNext x

def AArch64_AllocationTagAccessIsEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((((_get_SCR_EL3_Type_ATA (← readReg SCR_EL3)) == 0#1) && ((el == EL0) || ((el == EL1) || (el == EL2)))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (((_get_HCR_EL2_Type_ATA (← readReg HCR_EL2)) == 0#1) && ((el == EL0) || (el == EL1)))) <&&> (do
             (EL2Enabled ())) <&&> (do
             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))))) : Bool)
        then (do (pure false))
        else
          (do let regime ← (( do (TranslationRegime el) ) : SailM Regime )
              match regime with
              | .Regime_EL3 => (pure ((_get_SCTLR_EL3_Type_ATA (← readReg SCTLR_EL3)) == 1#1))
              | .Regime_EL2 => (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1))
              | .Regime_EL20 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL2_Type_ATA0 (← readReg SCTLR_EL2)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL2_Type_ATA (← readReg SCTLR_EL2)) == 1#1)))))
              | .Regime_EL10 =>
                (do
                  (if ((el == EL0) : Bool)
                  then (do (pure ((_get_SCTLR_EL1_Type_ATA0 (← readReg SCTLR_EL1)) == 1#1)))
                  else (do (pure ((_get_SCTLR_EL1_Type_ATA (← readReg SCTLR_EL1)) == 1#1)))))
              | _ =>
                (do
                  (Unreachable ())
                  (undefined_bool ()))))))

def undefined_GCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RGSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RGSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: alignment : Int, size : Int -/
def AllInAlignedQuantity (address : (BitVec 64)) (size : Int) (alignment : Int) : SailM Bool := do
  sail_assert (size ≤b alignment) "sail-arm/arm-v9.4-a/src/v8_base.sail:22735.28-22735.29"
  (pure ((Align_bits (BitVec.subInt (BitVec.addInt address size) 1) alignment) == (Align_bits address alignment)))

def AArch64_SPAlignmentFault (_ : Unit) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_SPAlignment) ) : SailM ExceptionRecord )
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((EL2Enabled ()) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def SP_read (_ : Unit) : SailM (BitVec 64) := do
  (if (((← readReg PSTATE).SP == 0#1) : Bool)
  then (do readReg SP_EL0)
  else
    (do let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL0) : Bool)
        then (do readReg SP_EL0)
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do readReg SP_EL1)
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do readReg SP_EL2)
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do readReg SP_EL3)
                          else (do (undefined_bitvector 64)))))))))))

def CheckSPAlignment (_ : Unit) : SailM Unit := do
  let sp ← (( do (SP_read ()) ) : SailM (BitVec 64) )
  let stack_align_check ← (( do (undefined_bool ()) ) : SailM Bool )
  let stack_align_check ← (( do
    (if (((← readReg PSTATE).EL == EL0) : Bool)
    then (do (pure ((_get_SCTLRType_SA0 (← (SCTLR_read__1 ()))) != 0#1)))
    else (do (pure ((_get_SCTLRType_SA (← (SCTLR_read__1 ()))) != 0#1)))) ) : SailM Bool )
  (if ((stack_align_check && (sp != (Align_bits sp 16))) : Bool)
  then (do (AArch64_SPAlignmentFault ()))
  else (do (pure ())))


end ArmASL.Functions
