import ArmASL.Part06

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def _get_EDSCR2_Type_EHBWE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_MDSCR_EL1_Type_EMBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_MDSCR_EL1_Type_KDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def _get_MDSCR_EL1_Type_MDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def undefined_OSLSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_OSLSR_EL1_Type_OSLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_DBGOSLSR_Type_OSLK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_OSLAR_EL1_Type_OSLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_DBGOSLSR_Type_OSLM (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange (Sail.BitVec.updateSubrange v 3 3 (Sail.BitVec.extractLsb x (2 -i 1) (((2 -i 1) -i ((3 -i 3) +i 1)) +i 1))) 0 0 (Sail.BitVec.extractLsb x ((2 -i 1) -i ((3 -i 3) +i 1)) ((((2 -i 1) -i ((3 -i 3) +i 1)) -i ((0 -i 0) +i 1)) +i 1)))

def AArch64_GenerateDebugExceptionsFrom (from_el : (BitVec 2)) (from_state : SecurityState) (mask : (BitVec 1)) : SailM Bool := do
  (if ((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 1#1)) <||> (do
       (DoubleLockStatus ())) <||> (do
       (Halted ())))) : Bool)
  then (do (pure false))
  else
    (do let route_to_el2 ← (( do (pure (HaveEL EL2)) <&&> (do (pure (bne from_state SS_Secure)) <||> (do (IsSecureEL2Enabled ()))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
        let target : (BitVec 2) :=
          if (route_to_el2 : Bool)
          then EL2
          else EL1
        let enabled ← (( do (undefined_bool ()) ) : SailM Bool )
        let enabled ← (( do
          (if (((HaveEL EL3) && (BEq.beq from_state SS_Secure)) : Bool)
          then
            (do let enabled ← (pure ((_get_MDCR_EL3_Type_SDD (← readReg MDCR_EL3)) == 0#1))
                (if ((←((pure (from_el == EL0)) <&&> (do
                     (ELUsingAArch32 EL1)))) : Bool)
                then (do (pure enabled) <||> (do (pure ((_get_SDER32_EL3_Type_SUIDEN (← (SDER32_EL3_read ()))) == 1#1))))
                else (do (pure enabled))))
          else (do (pure true))) ) : SailM Bool )
        (if ((from_el == target) : Bool)
        then (do (pure ((←((pure enabled) <&&> (do (pure ((_get_MDSCR_EL1_Type_KDE (← readReg MDSCR_EL1)) == 1#1))))) && (mask == 0#1))))
        else (do (pure (enabled && (((BitVec.toNat target) >b (BitVec.toNat from_el)) : Bool)))))))

def undefined_DBGOSLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGOSLSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGOSLSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGOSLSR ) : SailM DBGOSLSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSLSR_EL1) 0 32)))

def undefined_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HCR_Type_TAC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _get_HCR_Type_VA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HCR_Type_VA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def HCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCR ) : SailM HCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HCR_EL2) 0 32)))

def AArch64_GenerateDebugExceptions (_ : Unit) : SailM Bool := do
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  (AArch64_GenerateDebugExceptionsFrom (← readReg PSTATE).EL ss (← readReg PSTATE).D)

def undefined_HSCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HSCTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_HSCTLR_Type_LSMAOE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_SCTLR_Type_LSMAOE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_HSCTLR_Type_nTLSMD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_SCTLR_Type_nTLSMD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_SCTLR_EL1_Type_nTLSMD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def _get_SCTLR_EL2_Type_nTLSMD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 28 28)

def undefined_SCTLR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCTLR_EL2_Type_ATA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_SCTLR_EL1_Type_ATA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_DBGBCR_EL1_Type_BT (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 23 20)

def _get_SCTLR_EL2_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_HCRX_EL2_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_SCTLR_EL1_Type_CMOW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_SCTLR_EL2_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL1_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL3_Type_EnIA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _get_SCTLR_EL2_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL1_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL3_Type_EnIB (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_EL2_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL1_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL3_Type_TCF (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 41 40)

def _get_SCTLR_EL2_Type_TCF0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 39 38)

def _get_SCTLR_EL1_Type_TCF0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 39 38)

def _get_SCTLR_EL2_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL1_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL3_Type_TCSO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_SCTLR_EL2_Type_TCSO0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_SCTLR_EL1_Type_TCSO0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def HSCTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HSCTLR ) : SailM HSCTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SCTLR_EL2) 0 32)))

def undefined_SCTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SCTLR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_SCTLR_Type_AFE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_SCTLR_Type_TRE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_SCTLR_Type_UNK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_SCTLR_Type_UWXN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def SCTLR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SCTLR_NS ) : SailM SCTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SCTLR_EL1) 0 32)))

def SCTLR_read__2 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_SCTLR_Type ()) ) : SailM SCTLR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then
    (do let r ← readReg SCTLR_S
        let r : SCTLR_Type := (BitVec.update r 11 (Bit 1#1))
        (pure (BitVec.update r 22 (Bit 1#1))))
  else
    (do let r ← (SCTLR_NS_read ())
        let r : SCTLR_Type := (BitVec.update r 11 (Bit 1#1))
        (pure (BitVec.update r 22 (Bit 1#1)))))

def SCTLR_read (regime : (BitVec 2)) : SailM (BitVec 64) := do
  let r ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let r ← (( do
    let questionMark := regime
    (if ((questionMark == EL1) : Bool)
    then (do readReg SCTLR_EL1)
    else
      (do (if ((questionMark == EL2) : Bool)
          then (do readReg SCTLR_EL2)
          else
            (do (if ((questionMark == EL3) : Bool)
                then (do readReg SCTLR_EL3)
                else
                  (do (Unreachable ())
                      (pure r))))))) ) : SailM (BitVec 64) )
  (pure (Mk_SCTLRType r))

def SCTLR_read__1 (_ : Unit) : SailM (BitVec 64) := do
  (SCTLR_read (← (S1TranslationRegime__1 ())))

def IsCurrentSecurityState (ss : SecurityState) : SailM Bool := do
  (pure (BEq.beq (← (CurrentSecurityState ())) ss))

def ConditionHolds (cond : (BitVec 4)) : SailM Bool := do
  let result ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do
    match (Sail.BitVec.extractLsb cond 3 1) with
    | 0b000 => (do (pure ((← readReg PSTATE).Z == 1#1)))
    | 0b001 => (do (pure ((← readReg PSTATE).C == 1#1)))
    | 0b010 => (do (pure ((← readReg PSTATE).N == 1#1)))
    | 0b011 => (do (pure ((← readReg PSTATE).V == 1#1)))
    | 0b100 => (do (pure ((← readReg PSTATE).C == 1#1)) <&&> (do (pure ((← readReg PSTATE).Z == 0#1))))
    | 0b101 => (do (pure ((← readReg PSTATE).N == (← readReg PSTATE).V)))
    | 0b110 => (do (pure ((← readReg PSTATE).N == (← readReg PSTATE).V)) <&&> (do (pure ((← readReg PSTATE).Z == 0#1))))
    | _ => (pure true) ) : SailM Bool )
  (if (((((BitVec.access cond 0) : BitVec 1) == 1#1) && (cond != 0b1111#4)) : Bool)
  then (do (pure (! result)))
  else (do (pure result)))

def ThisInstrLength (_ : Unit) : SailM Int := do
  (if ((BEq.beq (← readReg __ThisInstrEnc) __T16) : Bool)
  then (do (pure 16))
  else (do (pure 32)))

def undefined_ESR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ESR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_ESR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ESR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_HPFAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HPFAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HavePFAR (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PFAR)

def undefined_MFAR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MFAR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PFAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PFAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PFAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PFAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveDoubleFaultExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleFault)

def ResetSVEState (_ : Unit) : SailM Unit := do
  let loop_n_lower := 0
  let loop_n_upper := 31
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do writeReg _Z (vectorUpdate (← readReg _Z) n (Zeros (n := MAX_VL)))
  (pure loop_vars)
  let loop_n_lower := 0
  let loop_n_upper := 15
  let mut loop_vars_1 := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars_1
    loop_vars_1 ← do writeReg _P (vectorUpdate (← readReg _P) n (Zeros (n := MAX_PL)))
  (pure loop_vars_1)
  writeReg _FFR (Zeros (n := MAX_PL))
  writeReg FPSR (Mk_FPSR_Type (Sail.BitVec.zeroExtend 0x0800009F#32 64))

def undefined_SPSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_abt_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_abt_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_fiq_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_fiq_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_hyp_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_hyp_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SPSR_hyp_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SPSR_hyp ) : SailM SPSR_hyp_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SPSR_EL2) 0 32)))

def SPSR_hyp_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SPSR_hyp_Type := value_name
  writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _SPSR_hyp r

def undefined_SPSR_irq_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_irq_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SPSR_mon_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_mon_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_SPSR_svc_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SPSR_svc_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SPSR_svc_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SPSR_svc ) : SailM SPSR_svc_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SPSR_EL1) 0 32)))

def SPSR_svc_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : SPSR_svc_Type := value_name
  writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _SPSR_svc r

def undefined_SPSR_und_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SPSR_und_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def SPSR_set {N : _} (value_name : (BitVec N)) : SailM Unit := do
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do sail_assert (N == 32) "sail-arm/arm-v9.4-a/src/v8_base.sail:9811.22-9811.23"
        let questionMark ← do (pure (← readReg PSTATE).M)
        (if ((questionMark == M32_FIQ) : Bool)
        then (do writeReg SPSR_fiq (Sail.BitVec.updateSubrange (← readReg SPSR_fiq) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
        else
          (do (if ((questionMark == M32_IRQ) : Bool)
              then (do writeReg SPSR_irq (Sail.BitVec.updateSubrange (← readReg SPSR_irq) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
              else
                (do (if ((questionMark == M32_Svc) : Bool)
                    then (do (SPSR_svc_write (Mk_SPSR_svc_Type (Sail.BitVec.updateSubrange (← (SPSR_svc_read ())) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))))
                    else
                      (do (if ((questionMark == M32_Monitor) : Bool)
                          then (do writeReg SPSR_mon (Sail.BitVec.updateSubrange (← readReg SPSR_mon) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                          else
                            (do (if ((questionMark == M32_Abort) : Bool)
                                then (do writeReg SPSR_abt (Sail.BitVec.updateSubrange (← readReg SPSR_abt) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                                else
                                  (do (if ((questionMark == M32_Hyp) : Bool)
                                      then (do (SPSR_hyp_write (Mk_SPSR_hyp_Type (Sail.BitVec.updateSubrange (← (SPSR_hyp_read ())) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))))
                                      else
                                        (do (if ((questionMark == M32_Undef) : Bool)
                                            then (do writeReg SPSR_und (Sail.BitVec.updateSubrange (← readReg SPSR_und) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                                            else (do (Unreachable ()))))))))))))))))
  else
    (do sail_assert (N == 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:9839.22-9839.23"
        let questionMark ← do (pure (← readReg PSTATE).EL)
        (if ((questionMark == EL1) : Bool)
        then (do writeReg SPSR_EL1 (Sail.BitVec.updateSubrange (← readReg SPSR_EL1) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do writeReg SPSR_EL2 (Sail.BitVec.updateSubrange (← readReg SPSR_EL2) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do writeReg SPSR_EL3 (Sail.BitVec.updateSubrange (← readReg SPSR_EL3) (N -i 1) 0 (Sail.BitVec.extractLsb value_name (N -i 1) 0)))
                    else (do (Unreachable ())))))))))

def SynchronizeContext (_ : Unit) : Unit :=
  ()

def SynchronizeErrors (_ : Unit) : Unit :=
  ()

def undefined_EDECCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDECCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_EDECCR_Type_NSE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _update_EDECCR_Type_NSE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _update_EDECCR_Type_NSR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def _update_EDECCR_Type_NSR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _update_EDECCR_Type_NSR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _update_EDECCR_Type_RLE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _update_EDECCR_Type_RLE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_EDECCR_Type_RLR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _update_EDECCR_Type_RLR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _update_EDECCR_Type_RLR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _update_EDECCR_Type_SE1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_EDECCR_Type_SE2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_EDECCR_Type_SE3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_EDECCR_Type_SR0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _update_EDECCR_Type_SR1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_EDECCR_Type_SR2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _update_EDECCR_Type_SR3 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def undefined_OSECCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_OSECCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def EDECCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDECCR ) : SailM EDECCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg OSECCR_EL1) 0 32)))

def undefined_EDESR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HaveExtendedECDebugEvents (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def Havev8p8Debug (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p8)

/-- Type quantifiers: k_exception_entry : Bool -/
def CheckExceptionCatch (exception_entry : Bool) : SailM Unit := do
  let ctrl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let exception_exit ← (( do (undefined_bool ()) ) : SailM Bool )
  let increment_name ← (( do (undefined_int ()) ) : SailM Int )
  let ss ← (( do (SecurityStateAtEL (← readReg PSTATE).EL) ) : SailM SecurityState )
  let base : Int := 0
  let base : Int :=
    match ss with
    | .SS_Secure => 0
    | .SS_NonSecure => 4
    | .SS_Realm => 16
    | .SS_Root => 0
  let base := base
  (if ((← (HaltingAllowed ())) : Bool)
  then
    (do let halt ← (( do (undefined_bool ()) ) : SailM Bool )
        let halt ← (( do
          (if ((← (HaveExtendedECDebugEvents ())) : Bool)
          then
            (do let exception_exit : Bool := (! exception_entry)
                let increment_name :=
                  if ((BEq.beq ss SS_Realm) : Bool)
                  then 4
                  else 8
                let ctrl ← (( do (pure (((BitVec.access (← (EDECCR_read ())) (((BitVec.toNat (← readReg PSTATE).EL) +i base) +i increment_name)) : BitVec 1) +++ ((BitVec.access (← (EDECCR_read ())) ((BitVec.toNat (← readReg PSTATE).EL) +i base)) : BitVec 1))) ) : SailM (BitVec 2) )
                match ctrl with
                | 0b00 => (pure false)
                | 0b01 => (pure true)
                | 0b10 => (pure (exception_exit == true))
                | _ => (pure (exception_entry == true)))
          else (do (pure (((BitVec.access (← (EDECCR_read ())) ((BitVec.toNat (← readReg PSTATE).EL) +i base)) : BitVec 1) == 1#1)))) ) : SailM Bool )
        (if (halt : Bool)
        then
          (do (if (((← (Havev8p8Debug ())) && exception_entry) : Bool)
              then (do writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 3 3 1#1))
              else (do (Halt DebugHalt_ExceptionCatch))))
        else (do (pure ()))))
  else (do (pure ())))

def HaveNV2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NV2)

def HaveNVExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_NV)

def VBAR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VBAR_NS ) : SailM VBAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VBAR_EL1) 0 32)))

def VBAR_read__2 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_bitvector 32) ) : SailM VBAR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg VBAR_S)
  else (do (VBAR_NS_read ())))

/-- Type quantifiers: vect_offset_in : Int -/
def AArch64_TakeException (target_el : (BitVec 2)) (exception_in : ExceptionRecord) (preferred_exception_return : (BitVec 64)) (vect_offset_in : Int) : SailM Unit := do
  writeReg __janus_exc_taken true
  writeReg __janus_exc_target_el target_el
  writeReg __janus_exc_type exception_in.exceptype
  writeReg __janus_exc_syndrome exception_in.syndrome
  writeReg __janus_exc_vaddress exception_in.vaddress
  sailThrow ((Error_ExceptionTaken ()))

def ExceptionSyndrome (exceptype : Exception) : SailM ExceptionRecord := do
  let r ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let r : ExceptionRecord := { r with exceptype := exceptype }
  let r : ExceptionRecord := { r with syndrome := (Zeros (n := 25)) }
  let r : ExceptionRecord := { r with syndrome2 := (Zeros (n := 24)) }
  let r : ExceptionRecord := { r with vaddress := (Zeros (n := 64)) }
  let r : ExceptionRecord := { r with ipavalid := false }
  let r : ExceptionRecord := { r with NS := 0#1 }
  let r : ExceptionRecord := { r with ipaddress := (Zeros (n := 56)) }
  let r ← (pure { r with paddress := (← do (pure { r.paddress with paspace := (← do (__UNKNOWN_PASpace ())) })) })
  let r ← (pure { r with paddress := (← do (pure { r.paddress with address := (← do (__UNKNOWN_bits 56)) })) })
  (pure { r with trappedsyscallinst := false })

def AArch64_BranchTargetException (vaddress : (BitVec 52)) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_BranchTarget) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 1 0 (← readReg PSTATE).BTYPE))) })
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 2 (Zeros (n := 23))) }
  let target_el : (BitVec 2) := EL1
  let target_el ← (( do
    (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
    then (do (pure (← readReg PSTATE).EL))
    else
      (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
          then (do (pure EL2))
          else (do (pure target_el))))) ) : SailM (BitVec 2) )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def ThisInstr (_ : Unit) : SailM (BitVec 32) := do
  readReg __ThisInstr

def AArch64_ExecutingBROrBLROrRetInstr (_ : Unit) : SailM Bool := do
  let opc ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  (if ((! (← (HaveBTIExt ()))) : Bool)
  then (do (pure false))
  else
    (do let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
        (if ((((Sail.BitVec.extractLsb instr 31 25) == 0b1101011#7) && ((Sail.BitVec.extractLsb instr 20 16) == 0b11111#5)) : Bool)
        then
          (do let opc : (BitVec 4) := (Sail.BitVec.extractLsb instr 24 21)
              (pure (opc != 0b0101#4)))
        else (do (pure false)))))

def AArch64_ExecutingBTIInstr (_ : Unit) : SailM Bool := do
  let CRm ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let op2 ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
  (if ((! (← (HaveBTIExt ()))) : Bool)
  then (do (pure false))
  else
    (do let instr ← (( do (ThisInstr ()) ) : SailM (BitVec 32) )
        (if (((((Sail.BitVec.extractLsb instr 31 22) == 0b1101010100#10) && ((Sail.BitVec.extractLsb instr 21 12) == 0b0000110010#10)) && ((Sail.BitVec.extractLsb instr 4 0) == 0b11111#5)) : Bool)
        then
          (do let CRm : (BitVec 4) := (Sail.BitVec.extractLsb instr 11 8)
              let op2 : (BitVec 3) := (Sail.BitVec.extractLsb instr 7 5)
              (pure ((CRm == 0b0100#4) && (((BitVec.access op2 0) : BitVec 1) == 0#1))))
        else (do (pure false)))))

def BranchTargetCheck (_ : Unit) : SailM Unit := do
  sail_assert (←((HaveBTIExt ()) <&&> (do
    (pure (! (← (UsingAArch32 ()))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:10588.50-10588.51"
  (if ((←(readReg InGuardedPage <&&> (do
       (pure ((← readReg PSTATE).BTYPE != 0b00#2))) <&&> (do
       (pure (! (← readReg BTypeCompatible)))) <&&> (do
       (pure (! (← (Halted ()))))))) : Bool)
  then
    (do let pc ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
        (AArch64_BranchTargetException (Sail.BitVec.extractLsb pc 51 0)))
  else (do (pure ())))
  let branch_instr ← (( do (AArch64_ExecutingBROrBLROrRetInstr ()) ) : SailM Bool )
  let bti_instr ← (( do (AArch64_ExecutingBTIInstr ()) ) : SailM Bool )
  (if ((! (branch_instr || bti_instr)) : Bool)
  then (do writeReg BTypeNext 0b00#2)
  else (do (pure ())))

def AArch32_CurrentCond (_ : Unit) : SailM (BitVec 4) := do
  readReg __currentCond

def ConditionSyndrome (_ : Unit) : SailM (BitVec 5) := do
  let cond ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let syndrome ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do let cond ← (( do (AArch32_CurrentCond ()) ) : SailM (BitVec 4) )
        (if (((← readReg PSTATE).T == 0#1) : Bool)
        then
          (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
              (if ((←((ConditionHolds cond) <&&> (do
                   (ConstrainUnpredictableBool Unpredictable_ESRCONDPASS)))) : Bool)
              then (do (pure (Sail.BitVec.updateSubrange syndrome 3 0 0b1110#4)))
              else (do (pure (Sail.BitVec.updateSubrange syndrome 3 0 cond)))))
        else
          (do (if ((← (__IMPDEF_boolean "Condition valid for trapped T32")) : Bool)
              then
                (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
                    (pure (Sail.BitVec.updateSubrange syndrome 3 0 cond)))
              else
                (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 0#1))
                    (pure (Sail.BitVec.updateSubrange syndrome 3 0 (← (__UNKNOWN_bits 4)))))))))
  else
    (do let syndrome : (BitVec 5) := (BitVec.update syndrome 4 (Bit 1#1))
        (pure (Sail.BitVec.updateSubrange syndrome 3 0 0b1110#4))))

def AArch64_WFxTrap (wfxtype : WFxType) (target_el : (BitVec 2)) : SailM Unit := do
  sail_assert ((BitVec.toNat target_el) >b (BitVec.toNat (← readReg PSTATE).EL)) "sail-arm/arm-v9.4-a/src/v8_base.sail:10642.44-10642.45"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_WFxTrap) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) })
  let except ← (( do
    match wfxtype with
    | .WFxType_WFI => (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b00#2) })
    | .WFxType_WFE => (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b01#2) })
    | .WFxType_WFIT =>
      (do
        let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b10#2) }
        let except : ExceptionRecord := { except with syndrome := (BitVec.update except.syndrome 2 (Bit 1#1)) }
        (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) }))
    | .WFxType_WFET =>
      (do
        let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 1 0 0b11#2) }
        let except : ExceptionRecord := { except with syndrome := (BitVec.update except.syndrome 2 (Bit 1#1)) }
        (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) })) ) : SailM ExceptionRecord )
  (if ((←((pure (target_el == EL1)) <&&> (do
       (EL2Enabled ())) <&&> (do
       (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
  then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else (do (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def AArch64_CheckForWFxTrap (target_el : (BitVec 2)) (wfxtype : WFxType) : SailM Unit := do
  sail_assert (HaveEL target_el) "sail-arm/arm-v9.4-a/src/v8_base.sail:10675.28-10675.29"
  let is_wfe : Bool := ((BEq.beq wfxtype WFxType_WFE) || (BEq.beq wfxtype WFxType_WFET))
  let trap ← (( do (undefined_bool ()) ) : SailM Bool )
  let trap ← (( do
    let questionMark := target_el
    (if ((questionMark == EL1) : Bool)
    then
      (do (pure ((← do
                (if (is_wfe : Bool)
                then (do (pure (_get_SCTLRType_nTWE (← (SCTLR_read__1 ())))))
                else (do (pure (_get_SCTLRType_nTWI (← (SCTLR_read__1 ()))))))) == 0#1)))
    else
      (do (if ((questionMark == EL2) : Bool)
          then
            (do (pure ((← do
                      (if (is_wfe : Bool)
                      then (do (pure (_get_HCR_EL2_Type_TWE (← readReg HCR_EL2))))
                      else (do (pure (_get_HCR_EL2_Type_TWI (← readReg HCR_EL2)))))) == 1#1)))
          else
            (do (if ((questionMark == EL3) : Bool)
                then
                  (do (pure ((← do
                            (if (is_wfe : Bool)
                            then (do (pure (_get_SCR_EL3_Type_TWE (← readReg SCR_EL3))))
                            else (do (pure (_get_SCR_EL3_Type_TWI (← readReg SCR_EL3)))))) == 1#1)))
                else (do (pure trap))))))) ) : SailM Bool )
  (if (trap : Bool)
  then (do (AArch64_WFxTrap wfxtype target_el))
  else (do (pure ())))

def ClearEventRegister (_ : Unit) : SailM Unit := do
  writeReg EventRegister 0#1

def HaveFeatWFxT (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_WFxT)

def HaveTWEDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TWED)

def IsEventRegisterSet (_ : Unit) : SailM Bool := do
  (pure ((← readReg EventRegister) == 1#1))

def WFETrapDelay (target_el : (BitVec 2)) : SailM (Bool × Int) := do
  let delay_enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let delay ← (( do (undefined_int ()) ) : SailM Int )
  let (delay, delay_enabled) ← (( do
    let questionMark := target_el
    let (delay, delay_enabled) ← (( do
      (if ((questionMark == EL1) : Bool)
      then
        (do let (delay, delay_enabled) ← (( do
              (if ((! (← (IsInHost ()))) : Bool)
              then
                (do let delay_enabled ← (pure ((_get_SCTLR_EL1_Type_TWEDEn (← readReg SCTLR_EL1)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCTLR_EL1_Type_TWEDEL (← readReg SCTLR_EL1))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))
              else
                (do let delay_enabled ← (pure ((_get_SCTLR_EL2_Type_TWEDEn (← readReg SCTLR_EL2)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCTLR_EL2_Type_TWEDEL (← readReg SCTLR_EL2))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
            (pure (delay, delay_enabled)))
      else
        (do let (delay, delay_enabled) ← (( do
              (if ((questionMark == EL2) : Bool)
              then
                (do sail_assert (← (EL2Enabled ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:10740.29-10740.30"
                    let delay_enabled ← (pure ((_get_HCR_EL2_Type_TWEDEn (← readReg HCR_EL2)) == 1#1))
                    let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_HCR_EL2_Type_TWEDEL (← readReg HCR_EL2))) +i 8))) ) : SailM Int )
                    (pure (delay, delay_enabled)))
              else
                (do let (delay, delay_enabled) ← (( do
                      (if ((questionMark == EL3) : Bool)
                      then
                        (do let delay_enabled ← (pure ((_get_SCR_EL3_Type_TWEDEn (← readReg SCR_EL3)) == 1#1))
                            let delay ← (( (pure (Int.shiftl 1 ((BitVec.toNat (_get_SCR_EL3_Type_TWEDEL (← readReg SCR_EL3))) +i 8))) ) : SailM Int )
                            (pure (delay, delay_enabled)))
                      else (do (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
                    (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
            (pure (delay, delay_enabled)))) ) : SailM (Int × Bool) )
    (pure (delay, delay_enabled)) ) : SailM (Int × Bool) )
  let delay := delay
  (pure (delay_enabled, delay))

def EnterLowPowerState (_ : Unit) : Unit :=
  ()

/-- Type quantifiers: localtimeout : Int -/
def LocalTimeoutEvent (localtimeout : Int) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: localtimeout : Int -/
def WaitForEvent (localtimeout : Int) : SailM Unit := do
  (if ((! (←((IsEventRegisterSet ()) <||> (do
         (HaveFeatWFxT ()) <&&> (do
           (LocalTimeoutEvent localtimeout)))))) : Bool)
  then
    (do writeReg IsWFEsleep true
        writeReg _DormantCtlReg (Sail.BitVec.updateSubrange (← readReg _DormantCtlReg) 10 10 1#1)
        (pure (EnterLowPowerState ())))
  else (do (pure ())))

/-- Type quantifiers: delay : Int, k_delay_enabled : Bool -/
def WaitForEventUntilDelay (delay_enabled : Bool) (delay : Int) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: localtimeout : Int -/
def Hint_WFE (localtimeout : Int) (wfxtype : WFxType) : SailM Unit := do
  let delay ← (( do (undefined_int ()) ) : SailM Int )
  let delay_enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let sctlr ← (( do (undefined_SCTLRType ()) ) : SailM SCTLRType )
  let trap ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (IsEventRegisterSet ())) : Bool)
  then (do (ClearEventRegister ()))
  else
    (do (if ((←((HaveFeatWFxT ()) <&&> (do
             (LocalTimeoutEvent localtimeout)))) : Bool)
        then (do (EndOfInstruction ()))
        else
          (do let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
              let trap : Bool := false
              let (target_el, trap) ← (( do
                (if (((← readReg PSTATE).EL == EL0) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let sctlr ← (( do (SCTLR_read__1 ()) ) : SailM SCTLRType )
                              let trap : Bool := ((_get_SCTLRType_nTWE sctlr) == 0#1)
                              let target_el : (BitVec 2) := EL1
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL1 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              let (target_el, trap) ← (( do
                (if ((←((pure (! trap)) <&&> (do
                     (pure ((← readReg PSTATE).EL == EL0)) <||> (do
                       (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
                     (EL2Enabled ())) <&&> (do
                     (pure (! (← (IsInHost ()))))))) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let trap ← (pure ((_get_HCR_EL2_Type_TWE (← readReg HCR_EL2)) == 1#1))
                              let target_el : (BitVec 2) := EL2
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL2 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              let (target_el, trap) ← (( do
                (if ((←((pure ((! trap) && (HaveEL EL3))) <&&> (do
                     (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
                then
                  (do let (target_el, trap) ← (( do
                        (if ((← (HaveTWEDExt ())) : Bool)
                        then
                          (do let trap ← (pure ((_get_SCR_EL3_Type_TWE (← readReg SCR_EL3)) == 1#1))
                              let target_el : (BitVec 2) := EL3
                              (pure (target_el, trap)))
                        else
                          (do (AArch64_CheckForWFxTrap EL3 wfxtype)
                              (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
                      (pure (target_el, trap)))
                else (do (pure (target_el, trap)))) ) : SailM ((BitVec 2) × Bool) )
              (if ((←((pure trap) <&&> (do
                   (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
              then
                (do let (delay, delay_enabled) ← (( do
                      let (tup__0, tup__1) ← do (WFETrapDelay target_el)
                      let delay_enabled : Bool := tup__0
                      let delay : Int := tup__1
                      (pure (delay, delay_enabled)) ) : SailM (Int × Bool) )
                    let delay := delay
                    (if ((! (← (WaitForEventUntilDelay delay_enabled delay))) : Bool)
                    then (do (AArch64_WFxTrap wfxtype target_el))
                    else (do (pure ()))))
              else (do (WaitForEvent localtimeout)))))))

def IsVirtualSErrorPending (_ : Unit) : SailM Bool := do
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do (pure ((_get_HCR_Type_VA (← (HCR_read ()))) == 1#1)))
  else (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1))))

def FIQPending (_ : Unit) : (Bool × Bool) :=
  (false, false)

def __GIC_InterruptPending (_ : Unit) : SailM Bool := do
  (pure (is_some (← readReg __GIC_Pending)))

def IRQPending (_ : Unit) : SailM (Bool × Bool) := do
  (pure ((← (__GIC_InterruptPending ())), false))

def IsPhysicalSErrorPending (_ : Unit) : Bool :=
  false

def VirtualFIQPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def VirtualIRQPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def InterruptPending (_ : Unit) : SailM Bool := do
  let fiq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let irq_pending ← (( do (undefined_bool ()) ) : SailM Bool )
  let pending_virtual_interrupt : Bool := false
  let irq_pending ← (( do
    let (__tup_0, _) ← do (IRQPending ())
    (pure __tup_0) ) : SailM Bool )
  let fiq_pending : Bool :=
    let (__tup_0, _) := (FIQPending ())
    __tup_0
  let pending_physical_interrupt : Bool := ((irq_pending || fiq_pending) || (IsPhysicalSErrorPending ()))
  let pending_virtual_interrupt ← (( do
    (if ((←((EL2Enabled ()) <&&> (do
         (pure ((← readReg PSTATE).EL == EL0)) <||> (do
           (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do
         (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))))) : Bool)
    then
      (do let virq_pending ← (( do (pure ((_get_HCR_EL2_Type_IMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (VirtualIRQPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VI (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          let vfiq_pending ← (( do (pure ((_get_HCR_EL2_Type_FMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (VirtualFIQPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VF (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          let vsei_pending ← (( do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)) <&&> (do (IsVirtualSErrorPending ()) <||> (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1)))) ) : SailM Bool )
          (pure ((vsei_pending || virq_pending) || vfiq_pending)))
    else (do (pure pending_virtual_interrupt))) ) : SailM Bool )
  (pure (pending_physical_interrupt || pending_virtual_interrupt))

/-- Type quantifiers: localtimeout : Int -/
def WaitForInterrupt (localtimeout : Int) : SailM Unit := do
  (if ((! (←((HaveFeatWFxT ()) <&&> (do
         (LocalTimeoutEvent localtimeout))))) : Bool)
  then
    (do writeReg IsWFIsleep true
        writeReg _DormantCtlReg (Sail.BitVec.updateSubrange (← readReg _DormantCtlReg) 0 0 1#1)
        (pure (EnterLowPowerState ())))
  else (do (pure ())))

/-- Type quantifiers: localtimeout : Int -/
def Hint_WFI (localtimeout : Int) (wfxtype : WFxType) : SailM Unit := do
  (if ((←((HaveTME ()) <&&> (do
       (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
  then (do (FailTransaction TMFailure_ERR false))
  else (do (pure ())))
  (if ((←((InterruptPending ()) <||> (do
       (HaveFeatWFxT ()) <&&> (do
         (LocalTimeoutEvent localtimeout))))) : Bool)
  then (do (EndOfInstruction ()))
  else
    (do (if (((← readReg PSTATE).EL == EL0) : Bool)
        then (do (AArch64_CheckForWFxTrap EL1 wfxtype))
        else (do (pure ())))
        (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
             (EL2Enabled ())) <&&> (do
             (pure (! (← (IsInHost ()))))))) : Bool)
        then (do (AArch64_CheckForWFxTrap EL2 wfxtype))
        else (do (pure ())))
        (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((← readReg PSTATE).EL != EL3))))) : Bool)
        then (do (AArch64_CheckForWFxTrap EL3 wfxtype))
        else (do (pure ())))
        (WaitForInterrupt localtimeout)))

def SendEventLocal (_ : Unit) : SailM Unit := do
  writeReg EventRegister 1#1

def EffectiveEA (_ : Unit) : SailM (BitVec 1) := do
  (if ((←((Halted ()) <&&> (do
       (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 0#1))))) : Bool)
  then (do (pure 0#1))
  else
    (do (if ((← (HaveAArch64 ())) : Bool)
        then (do (pure (_get_SCR_EL3_Type_EA (← readReg SCR_EL3))))
        else (do (pure (_get_SCR_Type_EA (← readReg SCR)))))))

def EL3SDDUndefPriority (_ : Unit) : SailM Bool := do
  (Halted ()) <&&> (do
    (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
    (__IMPDEF_boolean "EL3 trap priority when SDD == '1'"))

def EL3SDDUndef (_ : Unit) : SailM Bool := do
  (Halted ()) <&&> (do
    (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1)))

def undefined_GCSCRE0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_GCSCRE0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def GCSPCRSelected (el : (BitVec 2)) : SailM Bool := SailME.run do
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then (do SailME.throw (← do (pure ((_get_GCSCRE0_EL1_Type_PCRSEL (← readReg GCSCRE0_EL1)) == 1#1))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do SailME.throw (← do (pure ((_get_GCSCR_EL1_Type_PCRSEL (← readReg GCSCR_EL1)) == 1#1))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do SailME.throw (← do (pure ((_get_GCSCR_EL2_Type_PCRSEL (← readReg GCSCR_EL2)) == 1#1))))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do SailME.throw (← do (pure ((_get_GCSCR_EL3_Type_PCRSEL (← readReg GCSCR_EL3)) == 1#1))))
                    else (do (pure ())))))))))
  (Unreachable ())
  (pure true)

def undefined_HCRX_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HCRX_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HCRX_EL2_Type_FnXS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_HCRX_EL2_Type_TALLINT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_HCRX_EL2_Type_VFNMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_HCRX_EL2_Type_VINMI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def HaveFeatHCX (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HCX)

def IsHCRXEL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatHCX ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_HXEn (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def GCSEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure ((HaveEL EL3) && (el != EL3))) <&&> (do
             (pure ((_get_SCR_EL3_Type_GCSEn (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((pure ((el == EL0) || (el == EL1))) <&&> (do
                   (EL2Enabled ())) <&&> (do
                   (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <||> (do
                     (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1)))) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_GCSEn (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (GCSPCRSelected el)))))))

def AArch64_ChkFeat (feat_select : (BitVec 64)) : SailM (BitVec 64) := do
  let feat_en : (BitVec 64) := (Zeros (n := 64))
  let feat_en ←
    (pure (BitVec.update feat_en 0
        (Bit
          (← do
            (if ((←((HaveGCS ()) <&&> (do
                 (GCSEnabled (← readReg PSTATE).EL)))) : Bool)
            then (do (pure 1#1))
            else (do (pure 0#1)))))))
  (pure (feat_select &&& (Complement.complement feat_en)))

def TAG_GRANULE : Nat := 16

def BigEndian (acctype : AccessType) : SailM Bool := do
  let bigend ← (( do (undefined_bool ()) ) : SailM Bool )
  (if (((← (HaveNV2Ext ())) && (BEq.beq acctype AccessType_NV2)) : Bool)
  then (do (pure ((_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)) == 1#1)))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (pure ((← readReg PSTATE).E != 0#1)))
        else
          (do (if (((← readReg PSTATE).EL == EL0) : Bool)
              then (do (pure ((_get_SCTLRType_E0E (← (SCTLR_read__1 ()))) != 0#1)))
              else (do (pure ((_get_SCTLRType_EE (← (SCTLR_read__1 ()))) != 0#1))))))))

def IsDataAccess (acctype : AccessType) : Bool :=
  (! ((BEq.beq acctype AccessType_IFETCH) || ((BEq.beq acctype AccessType_TTW) || ((BEq.beq acctype AccessType_DC) || ((BEq.beq acctype AccessType_IC) || (BEq.beq acctype AccessType_AT))))))

def EffectiveTCMA (address : (BitVec 64)) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let tcma ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:11075.21-11075.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:11077.43-11077.44"
  let questionMark := regime
  (if ((questionMark == EL1) : Bool)
  then
    (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
        then (do (pure (_get_TCR_EL1_Type_TCMA1 (← readReg TCR_EL1))))
        else (do (pure (_get_TCR_EL1_Type_TCMA0 (← readReg TCR_EL1))))))
  else
    (do (if ((questionMark == EL2) : Bool)
        then
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (ELIsInHost el)))) : Bool)
              then
                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                    then (do (pure (_get_TCR_EL2_Type_TCMA1 (← readReg TCR_EL2))))
                    else (do (pure (_get_TCR_EL2_Type_TCMA0 (← readReg TCR_EL2))))))
              else (do (pure (_get_TCR_EL2_Type_TCMA (← readReg TCR_EL2))))))
        else
          (do (if ((questionMark == EL3) : Bool)
              then (do (pure (_get_TCR_EL3_Type_TCMA (← readReg TCR_EL3))))
              else (do (pure tcma)))))))

def HaveMTE4Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE4)

/-- Type quantifiers: k_is_instr : Bool -/
def EffectiveMTX (address : (BitVec 64)) (is_instr : Bool) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let mtx ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:11109.21-11109.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:11111.43-11111.44"
  (if (((! (← (HaveMTE4Ext ()))) || is_instr) : Bool)
  then (do (pure 0#1))
  else
    (do let questionMark := regime
        (if ((questionMark == EL1) : Bool)
        then
          (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
              then (do (pure (_get_TCR_EL1_Type_MTX1 (← readReg TCR_EL1))))
              else (do (pure (_get_TCR_EL1_Type_MTX0 (← readReg TCR_EL1))))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((←((HaveVirtHostExt ()) <&&> (do
                         (ELIsInHost el)))) : Bool)
                    then
                      (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                          then (do (pure (_get_TCR_EL2_Type_MTX1 (← readReg TCR_EL2))))
                          else (do (pure (_get_TCR_EL2_Type_MTX0 (← readReg TCR_EL2))))))
                    else (do (pure (_get_TCR_EL2_Type_MTX (← readReg TCR_EL2))))))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure (_get_TCR_EL3_Type_MTX (← readReg TCR_EL3))))
                    else (do (pure mtx)))))))))

def undefined_MPAM2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAM2_EL2_Type_ALTSP_EL2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_MPAM2_EL2_Type_ALTSP_HFC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_MPAM3_EL3_Type_ALTSP_HFC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_MPAM2_EL2_Type_EnMPAMSM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 50 50)

def _get_MPAM2_EL2_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _update_MPAM1_EL1_Type_MPAMEN (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 63 63 x)

def _update_MPAM3_EL3_Type_MPAMEN (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 63 63 x)

def _get_MPAM1_EL1_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_MPAM3_EL3_Type_MPAMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 63 63)

def _get_MPAM2_EL2_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM0_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM1_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM3_EL3_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAMSM_EL1_Type_PARTID_D (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 31 16)

def _get_MPAM2_EL2_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM0_EL1_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)


end ArmASL.Functions
