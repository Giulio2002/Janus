import ArmASL.Part08

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def AArch64_PhysicalAddressSize (d128 : (BitVec 1)) (encoded_ps : (BitVec 3)) (tgx : TGx) : SailM Int := do
  let ps : Int := 32
  let max_ps ← (( do (undefined_int ()) ) : SailM Int )
  let ps : Int :=
    match encoded_ps with
    | 0b000 => 32
    | 0b001 => 36
    | 0b010 => 40
    | 0b011 => 42
    | 0b100 => 44
    | 0b101 => 48
    | 0b110 => 52
    | _ => 56
  let ps := ps
  let max_ps ← (( do
    (if (((! (← (Have56BitPAExt ()))) || (d128 == 0#1)) : Bool)
    then
      (do (if ((←((pure (bne tgx TGx_64KB)) <&&> (do
               (pure (! (← (Have52BitIPAAndPASpaceExt ()))))))) : Bool)
          then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
          else
            (do (if ((! (← (Have52BitPAExt ()))) : Bool)
                then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
                else (do (pure (Min.min 52 (← (AArch64_PAMax ())))))))))
    else (do (AArch64_PAMax ()))) ) : SailM Int )
  let max_ps := max_ps
  (pure (Min.min ps max_ps))

def AArch64_OAOutOfRange (address : (BitVec 56)) (d128 : (BitVec 1)) (ps : (BitVec 3)) (tgx : TGx) : SailM Bool := do
  let oasize ← (( do (AArch64_PhysicalAddressSize d128 ps tgx) ) : SailM Int )
  (if ((oasize <b 56) : Bool)
  then (do (pure (! (is_zero_subrange address 55 oasize))))
  else (do (pure false)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_S1AMECFault (walkparams : S1TTWParams) (paspace : PASpace) (regime : Regime) (descriptor : (BitVec k_N)) : SailM Bool := do
  sail_assert (((Sail.BitVec.length descriptor) == 64) || ((Sail.BitVec.length descriptor) == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25140.31-25140.32"
  let descriptor_amec ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (103 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25142.35-25142.36"
          (pure ((BitVec.access descriptor 103) : BitVec 1)))
    else (do (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
  (pure (((((walkparams.emec +++ walkparams.amec) == 0b10#2) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) && (BEq.beq paspace PAS_Realm)) && (descriptor_amec == 1#1)))

def AArch64_S1EPD (regime : Regime) (va : (BitVec 64)) : SailM (BitVec 1) := do
  sail_assert (HasUnprivileged regime) "sail-arm/arm-v9.4-a/src/v8_base.sail:25151.34-25151.35"
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL20 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (_get_TCR_EL2_Type_EPD0 (← readReg TCR_EL2))))
      else (do (pure (_get_TCR_EL2_Type_EPD1 (← readReg TCR_EL2))))))
  | .Regime_EL10 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (_get_TCR_EL1_Type_EPD0 (← readReg TCR_EL1))))
      else (do (pure (_get_TCR_EL1_Type_EPD1 (← readReg TCR_EL1))))))
  | _ => (do (undefined_bitvector 1))

def AArch64_S1StartLevel (walkparams : S1TTWParams) : Int :=
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let s1startlevel : Int := (FINAL_LEVEL -i (fdiv_int ((iasize -i 1) -i granulebits) stride))
  let s1startlevel : Int :=
    if ((walkparams.d128 == 1#1) : Bool)
    then (s1startlevel +i (BitVec.toNat walkparams.skl))
    else s1startlevel
  let s1startlevel := s1startlevel
  s1startlevel

def AArch64_S1TTBR (regime : Regime) (va : (BitVec 64)) : SailM (BitVec 128) := do
  let varange : VARange := (AArch64_GetVARange va)
  match regime with
  | .Regime_EL3 => (pure (Sail.BitVec.zeroExtend (← readReg TTBR0_EL3) 128))
  | .Regime_EL2 => (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL2_read ())) 128))
  | .Regime_EL20 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL2_read ())) 128)))
      else (do (pure (Sail.BitVec.zeroExtend (← readReg TTBR1_EL2) 128)))))
  | .Regime_EL10 =>
    (do
      (if ((BEq.beq varange VARange_LOWER) : Bool)
      then (do (pure (Sail.BitVec.zeroExtend (← (TTBR0_EL1_read ())) 128)))
      else (do (pure (Sail.BitVec.zeroExtend (← (TTBR1_EL1_read ())) 128)))))
  | _ => (do (undefined_bitvector 128))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1TTBaseAddress (walkparams : S1TTWParams) (regime : Regime) (ttbr : (BitVec k_N)) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let startlevel := (AArch64_S1StartLevel walkparams)
  let levels := (FINAL_LEVEL -i startlevel)
  let tsize : Int := ((iasize -i ((levels *i stride) +i granulebits)) +i descsizelog2)
  let (tablebase, tsize) ← (( do
    (if (((← (Have56BitPAExt ())) && (walkparams.d128 == 1#1)) : Bool)
    then
      (do let tsize : Int := (Max.max tsize 5)
          let tablebase ← (( do
            (if ((BEq.beq regime Regime_EL3) : Bool)
            then
              (do sail_assert (55 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25229.38-25229.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 (Sail.BitVec.extractLsb ttbr 55 5))))
            else
              (do sail_assert (87 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25232.38-25232.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 ((Sail.BitVec.extractLsb ttbr 87 80) +++ (Sail.BitVec.extractLsb ttbr 47 5)))))) ) : SailM (BitVec 56) )
          (pure (tablebase, tsize)))
    else
      (do let (tablebase, tsize) ← (( do
            (if (((((← (Have52BitPAExt ())) && (BEq.beq walkparams.tgx TGx_64KB)) && (walkparams.ps == 0b110#3)) || (walkparams.ds == 1#1)) : Bool)
            then
              (do let tsize : Int := (Max.max tsize 6)
                  sail_assert (5 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25237.33-25237.34"
                  sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25238.34-25238.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 51 6 ((Sail.BitVec.extractLsb ttbr 5 2) +++ (Sail.BitVec.extractLsb ttbr 47 6)))
                  (pure (tablebase, tsize)))
            else
              (do sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25241.34-25241.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 47 1 (Sail.BitVec.extractLsb ttbr 47 1))
                  (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
          (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
  let tsize := tsize
  (pure (Align_bits tablebase (_shl_int_general 1 tsize)))

def AArch64_S1InitialTTWState (walkparams : S1TTWParams) (va : (BitVec 64)) (regime : Regime) (ss : SecurityState) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let permissions ← (( do (undefined_Permissions ()) ) : SailM Permissions )
  let ttbr ← (( do (AArch64_S1TTBR regime va) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    match ss with
    | .SS_Secure => { tablebase with paspace := PAS_Secure }
    | .SS_NonSecure => { tablebase with paspace := PAS_NonSecure }
    | .SS_Root => { tablebase with paspace := PAS_Root }
    | .SS_Realm => { tablebase with paspace := PAS_Realm }
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S1TTBaseAddress walkparams regime ttbr)) })
  let permissions : Permissions := { permissions with ap_table := 0b00#2 }
  let permissions : Permissions :=
    if ((HasUnprivileged regime) : Bool)
    then
      (let permissions : Permissions := { permissions with uxn_table := 0#1 }
      { permissions with pxn_table := 0#1 })
    else { permissions with xn_table := 0#1 }
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate : TTWState := { walkstate with level := (AArch64_S1StartLevel walkparams) }
  let walkstate : TTWState := { walkstate with istable := true }
  let walkstate : TTWState :=
    { walkstate with nG := if ((HasUnprivileged regime) : Bool)
      then 1#1
      else 0#1 }
  let walkstate ← (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })
  let walkstate : TTWState := { walkstate with permissions := permissions }
  let walkstate : TTWState :=
    if (((walkparams.d128 == 1#1) || (walkparams.pnch == 1#1)) : Bool)
    then { walkstate with s1assured := true }
    else { walkstate with s1assured := false }
  (pure { walkstate with disch := walkparams.disch })

/-- Type quantifiers: k_N : Nat, level : Int, 52 < k_N -/
def AArch64_ContiguousBit (tgx : TGx) (d128 : (BitVec 1)) (level : Int) (descriptor : (BitVec k_N)) : SailM (BitVec 1) := do
  (if ((d128 == 1#1) : Bool)
  then
    (do (if ((((BEq.beq tgx TGx_64KB) && (level == 1)) || ((BEq.beq tgx TGx_4KB) && (level == 0))) : Bool)
        then (do (pure 0#1))
        else
          (do sail_assert (111 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25301.39-25301.40"
              (pure ((BitVec.access descriptor 111) : BitVec 1)))))
  else
    (do (if (((BEq.beq tgx TGx_64KB) && (level == 1)) : Bool)
        then (do (pure 0#1))
        else
          (do (if (((BEq.beq tgx TGx_16KB) && (level == 1)) : Bool)
              then (do (pure 0#1))
              else
                (do (if (((BEq.beq tgx TGx_4KB) && (level == 0)) : Bool)
                    then (do (pure 0#1))
                    else (do (pure ((BitVec.access descriptor 52) : BitVec 1))))))))))

/-- Type quantifiers: k_N : Nat, level : Int, k_N ≥ 0 -/
def AArch64_LeafBase (descriptor : (BitVec k_N)) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (level : Int) : SailM (BitVec 56) := do
  let leafbase : (BitVec 56) := (Zeros (n := 56))
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let leafsize := (granulebits +i (stride *i (FINAL_LEVEL -i level)))
  sail_assert ((0 ≤b leafsize) && ((leafsize ≤b 47) && (47 <b (Sail.BitVec.length descriptor)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25326.67-25326.68"
  let leafbase : (BitVec 56) := (Sail.BitVec.updateSubrange leafbase 47 0 ((Sail.BitVec.extractLsb descriptor 47 leafsize) +++ (Zeros (n := leafsize))))
  (if (((← (Have56BitPAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25329.34-25329.35"
        (pure (Sail.BitVec.updateSubrange leafbase 55 48 (Sail.BitVec.extractLsb descriptor 55 48))))
  else
    (do (if (((← (Have52BitPAExt ())) && (BEq.beq tgx TGx_64KB)) : Bool)
        then (do (pure (Sail.BitVec.updateSubrange leafbase 51 48 (Sail.BitVec.extractLsb descriptor 15 12))))
        else
          (do (if ((ds == 1#1) : Bool)
              then
                (do sail_assert (49 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25336.34-25336.35"
                    (pure (Sail.BitVec.updateSubrange leafbase 51 48 ((Sail.BitVec.extractLsb descriptor 9 8) +++ (Sail.BitVec.extractLsb descriptor 49 48)))))
              else (do (pure leafbase)))))))

/-- Type quantifiers: index : Int -/
def AArch64_MAIRAttr (index : Int) (mair2 : (BitVec 64)) (mair : (BitVec 64)) : SailM (BitVec 8) := do
  let bit_index : Int := (8 *i index)
  sail_assert (←((pure (index <b 8)) <||> (do
    (pure ((← (HaveAIEExt ())) && (index <b 16)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25347.48-25347.49"
  (if ((index >b 7) : Bool)
  then
    (do let bit_index := (bit_index -i 64)
        sail_assert ((0 ≤b bit_index) && ((bit_index ≤b (bit_index +i 7)) && ((bit_index +i 7) <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25350.97-25350.98"
        (pure (Sail.BitVec.extractLsb mair2 (bit_index +i 7) bit_index)))
  else
    (do let bit_index := bit_index
        sail_assert ((0 ≤b bit_index) && ((bit_index ≤b (bit_index +i 7)) && ((bit_index +i 7) <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25354.97-25354.98"
        (pure (Sail.BitVec.extractLsb mair (bit_index +i 7) bit_index))))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1ApplyOutputPerms (permissions_in : Permissions) (descriptor : (BitVec k_N)) (regime : Regime) (walkparams : S1TTWParams) : SailM Permissions := do
  let bit_index ← (( do (undefined_int ()) ) : SailM Int )
  let permissions : Permissions := permissions_in
  let pi_index ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let permissions ← (( do
    (if ((walkparams.pie == 1#1) : Bool)
    then
      (do let pi_index ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25368.39-25368.40"
                  (pure (Sail.BitVec.extractLsb descriptor 118 115)))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25371.38-25371.39"
                  (pure (((Sail.BitVec.extractLsb descriptor 54 53) +++ ((BitVec.access descriptor 51) : BitVec 1)) +++ ((BitVec.access descriptor 6) : BitVec 1))))) ) : SailM (BitVec 4) )
          let bit_index := (4 *i (BitVec.toNat pi_index))
          let permissions : Permissions := { permissions with ppi := (Sail.BitVec.extractLsb walkparams.pir (bit_index +i 3) bit_index) }
          let permissions : Permissions := { permissions with upi := (Sail.BitVec.extractLsb walkparams.pire0 (bit_index +i 3) bit_index) }
          sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25377.33-25377.34"
          (pure { permissions with ndirty := ((BitVec.access descriptor 7) : BitVec 1) }))
    else
      (do let permissions ← (( do
            (if (((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                   (EL2Enabled ())))) && (walkparams.nv1 == 1#1)) : Bool)
            then
              (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25381.37-25381.38"
                  let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (((BitVec.access descriptor 7) : BitVec 1) +++ 0#1)) }
                  sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25383.38-25383.39"
                  (pure { permissions with pxn := ((BitVec.access descriptor 54) : BitVec 1) }))
            else
              (do (if ((HasUnprivileged regime) : Bool)
                  then
                    (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25386.37-25386.38"
                        let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (Sail.BitVec.extractLsb descriptor 7 6)) }
                        sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25388.38-25388.39"
                        let permissions : Permissions := { permissions with uxn := ((BitVec.access descriptor 54) : BitVec 1) }
                        (pure { permissions with pxn := ((BitVec.access descriptor 53) : BitVec 1) }))
                  else
                    (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25392.37-25392.38"
                        let permissions : Permissions := { permissions with ap := (Sail.BitVec.updateSubrange permissions.ap 2 1 (((BitVec.access descriptor 7) : BitVec 1) +++ 1#1)) }
                        sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25394.38-25394.39"
                        (pure { permissions with xn := ((BitVec.access descriptor 54) : BitVec 1) }))))) ) : SailM Permissions )
          sail_assert (51 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25397.34-25397.35"
          (if ((((walkparams.ha == 1#1) && (walkparams.hd == 1#1)) && (((BitVec.access descriptor 51) : BitVec 1) == 1#1)) : Bool)
          then (do (pure { permissions with ap := (BitVec.update permissions.ap 2 (Bit 0#1)) }))
          else (do (pure permissions))))) ) : SailM Permissions )
  let poe ← (( do (AArch64_S1POEnabled regime) ) : SailM Bool )
  let e0poe ← (( do (pure (HasUnprivileged regime)) <&&> (do (AArch64_S1E0POEnabled regime walkparams.nv1)) ) : SailM Bool )
  (if ((poe || e0poe) : Bool)
  then
    (do (if ((walkparams.d128 == 1#1) : Bool)
        then
          (do sail_assert (124 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25407.39-25407.40"
              (pure { permissions with po_index := (Sail.BitVec.extractLsb descriptor 124 121) }))
        else
          (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25410.38-25410.39"
              (pure { permissions with po_index := (0#1 +++ (Sail.BitVec.extractLsb descriptor 62 60)) }))))
  else (do (pure permissions)))

/-- Type quantifiers: k_N : Nat, k_s2fs1mro : Bool, k_N ≥ 0 -/
def AArch64_S1NextWalkStateLeaf (currentstate : TTWState) (s2fs1mro : Bool) (regime : Regime) (ss : SecurityState) (walkparams : S1TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let baseaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let baseaddress ← (pure { baseaddress with address := (← do (AArch64_LeafBase descriptor walkparams.d128 walkparams.ds walkparams.tgx currentstate.level)) })
  let baseaddress ← (( do
    (if ((BEq.beq currentstate.baseaddress.paspace PAS_Secure) : Bool)
    then
      (do let ns ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25426.39-25426.40"
                  (pure ((BitVec.access descriptor 127) : BitVec 1)))
            else
              (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25429.37-25429.38"
                  (pure ((BitVec.access descriptor 5) : BitVec 1)))) ) : SailM (BitVec 1) )
          (pure { baseaddress with paspace := if ((ns == 0#1) : Bool)
              then PAS_Secure
              else PAS_NonSecure }))
    else
      (do (if ((BEq.beq currentstate.baseaddress.paspace PAS_Root) : Bool)
          then
            (do let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                let (ns, nse) ← (( do
                  let split_vec ← do
                    (if ((walkparams.d128 == 1#1) : Bool)
                    then
                      (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25437.38-25437.39"
                          sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25438.39-25438.40"
                          (pure (((BitVec.access descriptor 11) : BitVec 1) +++ ((BitVec.access descriptor 127) : BitVec 1))))
                    else
                      (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25441.38-25441.39"
                          (pure (((BitVec.access descriptor 11) : BitVec 1) +++ ((BitVec.access descriptor 5) : BitVec 1)))))
                  let nse : (BitVec 1) := (Sail.BitVec.extractLsb split_vec 1 1)
                  let ns : (BitVec 1) := (Sail.BitVec.extractLsb split_vec 0 0)
                  (pure (ns, nse)) ) : SailM ((BitVec 1) × (BitVec 1)) )
                let baseaddress ← (pure { baseaddress with paspace := (← do (DecodePASpace nse ns)) })
                (if ((←((pure (BEq.beq baseaddress.paspace PAS_Secure)) <&&> (do
                     (pure (! (← (HaveSecureState ()))))))) : Bool)
                then (do (pure { baseaddress with paspace := PAS_NonSecure }))
                else (do (pure baseaddress))))
          else
            (do (if (((BEq.beq currentstate.baseaddress.paspace PAS_Realm) && ((BEq.beq regime Regime_EL2) || (BEq.beq regime Regime_EL20))) : Bool)
                then
                  (do let ns ← (( do
                        (if ((walkparams.d128 == 1#1) : Bool)
                        then
                          (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25451.39-25451.40"
                              (pure ((BitVec.access descriptor 127) : BitVec 1)))
                        else
                          (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25454.37-25454.38"
                              (pure ((BitVec.access descriptor 5) : BitVec 1)))) ) : SailM (BitVec 1) )
                      (pure { baseaddress with paspace := if ((ns == 0#1) : Bool)
                          then PAS_Realm
                          else PAS_NonSecure }))
                else
                  (do (if ((BEq.beq currentstate.baseaddress.paspace PAS_Realm) : Bool)
                      then (do (pure { baseaddress with paspace := PAS_Realm }))
                      else (do (pure { baseaddress with paspace := PAS_NonSecure }))))))))) ) : SailM FullAddress )
  let nextstate : TTWState := { nextstate with istable := false }
  let nextstate : TTWState := { nextstate with level := currentstate.level }
  let nextstate : TTWState := { nextstate with baseaddress := baseaddress }
  let attrindx ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let attrindx ← (( do
    (if ((walkparams.aie == 1#1) : Bool)
    then
      (do (if ((walkparams.d128 == 1#1) : Bool)
          then
            (do sail_assert (5 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25469.37-25469.38"
                (pure (Sail.BitVec.extractLsb descriptor 5 2)))
          else
            (do sail_assert (59 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25472.38-25472.39"
                (pure (((BitVec.access descriptor 59) : BitVec 1) +++ (Sail.BitVec.extractLsb descriptor 4 2))))))
    else
      (do sail_assert (4 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25476.33-25476.34"
          (pure (0#1 +++ (Sail.BitVec.extractLsb descriptor 4 2))))) ) : SailM (BitVec 4) )
  let sh ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let sh ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25481.33-25481.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))
    else
      (do (if ((walkparams.ds == 1#1) : Bool)
          then (do (pure walkparams.sh))
          else
            (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25486.33-25486.34"
                (pure (Sail.BitVec.extractLsb descriptor 9 8)))))) ) : SailM (BitVec 2) )
  let attr ← (( do (AArch64_MAIRAttr (BitVec.toNat attrindx) walkparams.mair2 walkparams.mair) ) : SailM (BitVec 8) )
  let s1aarch64 : Bool := true
  let nextstate ← (pure { nextstate with memattrs := (← do (S1DecodeMemAttrs attr sh s1aarch64 walkparams)) })
  let nextstate ← (pure { nextstate with permissions := (← do (AArch64_S1ApplyOutputPerms currentstate.permissions descriptor regime walkparams)) })
  let protectedbit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let protectedbit ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25495.35-25495.36"
          (pure ((BitVec.access descriptor 114) : BitVec 1)))
    else
      (do (if ((walkparams.pnch == 1#1) : Bool)
          then
            (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25499.38-25499.39"
                (pure ((BitVec.access descriptor 52) : BitVec 1)))
          else (do (pure 0#1))))) ) : SailM (BitVec 1) )
  let nextstate : TTWState :=
    if (((currentstate.s1assured && s2fs1mro) && (protectedbit == 1#1)) : Bool)
    then { nextstate with s1assured := true }
    else { nextstate with s1assured := false }
  let nextstate ← (( do
    (if (((walkparams.pnch == 1#1) || (currentstate.disch == 1#1)) : Bool)
    then (do (pure { nextstate with contiguous := 0#1 }))
    else
      (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25511.34-25511.35"
          (pure { nextstate with contiguous := (← do (AArch64_ContiguousBit walkparams.tgx walkparams.d128 currentstate.level descriptor)) }))) ) : SailM TTWState )
  let nextstate ← (( do
    (if ((! (HasUnprivileged regime)) : Bool)
    then (do (pure { nextstate with nG := 0#1 }))
    else
      (do (if (((BEq.beq ss SS_Secure) && (BEq.beq currentstate.baseaddress.paspace PAS_NonSecure)) : Bool)
          then (do (pure { nextstate with nG := 1#1 }))
          else
            (do sail_assert (11 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25519.34-25519.35"
                (pure { nextstate with nG := ((BitVec.access descriptor 11) : BitVec 1) }))))) ) : SailM TTWState )
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do sail_assert (113 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25523.35-25523.36"
        (pure { nextstate with guardedpage := ((BitVec.access descriptor 113) : BitVec 1) }))
  else
    (do sail_assert (50 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25526.34-25526.35"
        (pure { nextstate with guardedpage := ((BitVec.access descriptor 50) : BitVec 1) })))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_NextTableBase (descriptor : (BitVec k_N)) (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let tablebase ← (( do
    match tgx with
    | .TGx_4KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25539.36-25539.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 12 (Sail.BitVec.extractLsb descriptor 47 12))))
    | .TGx_16KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25543.36-25543.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 14 (Sail.BitVec.extractLsb descriptor 47 14))))
    | .TGx_64KB =>
      (do
        sail_assert (47 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25547.36-25547.37"
        (pure (Sail.BitVec.updateSubrange tablebase 47 16 (Sail.BitVec.extractLsb descriptor 47 16)))) ) : SailM (BitVec 56) )
  (if (((← (Have56BitPAExt ())) && (d128 == 1#1)) : Bool)
  then
    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25552.34-25552.35"
        (pure (Sail.BitVec.updateSubrange tablebase 55 48 (Sail.BitVec.extractLsb descriptor 55 48))))
  else
    (do (if (((← (Have52BitPAExt ())) && (BEq.beq tgx TGx_64KB)) : Bool)
        then
          (do sail_assert (15 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25557.34-25557.35"
              (pure (Sail.BitVec.updateSubrange tablebase 51 48 (Sail.BitVec.extractLsb descriptor 15 12))))
        else
          (do (if ((ds == 1#1) : Bool)
              then
                (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25562.33-25562.34"
                    sail_assert (49 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25563.34-25563.35"
                    (pure (Sail.BitVec.updateSubrange tablebase 51 48 ((Sail.BitVec.extractLsb descriptor 9 8) +++ (Sail.BitVec.extractLsb descriptor 49 48)))))
              else (do (pure tablebase)))))))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S1ApplyTablePerms (permissions_in : Permissions) (descriptor : (BitVec k_N)) (regime : Regime) (walkparams : S1TTWParams) : SailM Permissions := do
  let permissions : Permissions := permissions_in
  let ap_table ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let pxn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let uxn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let xn_table ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  (if (((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
         (EL2Enabled ())))) && (walkparams.nv1 == 1#1)) : Bool)
  then
    (do let (ap_table, pxn_table) ← (( do
          (if ((walkparams.d128 == 1#1) : Bool)
          then
            (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25581.39-25581.40"
                let ap_table : (BitVec 2) := (((BitVec.access descriptor 126) : BitVec 1) +++ 0#1)
                let pxn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                (pure (ap_table, pxn_table)))
          else
            (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25585.38-25585.39"
                let ap_table : (BitVec 2) := (((BitVec.access descriptor 62) : BitVec 1) +++ 0#1)
                let pxn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                (pure (ap_table, pxn_table)))) ) : SailM ((BitVec 2) × (BitVec 1)) )
        let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
        (pure { permissions with pxn_table := (permissions.pxn_table ||| pxn_table) }))
  else
    (do (if ((HasUnprivileged regime) : Bool)
        then
          (do let (ap_table, pxn_table, uxn_table) ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25593.39-25593.40"
                      let ap_table : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 126 125)
                      let uxn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                      let pxn_table : (BitVec 1) := ((BitVec.access descriptor 123) : BitVec 1)
                      (pure (ap_table, pxn_table, uxn_table)))
                else
                  (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25598.38-25598.39"
                      let ap_table : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 62 61)
                      let uxn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                      let pxn_table : (BitVec 1) := ((BitVec.access descriptor 59) : BitVec 1)
                      (pure (ap_table, pxn_table, uxn_table)))) ) : SailM ((BitVec 2) × (BitVec 1) × (BitVec 1)) )
              let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
              let permissions : Permissions := { permissions with uxn_table := (permissions.uxn_table ||| uxn_table) }
              (pure { permissions with pxn_table := (permissions.pxn_table ||| pxn_table) }))
        else
          (do let (ap_table, xn_table) ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (126 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25608.39-25608.40"
                      let ap_table : (BitVec 2) := (((BitVec.access descriptor 126) : BitVec 1) +++ 0#1)
                      let xn_table : (BitVec 1) := ((BitVec.access descriptor 124) : BitVec 1)
                      (pure (ap_table, xn_table)))
                else
                  (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25612.38-25612.39"
                      let ap_table : (BitVec 2) := (((BitVec.access descriptor 62) : BitVec 1) +++ 0#1)
                      let xn_table : (BitVec 1) := ((BitVec.access descriptor 60) : BitVec 1)
                      (pure (ap_table, xn_table)))) ) : SailM ((BitVec 2) × (BitVec 1)) )
              let permissions : Permissions := { permissions with ap_table := (permissions.ap_table ||| ap_table) }
              (pure { permissions with xn_table := (permissions.xn_table ||| xn_table) })))))

/-- Type quantifiers: k_N : Nat, k_s2fs1mro : Bool, k_N ≥ 0 -/
def AArch64_S1NextWalkStateTable (currentstate : TTWState) (s2fs1mro : Bool) (regime : Regime) (walkparams : S1TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let skl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let tablebase ← (pure { tablebase with address := (← do (AArch64_NextTableBase descriptor walkparams.d128 walkparams.ds walkparams.tgx)) })
  let tablebase ← (( do
    (if ((BEq.beq currentstate.baseaddress.paspace PAS_Secure) : Bool)
    then
      (do let nstable ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25632.39-25632.40"
                  (pure ((BitVec.access descriptor 127) : BitVec 1)))
            else
              (do sail_assert (63 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25635.38-25635.39"
                  (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
          (pure { tablebase with paspace := if ((nstable == 0#1) : Bool)
              then PAS_Secure
              else PAS_NonSecure }))
    else (do (pure { tablebase with paspace := currentstate.baseaddress.paspace }))) ) : SailM FullAddress )
  let nextstate : TTWState := { nextstate with istable := true }
  let nextstate : TTWState := { nextstate with nG := currentstate.nG }
  let nextstate ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (110 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25645.35-25645.36"
          let skl : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 110 109)
          (pure { nextstate with level := ((currentstate.level +i (BitVec.toNat skl)) +i 1) }))
    else (do (pure { nextstate with level := (currentstate.level +i 1) }))) ) : SailM TTWState )
  let nextstate : TTWState := { nextstate with baseaddress := tablebase }
  let nextstate : TTWState := { nextstate with memattrs := currentstate.memattrs }
  let nextstate ← (( do
    (if (((walkparams.hpd == 0#1) && (walkparams.pie == 0#1)) : Bool)
    then (do (pure { nextstate with permissions := (← do (AArch64_S1ApplyTablePerms currentstate.permissions descriptor regime walkparams)) }))
    else (do (pure { nextstate with permissions := currentstate.permissions }))) ) : SailM TTWState )
  let protectedbit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let protectedbit ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25660.35-25660.36"
          (pure ((BitVec.access descriptor 114) : BitVec 1)))
    else
      (do (if ((walkparams.pnch == 1#1) : Bool)
          then
            (do sail_assert (52 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25664.38-25664.39"
                (pure ((BitVec.access descriptor 52) : BitVec 1)))
          else (do (pure 0#1))))) ) : SailM (BitVec 1) )
  let nextstate : TTWState :=
    if (((currentstate.s1assured && s2fs1mro) && (protectedbit == 1#1)) : Bool)
    then { nextstate with s1assured := true }
    else { nextstate with s1assured := false }
  (pure { nextstate with disch := (← do
      (if ((walkparams.d128 == 1#1) : Bool)
      then
        (do sail_assert (112 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25674.35-25674.36"
            (pure ((BitVec.access descriptor 112) : BitVec 1)))
      else (do (pure 0#1)))) })

/-- Type quantifiers: level : Int -/
def AArch64_S1SLTTEntryAddress (level : Int) (walkparams : S1TTWParams) (ia : (BitVec 64)) (tablebase : FullAddress) : SailM FullAddress := do
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i level)
  let lsb := ((levels *i stride) +i granulebits)
  let msb := (iasize -i 1)
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:25691.61-25691.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:25692.60-25692.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ia msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_HaveS2TG (tgx : TGx) : SailM Bool := do
  sail_assert (HaveEL EL2) "sail-arm/arm-v9.4-a/src/v8_base.sail:25703.22-25703.23"
  (if ((← (HaveGTGExt ())) : Bool)
  then
    (do match tgx with
        | .TGx_4KB => (__IMPDEF_boolean "Has Stage 2 4K Translation Granule")
        | .TGx_16KB => (__IMPDEF_boolean "Has Stage 2 16K Translation Granule")
        | .TGx_64KB => (__IMPDEF_boolean "Has Stage 2 64K Translation Granule"))
  else (do (AArch64_HaveS1TG tgx)))

def AArch64_S2DecodeTG0 (tg0_in : (BitVec 2)) : SailM TGx := do
  let tg0 : (BitVec 2) := tg0_in
  let tgx ← (( do (undefined_TGx ()) ) : SailM TGx )
  let tg0 ← (( do
    (if ((tg0 == 0b11#2) : Bool)
    then (do (__IMPDEF_bits 2 "TG0 encoded granule size"))
    else (do (pure tg0))) ) : SailM (BitVec 2) )
  let tgx : TGx :=
    match tg0 with
    | 0b00 => TGx_4KB
    | 0b01 => TGx_64KB
    | 0b10 => TGx_16KB
    | _ => tgx
  (if ((! (← (AArch64_HaveS2TG tgx))) : Bool)
  then
    (do match (← (__IMPDEF_bits 2 "TG0 encoded granule size")) with
        | 0b00 => (pure TGx_4KB)
        | 0b01 => (pure TGx_64KB)
        | 0b10 => (pure TGx_16KB)
        | _ => (pure tgx))
  else (do (pure tgx)))

def undefined_S2PIR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2PIR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_NSS2TTWParams (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  let walkparams ← (pure { walkparams with vm := (← do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) ||| (_get_HCR_EL2_Type_DC (← readReg HCR_EL2))))) })
  let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VTCR_EL2_Type_TG0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VTCR_EL2_Type_T0SZ (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_VTCR_EL2_Type_PS (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_VTCR_EL2_Type_IRGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_VTCR_EL2_Type_ORGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_VTCR_EL2_Type_SH0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_D128 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with skl := (← do (pure (_get_VTTBR_EL2_Type_SKL (← (VTTBR_EL2_read ()))))) }))
    else (do (pure { walkparams with sl0 := (← do (pure (_get_VTCR_EL2_Type_SL0 (← readReg VTCR_EL2)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with ptw := (← do
        (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
        then (do (pure (_get_HCR_EL2_Type_PTW (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with fwb := (← do
        (if ((← (HaveStage2MemAttrControl ())) : Bool)
        then (do (pure (_get_HCR_EL2_Type_FWB (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HA (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HD (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ← (( do
    (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with sl2 := (← do (pure ((_get_VTCR_EL2_Type_SL2 (← readReg VTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
    else (do (pure { walkparams with sl2 := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((←((HaveFeatCMOW ()) <&&> (do
             (IsHCRXEL2Enabled ())))) : Bool)
        then (do (pure (_get_HCRX_EL2_Type_CMOW (← readReg HCRX_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with s2pie := 1#1 }))
    else
      (do (pure { walkparams with s2pie := (← do
              (if ((← (HaveS2PIExt ())) : Bool)
              then (do (pure (_get_VTCR_EL2_Type_S2PIE (← readReg VTCR_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with s2pir := (← do
        (if ((← (HaveS2PIExt ())) : Bool)
        then (do (pure (Mk_S2PIRType (← readReg S2PIR_EL2))))
        else (do (pure (Mk_S2PIRType (Zeros (n := 64))))))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 != 1#1)) : Bool)
    then (do (pure { walkparams with assuredonly := (← do (pure (_get_VTCR_EL2_Type_AssuredOnly (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with assuredonly := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with tl0 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL0 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tl1 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL1 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
  then (do (pure { walkparams with haft := (← do (pure (_get_VTCR_EL2_Type_HAFT (← readReg VTCR_EL2)))) }))
  else (do (pure { walkparams with haft := 0#1 })))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_RLS2TTWParams (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (AArch64_NSS2TTWParams s1aarch64) ) : SailM S2TTWParams )
  (pure { walkparams with emec := (← do
      (if ((←((HaveFeatMEC ()) <&&> (do
           (IsSCTLR2EL2Enabled ())))) : Bool)
      then (do (pure (_get_SCTLR2_EL2_Type_EMEC (← readReg SCTLR2_EL2))))
      else (do (pure 0#1)))) })

def undefined_VSTCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSTCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSTCR_EL2_Type_SW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_PMUSERENR_EL0_Type_SW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_VSTTBR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSTTBR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_SS2TTWParams (ipaspace : PASpace) (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with d128 := (← do
        (if ((← (Have128BitDescriptorExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_D128 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then
      (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VSTCR_EL2_Type_TG0 (← readReg VSTCR_EL2)))) })
          let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VSTCR_EL2_Type_T0SZ (← readReg VSTCR_EL2)))) })
          let walkparams ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then (do (pure { walkparams with skl := (← do (pure (_get_VSTTBR_EL2_Type_SKL (← readReg VSTTBR_EL2)))) }))
            else (do (pure { walkparams with sl0 := (← do (pure (_get_VSTCR_EL2_Type_SL0 (← readReg VSTCR_EL2)))) }))) ) : SailM S2TTWParams )
          (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
               (Have52BitIPAAndPASpaceExt ())))) : Bool)
          then (do (pure { walkparams with sl2 := (← do (pure ((_get_VSTCR_EL2_Type_SL2 (← readReg VSTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
          else (do (pure { walkparams with sl2 := 0#1 }))))
    else
      (do (if ((BEq.beq ipaspace PAS_NonSecure) : Bool)
          then
            (do let walkparams ← (pure { walkparams with tgx := (← do (AArch64_S2DecodeTG0 (_get_VTCR_EL2_Type_TG0 (← readReg VTCR_EL2)))) })
                let walkparams ← (pure { walkparams with txsz := (← do (pure (_get_VTCR_EL2_Type_T0SZ (← readReg VTCR_EL2)))) })
                let walkparams ← (( do
                  (if ((walkparams.d128 == 1#1) : Bool)
                  then (do (pure { walkparams with skl := (← do (pure (_get_VTTBR_EL2_Type_SKL (← (VTTBR_EL2_read ()))))) }))
                  else (do (pure { walkparams with sl0 := (← do (pure (_get_VTCR_EL2_Type_SL0 (← readReg VTCR_EL2)))) }))) ) : SailM S2TTWParams )
                (if ((←((pure (BEq.beq walkparams.tgx TGx_4KB)) <&&> (do
                     (Have52BitIPAAndPASpaceExt ())))) : Bool)
                then (do (pure { walkparams with sl2 := (← do (pure ((_get_VTCR_EL2_Type_SL2 (← readReg VTCR_EL2)) &&& (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2))))) }))
                else (do (pure { walkparams with sl2 := 0#1 }))))
          else
            (do (Unreachable ())
                (pure walkparams))))) ) : SailM S2TTWParams )
  let walkparams ← (pure { walkparams with sw := (← do (pure (_get_VSTCR_EL2_Type_SW (← readReg VSTCR_EL2)))) })
  let walkparams ← (pure { walkparams with nsw := (← do (pure (_get_VTCR_EL2_Type_NSW (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sa := (← do (pure (_get_VSTCR_EL2_Type_SA (← readReg VSTCR_EL2)))) })
  let walkparams ← (pure { walkparams with nsa := (← do (pure (_get_VTCR_EL2_Type_NSA (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with vm := (← do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) ||| (_get_HCR_EL2_Type_DC (← readReg HCR_EL2))))) })
  let walkparams ← (pure { walkparams with ps := (← do (pure (_get_VTCR_EL2_Type_PS (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with irgn := (← do (pure (_get_VTCR_EL2_Type_IRGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with orgn := (← do (pure (_get_VTCR_EL2_Type_ORGN0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with sh := (← do (pure (_get_VTCR_EL2_Type_SH0 (← readReg VTCR_EL2)))) })
  let walkparams ← (pure { walkparams with ee := (← do (pure (_get_SCTLR_EL2_Type_EE (← readReg SCTLR_EL2)))) })
  let walkparams ←
    (pure { walkparams with ptw := (← do
        (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
        then (do (pure (_get_HCR_EL2_Type_PTW (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with fwb := (← do
        (if ((← (HaveStage2MemAttrControl ())) : Bool)
        then (do (pure (_get_HCR_EL2_Type_FWB (← readReg HCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with ha := (← do
        (if ((← (HaveAccessFlagUpdateExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HA (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with hd := (← do
        (if ((← (HaveDirtyBitModifierExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_HD (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((←((pure ((BEq.beq walkparams.tgx TGx_4KB) || (BEq.beq walkparams.tgx TGx_16KB))) <&&> (do
         (Have52BitIPAAndPASpaceExt ())))) : Bool)
    then (do (pure { walkparams with ds := (← do (pure (_get_VTCR_EL2_Type_DS (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with ds := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with cmow := (← do
        (if ((←((HaveFeatCMOW ()) <&&> (do
             (IsHCRXEL2Enabled ())))) : Bool)
        then (do (pure (_get_HCRX_EL2_Type_CMOW (← readReg HCRX_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then (do (pure { walkparams with s2pie := 1#1 }))
    else
      (do (pure { walkparams with s2pie := (← do
              (if ((← (HaveS2PIExt ())) : Bool)
              then (do (pure (_get_VTCR_EL2_Type_S2PIE (← readReg VTCR_EL2))))
              else (do (pure 0#1)))) }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with s2pir := (← do
        (if ((← (HaveS2PIExt ())) : Bool)
        then (do (pure (Mk_S2PIRType (← readReg S2PIR_EL2))))
        else (do (pure (Mk_S2PIRType (Zeros (n := 64))))))) })
  let walkparams ← (( do
    (if (((← (HaveTHExt ())) && (walkparams.d128 != 1#1)) : Bool)
    then (do (pure { walkparams with assuredonly := (← do (pure (_get_VTCR_EL2_Type_AssuredOnly (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with assuredonly := 0#1 }))) ) : SailM S2TTWParams )
  let walkparams ←
    (pure { walkparams with tl0 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL0 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ←
    (pure { walkparams with tl1 := (← do
        (if ((← (HaveTHExt ())) : Bool)
        then (do (pure (_get_VTCR_EL2_Type_TL1 (← readReg VTCR_EL2))))
        else (do (pure 0#1)))) })
  let walkparams ← (( do
    (if (((← (HaveAccessFlagUpdateForTableExt ())) && (walkparams.ha == 1#1)) : Bool)
    then (do (pure { walkparams with haft := (← do (pure (_get_VTCR_EL2_Type_HAFT (← readReg VTCR_EL2)))) }))
    else (do (pure { walkparams with haft := 0#1 }))) ) : SailM S2TTWParams )
  (pure { walkparams with emec := 0#1 })

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_GetS2TTWParams (ss : SecurityState) (ipaspace : PASpace) (s1aarch64 : Bool) : SailM S2TTWParams := do
  let walkparams ← (( do (undefined_S2TTWParams ()) ) : SailM S2TTWParams )
  (if ((BEq.beq ss SS_NonSecure) : Bool)
  then (do (AArch64_NSS2TTWParams s1aarch64))
  else
    (do (if (((← (HaveSecureEL2Ext ())) && (BEq.beq ss SS_Secure)) : Bool)
        then (do (AArch64_SS2TTWParams ipaspace s1aarch64))
        else
          (do (if ((BEq.beq ss SS_Realm) : Bool)
              then (do (AArch64_RLS2TTWParams s1aarch64))
              else
                (do (Unreachable ())
                    (pure walkparams)))))))

def AArch64_IPAIsOutOfRange (ipa : (BitVec 56)) (walkparams : S2TTWParams) : Bool :=
  let iasize := (AArch64_IASize walkparams.txsz)
  if ((iasize <b 56) : Bool)
  then (! (is_zero_subrange ipa 55 iasize))
  else false

def AArch64_S2DirectBasePermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let r : (BitVec 1) := ((BitVec.access permissions.s2ap 0) : BitVec 1)
  let w : (BitVec 1) := ((BitVec.access permissions.s2ap 1) : BitVec 1)
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (px, ux) : ((BitVec 1) × (BitVec 1)) :=
    match (permissions.s2xn +++ permissions.s2xnx) with
    | 0b00 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | 0b01 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | 0b10 =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
    | _ =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let px : (BitVec 1) := tup__0
      let ux : (BitVec 1) := tup__1
      (px, ux))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let s2perms : S2AccessControls := { s2perms with r := r }
  let s2perms : S2AccessControls := { s2perms with w := w }
  let s2perms : S2AccessControls := { s2perms with x := x }
  let s2perms : S2AccessControls := { s2perms with r_rcw := r }
  let s2perms : S2AccessControls := { s2perms with w_rcw := w }
  let s2perms : S2AccessControls := { s2perms with r_mmu := r }
  (pure { s2perms with w_mmu := w })

def AArch64_S2IndirectBasePermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel0 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let s2pi : (BitVec 4) := permissions.s2pi
  let (px, r, ux, w, w_mmu, w_rcw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    match s2pi with
    | 0b0000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 1#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0111 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | _ =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let (r_mmu, r_rcw) : ((BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1) := ((r, r) : ((BitVec 1) × (BitVec 1)))
    let r_rcw : (BitVec 1) := tup__0
    let r_mmu : (BitVec 1) := tup__1
    (r_mmu, r_rcw)
  let (toplevel0, toplevel1) : ((BitVec 1) × (BitVec 1)) :=
    match s2pi with
    | 0b0110 =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0011 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0111 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | _ =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
  let s2perms : S2AccessControls := { s2perms with r := r }
  let s2perms : S2AccessControls := { s2perms with w := w }
  let s2perms : S2AccessControls := { s2perms with x := x }
  let s2perms : S2AccessControls := { s2perms with r_rcw := r_rcw }
  let s2perms : S2AccessControls := { s2perms with r_mmu := r_mmu }
  let s2perms : S2AccessControls := { s2perms with w_rcw := w_rcw }
  let s2perms : S2AccessControls := { s2perms with w_mmu := w_mmu }
  let s2perms : S2AccessControls := { s2perms with toplevel0 := toplevel0 }
  (pure { s2perms with toplevel1 := toplevel1 })

def undefined_S2POR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2POR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def AArch64_S2OverlayPermissions (permissions : Permissions) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_rcw ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let r_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w_mmu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let px ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ux ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel0 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let toplevel1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let s2overlay_perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let index := (4 *i (BitVec.toNat permissions.s2po_index))
  let s2po ← (( do (pure (Sail.BitVec.extractLsb (← readReg S2POR_EL1) (index +i 3) index)) ) : SailM (BitVec 4) )
  let (px, r, ux, w, w_mmu, w_rcw) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    match s2po with
    | 0b0000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 1#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((0#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b0111 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1000 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1001 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 0#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1010 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 0#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1011 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 0#1, 1#1, 1#1, 0#1, 0#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1100 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1101 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 0#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | 0b1110 =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 0#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
    | _ =>
      (let (tup__0, tup__1, tup__2, tup__3, tup__4, tup__5) := ((1#1, 1#1, 1#1, 1#1, 1#1, 1#1) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)))
      let r : (BitVec 1) := tup__0
      let w : (BitVec 1) := tup__1
      let px : (BitVec 1) := tup__2
      let ux : (BitVec 1) := tup__3
      let w_rcw : (BitVec 1) := tup__4
      let w_mmu : (BitVec 1) := tup__5
      (px, r, ux, w, w_mmu, w_rcw))
  let x : (BitVec 1) :=
    if ((accdesc.el == EL0) : Bool)
    then ux
    else px
  let (r_mmu, r_rcw) : ((BitVec 1) × (BitVec 1)) :=
    let (tup__0, tup__1) := ((r, r) : ((BitVec 1) × (BitVec 1)))
    let r_rcw : (BitVec 1) := tup__0
    let r_mmu : (BitVec 1) := tup__1
    (r_mmu, r_rcw)
  let (toplevel0, toplevel1) : ((BitVec 1) × (BitVec 1)) :=
    match s2po with
    | 0b0110 =>
      (let (tup__0, tup__1) := ((1#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0011 =>
      (let (tup__0, tup__1) := ((0#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | 0b0111 =>
      (let (tup__0, tup__1) := ((1#1, 1#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
    | _ =>
      (let (tup__0, tup__1) := ((0#1, 0#1) : ((BitVec 1) × (BitVec 1)))
      let toplevel0 : (BitVec 1) := tup__0
      let toplevel1 : (BitVec 1) := tup__1
      (toplevel0, toplevel1))
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or := r }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow := w }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ox := x }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or_rcw := r_rcw }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow_rcw := w_rcw }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with or_mmu := r_mmu }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with ow_mmu := w_mmu }
  let s2overlay_perms : S2AccessControls := { s2overlay_perms with toplevel0 := toplevel0 }
  (pure { s2overlay_perms with toplevel1 := toplevel1 })

def AArch64_S2ComputePermissions (permissions : Permissions) (walkparams : S2TTWParams) (accdesc : AccessDescriptor) : SailM S2AccessControls := do
  let s2overlay_perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  let s2perms ← (( do (undefined_S2AccessControls ()) ) : SailM S2AccessControls )
  (if ((walkparams.s2pie == 1#1) : Bool)
  then
    (do let s2perms ← (AArch64_S2IndirectBasePermissions permissions accdesc)
        let s2perms ← (pure { s2perms with overlay := (← do (HaveS2POExt ()) <&&> (do (pure ((_get_VTCR_EL2_Type_S2POE (← readReg VTCR_EL2)) == 1#1)))) })
        (if (s2perms.overlay : Bool)
        then
          (do let s2overlay_perms ← (( do (AArch64_S2OverlayPermissions permissions accdesc) ) : SailM S2AccessControls )
              let s2perms : S2AccessControls := { s2perms with or := s2overlay_perms.or }
              let s2perms : S2AccessControls := { s2perms with ow := s2overlay_perms.ow }
              let s2perms : S2AccessControls := { s2perms with ox := s2overlay_perms.ox }
              let s2perms : S2AccessControls := { s2perms with or_rcw := s2overlay_perms.or_rcw }
              let s2perms : S2AccessControls := { s2perms with ow_rcw := s2overlay_perms.ow_rcw }
              let s2perms : S2AccessControls := { s2perms with or_mmu := s2overlay_perms.or_mmu }
              let s2perms : S2AccessControls := { s2perms with ow_mmu := s2overlay_perms.ow_mmu }
              (if ((((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) &&& (s2perms.ow +++ (s2perms.ow_rcw +++ s2perms.ow_mmu))) == 0b011#3) : Bool)
              then
                (do let s2perms : S2AccessControls := { s2perms with toplevel0 := (s2perms.toplevel0 ||| s2overlay_perms.toplevel0) }
                    (pure { s2perms with toplevel1 := (s2perms.toplevel1 ||| s2overlay_perms.toplevel1) }))
              else
                (do let s2perms : S2AccessControls := { s2perms with toplevel0 := 0#1 }
                    (pure { s2perms with toplevel1 := 0#1 }))))
        else (do (pure s2perms))))
  else (do (AArch64_S2DirectBasePermissions permissions accdesc)))

def AArch64_S2CheckPermissions (fault_in : FaultRecord) (walkstate : TTWState) (walkparams : S2TTWParams) (ipa : AddressDescriptor) (accdesc : AccessDescriptor) : SailM (FaultRecord × Bool) := do
  let memtype : MemType := walkstate.memattrs.memtype
  let permissions : Permissions := walkstate.permissions
  let fault : FaultRecord := fault_in
  let s2perms ← (( do (AArch64_S2ComputePermissions permissions walkparams accdesc) ) : SailM S2AccessControls )
  let r ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let w ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let or ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let ow ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (or, ow, r, w) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
    if ((BEq.beq accdesc.acctype AccessType_TTW) : Bool)
    then
      (let r : (BitVec 1) := s2perms.r_mmu
      let w : (BitVec 1) := s2perms.w_mmu
      let or : (BitVec 1) := s2perms.or_mmu
      let ow : (BitVec 1) := s2perms.ow_mmu
      (or, ow, r, w))
    else
      (let (or, ow, r, w) : ((BitVec 1) × (BitVec 1) × (BitVec 1) × (BitVec 1)) :=
        if (accdesc.rcw : Bool)
        then
          (let r : (BitVec 1) := s2perms.r_rcw
          let w : (BitVec 1) := s2perms.w_rcw
          let or : (BitVec 1) := s2perms.or_rcw
          let ow : (BitVec 1) := s2perms.ow_rcw
          (or, ow, r, w))
        else
          (let r : (BitVec 1) := s2perms.r
          let w : (BitVec 1) := s2perms.w
          let or : (BitVec 1) := s2perms.or
          let ow : (BitVec 1) := s2perms.ow
          (or, ow, r, w))
      (or, ow, r, w))
  let fault ← (( do
    (if ((BEq.beq accdesc.acctype AccessType_TTW) : Bool)
    then
      (do (if (((accdesc.toplevel && (BEq.beq accdesc.varange VARange_LOWER)) && (((walkparams.tl0 == 1#1) && (s2perms.toplevel0 == 0#1)) || ((walkparams.tl1 == 1#1) && ((s2perms.toplevel1 +++ s2perms.toplevel0) == 0b10#2)))) : Bool)
          then
            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                (pure { fault with toplevel := true }))
          else
            (do (if (((accdesc.toplevel && (BEq.beq accdesc.varange VARange_UPPER)) && (((walkparams.tl1 == 1#1) && (s2perms.toplevel1 == 0#1)) || ((walkparams.tl0 == 1#1) && ((s2perms.toplevel1 +++ s2perms.toplevel0) == 0b01#2)))) : Bool)
                then
                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                      (pure { fault with toplevel := true }))
                else
                  (do (if (((walkparams.ptw == 1#1) && (BEq.beq memtype MemType_Device)) : Bool)
                      then (do (pure { fault with statuscode := Fault_Permission }))
                      else
                        (do (if ((s2perms.overlay && (or == 0#1)) : Bool)
                            then
                              (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                  (pure { fault with overlay := true }))
                            else
                              (do (if (((accdesc.write && s2perms.overlay) && (ow == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if (((BEq.beq accdesc.ss SS_Realm) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
                                        then (do (pure { fault with statuscode := Fault_Permission }))
                                        else
                                          (do (if ((r == 0#1) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if ((accdesc.write && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else
                                                      (do (if ((((accdesc.write && (! ((walkparams.ha +++ walkparams.hd) == 0b11#2))) && (walkparams.s2pie == 1#1)) && (permissions.s2dirty == 0#1)) : Bool)
                                                          then
                                                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                (pure { fault with dirtybit := true }))
                                                          else (do (pure fault))))))))))))))))))))
    else
      (do (if ((←((pure ((walkstate.s2assuredonly == 1#1) && (! ipa.s1assured))) <||> (do
               (pure (((←((pure (walkstate.s2assuredonly != 1#1)) <&&> (do (HaveGCS ())) <&&> (do (pure ((_get_VTCR_EL2_Type_GCSH (← readReg VTCR_EL2)) == 1#1))))) && (BEq.beq accdesc.acctype AccessType_GCS)) && (accdesc.el != EL0)))))) : Bool)
          then
            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                (pure { fault with assuredonly := true }))
          else
            (do (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
                then
                  (do (if ((s2perms.overlay && (s2perms.ox == 0#1)) : Bool)
                      then
                        (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                            (pure { fault with overlay := true }))
                      else
                        (do (if ((←((pure (BEq.beq memtype MemType_Device)) <&&> (do
                                 (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_INSTRDEVICE)) Constraint_FAULT))))) : Bool)
                            then (do (pure { fault with statuscode := Fault_Permission }))
                            else
                              (do (if (((BEq.beq accdesc.ss SS_Realm) && (bne walkstate.baseaddress.paspace PAS_Realm)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_Permission }))
                                  else
                                    (do (if ((s2perms.x == 0#1) : Bool)
                                        then (do (pure { fault with statuscode := Fault_Permission }))
                                        else (do (pure fault))))))))))
                else
                  (do (if ((BEq.beq accdesc.acctype AccessType_DC) : Bool)
                      then
                        (do (if ((BEq.beq accdesc.cacheop CacheOp_Invalidate) : Bool)
                            then
                              (do let fault ← (( do
                                    (if ((((! (← (ELUsingAArch32 EL1))) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                    then
                                      (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                          (pure { fault with overlay := true }))
                                    else (do (pure fault))) ) : SailM FaultRecord )
                                  (if (((! (← (ELUsingAArch32 EL1))) && (w == 0#1)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_Permission }))
                                  else (do (pure fault))))
                            else
                              (do (if (((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && s2perms.overlay) && (or == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if ((((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              (pure { fault with overlay := true }))
                                        else
                                          (do (if ((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && (r == 0#1)) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if (((((walkparams.cmow == 1#1) && (BEq.beq accdesc.opscope CacheOpScope_PoC)) && (BEq.beq accdesc.cacheop CacheOp_CleanInvalidate)) && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else (do (pure fault))))))))))))
                      else
                        (do (if ((BEq.beq accdesc.acctype AccessType_IC) : Bool)
                            then
                              (do (if ((←((pure ((((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && s2perms.overlay) && (or == 0#1))) <&&> (do
                                       (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        (pure { fault with overlay := true }))
                                  else
                                    (do (if ((((walkparams.cmow == 1#1) && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              (pure { fault with overlay := true }))
                                        else
                                          (do (if ((←((pure (((! (← (ELUsingAArch32 EL1))) && (accdesc.el == EL0)) && (r == 0#1))) <&&> (do
                                                   (__IMPDEF_boolean "Permission fault on EL0 IC_IVAU execution")))) : Bool)
                                              then (do (pure { fault with statuscode := Fault_Permission }))
                                              else
                                                (do (if (((walkparams.cmow == 1#1) && (w == 0#1)) : Bool)
                                                    then (do (pure { fault with statuscode := Fault_Permission }))
                                                    else (do (pure fault))))))))))
                            else
                              (do (if (((accdesc.read && s2perms.overlay) && (or == 0#1)) : Bool)
                                  then
                                    (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                        let fault : FaultRecord := { fault with overlay := true }
                                        (pure { fault with write := false }))
                                  else
                                    (do (if (((accdesc.write && s2perms.overlay) && (ow == 0#1)) : Bool)
                                        then
                                          (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                              let fault : FaultRecord := { fault with overlay := true }
                                              (pure { fault with write := true }))
                                        else
                                          (do (if ((accdesc.read && (r == 0#1)) : Bool)
                                              then
                                                (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                    (pure { fault with write := false }))
                                              else
                                                (do (if ((accdesc.write && (w == 0#1)) : Bool)
                                                    then
                                                      (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                          (pure { fault with write := true }))
                                                    else
                                                      (do (if ((((accdesc.tagaccess || accdesc.tagchecked) && (BEq.beq ipa.memattrs.tags MemTag_AllocationTagged)) && (permissions.s2tag_na == 1#1)) : Bool)
                                                          then
                                                            (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                let fault : FaultRecord := { fault with tagaccess := true }
                                                                (pure { fault with write := (accdesc.tagaccess && accdesc.write) }))
                                                          else
                                                            (do (if ((((accdesc.write && (! ((walkparams.ha +++ walkparams.hd) == 0b11#2))) && (walkparams.s2pie == 1#1)) && (permissions.s2dirty == 0#1)) : Bool)
                                                                then
                                                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Permission }
                                                                      let fault : FaultRecord := { fault with dirtybit := true }
                                                                      (pure { fault with write := true }))
                                                                else (do (pure fault))))))))))))))))))))))) ) : SailM FaultRecord )
  let mro ← (( do (undefined_bool ()) ) : SailM Bool )
  let mro : Bool :=
    if (s2perms.overlay : Bool)
    then (((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) &&& (s2perms.ow +++ (s2perms.ow_rcw +++ s2perms.ow_mmu))) == 0b011#3)
    else ((s2perms.w +++ (s2perms.w_rcw +++ s2perms.w_mmu)) == 0b011#3)
  (pure (fault, mro))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S2HasAlignmentFault (accdesc : AccessDescriptor) (aligned : Bool) (memattrs : MemoryAttributes) : SailM Bool := do
  (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
  then (do (pure false))
  else
    (do (if ((((← (HaveMTEExt ())) && accdesc.tagaccess) && accdesc.write) : Bool)
        then (do (pure (BEq.beq memattrs.memtype MemType_Device)) <&&> (do (pure (BEq.beq (← (ConstrainUnpredictable Unpredictable_DEVICETAGSTORE)) Constraint_FAULT))))
        else
          (do (if ((BEq.beq accdesc.acctype AccessType_DCZero) : Bool)
              then (do (pure (BEq.beq memattrs.memtype MemType_Device)))
              else (do (pure ((BEq.beq memattrs.memtype MemType_Device) && (! aligned)))))))))

def AArch64_S2StartLevel (walkparams : S2TTWParams) : SailM Int := do
  let descsizelog2 ← (( do (undefined_int ()) ) : SailM Int )
  let granulebits ← (( do (undefined_int ()) ) : SailM Int )
  let iasize ← (( do (undefined_int ()) ) : SailM Int )
  let s2startlevel ← (( do (undefined_int ()) ) : SailM Int )
  let stride ← (( do (undefined_int ()) ) : SailM Int )
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do let iasize := (AArch64_IASize walkparams.txsz)
        let granulebits := (TGxGranuleBits walkparams.tgx)
        let descsizelog2 := 4
        let stride := (granulebits -i descsizelog2)
        let s2startlevel : Int := (FINAL_LEVEL -i (fdiv_int ((iasize -i 1) -i granulebits) stride))
        let s2startlevel := (s2startlevel +i (BitVec.toNat walkparams.skl))
        (pure s2startlevel))
  else
    (do match walkparams.tgx with
        | .TGx_4KB =>
          (do
            match (walkparams.sl2 +++ walkparams.sl0) with
            | 0b000 => (pure 2)
            | 0b001 => (pure 1)
            | 0b010 => (pure 0)
            | 0b011 => (pure 3)
            | 0b100 => (pure (Neg.neg 1))
            | _ => (do (undefined_int ())))
        | .TGx_16KB =>
          (do
            match walkparams.sl0 with
            | 0b00 => (pure 3)
            | 0b01 => (pure 2)
            | 0b10 => (pure 1)
            | 0b11 => (pure 0)
            | _ => (do (undefined_int ())))
        | .TGx_64KB =>
          (do
            match walkparams.sl0 with
            | 0b00 => (pure 3)
            | 0b01 => (pure 2)
            | 0b10 => (pure 1)
            | _ => (do (undefined_int ())))))

def AArch64_S2InconsistentSL (walkparams : S2TTWParams) : SailM Bool := do
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let levels := (FINAL_LEVEL -i startlevel)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 := 3
  let stride := (granulebits -i descsizelog2)
  let sl_min_iasize := (((levels *i stride) +i granulebits) +i 1)
  let sl_max_iasize := ((sl_min_iasize +i (stride -i 1)) +i 4)
  let iasize := (AArch64_IASize walkparams.txsz)
  (pure ((iasize <b sl_min_iasize) || (iasize >b sl_max_iasize)))

def AArch64_S2InvalidSL (walkparams : S2TTWParams) : SailM Bool := do
  match walkparams.tgx with
  | .TGx_4KB =>
    (do
      let b__0 := (walkparams.sl2 +++ walkparams.sl0)
      (if ((((Sail.BitVec.extractLsb b__0 2 2) == (1#1 : (BitVec 1))) && ((Sail.BitVec.extractLsb b__0 0 0) == (1#1 : (BitVec 1)))) : Bool)
      then (do (pure true))
      else
        (do (if (((Sail.BitVec.extractLsb b__0 2 1) == (0b11#2 : (BitVec 2))) : Bool)
            then (do (pure true))
            else
              (do (if ((b__0 == (0b010#3 : (BitVec 3))) : Bool)
                  then (do (pure ((← (AArch64_PAMax ())) <b 44)))
                  else
                    (do (if ((b__0 == (0b011#3 : (BitVec 3))) : Bool)
                        then (do (pure (! (← (HaveSmallTranslationTableExt ())))))
                        else (do (pure false))))))))))
  | .TGx_16KB =>
    (do
      match walkparams.sl0 with
      | 0b11 => (pure (walkparams.ds == 0#1))
      | 0b10 => (pure ((← (AArch64_PAMax ())) <b 42))
      | _ => (pure false))
  | .TGx_64KB =>
    (do
      match walkparams.sl0 with
      | 0b11 => (pure true)
      | 0b10 => (pure ((← (AArch64_PAMax ())) <b 44))
      | _ => (pure false))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_S2MinTxSZ (d128 : (BitVec 1)) (ds : (BitVec 1)) (tgx : TGx) (s1aarch64 : Bool) : SailM Int := do
  let ips ← (( do (AArch64_PAMax ()) ) : SailM Int )
  let ips ← (( do
    (if ((d128 == 0#1) : Bool)
    then
      (do (if ((((← (Have52BitPAExt ())) && (bne tgx TGx_64KB)) && (ds == 0#1)) : Bool)
          then (do (pure (Min.min 48 (← (AArch64_PAMax ())))))
          else (do (pure (Min.min 52 (← (AArch64_PAMax ())))))))
    else (do (pure ips))) ) : SailM Int )
  let ips := ips
  let min_txsz : Int := (64 -i ips)
  let min_txsz : Int :=
    if ((! s1aarch64) : Bool)
    then (Min.min min_txsz 24)
    else min_txsz
  let min_txsz := min_txsz
  (pure min_txsz)

def undefined_VMECID_A_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VMECID_A_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_N : Nat, List.elem k_N [64, 128] -/
def AArch64_S2OutputMECID (walkparams : S2TTWParams) (paspace : PASpace) (descriptor : (BitVec k_N)) : SailM (BitVec 16) := do
  sail_assert (((Sail.BitVec.length descriptor) == 64) || ((Sail.BitVec.length descriptor) == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26576.31-26576.32"
  (if ((walkparams.emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((bne paspace PAS_Realm) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do let descriptor_amec ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (103 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26584.35-26584.36"
                      (pure ((BitVec.access descriptor 103) : BitVec 1)))
                else (do (pure ((BitVec.access descriptor 63) : BitVec 1)))) ) : SailM (BitVec 1) )
              (if ((descriptor_amec == 0#1) : Bool)
              then (do (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2))))
              else (do (pure (_get_VMECID_A_EL2_Type_MECID (← readReg VMECID_A_EL2)))))))))

/-- Type quantifiers: k_s1aarch64 : Bool -/
def AArch64_S2TxSZFaults (walkparams : S2TTWParams) (s1aarch64 : Bool) : SailM Bool := do
  let mintxsz ← (( do (AArch64_S2MinTxSZ walkparams.d128 walkparams.ds walkparams.tgx s1aarch64) ) : SailM Int )
  let maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailM Int )
  (if (((BitVec.toNat walkparams.txsz) <b mintxsz) : Bool)
  then (do (Have52BitPAExt ()) <||> (do (__IMPDEF_boolean "Fault on TxSZ value below minimum")))
  else
    (do (if (((BitVec.toNat walkparams.txsz) >b maxtxsz) : Bool)
        then (do (__IMPDEF_boolean "Fault on TxSZ value above maximum"))
        else (do (pure false)))))

def AArch64_GetS2TLBContext (ss : SecurityState) (ipa : FullAddress) (tg : TGx) : SailM TLBContext := do
  sail_assert (← (EL2Enabled ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:26612.23-26612.24"
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with ss := ss }
  let tlbcontext : TLBContext := { tlbcontext with regime := Regime_EL10 }
  let tlbcontext : TLBContext := { tlbcontext with ipaspace := ipa.paspace }
  let tlbcontext ← (pure { tlbcontext with vmid := (← do (VMID_read ())) })
  let tlbcontext : TLBContext := { tlbcontext with tg := tg }
  let tlbcontext : TLBContext := { tlbcontext with ia := (Sail.BitVec.zeroExtend ipa.address 64) }
  let tlbcontext ← (( do
    (if ((← (HaveCommonNotPrivateTransExt ())) : Bool)
    then
      (do (pure { tlbcontext with cnp := (← do
              (if ((BEq.beq ipa.paspace PAS_Secure) : Bool)
              then (do (pure (_get_VSTTBR_EL2_Type_CnP (← readReg VSTTBR_EL2))))
              else (do (pure (_get_VTTBR_EL2_Type_CnP (← (VTTBR_EL2_read ()))))))) }))
    else (do (pure { tlbcontext with cnp := 0#1 }))) ) : SailM TLBContext )
  let tlbcontext : TLBContext := { tlbcontext with includes_s1_name := false }
  let tlbcontext : TLBContext := { tlbcontext with includes_s2_name := true }
  (pure { tlbcontext with includes_gpt_name := false })

/-- Type quantifiers: k_N : Nat, 11 < k_N -/
def AArch64_S2ApplyFWBMemAttrs (s1_memattrs : MemoryAttributes) (walkparams : S2TTWParams) (descriptor : (BitVec k_N)) : SailM MemoryAttributes := do
  let s2_device ← (( do (undefined_DeviceType ()) ) : SailM DeviceType )
  let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailM MemoryAttributes )
  let s2_attr : (BitVec 4) := (Sail.BitVec.extractLsb descriptor 5 2)
  let s2_sh ← (( do
    (if ((walkparams.ds == 1#1) : Bool)
    then (do (pure walkparams.sh))
    else
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26640.33-26640.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))) ) : SailM (BitVec 2) )
  let s2_fnxs : (BitVec 1) := ((BitVec.access descriptor 11) : BitVec 1)
  let memattrs ← (( do
    (if ((((BitVec.access s2_attr 2) : BitVec 1) == 0#1) : Bool)
    then
      (do let s2_device ← (( do (DecodeDevice (Sail.BitVec.extractLsb s2_attr 1 0)) ) : SailM DeviceType )
          let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Device }
          let memattrs : MemoryAttributes :=
            if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
            then { memattrs with device := (S2CombineS1Device s1_memattrs.device s2_device) }
            else { memattrs with device := s2_device }
          (pure { memattrs with xs := s1_memattrs.xs }))
    else
      (do (if (((Sail.BitVec.extractLsb s2_attr 1 0) == 0b11#2) : Bool)
          then (do (pure s1_memattrs))
          else
            (do (if (((Sail.BitVec.extractLsb s2_attr 1 0) == 0b10#2) : Bool)
                then
                  (do let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                      let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with attrs := MemAttr_WB } }
                      let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with attrs := MemAttr_WB } }
                      let memattrs : MemoryAttributes :=
                        if (((BEq.beq s1_memattrs.memtype MemType_Normal) && (s1_memattrs.inner.attrs != MemAttr_NC)) : Bool)
                        then
                          (let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := s1_memattrs.inner.hints } }
                          { memattrs with inner := { memattrs.inner with transient := s1_memattrs.inner.transient } })
                        else
                          (let memattrs : MemoryAttributes := { memattrs with inner := { memattrs.inner with hints := MemHint_RWA } }
                          { memattrs with inner := { memattrs.inner with transient := false } })
                      let memattrs : MemoryAttributes :=
                        if (((BEq.beq s1_memattrs.memtype MemType_Normal) && (s1_memattrs.outer.attrs != MemAttr_NC)) : Bool)
                        then
                          (let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := s1_memattrs.outer.hints } }
                          { memattrs with outer := { memattrs.outer with transient := s1_memattrs.outer.transient } })
                        else
                          (let memattrs : MemoryAttributes := { memattrs with outer := { memattrs.outer with hints := MemHint_RWA } }
                          { memattrs with outer := { memattrs.outer with transient := false } })
                      (pure { memattrs with xs := 0#1 }))
                else
                  (do (if ((BEq.beq s1_memattrs.memtype MemType_Device) : Bool)
                      then (do (pure s1_memattrs))
                      else
                        (do let cacheability_attr ← (( do (undefined_MemAttrHints ()) ) : SailM MemAttrHints )
                            let cacheability_attr : MemAttrHints := { cacheability_attr with attrs := MemAttr_NC }
                            let memattrs : MemoryAttributes := { memattrs with memtype := MemType_Normal }
                            let memattrs : MemoryAttributes := { memattrs with inner := cacheability_attr }
                            let memattrs : MemoryAttributes := { memattrs with outer := cacheability_attr }
                            (pure { memattrs with xs := s1_memattrs.xs }))))))))) ) : SailM MemoryAttributes )
  let s2_shareability ← (( do (DecodeShareability s2_sh) ) : SailM Shareability )
  let memattrs : MemoryAttributes := { memattrs with shareability := (S2CombineS1Shareability s1_memattrs.shareability s2_shareability) }
  let memattrs ← (pure { memattrs with tags := (← do (S2MemTagType memattrs s1_memattrs.tags)) })
  let memattrs : MemoryAttributes := { memattrs with notagaccess := (((Sail.BitVec.extractLsb s2_attr 3 1) == 0b111#3) && (BEq.beq memattrs.tags MemTag_AllocationTagged)) }
  let memattrs : MemoryAttributes :=
    if ((s2_fnxs == 1#1) : Bool)
    then { memattrs with xs := 0#1 }
    else memattrs
  (pure { memattrs with shareability := (EffectiveShareability memattrs) })

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2TTBaseAddress (walkparams : S2TTWParams) (paspace : PASpace) (ttbr : (BitVec k_N)) : SailM (BitVec 56) := do
  let tablebase : (BitVec 56) := (Zeros (n := 56))
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let levels := (FINAL_LEVEL -i startlevel)
  let tsize : Int := ((iasize -i ((levels *i stride) +i granulebits)) +i descsizelog2)
  let (tablebase, tsize) ← (( do
    (if (((← (Have56BitPAExt ())) && (walkparams.d128 == 1#1)) : Bool)
    then
      (do let tsize : Int := (Max.max tsize 5)
          let tablebase ← (( do
            (if ((BEq.beq paspace PAS_Secure) : Bool)
            then
              (do sail_assert (55 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26712.38-26712.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 (Sail.BitVec.extractLsb ttbr 55 5))))
            else
              (do sail_assert (87 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26715.38-26715.39"
                  (pure (Sail.BitVec.updateSubrange tablebase 55 5 ((Sail.BitVec.extractLsb ttbr 87 80) +++ (Sail.BitVec.extractLsb ttbr 47 5)))))) ) : SailM (BitVec 56) )
          (pure (tablebase, tsize)))
    else
      (do let (tablebase, tsize) ← (( do
            (if (((((← (Have52BitPAExt ())) && (BEq.beq walkparams.tgx TGx_64KB)) && (walkparams.ps == 0b110#3)) || (walkparams.ds == 1#1)) : Bool)
            then
              (do let tsize : Int := (Max.max tsize 6)
                  sail_assert (5 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26720.33-26720.34"
                  sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26721.34-26721.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 51 6 ((Sail.BitVec.extractLsb ttbr 5 2) +++ (Sail.BitVec.extractLsb ttbr 47 6)))
                  (pure (tablebase, tsize)))
            else
              (do sail_assert (47 <b (Sail.BitVec.length ttbr)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26724.34-26724.35"
                  let tablebase : (BitVec 56) := (Sail.BitVec.updateSubrange tablebase 47 1 (Sail.BitVec.extractLsb ttbr 47 1))
                  (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
          (pure (tablebase, tsize)))) ) : SailM ((BitVec 56) × Int) )
  let tsize := tsize
  (pure (Align_bits tablebase (_shl_int_general 1 tsize)))

def AArch64_S2InitialTTWState (ss : SecurityState) (walkparams : S2TTWParams) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let ttbr ← (( do (pure (Sail.BitVec.zeroExtend (← (VTTBR_EL2_read ())) 128)) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    match ss with
    | .SS_NonSecure => { tablebase with paspace := PAS_NonSecure }
    | .SS_Realm => { tablebase with paspace := PAS_Realm }
    | _ => tablebase
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S2TTBaseAddress walkparams tablebase.paspace ttbr)) })
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate ← (pure { walkstate with level := (← do (AArch64_S2StartLevel walkparams)) })
  let walkstate : TTWState := { walkstate with istable := true }
  (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2ApplyOutputPerms (descriptor : (BitVec k_N)) (walkparams : S2TTWParams) : SailM Permissions := do
  let bit_index ← (( do (undefined_int ()) ) : SailM Int )
  let permissions ← (( do (undefined_Permissions ()) ) : SailM Permissions )
  let s2pi_index ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let permissions ← (( do
    (if ((walkparams.s2pie == 1#1) : Bool)
    then
      (do let s2pi_index ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26764.39-26764.40"
                  (pure (Sail.BitVec.extractLsb descriptor 118 115)))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26767.38-26767.39"
                  (pure ((Sail.BitVec.extractLsb descriptor 54 53) +++ (((BitVec.access descriptor 51) : BitVec 1) +++ ((BitVec.access descriptor 6) : BitVec 1)))))) ) : SailM (BitVec 4) )
          let bit_index := (4 *i (BitVec.toNat s2pi_index))
          let permissions : Permissions := { permissions with s2pi := (Sail.BitVec.extractLsb walkparams.s2pir (bit_index +i 3) bit_index) }
          sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26772.33-26772.34"
          (pure { permissions with s2dirty := ((BitVec.access descriptor 7) : BitVec 1) }))
    else
      (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26775.33-26775.34"
          let permissions : Permissions := { permissions with s2ap := (Sail.BitVec.extractLsb descriptor 7 6) }
          let permissions ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26778.39-26778.40"
                  (pure { permissions with s2xn := ((BitVec.access descriptor 118) : BitVec 1) }))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26781.38-26781.39"
                  (pure { permissions with s2xn := ((BitVec.access descriptor 54) : BitVec 1) }))) ) : SailM Permissions )
          let permissions ← (( do
            (if ((← (HaveExtendedExecuteNeverExt ())) : Bool)
            then
              (do (if ((walkparams.d128 == 1#1) : Bool)
                  then
                    (do sail_assert (117 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26786.43-26786.44"
                        (pure { permissions with s2xnx := ((BitVec.access descriptor 117) : BitVec 1) }))
                  else
                    (do sail_assert (53 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26789.42-26789.43"
                        (pure { permissions with s2xnx := ((BitVec.access descriptor 53) : BitVec 1) }))))
            else (do (pure { permissions with s2xnx := 0#1 }))) ) : SailM Permissions )
          let desc_dbm ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let desc_dbm ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (115 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26797.39-26797.40"
                  (pure ((BitVec.access descriptor 115) : BitVec 1)))
            else
              (do sail_assert (51 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26800.38-26800.39"
                  (pure ((BitVec.access descriptor 51) : BitVec 1)))) ) : SailM (BitVec 1) )
          (if ((((walkparams.ha == 1#1) && (walkparams.hd == 1#1)) && (desc_dbm == 1#1)) : Bool)
          then (do (pure { permissions with s2ap := (BitVec.update permissions.s2ap 1 (Bit 1#1)) }))
          else (do (pure permissions))))) ) : SailM Permissions )
  (if ((←((pure (walkparams.s2pie == 1#1)) <&&> (do
       (HaveS2POExt ())) <&&> (do
       (pure ((_get_VTCR_EL2_Type_S2POE (← readReg VTCR_EL2)) == 1#1))))) : Bool)
  then
    (do (if ((walkparams.d128 == 1#1) : Bool)
        then
          (do sail_assert (124 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26810.39-26810.40"
              (pure { permissions with s2po_index := (Sail.BitVec.extractLsb descriptor 124 121) }))
        else
          (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26813.38-26813.39"
              (pure { permissions with s2po_index := (Sail.BitVec.extractLsb descriptor 62 59) }))))
  else (do (pure permissions)))

def AArch64_SS2OutputPASpace (walkparams : S2TTWParams) (ipaspace : PASpace) : PASpace :=
  if ((BEq.beq ipaspace PAS_Secure) : Bool)
  then
    (if (((walkparams.sw +++ walkparams.sa) == 0b00#2) : Bool)
    then PAS_Secure
    else PAS_NonSecure)
  else
    (if (((walkparams.sw +++ (walkparams.sa +++ (walkparams.nsw +++ walkparams.nsa))) == 0b0000#4) : Bool)
    then PAS_Secure
    else PAS_NonSecure)

/-- Type quantifiers: k_N : Nat, 52 < k_N -/
def AArch64_S2NextWalkStateLeaf (currentstate : TTWState) (ss : SecurityState) (walkparams : S2TTWParams) (ipa : AddressDescriptor) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let s2aarch64 ← (( do (undefined_bool ()) ) : SailM Bool )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let baseaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let baseaddress ← (( do
    (if ((BEq.beq ss SS_Secure) : Bool)
    then (do (pure { baseaddress with paspace := (AArch64_SS2OutputPASpace walkparams ipa.paddress.paspace) }))
    else
      (do (if ((BEq.beq ss SS_Realm) : Bool)
          then
            (do let ns ← (( do
                  (if ((walkparams.d128 == 1#1) : Bool)
                  then
                    (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26849.39-26849.40"
                        (pure ((BitVec.access descriptor 127) : BitVec 1)))
                  else
                    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26852.38-26852.39"
                        (pure ((BitVec.access descriptor 55) : BitVec 1)))) ) : SailM (BitVec 1) )
                (pure { baseaddress with paspace := if ((ns == 1#1) : Bool)
                    then PAS_NonSecure
                    else PAS_Realm }))
          else (do (pure { baseaddress with paspace := PAS_NonSecure }))))) ) : SailM FullAddress )
  let baseaddress ← (pure { baseaddress with address := (← do (AArch64_LeafBase descriptor walkparams.d128 walkparams.ds walkparams.tgx currentstate.level)) })
  let nextstate : TTWState := { nextstate with istable := false }
  let nextstate : TTWState := { nextstate with level := currentstate.level }
  let nextstate : TTWState := { nextstate with baseaddress := baseaddress }
  let nextstate ← (pure { nextstate with permissions := (← do (AArch64_S2ApplyOutputPerms descriptor walkparams)) })
  let s2_attr : (BitVec 4) := (Sail.BitVec.extractLsb descriptor 5 2)
  let s2_sh ← (( do
    (if ((walkparams.ds == 1#1) : Bool)
    then (do (pure walkparams.sh))
    else
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26866.33-26866.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))) ) : SailM (BitVec 2) )
  let s2_fnxs : (BitVec 1) := ((BitVec.access descriptor 11) : BitVec 1)
  let nextstate ← (( do
    (if ((walkparams.fwb == 1#1) : Bool)
    then
      (do let nextstate ← (pure { nextstate with memattrs := (← do (AArch64_S2ApplyFWBMemAttrs ipa.memattrs walkparams descriptor)) })
          (if (((Sail.BitVec.extractLsb s2_attr 3 1) == 0b111#3) : Bool)
          then (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 1#1 } }))
          else (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 0#1 } }))))
    else
      (do let s2aarch64 : Bool := true
          let nextstate ← (pure { nextstate with memattrs := (← do (S2DecodeMemAttrs s2_attr s2_sh s2aarch64)) })
          let nextstate : TTWState := { nextstate with memattrs := { nextstate.memattrs with xs := (Complement.complement s2_fnxs) } }
          (if ((s2_attr == 0b0100#4) : Bool)
          then (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 1#1 } }))
          else (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 0#1 } }))))) ) : SailM TTWState )
  let nextstate ← (pure { nextstate with contiguous := (← do (AArch64_ContiguousBit walkparams.tgx walkparams.d128 currentstate.level descriptor)) })
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26889.35-26889.36"
        (pure { nextstate with s2assuredonly := ((BitVec.access descriptor 114) : BitVec 1) }))
  else
    (do (pure { nextstate with s2assuredonly := (← do
            (if ((walkparams.assuredonly == 1#1) : Bool)
            then
              (do sail_assert (58 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26893.38-26893.39"
                  (pure ((BitVec.access descriptor 58) : BitVec 1)))
            else (do (pure 0#1)))) })))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2NextWalkStateTable (currentstate : TTWState) (walkparams : S2TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let skl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let tablebase ← (pure { tablebase with address := (← do (AArch64_NextTableBase descriptor walkparams.d128 walkparams.ds walkparams.tgx)) })
  let tablebase : FullAddress := { tablebase with paspace := currentstate.baseaddress.paspace }
  let nextstate : TTWState := { nextstate with istable := true }
  let nextstate ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (110 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26911.35-26911.36"
          let skl : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 110 109)
          (pure { nextstate with level := ((currentstate.level +i (BitVec.toNat skl)) +i 1) }))
    else (do (pure { nextstate with level := (currentstate.level +i 1) }))) ) : SailM TTWState )
  let nextstate : TTWState := { nextstate with baseaddress := tablebase }
  (pure { nextstate with memattrs := currentstate.memattrs })

def AArch64_S2SLTTEntryAddress (walkparams : S2TTWParams) (ipa : (BitVec 56)) (tablebase : FullAddress) : SailM FullAddress := do
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i startlevel)
  let lsb := ((levels *i stride) +i granulebits)
  let msb := (iasize -i 1)
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 56))) "sail-arm/arm-v9.4-a/src/v8_base.sail:26933.61-26933.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26934.60-26934.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ipa msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_SS2InitialTTWState (walkparams : S2TTWParams) (ipaspace : PASpace) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let ttbr ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let ttbr ← (( do
    (if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← readReg VSTTBR_EL2) 128)))
    else (do (pure (Sail.BitVec.zeroExtend (← (VTTBR_EL2_read ())) 128)))) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then
      (if ((walkparams.sw == 0#1) : Bool)
      then { tablebase with paspace := PAS_Secure }
      else { tablebase with paspace := PAS_NonSecure })
    else
      (if ((walkparams.nsw == 0#1) : Bool)
      then { tablebase with paspace := PAS_Secure }
      else { tablebase with paspace := PAS_NonSecure })
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S2TTBaseAddress walkparams tablebase.paspace ttbr)) })
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate ← (pure { walkstate with level := (← do (AArch64_S2StartLevel walkparams)) })
  let walkstate : TTWState := { walkstate with istable := true }
  (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })

/-- Type quantifiers: level : Int -/
def AArch64_TTEntryAddress (level : Int) (d128 : (BitVec 1)) (skl : (BitVec 2)) (tgx : TGx) (txsz : (BitVec 6)) (ia : (BitVec 64)) (tablebase : FullAddress) : SailM FullAddress := do
  let iasize := (AArch64_IASize txsz)
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i level)
  let msb ← (( do (undefined_int ()) ) : SailM Int )
  let lsb := ((levels *i stride) +i granulebits)
  let msb : Int :=
    if ((d128 == 1#1) : Bool)
    then ((lsb +i (stride *i (1 +i (BitVec.toNat skl)))) -i 1)
    else ((lsb +i stride) -i 1)
  let msb := msb
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:26991.61-26991.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26992.60-26992.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ia msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_TTWalkMECID (emec : (BitVec 1)) (regime : Regime) (ss : SecurityState) : SailM (BitVec 16) := do
  (if ((emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((bne ss SS_Realm) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do match regime with
              | .Regime_EL2 => (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2)))
              | .Regime_EL20 =>
                (do
                  (if (((_get_TCR_EL2_Type_A1 (← readReg TCR_EL2)) == 0#1) : Bool)
                  then (do (pure (_get_MECID_P1_EL2_Type_MECID (← readReg MECID_P1_EL2))))
                  else (do (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2))))))
              | .Regime_EL10 => (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2)))
              | _ =>
                (do
                  (Unreachable ())
                  (undefined_bitvector 16))))))

def S2TLBCache (tlbrecord : TLBRecord) : Unit :=
  ()

def S2TLBLookup (tlbcontext : TLBContext) : SailM TLBLine := do
  (__UNKNOWN_TLBLine ())

/-- Type quantifiers: N : Nat, List.elem N [32, 64, 128] -/
def AArch64_S2Walk (fault_in : FaultRecord) (ipa : AddressDescriptor) (walkparams : S2TTWParams) (accdesc : AccessDescriptor) (s1level : (Option Int)) (N : Nat) : SailM (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) := SailME.run do
  let fault : FaultRecord := fault_in
  let ipa_64 : (BitVec 64) := (Sail.BitVec.zeroExtend ipa.paddress.address 64)
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBContext )
  let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
  let (fault, tlbcontext, tlbrecord) ← (( do
    (if ((← readReg __tlb_enabled) : Bool)
    then
      (do let tlbcontext ← (AArch64_GetS2TLBContext accdesc.ss ipa.paddress walkparams.tgx)
          let tlbentry ← (( do (S2TLBLookup tlbcontext) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBLine )
          let tlbrecord : TLBRecord := tlbentry.tlbrecord
          let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx tlbrecord.walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
          let (fault, tlbrecord) ← (( do
            (if (((←((pure tlbentry.valid_name) <&&> (do
                   (pure (! (← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx))))))) && (! ((((((walkparams.ha +++ walkparams.hd) == 0b11#2) && ((walkparams.s2pie == 1#1) || (((BitVec.access tlbrecord.s2descriptor 51) : BitVec 1) == 1#1))) && (((BitVec.access tlbrecord.s2descriptor 7) : BitVec 1) == 0#1)) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))))) : Bool)
            then
              (do let a__11033 ← (( do
                    let tlbrecord ← (( do
                      (if ((walkparams.fwb == 1#1) : Bool)
                      then
                        (do let tlbrecord ← (pure { tlbrecord with walkstate := (← do (pure { tlbrecord.walkstate with memattrs := (← do (AArch64_S2ApplyFWBMemAttrs ipa.memattrs walkparams tlbrecord.s2descriptor)) })) })
                            (if (((Sail.BitVec.extractLsb tlbrecord.s2descriptor 5 3) == 0b111#3) : Bool)
                            then (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 1#1 } } }))
                            else (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 0#1 } } }))))
                      else (do (pure tlbrecord))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                    let fault : FaultRecord := { fault with level := tlbrecord.walkstate.level }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), tlbrecord.walkstate, (Sail.BitVec.extractLsb tlbrecord.s2descriptor (N -i 1) 0))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                  SailME.throw a__11033)
            else (do (pure (fault, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBRecord) )
          (pure (fault, tlbcontext, tlbrecord)))
    else (do (pure (fault, tlbcontext, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBContext × TLBRecord) )
  let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let walkstate ← (( do
    (if ((BEq.beq accdesc.ss SS_Secure) : Bool)
    then (do (AArch64_SS2InitialTTWState walkparams ipa.paddress.paspace))
    else (do (AArch64_S2InitialTTWState accdesc.ss walkparams))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let startlevel := walkstate.level
  let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
  let walkaccess ← (( do (CreateAccDescS2TTW accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
  let walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let skl : (BitVec 2) := 0b00#2
  let walkaddress : AddressDescriptor := { walkaddress with vaddress := ipa.vaddress }
  let walkaddress ← (pure { walkaddress with mecid := (← do (AArch64_TTWalkMECID walkparams.emec Regime_EL10 accdesc.ss)) })
  let walkaddress ← (( do
    (if (((_get_HCR_EL2_Type_CD (← readReg HCR_EL2)) == 1#1) : Bool)
    then
      (do let walkaddress ← (pure { walkaddress with memattrs := (← do (NormalNCMemAttr ())) })
          (pure { walkaddress with memattrs := { walkaddress.memattrs with xs := walkstate.memattrs.xs } }))
    else (do (pure { walkaddress with memattrs := walkstate.memattrs }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let walkaddress : AddressDescriptor := { walkaddress with memattrs := { walkaddress.memattrs with shareability := (EffectiveShareability walkaddress.memattrs) } }
  let walkaddress : AddressDescriptor := { walkaddress with tlbcontext := tlbcontext }
  let desctype ← (( do (undefined_DescriptorType ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) DescriptorType )
  let descaddress ← (( do (AArch64_S2SLTTEntryAddress walkparams ipa.paddress.address walkstate.baseaddress) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
  (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
        let fault : FaultRecord := { fault with level := 0 }
        (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
  else
    (do let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) ← (( do
          let mut loop_vars := (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate)
          repeat
            let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) := loop_vars
            loop_vars ← do
              let fault : FaultRecord := { fault with level := walkstate.level }
              let walkaddress : AddressDescriptor := { walkaddress with paddress := descaddress }
              let translation_info ← (( do
                (pure { regime := Regime_EL10
                        vmid := (← do
                          (pure (some (← (VMID_read ())))))
                        asid := none
                        va := walkaddress.vaddress
                        s1level := s1level
                        s2info := (some (ipa_64, walkstate.level))
                        s1params := none
                        s2params := (some walkparams)
                        memattrs := walkaddress.memattrs }) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TranslationInfo )
              let (descriptor, fault) ← (( do
                let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee walkaddress walkaccess fault N translation_info)
                let fault : FaultRecord := tup__0
                let descriptor : (BitVec N) := tup__1
                (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
              let (descaddress, descriptor, desctype, fault, skl, walkstate) ← (( do
                (if ((bne fault.statuscode Fault_None) : Bool)
                then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                else
                  (do let new_descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                      let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) ← (( do
                        let mut loop_vars_1 := (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate)
                        repeat
                          let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) := loop_vars_1
                          loop_vars_1 ← do
                            let new_descriptor : (BitVec N) := descriptor
                            let desctype ← (AArch64_DecodeDescriptorType descriptor walkparams.d128 walkparams.ds walkparams.tgx walkstate.level)
                            let (descaddress, fault, new_descriptor, skl, walkstate) ← (( do
                              match desctype with
                              | .DescriptorType_Table =>
                                (do
                                  let walkstate ← (AArch64_S2NextWalkStateTable walkstate walkparams descriptor)
                                  let skl ←
                                    (if ((walkparams.d128 == 1#1) : Bool)
                                    then
                                      (do sail_assert (110 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27115.49-27115.50"
                                          (pure (Sail.BitVec.extractLsb descriptor 110 109)))
                                    else (do (pure 0b00#2)))
                                  let descaddress ← (AArch64_TTEntryAddress walkstate.level walkparams.d128 skl walkparams.tgx walkparams.txsz ipa_64 walkstate.baseaddress)
                                  let (fault, new_descriptor) ← (( do
                                    (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                    then
                                      (do let a__11030 ← (( do
                                            let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
                                            (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                          SailME.throw a__11030)
                                    else
                                      (do let new_descriptor : (BitVec N) :=
                                            if ((walkparams.haft == 1#1) : Bool)
                                            then (BitVec.update new_descriptor 10 (Bit 1#1))
                                            else new_descriptor
                                          let fault ← (( do
                                            (if ((←((pure ((walkparams.d128 == 1#1) && (skl != 0b00#2))) <&&> (do
                                                 (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                                            then
                                              (do let a__11031 ← (( do
                                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                  SailME.throw a__11031)
                                            else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                                          (pure (fault, new_descriptor)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × (BitVec N)) )
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Leaf =>
                                (do
                                  sail_assert (52 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27133.44-27133.45"
                                  let walkstate ← (AArch64_S2NextWalkStateLeaf walkstate accdesc.ss walkparams ipa descriptor)
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Invalid =>
                                (do
                                  let a__11032 ← (( do
                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                  SailME.throw a__11032) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                            let (descriptor, fault) ← (( do
                              (if ((new_descriptor != descriptor) : Bool)
                              then
                                (do let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                                    sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27146.50-27146.51"
                                    let (descriptor, fault) ← (( do
                                      let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_descriptor walkparams.ee descaccess walkaddress translation_info)
                                      let fault : FaultRecord := tup__0
                                      let descriptor : (BitVec N) := tup__1
                                      (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                                    (if ((bne fault.statuscode Fault_None) : Bool)
                                    then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                    else (do (pure ())))
                                    (pure (descriptor, fault)))
                              else (do (pure (descriptor, fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                            (pure (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate))
                        until (λ (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) => (new_descriptor == descriptor)) loop_vars_1
                        (pure loop_vars_1) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                      (pure (descaddress, descriptor, desctype, fault, skl, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × TTWState) )
              (pure (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate))
          until (λ (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) => (BEq.beq desctype DescriptorType_Leaf)) loop_vars
          (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × AddressDescriptor × TTWState) )
        let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
        let fault ← (( do
          (if ((←((pure (walkstate.contiguous == 1#1)) <&&> (do
               (AArch64_ContiguousBitFaults walkparams.d128 walkparams.txsz walkparams.tgx walkstate.level)))) : Bool)
          then (do (pure { fault with statuscode := Fault_Translation }))
          else
            (do (if ((←((pure ((BEq.beq desctype DescriptorType_Leaf) && (walkstate.level <b FINAL_LEVEL))) <&&> (do
                     (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                then (do (pure { fault with statuscode := Fault_Translation }))
                else
                  (do (if ((← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                      then (do (pure { fault with statuscode := Fault_AddressSize }))
                      else
                        (do (if ((←((pure ((((BitVec.access descriptor 10) : BitVec 1) == 0#1) && (walkparams.ha == 0#1))) <&&> (do
                                 (pure (! (←((pure ((BEq.beq accdesc.acctype AccessType_DC) || (BEq.beq accdesc.acctype AccessType_IC))) <&&> (do (pure (! (← (__IMPDEF_boolean "Generate access flag fault on IC/DC operations")))))))))))) : Bool)
                            then (do (pure { fault with statuscode := Fault_AccessFlag }))
                            else (do (pure fault))))))))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
        (if ((((← readReg __tlb_enabled) && (BEq.beq fault.statuscode Fault_None)) && (((BitVec.access descriptor 10) : BitVec 1) == 1#1)) : Bool)
        then
          (do let tlbcontext : TLBContext := { tlbcontext with xs := walkstate.memattrs.xs }
              let tlbcontext : TLBContext := { tlbcontext with level := walkstate.level }
              let tlbcontext : TLBContext := { tlbcontext with isd128 := (walkparams.d128 == 1#1) }
              let tlbrecord : TLBRecord := { tlbrecord with context := tlbcontext }
              let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
              let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
              let tlbrecord ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (127 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27174.39-27174.40"
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.extractLsb descriptor 127 0) }))
                else
                  (do sail_assert (63 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27177.38-27177.39"
                      let tlbrecord : TLBRecord := { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 63 0 (Sail.BitVec.extractLsb descriptor 63 0)) }
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 127 64 (Zeros (n := 64))) }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              let tlbrecord ← (( do
                (if ((walkstate.contiguous == 1#1) : Bool)
                then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                else (do (pure { tlbrecord with contigsize := 0 }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              (pure (S2TLBCache tlbrecord)))
        else (do (pure ())))
        (pure (fault, walkaddress, walkstate, descriptor))))

def AArch64_SettingAccessFlagPermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if (((BEq.beq fault.statuscode Fault_Alignment) || (BEq.beq fault.statuscode Fault_Permission)) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_AFUPDATE))
        else (do (pure false)))))

def AArch64_SettingDirtyStatePermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if ((BEq.beq fault.statuscode Fault_Alignment) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_DBUPDATE))
        else (do (pure false)))))


end ArmASL.Functions
