import ArmASL.Part08

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def AArch32_EnterHypModeInDebugState (except : ExceptionRecord) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL2)) <&&> (do
    (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))) <&&> (do
    (ELUsingAArch32 EL2)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13905.87-13905.88"
  (AArch32_ReportHypEntry except)
  (AArch32_WriteMode M32_Hyp)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (ELR_hyp_write (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def HVBAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HVBAR ) : SailM HVBAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VBAR_EL2) 0 32)))

/-- Type quantifiers: vect_offset : Int -/
def AArch32_EnterHypMode (except : ExceptionRecord) (preferred_exception_return : (BitVec 32)) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL2)) <&&> (do
    (pure (BEq.beq (← (CurrentSecurityState ())) SS_NonSecure))) <&&> (do
    (ELUsingAArch32 EL2)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13942.87-13942.88"
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterHypModeInDebugState except))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if ((! ((BEq.beq except.exceptype Exception_IRQ) || (BEq.beq except.exceptype Exception_FIQ))) : Bool)
        then (do (AArch32_ReportHypEntry except))
        else (do (pure ())))
        (AArch32_WriteMode M32_Hyp)
        (SPSR_set (N := 32) spsr)
        (ELR_hyp_write preferred_exception_return)
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_HSCTLR_Type_TE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_EA (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with A := 1#1 })
        else (do (pure ())))
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_IRQ (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with I := 1#1 })
        else (do (pure ())))
        (if ((←((pure (! (HaveEL EL3))) <||> (do
             (pure ((_get_SCRType_FIQ (← (SCR_GEN_read ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with F := 1#1 })
        else (do (pure ())))
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_HSCTLR_Type_EE (← (HSCTLR_read ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_HSCTLR_Type_DSSBS (← (HSCTLR_read ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← (HVBAR_read ())) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

/-- Type quantifiers: n : Int -/
def Rmode_set (n : Int) (mode : (BitVec 5)) (value_name : (BitVec 32)) : SailM Unit := do
  sail_assert ((n ≥b 0) && (n ≤b 14)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13980.27-13980.28"
  (if ((bne (← (CurrentSecurityState ())) SS_Secure) : Bool)
  then (do sail_assert (mode != M32_Monitor) "sail-arm/arm-v9.4-a/src/v8_base.sail:13982.34-13982.35")
  else (do (pure ())))
  sail_assert (! (← (BadMode mode))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13984.34-13984.35"
  (if ((mode == M32_Monitor) : Bool)
  then
    (do (if ((n == 13) : Bool)
        then (do writeReg SP_mon value_name)
        else
          (do (if ((n == 14) : Bool)
              then (do writeReg LR_mon value_name)
              else (do (set_R_bits n 31 0 value_name))))))
  else
    (do (if ((←((HaveAArch64 ()) <&&> (do
             (ConstrainUnpredictableBool Unpredictable_ZEROUPPER)))) : Bool)
        then (do (set_R (← (LookUpRIndex n mode)) (Sail.BitVec.zeroExtend value_name 64)))
        else (do (set_R_bits (← (LookUpRIndex n mode)) 31 0 value_name)))))

/-- Type quantifiers: n : Int -/
def R_set (n : Int) (value_name : (BitVec 32)) : SailM Unit := do
  (Rmode_set n (← readReg PSTATE).M value_name)

def AArch32_EnterModeInDebugState (target_mode : (BitVec 5)) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((ELUsingAArch32 EL1) <&&> (do
    (pure ((← readReg PSTATE).EL != EL2))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14014.49-14014.50"
  (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
  then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else (do (pure ())))
  (AArch32_WriteMode target_mode)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (R_set 14 (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((←((HavePANExt ()) <&&> (do
       (pure ((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1))))) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
  else (do (pure ())))
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def ExcVectorBase (_ : Unit) : SailM (BitVec 32) := do
  (if (((_get_SCTLR_Type_V (← (SCTLR_read__2 ()))) == 1#1) : Bool)
  then (do (pure ((Ones (n := 16)) +++ (Zeros (n := 16)))))
  else (do (pure ((Sail.BitVec.extractLsb (← (VBAR_read__2 ())) 31 5) +++ (Zeros (n := 5))))))

/-- Type quantifiers: lr_offset : Int, vect_offset : Int -/
def AArch32_EnterMode (target_mode : (BitVec 5)) (preferred_exception_return : (BitVec 32)) (lr_offset : Int) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((ELUsingAArch32 EL1) <&&> (do
    (pure ((← readReg PSTATE).EL != EL2))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14054.49-14054.50"
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterModeInDebugState target_mode))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
        then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
        else (do (pure ())))
        (AArch32_WriteMode target_mode)
        (SPSR_set (N := 32) spsr)
        (R_set 14 (BitVec.addInt preferred_exception_return lr_offset))
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        (if ((target_mode == M32_FIQ) : Bool)
        then
          (do writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) })
        else
          (do (if (((target_mode == M32_Abort) || (target_mode == M32_IRQ)) : Bool)
              then
                (do writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b11#2 1 1) }
                    writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b11#2 0 0) })
              else (do writeReg PSTATE { (← readReg PSTATE) with I := 1#1 }))))
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((←((HavePANExt ()) <&&> (do
             (pure ((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1))))) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
        else (do (pure ())))
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_SCTLR_Type_DSSBS (← (SCTLR_read__2 ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← (ExcVectorBase ())) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

def AArch32_EnterMonitorModeInDebugState (_ : Unit) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL3)) <&&> (do
    (ELUsingAArch32 EL3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14094.44-14094.45"
  let from_secure ← (( do (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) ) : SailM Bool )
  (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
  then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
  else (do (pure ())))
  (AArch32_WriteMode M32_Monitor)
  (SPSR_set (N := 32) (← (__UNKNOWN_bits 32)))
  (R_set 14 (← (__UNKNOWN_bits 32)))
  writeReg PSTATE { (← readReg PSTATE) with T := 1#1 }
  let split_vec ← do (__UNKNOWN_bits 4)
  writeReg PSTATE { (← readReg PSTATE) with SS := (Sail.BitVec.extractLsb split_vec 3 3) }
  writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
  writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
  writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) }
  writeReg PSTATE { (← readReg PSTATE) with E := (← do
    (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
  writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
  writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
  (if ((← (HavePANExt ())) : Bool)
  then
    (do (if ((! from_secure) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 0#1 })
        else
          (do (if (((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
              else (do (pure ()))))))
  else (do (pure ())))
  (if ((← (HaveSSBSExt ())) : Bool)
  then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (__UNKNOWN_bit ())) })
  else (do (pure ())))
  (DLR_write (← (__UNKNOWN_bits 32)))
  (DSPSR_write (Mk_DSPSR_Type (← (__UNKNOWN_bits 32))))
  (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 1#1))
  (UpdateEDSCRFields ())
  (EndOfInstruction ())

def undefined_MVBAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_MVBAR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

/-- Type quantifiers: lr_offset : Int, vect_offset : Int -/
def AArch32_EnterMonitorMode (preferred_exception_return : (BitVec 32)) (lr_offset : Int) (vect_offset : Int) : SailM Unit := do
  let _ : Unit := (SynchronizeContext ())
  sail_assert (←((pure (HaveEL EL3)) <&&> (do
    (ELUsingAArch32 EL3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14133.44-14133.45"
  let from_secure ← (( do (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) ) : SailM Bool )
  (if ((← (Halted ())) : Bool)
  then (do (AArch32_EnterMonitorModeInDebugState ()))
  else
    (do let spsr ← (( do (GetPSRFromPSTATE AArch32_NonDebugState 32) ) : SailM (BitVec 32) )
        (if (((← readReg PSTATE).M == M32_Monitor) : Bool)
        then (do writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1))
        else (do (pure ())))
        (AArch32_WriteMode M32_Monitor)
        (SPSR_set (N := 32) spsr)
        (R_set 14 (BitVec.addInt preferred_exception_return lr_offset))
        writeReg PSTATE { (← readReg PSTATE) with T := (← do
          (pure (_get_SCTLR_Type_TE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with SS := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb 0b111#3 2 2) }
        writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb 0b111#3 1 1) }
        writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb 0b111#3 0 0) }
        writeReg PSTATE { (← readReg PSTATE) with E := (← do
          (pure (_get_SCTLR_Type_EE (← (SCTLR_read__2 ()))))) }
        writeReg PSTATE { (← readReg PSTATE) with IL := 0#1 }
        writeReg PSTATE { (← readReg PSTATE) with IT := 0b00000000#8 }
        (if ((← (HavePANExt ())) : Bool)
        then
          (do (if ((! from_secure) : Bool)
              then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 0#1 })
              else
                (do (if (((_get_SCTLR_Type_SPAN (← (SCTLR_read__2 ()))) == 0#1) : Bool)
                    then (do writeReg PSTATE { (← readReg PSTATE) with PAN := 1#1 })
                    else (do (pure ()))))))
        else (do (pure ())))
        (if ((← (HaveSSBSExt ())) : Bool)
        then (do writeReg PSTATE { (← readReg PSTATE) with SSBS := (← do (pure (_get_SCTLR_Type_DSSBS (← (SCTLR_read__2 ()))))) })
        else (do (pure ())))
        let branch_conditional : Bool := false
        (BranchTo ((Sail.BitVec.extractLsb (← readReg MVBAR) 31 5) +++ (integer_subrange vect_offset 4 0)) BranchType_EXCEPTION branch_conditional)
        (CheckExceptionCatch true)
        (EndOfInstruction ())))

/-- Type quantifiers: level : Int -/
def EncodeSDFSC (statuscode : Fault) (level : Int) : SailM (BitVec 5) := do
  let result ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  match statuscode with
  | .Fault_AccessFlag =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14174.40-14174.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b00011#5))
      else (do (pure 0b00110#5))))
  | .Fault_Alignment => (pure 0b00001#5)
  | .Fault_Permission =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14181.40-14181.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01101#5))
      else (do (pure 0b01111#5))))
  | .Fault_Domain =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14185.40-14185.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01001#5))
      else (do (pure 0b01011#5))))
  | .Fault_Translation =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14189.40-14189.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b00101#5))
      else (do (pure 0b00111#5))))
  | .Fault_SyncExternal => (pure 0b01000#5)
  | .Fault_SyncExternalOnWalk =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14196.40-14196.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b01100#5))
      else (do (pure 0b01110#5))))
  | .Fault_SyncParity => (pure 0b11001#5)
  | .Fault_SyncParityOnWalk =>
    (do
      sail_assert ((level == 1) || (level == 2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:14203.40-14203.41"
      (if ((level == 1) : Bool)
      then (do (pure 0b11100#5))
      else (do (pure 0b11110#5))))
  | .Fault_AsyncParity => (pure 0b11000#5)
  | .Fault_AsyncExternal => (pure 0b10110#5)
  | .Fault_Debug => (pure 0b00010#5)
  | .Fault_TLBConflict => (pure 0b10000#5)
  | .Fault_Lockdown => (pure 0b10100#5)
  | .Fault_Exclusive => (pure 0b10101#5)
  | .Fault_ICacheMaint => (pure 0b00100#5)
  | _ =>
    (do
      (Unreachable ())
      (pure result))

/-- Type quantifiers: k_long_format : Bool -/
def AArch32_CommonFaultStatus (fault : FaultRecord) (long_format : Bool) : SailM (BitVec 32) := do
  let target : (BitVec 32) := (Zeros (n := 32))
  let target ← (( do
    (if ((←((HaveRASExt ()) <&&> (do
         (IsAsyncAbort__1 fault)))) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange target 15 14 (← (AArch32_EncodeAsyncErrorSyndrome errstate)))))
    else (do (pure target))) ) : SailM (BitVec 32) )
  let target ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update target 12 (Bit fault.extflag))))
    else (do (pure target))) ) : SailM (BitVec 32) )
  let target : (BitVec 32) :=
    (BitVec.update target 9
      (Bit
        (if (long_format : Bool)
        then 1#1
        else 0#1)))
  (if (long_format : Bool)
  then (do (pure (Sail.BitVec.updateSubrange target 5 0 (← (EncodeLDFSC fault.statuscode fault.level)))))
  else
    (do let split_vec ← do (EncodeSDFSC fault.statuscode fault.level)
        let target : (BitVec 32) := (Sail.BitVec.updateSubrange target 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
        (pure (Sail.BitVec.updateSubrange target 3 0 (Sail.BitVec.extractLsb split_vec 3 0)))))

def DFAR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  writeReg FAR_EL1 (Sail.BitVec.updateSubrange (← readReg FAR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DFAR_NS r

def HDFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HDFAR ) : SailM HDFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FAR_EL2) 0 32)))

def DFAR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  (HDFAR_write (set_slice 32 (← (HDFAR_read ())) 0 (BitVec.slice r 0 32)))
  writeReg _DFAR_S r

def DFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (DFAR_S_write r))
  else (do (DFAR_NS_write r)))

def undefined_DFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_VDFSR_Type_AET (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VSESR_EL2_Type_AET (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VDFSR_Type_ExT (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_VSESR_EL2_Type_ExT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def DFSR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFSR_Type := value_name
  writeReg ESR_EL1 (Sail.BitVec.updateSubrange (← readReg ESR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DFSR_NS r

def DFSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DFSR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg DFSR_S r)
  else (do (DFSR_NS_write r)))

def undefined_IFSR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_IFSR32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_IFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_IFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def IFSR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFSR_Type := value_name
  writeReg IFSR32_EL2 (Sail.BitVec.updateSubrange (← readReg IFSR32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _IFSR_NS r

def IFSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFSR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg IFSR_S r)
  else (do (IFSR_NS_write r)))

/-- Type quantifiers: k_route_to_monitor : Bool -/
def AArch32_ReportDataAbort (route_to_monitor : Bool) (fault : FaultRecord) (vaddress : (BitVec 32)) : SailM Unit := do
  let long_format ← (( do (undefined_bool ()) ) : SailM Bool )
  let long_format ← (( do
    (if ((←((pure route_to_monitor) <&&> (do
         (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
    then (do (pure ((_get_TTBCR_Type_EAE (← readReg TTBCR_S)) == 1#1)) <||> (do (IsExternalSyncAbort__1 fault) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1))) <||> (do (pure fault.secondstage) <&&> (do (__IMPDEF_boolean "Report abort using Long-descriptor format"))))))
    else (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)))) ) : SailM Bool )
  let syndrome ← (( do (AArch32_CommonFaultStatus fault long_format) ) : SailM (BitVec 32) )
  let syndrome : (BitVec 32) :=
    if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then
      (let syndrome : (BitVec 32) := (BitVec.update syndrome 13 (Bit 1#1))
      (BitVec.update syndrome 11 (Bit 1#1)))
    else
      (BitVec.update syndrome 11
        (Bit
          (if (fault.write : Bool)
          then 1#1
          else 0#1)))
  let syndrome : (BitVec 32) :=
    if ((! long_format) : Bool)
    then (Sail.BitVec.updateSubrange syndrome 7 4 fault.domain)
    else syndrome
  let syndrome ← (( do
    (if ((BEq.beq fault.access.acctype AccessType_IC) : Bool)
    then
      (do let i_syndrome ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
          let (i_syndrome, syndrome) ← (( do
            (if ((←((pure (! long_format)) <&&> (do
                 (__IMPDEF_boolean "Report I-cache maintenance fault in IFSR")))) : Bool)
            then
              (do let i_syndrome : (BitVec 32) := syndrome
                  let split_vec ← do (EncodeSDFSC Fault_ICacheMaint 1)
                  let syndrome : (BitVec 32) := (Sail.BitVec.updateSubrange syndrome 10 10 (Sail.BitVec.extractLsb split_vec 4 4))
                  let syndrome : (BitVec 32) := (Sail.BitVec.updateSubrange syndrome 3 0 (Sail.BitVec.extractLsb split_vec 3 0))
                  (pure (i_syndrome, syndrome)))
            else
              (do let i_syndrome ← (__UNKNOWN_bits 32)
                  (pure (i_syndrome, syndrome)))) ) : SailM ((BitVec 32) × (BitVec 32)) )
          (if (route_to_monitor : Bool)
          then (do writeReg IFSR_S (Mk_IFSR_Type i_syndrome))
          else (do (IFSR_write (Mk_IFSR_Type i_syndrome))))
          (pure syndrome))
    else (do (pure syndrome))) ) : SailM (BitVec 32) )
  (if (route_to_monitor : Bool)
  then
    (do writeReg DFSR_S (Mk_DFSR_Type syndrome)
        (DFAR_S_write vaddress))
  else
    (do (DFSR_write (Mk_DFSR_Type syndrome))
        (DFAR_write vaddress)))

def undefined_DBGDSCRext_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGDSCRext_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_DBGDSCRext_Type_MDBGen (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 15 x)

def _update_DBGDSCRext_Type_MOE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 2 x)

def _update_DBGDSCRext_Type_UDCCdis (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 12 12 x)

def undefined_DBGDSCRint_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DBGDSCRint_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DBGDSCRint_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDSCRint ) : SailM DBGDSCRint_Type )
  let r ← (pure (Sail.BitVec.updateSubrange r 30 29 (BitVec.slice (← readReg MDCCSR_EL0) 29 2)))
  let r ← (pure (BitVec.update r 15 (Bit (BitVec.slice (← readReg MDSCR_EL1) 15 1))))
  let r ← (pure (BitVec.update r 12 (Bit (BitVec.slice (← readReg MDSCR_EL1) 12 1))))
  (pure (Sail.BitVec.updateSubrange r 5 2 (BitVec.slice (← readReg MDSCR_EL1) 2 4)))

def DBGDSCRext_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDSCRext ) : SailM DBGDSCRext_Type )
  let r ← (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDSCR_EL1) 0 32)))
  let r ← (pure (BitVec.update r 15 (Bit (BitVec.slice (← (DBGDSCRint_read ())) 15 1))))
  let r ← (pure (BitVec.update r 12 (Bit (BitVec.slice (← (DBGDSCRint_read ())) 12 1))))
  (pure (Sail.BitVec.updateSubrange r 5 2 (BitVec.slice (← (DBGDSCRint_read ())) 2 4)))

def DBGDSCRint_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDSCRint_Type := value_name
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 29 (BitVec.slice r 29 2))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 15 (Bit (BitVec.slice r 15 1)))
  writeReg MDSCR_EL1 (BitVec.update (← readReg MDSCR_EL1) 12 (Bit (BitVec.slice r 12 1)))
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 5 2 (BitVec.slice r 2 4))
  writeReg _DBGDSCRint r

def DBGDSCRext_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDSCRext_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 31 0 (BitVec.slice r 0 32))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 1 (← (DBGDSCRint_read ())) 15 (BitVec.slice r 15 1))))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 1 (← (DBGDSCRint_read ())) 12 (BitVec.slice r 12 1))))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 4 (← (DBGDSCRint_read ())) 2 (BitVec.slice r 2 4))))
  writeReg _DBGDSCRext r

def undefined_HCR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HCR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HCR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HCR2 ) : SailM HCR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HCR_EL2) 32 32)))

def IsDebugException (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:14522.41-14522.42"
  (pure (BEq.beq fault.statuscode Fault_Debug))

def AArch32_TakeDataAbortException (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))) <&&> (do (IsExternalAbort__1 fault)) ) : SailM Bool )
  let route_to_hyp ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR2_Type_TEA (← (HCR2_read ()))) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_HDCR_Type_TDE (← (HDCR_read ()))) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x10#8)
  let lr_offset := 8
  (if ((← (IsDebugException fault)) : Bool)
  then (do (DBGDSCRext_write (_update_DBGDSCRext_Type_MOE (← (DBGDSCRext_read ())) fault.debugmoe)))
  else (do (pure ())))
  (if (route_to_monitor : Bool)
  then
    (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do (AArch32_AbortSyndrome Exception_DataAbort fault vaddress EL2) ) : SailM ExceptionRecord )
              (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (AArch32_ReportDataAbort route_to_monitor fault vaddress)
              (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)))))

def IFAR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  writeReg FAR_EL1 (Sail.BitVec.updateSubrange (← readReg FAR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _IFAR_NS r

def HIFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HIFAR ) : SailM HIFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FAR_EL2) 32 32)))

def IFAR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  (if ((HaveEL EL2) : Bool)
  then (do writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 63 32 (BitVec.slice r 0 32)))
  else (do (HIFAR_write (set_slice 32 (← (HIFAR_read ())) 0 (BitVec.slice r 0 32)))))
  writeReg _IFAR_S r

def IFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : IFAR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (IFAR_S_write r))
  else (do (IFAR_NS_write r)))

/-- Type quantifiers: k_route_to_monitor : Bool -/
def AArch32_ReportPrefetchAbort (route_to_monitor : Bool) (fault : FaultRecord) (vaddress : (BitVec 32)) : SailM Unit := do
  let long_format : Bool := false
  let long_format ← (( do
    (if ((←((pure route_to_monitor) <&&> (do
         (pure (bne (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
    then (do (pure ((_get_TTBCR_Type_EAE (← readReg TTBCR_S)) == 1#1)) <||> (do (pure ((← readReg PSTATE).EL == EL2))) <||> (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1))))
    else (do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)))) ) : SailM Bool )
  let fsr ← (( do (AArch32_CommonFaultStatus fault long_format) ) : SailM (BitVec 32) )
  (if (route_to_monitor : Bool)
  then
    (do writeReg IFSR_S (Mk_IFSR_Type fsr)
        (IFAR_S_write vaddress))
  else
    (do (IFSR_write (Mk_IFSR_Type fsr))
        (IFAR_write vaddress)))

def AArch32_TakePrefetchAbortException (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let route_to_monitor ← (( do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))) <&&> (do (IsExternalAbort__1 fault)) ) : SailM Bool )
  let route_to_hyp ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR2_Type_TEA (← (HCR2_read ()))) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_HDCR_Type_TDE (← (HDCR_read ()))) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x0C#8)
  let lr_offset := 4
  (if ((← (IsDebugException fault)) : Bool)
  then (do (DBGDSCRext_write (_update_DBGDSCRext_Type_MOE (← (DBGDSCRext_read ())) fault.debugmoe)))
  else (do (pure ())))
  (if (route_to_monitor : Bool)
  then
    (do (AArch32_ReportPrefetchAbort route_to_monitor fault vaddress)
        (AArch32_EnterMonitorMode preferred_exception_return lr_offset vect_offset))
  else
    (do (if ((((← readReg PSTATE).EL == EL2) || route_to_hyp) : Bool)
        then
          (do let except ← (( do
                (if ((BEq.beq fault.statuscode Fault_Alignment) : Bool)
                then
                  (do let except ← (ExceptionSyndrome Exception_PCAlignment)
                      (pure { except with vaddress := (← do (ThisInstrAddr 64)) }))
                else (do (AArch32_AbortSyndrome Exception_InstructionAbort fault vaddress EL2))) ) : SailM ExceptionRecord )
              (if (((← readReg PSTATE).EL == EL2) : Bool)
              then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
              else (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))))
        else
          (do (AArch32_ReportPrefetchAbort route_to_monitor fault vaddress)
              (AArch32_EnterMode M32_Abort preferred_exception_return lr_offset vect_offset)))))

def AArch64_EncodeSyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 2) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b10#2)
  | .ErrorState_UEO => (pure 0b11#2)
  | .ErrorState_UER => (pure 0b00#2)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 2))

def ExtAbortToA64 (fault : FaultRecord) : SailM Bool := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (IsSecondStage fault)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR_EL2_Type_TEA (← readReg HCR_EL2)) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((_get_SCRType_EA (← (SCR_GEN_read ()))) == 1#1)) <&&> (do (IsExternalAbort__1 fault)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (pure route_to_aarch64) <&&> (do
    (IsExternalSyncAbort fault.statuscode))

def FaultIsCorrected (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsIMPDEF (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUncategorized (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch64_PEErrorState (fault : FaultRecord) : SailM ErrorState := SailME.run do
  (if ((←((pure (! (← (IsExternalSyncAbort__1 fault)))) <&&> (do
       (ExtAbortToA64 fault)))) : Bool)
  then
    (do (if ((← (ReportErrorAsUncategorized ())) : Bool)
        then (do SailME.throw (ErrorState_Uncategorized : ErrorState))
        else
          (do (if ((← (ReportErrorAsIMPDEF ())) : Bool)
              then (do SailME.throw (ErrorState_IMPDEF : ErrorState))
              else (do (pure ()))))))
  else (do (pure ())))
  sail_assert (! (← (FaultIsCorrected ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:14707.39-14707.40"
  (if ((←((pure (! (← (ErrorIsContained ())))) <||> (do
       (pure (! (← (ErrorIsSynchronized ())))) <&&> (do
         (pure (! (← (StateIsRecoverable ())))))) <||> (do
       (ReportErrorAsUC ())))) : Bool)
  then (do (pure ErrorState_UC))
  else
    (do (if ((←((pure (! (← (StateIsRecoverable ())))) <||> (do
             (ReportErrorAsUEU ())))) : Bool)
        then
          (do (if ((← (IsExternalSyncAbort__1 fault)) : Bool)
              then (do (pure ErrorState_UC))
              else (do (pure ErrorState_UEU))))
        else
          (do (if ((←((ActionRequired ()) <||> (do
                   (ReportErrorAsUER ())))) : Bool)
              then (do (pure ErrorState_UER))
              else (do (pure ErrorState_UEO)))))))

def HaveFeatLS64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LS64)

def GetLoadStoreType (_ : Unit) : SailM (BitVec 2) := do
  (__UNKNOWN_bits 2)

def LS64InstructionSyndrome (_ : Unit) : SailM ((BitVec 24) × (BitVec 11)) := do
  (pure ((← (undefined_bitvector 24)), (← (undefined_bitvector 11))))

/-- Type quantifiers: k_d_side : Bool, k_pavalid : Bool -/
def AArch64_FaultSyndrome (d_side : Bool) (fault : FaultRecord) (pavalid : Bool) : SailM ((BitVec 25) × (BitVec 24)) := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:14736.41-14736.42"
  let iss : (BitVec 25) := (Zeros (n := 25))
  let iss2 : (BitVec 24) := (Zeros (n := 24))
  let iss ← (( do
    (if (((← (HaveRASExt ())) && (BEq.beq fault.statuscode Fault_SyncExternal)) : Bool)
    then
      (do let errstate ← (( do (AArch64_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange iss 12 11 (← (AArch64_EncodeSyncErrorSyndrome errstate)))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let (iss, iss2) ← (( do
    (if (d_side : Bool)
    then
      (do let iss2 : (BitVec 24) :=
            if ((BEq.beq fault.access.acctype AccessType_GCS) : Bool)
            then (BitVec.update iss2 8 (Bit 1#1))
            else iss2
          let (iss, iss2) ← (( do
            (if (((← (HaveFeatLS64 ())) && fault.access.ls64) : Bool)
            then
              (do let (iss, iss2) ← (( do
                    (if (((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_Permission))) : Bool)
                    then
                      (do let (tup__0, tup__1) ← do (LS64InstructionSyndrome ())
                          let iss2 : (BitVec 24) := tup__0
                          let iss : (BitVec 25) := (Sail.BitVec.updateSubrange iss 24 14 tup__1)
                          (pure (iss, iss2)))
                    else (do (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
                  (pure (iss, iss2)))
            else
              (do let iss ← (( do
                    (if ((←((pure ((← (IsSecondStage fault)) && (! fault.s2fs1walk))) <&&> (do
                         (pure (! (← (IsExternalSyncAbort__1 fault)))) <||> (do
                           (pure ((! (← (HaveRASExt ()))) && (BEq.beq fault.access.acctype AccessType_TTW))) <&&> (do
                             (__IMPDEF_boolean "ISV on second stage translation table walk")))))) : Bool)
                    then (do (pure (Sail.BitVec.updateSubrange iss 24 14 (LSInstructionSyndrome ()))))
                    else (do (pure iss))) ) : SailM (BitVec 25) )
                  (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
          let iss ← (( do
            (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
            then (do (pure (BitVec.update iss 13 (Bit 1#1))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss ← (( do
            (if (((← (HaveFeatLS64 ())) && ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_Permission)))) : Bool)
            then (do (pure (Sail.BitVec.updateSubrange iss 12 11 (← (GetLoadStoreType ())))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss : (BitVec 25) :=
            if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (BitVec.update iss 8 (Bit 1#1))
            else iss
          let iss ← (( do
            (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (do (pure (BitVec.update iss 6 (Bit 1#1))))
            else
              (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
                  then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                  else
                    (do (if ((←((pure fault.access.atomicop) <&&> (do
                             (IsExternalAbort__1 fault)))) : Bool)
                        then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                        else
                          (do (pure (BitVec.update iss 6
                                  (Bit
                                    (if (fault.write : Bool)
                                    then 1#1
                                    else 0#1)))))))))) ) : SailM (BitVec 25) )
          let (iss, iss2) : ((BitVec 25) × (BitVec 24)) :=
            if ((BEq.beq fault.statuscode Fault_Permission) : Bool)
            then
              (let iss2 : (BitVec 24) :=
                (BitVec.update iss2 5
                  (Bit
                    (if (fault.dirtybit : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 6
                  (Bit
                    (if (fault.overlay : Bool)
                    then 1#1
                    else 0#1)))
              let iss : (BitVec 25) :=
                if ((((BitVec.access iss 24) : BitVec 1) == 0#1) : Bool)
                then
                  (BitVec.update iss 21
                    (Bit
                      (if (fault.toplevel : Bool)
                      then 1#1
                      else 0#1)))
                else iss
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 7
                  (Bit
                    (if (fault.assuredonly : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 9
                  (Bit
                    (if (fault.tagaccess : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 10
                  (Bit
                    (if (fault.s1tagnotdata : Bool)
                    then 1#1
                    else 0#1)))
              (iss, iss2))
            else (iss, iss2)
          (pure (iss, iss2)))
    else
      (do let (iss, iss2) : ((BitVec 25) × (BitVec 24)) :=
            if (((BEq.beq fault.access.acctype AccessType_IFETCH) && (BEq.beq fault.statuscode Fault_Permission)) : Bool)
            then
              (let iss2 : (BitVec 24) :=
                (BitVec.update iss2 5
                  (Bit
                    (if (fault.dirtybit : Bool)
                    then 1#1
                    else 0#1)))
              let iss : (BitVec 25) :=
                (BitVec.update iss 21
                  (Bit
                    (if (fault.toplevel : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 7
                  (Bit
                    (if (fault.assuredonly : Bool)
                    then 1#1
                    else 0#1)))
              let iss2 : (BitVec 24) :=
                (BitVec.update iss2 6
                  (Bit
                    (if (fault.overlay : Bool)
                    then 1#1
                    else 0#1)))
              (iss, iss2))
            else (iss, iss2)
          (pure (iss, iss2)))) ) : SailM ((BitVec 25) × (BitVec 24)) )
  let iss ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update iss 9 (Bit fault.extflag))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss : (BitVec 25) :=
    (BitVec.update iss 7
      (Bit
        (if (fault.s2fs1walk : Bool)
        then 1#1
        else 0#1)))
  let iss ← (pure (Sail.BitVec.updateSubrange iss 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))
  (pure (iss, iss2))

def AArch64_AbortSyndrome (exceptype : Exception) (fault : FaultRecord) (vaddress : (BitVec 64)) (target_el : (BitVec 2)) : SailM ExceptionRecord := do
  let except ← (( do (ExceptionSyndrome exceptype) ) : SailM ExceptionRecord )
  let d_side : Bool := ((BEq.beq exceptype Exception_DataAbort) || ((BEq.beq exceptype Exception_NV2DataAbort) || ((BEq.beq exceptype Exception_Watchpoint) || (BEq.beq exceptype Exception_NV2Watchpoint))))
  let except ← (( do
    (if ((←((pure (! (← (HavePFAR ())))) <||> (do
         (pure (! (← (IsExternalSyncAbort__1 fault))))) <||> (do
         (pure ((←((EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))))) && (target_el == EL1)))))) : Bool)
    then (do (pure { except with pavalid := false }))
    else (do (pure { except with pavalid := (← do (__IMPDEF_boolean "PFAR_ELx is valid")) }))) ) : SailM ExceptionRecord )
  let except ← (( do
    let (tup__0, tup__1) ← do (AArch64_FaultSyndrome d_side fault except.pavalid)
    let except : ExceptionRecord := { except with syndrome := tup__0 }
    (pure { except with syndrome2 := tup__1 }) ) : SailM ExceptionRecord )
  let except ← (( do
    (if ((BEq.beq fault.statuscode Fault_TagCheck) : Bool)
    then
      (do (if ((← (HaveMTE4Ext ())) : Bool)
          then (do (pure { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }))
          else (do (pure { except with vaddress := (← do (pure ((← (__UNKNOWN_bits 4)) +++ (Sail.BitVec.extractLsb vaddress 59 0)))) }))))
    else (do (pure { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }))) ) : SailM ExceptionRecord )
  (if ((← (IPAValid fault)) : Bool)
  then
    (do let except : ExceptionRecord := { except with ipavalid := true }
        let except : ExceptionRecord :=
          { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
            then 1#1
            else 0#1 }
        (pure { except with ipaddress := fault.ipaddress.address }))
  else (do (pure { except with ipavalid := false })))

def AArch64_BreakpointException (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:14835.27-14835.28"
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
    then (do (pure EL2))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  let vaddress ← (( do (__UNKNOWN_bits 64) ) : SailM (BitVec 64) )
  let except ← (( do (AArch64_AbortSyndrome Exception_Breakpoint fault vaddress target_el) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def HaveDoubleFault2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_DoubleFault2)

def HaveFeatSCTLR2 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SCTLR2)

def IsSCTLR2EL1Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatSCTLR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_SCTLR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (! (← (IsHCRXEL2Enabled ())))) <||> (do
                     (pure ((_get_HCRX_EL2_Type_SCTLR2En (← readReg HCRX_EL2)) == 0#1)))))) : Bool)
              then (do (pure false))
              else (do (pure true)))))))

def IsSCTLR2EL2Enabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveFeatSCTLR2 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (pure ((_get_SCR_EL3_Type_SCTLR2En (← readReg SCR_EL3)) == 0#1))))) : Bool)
        then (do (pure false))
        else (do (EL2Enabled ())))))

def undefined_SCTLR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR2_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SCTLR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SCTLR2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_SCTLR2_EL2_Type_EMEC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SCTLR2_EL3_Type_EMEC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def AArch64_RouteToSErrorOffset (target_el : (BitVec 2)) : SailM Bool := do
  (if ((! (← (HaveDoubleFaultExt ()))) : Bool)
  then (do (pure false))
  else
    (do let ease_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let ease_bit ← (( do
          let questionMark := target_el
          (if ((questionMark == EL3) : Bool)
          then (do (pure (_get_SCR_EL3_Type_EASE (← readReg SCR_EL3))))
          else
            (do (if ((questionMark == EL2) : Bool)
                then
                  (do (if ((←((HaveDoubleFault2Ext ()) <&&> (do
                           (IsSCTLR2EL2Enabled ())))) : Bool)
                      then (do (pure (_get_SCTLR2_EL2_Type_EASE (← readReg SCTLR2_EL2))))
                      else (do (pure 0#1))))
                else
                  (do (if ((questionMark == EL1) : Bool)
                      then
                        (do (if ((←((HaveDoubleFault2Ext ()) <&&> (do
                                 (IsSCTLR2EL1Enabled ())))) : Bool)
                            then (do (pure (_get_SCTLR2_EL1_Type_EASE (← readReg SCTLR2_EL1))))
                            else (do (pure 0#1))))
                      else (do (pure ease_bit))))))) ) : SailM (BitVec 1) )
        (pure (ease_bit == 1#1))))

def AArch64_SyncExternalAbortTarget (fault : FaultRecord) : SailM (BitVec 2) := do
  let route_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el3 ← (( do
    (if (((← readReg PSTATE).EL != EL3) : Bool)
    then (do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))))
    else (do (pure false))) ) : SailM Bool )
  let tea_bit ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure (_get_HCR_EL2_Type_TEA (← readReg HCR_EL2))))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el2 ← (( do
    (if ((←((pure (! route_to_el3)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
    then (do (pure ((tea_bit == 1#1) || (BEq.beq fault.access.acctype AccessType_NV2))) <||> (do (IsSecondStage fault)))
    else
      (do (if ((←((pure (! route_to_el3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then (do (pure (! (← (IsInHost ())))) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1) || (tea_bit == 1#1))) <||> (do (IsSecondStage fault))))
          else (do (pure false))))) ) : SailM Bool )
  let route_masked_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_masked_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (route_masked_to_el2, route_masked_to_el3) ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let route_masked_to_el2 ← (pure ((← (EL2Enabled ())) && (! route_to_el3))) <&&> (do (pure ((← readReg PSTATE).EL == EL1)) <&&> (do (pure ((← readReg PSTATE).A == 1#1)))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_TMEA (← readReg HCRX_EL2)) == 1#1)))
          let route_masked_to_el3 ← (pure ((HaveEL EL3) && (! (route_to_el2 || route_masked_to_el2)))) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure ((← readReg PSTATE).A == 1#1)))) <&&> (do (pure ((_get_SCR_EL3_Type_TMEA (← readReg SCR_EL3)) == 1#1)))
          (pure (route_masked_to_el2, route_masked_to_el3)))
    else
      (do let route_masked_to_el2 : Bool := false
          let route_masked_to_el3 : Bool := false
          (pure (route_masked_to_el2, route_masked_to_el3)))) ) : SailM (Bool × Bool) )
  let take_in_el3 ← (( do (pure ((← readReg PSTATE).EL == EL3)) ) : SailM Bool )
  let take_in_el2_0 ← (( do (pure ((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do (IsInHost ())))) && (! (route_to_el3 || route_masked_to_el3)))) ) : SailM Bool )
  let take_in_el1_0 ← (( do (pure (((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (IsInHost ())))))))) && (! (route_to_el2 || route_masked_to_el2))) && (! (route_to_el3 || route_masked_to_el3)))) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  (if (((take_in_el3 || route_to_el3) || route_masked_to_el3) : Bool)
  then (do (pure EL3))
  else
    (do (if (((take_in_el2_0 || route_to_el2) || route_masked_to_el2) : Bool)
        then (do (pure EL2))
        else
          (do (if (take_in_el1_0 : Bool)
              then (do (pure EL1))
              else
                (do sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:14970.20-14970.21"
                    throw Error.Exit))))))

def take_exception (fault : (Option FaultRecord)) : SailM Unit := do
  (sail_take_exception fault)

def AArch64_DataAbort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (AArch64_SyncExternalAbortTarget fault))
    else
      (do let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((← (HaveRME ())) && (BEq.beq fault.gpcf.gpf GPCF_Fail))) <&&> (do (pure ((_get_HCR_EL2_Type_GPF (← readReg HCR_EL2)) == 1#1)))) <||> (do (pure ((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL3) : Bool)
          then (do (pure EL3))
          else
            (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
                then (do (pure EL2))
                else (do (pure EL1))))))) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (AArch64_AbortSyndrome Exception_NV2DataAbort fault vaddress target_el))
    else (do (AArch64_AbortSyndrome Exception_DataAbort fault vaddress target_el))) ) : SailM ExceptionRecord )
  (take_exception (some fault))
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_InstructionAbort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (HaveDoubleFaultExt ())) : Bool)
  then (do sail_assert (bne fault.statuscode Fault_AsyncExternal) "sail-arm/arm-v9.4-a/src/v8_base.sail:15017.54-15017.55")
  else (do (pure ())))
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let target_el ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (AArch64_SyncExternalAbortTarget fault))
    else
      (do let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1)))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((← (HaveRME ())) && (BEq.beq fault.gpcf.gpf GPCF_Fail))) <&&> (do (pure ((_get_HCR_EL2_Type_GPF (← readReg HCR_EL2)) == 1#1)))) <||> (do (IsSecondStage fault))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL3) : Bool)
          then (do (pure EL3))
          else
            (do (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
                then (do (pure EL2))
                else (do (pure EL1))))))) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  let except ← (( do (AArch64_AbortSyndrome Exception_InstructionAbort fault vaddress target_el) ) : SailM ExceptionRecord )
  (take_exception (some fault))
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_VectorCatchException (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL2) "sail-arm/arm-v9.4-a/src/v8_base.sail:15048.27-15048.28"
  sail_assert (←((EL2Enabled ()) <&&> (do
    (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do
      (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15049.70-15049.71"
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let vaddress ← (( do (__UNKNOWN_bits 64) ) : SailM (BitVec 64) )
  let except ← (( do (AArch64_AbortSyndrome Exception_VectorCatch fault vaddress EL2) ) : SailM ExceptionRecord )
  (AArch64_TakeException EL2 except preferred_exception_return vect_offset)

def AArch64_WatchpointException (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  sail_assert ((← readReg PSTATE).EL != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:15060.27-15060.28"
  let route_to_el2 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let target_el ← (( do
    (if ((((← readReg PSTATE).EL == EL2) || route_to_el2) : Bool)
    then (do (pure EL2))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (AArch64_AbortSyndrome Exception_NV2Watchpoint fault vaddress target_el))
    else (do (AArch64_AbortSyndrome Exception_Watchpoint fault vaddress target_el))) ) : SailM ExceptionRecord )
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def ReportAsGPCException (fault : FaultRecord) : SailM Bool := do
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15078.20-15078.21"
  sail_assert ((BEq.beq fault.statuscode Fault_GPCFOnWalk) || (BEq.beq fault.statuscode Fault_GPCFOnOutput)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15079.88-15079.89"
  sail_assert (bne fault.gpcf.gpf GPCF_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:15080.38-15080.39"
  match fault.gpcf.gpf with
  | .GPCF_Walk => (pure true)
  | .GPCF_AddressSize => (pure true)
  | .GPCF_EABT => (pure true)
  | .GPCF_Fail => (pure ((_get_SCR_EL3_Type_GPF (← readReg SCR_EL3)) == 1#1)) <&&> (do (pure ((← readReg PSTATE).EL != EL3)))
  | _ => (do (undefined_bool ()))

def EncodeGPCSC (gpcf : GPCFRecord) : SailM (BitVec 6) := do
  sail_assert ((gpcf.level == 0) || (gpcf.level == 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15103.44-15103.45"
  match gpcf.gpf with
  | .GPCF_AddressSize => (pure (0b00000#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_Walk => (pure (0b00010#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_Fail => (pure (0b00110#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | .GPCF_EABT => (pure (0b01010#5 +++ ((integer_access gpcf.level 0) : BitVec 1)))
  | _ => (do (undefined_bitvector 6))

def HaveAccessFlagUpdateExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFDBS)

def HaveAtomicExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LSE)

def HaveDirtyBitModifierExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HAFDBS)

def TakeGPCException (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  sail_assert (← (HaveRME ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15144.20-15144.21"
  sail_assert (← (HaveAtomicExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15145.26-15145.27"
  sail_assert (← (HaveAccessFlagUpdateExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15146.36-15146.37"
  sail_assert (← (HaveDirtyBitModifierExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15147.36-15147.37"
  sail_assert (← (HaveDoubleFaultExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:15148.31-15148.32"
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with exceptype := Exception_GPC }
  let except : ExceptionRecord := { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }
  let except : ExceptionRecord := { except with paddress := fault.paddress }
  let except : ExceptionRecord := { except with pavalid := true }
  let except ← (( do
    (if ((← (IPAValid fault)) : Bool)
    then
      (do let except : ExceptionRecord := { except with ipavalid := true }
          let except : ExceptionRecord :=
            { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
              then 1#1
              else 0#1 }
          (pure { except with ipaddress := fault.ipaddress.address }))
    else (do (pure { except with ipavalid := false }))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord :=
    if ((BEq.beq fault.access.acctype AccessType_GCS) : Bool)
    then { except with syndrome2 := (BitVec.update except.syndrome2 8 (Bit 1#1)) }
    else except
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 22 (Zeros (n := 3))) }
  let except : ExceptionRecord :=
    { except with syndrome := (BitVec.update except.syndrome 21
        (Bit
          (if (fault.gpcfs2walk : Bool)
          then 1#1
          else 0#1))) }
  let except : ExceptionRecord :=
    if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
    then { except with syndrome := (BitVec.update except.syndrome 20 (Bit 1#1)) }
    else { except with syndrome := (BitVec.update except.syndrome 20 (Bit 0#1)) }
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 19 14 (← (EncodeGPCSC fault.gpcf))))) })
  let except ← (( do
    (if (((← (HaveNV2Ext ())) && (BEq.beq fault.access.acctype AccessType_NV2)) : Bool)
    then (do (pure { except with syndrome := (BitVec.update except.syndrome 13 (Bit 1#1)) }))
    else (do (pure { except with syndrome := (BitVec.update except.syndrome 13 (Bit 0#1)) }))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 12 11 0b00#2) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 10 9 0b00#2) }
  let except : ExceptionRecord :=
    if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then { except with syndrome := (BitVec.update except.syndrome 8 (Bit 1#1)) }
    else { except with syndrome := (BitVec.update except.syndrome 8 (Bit 0#1)) }
  let except : ExceptionRecord :=
    { except with syndrome := (BitVec.update except.syndrome 7
        (Bit
          (if (fault.s2fs1walk : Bool)
          then 1#1
          else 0#1))) }
  let except ← (( do
    (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
    then (do (pure { except with syndrome := (BitVec.update except.syndrome 6 (Bit 1#1)) }))
    else
      (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
          then (do (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 6 (Bit (← (__UNKNOWN_bit ())))))) }))
          else
            (do (if ((←((pure fault.access.atomicop) <&&> (do
                     (IsExternalAbort__1 fault)))) : Bool)
                then (do (pure { except with syndrome := (← do (pure (BitVec.update except.syndrome 6 (Bit (← (__UNKNOWN_bit ())))))) }))
                else
                  (do (pure { except with syndrome := (BitVec.update except.syndrome 6
                            (Bit
                              (if (fault.write : Bool)
                              then 1#1
                              else 0#1))) }))))))) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))) })
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let target_el : (BitVec 2) := EL3
  let vect_offset ← (( do (undefined_int ()) ) : SailM Int )
  let vect_offset ← (( do
    (if ((←((IsExternalAbort__1 fault) <&&> (do
         (AArch64_RouteToSErrorOffset target_el)))) : Bool)
    then (do (pure (BitVec.toNat 0x180#12)))
    else (do (pure (BitVec.toNat 0x0#4)))) ) : SailM Int )
  let vect_offset := vect_offset
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def AArch64_Abort (vaddress : (BitVec 64)) (fault : FaultRecord) : SailM Unit := do
  (if ((← (IsDebugException fault)) : Bool)
  then
    (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
        then
          (do (if (((← (UsingAArch32 ())) && (fault.debugmoe == DebugException_VectorCatch)) : Bool)
              then (do (AArch64_VectorCatchException fault))
              else (do (AArch64_BreakpointException fault))))
        else (do (AArch64_WatchpointException vaddress fault))))
  else
    (do (if ((←((pure (bne fault.gpcf.gpf GPCF_None)) <&&> (do
             (ReportAsGPCException fault)))) : Bool)
        then (do (TakeGPCException vaddress fault))
        else
          (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
              then (do (AArch64_InstructionAbort vaddress fault))
              else (do (AArch64_DataAbort vaddress fault)))))))

def AArch32_Abort (vaddress : (BitVec 32)) (fault : FaultRecord) : SailM Unit := do
  let route_to_aarch64 ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (ELUsingAArch32 EL1))))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure (! route_to_aarch64)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure (! (← (ELUsingAArch32 EL2))))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1)) <||> (do (IsSecondStage fault)) <||> (do (HaveRASExt ()) <&&> (do (pure ((_get_HCR_EL2_Type_TEA (← readReg HCR_EL2)) == 1#1))) <&&> (do (IsExternalAbort__1 fault))) <||> (do (IsDebugException fault) <&&> (do (pure ((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) == 1#1)))))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  let route_to_aarch64 ← (( do
    (if ((←((pure ((! route_to_aarch64) && (HaveEL EL3))) <&&> (do
         (pure (! (← (ELUsingAArch32 EL3))))))) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 1#1)) <&&> (do (IsExternalAbort__1 fault)))
    else (do (pure route_to_aarch64))) ) : SailM Bool )
  (if (route_to_aarch64 : Bool)
  then (do (AArch64_Abort (Sail.BitVec.zeroExtend vaddress 64) fault))
  else
    (do (if ((BEq.beq fault.access.acctype AccessType_IFETCH) : Bool)
        then (do (AArch32_TakePrefetchAbortException vaddress fault))
        else (do (AArch32_TakeDataAbortException vaddress fault)))))

def GPCNoFault (_ : Unit) : SailM GPCFRecord := do
  let result ← (( do (undefined_GPCFRecord ()) ) : SailM GPCFRecord )
  (pure { result with gpf := GPCF_None })

def NoFault (_ : Unit) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault ← (pure { fault with access := (← do (__UNKNOWN_AccessDescriptor ())) })
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with dirtybit := false }
  let fault : FaultRecord := { fault with overlay := false }
  let fault : FaultRecord := { fault with toplevel := false }
  let fault : FaultRecord := { fault with assuredonly := false }
  let fault : FaultRecord := { fault with s1tagnotdata := false }
  let fault : FaultRecord := { fault with tagaccess := false }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

def NoFault__1 (accdesc : AccessDescriptor) : SailM FaultRecord := do
  let fault ← (( do (undefined_FaultRecord ()) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault : FaultRecord := { fault with access := accdesc }
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  let fault : FaultRecord := { fault with dirtybit := false }
  let fault : FaultRecord := { fault with overlay := false }
  let fault : FaultRecord := { fault with toplevel := false }
  let fault : FaultRecord := { fault with assuredonly := false }
  let fault : FaultRecord := { fault with s1tagnotdata := false }
  let fault : FaultRecord := { fault with tagaccess := false }
  let fault : FaultRecord := { fault with write := ((! accdesc.read) && accdesc.write) }
  let fault : FaultRecord := { fault with gpcfs2walk := false }
  (pure { fault with gpcf := (← do (GPCNoFault ())) })

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def HandleExternalAbort (memretstatus : PhysMemRetStatus) (iswrite : Bool) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  sail_assert (←((pure ((BEq.beq memretstatus.statuscode Fault_SyncExternal) || (BEq.beq memretstatus.statuscode Fault_AsyncExternal))) <||> (do
    (pure ((! (← (HaveRASExt ()))) && ((BEq.beq memretstatus.statuscode Fault_SyncParity) || (BEq.beq memretstatus.statuscode Fault_AsyncParity))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15300.227-15300.228"
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let fault : FaultRecord := { fault with statuscode := memretstatus.statuscode }
  let fault : FaultRecord := { fault with write := iswrite }
  let fault : FaultRecord := { fault with extflag := memretstatus.extflag }
  let fault ← (( do
    (if ((←((IsExternalSyncAbort__1 fault) <&&> (do
         (pure (! (← (IsExternalAbortTakenSynchronously memretstatus iswrite memaddrdesc size accdesc))))))) : Bool)
    then
      (do (if ((BEq.beq fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { fault with statuscode := Fault_AsyncParity }))
          else (do (pure { fault with statuscode := Fault_AsyncExternal }))))
    else (do (pure fault))) ) : SailM FaultRecord )
  let fault ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure { fault with merrorstate := memretstatus.merrorstate }))
    else (do (pure fault))) ) : SailM FaultRecord )
  (if ((← (IsExternalSyncAbort__1 fault)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (AArch32_Abort (Sail.BitVec.extractLsb memaddrdesc.vaddress 31 0) fault))
        else (do (AArch64_Abort memaddrdesc.vaddress fault))))
  else (do (pure (PendSErrorInterrupt fault))))

/-- Type quantifiers: size : Int -/
def HandleExternalReadAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := false
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

/-- Type quantifiers: size : Int -/
def HandleExternalWriteAbort (memstatus : PhysMemRetStatus) (memaddrdesc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Unit := do
  let iswrite : Bool := true
  (HandleExternalAbort memstatus iswrite memaddrdesc size accdesc)

def HCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCR r

def ClearPendingVirtualSError (_ : Unit) : SailM Unit := do
  (if ((← (ELUsingAArch32 EL2)) : Bool)
  then (do (HCR_write (_update_HCR_Type_VA (← (HCR_read ())) 0#1)))
  else (do writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1)))

def IsSErrorEdgeTriggered (_ : Unit) : SailM Bool := do
  (if ((← (HaveDoubleFaultExt ())) : Bool)
  then (do (pure true))
  else (do (__IMPDEF_boolean "Edge-triggered SError")))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPInfinity (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15378.38-15378.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPMaxNormal (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15389.38-15389.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := ((Ones (n := (E -i 1))) +++ 0#1)
  let frac : (BitVec F) := (Ones (n := F))
  (pure ((sign +++ exp) +++ frac))

def AArch32_GeneralExceptionsToAArch64 (_ : Unit) : SailM Bool := do
  (pure ((← readReg PSTATE).EL == EL0)) <&&> (do
    (pure (! (← (ELUsingAArch32 EL1))))) <||> (do
    (EL2Enabled ()) <&&> (do
      (pure (! (← (ELUsingAArch32 EL2))))) <&&> (do
      (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))

def AArch32_TakeUndefInstrException__1 (except : ExceptionRecord) : SailM Unit := do
  let route_to_hyp ← (( do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_Type_TGE (← (HCR_read ()))) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 32) ) : SailM (BitVec 32) )
  let vect_offset := (BitVec.toNat 0x04#8)
  let lr_offset ← (( do
    (if ((BEq.beq (← (CurrentInstrSet ())) InstrSet_A32) : Bool)
    then (do (pure 4))
    else (do (pure 2))) ) : SailM Int )
  (if (((← readReg PSTATE).EL == EL2) : Bool)
  then (do (AArch32_EnterHypMode except preferred_exception_return vect_offset))
  else
    (do (if (route_to_hyp : Bool)
        then (do (AArch32_EnterHypMode except preferred_exception_return (BitVec.toNat 0x14#8)))
        else (do (AArch32_EnterMode M32_Undef preferred_exception_return lr_offset vect_offset)))))

def AArch32_TakeUndefInstrException (_ : Unit) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_Uncategorized) ) : SailM ExceptionRecord )
  (AArch32_TakeUndefInstrException__1 except)

/-- Type quantifiers: k_is_ase : Bool -/
def AArch64_FPTrappedException (is_ase : Bool) (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let except ← (( do (ExceptionSyndrome Exception_FPTrappedException) ) : SailM ExceptionRecord )
  let except ← (( do
    (if (is_ase : Bool)
    then
      (do (if ((← (__IMPDEF_boolean "vector instructions set TFV to 1")) : Bool)
          then (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))
          else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 0#1)) }))))
    else (do (pure { except with syndrome := (BitVec.update except.syndrome 23 (Bit 1#1)) }))) ) : SailM ExceptionRecord )
  let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 10 8 (← (__UNKNOWN_bits 3))))) })
  let except ← (( do
    (if ((((BitVec.access except.syndrome 23) : BitVec 1) == 1#1) : Bool)
    then
      (do let split_vec := (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0))
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))
    else
      (do let split_vec ← do (__UNKNOWN_bits 6)
          let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 7 7 (Sail.BitVec.extractLsb split_vec 5 5)) }
          (pure { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 (Sail.BitVec.extractLsb split_vec 4 0)) }))) ) : SailM ExceptionRecord )
  let route_to_el2 ← (( do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  (if (((BitVec.toNat (← readReg PSTATE).EL) >b (BitVec.toNat EL1)) : Bool)
  then (do (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset))
  else
    (do (if (route_to_el2 : Bool)
        then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
        else (do (AArch64_TakeException EL1 except preferred_exception_return vect_offset)))))

def undefined_FPEXC32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPEXC32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_FPEXC_Type_DEX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_FPEXC32_EL2_Type_DZF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_FPEXC_Type_EN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_PMUSERENR_EL0_Type_EN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_FPEXC_Type_EX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_FPEXC_Type_FP2V (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_FPEXC32_EL2_Type_IDF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_FPEXC32_EL2_Type_IOF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_FPEXC32_EL2_Type_IXF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_FPEXC32_EL2_Type_OFF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _update_FPEXC_Type_TFV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _get_FPEXC32_EL2_Type_UFF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_FPEXC_Type_VECITR (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 8 x)

def _update_FPEXC_Type_VV (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def undefined_FPEXC_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_FPEXC_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def FPEXC_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _FPEXC ) : SailM FPEXC_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg FPEXC32_EL2) 0 32)))

def FPEXC_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPEXC_Type := value_name
  writeReg FPEXC32_EL2 (Sail.BitVec.updateSubrange (← readReg FPEXC32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _FPEXC r

def AArch32_FPTrappedException (accumulated_exceptions : (BitVec 8)) : SailM Unit := do
  let element ← (( do (undefined_int ()) ) : SailM Int )
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  (if ((← (AArch32_GeneralExceptionsToAArch64 ())) : Bool)
  then
    (do let is_ase : Bool := false
        let element : Int := 0
        (AArch64_FPTrappedException is_ase accumulated_exceptions))
  else (do (pure ())))
  (FPEXC_write (_update_FPEXC_Type_DEX (← (FPEXC_read ())) 1#1))
  (FPEXC_write (_update_FPEXC_Type_TFV (← (FPEXC_read ())) 1#1))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 7 7 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 5 1))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 4 0 (BitVec.slice (((BitVec.access accumulated_exceptions 7) : BitVec 1) +++ (Sail.BitVec.extractLsb accumulated_exceptions 4 0)) 0 5))))
  (FPEXC_write (Mk_FPEXC_Type (Sail.BitVec.updateSubrange (← (FPEXC_read ())) 10 8 0b111#3)))
  (AArch32_TakeUndefInstrException ())

def FPSCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : FPSCR_Type := value_name
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 31 27 (BitVec.slice r 27 5))
  writeReg FPSR (BitVec.update (← readReg FPSR) 7 (Bit (BitVec.slice r 7 1)))
  writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 4 0 (BitVec.slice r 0 5))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 26 15 (BitVec.slice r 15 12))
  writeReg FPCR (Sail.BitVec.updateSubrange (← readReg FPCR) 12 8 (BitVec.slice r 8 5))

def HaveSMEFullA64 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME_FA64)

def IsFullA64Enabled (_ : Unit) : SailM Bool := SailME.run do
  (if ((! (← (HaveSMEFullA64 ()))) : Bool)
  then (do (pure false))
  else
    (do (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
             (pure (! (← (IsInHost ()))))))) : Bool)
        then
          (do (if (((_get_SMCR_EL1_Type_FA64 (← readReg SMCR_EL1)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
             (pure ((← readReg PSTATE).EL == EL1)) <||> (do
               (pure ((← readReg PSTATE).EL == EL2)))) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do (if (((_get_SMCR_EL2_Type_FA64 (← readReg SMCR_EL2)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((HaveEL EL3) : Bool)
        then
          (do (if (((_get_SMCR_EL3_Type_FA64 (← readReg SMCR_EL3)) == 0#1) : Bool)
              then (do SailME.throw (false : Bool))
              else (do (pure ()))))
        else (do (pure ())))
        (pure true)))

def GetAccumulatedFPExceptions (_ : Unit) : SailM (BitVec 8) := do
  (__UNKNOWN_bits 8)

def IsASEInstruction (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def SetAccumulatedFPExceptions (accumulated_exceptions : (BitVec 8)) : Unit :=
  ()

def FPProcessException (except : FPExc) (fpcr : (BitVec 64)) : SailM Unit := do
  let is_ase ← (( do (undefined_bool ()) ) : SailM Bool )
  let cumul : Int := 0
  let cumul : Int :=
    match except with
    | .FPExc_InvalidOp => 0
    | .FPExc_DivideByZero => 1
    | .FPExc_Overflow => 2
    | .FPExc_Underflow => 3
    | .FPExc_Inexact => 4
    | .FPExc_InputDenorm => 7
  let cumul := cumul
  let enable := (cumul +i 8)
  (if ((←((pure (((BitVec.access fpcr enable) : BitVec 1) == 1#1)) <&&> (do
       (pure (! (← (HaveSME ())))) <||> (do
         (pure ((← readReg PSTATE).SM == 0#1))) <||> (do
         (IsFullA64Enabled ()))))) : Bool)
  then
    (do let accumulated_exceptions ← (( do (GetAccumulatedFPExceptions ()) ) : SailM (BitVec 8) )
        let accumulated_exceptions : (BitVec 8) := (BitVec.update accumulated_exceptions cumul (Bit 1#1))
        (if ((← (__IMPDEF_boolean "Support trapping of floating-point exceptions")) : Bool)
        then
          (do (if ((← (UsingAArch32 ())) : Bool)
              then (do (AArch32_FPTrappedException accumulated_exceptions))
              else
                (do let is_ase ← (( do (IsASEInstruction ()) ) : SailM Bool )
                    (AArch64_FPTrappedException is_ase accumulated_exceptions))))
        else (do (pure (SetAccumulatedFPExceptions accumulated_exceptions)))))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (Mk_FPSCR_Type (Sail.BitVec.updateSubrange (← (FPSCR_read__1 ())) cumul cumul 1#1))))
        else (do writeReg FPSR (BitVec.update (← readReg FPSR) cumul (Bit 1#1))))))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPZero (sign : (BitVec 1)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15627.38-15627.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let exp : (BitVec E) := (Zeros (n := E))
  let frac : (BitVec F) := (Zeros (n := F))
  (pure ((sign +++ exp) +++ frac))

def HaveAltFP (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AFP)

/-- Type quantifiers: N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem N [16, 32, 64] -/
def FPRoundBase__1 (op : real) (fpcr : (BitVec 64)) (rounding : FPRounding) (isbfloat16 : Bool) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := SailME.run do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15647.38-15647.39"
  sail_assert (bne op (0)) "sail-arm/arm-v9.4-a/src/v8_base.sail:15648.20-15648.21"
  sail_assert (bne rounding FPRounding_TIEAWAY) "sail-arm/arm-v9.4-a/src/v8_base.sail:15649.41-15649.42"
  let result ← (( do (undefined_bitvector N) ) : SailME (BitVec N) (BitVec N) )
  let minimum_exp ← (( do (undefined_int ()) ) : SailME (BitVec N) Int )
  let F : Int := 7
  let E : Int := 5
  let (E, F, minimum_exp) : (Int × Int × Int) :=
    if ((N == 16) : Bool)
    then
      (let minimum_exp : Int := (Neg.neg 14)
      let E : Int := 5
      let F : Int := 10
      (E, F, minimum_exp))
    else
      (let (E, F, minimum_exp) : (Int × Int × Int) :=
        if (((N == 32) && isbfloat16) : Bool)
        then
          (let minimum_exp : Int := (Neg.neg 126)
          let E : Int := 8
          let F : Int := 7
          (E, F, minimum_exp))
        else
          (let (E, F, minimum_exp) : (Int × Int × Int) :=
            if ((N == 32) : Bool)
            then
              (let minimum_exp : Int := (Neg.neg 126)
              let E : Int := 8
              let F : Int := 23
              (E, F, minimum_exp))
            else
              (let minimum_exp : Int := (Neg.neg 1022)
              let E : Int := 11
              let F : Int := 52
              (E, F, minimum_exp))
          (E, F, minimum_exp))
      (E, F, minimum_exp))
  let minimum_exp := minimum_exp
  let F := F
  let E := E
  let sign ← (( do (undefined_bitvector 1) ) : SailME (BitVec N) (BitVec 1) )
  let mantissa ← (( do (undefined_real ()) ) : SailME (BitVec N) real )
  let (mantissa, sign) : (real × (BitVec 1)) :=
    if ((lt_real op (0)) : Bool)
    then
      (let sign : (BitVec 1) := 1#1
      let mantissa : real := (neg_real op)
      (mantissa, sign))
    else
      (let sign : (BitVec 1) := 0#1
      let mantissa : real := op
      (mantissa, sign))
  let exponent : Int := 0
  let (exponent, mantissa) ← (( do
    let mut loop_vars := (exponent, mantissa)
    while (λ (exponent, mantissa) => (lt_real mantissa (1))) loop_vars do
      let (exponent, mantissa) := loop_vars
      loop_vars :=
        (let mantissa : real := (mult_real mantissa (2))
        let exponent : Int := (exponent -i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars) ) : SailME (BitVec N) (Int × real) )
  let (exponent, mantissa) ← (( do
    let mut loop_vars_1 := (exponent, mantissa)
    while (λ (exponent, mantissa) => (gteq_real mantissa (2))) loop_vars_1 do
      let (exponent, mantissa) := loop_vars_1
      loop_vars_1 :=
        (let mantissa : real := (div_real mantissa (2))
        let exponent : Int := (exponent +i 1)
        (exponent, mantissa) : (Int × real))
    (pure loop_vars_1) ) : SailME (BitVec N) (Int × real) )
  let exponent := exponent
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailME (BitVec N) Bool )
  (if ((((! altfp) && ((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16)))) && (exponent <b minimum_exp)) : Bool)
  then
    (do (if ((← (UsingAArch32 ())) : Bool)
        then (do (FPSCR_write (_update_FPSCR_Type_UFC (← (FPSCR_read__1 ())) 1#1)))
        else
          (do (if (fpexc : Bool)
              then (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1))
              else (do (pure ())))))
        (FPZero sign N))
  else
    (do let biased_exp_unconstrained : Int := ((exponent -i minimum_exp) +i 1)
        let int_mant_unconstrained : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error_unconstrained : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant_unconstrained))
        let biased_exp : Int := (Max.max ((exponent -i minimum_exp) +i 1) 0)
        let mantissa : real :=
          if ((biased_exp == 0) : Bool)
          then (div_real mantissa (real_power (2) (minimum_exp -i exponent)))
          else mantissa
        let mantissa := mantissa
        let int_mant : Int := (round_down (mult_real mantissa (real_power (2) F)))
        let error : real := (sub_real (mult_real mantissa (real_power (2) F)) (to_real int_mant))
        let trapped_UF ← (( do (pure ((_get_FPCRType_UFE fpcr) == 1#1)) <&&> (do (pure (! (← (InStreamingMode ())))) <||> (do (IsFullA64Enabled ()))) ) : SailME (BitVec N) Bool )
        (if ((((! altfp) && (biased_exp == 0)) && ((bne error (0)) || trapped_UF)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Underflow fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        let round_up_unconstrained ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let round_up ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let overflow_to_inf ← (( do (undefined_bool ()) ) : SailME (BitVec N) Bool )
        let (overflow_to_inf, round_up) ← (( do
          (if (altfp : Bool)
          then
            (do let (overflow_to_inf, round_up, round_up_unconstrained) : (Bool × Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up_unconstrained : Bool := ((gt_real error_unconstrained (1/2)) || ((eq_real error_unconstrained (1/2)) && (((integer_access int_mant_unconstrained 0) : BitVec 1) == 1#1)))
                    let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_POSINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 0#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_NEGINF =>
                    (let round_up_unconstrained : Bool := ((bne error_unconstrained (0)) && (sign == 1#1))
                    let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ZERO =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | .FPRounding_ODD =>
                    (let round_up_unconstrained : Bool := false
                    let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up, round_up_unconstrained))
                  | _ => (overflow_to_inf, round_up, round_up_unconstrained)
                let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                  if (round_up_unconstrained : Bool)
                  then
                    (let int_mant_unconstrained : Int := (int_mant_unconstrained +i 1)
                    let (biased_exp_unconstrained, int_mant_unconstrained) : (Int × Int) :=
                      if ((int_mant_unconstrained == (2 ^i (F +i 1))) : Bool)
                      then
                        (let biased_exp_unconstrained : Int := (biased_exp_unconstrained +i 1)
                        let int_mant_unconstrained : Int := (fdiv_int int_mant_unconstrained 2)
                        (biased_exp_unconstrained, int_mant_unconstrained))
                      else (biased_exp_unconstrained, int_mant_unconstrained)
                    (biased_exp_unconstrained, int_mant_unconstrained))
                  else (biased_exp_unconstrained, int_mant_unconstrained)
                let int_mant_unconstrained := int_mant_unconstrained
                let biased_exp_unconstrained := biased_exp_unconstrained
                (if (((biased_exp_unconstrained <b 1) && (int_mant_unconstrained != 0)) : Bool)
                then
                  (do (if (((((_get_FPCRType_FZ fpcr) == 1#1) && (N != 16)) || (((_get_FPCRType_FZ16 fpcr) == 1#1) && (N == 16))) : Bool)
                      then
                        (do SailME.throw (← do
                                (if (fpexc : Bool)
                                then
                                  (do writeReg FPSR (Sail.BitVec.updateSubrange (← readReg FPSR) 3 3 1#1)
                                      (FPProcessException FPExc_Inexact fpcr))
                                else (do (pure ())))
                                (FPZero sign N)))
                      else
                        (do (if (((bne error (0)) || trapped_UF) : Bool)
                            then
                              (do (if (fpexc : Bool)
                                  then (do (FPProcessException FPExc_Underflow fpcr))
                                  else (do (pure ()))))
                            else (do (pure ()))))))
                else (do (pure ())))
                (pure (overflow_to_inf, round_up)))
          else
            (do let (overflow_to_inf, round_up) : (Bool × Bool) :=
                  match rounding with
                  | .FPRounding_TIEEVEN =>
                    (let round_up : Bool := ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_mant 0) : BitVec 1) == 1#1)))
                    let overflow_to_inf : Bool := true
                    (overflow_to_inf, round_up))
                  | .FPRounding_POSINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 0#1))
                    let overflow_to_inf : Bool := (sign == 0#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_NEGINF =>
                    (let round_up : Bool := ((bne error (0)) && (sign == 1#1))
                    let overflow_to_inf : Bool := (sign == 1#1)
                    (overflow_to_inf, round_up))
                  | .FPRounding_ZERO =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | .FPRounding_ODD =>
                    (let round_up : Bool := false
                    let overflow_to_inf : Bool := false
                    (overflow_to_inf, round_up))
                  | _ => (overflow_to_inf, round_up)
                (pure (overflow_to_inf, round_up)))) ) : SailME (BitVec N) (Bool × Bool) )
        let (biased_exp, int_mant) : (Int × Int) :=
          if (round_up : Bool)
          then
            (let int_mant : Int := (int_mant +i 1)
            let biased_exp : Int :=
              if ((int_mant == (2 ^i F)) : Bool)
              then 1
              else biased_exp
            let (biased_exp, int_mant) : (Int × Int) :=
              if ((int_mant == (2 ^i (F +i 1))) : Bool)
              then
                (let biased_exp : Int := (biased_exp +i 1)
                let int_mant : Int := (fdiv_int int_mant 2)
                (biased_exp, int_mant))
              else (biased_exp, int_mant)
            (biased_exp, int_mant))
          else (biased_exp, int_mant)
        let biased_exp := biased_exp
        let int_mant : Int :=
          if (((bne error (0)) && (BEq.beq rounding FPRounding_ODD)) : Bool)
          then (integer_update_subrange int_mant 0 0 1#1)
          else int_mant
        let int_mant := int_mant
        let (error, result) ← (( do
          (if (((N != 16) || ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
          then
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b ((2 ^i E) -i 1)) : Bool)
                  then
                    (do let result ←
                          (if (overflow_to_inf : Bool)
                          then (do (FPInfinity sign N))
                          else (do (FPMaxNormal sign N)))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_Overflow fpcr))
                        else (do (pure ())))
                        let error : real := (1)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15829.54-15829.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))
          else
            (do let (error, result) ← (( do
                  (if ((biased_exp ≥b (2 ^i E)) : Bool)
                  then
                    (do let result : (BitVec N) := (sign +++ (Ones (n := (N -i 1))))
                        (if (fpexc : Bool)
                        then (do (FPProcessException FPExc_InvalidOp fpcr))
                        else (do (pure ())))
                        let error : real := (0)
                        (pure (error, result)))
                  else
                    (do sail_assert ((N -i ((E +i F) +i 1)) ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15840.54-15840.55"
                        let result : (BitVec N) := (((sign +++ (integer_subrange biased_exp (E -i 1) 0)) +++ (integer_subrange int_mant (F -i 1) 0)) +++ (Zeros (n := (N -i ((E +i F) +i 1)))))
                        (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
                (pure (error, result)))) ) : SailME (BitVec N) (real × (BitVec N)) )
        (if ((bne error (0)) : Bool)
        then
          (do (if (fpexc : Bool)
              then (do (FPProcessException FPExc_Inexact fpcr))
              else (do (pure ()))))
        else (do (pure ())))
        (pure result)))

def FPDecodeRounding (rmode : (BitVec 2)) : SailM FPRounding := do
  match rmode with
  | 0b00 => (pure FPRounding_TIEEVEN)
  | 0b01 => (pure FPRounding_POSINF)
  | 0b10 => (pure FPRounding_NEGINF)
  | 0b11 => (pure FPRounding_ZERO)
  | _ => (do (undefined_FPRounding ()))

def FPRoundingMode (fpcr : (BitVec 64)) : SailM FPRounding := do
  (FPDecodeRounding (_get_FPCRType_RMode fpcr))

/-- Type quantifiers: N : Nat, k_fpexc : Bool, List.elem N [16, 32, 64] -/
def FPRound__2 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (fpexc : Bool) (N : Nat) : SailM (BitVec N) := do
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let isbfloat16 : Bool := false
  (FPRoundBase__1 op fpcr rounding isbfloat16 fpexc N)

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPRound__1 (op : real) (fpcr_in : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  let fpexc : Bool := true
  (FPRound__2 op fpcr_in rounding fpexc N)

/-- Type quantifiers: k_M : Nat, N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem N [16, 32, 64] ∧ List.elem k_M [16, 32, 64] -/
def FixedToFP (op : (BitVec k_M)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15912.38-15912.39"
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15913.41-15913.42"
  let result ← (( do (undefined_bitvector N) ) : SailM (BitVec N) )
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:15915.21-15915.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:15916.37-15916.38"
  let int_operand ← (( do (asl_Int op is_unsigned) ) : SailM Int )
  let real_operand : real := (div_real (to_real int_operand) (real_power (2) fbits))
  (if ((eq_real real_operand (0)) : Bool)
  then (do (FPZero 0#1 N))
  else (do (FPRound__1 real_operand fpcr rounding N)))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, k_isbfloat16 : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) (isbfloat16 : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let exp16 ← (( do (undefined_bitvector 5) ) : SailM (BitVec 5) )
  let exp64 ← (( do (undefined_bitvector 11) ) : SailM (BitVec 11) )
  let frac16 ← (( do (undefined_bitvector 10) ) : SailM (BitVec 10) )
  let frac64 ← (( do (undefined_bitvector 52) ) : SailM (BitVec 52) )
  sail_assert (((Sail.BitVec.length fpval) == 16) || (((Sail.BitVec.length fpval) == 32) || ((Sail.BitVec.length fpval) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:15949.41-15949.42"
  let fpcr : FPCRType := fpcr_in
  let altfp ← (( do (HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))) ) : SailM Bool )
  let fiz : Bool := (altfp && ((_get_FPCRType_FIZ fpcr) == 1#1))
  let fz : Bool := (((_get_FPCRType_FZ fpcr) == 1#1) && (! (altfp && ((_get_FPCRType_AH fpcr) == 1#1))))
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let (fptype, sign, value_name) ← (( do
    (if ((((Sail.BitVec.length fpval) == 16) && (! isbfloat16)) : Bool)
    then
      (do let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
          let exp16 : (BitVec 5) := (Sail.BitVec.extractLsb fpval 14 10)
          let frac16 : (BitVec 10) := (Sail.BitVec.extractLsb fpval 9 0)
          let (fptype, value_name) : (FPType × real) :=
            if ((IsZero exp16) : Bool)
            then
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsZero frac16) || ((_get_FPCRType_FZ16 fpcr) == 1#1)) : Bool)
                then
                  (let fptype : FPType := FPType_Zero
                  let value_name : real := (0)
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Denormal
                  let value_name : real := (mult_real (real_power (2) (Neg.neg 14)) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10))))
                  (fptype, value_name))
              (fptype, value_name))
            else
              (let (fptype, value_name) : (FPType × real) :=
                if (((IsOnes exp16) && ((_get_FPCRType_AHP fpcr) == 0#1)) : Bool)
                then
                  (let (fptype, value_name) : (FPType × real) :=
                    if ((IsZero frac16) : Bool)
                    then
                      (let fptype : FPType := FPType_Infinity
                      let value_name : real := (real_power (2) 1000000)
                      (fptype, value_name))
                    else
                      (let fptype : FPType :=
                        if ((((BitVec.access frac16 9) : BitVec 1) == 1#1) : Bool)
                        then FPType_QNaN
                        else FPType_SNaN
                      let value_name : real := (0)
                      (fptype, value_name))
                  (fptype, value_name))
                else
                  (let fptype : FPType := FPType_Nonzero
                  let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp16) -i 15)) (add_real (1) (mult_real (to_real (BitVec.toNat frac16)) (real_power (2) (Neg.neg 10)))))
                  (fptype, value_name))
              (fptype, value_name))
          (pure (fptype, sign, value_name)))
    else
      (do let (fptype, sign, value_name) ← (( do
            (if ((((Sail.BitVec.length fpval) == 32) || isbfloat16) : Bool)
            then
              (do let exp32 ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
                  let frac32 ← (( do (undefined_bitvector 23) ) : SailM (BitVec 23) )
                  let (exp32, frac32, sign) : ((BitVec 8) × (BitVec 23) × (BitVec 1)) :=
                    if (isbfloat16 : Bool)
                    then
                      (let sign : (BitVec 1) := ((BitVec.access fpval 15) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 14 7)
                      let frac32 : (BitVec 23) := ((Sail.BitVec.extractLsb fpval 6 0) +++ (Zeros (n := 16)))
                      (exp32, frac32, sign))
                    else
                      (let sign : (BitVec 1) := ((BitVec.access fpval 31) : BitVec 1)
                      let exp32 : (BitVec 8) := (Sail.BitVec.extractLsb fpval 30 23)
                      let frac32 : (BitVec 23) := (Sail.BitVec.extractLsb fpval 22 0)
                      (exp32, frac32, sign))
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp32) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac32) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 126)) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp32) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac32) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac32 22) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp32) -i 127)) (add_real (1) (mult_real (to_real (BitVec.toNat frac32)) (real_power (2) (Neg.neg 23)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))
            else
              (do let sign : (BitVec 1) := ((BitVec.access fpval 63) : BitVec 1)
                  let exp64 : (BitVec 11) := (Sail.BitVec.extractLsb fpval 62 52)
                  let frac64 : (BitVec 52) := (Sail.BitVec.extractLsb fpval 51 0)
                  let (fptype, value_name) ← (( do
                    (if ((IsZero exp64) : Bool)
                    then
                      (do let (fptype, value_name) ← (( do
                            (if ((IsZero frac64) : Bool)
                            then
                              (do let fptype : FPType := FPType_Zero
                                  let value_name : real := (0)
                                  (pure (fptype, value_name)))
                            else
                              (do let (fptype, value_name) ← (( do
                                    (if ((fz || fiz) : Bool)
                                    then
                                      (do let fptype : FPType := FPType_Zero
                                          let value_name : real := (0)
                                          (if (fz : Bool)
                                          then
                                            (do (if (fpexc : Bool)
                                                then (do (FPProcessException FPExc_InputDenorm fpcr))
                                                else (do (pure ()))))
                                          else (do (pure ())))
                                          (pure (fptype, value_name)))
                                    else
                                      (do let fptype : FPType := FPType_Denormal
                                          let value_name : real := (mult_real (real_power (2) (Neg.neg 1022)) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52))))
                                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                                  (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                          (pure (fptype, value_name)))
                    else
                      (do let (fptype, value_name) : (FPType × real) :=
                            if ((IsOnes exp64) : Bool)
                            then
                              (let (fptype, value_name) : (FPType × real) :=
                                if ((IsZero frac64) : Bool)
                                then
                                  (let fptype : FPType := FPType_Infinity
                                  let value_name : real := (real_power (2) 1000000)
                                  (fptype, value_name))
                                else
                                  (let fptype : FPType :=
                                    if ((((BitVec.access frac64 51) : BitVec 1) == 1#1) : Bool)
                                    then FPType_QNaN
                                    else FPType_SNaN
                                  let value_name : real := (0)
                                  (fptype, value_name))
                              (fptype, value_name))
                            else
                              (let fptype : FPType := FPType_Nonzero
                              let value_name : real := (mult_real (real_power (2) ((BitVec.toNat exp64) -i 1023)) (add_real (1) (mult_real (to_real (BitVec.toNat frac64)) (real_power (2) (Neg.neg 52)))))
                              (fptype, value_name))
                          (pure (fptype, value_name)))) ) : SailM (FPType × real) )
                  (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
          (pure (fptype, sign, value_name)))) ) : SailM (FPType × (BitVec 1) × real) )
  let value_name : real :=
    if ((sign == 1#1) : Bool)
    then (neg_real value_name)
    else value_name
  let value_name := value_name
  (pure (fptype, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpackBase (fpval : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let isbfloat16 : Bool := false
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase__1 fpval fpcr fpexc isbfloat16)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPUnpack (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let fpexc : Bool := true
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPUnpack__1 (fpval : (BitVec k_N)) (fpcr_in : (BitVec 64)) (fpexc : Bool) : SailM (FPType × (BitVec 1) × real) := do
  let fp_type ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  let fpcr : FPCRType := fpcr_in
  let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 26 26 0#1)
  let (fp_type, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpackBase fpval fpcr fpexc)
    let fp_type : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fp_type, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  (pure (fp_type, sign, value_name))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def FPDefaultNaN__1 (fpcr : (BitVec 64)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16128.38-16128.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := (N -i (E +i 1))
  let sign ← (( do
    (if ((←((HaveAltFP ()) <&&> (do
         (pure (! (← (UsingAArch32 ()))))))) : Bool)
    then (do (pure (_get_FPCRType_AH fpcr)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let exp : (BitVec E) := (Ones (n := E))
  let frac : (BitVec F) := (1#1 +++ (Zeros (n := (F -i 1))))
  (pure ((sign +++ exp) +++ frac))

/-- Type quantifiers: N : Int -/
def FPProcessDenorms (type1 : FPType) (type2 : FPType) (N : Int) (fpcr : (BitVec 64)) : SailM Unit := do
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  (if (((altfp && (N != 16)) && ((BEq.beq type1 FPType_Denormal) || (BEq.beq type2 FPType_Denormal))) : Bool)
  then (do (FPProcessException FPExc_InputDenorm fpcr))
  else (do (pure ())))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaN__1 (fptype : FPType) (op : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16162.41-16162.42"
  sail_assert ((BEq.beq fptype FPType_QNaN) || (BEq.beq fptype FPType_SNaN)) "sail-arm/arm-v9.4-a/src/v8_base.sail:16163.56-16163.57"
  let topfrac : Int := 9
  let topfrac : Int :=
    match (Sail.BitVec.length op) with
    | 16 => 9
    | 32 => 22
    | 64 => 51
    | _ => topfrac
  let topfrac := topfrac
  let result : (BitVec k_N) := op
  let result ← (( do
    (if ((BEq.beq fptype FPType_SNaN) : Bool)
    then
      (do sail_assert ((0 ≤b topfrac) && (topfrac <b (Sail.BitVec.length result))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16180.58-16180.59"
          let result : (BitVec k_N) := (BitVec.update result topfrac (Bit 1#1))
          (if (fpexc : Bool)
          then (do (FPProcessException FPExc_InvalidOp fpcr))
          else (do (pure ())))
          (pure result))
    else (do (pure result))) ) : SailM (BitVec k_N) )
  (if (((_get_FPCRType_DN fpcr) == 1#1) : Bool)
  then (do (FPDefaultNaN__1 fpcr (Sail.BitVec.length result)))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs__1 (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (Bool × (BitVec k_N)) := do
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16206.41-16206.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let op1_nan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN))
  let op2_nan : Bool := ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN))
  let any_snan : Bool := ((BEq.beq type1 FPType_SNaN) || (BEq.beq type2 FPType_SNaN))
  let type_nan : FPType :=
    if (any_snan : Bool)
    then FPType_SNaN
    else FPType_QNaN
  let (done, result) ← (( do
    (if (((altfp && op1_nan) && op2_nan) : Bool)
    then
      (do let done : Bool := true
          let result ← (FPProcessNaN__1 type_nan op1 fpcr fpexc)
          (pure (done, result)))
    else
      (do let (done, result) ← (( do
            (if ((BEq.beq type1 FPType_SNaN) : Bool)
            then
              (do let done : Bool := true
                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                  (pure (done, result)))
            else
              (do let (done, result) ← (( do
                    (if ((BEq.beq type2 FPType_SNaN) : Bool)
                    then
                      (do let done : Bool := true
                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                          (pure (done, result)))
                    else
                      (do let (done, result) ← (( do
                            (if ((BEq.beq type1 FPType_QNaN) : Bool)
                            then
                              (do let done : Bool := true
                                  let result ← (FPProcessNaN__1 type1 op1 fpcr fpexc)
                                  (pure (done, result)))
                            else
                              (do let (done, result) ← (( do
                                    (if ((BEq.beq type2 FPType_QNaN) : Bool)
                                    then
                                      (do let done : Bool := true
                                          let result ← (FPProcessNaN__1 type2 op2 fpcr fpexc)
                                          (pure (done, result)))
                                    else
                                      (do let done : Bool := false
                                          let result : (BitVec k_N) := (Zeros (n := (Sail.BitVec.length result)))
                                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
                  (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
          (pure (done, result)))) ) : SailM (Bool × (BitVec k_N)) )
  (pure (done, result))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPProcessNaNs (type1 : FPType) (type2 : FPType) (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (Bool × (BitVec k_N)) := do
  let fpexc : Bool := true
  (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_fpexc : Bool, List.elem k_N [16, 32, 64] -/
def FPAdd__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) (fpexc : Bool) : SailM (BitVec k_N) := do
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let inf2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let result_sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let result_value ← (( do (undefined_real ()) ) : SailM real )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  let zero1 ← (( do (undefined_bool ()) ) : SailM Bool )
  let zero2 ← (( do (undefined_bool ()) ) : SailM Bool )
  sail_assert (((Sail.BitVec.length result) == 16) || (((Sail.BitVec.length result) == 32) || ((Sail.BitVec.length result) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16263.41-16263.42"
  let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op1 fpcr fpexc)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op2 fpcr fpexc)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (done, result) ← (( do
    let (tup__0, tup__1) ← do (FPProcessNaNs__1 type1 type2 op1 op2 fpcr fpexc)
    let done : Bool := tup__0
    let result : (BitVec k_N) := tup__1
    (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
  (if ((! done) : Bool)
  then
    (do let inf1 : Bool := (BEq.beq type1 FPType_Infinity)
        let inf2 : Bool := (BEq.beq type2 FPType_Infinity)
        let zero1 : Bool := (BEq.beq type1 FPType_Zero)
        let zero2 : Bool := (BEq.beq type2 FPType_Zero)
        let result ← (( do
          (if (((inf1 && inf2) && (sign1 == (Complement.complement sign2))) : Bool)
          then
            (do let result ← (FPDefaultNaN__1 fpcr (Sail.BitVec.length result))
                (if (fpexc : Bool)
                then (do (FPProcessException FPExc_InvalidOp fpcr))
                else (do (pure ())))
                (pure result))
          else
            (do (if (((inf1 && (sign1 == 0#1)) || (inf2 && (sign2 == 0#1))) : Bool)
                then (do (FPInfinity 0#1 (Sail.BitVec.length result)))
                else
                  (do (if (((inf1 && (sign1 == 1#1)) || (inf2 && (sign2 == 1#1))) : Bool)
                      then (do (FPInfinity 1#1 (Sail.BitVec.length result)))
                      else
                        (do (if (((zero1 && zero2) && (sign1 == sign2)) : Bool)
                            then (do (FPZero sign1 (Sail.BitVec.length result)))
                            else
                              (do let result_value : real := (add_real value1_name value2_name)
                                  (if ((eq_real result_value (0)) : Bool)
                                  then
                                    (do let result_sign : (BitVec 1) :=
                                          if ((BEq.beq rounding FPRounding_NEGINF) : Bool)
                                          then 1#1
                                          else 0#1
                                        (FPZero result_sign (Sail.BitVec.length result)))
                                  else (do (FPRound__2 result_value fpcr rounding fpexc (Sail.BitVec.length result)))))))))))) ) : SailM (BitVec k_N) )
        (if (fpexc : Bool)
        then (do (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr))
        else (do (pure ())))
        (pure result))
  else (do (pure result)))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPAdd (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let fpexc : Bool := true
  (FPAdd__1 op1 op2 fpcr fpexc)

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMax__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16634.41-16634.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((gt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 &&& sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMaxNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16680.41-16680.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 1#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 1#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMax__1 op1 op2 fpcr altfmaxfmin)

def IsMerging (fpcr : (BitVec 64)) : SailM Bool := do
  let nep ← (( do
    (if ((←((HaveSME ()) <&&> (do
         (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do
         (pure (! (← (IsFullA64Enabled ()))))))) : Bool)
    then (do (pure 0#1))
    else (do (pure (_get_FPCRType_NEP fpcr)))) ) : SailM (BitVec 1) )
  (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && (nep == 1#1)))

/-- Type quantifiers: k_N : Nat, k_altfp : Bool, List.elem k_N [16, 32, 64] -/
def FPMin__1 (op1 : (BitVec k_N)) (op2 : (BitVec k_N)) (fpcr_in : (BitVec 64)) (altfp : Bool) : SailM (BitVec k_N) := do
  let sign1 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sign2 ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let value1_name ← (( do (undefined_real ()) ) : SailM real )
  let value2_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op2) == 16) || (((Sail.BitVec.length op2) == 32) || ((Sail.BitVec.length op2) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16735.41-16735.42"
  let done ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector (Sail.BitVec.length op2)) ) : SailM (BitVec k_N) )
  let fpcr : FPCRType := fpcr_in
  let (sign1, type1, value1_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op1 fpcr)
    let type1 : FPType := tup__0
    let sign1 : (BitVec 1) := tup__1
    let value1_name : real := tup__2
    (pure (sign1, type1, value1_name)) ) : SailM ((BitVec 1) × FPType × real) )
  let (sign2, type2, value2_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack op2 fpcr)
    let type2 : FPType := tup__0
    let sign2 : (BitVec 1) := tup__1
    let value2_name : real := tup__2
    (pure (sign2, type2, value2_name)) ) : SailM ((BitVec 1) × FPType × real) )
  (if ((((altfp && (BEq.beq type1 FPType_Zero)) && (BEq.beq type2 FPType_Zero)) && (sign1 != sign2)) : Bool)
  then (do (FPZero sign2 (Sail.BitVec.length result)))
  else
    (do (if ((altfp && (((BEq.beq type1 FPType_SNaN) || (BEq.beq type1 FPType_QNaN)) || ((BEq.beq type2 FPType_SNaN) || (BEq.beq type2 FPType_QNaN)))) : Bool)
        then
          (do (FPProcessException FPExc_InvalidOp fpcr)
              (if ((BEq.beq type2 FPType_Zero) : Bool)
              then (do (FPZero sign2 (Sail.BitVec.length result)))
              else (do (pure op2))))
        else
          (do let (done, result) ← (( do
                let (tup__0, tup__1) ← do (FPProcessNaNs type1 type2 op1 op2 fpcr)
                let done : Bool := tup__0
                let result : (BitVec k_N) := tup__1
                (pure (done, result)) ) : SailM (Bool × (BitVec k_N)) )
              (if ((! done) : Bool)
              then
                (do let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
                    let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
                    let value_name ← (( do (undefined_real ()) ) : SailM real )
                    let rounding ← (( do (undefined_FPRounding ()) ) : SailM FPRounding )
                    let (fptype, sign, value_name) : (FPType × (BitVec 1) × real) :=
                      if ((lt_real value1_name value2_name) : Bool)
                      then
                        (let (tup__0, tup__1, tup__2) := ((type1, sign1, value1_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                      else
                        (let (tup__0, tup__1, tup__2) := ((type2, sign2, value2_name) : (FPType × (BitVec 1) × real))
                        let fptype : FPType := tup__0
                        let sign : (BitVec 1) := tup__1
                        let value_name : real := tup__2
                        (fptype, sign, value_name))
                    let (fpcr, result) ← (( do
                      (if ((BEq.beq fptype FPType_Infinity) : Bool)
                      then
                        (do let result ← (FPInfinity sign (Sail.BitVec.length result))
                            (pure (fpcr, result)))
                      else
                        (do let (fpcr, result) ← (( do
                              (if ((BEq.beq fptype FPType_Zero) : Bool)
                              then
                                (do let sign : (BitVec 1) := (sign1 ||| sign2)
                                    let result ← (FPZero sign (Sail.BitVec.length result))
                                    (pure (fpcr, result)))
                              else
                                (do let rounding ← (( do (FPRoundingMode fpcr) ) : SailM FPRounding )
                                    let fpcr : (BitVec 64) :=
                                      if (altfp : Bool)
                                      then
                                        (let fpcr : FPCRType := (Sail.BitVec.updateSubrange fpcr 24 24 0#1)
                                        (Sail.BitVec.updateSubrange fpcr 19 19 0#1))
                                      else fpcr
                                    let result ← (FPRound__2 value_name fpcr rounding true (Sail.BitVec.length result))
                                    (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                            (pure (fpcr, result)))) ) : SailM ((BitVec 64) × (BitVec k_N)) )
                    (FPProcessDenorms type1 type2 (Sail.BitVec.length result) fpcr)
                    (pure result))
              else (do (pure result)))))))

/-- Type quantifiers: k_N : Nat, List.elem k_N [16, 32, 64] -/
def FPMinNum (op1_in : (BitVec k_N)) (op2_in : (BitVec k_N)) (fpcr : (BitVec 64)) : SailM (BitVec k_N) := do
  let type1 ← (( do (undefined_FPType ()) ) : SailM FPType )
  let type2 ← (( do (undefined_FPType ()) ) : SailM FPType )
  sail_assert (((Sail.BitVec.length op2_in) == 16) || (((Sail.BitVec.length op2_in) == 32) || ((Sail.BitVec.length op2_in) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:16782.41-16782.42"
  let op1 : (BitVec k_N) := op1_in
  let op2 : (BitVec k_N) := op2_in
  let type1 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op1 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type2 ← (( do
    let (__tup_0, _, _) ← do (FPUnpack op2 fpcr)
    (pure __tup_0) ) : SailM FPType )
  let type1_nan : Bool := ((BEq.beq type1 FPType_QNaN) || (BEq.beq type1 FPType_SNaN))
  let type2_nan : Bool := ((BEq.beq type2 FPType_QNaN) || (BEq.beq type2 FPType_SNaN))
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let (op1, op2) ← (( do
    (if ((! ((altfp && type1_nan) && type2_nan)) : Bool)
    then
      (do let (op1, op2) ← (( do
            (if (((BEq.beq type1 FPType_QNaN) && (bne type2 FPType_QNaN)) : Bool)
            then
              (do let op1 ← (FPInfinity 0#1 (Sail.BitVec.length op2_in))
                  (pure (op1, op2)))
            else
              (do let op2 ← (( do
                    (if (((bne type1 FPType_QNaN) && (BEq.beq type2 FPType_QNaN)) : Bool)
                    then (do (FPInfinity 0#1 (Sail.BitVec.length op2_in)))
                    else (do (pure op2))) ) : SailM (BitVec k_N) )
                  (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
          (pure (op1, op2)))
    else (do (pure (op1, op2)))) ) : SailM ((BitVec k_N) × (BitVec k_N)) )
  let altfmaxfmin : Bool := false
  (FPMin__1 op1 op2 fpcr altfmaxfmin)

/-- Type quantifiers: M : Nat, k_N : Nat, fbits : Int, k_is_unsigned : Bool, List.elem k_N [16, 32, 64] ∧ List.elem M [16, 32, 64] -/
def FPToFixed (op : (BitVec k_N)) (fbits : Int) (is_unsigned : Bool) (fpcr : (BitVec 64)) (rounding : FPRounding) (M : Nat) : SailM (BitVec M) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let overflow ← (( do (undefined_bool ()) ) : SailM Bool )
  let result ← (( do (undefined_bitvector M) ) : SailM (BitVec M) )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 16) || (((Sail.BitVec.length op) == 32) || ((Sail.BitVec.length op) == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17844.41-17844.42"
  sail_assert ((M == 16) || ((M == 32) || (M == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17845.38-17845.39"
  sail_assert (fbits ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:17846.21-17846.22"
  sail_assert (bne rounding FPRounding_ODD) "sail-arm/arm-v9.4-a/src/v8_base.sail:17847.37-17847.38"
  let altfp ← (( do (pure ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1))) ) : SailM Bool )
  let fpexc : Bool := (! altfp)
  let (fptype, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, value_name)) ) : SailM (FPType × real) )
  (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else (do (pure ())))
  let value_name : real := (mult_real value_name (real_power (2) fbits))
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_up ← (( do (undefined_bool ()) ) : SailM Bool )
  let round_up : Bool :=
    match rounding with
    | .FPRounding_TIEEVEN => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (((integer_access int_result 0) : BitVec 1) == 1#1)))
    | .FPRounding_POSINF => (bne error (0))
    | .FPRounding_NEGINF => false
    | .FPRounding_ZERO => ((bne error (0)) && (int_result <b 0))
    | .FPRounding_TIEAWAY => ((gt_real error (1/2)) || ((eq_real error (1/2)) && (int_result ≥b 0)))
    | _ => round_up
  let int_result : Int :=
    if (round_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let (overflow, result) ← (( do
    let (tup__0, tup__1) ← do (SatQ int_result M is_unsigned)
    let result : (BitVec M) := tup__0
    let overflow : Bool := tup__1
    (pure (overflow, result)) ) : SailM (Bool × (BitVec M)) )
  (if (overflow : Bool)
  then (do (FPProcessException FPExc_InvalidOp fpcr))
  else
    (do (if ((bne error (0)) : Bool)
        then (do (FPProcessException FPExc_Inexact fpcr))
        else (do (pure ())))))
  (pure result)

/-- Type quantifiers: k_Is64 : Bool, k_M : Nat, N : Nat, k_M = 64 ∧ N = 32 -/
def FPToFixedJS (op : (BitVec k_M)) (fpcr : (BitVec 64)) (Is64 : Bool) (N : Nat) : SailM ((BitVec N) × (BitVec 1)) := do
  let fptype ← (( do (undefined_FPType ()) ) : SailM FPType )
  let sign ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let value_name ← (( do (undefined_real ()) ) : SailM real )
  sail_assert (((Sail.BitVec.length op) == 64) && (N == 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:17897.29-17897.30"
  let fpexc_idenorm ← (( do (pure (! ((←((HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))))) && ((_get_FPCRType_AH fpcr) == 1#1)))) ) : SailM Bool )
  let (fptype, sign, value_name) ← (( do
    let (tup__0, tup__1, tup__2) ← do (FPUnpack__1 op fpcr fpexc_idenorm)
    let fptype : FPType := tup__0
    let sign : (BitVec 1) := tup__1
    let value_name : real := tup__2
    (pure (fptype, sign, value_name)) ) : SailM (FPType × (BitVec 1) × real) )
  let z : (BitVec 1) := 1#1
  let z ← (( do
    (if (((BEq.beq fptype FPType_SNaN) || (BEq.beq fptype FPType_QNaN)) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else (do (pure z))) ) : SailM (BitVec 1) )
  let int_result : Int := (round_down value_name)
  let error : real := (sub_real value_name (to_real int_result))
  let round_it_up : Bool := ((bne error (0)) && (int_result <b 0))
  let int_result : Int :=
    if (round_it_up : Bool)
    then (int_result +i 1)
    else int_result
  let int_result := int_result
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let result : Int :=
    if ((int_result <b 0) : Bool)
    then (int_result -i ((2 ^i 32) *i (round_up (div_real (to_real int_result) (to_real (2 ^i 32))))))
    else (int_result -i ((2 ^i 32) *i (round_down (div_real (to_real int_result) (to_real (2 ^i 32))))))
  let z ← (( do
    (if (((int_result <b (Neg.neg (2 ^i 31))) || (int_result >b ((2 ^i 31) -i 1))) : Bool)
    then
      (do (FPProcessException FPExc_InvalidOp fpcr)
          (pure 0#1))
    else
      (do (if ((bne error (0)) : Bool)
          then
            (do (FPProcessException FPExc_Inexact fpcr)
                (pure 0#1))
          else
            (do (if (((sign == 1#1) && (eq_real value_name (0))) : Bool)
                then (do (pure 0#1))
                else
                  (do (if ((((sign == 0#1) && (eq_real value_name (0))) && (! (IsZero (Sail.BitVec.extractLsb op 51 0)))) : Bool)
                      then (do (pure 0#1))
                      else (do (pure z))))))))) ) : SailM (BitVec 1) )
  let result : Int :=
    if ((BEq.beq fptype FPType_Infinity) : Bool)
    then 0
    else result
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), z))

/-- Type quantifiers: N : Nat, List.elem N [16, 32, 64] -/
def VFPExpandImm (imm8 : (BitVec 8)) (N : Nat) : SailM (BitVec N) := do
  sail_assert ((N == 16) || ((N == 32) || (N == 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:17939.38-17939.39"
  let E :=
    if ((N == 16) : Bool)
    then 5
    else
      (if ((N == 32) : Bool)
      then 8
      else 11)
  let F := ((N -i E) -i 1)
  let sign : (BitVec 1) := ((BitVec.access imm8 7) : BitVec 1)
  let exp : (BitVec (1 + (E - 3) + 2)) := (((Complement.complement ((BitVec.access imm8 6) : BitVec 1)) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) (E -i 3))) +++ (Sail.BitVec.extractLsb imm8 5 4))
  let frac : (BitVec (4 + (F - 4))) := ((Sail.BitVec.extractLsb imm8 3 0) +++ (Zeros (n := (F -i 4))))
  (pure ((sign +++ exp) +++ frac))

def IsFault (addrdesc : AddressDescriptor) : Bool :=
  (bne addrdesc.fault.statuscode Fault_None)

def IsFault__1 (fault : Fault) : Bool :=
  (bne fault Fault_None)

def IsFault__2 (retstatus : PhysMemRetStatus) : Bool :=
  (bne retstatus.statuscode Fault_None)

def undefined_CNTHP_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHP_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_CNTHP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTP_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_CNTV_CTL_Type_ENABLE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def undefined_CNTHP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTHP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTHP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHP_CTL ) : SailM CNTHP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHP_CTL_EL2) 0 32)))

def CNTHP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHP_CTL_Type := value_name
  writeReg CNTHP_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHP_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHP_CTL r

def undefined_CNTHP_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHP_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTP_CTL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTP_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_CNTP_CTL_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def CNTP_CTL_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTP_CTL_NS ) : SailM CNTP_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTP_CTL_EL0) 0 32)))

def CNTP_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CNTP_CTL_Type ()) ) : SailM CNTP_CTL_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CNTP_CTL_S)
  else (do (CNTP_CTL_NS_read ())))

def CNTP_CTL_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  writeReg CNTP_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTP_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTP_CTL_NS r

def CNTP_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTP_CTL_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CNTP_CTL_S r)
  else (do (CNTP_CTL_NS_write r)))

def undefined_CNTP_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTP_CVAL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTP_CVAL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_CTL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTV_CTL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTV_CVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTV_CVAL_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHPS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHPS_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHPS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHPS_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHVS_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHVS_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHVS_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHVS_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHV_CTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHV_CTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTHV_CVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHV_CVAL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTPS_CTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTPS_CTL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTPS_CVAL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTPS_CVAL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_CNTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HaveCNTSCExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_CNTSC)

def undefined_CNTKCTL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTKCTL_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def HaveMPAMExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAM)

def Have16bitVMID (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_VMID16)

def AArch64_HaveHPDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HPDS)


end ArmASL.Functions
