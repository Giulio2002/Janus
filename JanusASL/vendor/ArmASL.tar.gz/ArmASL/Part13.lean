import ArmASL.Part12

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_GICR_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_PENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_PROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_SETLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_SYNCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VPENDBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VPROPBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_VSGIPENDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_VSGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_WAKER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICV_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CBASER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CREADR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_CWRITER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPAMIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_MPIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_PARTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_SGIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GITS_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GITS_TYPER_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_MCTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MGRPEN1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ICC_MSRE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCFGR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCGCR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMIIDR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMMIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPCSCTL_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_PMVCIDSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCFGR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCFGR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCFGR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCFGR ) : SailM AMCFGR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCFGR_EL0) 0 32)))

def AMCFGR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCFGR_Type := value_name
  writeReg AMCFGR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCFGR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCFGR r

def undefined_AMCGCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCGCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCGCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCGCR ) : SailM AMCGCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCGCR_EL0) 0 32)))

def AMCGCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCGCR_Type := value_name
  writeReg AMCGCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCGCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCGCR r

def undefined_AMCNTENCLR0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR0 ) : SailM AMCNTENCLR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR0_EL0) 0 32)))

def AMCNTENCLR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR0_Type := value_name
  writeReg AMCNTENCLR0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR0 r

def undefined_AMCNTENCLR1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENCLR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENCLR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENCLR1 ) : SailM AMCNTENCLR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENCLR1_EL0) 0 32)))

def AMCNTENCLR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENCLR1_Type := value_name
  writeReg AMCNTENCLR1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENCLR1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENCLR1 r

def undefined_AMCNTENSET0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET0 ) : SailM AMCNTENSET0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET0_EL0) 0 32)))

def AMCNTENSET0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET0_Type := value_name
  writeReg AMCNTENSET0_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET0 r

def undefined_AMCNTENSET1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCNTENSET1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCNTENSET1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCNTENSET1 ) : SailM AMCNTENSET1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCNTENSET1_EL0) 0 32)))

def AMCNTENSET1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCNTENSET1_Type := value_name
  writeReg AMCNTENSET1_EL0 (Sail.BitVec.updateSubrange (← readReg AMCNTENSET1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCNTENSET1 r

def undefined_AMCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMCR ) : SailM AMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMCR_EL0) 0 32)))

def AMCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMCR_Type := value_name
  writeReg AMCR_EL0 (Sail.BitVec.updateSubrange (← readReg AMCR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMCR r

def undefined_AMUSERENR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMUSERENR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def AMUSERENR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _AMUSERENR ) : SailM AMUSERENR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg AMUSERENR_EL0) 0 32)))

def AMUSERENR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : AMUSERENR_Type := value_name
  writeReg AMUSERENR_EL0 (Sail.BitVec.updateSubrange (← readReg AMUSERENR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _AMUSERENR r

def undefined_CCSIDR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR2 ) : SailM CCSIDR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR2_EL1) 0 32)))

def CCSIDR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR2_Type := value_name
  writeReg CCSIDR2_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR2 r

def undefined_CCSIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CCSIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CCSIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CCSIDR ) : SailM CCSIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CCSIDR_EL1) 0 32)))

def CCSIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CCSIDR_Type := value_name
  writeReg CCSIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CCSIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CCSIDR r

def undefined_CNTHCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHCTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHCTL ) : SailM CNTHCTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHCTL_EL2) 0 32)))

def CNTHCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHCTL_Type := value_name
  writeReg CNTHCTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHCTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHCTL r

def undefined_CNTHPS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHPS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHPS_CTL ) : SailM CNTHPS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHPS_CTL_EL2) 0 32)))

def CNTHPS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHPS_CTL_Type := value_name
  writeReg CNTHPS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHPS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHPS_CTL r

def undefined_CNTHVS_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHVS_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHVS_CTL ) : SailM CNTHVS_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHVS_CTL_EL2) 0 32)))

def CNTHVS_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHVS_CTL_Type := value_name
  writeReg CNTHVS_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHVS_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHVS_CTL r

def undefined_CNTHV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTHV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTHV_CTL ) : SailM CNTHV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTHV_CTL_EL2) 0 32)))

def CNTHV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTHV_CTL_Type := value_name
  writeReg CNTHV_CTL_EL2 (Sail.BitVec.updateSubrange (← readReg CNTHV_CTL_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTHV_CTL r

def CNTKCTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTKCTL_Type := value_name
  writeReg CNTKCTL_EL1 (Sail.BitVec.updateSubrange (← readReg CNTKCTL_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTKCTL r

def undefined_CNTV_CTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CNTV_CTL_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CNTV_CTL ) : SailM CNTV_CTL_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CNTV_CTL_EL0) 0 32)))

def CNTV_CTL_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CNTV_CTL_Type := value_name
  writeReg CNTV_CTL_EL0 (Sail.BitVec.updateSubrange (← readReg CNTV_CTL_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CNTV_CTL r

def CPACR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CPACR_Type := value_name
  writeReg CPACR_EL1 (Sail.BitVec.updateSubrange (← readReg CPACR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CPACR r

def undefined_CSSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CSSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def CSSELR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CSSELR_NS ) : SailM CSSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CSSELR_EL1) 0 32)))

def CSSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_CSSELR_Type ()) ) : SailM CSSELR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg CSSELR_S)
  else (do (CSSELR_NS_read ())))

def CSSELR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  writeReg CSSELR_EL1 (Sail.BitVec.updateSubrange (← readReg CSSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CSSELR_NS r

def CSSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CSSELR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg CSSELR_S r)
  else (do (CSSELR_NS_write r)))

def undefined_CTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CTR ) : SailM CTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CTR_EL0) 0 32)))

def CTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CTR_Type := value_name
  writeReg CTR_EL0 (Sail.BitVec.updateSubrange (← readReg CTR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _CTR r

def undefined_DBGAUTHSTATUS_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGAUTHSTATUS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGAUTHSTATUS ) : SailM DBGAUTHSTATUS_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGAUTHSTATUS_EL1) 0 32)))

def DBGAUTHSTATUS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGAUTHSTATUS_Type := value_name
  writeReg DBGAUTHSTATUS_EL1 (Sail.BitVec.updateSubrange (← readReg DBGAUTHSTATUS_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGAUTHSTATUS r

def undefined_DBGCLAIMCLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMCLR ) : SailM DBGCLAIMCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMCLR_EL1) 0 32)))

def DBGCLAIMCLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMCLR_Type := value_name
  writeReg DBGCLAIMCLR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMCLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMCLR r

def undefined_DBGCLAIMSET_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGCLAIMSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGCLAIMSET_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGCLAIMSET ) : SailM DBGCLAIMSET_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGCLAIMSET_EL1) 0 32)))

def DBGCLAIMSET_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGCLAIMSET_Type := value_name
  writeReg DBGCLAIMSET_EL1 (Sail.BitVec.updateSubrange (← readReg DBGCLAIMSET_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGCLAIMSET r

def undefined_MDCCINT_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDCCINT_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGDCCINT_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGDCCINT ) : SailM DBGDCCINT_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDCCINT_EL1) 0 32)))

def DBGDCCINT_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGDCCINT_Type := value_name
  writeReg MDCCINT_EL1 (Sail.BitVec.updateSubrange (← readReg MDCCINT_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGDCCINT r

def undefined_MDRAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGDRAR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def DBGDRAR_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _DBGDRAR ) : SailM DBGDRAR_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg MDRAR_EL1) 0 64)))

def DBGDRAR_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : DBGDRAR_Type := value_name
  writeReg MDRAR_EL1 (Sail.BitVec.updateSubrange (← readReg MDRAR_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _DBGDRAR r

def DBGOSDLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSDLR_Type := value_name
  writeReg OSDLR_EL1 (Sail.BitVec.updateSubrange (← readReg OSDLR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSDLR r

def DBGOSLSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGOSLSR_Type := value_name
  writeReg OSLSR_EL1 (Sail.BitVec.updateSubrange (← readReg OSLSR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGOSLSR r

def DBGPRCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGPRCR_Type := value_name
  writeReg DBGPRCR_EL1 (Sail.BitVec.updateSubrange (← readReg DBGPRCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGPRCR r

def undefined_DBGVCR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DBGVCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def DBGVCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DBGVCR ) : SailM DBGVCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DBGVCR32_EL2) 0 32)))

def DBGVCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DBGVCR_Type := value_name
  writeReg DBGVCR32_EL2 (Sail.BitVec.updateSubrange (← readReg DBGVCR32_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _DBGVCR r

def DFSR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DFSR_NS ) : SailM DFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ESR_EL1) 0 32)))

def DFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_DFSR_Type ()) ) : SailM DFSR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg DFSR_S)
  else (do (DFSR_NS_read ())))

def DISR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DISR ) : SailM DISR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DISR_EL1) 0 32)))

def DSPSR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _DSPSR2 ) : SailM DSPSR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg DSPSR_EL0) 32 32)))

def EDECCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDECCR_Type := value_name
  writeReg OSECCR_EL1 (Sail.BitVec.updateSubrange (← readReg OSECCR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _EDECCR r

def EDSCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDSCR2_Type := value_name
  writeReg MDSCR_EL1 (Sail.BitVec.updateSubrange (← readReg MDSCR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _EDSCR2 r

def undefined_ERRIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRIDR ) : SailM ERRIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRIDR_EL1) 0 32)))

def ERRIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRIDR_Type := value_name
  writeReg ERRIDR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRIDR r

def undefined_ERRSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ERRSELR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ERRSELR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ERRSELR ) : SailM ERRSELR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ERRSELR_EL1) 0 32)))

def ERRSELR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ERRSELR_Type := value_name
  writeReg ERRSELR_EL1 (Sail.BitVec.updateSubrange (← readReg ERRSELR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ERRSELR r

def HCPTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCPTR_Type := value_name
  writeReg CPTR_EL2 (Sail.BitVec.updateSubrange (← readReg CPTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HCPTR r

def HCR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HCR2_Type := value_name
  writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 63 32 (BitVec.slice r 0 32))
  writeReg _HCR2 r

def HDCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HDCR_Type := value_name
  writeReg MDCR_EL2 (Sail.BitVec.updateSubrange (← readReg MDCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HDCR r

def undefined_RMR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HRMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HRMR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HRMR ) : SailM HRMR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg RMR_EL2) 0 32)))

def HRMR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HRMR_Type := value_name
  writeReg RMR_EL2 (Sail.BitVec.updateSubrange (← readReg RMR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HRMR r

def HSCTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSCTLR_Type := value_name
  writeReg SCTLR_EL2 (Sail.BitVec.updateSubrange (← readReg SCTLR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSCTLR r

def undefined_HSTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HSTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HSTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HSTR ) : SailM HSTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HSTR_EL2) 0 32)))

def HSTR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSTR_Type := value_name
  writeReg HSTR_EL2 (Sail.BitVec.updateSubrange (← readReg HSTR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSTR r

def undefined_HTCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTCR ) : SailM HTCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL2) 0 32)))

def HTCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTCR_Type := value_name
  writeReg TCR_EL2 (Sail.BitVec.updateSubrange (← readReg TCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTCR r

def undefined_TRFCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HTRFCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def HTRFCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HTRFCR ) : SailM HTRFCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TRFCR_EL2) 0 32)))

def HTRFCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HTRFCR_Type := value_name
  writeReg TRFCR_EL2 (Sail.BitVec.updateSubrange (← readReg TRFCR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HTRFCR r

def HVBAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HVBAR_Type := value_name
  writeReg VBAR_EL2 (Sail.BitVec.updateSubrange (← readReg VBAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HVBAR r

def undefined_ICC_ASGI1R_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_ASGI1R_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_ASGI1R_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _ICC_ASGI1R ) : SailM ICC_ASGI1R_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg ICC_ASGI1R_EL1) 0 64)))

def ICC_ASGI1R_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_ASGI1R_Type := value_name
  writeReg ICC_ASGI1R_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_ASGI1R_EL1) 63 0 (BitVec.slice r 0 64))
  writeReg _ICC_ASGI1R r

def undefined_ICC_BPR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR0 ) : SailM ICC_BPR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR0_EL1) 0 32)))

def ICC_BPR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR0_Type := value_name
  writeReg ICC_BPR0_EL1 (Sail.BitVec.updateSubrange (← readReg ICC_BPR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR0 r

def undefined_ICC_BPR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_BPR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_BPR1_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_NS ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_NS) 0 32)))

def ICC_BPR1_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_BPR1_S ) : SailM ICC_BPR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_BPR1_EL1_S) 0 32)))

def ICC_BPR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_BPR1_Type ()) ) : SailM ICC_BPR1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_read ()))
  else (do (ICC_BPR1_NS_read ())))

def ICC_BPR1_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_NS r

def ICC_BPR1_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  writeReg ICC_BPR1_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_BPR1_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_BPR1_S r

def ICC_BPR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_BPR1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_BPR1_S_write r))
  else (do (ICC_BPR1_NS_write r)))

def undefined_ICC_CTLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_CTLR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_NS ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_NS) 0 32)))

def ICC_CTLR_S_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_CTLR_S ) : SailM ICC_CTLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_CTLR_EL1_S) 0 32)))

def ICC_CTLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_ICC_CTLR_Type ()) ) : SailM ICC_CTLR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_read ()))
  else (do (ICC_CTLR_NS_read ())))

def ICC_CTLR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_NS (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_NS) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_NS r

def ICC_CTLR_S_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  writeReg ICC_CTLR_EL1_S (Sail.BitVec.updateSubrange (← readReg ICC_CTLR_EL1_S) 31 0 (BitVec.slice r 0 32))
  writeReg _ICC_CTLR_S r

def ICC_CTLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ICC_CTLR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do (ICC_CTLR_S_write r))
  else (do (ICC_CTLR_NS_write r)))

def undefined_ICC_DIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ICC_DIR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ICC_DIR ) : SailM ICC_DIR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ICC_DIR_EL1) 0 32)))


end ArmASL.Functions
