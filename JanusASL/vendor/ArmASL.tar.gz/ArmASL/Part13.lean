import ArmASL.Part12

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def AArch32_IMPDEFResets (_ : Unit) : SailM Unit := do
  (PMCR_write (_update_PMCR_Type_IMP (← (PMCR_read ())) (Zeros (n := 8))))
  (PMCR_write
    (_update_PMCR_Type_IDCODE (← (PMCR_read ()))
      (← do
        (if ((IsZero (_get_PMCR_Type_IMP (← (PMCR_read ())))) : Bool)
        then (do (pure (Zeros (n := 8))))
        else (do (pure CFG_PMCR_IDCODE))))))
  (PMCR_write (_update_PMCR_Type_N (← (PMCR_read ())) (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  (PMCR_write (_update_PMCR_Type_C (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_P (← (PMCR_read ())) 0#1))
  (PMCEID0_write (Mk_PMCEID0_Type 0b01001000000000100000000100000001#32))
  (PMCEID2_write (Mk_PMCEID2_Type (Sail.BitVec.zeroExtend 0b1111#4 32)))
  (PMCEID1_write (Mk_PMCEID1_Type (Zeros (n := 32))))
  (PMCEID3_write (Mk_PMCEID3_Type (Zeros (n := 32))))
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 31 28 0b0000#4)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 21 21 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 19 19 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 18 18 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 17 17 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 16 16 0#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 15 15 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 14 14 1#1)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 13 8 0b111111#6)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 7 0 (0b000#3 +++ (integer_subrange (← readReg NUM_PMU_COUNTERS) 4 0)))
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 7 4 0b0001#4)
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 3 0 0b0110#4)
  writeReg PMPIDR0 (Sail.BitVec.updateSubrange (← readReg PMPIDR0) 7 0 0b00001111#8)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 7 4 0b1011#4)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 3 0 0b1101#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 7 4 0b0000#4)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 3 3 1#1)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 2 0 0b011#3)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 7 4 0b0000#4)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 3 0 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 7 4 0b0000#4)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 3 0 0b0100#4)
  writeReg PMCIDR0 (Sail.BitVec.updateSubrange (← readReg PMCIDR0) 7 0 0b00001101#8)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 7 4 0b1001#4)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 3 0 0b0000#4)
  writeReg PMCIDR2 (Sail.BitVec.updateSubrange (← readReg PMCIDR2) 7 0 0b00000101#8)
  writeReg PMCIDR3 (Sail.BitVec.updateSubrange (← readReg PMCIDR3) 7 0 0b10110001#8)
  writeReg VBAR_S (Sail.BitVec.updateSubrange (← readReg VBAR_S) 31 5 (Zeros (n := 27)))
  (CCSIDR_write (_update_CCSIDR_Type_Associativity (← (CCSIDR_read ())) (Sail.BitVec.zeroExtend 0x1#4 21)))
  (CCSIDR_write (_update_CCSIDR_Type_LineSize (← (CCSIDR_read ())) 0b010#3))
  (CLIDR_write (_update_CLIDR_Type_ICB (← (CLIDR_read ())) 0b00#2))
  (CLIDR_write (_update_CLIDR_Type_LoUU (← (CLIDR_read ())) 0b000#3))
  (CLIDR_write (_update_CLIDR_Type_LoUIS (← (CLIDR_read ())) 0b000#3))
  (CLIDR_write (Mk_CLIDR_Type (Sail.BitVec.updateSubrange (← (CLIDR_read ())) 20 0 0b000000000000000100011#21)))
  (CTR_write (_update_CTR_Type_DIC (← (CTR_read ())) 0#1))
  (CTR_write (_update_CTR_Type_IDC (← (CTR_read ())) 0#1))
  (CTR_write (_update_CTR_Type_CWG (← (CTR_read ())) 0b0100#4))
  (CTR_write (_update_CTR_Type_ERG (← (CTR_read ())) (← readReg __exclusive_granule_size)))
  (CTR_write (_update_CTR_Type_DminLine (← (CTR_read ())) 0b0100#4))
  (CTR_write (_update_CTR_Type_L1Ip (← (CTR_read ())) 0b10#2))
  (CTR_write (_update_CTR_Type_IminLine (← (CTR_read ())) 0b0100#4))
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 31 24 0b01000001#8)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 23 23 0#1)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 22 16 0b0000100#7)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 15 8 0b00110000#8)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 7 4 0b0111#4)
  writeReg FPSID (Sail.BitVec.updateSubrange (← readReg FPSID) 3 0 0b0000#4)
  (ID_DFR0_write (_update_ID_DFR0_Type_MProfDbg (← (ID_DFR0_read ())) 0b0000#4))
  (ID_DFR0_write (_update_ID_DFR0_Type_MMapDbg (← (ID_DFR0_read ())) 0b0000#4))
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
  then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
  else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())))))))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Divide (← (ID_ISAR0_read ())) 0b0010#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Debug (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Coproc (← (ID_ISAR0_read ())) 0b0000#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_CmpBranch (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_BitField (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_BitCount (← (ID_ISAR0_read ())) 0b0001#4))
  (ID_ISAR0_write (_update_ID_ISAR0_Type_Swap (← (ID_ISAR0_read ())) 0b0000#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Jazelle (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Interwork (← (ID_ISAR1_read ())) 0b0011#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Immediate (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_IfThen (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Extend (← (ID_ISAR1_read ())) 0b0010#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Except_AR (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Except (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR1_write (_update_ID_ISAR1_Type_Endian (← (ID_ISAR1_read ())) 0b0001#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_Reversal (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_PSR_AR (← (ID_ISAR2_read ())) 0b0001#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultU (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultS (← (ID_ISAR2_read ())) 0b0011#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_Mult (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MultiAccessInt (← (ID_ISAR2_read ())) 0b0000#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_MemHint (← (ID_ISAR2_read ())) 0b0100#4))
  (ID_ISAR2_write (_update_ID_ISAR2_Type_LoadStore (← (ID_ISAR2_read ())) 0b0010#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_T32EE (← (ID_ISAR3_read ())) 0b0000#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_TrueNOP (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_T32Copy (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_TabBranch (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SynchPrim (← (ID_ISAR3_read ())) 0b0010#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SVC (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_SIMD (← (ID_ISAR3_read ())) 0b0011#4))
  (ID_ISAR3_write (_update_ID_ISAR3_Type_Saturate (← (ID_ISAR3_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SWP_frac (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_PSR_M (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SynchPrim_frac (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Barrier (← (ID_ISAR4_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_SMC (← (ID_ISAR4_read ())) 0b0000#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Writeback (← (ID_ISAR4_read ())) 0b0001#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_WithShifts (← (ID_ISAR4_read ())) 0b0100#4))
  (ID_ISAR4_write (_update_ID_ISAR4_Type_Unpriv (← (ID_ISAR4_read ())) 0b0010#4))
  writeReg ID_MMFR5_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR5_EL1) 7 4 0b0001#4)
  (ID_ISAR5_write (_update_ID_ISAR5_Type_VCMA (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_RDM (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_CRC32 (← (ID_ISAR5_read ())) 0b0000#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SHA2 (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SHA1 (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_AES (← (ID_ISAR5_read ())) 0b0010#4))
  (ID_ISAR5_write (_update_ID_ISAR5_Type_SEVL (← (ID_ISAR5_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_DP (← (ID_ISAR6_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_BF16 (← (ID_ISAR6_read ())) 0b0001#4))
  (ID_ISAR6_write (_update_ID_ISAR6_Type_I8MM (← (ID_ISAR6_read ())) 0b0001#4))
  (if ((← (IsFeatureImplemented FEAT_FP16)) : Bool)
  then
    (do (MVFR1_write (_update_MVFR1_Type_FPHP (← (MVFR1_read ())) 0b0011#4))
        (MVFR1_write (_update_MVFR1_Type_SIMDHP (← (MVFR1_read ())) 0b0010#4)))
  else
    (do (MVFR1_write (_update_MVFR1_Type_FPHP (← (MVFR1_read ())) 0b0010#4))
        (MVFR1_write (_update_MVFR1_Type_SIMDHP (← (MVFR1_read ())) 0b0001#4))))
  (if ((HasArchVersion v8Ap3) : Bool)
  then
    (do (ID_MMFR4_write (_update_ID_MMFR4_Type_CCIDX (← (ID_MMFR4_read ())) 0b0001#4))
        (ID_ISAR6_write (_update_ID_ISAR6_Type_JSCVT (← (ID_ISAR6_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_TraceFilt (← (ID_DFR0_read ())) 0b0001#4)))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then
    (do writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 39 36 0b0001#4)
        (ID_ISAR6_write (_update_ID_ISAR6_Type_FHM (← (ID_ISAR6_read ())) 0b0001#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_AMU (← (ID_PFR0_read ())) 0b0001#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_DIT (← (ID_PFR0_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1001#4))
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
        else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_EL1_Type_CopDbg (← readReg ID_DFR0_EL1)))))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap7) : Bool)
  then (do (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b0111#4)))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do (ID_MMFR5_write (_update_ID_MMFR5_Type_ETS (← (ID_MMFR5_read ())) 0b0010#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1010#4))
        (if ((←((pure (! (HaveEL EL3))) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 1#1))))) : Bool)
        then (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b0000#4)))
        else (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) (_get_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ()))))))))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap6) : Bool)
  then
    (do (ID_PFR1_write (_update_ID_PFR1_Type_GenTimer (← (ID_PFR1_read ())) 0b0010#4))
        (ID_PFR0_write (_update_ID_PFR0_Type_AMU (← (ID_PFR0_read ())) 0b0010#4)))
  else (do (pure ())))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_InnerShr (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_FCSE (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_AuxReg (← (ID_MMFR0_read ())) 0b0010#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_TCM (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_ShareLvl (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_OuterShr (← (ID_MMFR0_read ())) 0b0001#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_PMSA (← (ID_MMFR0_read ())) 0b0000#4))
  (ID_MMFR0_write (_update_ID_MMFR0_Type_VMSA (← (ID_MMFR0_read ())) 0b0101#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_BPred (← (ID_MMFR1_read ())) 0b0010#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1TstCln (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1Uni (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1Hvd (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1UniSW (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1HvdSW (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1UniVA (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR1_write (_update_ID_MMFR1_Type_L1HvdVA (← (ID_MMFR1_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_HWAccFlg (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_WFIStall (← (ID_MMFR2_read ())) 0b0001#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_MemBarr (← (ID_MMFR2_read ())) 0b0010#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_UniTLB (← (ID_MMFR2_read ())) 0b0110#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_HvdTLB (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdRng (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdBG (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR2_write (_update_ID_MMFR2_Type_L1HvdFG (← (ID_MMFR2_read ())) 0b0000#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_Supersec (← (ID_MMFR3_read ())) 0b0000#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMemSz (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CohWalk (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_PAN (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_MaintBcst (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_BPMaint (← (ID_MMFR3_read ())) 0b0010#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMaintSW (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_MMFR3_write (_update_ID_MMFR3_Type_CMaintVA (← (ID_MMFR3_read ())) 0b0001#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_RAS (← (ID_PFR0_read ())) 0b0010#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State3 (← (ID_PFR0_read ())) 0b0000#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State2 (← (ID_PFR0_read ())) 0b0001#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State1 (← (ID_PFR0_read ())) 0b0011#4))
  (ID_PFR0_write (_update_ID_PFR0_Type_State0 (← (ID_PFR0_read ())) 0b0001#4))
  (ID_DFR1_write (_update_ID_DFR1_Type_MTPMU (← (ID_DFR1_read ())) 0b0001#4))
  (if ((HasArchVersion v8Ap5) : Bool)
  then
    (do (ID_PFR0_write (_update_ID_PFR0_Type_CSV2 (← (ID_PFR0_read ())) 0b0001#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b0110#4)))
  else (do (pure ())))
  (ID_DFR0_write (_update_ID_DFR0_Type_MMapTrc (← (ID_DFR0_read ())) 0b0001#4))
  (ID_DFR0_write (_update_ID_DFR0_Type_CopTrc (← (ID_DFR0_read ())) 0b0001#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_GIC (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Virt_frac (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Sec_frac (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_MProgMod (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_ProgMod (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Security (← (ID_PFR1_read ())) 0b0000#4))
  (ID_PFR1_write (_update_ID_PFR1_Type_Virtualization (← (ID_PFR1_read ())) 0b0000#4))
  (MIDR_write (_update_MIDR_Type_Implementer (← (MIDR_read ())) 0b01000001#8))
  (MIDR_write (_update_MIDR_Type_Variant (← (MIDR_read ())) 0b0000#4))
  (MIDR_write (_update_MIDR_Type_Architecture (← (MIDR_read ())) 0b1111#4))
  (MIDR_write (_update_MIDR_Type_PartNum (← (MIDR_read ())) 0b110100001111#12))
  (MIDR_write (_update_MIDR_Type_Revision (← (MIDR_read ())) 0b0000#4))
  (VPIDR_write (_update_VPIDR_Type_Implementer (← (VPIDR_read ())) 0b01000001#8))
  (VPIDR_write (_update_VPIDR_Type_Variant (← (VPIDR_read ())) 0b0000#4))
  (VPIDR_write (_update_VPIDR_Type_Architecture (← (VPIDR_read ())) 0b1111#4))
  (VPIDR_write (_update_VPIDR_Type_PartNum (← (VPIDR_read ())) 0b110100001111#12))
  (VPIDR_write (_update_VPIDR_Type_Revision (← (VPIDR_read ())) 0b0000#4))
  (MPIDR_write (_update_MPIDR_Type_M (← (MPIDR_read ())) 1#1))
  (MPIDR_write (_update_MPIDR_Type_U (← (MPIDR_read ())) 0#1))
  (MPIDR_write (_update_MPIDR_Type_MT (← (MPIDR_read ())) 0#1))
  (MPIDR_write (_update_MPIDR_Type_Aff2 (← (MPIDR_read ())) 0b00000000#8))
  (MPIDR_write (_update_MPIDR_Type_Aff1 (← (MPIDR_read ())) 0b00000000#8))
  (MPIDR_write (_update_MPIDR_Type_Aff0 (← (MPIDR_read ())) 0b00000000#8))
  (MVFR0_write (_update_MVFR0_Type_FPRound (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPShVec (← (MVFR0_read ())) 0b0000#4))
  (MVFR0_write (_update_MVFR0_Type_FPSqrt (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPDivide (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPTrap (← (MVFR0_read ())) 0b0001#4))
  (MVFR0_write (_update_MVFR0_Type_FPDP (← (MVFR0_read ())) 0b0010#4))
  (MVFR0_write (_update_MVFR0_Type_FPSP (← (MVFR0_read ())) 0b0010#4))
  (MVFR0_write (_update_MVFR0_Type_SIMDReg (← (MVFR0_read ())) 0b0010#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDFMAC (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDSP (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDInt (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_SIMDLS (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_FPDNaN (← (MVFR1_read ())) 0b0001#4))
  (MVFR1_write (_update_MVFR1_Type_FPFtZ (← (MVFR1_read ())) 0b0001#4))
  (MVFR2_write (_update_MVFR2_Type_FPMisc (← (MVFR2_read ())) 0b0100#4))
  (MVFR2_write (_update_MVFR2_Type_SIMDMisc (← (MVFR2_read ())) 0b0011#4))
  writeReg TLBTR (Sail.BitVec.updateSubrange (← readReg TLBTR) 0 0 0#1)
  (HSCTLR_write (_update_HSCTLR_Type_EE (← (HSCTLR_read ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_TE (← (SCTLR_read__2 ())) (_get_Configuration_Type_ExceptInit (← readReg _ConfigReg))))
  (SCTLR_write (_update_SCTLR_Type_EE (← (SCTLR_read__2 ())) (_get_Configuration_Type_CFGEND (← readReg _ConfigReg))))
  (SCTLR_write (_update_SCTLR_Type_SPAN (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_V (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_UNK (← (SCTLR_read__2 ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_EX (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_FP2V (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_VV (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_TFV (← (FPEXC_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_VECITR (← (FPEXC_read ())) 0b111#3))
  (HTCR_write (_update_HTCR_Type_HWU62 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU61 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU60 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HWU59 (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_HPD (← (HTCR_read ())) 0#1))
  (HTCR_write (_update_HTCR_Type_SH0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_ORGN0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_IRGN0 (← (HTCR_read ())) 0b00#2))
  (HTCR_write (_update_HTCR_Type_T0SZ (← (HTCR_read ())) 0b000#3))
  (NMRR_write (Mk_NMRR_Type (Sail.BitVec.updateSubrange (← (NMRR_read ())) 31 16 0b0100010011100000#16)))
  (NMRR_write (Mk_NMRR_Type (Sail.BitVec.updateSubrange (← (NMRR_read ())) 15 0 0b0100100011100000#16)))
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 11 11 0#1)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 10 10 0#1)
  (PRRR_write (Mk_PRRR_Type (Sail.BitVec.updateSubrange (← (PRRR_read ())) 31 24 (Zeros (n := 8)))))
  (PRRR_write (_update_PRRR_Type_NS1 (← (PRRR_read ())) 1#1))
  (PRRR_write (_update_PRRR_Type_NS0 (← (PRRR_read ())) 0#1))
  (PRRR_write (_update_PRRR_Type_DS1 (← (PRRR_read ())) 0#1))
  (PRRR_write (_update_PRRR_Type_DS0 (← (PRRR_read ())) 1#1))
  (PRRR_write (Mk_PRRR_Type (Sail.BitVec.updateSubrange (← (PRRR_read ())) 15 0 0b1000101010100100#16)))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 31 28 (integer_subrange ((← readReg NUM_WATCHPOINTS) -i 1) 3 0))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 27 24 (integer_subrange ((← readReg NUM_BREAKPOINTS) -i 1) 3 0))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 23 20 (integer_subrange ((← readReg __num_ctx_breakpoints) -i 1) 3 0))
  (if ((HasArchVersion v8Ap2) : Bool)
  then (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1000#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap4) : Bool)
  then (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1001#4))
  else (do (pure ())))
  (if ((HasArchVersion v8Ap8) : Bool)
  then
    (do writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1010#4)
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b1000#4)))
  else (do (pure ())))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 14 14 1#1)
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 12 12 1#1)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 7 4 0b0001#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 11 8 0b1111#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 15 12 0b0000#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 19 16 0b0001#4)
  writeReg DBGDEVID (Sail.BitVec.updateSubrange (← readReg DBGDEVID) 27 24 0b0001#4)
  (HDCR_write (_update_HDCR_Type_HPMN (← (HDCR_read ())) (_get_PMCR_Type_N (← (PMCR_read ())))))
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 0 0 1#1)
  (ICC_HSRE_write (_update_ICC_HSRE_Type_SRE (← (ICC_HSRE_read ())) 1#1))
  writeReg JMCR (Zeros (n := 32))
  writeReg JOSCR (Zeros (n := 32))
  writeReg JIDR (Zeros (n := 32))
  (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLM (← (DBGOSLSR_read ())) 0b10#2))
  (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLK (← (DBGOSLSR_read ())) 1#1))
  (HCPTR_write (_update_HCPTR_Type_TCPAC (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TTA (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TASE (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TCP11 (← (HCPTR_read ())) 0#1))
  (HCPTR_write (_update_HCPTR_Type_TCP10 (← (HCPTR_read ())) 0#1))
  (if ((HasArchVersion v9Ap4) : Bool)
  then
    (do (ID_DFR0_write (_update_ID_DFR0_Type_CopSDbg (← (ID_DFR0_read ())) 0b1011#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_CopDbg (← (ID_DFR0_read ())) 0b1011#4))
        (ID_DFR0_write (_update_ID_DFR0_Type_PerfMon (← (ID_DFR0_read ())) 0b1001#4))
        (ID_ISAR6_write (_update_ID_ISAR6_Type_SPECRES (← (ID_ISAR6_read ())) 0b0010#4))
        (ID_ISAR6_write (Mk_ID_ISAR6_Type (Sail.BitVec.updateSubrange (← (ID_ISAR6_read ())) 31 28 0b0001#4)))
        writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 19 16 0b1011#4)
        writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 7 4 0b0010#4))
  else (do (pure ())))

def undefined_ACCDATA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_AMCG1IDR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_BRBINFINJ_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHPS_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHP_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHVS_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTHV_TVAL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTPS_TVAL_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTP_TVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_CNTV_TVAL_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DACR32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_DCZID_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GMID_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HAFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGRTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGWTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HDFGWTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGRTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGRTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGWTR2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_HFGWTR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_CTLR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_IGRPEN1_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_NMIAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICC_SRE_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ICV_NMIAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ISAR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64MMFR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64PFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64SMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_AA64ZFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORC_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LOREA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORID_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORN_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_LORSA_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MDSELR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MECIDR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_OSLAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMBIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMECR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMMIR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSEVFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSFCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSICR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSIRR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSLATFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSNEVFR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMSSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMUACR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMXEVCNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMZR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SMIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SMPRI_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_SPMSELR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def ICC_BPR1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_BPR1_EL1_Type ()) ) : SailM ICC_BPR1_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_BPR1_EL1_S)
  else (do readReg ICC_BPR1_EL1_NS))

def ICC_BPR1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_BPR1_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_BPR1_EL1_S r)
  else (do writeReg ICC_BPR1_EL1_NS r))

def ICC_CTLR_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_CTLR_EL1_Type ()) ) : SailM ICC_CTLR_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_CTLR_EL1_S)
  else (do readReg ICC_CTLR_EL1_NS))

def ICC_CTLR_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_CTLR_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_CTLR_EL1_S r)
  else (do writeReg ICC_CTLR_EL1_NS r))

def ICC_IGRPEN1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_IGRPEN1_EL1_Type ()) ) : SailM ICC_IGRPEN1_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_IGRPEN1_EL1_S)
  else (do readReg ICC_IGRPEN1_EL1_NS))

def ICC_IGRPEN1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_IGRPEN1_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_IGRPEN1_EL1_S r)
  else (do writeReg ICC_IGRPEN1_EL1_NS r))

def ICC_SRE_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_ICC_SRE_EL1_Type ()) ) : SailM ICC_SRE_EL1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg ICC_SRE_EL1_S)
  else (do readReg ICC_SRE_EL1_NS))

def ICC_SRE_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : ICC_SRE_EL1_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg ICC_SRE_EL1_S r)
  else (do writeReg ICC_SRE_EL1_NS r))

def MPAM3_EL3_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM3_EL3_Type := value_name
  writeReg MPAM2_EL2 (BitVec.update (← readReg MPAM2_EL2) 63 (Bit (BitVec.slice r 63 1)))
  writeReg _MPAM3_EL3 r

def MPAM1_EL1_write (value_name : (BitVec 64)) : SailM Unit := do
  let r : MPAM1_EL1_Type := value_name
  (if ((HaveEL EL3) : Bool)
  then (do (MPAM3_EL3_write (Mk_MPAM3_EL3_Type (set_slice 1 (← (MPAM3_EL3_read ())) 63 (BitVec.slice r 63 1)))))
  else (do writeReg MPAM2_EL2 (BitVec.update (← readReg MPAM2_EL2) 63 (Bit (BitVec.slice r 63 1)))))
  writeReg _MPAM1_EL1 r

def Mk_ICC_BPR1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_CTLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_IGRPEN1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_ICC_SRE_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def Mk_PAR_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def undefined_PAR_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def PAR_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _PAR_EL1 ) : SailM PAR_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (PAR_read ())) 0 64)))

def PAR_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : PAR_EL1_Type := value_name
  (PAR_write (Mk_PAR_Type (set_slice 64 (← (PAR_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _PAR_EL1 r

def TTBR0_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR0_EL1_Type := value_name
  (TTBR0_write (Mk_TTBR0_Type (set_slice 64 (← (TTBR0_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _TTBR0_EL1 r

def TTBR0_EL2_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR0_EL2_Type := value_name
  writeReg HTTBR (Sail.BitVec.updateSubrange (← readReg HTTBR) 47 1 (BitVec.slice r 1 47))
  writeReg _TTBR0_EL2 r

def TTBR1_EL1_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : TTBR1_EL1_Type := value_name
  (TTBR1_write (Mk_TTBR1_Type (set_slice 64 (← (TTBR1_read ())) 0 (BitVec.slice r 0 64))))
  writeReg _TTBR1_EL1 r

def VTTBR_EL2_write (value_name : (BitVec 128)) : SailM Unit := do
  let r : VTTBR_EL2_Type := value_name
  writeReg VTTBR (Sail.BitVec.updateSubrange (← readReg VTTBR) 63 0 (BitVec.slice r 0 64))
  writeReg _VTTBR_EL2 r

def _update_ICC_IGRPEN1_EL1_Type_Enable (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _update_ICC_SRE_EL1_Type_DFB (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_ICC_SRE_EL1_Type_DIB (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 2 2 x)

def _update_ICC_SRE_EL1_Type_SRE (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 0 0 x)


end ArmASL.Functions
