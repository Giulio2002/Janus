import ArmASL.Part19

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def CNTV_TVAL_EL0_SysRegWrite_1d3b2670e7bc3a02 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CNTV_CVAL_EL0 (Mk_CNTV_CVAL_EL0_Type (((sign_extend (Sail.BitVec.extractLsb (← (X_read t 64)) 31 0) 64) + (← (PhysicalCountInt ()))) - (← readReg CNTVOFF_EL2))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CONTEXTIDR_EL1_SysRegWrite_dd8dc6c6937913e2 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x108#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CONTEXTIDR_EL1 (Mk_CONTEXTIDR_EL1_Type (← (X_read t 64))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CONTEXTIDR_EL1 (Mk_CONTEXTIDR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CONTEXTIDR_EL2_SysRegWrite_8c6e5eeae39e62ee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CONTEXTIDR_EL2 (Mk_CONTEXTIDR_EL2_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CONTEXTIDR_EL2 (Mk_CONTEXTIDR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CONTEXTIDR_EL2_SysRegWrite_ba4861401c41da1a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TVM ← (( do (pure (_get_HCR_EL2_Type_TVM (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_CONTEXTIDR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_CONTEXTIDR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TVM == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_CONTEXTIDR_EL1 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((←((EL2Enabled ()) <&&> (do
                               (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                          then (do (NVMem_set (BitVec.toNat 0x108#12) (← (X_read t 64))))
                          else (do writeReg CONTEXTIDR_EL1 (Mk_CONTEXTIDR_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then (do writeReg CONTEXTIDR_EL2 (Mk_CONTEXTIDR_EL2_Type (← (X_read t 64))))
                    else (do writeReg CONTEXTIDR_EL1 (Mk_CONTEXTIDR_EL1_Type (← (X_read t 64))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CONTEXTIDR_EL1 (Mk_CONTEXTIDR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CPACR_EL1_SysRegWrite_8a190aadf7d2b08b (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TCPAC ← (( do (pure (_get_CPTR_EL3_Type_TCPAC (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if ((←((EL2Enabled ()) <&&> (do
                   (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b101#3))))) : Bool)
              then (do (NVMem_set (BitVec.toNat 0x100#12) (← (X_read t 64))))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else (do writeReg CPACR_EL1 (Mk_CPACR_EL1_Type (← (X_read t 64))))))))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (! (← (ELUsingAArch32 EL2))))))) && (__HCR_EL2_E2H == 1#1)) : Bool)
                          then (do writeReg CPACR_EL1 (Mk_CPACR_EL1_Type (← (X_read t 64))))
                          else (do sailThrow ((Error_Undefined ())))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CPACR_EL1_SysRegWrite_c63495641b6492df (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TCPAC ← (( do (pure (_get_CPTR_EL3_Type_TCPAC (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  let __CPTR_EL2_TCPAC ← (( do (pure (_get_CPTR_EL2_Type_TCPAC (← readReg CPTR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_CPACR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_CPACR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_E2H ← (( do (pure (_get_HCR_EL2_Type_E2H (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if (((← (EL2Enabled ())) && (__CPTR_EL2_TCPAC == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_CPACR_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((HaveEL EL3) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((EL2Enabled ()) <&&> (do
                                           (pure (((_get_HCR_EL2_Type_NV2 (← readReg HCR_EL2)) +++ ((_get_HCR_EL2_Type_NV1 (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_NV (← readReg HCR_EL2)))) == 0b111#3))))) : Bool)
                                      then (do (NVMem_set (BitVec.toNat 0x100#12) (← (X_read t 64))))
                                      else (do writeReg CPACR_EL1 (Mk_CPACR_EL1_Type (← (X_read t 64))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((__HCR_EL2_E2H == 1#1) : Bool)
                                then (do writeReg CPTR_EL2 (Mk_CPTR_EL2_Type (← (X_read t 64))))
                                else (do writeReg CPACR_EL1 (Mk_CPACR_EL1_Type (← (X_read t 64))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CPACR_EL1 (Mk_CPACR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CPTR_EL2_SysRegWrite_26c85eb30bcb8d19 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __CPTR_EL3_TCPAC ← (( do (pure (_get_CPTR_EL3_Type_TCPAC (← readReg CPTR_EL3))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do sailThrow ((Error_Undefined ())))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__CPTR_EL3_TCPAC == 1#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do writeReg CPTR_EL2 (Mk_CPTR_EL2_Type (← (X_read t 64))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CPTR_EL2 (Mk_CPTR_EL2_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CPTR_EL3_SysRegWrite_3835d83d048c2034 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CPTR_EL3 (Mk_CPTR_EL3_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def CSSELR_EL1_SysRegWrite_cd9c3d82f382498a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_TID2 ← (( do (pure (_get_HCR_EL2_Type_TID2 (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TID4 ← (( do (pure (_get_HCR_EL2_Type_TID4 (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HFGWTR_EL2_CSSELR_EL1 ← (( do (pure (_get_HFGWTR_EL2_Type_CSSELR_EL1 (← readReg HFGWTR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TID2 == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TID4 == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HFGWTR_EL2_CSSELR_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do writeReg CSSELR_EL1 (Mk_CSSELR_EL1_Type (← (X_read t 64))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then (do writeReg CSSELR_EL1 (Mk_CSSELR_EL1_Type (← (X_read t 64))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do writeReg CSSELR_EL1 (Mk_CSSELR_EL1_Type (← (X_read t 64))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DACR32_EL2_SysRegWrite_94b89018206732e0 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __HCR_EL2_NV ← (( do (pure (_get_HCR_EL2_Type_NV (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((! (HaveAArch32EL EL1)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_NV == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do sailThrow ((Error_Undefined ())))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then (do writeReg DACR32_EL2 (Mk_DACR32_EL2_Type (← (X_read t 64))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then (do writeReg DACR32_EL2 (Mk_DACR32_EL2_Type (← (X_read t 64))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DAIF_SysRegWrite_523f21b562245414 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __SCTLR_EL1_UMA ← (( do (pure (_get_SCTLR_EL1_Type_UMA (← readReg SCTLR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((EL2Enabled ()) <&&> (do
               (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))) || (__SCTLR_EL1_UMA == 0#1)) : Bool)
        then
          (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
              then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
              else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
        else
          (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 9 6))
              writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
              writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) })))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 9 6))
              writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
              writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
              writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
              writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) })
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 9 6))
                    writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
                    writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
                    writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
                    writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) })
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then
                      (do let split_vec ← do (pure (Sail.BitVec.extractLsb (← (X_read t 64)) 9 6))
                          writeReg PSTATE { (← readReg PSTATE) with D := (Sail.BitVec.extractLsb split_vec 3 3) }
                          writeReg PSTATE { (← readReg PSTATE) with A := (Sail.BitVec.extractLsb split_vec 2 2) }
                          writeReg PSTATE { (← readReg PSTATE) with I := (Sail.BitVec.extractLsb split_vec 1 1) }
                          writeReg PSTATE { (← readReg PSTATE) with F := (Sail.BitVec.extractLsb split_vec 0 0) })
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_02aee1e0e30b8f1d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (6 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 6 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 6 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (6 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 6 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_061098b9cf5c8fa1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (5 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 5 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 5 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (5 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 5 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_1e501456d6155d4d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (1 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 1 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 1 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (1 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 1 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_2d22fdf5e1f2ca10 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (15 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 15 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 15 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 15 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_35bdee83adebd0e9 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (10 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 10 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 10 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (10 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 10 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_5aacf61e65fbc833 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (13 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 13 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 13 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (13 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 13 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_5dfc64a898404c6e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (8 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 8 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 8 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (8 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 8 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_61c83a14b45e16e7 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (11 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 11 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 11 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 11 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_6dec972069cd8973 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (0 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 0 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 0 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (0 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 0 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_744b1c8f0dd2fb3d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (3 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 3 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 3 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (3 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 3 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_88fc06956ff9a27d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (9 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 9 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 9 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (9 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 9 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_8f8afc10abdec5e5 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (7 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 7 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 7 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 7 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_ded364def59ffa88 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (2 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 2 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 2 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (2 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 2 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_ff386e82c1b05d03 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (4 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 4 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 4 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (4 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 4 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_ffc42f78aa082453 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (14 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 14 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 14 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (14 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 14 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBCR_EL1_SysRegWrite_ffdc1fc8f6c7fc45 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBCRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBCRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (12 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBCRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 12 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 12 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) (12 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBCR_EL1 (vectorUpdate (← readReg DBGBCR_EL1) 12 (Mk_DBGBCR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_01d1bc9e52696bd3 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (7 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 7 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 7 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (7 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 7 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_0ffea2b5aaa11a7e (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (15 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 15 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 15 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (15 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 15 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))

/-- Type quantifiers: t : Int -/
def DBGBVR_EL1_SysRegWrite_29714f88a060e4b6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_TDA ← (( do (pure (_get_MDCR_EL3_Type_TDA (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn ← (( do (pure (_get_SCR_EL3_Type_FGTEn (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR_EL2_DBGBVRn_EL1 ← (( do (pure (_get_HDFGWTR_EL2_Type_DBGBVRn_EL1 (← readReg HDFGWTR_EL2))) ) : SailM (BitVec 1) )
  let __EDSCR_TDA ← (( do (pure (_get_EDSCR_Type_TDA (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  (if ((←((pure (! (← (IsFeatureImplemented FEAT_Debugv8p9)))) <&&> (do
       (pure (11 ≥b (← readReg NUM_BREAKPOINTS)))) <||> (do
       (IsFeatureImplemented FEAT_Debugv8p9) <&&> (do
         (pure ((11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) ≥b (← readReg NUM_BREAKPOINTS))))))) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else
    (do (if ((__PSTATE_EL == EL0) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__PSTATE_EL == EL1) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT)))) && ((! (HaveEL EL3)) || (__SCR_EL3_FGTEn == 1#1))) && (__HDFGWTR_EL2_DBGBVRn_EL1 == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if ((←((EL2Enabled ()) <&&> (do
                                     (pure (((_get_MDCR_EL2_Type_TDE (← readReg MDCR_EL2)) +++ (_get_MDCR_EL2_Type_TDA (← readReg MDCR_EL2))) != 0b00#2))))) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else
                                        (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                                   (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                            then (do (Halt DebugHalt_SoftwareAccess))
                                            else
                                              (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                                  then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                                  else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 11 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))))))
              else
                (do (if ((__PSTATE_EL == EL2) : Bool)
                    then
                      (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                                 (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_TDA == 1#1)) : Bool)
                                then
                                  (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                             (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                      then (do (Halt DebugHalt_SoftwareAccess))
                                      else
                                        (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                            then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                            else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 11 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))))))
                    else
                      (do (if ((__PSTATE_EL == EL3) : Bool)
                          then
                            (do (if (((←((pure ((_get_OSLSR_EL1_Type_OSLK (← readReg OSLSR_EL1)) == 0#1)) <&&> (do
                                       (HaltingAllowed ())))) && (__EDSCR_TDA == 1#1)) : Bool)
                                then (do (Halt DebugHalt_SoftwareAccess))
                                else
                                  (do (if ((← (IsFeatureImplemented FEAT_Debugv8p9)) : Bool)
                                      then (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) (11 +i ((BitVec.toNat (← (EffectiveMDSELR_EL1_BANK ()))) *i 16)) (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))
                                      else (do writeReg DBGBVR_EL1 (vectorUpdate (← readReg DBGBVR_EL1) 11 (Mk_DBGBVR_EL1_Type (← (X_read t 64)))))))))
                          else (do (pure ())))))))))))


end ArmASL.Functions
