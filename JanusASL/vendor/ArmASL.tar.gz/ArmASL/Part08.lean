import ArmASL.Part07

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def _get_MPAM1_EL1_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM3_EL3_Type_PARTID_I (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAM2_EL2_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM0_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM1_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM3_EL3_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAMSM_EL1_Type_PMG_D (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 47 40)

def _get_MPAM2_EL2_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM0_EL1_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM1_EL1_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM3_EL3_Type_PMG_I (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAM2_EL2_Type_TRAPMPAM0EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 49 49)

def _get_MPAM2_EL2_Type_TRAPMPAM1EL1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 48 48)

def undefined_MPAM3_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM3_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAM3_EL3_Type_ALTSP_EL3 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_MPAM3_EL3_Type_ALTSP_HEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_MPAM3_EL3_Type_FORCE_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_MPAM3_EL3_Type_RT_ALTSP_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_MPAM3_EL3_Type_SDEFLT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_MPAM3_EL3_Type_TRAPLOWER (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 62 62)

def _update_MPAM3_EL3_Type_TRAPLOWER (v : (BitVec 64)) (x : (BitVec 1)) : (BitVec 64) :=
  (Sail.BitVec.updateSubrange v 62 62 x)

def MPAM3_EL3_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _MPAM3_EL3 ) : SailM MPAM3_EL3_Type )
  (pure (BitVec.update r 63 (Bit (BitVec.slice (← readReg MPAM2_EL2) 63 1))))

def undefined_MPAM1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM1_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def MPAM1_EL1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _MPAM1_EL1 ) : SailM MPAM1_EL1_Type )
  (if ((HaveEL EL3) : Bool)
  then (do (pure (BitVec.update r 63 (Bit (BitVec.slice (← (MPAM3_EL3_read ())) 63 1)))))
  else (do (pure (BitVec.update r 63 (Bit (BitVec.slice (← readReg MPAM2_EL2) 63 1))))))

def MPAMisEnabled (_ : Unit) : SailM Bool := do
  let el : (BitVec 2) := (HighestEL ())
  let questionMark := el
  (if ((questionMark == EL3) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_MPAMEN (← (MPAM3_EL3_read ()))) == 1#1)))
  else
    (do (if ((questionMark == EL2) : Bool)
        then (do (pure ((_get_MPAM2_EL2_Type_MPAMEN (← readReg MPAM2_EL2)) == 1#1)))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do (pure ((_get_MPAM1_EL1_Type_MPAMEN (← (MPAM1_EL1_read ()))) == 1#1)))
              else (do (undefined_bool ())))))))

def UsePrimarySpaceEL10 (_ : Unit) : SailM Bool := do
  (if (((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 0#1)))
  else (do (pure (! (← (MPAMisEnabled ())))) <||> (do (pure (! (← (EL2Enabled ()))))) <||> (do (pure ((_get_MPAM2_EL2_Type_ALTSP_HFC (← readReg MPAM2_EL2)) == 0#1)))))

def UsePrimarySpaceEL2 (_ : Unit) : SailM Bool := do
  (if (((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1) : Bool)
  then (do (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 0#1)))
  else (do (pure (! (← (MPAMisEnabled ())))) <||> (do (pure ((_get_MPAM2_EL2_Type_ALTSP_EL2 (← readReg MPAM2_EL2)) == 0#1)))))

def AltPIdRealm (el : (BitVec 2)) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  let PIdSpace : PARTIDspaceType := primaryPIdSpace
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then
    (do (if ((← (ELIsInHost EL0)) : Bool)
        then
          (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))
        else
          (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then
          (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (Unreachable ())
                    (pure PIdSpace)))))))

def AltPIdSecure (el : (BitVec 2)) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  let PIdSpace : PARTIDspaceType := primaryPIdSpace
  let el2en ← (( do (EL2Enabled ()) ) : SailM Bool )
  let questionMark := el
  (if ((questionMark == EL0) : Bool)
  then
    (do (if (el2en : Bool)
        then
          (do (if ((← (ELIsInHost EL0)) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))))
        else
          (do (if ((←((pure ((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1)) <&&> (do
                   (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 1#1))))) : Bool)
              then (do (pure PIdSpace_NonSecure))
              else (do (pure PIdSpace))))))
  else
    (do (if ((questionMark == EL1) : Bool)
        then
          (do (if (el2en : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL10 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (if ((←((pure ((_get_MPAM3_EL3_Type_ALTSP_HEN (← (MPAM3_EL3_read ()))) == 0#1)) <&&> (do
                         (pure ((_get_MPAM3_EL3_Type_ALTSP_HFC (← (MPAM3_EL3_read ()))) == 1#1))))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (if ((! (← (UsePrimarySpaceEL2 ()))) : Bool)
                    then (do (pure PIdSpace_NonSecure))
                    else (do (pure PIdSpace))))
              else
                (do (Unreachable ())
                    (pure PIdSpace)))))))

def AltPARTIDspace (el : (BitVec 2)) (security : SecurityState) (primaryPIdSpace : PARTIDspaceType) : SailM PARTIDspaceType := do
  match security with
  | .SS_NonSecure =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11334.26-11334.27"
      (pure primaryPIdSpace))
  | .SS_Secure =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11338.26-11338.27"
      (if ((BEq.beq primaryPIdSpace PIdSpace_NonSecure) : Bool)
      then (do (pure primaryPIdSpace))
      else (do (AltPIdSecure el primaryPIdSpace))))
  | .SS_Root =>
    (do
      sail_assert (el == EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11345.26-11345.27"
      (if (((_get_MPAM3_EL3_Type_ALTSP_EL3 (← (MPAM3_EL3_read ()))) == 1#1) : Bool)
      then
        (do (if (((_get_MPAM3_EL3_Type_RT_ALTSP_NS (← (MPAM3_EL3_read ()))) == 1#1) : Bool)
            then (do (pure PIdSpace_NonSecure))
            else (do (pure PIdSpace_Secure))))
      else (do (pure primaryPIdSpace))))
  | .SS_Realm =>
    (do
      sail_assert (el != EL3) "sail-arm/arm-v9.4-a/src/v8_base.sail:11357.26-11357.27"
      (AltPIdRealm el primaryPIdSpace))

def DefaultMPAMinfo (partidspace : PARTIDspaceType) : SailM MPAMinfo := do
  let DefaultInfo ← (( do (undefined_MPAMinfo ()) ) : SailM MPAMinfo )
  let DefaultInfo : MPAMinfo := { DefaultInfo with mpam_sp := partidspace }
  let DefaultInfo : MPAMinfo := { DefaultInfo with partid := DefaultPARTID }
  (pure { DefaultInfo with pmg := DefaultPMG })

def HaveMPAMv0p1Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAMv0p1)

def HaveMPAMv1p1Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MPAMv1p1)

def undefined_MPAMIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_MPAMIDR_EL1_Type_HAS_ALTSP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_MPAMIDR_EL1_Type_HAS_FORCE_NS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_MPAMIDR_EL1_Type_HAS_HCR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_MPAMIDR_EL1_Type_HAS_SDEFLT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_MPAMIDR_EL1_Type_PARTID_MAX (v : (BitVec 64)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 15 0)

def _get_MPAMIDR_EL1_Type_PMG_MAX (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 39 32)

def _get_MPAMIDR_EL1_Type_VPMR_MAX (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 20 18)

def PARTIDspaceFromSS (security : SecurityState) : PARTIDspaceType :=
  match security with
  | .SS_NonSecure => PIdSpace_NonSecure
  | .SS_Root => PIdSpace_Root
  | .SS_Realm => PIdSpace_Realm
  | .SS_Secure => PIdSpace_Secure

def undefined_MPAMHCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMHCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MPAMHCR_EL2_Type_EL0_VPMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_MPAMHCR_EL2_Type_EL1_VPMEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_MPAMHCR_EL2_Type_GSTAPP_PLK (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def undefined_MPAMVPM0_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM0_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPMV_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPMV_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM1_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM1_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM2_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM2_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM3_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM3_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM4_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM4_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM5_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM5_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM6_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM6_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMVPM7_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMVPM7_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: vpartid : Int -/
def mapvpmw (vpartid : Int) : SailM (BitVec 16) := do
  let vpmw ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let wd := (fdiv_int vpartid 4)
  let vpmw ← (( do
    match wd with
    | 0 => (do readReg MPAMVPM0_EL2)
    | 1 => (do readReg MPAMVPM1_EL2)
    | 2 => (do readReg MPAMVPM2_EL2)
    | 3 => (do readReg MPAMVPM3_EL2)
    | 4 => (do readReg MPAMVPM4_EL2)
    | 5 => (do readReg MPAMVPM5_EL2)
    | 6 => (do readReg MPAMVPM6_EL2)
    | 7 => (do readReg MPAMVPM7_EL2)
    | _ => (pure (Zeros (n := 64))) ) : SailM (BitVec 64) )
  let vpmw := vpmw
  let vpme_lsb := ((fmod_int vpartid 4) *i 16)
  (pure (BitVec.slice vpmw vpme_lsb 16))

def MAP_vPARTID (vpartid : (BitVec 16)) : SailM ((BitVec 16) × Bool) := do
  let ret ← (( do (undefined_bitvector 16) ) : SailM PARTIDtype )
  let err ← (( do (undefined_bool ()) ) : SailM Bool )
  let virt : Int := (BitVec.toNat vpartid)
  let vpmrmax ← (( do (pure (BitVec.toNat (_get_MPAMIDR_EL1_Type_VPMR_MAX (← readReg MPAMIDR_EL1)))) ) : SailM Int )
  let vpartid_max := ((Int.shiftl vpmrmax 2) +i 3)
  let virt : Int :=
    if (((BitVec.toNat vpartid) >b vpartid_max) : Bool)
    then (fmod_int virt (vpartid_max +i 1))
    else virt
  let virt := virt
  sail_assert ((0 ≤b virt) && (virt <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:11606.48-11606.49"
  let (err, ret) ← (( do
    (if ((((BitVec.access (← readReg MPAMVPMV_EL2) virt) : BitVec 1) == 1#1) : Bool)
    then
      (do let ret ← (mapvpmw virt)
          let err : Bool := false
          (pure (err, ret)))
    else
      (do let (err, ret) ← (( do
            (if ((((BitVec.access (← readReg MPAMVPMV_EL2) 0) : BitVec 1) == 1#1) : Bool)
            then
              (do let ret ← (pure (BitVec.slice (← readReg MPAMVPM0_EL2) 0 16))
                  let err : Bool := false
                  (pure (err, ret)))
            else
              (do let ret : PARTIDtype := DefaultPARTID
                  let err : Bool := true
                  (pure (err, ret)))) ) : SailM (Bool × (BitVec 16)) )
          (pure (err, ret)))) ) : SailM (Bool × (BitVec 16)) )
  let partid_max ← (( do (pure (BitVec.toNat (_get_MPAMIDR_EL1_Type_PARTID_MAX (← readReg MPAMIDR_EL1)))) ) : SailM Int )
  let (err, ret) : (Bool × (BitVec 16)) :=
    if (((BitVec.toNat ret) >b partid_max) : Bool)
    then
      (let ret : PARTIDtype := DefaultPARTID
      let err : Bool := true
      (err, ret))
    else (err, ret)
  let err := err
  let ret := ret
  (pure (ret, err))

def MPAMisVirtual (el : (BitVec 2)) : SailM Bool := do
  (pure ((_get_MPAMIDR_EL1_Type_HAS_HCR (← readReg MPAMIDR_EL1)) == 1#1)) <&&> (do
    (EL2Enabled ())) <&&> (do
    (pure (el == EL0)) <&&> (do
      (pure ((_get_MPAMHCR_EL2_Type_EL0_VPMEN (← readReg MPAMHCR_EL2)) == 1#1))) <&&> (do
      (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 0#1)) <||> (do
        (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)))) <||> (do
      (pure (el == EL1)) <&&> (do
        (pure ((_get_MPAMHCR_EL2_Type_EL1_VPMEN (← readReg MPAMHCR_EL2)) == 1#1)))))

def undefined_MPAM0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAM0_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_MPAMSM_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MPAMSM_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def getMPAM_PARTID (MPAMn : (BitVec 2)) (InD : Bool) (InSM : Bool) : SailM (BitVec 16) := do
  let partid ← (( do (undefined_bitvector 16) ) : SailM PARTIDtype )
  let el2avail ← (( do (EL2Enabled ()) ) : SailM Bool )
  (if (InSM : Bool)
  then (do (pure (_get_MPAMSM_EL1_Type_PARTID_D (← readReg MPAMSM_EL1))))
  else
    (do (if (InD : Bool)
        then
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PARTID_I (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PARTID_I (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 16))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PARTID_I (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PARTID_I (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PARTIDtype ())))
        else
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PARTID_D (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PARTID_D (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 16))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PARTID_D (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PARTID_D (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PARTIDtype ()))))))

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def genPARTID (el : (BitVec 2)) (InD : Bool) (InSM : Bool) : SailM ((BitVec 16) × Bool) := do
  let partidel ← (( do (getMPAM_PARTID el InD InSM) ) : SailM PARTIDtype )
  let partid_max ← (( do (pure (_get_MPAMIDR_EL1_Type_PARTID_MAX (← readReg MPAMIDR_EL1))) ) : SailM PARTIDtype )
  (if (((BitVec.toNat partidel) >b (BitVec.toNat partid_max)) : Bool)
  then (do (pure (DefaultPARTID, true)))
  else
    (do (if ((← (MPAMisVirtual el)) : Bool)
        then (do (MAP_vPARTID partidel))
        else (do (pure (partidel, false))))))

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def getMPAM_PMG (MPAMn : (BitVec 2)) (InD : Bool) (InSM : Bool) : SailM (BitVec 8) := do
  let pmg ← (( do (undefined_bitvector 8) ) : SailM PMGtype )
  let el2avail ← (( do (EL2Enabled ()) ) : SailM Bool )
  (if (InSM : Bool)
  then (do (pure (_get_MPAMSM_EL1_Type_PMG_D (← readReg MPAMSM_EL1))))
  else
    (do (if (InD : Bool)
        then
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PMG_I (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PMG_I (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 8))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PMG_I (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PMG_I (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PMGtype ())))
        else
          (do match MPAMn with
              | 0b11 => (do (pure (_get_MPAM3_EL3_Type_PMG_D (← (MPAM3_EL3_read ())))))
              | 0b10 =>
                (do
                  (if (el2avail : Bool)
                  then (do (pure (_get_MPAM2_EL2_Type_PMG_D (← readReg MPAM2_EL2))))
                  else (do (pure (Zeros (n := 8))))))
              | 0b01 => (do (pure (_get_MPAM1_EL1_Type_PMG_D (← (MPAM1_EL1_read ())))))
              | 0b00 => (do (pure (_get_MPAM0_EL1_Type_PMG_D (← readReg MPAM0_EL1))))
              | _ => (do (__UNKNOWN_PMGtype ()))))))

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool, k_partid_err : Bool -/
def genPMG (el : (BitVec 2)) (InD : Bool) (InSM : Bool) (partid_err : Bool) : SailM (BitVec 8) := do
  let pmg_max ← (( do (pure (BitVec.toNat (_get_MPAMIDR_EL1_Type_PMG_MAX (← readReg MPAMIDR_EL1)))) ) : SailM Int )
  (if (partid_err : Bool)
  then (do (pure DefaultPMG))
  else
    (do let groupel ← (( do (getMPAM_PMG el InD InSM) ) : SailM PMGtype )
        (if (((BitVec.toNat groupel) ≤b pmg_max) : Bool)
        then (do (pure groupel))
        else (do (pure DefaultPMG)))))

/-- Type quantifiers: k_InD : Bool, k_InSM : Bool -/
def genMPAM (el : (BitVec 2)) (InD : Bool) (InSM : Bool) (pspace : PARTIDspaceType) : SailM MPAMinfo := do
  let returninfo ← (( do (undefined_MPAMinfo ()) ) : SailM MPAMinfo )
  let partidel ← (( do (undefined_bitvector 16) ) : SailM PARTIDtype )
  let perr ← (( do (undefined_bool ()) ) : SailM Bool )
  let gstplk ← (( do (pure (el == EL0)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_MPAMHCR_EL2_Type_GSTAPP_PLK (← readReg MPAMHCR_EL2)) == 1#1))) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1))) ) : SailM Bool )
  let eff_el : (BitVec 2) :=
    if (gstplk : Bool)
    then EL1
    else el
  let (partidel, perr) ← (( do
    let (tup__0, tup__1) ← do (genPARTID eff_el InD InSM)
    let partidel : PARTIDtype := tup__0
    let perr : Bool := tup__1
    (pure (partidel, perr)) ) : SailM ((BitVec 16) × Bool) )
  let groupel ← (( do (genPMG eff_el InD InSM perr) ) : SailM PMGtype )
  let returninfo : MPAMinfo := { returninfo with mpam_sp := pspace }
  let returninfo : MPAMinfo := { returninfo with partid := partidel }
  (pure { returninfo with pmg := groupel })

def GenMPAMatEL (acctype : AccessType) (el : (BitVec 2)) : SailM MPAMinfo := SailME.run do
  let mpamEL ← (( do (undefined_bitvector 2) ) : SailME MPAMinfo (BitVec 2) )
  let validEL_name : Bool := false
  let security ← (( do (SecurityStateAtEL el) ) : SailME MPAMinfo SecurityState )
  let InD : Bool := false
  let InSM : Bool := false
  let pspace : PARTIDspaceType := (PARTIDspaceFromSS security)
  (if ((←((pure (BEq.beq pspace PIdSpace_NonSecure)) <&&> (do
       (pure (! (← (MPAMisEnabled ()))))))) : Bool)
  then (do (DefaultMPAMinfo pspace))
  else
    (do let (mpamEL, validEL_name) ← (( do
          (if ((← (UsingAArch32 ())) : Bool)
          then
            (do let (tup__0, tup__1) ← do (ELFromM32 (← readReg PSTATE).M)
                let validEL_name : Bool := tup__0
                let mpamEL : (BitVec 2) := tup__1
                (pure (mpamEL, validEL_name)))
          else
            (do let mpamEL : (BitVec 2) :=
                  if ((BEq.beq acctype AccessType_NV2) : Bool)
                  then EL2
                  else el
                let validEL_name : Bool := true
                (pure (mpamEL, validEL_name)))) ) : SailME MPAMinfo ((BitVec 2) × Bool) )
        let (InD, InSM) ← (( do
          match acctype with
          | .AccessType_IFETCH =>
            (let InD : Bool := true
            (pure (InD, InSM)))
          | .AccessType_IC =>
            (let InD : Bool := true
            (pure (InD, InSM)))
          | .AccessType_SME =>
            (do
              let InSM ← (__IMPDEF_boolean "Shared SMCU") <||> (do (__IMPDEF_boolean "MPAMSM_EL1 label precedence"))
              (pure (InD, InSM)))
          | .AccessType_ASIMD =>
            (do
              let InSM ← (HaveSME ()) <&&> (do (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do (__IMPDEF_boolean "Shared SMCU") <||> (do (__IMPDEF_boolean "MPAMSM_EL1 label precedence")))
              (pure (InD, InSM)))
          | .AccessType_SVE =>
            (do
              let InSM ← (HaveSME ()) <&&> (do (pure ((← readReg PSTATE).SM == 1#1))) <&&> (do (__IMPDEF_boolean "Shared SMCU") <||> (do (__IMPDEF_boolean "MPAMSM_EL1 label precedence")))
              (pure (InD, InSM)))
          | _ =>
            (let InD : Bool := false
            (pure (InD, InSM))) ) : SailME MPAMinfo (Bool × Bool) )
        (if ((! validEL_name) : Bool)
        then (do (DefaultMPAMinfo pspace))
        else
          (do let pspace ← (( do
                (if ((←((HaveRME ()) <&&> (do
                     (pure ((_get_MPAMIDR_EL1_Type_HAS_ALTSP (← readReg MPAMIDR_EL1)) == 1#1))))) : Bool)
                then (do (AltPARTIDspace mpamEL security pspace))
                else (do (pure pspace))) ) : SailME MPAMinfo PARTIDspaceType )
              let pspace ← (( do
                (if ((←((HaveMPAMv0p1Ext ()) <&&> (do
                     (pure ((_get_MPAMIDR_EL1_Type_HAS_FORCE_NS (← readReg MPAMIDR_EL1)) == 1#1))))) : Bool)
                then
                  (do (if ((((_get_MPAM3_EL3_Type_FORCE_NS (← (MPAM3_EL3_read ()))) == 1#1) && (BEq.beq security SS_Secure)) : Bool)
                      then (do (pure PIdSpace_NonSecure))
                      else (do (pure pspace))))
                else (do (pure pspace))) ) : SailME MPAMinfo PARTIDspaceType )
              (if ((←((HaveMPAMv0p1Ext ()) <||> (do
                   (HaveMPAMv1p1Ext ())) <&&> (do
                   (pure ((_get_MPAMIDR_EL1_Type_HAS_SDEFLT (← readReg MPAMIDR_EL1)) == 1#1))))) : Bool)
              then
                (do (if ((((_get_MPAM3_EL3_Type_SDEFLT (← (MPAM3_EL3_read ()))) == 1#1) && (BEq.beq security SS_Secure)) : Bool)
                    then (do SailME.throw (← do (DefaultMPAMinfo pspace)))
                    else (do (pure ()))))
              else (do (pure ())))
              (if ((! (← (MPAMisEnabled ()))) : Bool)
              then (do (DefaultMPAMinfo pspace))
              else (do (genMPAM mpamEL InD InSM pspace)))))))

def GenMPAMcurEL (acctype : AccessType) : SailM MPAMinfo := do
  (GenMPAMatEL acctype (← readReg PSTATE).EL)

def NewAccDesc (acctype : AccessType) : SailM AccessDescriptor := do
  let accdesc ← (( do (undefined_AccessDescriptor ()) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acctype := acctype }
  let accdesc ← (pure { accdesc with el := (← do (pure (← readReg PSTATE).EL)) })
  let accdesc ← (pure { accdesc with ss := (← do (SecurityStateAtEL (← readReg PSTATE).EL)) })
  let accdesc : AccessDescriptor := { accdesc with acqsc := false }
  let accdesc : AccessDescriptor := { accdesc with acqpc := false }
  let accdesc : AccessDescriptor := { accdesc with relsc := false }
  let accdesc : AccessDescriptor := { accdesc with limitedordered := false }
  let accdesc : AccessDescriptor := { accdesc with exclusive := false }
  let accdesc : AccessDescriptor := { accdesc with rcw := false }
  let accdesc : AccessDescriptor := { accdesc with rcws := false }
  let accdesc : AccessDescriptor := { accdesc with atomicop := false }
  let accdesc : AccessDescriptor := { accdesc with nontemporal := false }
  let accdesc : AccessDescriptor := { accdesc with read := false }
  let accdesc : AccessDescriptor := { accdesc with write := false }
  let accdesc : AccessDescriptor := { accdesc with pan := false }
  let accdesc : AccessDescriptor := { accdesc with nonfault := false }
  let accdesc : AccessDescriptor := { accdesc with firstfault := false }
  let accdesc : AccessDescriptor := { accdesc with first := false }
  let accdesc : AccessDescriptor := { accdesc with contiguous := false }
  let accdesc : AccessDescriptor := { accdesc with streamingsve := false }
  let accdesc : AccessDescriptor := { accdesc with ls64 := false }
  let accdesc : AccessDescriptor := { accdesc with mops := false }
  let accdesc : AccessDescriptor := { accdesc with a32lsmd := false }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := false }
  let accdesc : AccessDescriptor := { accdesc with tagaccess := false }
  let accdesc : AccessDescriptor := { accdesc with transactional := false }
  (pure { accdesc with mpam := (← do (GenMPAMcurEL acctype)) })

/-- Type quantifiers: k_nontemporal : Bool, k_privileged : Bool, k_tagchecked : Bool -/
def CreateAccDescGPR (memop : MemOp) (nontemporal : Bool) (privileged : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc ←
    (pure { accdesc with el := (← do
        (if ((! privileged) : Bool)
        then (do (pure EL0))
        else (do (pure (← readReg PSTATE).EL)))) })
  let accdesc : AccessDescriptor := { accdesc with nontemporal := nontemporal }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_acqrel : Bool, k_tagchecked : Bool -/
def CreateAccDescExLDST (memop : MemOp) (acqrel : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqsc := (acqrel && (BEq.beq memop MemOp_LOAD)) }
  let accdesc : AccessDescriptor := { accdesc with relsc := (acqrel && (BEq.beq memop MemOp_STORE)) }
  let accdesc : AccessDescriptor := { accdesc with exclusive := true }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_acquire : Bool, k_release : Bool, k_tagchecked : Bool -/
def CreateAccDescAtomicOp (modop : MemAtomicOp) (acquire : Bool) (release : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqsc := acquire }
  let accdesc : AccessDescriptor := { accdesc with relsc := release }
  let accdesc : AccessDescriptor := { accdesc with atomicop := true }
  let accdesc : AccessDescriptor := { accdesc with modop := modop }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with write := true }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescAcqRel (memop : MemOp) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqsc := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with relsc := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescLOR (memop : MemOp) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqsc := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with relsc := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with limitedordered := true }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagchecked : Bool -/
def CreateAccDescLDAcqPC (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPR) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with acqpc := true }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

def InStreamingMode (_ : Unit) : SailM Bool := do
  (HaveSME ()) <&&> (do
    (pure ((← readReg PSTATE).SM == 1#1)))

/-- Type quantifiers: k_nontemporal : Bool, k_tagchecked : Bool -/
def CreateAccDescASIMD (memop : MemOp) (nontemporal : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_ASIMD) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with nontemporal := nontemporal }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc ← (pure { accdesc with streamingsve := (← do (InStreamingMode ())) })
  let accdesc ← (( do
    (if ((←((pure accdesc.streamingsve) <&&> (do
         (__IMPDEF_boolean "No tag checking of SIMD&FP loads and stores in Streaming SVE mode")))) : Bool)
    then (do (pure { accdesc with tagchecked := false }))
    else (do (pure { accdesc with tagchecked := tagchecked }))) ) : SailM AccessDescriptor )
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

/-- Type quantifiers: k_tagaccess : Bool, k_tagchecked : Bool -/
def CreateAccDescDCZero (tagaccess : Bool) (tagchecked : Bool) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_DCZero) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with write := true }
  let accdesc : AccessDescriptor := { accdesc with pan := true }
  let accdesc : AccessDescriptor := { accdesc with tagchecked := tagchecked }
  let accdesc : AccessDescriptor := { accdesc with tagaccess := tagaccess }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

def CreateAccDescTTEUpdate (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with atomicop := true }
  let accdesc : AccessDescriptor := { accdesc with modop := MemAtomicOp_CAS }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with write := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

/-- Type quantifiers: k_toplevel : Bool -/
def CreateAccDescS1TTW (toplevel : Bool) (varange : VARange) (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  let accdesc : AccessDescriptor := { accdesc with toplevel := toplevel }
  let accdesc : AccessDescriptor := { accdesc with varange := varange }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescS2TTW (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_TTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescNV2 (memop : MemOp) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_NV2) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := EL2 }
  let accdesc ← (pure { accdesc with ss := (← do (SecurityStateAtEL EL2)) })
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  let accdesc : AccessDescriptor := { accdesc with write := (BEq.beq memop MemOp_STORE) }
  (pure { accdesc with transactional := (← do (HaveTME ()) <&&> (do (pure ((← readReg TSTATE).depth >b 0)))) })

def CreateAccDescGPTW (accdesc_in : AccessDescriptor) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GPTW) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := accdesc_in.el }
  let accdesc : AccessDescriptor := { accdesc with ss := accdesc_in.ss }
  let accdesc : AccessDescriptor := { accdesc with read := true }
  (pure { accdesc with mpam := accdesc_in.mpam })

def CreateAccDescGCS (el : (BitVec 2)) (memop : MemOp) : SailM AccessDescriptor := do
  let accdesc ← (( do (NewAccDesc AccessType_GCS) ) : SailM AccessDescriptor )
  let accdesc : AccessDescriptor := { accdesc with el := el }
  let accdesc : AccessDescriptor := { accdesc with read := (BEq.beq memop MemOp_LOAD) }
  (pure { accdesc with write := (BEq.beq memop MemOp_STORE) })

def TranslationRegime (el : (BitVec 2)) : SailM Regime := do
  (if ((el == EL3) : Bool)
  then
    (do (if ((← (ELUsingAArch32 EL3)) : Bool)
        then (do (pure Regime_EL30))
        else (do (pure Regime_EL3))))
  else
    (do (if ((el == EL2) : Bool)
        then
          (do (if ((← (ELIsInHost EL2)) : Bool)
              then (do (pure Regime_EL20))
              else (do (pure Regime_EL2))))
        else
          (do (if ((el == EL1) : Bool)
              then (do (pure Regime_EL10))
              else
                (do (if ((el == EL0) : Bool)
                    then
                      (do (if ((←((pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) <&&> (do
                               (ELUsingAArch32 EL3)))) : Bool)
                          then (do (pure Regime_EL30))
                          else
                            (do (if ((← (ELIsInHost EL0)) : Bool)
                                then (do (pure Regime_EL20))
                                else (do (pure Regime_EL10))))))
                    else
                      (do (Unreachable ())
                          (undefined_Regime ())))))))))

def AlignmentEnforced (_ : Unit) : SailM Bool := do
  let regime ← (( do (TranslationRegime (← readReg PSTATE).EL) ) : SailM Regime )
  let A ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let A ← (( do
    match regime with
    | .Regime_EL3 => (do (pure (_get_SCTLR_EL3_Type_A (← readReg SCTLR_EL3))))
    | .Regime_EL30 => (do (pure (_get_SCTLR_Type_A (← (SCTLR_read__2 ())))))
    | .Regime_EL2 =>
      (do
        (if ((← (ELUsingAArch32 EL2)) : Bool)
        then (do (pure (_get_HSCTLR_Type_A (← (HSCTLR_read ())))))
        else (do (pure (_get_SCTLR_EL2_Type_A (← readReg SCTLR_EL2))))))
    | .Regime_EL20 => (do (pure (_get_SCTLR_EL2_Type_A (← readReg SCTLR_EL2))))
    | .Regime_EL10 =>
      (do
        (if ((← (ELUsingAArch32 EL1)) : Bool)
        then (do (pure (_get_SCTLR_Type_A (← (SCTLR_read__2 ())))))
        else (do (pure (_get_SCTLR_EL1_Type_A (← readReg SCTLR_EL1)))))) ) : SailM (BitVec 1) )
  (pure (A == 1#1))

def undefined_CLIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_CLIDR_Type_ICB (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 30 x)

def _update_CLIDR_Type_LoUIS (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 21 x)

def _update_CLIDR_Type_LoUU (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 27 x)

def HaveAESExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_AES)

/-- Type quantifiers: k_N : Nat, shift : Int, k_N ≥ 0 -/
def ROL (x : (BitVec k_N)) (shift : Int) : SailM (BitVec k_N) := do
  sail_assert ((shift ≥b 0) && (shift ≤b (Sail.BitVec.length x))) "sail-arm/arm-v9.4-a/src/v8_base.sail:12606.35-12606.36"
  (if ((shift == 0) : Bool)
  then (do (pure x))
  else (do (pure (ROR x ((Sail.BitVec.length x) -i shift)))))

def AESShiftRows (op : (BitVec 128)) : (BitVec 128) :=
  ((((((((((((((((Sail.BitVec.extractLsb op 95 88) +++ (Sail.BitVec.extractLsb op 55 48)) +++ (Sail.BitVec.extractLsb op 15 8)) +++ (Sail.BitVec.extractLsb op 103 96)) +++ (Sail.BitVec.extractLsb op 63 56)) +++ (Sail.BitVec.extractLsb op 23 16)) +++ (Sail.BitVec.extractLsb op 111 104)) +++ (Sail.BitVec.extractLsb op 71 64)) +++ (Sail.BitVec.extractLsb op 31 24)) +++ (Sail.BitVec.extractLsb op 119 112)) +++ (Sail.BitVec.extractLsb op 79 72)) +++ (Sail.BitVec.extractLsb op 39 32)) +++ (Sail.BitVec.extractLsb op 127 120)) +++ (Sail.BitVec.extractLsb op 87 80)) +++ (Sail.BitVec.extractLsb op 47 40)) +++ (Sail.BitVec.extractLsb op 7 0))

def AESInvShiftRows (op : (BitVec 128)) : (BitVec 128) :=
  ((((((((((((((((Sail.BitVec.extractLsb op 31 24) +++ (Sail.BitVec.extractLsb op 55 48)) +++ (Sail.BitVec.extractLsb op 79 72)) +++ (Sail.BitVec.extractLsb op 103 96)) +++ (Sail.BitVec.extractLsb op 127 120)) +++ (Sail.BitVec.extractLsb op 23 16)) +++ (Sail.BitVec.extractLsb op 47 40)) +++ (Sail.BitVec.extractLsb op 71 64)) +++ (Sail.BitVec.extractLsb op 95 88)) +++ (Sail.BitVec.extractLsb op 119 112)) +++ (Sail.BitVec.extractLsb op 15 8)) +++ (Sail.BitVec.extractLsb op 39 32)) +++ (Sail.BitVec.extractLsb op 63 56)) +++ (Sail.BitVec.extractLsb op 87 80)) +++ (Sail.BitVec.extractLsb op 111 104)) +++ (Sail.BitVec.extractLsb op 7 0))

def AESSubBytes (op : (BitVec 128)) : SailM (BitVec 128) := do
  let GF2 : (BitVec 2048) := (((((((((((((((0x16BB54B00F2D99416842E6BF0D89A18C#128 +++ 0xDF2855CEE9871E9B948ED9691198F8E1#128) +++ 0x9E1DC186B95735610EF6034866B53E70#128) +++ 0x8A8BBD4B1F74DDE8C6B4A61C2E2578BA#128) +++ 0x08AE7A65EAF4566CA94ED58D6D37C8E7#128) +++ 0x79E4959162ACD3C25C2406490A3A32E0#128) +++ 0xDB0B5EDE14B8EE4688902A22DC4F8160#128) +++ 0x73195D643D7EA7C41744975FEC130CCD#128) +++ 0xD2F3FF1021DAB6BCF5389D928F40A351#128) +++ 0xA89F3C507F02F94585334D43FBAAEFD0#128) +++ 0xCF584C4A39BECB6A5BB1FC20ED00D153#128) +++ 0x842FE329B3D63B52A05A6E1B1A2C8309#128) +++ 0x75B227EBE28012079A059618C323C704#128) +++ 0x1531D871F1E5A534CCF73F362693FDB7#128) +++ 0xC072A49CAFA2D4ADF04759FA7DC982CA#128) +++ 0x76ABD7FE2B670130C56F6BF27B777C63#128)
  let out ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := out
  for i in [loop_i_lower:loop_i_upper:1]i do
    let out := loop_vars
    loop_vars := (set_slice 8 out (i *i 8) (BitVec.slice GF2 ((BitVec.toNat (BitVec.slice op (i *i 8) 8)) *i 8) 8))
  (pure loop_vars)

def AESInvSubBytes (op : (BitVec 128)) : SailM (BitVec 128) := do
  let GF2_inv : (BitVec 2048) := (((((((((((((((0x7D0C2155631469E126D677BA7E042B17#128 +++ 0x619953833CBBEBC8B0F52AAE4D3BE0A0#128) +++ 0xEF9CC9939F7AE52D0D4AB519A97F5160#128) +++ 0x5FEC8027591012B131C7078833A8DD1F#128) +++ 0xF45ACD78FEC0DB9A2079D2C64B3E56FC#128) +++ 0x1BBE18AA0E62B76F89C5291D711AF147#128) +++ 0x6EDF751CE837F9E28535ADE72274AC96#128) +++ 0x73E6B4F0CECFF297EADC674F4111913A#128) +++ 0x6B8A130103BDAFC1020F3FCA8F1E2CD0#128) +++ 0x0645B3B80558E4F70AD3BC8C00ABD890#128) +++ 0x849D8DA75746155EDAB9EDFD5048706C#128) +++ 0x92B6655DCC5CA4D41698688664F6F872#128) +++ 0x25D18B6D49A25B76B224D92866A12E08#128) +++ 0x4EC3FA420B954CEE3D23C2A632947B54#128) +++ 0xCBE9DEC444438E3487FF2F9B8239E37C#128) +++ 0xFBD7F3819EA340BF38A53630D56A0952#128)
  let out ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let loop_i_lower := 0
  let loop_i_upper := 15
  let mut loop_vars := out
  for i in [loop_i_lower:loop_i_upper:1]i do
    let out := loop_vars
    loop_vars := (set_slice 8 out (i *i 8) (BitVec.slice GF2_inv ((BitVec.toNat (BitVec.slice op (i *i 8) 8)) *i 8) 8))
  (pure loop_vars)

def FFmul02 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_02 : (BitVec 2048) := (((((((((((((((0xE5E7E1E3EDEFE9EBF5F7F1F3FDFFF9FB#128 +++ 0xC5C7C1C3CDCFC9CBD5D7D1D3DDDFD9DB#128) +++ 0xA5A7A1A3ADAFA9ABB5B7B1B3BDBFB9BB#128) +++ 0x858781838D8F898B959791939D9F999B#128) +++ 0x656761636D6F696B757771737D7F797B#128) +++ 0x454741434D4F494B555751535D5F595B#128) +++ 0x252721232D2F292B353731333D3F393B#128) +++ 0x050701030D0F090B151711131D1F191B#128) +++ 0xFEFCFAF8F6F4F2F0EEECEAE8E6E4E2E0#128) +++ 0xDEDCDAD8D6D4D2D0CECCCAC8C6C4C2C0#128) +++ 0xBEBCBAB8B6B4B2B0AEACAAA8A6A4A2A0#128) +++ 0x9E9C9A98969492908E8C8A8886848280#128) +++ 0x7E7C7A78767472706E6C6A6866646260#128) +++ 0x5E5C5A58565452504E4C4A4846444240#128) +++ 0x3E3C3A38363432302E2C2A2826242220#128) +++ 0x1E1C1A18161412100E0C0A0806040200#128)
  (BitVec.slice FFmul_02 ((BitVec.toNat b) *i 8) 8)

def FFmul03 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_03 : (BitVec 2048) := (((((((((((((((0x1A191C1F16151013020104070E0D080B#128 +++ 0x2A292C2F26252023323134373E3D383B#128) +++ 0x7A797C7F76757073626164676E6D686B#128) +++ 0x4A494C4F46454043525154575E5D585B#128) +++ 0xDAD9DCDFD6D5D0D3C2C1C4C7CECDC8CB#128) +++ 0xEAE9ECEFE6E5E0E3F2F1F4F7FEFDF8FB#128) +++ 0xBAB9BCBFB6B5B0B3A2A1A4A7AEADA8AB#128) +++ 0x8A898C8F86858083929194979E9D989B#128) +++ 0x818287848D8E8B88999A9F9C95969390#128) +++ 0xB1B2B7B4BDBEBBB8A9AAAFACA5A6A3A0#128) +++ 0xE1E2E7E4EDEEEBE8F9FAFFFCF5F6F3F0#128) +++ 0xD1D2D7D4DDDEDBD8C9CACFCCC5C6C3C0#128) +++ 0x414247444D4E4B48595A5F5C55565350#128) +++ 0x717277747D7E7B78696A6F6C65666360#128) +++ 0x212227242D2E2B28393A3F3C35363330#128) +++ 0x111217141D1E1B18090A0F0C05060300#128)
  (BitVec.slice FFmul_03 ((BitVec.toNat b) *i 8) 8)

def FFmul09 (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_09 : (BitVec 2048) := (((((((((((((((0x464F545D626B70790E071C152A233831#128 +++ 0xD6DFC4CDF2FBE0E99E978C85BAB3A8A1#128) +++ 0x7D746F6659504B42353C272E1118030A#128) +++ 0xEDE4FFF6C9C0DBD2A5ACB7BE8188939A#128) +++ 0x3039222B141D060F78716A635C554E47#128) +++ 0xA0A9B2BB848D969FE8E1FAF3CCC5DED7#128) +++ 0x0B0219102F263D34434A5158676E757C#128) +++ 0x9B928980BFB6ADA4D3DAC1C8F7FEE5EC#128) +++ 0xAAA3B8B18E879C95E2EBF0F9C6CFD4DD#128) +++ 0x3A3328211E170C05727B6069565F444D#128) +++ 0x9198838AB5BCA7AED9D0CBC2FDF4EFE6#128) +++ 0x0108131A252C373E49405B526D647F76#128) +++ 0xDCD5CEC7F8F1EAE3949D868FB0B9A2AB#128) +++ 0x4C455E5768617A73040D161F2029323B#128) +++ 0xE7EEF5FCC3CAD1D8AFA6BDB48B829990#128) +++ 0x777E656C535A41483F362D241B120900#128)
  (BitVec.slice FFmul_09 ((BitVec.toNat b) *i 8) 8)

def FFmul0B (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0B : (BitVec 2048) := (((((((((((((((0xA3A8B5BE8F849992FBF0EDE6D7DCC1CA#128 +++ 0x1318050E3F3429224B405D56676C717A#128) +++ 0xD8D3CEC5F4FFE2E9808B969DACA7BAB1#128) +++ 0x68637E75444F5259303B262D1C170A01#128) +++ 0x555E434879726F640D061B10212A373C#128) +++ 0xE5EEF3F8C9C2DFD4BDB6ABA0919A878C#128) +++ 0x2E2538330209141F767D606B5A514C47#128) +++ 0x9E958883B2B9A4AFC6CDD0DBEAE1FCF7#128) +++ 0x545F424978736E650C071A11202B363D#128) +++ 0xE4EFF2F9C8C3DED5BCB7AAA1909B868D#128) +++ 0x2F2439320308151E777C616A5B504D46#128) +++ 0x9F948982B3B8A5AEC7CCD1DAEBE0FDF6#128) +++ 0xA2A9B4BF8E859893FAF1ECE7D6DDC0CB#128) +++ 0x1219040F3E3528234A415C57666D707B#128) +++ 0xD9D2CFC4F5FEE3E8818A979CADA6BBB0#128) +++ 0x69627F74454E5358313A272C1D160B00#128)
  (BitVec.slice FFmul_0B ((BitVec.toNat b) *i 8) 8)

def FFmul0D (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0D : (BitVec 2048) := (((((((((((((((0x979A8D80A3AEB9B4FFF2E5E8CBC6D1DC#128 +++ 0x474A5D50737E69642F2235381B16010C#128) +++ 0x2C21363B1815020F44495E53707D6A67#128) +++ 0xFCF1E6EBC8C5D2DF94998E83A0ADBAB7#128) +++ 0xFAF7E0EDCEC3D4D9929F8885A6ABBCB1#128) +++ 0x2A27303D1E130409424F5855767B6C61#128) +++ 0x414C5B5675786F622924333E1D10070A#128) +++ 0x919C8B86A5A8BFB2F9F4E3EECDC0D7DA#128) +++ 0x4D40575A7974636E25283F32111C0B06#128) +++ 0x9D90878AA9A4B3BEF5F8EFE2C1CCDBD6#128) +++ 0xF6FBECE1C2CFD8D59E938489AAA7B0BD#128) +++ 0x262B3C31121F08054E4354597A77606D#128) +++ 0x202D3A3714190E034845525F7C71666B#128) +++ 0xF0FDEAE7C4C9DED39895828FACA1B6BB#128) +++ 0x9B96818CAFA2B5B8F3FEE9E4C7CADDD0#128) +++ 0x4B46515C7F726568232E3934171A0D00#128)
  (BitVec.slice FFmul_0D ((BitVec.toNat b) *i 8) 8)

def FFmul0E (b : (BitVec 8)) : (BitVec 8) :=
  let FFmul_0E : (BitVec 2048) := (((((((((((((((0x8D83919FB5BBA9A7FDF3E1EFC5CBD9D7#128 +++ 0x6D63717F555B49471D13010F252B3937#128) +++ 0x56584A446E60727C26283A341E10020C#128) +++ 0xB6B8AAA48E80929CC6C8DAD4FEF0E2EC#128) +++ 0x202E3C321816040A505E4C426866747A#128) +++ 0xC0CEDCD2F8F6E4EAB0BEACA28886949A#128) +++ 0xFBF5E7E9C3CDDFD18B859799B3BDAFA1#128) +++ 0x1B150709232D3F316B657779535D4F41#128) +++ 0xCCC2D0DEF4FAE8E6BCB2A0AE848A9896#128) +++ 0x2C22303E141A08065C52404E646A7876#128) +++ 0x17190B052F21333D67697B755F51434D#128) +++ 0xF7F9EBE5CFC1D3DD87899B95BFB1A3AD#128) +++ 0x616F7D735957454B111F0D032927353B#128) +++ 0x818F9D93B9B7A5ABF1FFEDE3C9C7D5DB#128) +++ 0xBAB4A6A8828C9E90CAC4D6D8F2FCEEE0#128) +++ 0x5A544648626C7E702A243638121C0E00#128)
  (BitVec.slice FFmul_0E ((BitVec.toNat b) *i 8) 8)

def AESMixColumns (op : (BitVec 128)) : SailM (BitVec 128) := do
  let in0 : (BitVec 32) := ((((BitVec.slice op 96 8) +++ (BitVec.slice op 64 8)) +++ (BitVec.slice op 32 8)) +++ (BitVec.slice op 0 8))
  let in1 : (BitVec 32) := ((((BitVec.slice op 104 8) +++ (BitVec.slice op 72 8)) +++ (BitVec.slice op 40 8)) +++ (BitVec.slice op 8 8))
  let in2 : (BitVec 32) := ((((BitVec.slice op 112 8) +++ (BitVec.slice op 80 8)) +++ (BitVec.slice op 48 8)) +++ (BitVec.slice op 16 8))
  let in3 : (BitVec 32) := ((((BitVec.slice op 120 8) +++ (BitVec.slice op 88 8)) +++ (BitVec.slice op 56 8)) +++ (BitVec.slice op 24 8))
  let out0 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out1 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out2 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out3 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (out0, out1, out2, out3) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := 3
    let mut loop_vars := (out0, out1, out2, out3)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (out0, out1, out2, out3) := loop_vars
      loop_vars :=
        let out0 : (BitVec 32) := (set_slice 8 out0 (c *i 8) ((((FFmul02 (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in1 (c *i 8) 8))) ^^^ (BitVec.slice in2 (c *i 8) 8)) ^^^ (BitVec.slice in3 (c *i 8) 8)))
        let out1 : (BitVec 32) := (set_slice 8 out1 (c *i 8) ((((FFmul02 (BitVec.slice in1 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in2 (c *i 8) 8))) ^^^ (BitVec.slice in3 (c *i 8) 8)) ^^^ (BitVec.slice in0 (c *i 8) 8)))
        let out2 : (BitVec 32) := (set_slice 8 out2 (c *i 8) ((((FFmul02 (BitVec.slice in2 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in3 (c *i 8) 8))) ^^^ (BitVec.slice in0 (c *i 8) 8)) ^^^ (BitVec.slice in1 (c *i 8) 8)))
        let out3 : (BitVec 32) := (set_slice 8 out3 (c *i 8) ((((FFmul02 (BitVec.slice in3 (c *i 8) 8)) ^^^ (FFmul03 (BitVec.slice in0 (c *i 8) 8))) ^^^ (BitVec.slice in1 (c *i 8) 8)) ^^^ (BitVec.slice in2 (c *i 8) 8)))
        (out0, out1, out2, out3)
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 32)) )
  (pure ((((((((((((((((BitVec.slice out3 (3 *i 8) 8) +++ (BitVec.slice out2 (3 *i 8) 8)) +++ (BitVec.slice out1 (3 *i 8) 8)) +++ (BitVec.slice out0 (3 *i 8) 8)) +++ (BitVec.slice out3 (2 *i 8) 8)) +++ (BitVec.slice out2 (2 *i 8) 8)) +++ (BitVec.slice out1 (2 *i 8) 8)) +++ (BitVec.slice out0 (2 *i 8) 8)) +++ (BitVec.slice out3 (1 *i 8) 8)) +++ (BitVec.slice out2 (1 *i 8) 8)) +++ (BitVec.slice out1 (1 *i 8) 8)) +++ (BitVec.slice out0 (1 *i 8) 8)) +++ (BitVec.slice out3 (0 *i 8) 8)) +++ (BitVec.slice out2 (0 *i 8) 8)) +++ (BitVec.slice out1 (0 *i 8) 8)) +++ (BitVec.slice out0 (0 *i 8) 8)))

def AESInvMixColumns (op : (BitVec 128)) : SailM (BitVec 128) := do
  let in0 : (BitVec 32) := ((((BitVec.slice op 96 8) +++ (BitVec.slice op 64 8)) +++ (BitVec.slice op 32 8)) +++ (BitVec.slice op 0 8))
  let in1 : (BitVec 32) := ((((BitVec.slice op 104 8) +++ (BitVec.slice op 72 8)) +++ (BitVec.slice op 40 8)) +++ (BitVec.slice op 8 8))
  let in2 : (BitVec 32) := ((((BitVec.slice op 112 8) +++ (BitVec.slice op 80 8)) +++ (BitVec.slice op 48 8)) +++ (BitVec.slice op 16 8))
  let in3 : (BitVec 32) := ((((BitVec.slice op 120 8) +++ (BitVec.slice op 88 8)) +++ (BitVec.slice op 56 8)) +++ (BitVec.slice op 24 8))
  let out0 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out1 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out2 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let out3 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let (out0, out1, out2, out3) ← (( do
    let loop_c_lower := 0
    let loop_c_upper := 3
    let mut loop_vars := (out0, out1, out2, out3)
    for c in [loop_c_lower:loop_c_upper:1]i do
      let (out0, out1, out2, out3) := loop_vars
      loop_vars :=
        let out0 : (BitVec 32) := (set_slice 8 out0 (c *i 8) ((((FFmul0E (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0B (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0D (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul09 (BitVec.slice in3 (c *i 8) 8))))
        let out1 : (BitVec 32) := (set_slice 8 out1 (c *i 8) ((((FFmul09 (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0E (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0B (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0D (BitVec.slice in3 (c *i 8) 8))))
        let out2 : (BitVec 32) := (set_slice 8 out2 (c *i 8) ((((FFmul0D (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul09 (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul0E (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0B (BitVec.slice in3 (c *i 8) 8))))
        let out3 : (BitVec 32) := (set_slice 8 out3 (c *i 8) ((((FFmul0B (BitVec.slice in0 (c *i 8) 8)) ^^^ (FFmul0D (BitVec.slice in1 (c *i 8) 8))) ^^^ (FFmul09 (BitVec.slice in2 (c *i 8) 8))) ^^^ (FFmul0E (BitVec.slice in3 (c *i 8) 8))))
        (out0, out1, out2, out3)
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 32)) )
  (pure ((((((((((((((((BitVec.slice out3 (3 *i 8) 8) +++ (BitVec.slice out2 (3 *i 8) 8)) +++ (BitVec.slice out1 (3 *i 8) 8)) +++ (BitVec.slice out0 (3 *i 8) 8)) +++ (BitVec.slice out3 (2 *i 8) 8)) +++ (BitVec.slice out2 (2 *i 8) 8)) +++ (BitVec.slice out1 (2 *i 8) 8)) +++ (BitVec.slice out0 (2 *i 8) 8)) +++ (BitVec.slice out3 (1 *i 8) 8)) +++ (BitVec.slice out2 (1 *i 8) 8)) +++ (BitVec.slice out1 (1 *i 8) 8)) +++ (BitVec.slice out0 (1 *i 8) 8)) +++ (BitVec.slice out3 (0 *i 8) 8)) +++ (BitVec.slice out2 (0 *i 8) 8)) +++ (BitVec.slice out1 (0 *i 8) 8)) +++ (BitVec.slice out0 (0 *i 8) 8)))

def SHAchoose (x : (BitVec 32)) (y : (BitVec 32)) (z : (BitVec 32)) : (BitVec 32) :=
  (((y ^^^ z) &&& x) ^^^ z)

def SHAmajority (x : (BitVec 32)) (y : (BitVec 32)) (z : (BitVec 32)) : (BitVec 32) :=
  ((x &&& y) ||| ((x ||| y) &&& z))

def SHAhashSIGMA0 (x : (BitVec 32)) : (BitVec 32) :=
  (((ROR x 2) ^^^ (ROR x 13)) ^^^ (ROR x 22))

def SHAhashSIGMA1 (x : (BitVec 32)) : (BitVec 32) :=
  (((ROR x 6) ^^^ (ROR x 11)) ^^^ (ROR x 25))

/-- Type quantifiers: k_part1 : Bool -/
def SHA256hash (x_in : (BitVec 128)) (y_in : (BitVec 128)) (w : (BitVec 128)) (part1 : Bool) : SailM (BitVec 128) := do
  let chs ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let maj ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let t ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let x : (BitVec 128) := x_in
  let y : (BitVec 128) := y_in
  let (chs, maj, t, x, y) ← (( do
    let loop_e_lower := 0
    let loop_e_upper := 3
    let mut loop_vars := (chs, maj, t, x, y)
    for e in [loop_e_lower:loop_e_upper:1]i do
      let (chs, maj, t, x, y) := loop_vars
      loop_vars ← do
        let chs : (BitVec 32) := (SHAchoose (Sail.BitVec.extractLsb y 31 0) (Sail.BitVec.extractLsb y 63 32) (Sail.BitVec.extractLsb y 95 64))
        let maj : (BitVec 32) := (SHAmajority (Sail.BitVec.extractLsb x 31 0) (Sail.BitVec.extractLsb x 63 32) (Sail.BitVec.extractLsb x 95 64))
        let t ← (pure ((((Sail.BitVec.extractLsb y 127 96) + (SHAhashSIGMA1 (Sail.BitVec.extractLsb y 31 0))) + chs) + (← (Elem_read w e 32))))
        let x : (BitVec 128) := (Sail.BitVec.updateSubrange x 127 96 (t + (Sail.BitVec.extractLsb x 127 96)))
        let y : (BitVec 128) := (Sail.BitVec.updateSubrange y 127 96 ((t + (SHAhashSIGMA0 (Sail.BitVec.extractLsb x 31 0))) + maj))
        let split_vec ← do (ROL (y +++ x) 32)
        let y : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 255 128)
        let x : (BitVec 128) := (Sail.BitVec.extractLsb split_vec 127 0)
        (pure (chs, maj, t, x, y))
    (pure loop_vars) ) : SailM ((BitVec 32) × (BitVec 32) × (BitVec 32) × (BitVec 128) × (BitVec 128)) )
  (if (part1 : Bool)
  then (do (pure x))
  else (do (pure y)))

def undefined_CONTEXTIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CONTEXTIDR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_TTBCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_TTBCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_TTBCR_Type_EAE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_TTBCR_Type_EAE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_TTBCR_Type_PD0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def _update_TTBCR_Type_PD1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def TTBCR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _TTBCR_NS ) : SailM TTBCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg TCR_EL1) 0 32)))

def TTBCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_TTBCR_Type ()) ) : SailM TTBCR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBCR_S)
  else (do (TTBCR_NS_read ())))

def undefined_CONTEXTIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_TTBR0_EL1_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR0_EL2_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR1_EL1_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def _get_TTBR1_EL2_Type_ASID (v : (BitVec 128)) : (BitVec 16) :=
  (Sail.BitVec.extractLsb v 63 48)

def undefined_TTBR0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_GPTBR_EL3_Type_BADDR (v : (BitVec 64)) : (BitVec 40) :=
  (Sail.BitVec.extractLsb v 39 0)

def _get_VNCR_EL2_Type_BADDR (v : (BitVec 64)) : (BitVec 45) :=
  (Sail.BitVec.extractLsb v 56 12)

def _get_TTBR0_EL1_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR0_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR0_EL3_Type_CnP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR1_EL1_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TTBR1_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_VSTTBR_EL2_Type_CnP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_VTTBR_EL2_Type_CnP (v : (BitVec 128)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_GPCCR_EL3_Type_IRGN (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def TTBR0_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_TTBR0_Type ()) ) : SailM TTBR0_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBR0_S)
  else (do readReg TTBR0_NS))

def undefined_TTBR0_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR0_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def _get_TTBR0_EL1_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR0_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR0_EL3_Type_SKL (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR1_EL1_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_TTBR1_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_VSTTBR_EL2_Type_SKL (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def _get_VTTBR_EL2_Type_SKL (v : (BitVec 128)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 2 1)

def TTBR0_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR0_EL1 ) : SailM TTBR0_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (TTBR0_read ())) 0 64)))

def undefined_HTTBR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TTBR0_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR0_EL2_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def TTBR0_EL2_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR0_EL2 ) : SailM TTBR0_EL2_Type )
  (pure (Sail.BitVec.updateSubrange r 47 1 (BitVec.slice (← readReg HTTBR) 1 47)))

def undefined_TTBR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TTBR1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def TTBR1_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (undefined_TTBR1_Type ()) ) : SailM TTBR1_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg TTBR1_S)
  else (do readReg TTBR1_NS))

def undefined_TTBR1_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def Mk_TTBR1_EL1_Type (v : (BitVec 128)) : (BitVec 128) :=
  v

def TTBR1_EL1_read (_ : Unit) : SailM (BitVec 128) := do
  let r ← (( do readReg _TTBR1_EL1 ) : SailM TTBR1_EL1_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← (TTBR1_read ())) 0 64)))

def undefined_TTBR1_EL2_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

/-- Type quantifiers: N : Nat, i : Int, 0 ≤ (N - 1) -/
def SignedSatQ (i : Int) (N : Nat) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let saturated ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, saturated) : (Int × Bool) :=
    if ((i >b ((2 ^i (N -i 1)) -i 1)) : Bool)
    then
      (let result : Int := ((2 ^i (N -i 1)) -i 1)
      let saturated : Bool := true
      (result, saturated))
    else
      (let (result, saturated) : (Int × Bool) :=
        if ((i <b (Neg.neg (2 ^i (N -i 1)))) : Bool)
        then
          (let result : Int := (Neg.neg (2 ^i (N -i 1)))
          let saturated : Bool := true
          (result, saturated))
        else
          (let result : Int := i
          let saturated : Bool := false
          (result, saturated))
      (result, saturated))
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), saturated))

/-- Type quantifiers: N : Nat, i : Int, 0 ≤ (N - 1) -/
def UnsignedSatQ (i : Int) (N : Nat) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_int ()) ) : SailM Int )
  let saturated ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, saturated) : (Int × Bool) :=
    if ((i >b ((2 ^i N) -i 1)) : Bool)
    then
      (let result : Int := ((2 ^i N) -i 1)
      let saturated : Bool := true
      (result, saturated))
    else
      (let (result, saturated) : (Int × Bool) :=
        if ((i <b 0) : Bool)
        then
          (let result : Int := 0
          let saturated : Bool := true
          (result, saturated))
        else
          (let result : Int := i
          let saturated : Bool := false
          (result, saturated))
      (result, saturated))
  let result := result
  (pure ((integer_subrange result (N -i 1) 0), saturated))

/-- Type quantifiers: N : Nat, i : Int, k_is_unsigned : Bool, N ≥ 0 -/
def SatQ (i : Int) (N : Nat) (is_unsigned : Bool) : SailM ((BitVec N) × Bool) := do
  let result ← (( do (undefined_bitvector N) ) : SailM (BitVec N) )
  let sat ← (( do (undefined_bool ()) ) : SailM Bool )
  let (result, sat) ← (( do
    let (tup__0, tup__1) ← do
      (if (is_unsigned : Bool)
      then
        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13218.38-13218.39"
            (UnsignedSatQ i N))
      else
        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:13221.38-13221.39"
            (SignedSatQ i N)))
    let result : (BitVec N) := tup__0
    let sat : Bool := tup__1
    (pure (result, sat)) ) : SailM ((BitVec N) × Bool) )
  (pure (result, sat))

def AdvSIMDExpandImm (op : (BitVec 1)) (cmode : (BitVec 4)) (imm8 : (BitVec 8)) : SailM (BitVec 64) := do
  let imm32 ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let imm8a ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8b ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8c ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8d ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8e ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8f ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8g ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm8h ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
  let imm64 ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  match (Sail.BitVec.extractLsb cmode 3 1) with
  | 0b000 => (pure (BitVec.replicateBits ((Zeros (n := 24)) +++ imm8) 2))
  | 0b001 => (pure (BitVec.replicateBits (((Zeros (n := 16)) +++ imm8) +++ (Zeros (n := 8))) 2))
  | 0b010 => (pure (BitVec.replicateBits (((Zeros (n := 8)) +++ imm8) +++ (Zeros (n := 16))) 2))
  | 0b011 => (pure (BitVec.replicateBits (imm8 +++ (Zeros (n := 24))) 2))
  | 0b100 => (pure (BitVec.replicateBits ((Zeros (n := 8)) +++ imm8) 4))
  | 0b101 => (pure (BitVec.replicateBits (imm8 +++ (Zeros (n := 8))) 4))
  | 0b110 =>
    ((if ((((BitVec.access cmode 0) : BitVec 1) == 0#1) : Bool)
    then (do (pure (BitVec.replicateBits (((Zeros (n := 16)) +++ imm8) +++ (Ones (n := 8))) 2)))
    else (do (pure (BitVec.replicateBits (((Zeros (n := 8)) +++ imm8) +++ (Ones (n := 16))) 2)))))
  | _ =>
    (do
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 0#1) && (op == 0#1)) : Bool)
        then (BitVec.replicateBits imm8 8)
        else imm64
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 0#1) && (op == 1#1)) : Bool)
        then
          (let imm8a : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 7) : BitVec 1) 8)
          let imm8b : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 8)
          let imm8c : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 5) : BitVec 1) 8)
          let imm8d : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 4) : BitVec 1) 8)
          let imm8e : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 3) : BitVec 1) 8)
          let imm8f : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 2) : BitVec 1) 8)
          let imm8g : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 1) : BitVec 1) 8)
          let imm8h : (BitVec 8) := (BitVec.replicateBits ((BitVec.access imm8 0) : BitVec 1) 8)
          (((((((imm8a +++ imm8b) +++ imm8c) +++ imm8d) +++ imm8e) +++ imm8f) +++ imm8g) +++ imm8h))
        else imm64
      let imm64 : (BitVec 64) :=
        if (((((BitVec.access cmode 0) : BitVec 1) == 1#1) && (op == 0#1)) : Bool)
        then
          (let imm32 : (BitVec 32) := ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 5)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 19)))
          (BitVec.replicateBits imm32 2))
        else imm64
      (if (((((BitVec.access cmode 0) : BitVec 1) == 1#1) && (op == 1#1)) : Bool)
      then
        (do (if ((← (UsingAArch32 ())) : Bool)
            then (do (ReservedEncoding ()))
            else (do (pure ())))
            (pure ((((((BitVec.access imm8 7) : BitVec 1) +++ (Complement.complement ((BitVec.access imm8 6) : BitVec 1))) +++ (BitVec.replicateBits ((BitVec.access imm8 6) : BitVec 1) 8)) +++ (Sail.BitVec.extractLsb imm8 5 0)) +++ (Zeros (n := 48)))))
      else (do (pure imm64))))

/-- Type quantifiers: k_N : Nat, k_N > 0 -/
def AddWithCarry (x : (BitVec k_N)) (y : (BitVec k_N)) (carry_in : (BitVec 1)) : ((BitVec k_N) × (BitVec 4)) :=
  let unsigned_sum := (((BitVec.toNat x) +i (BitVec.toNat y)) +i (BitVec.toNat carry_in))
  let signed_sum := (((BitVec.toInt x) +i (BitVec.toInt y)) +i (BitVec.toNat carry_in))
  let result : (BitVec k_N) := (integer_subrange unsigned_sum ((Sail.BitVec.length y) -i 1) 0)
  let n : (BitVec 1) := ((BitVec.access result ((Sail.BitVec.length y) -i 1)) : BitVec 1)
  let z : (BitVec 1) :=
    if ((IsZero result) : Bool)
    then 1#1
    else 0#1
  let c : (BitVec 1) :=
    if (((BitVec.toNat result) == unsigned_sum) : Bool)
    then 0#1
    else 1#1
  let v : (BitVec 1) :=
    if (((BitVec.toInt result) == signed_sum) : Bool)
    then 0#1
    else 1#1
  (result, (((n +++ z) +++ c) +++ v))

def HaveRASExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RAS)

def IsExternalSyncAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13362.35-13362.36"
  (pure ((BEq.beq statuscode Fault_SyncExternal) || ((BEq.beq statuscode Fault_SyncParity) || ((BEq.beq statuscode Fault_SyncExternalOnWalk) || (BEq.beq statuscode Fault_SyncParityOnWalk)))))

def IsExternalSyncAbort__1 (fault : FaultRecord) : SailM Bool := do
  (pure ((← (IsExternalSyncAbort fault.statuscode)) || (BEq.beq fault.gpcf.gpf GPCF_EABT)))

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def IsExternalAbortTakenSynchronously (memstatus : PhysMemRetStatus) (iswrite : Bool) (desc : AddressDescriptor) (size : Int) (accdesc : AccessDescriptor) : SailM Bool := do
  (__UNKNOWN_boolean ())

def PendSErrorInterrupt (fault : FaultRecord) : Unit :=
  ()

/-- Type quantifiers: k_iswrite : Bool, size : Int -/
def HandleExternalTTWAbort (memretstatus : PhysMemRetStatus) (iswrite : Bool) (memaddrdesc : AddressDescriptor) (accdesc : AccessDescriptor) (size : Int) (input_fault : FaultRecord) : SailM FaultRecord := do
  let output_fault : FaultRecord := input_fault
  let output_fault : FaultRecord := { output_fault with extflag := memretstatus.extflag }
  let output_fault : FaultRecord := { output_fault with statuscode := memretstatus.statuscode }
  let output_fault ← (( do
    (if ((←((IsExternalSyncAbort__1 output_fault) <&&> (do
         (pure (! (← (IsExternalAbortTakenSynchronously memretstatus iswrite memaddrdesc size accdesc))))))) : Bool)
    then
      (do (if ((BEq.beq output_fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { output_fault with statuscode := Fault_AsyncParity }))
          else (do (pure { output_fault with statuscode := Fault_AsyncExternal }))))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  let output_fault ← (( do
    (if ((← (IsExternalSyncAbort__1 output_fault)) : Bool)
    then
      (do (if ((BEq.beq output_fault.statuscode Fault_SyncParity) : Bool)
          then (do (pure { output_fault with statuscode := Fault_SyncParityOnWalk }))
          else (do (pure { output_fault with statuscode := Fault_SyncExternalOnWalk }))))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  let output_fault ← (( do
    (if ((← (HaveRASExt ())) : Bool)
    then (do (pure { output_fault with merrorstate := memretstatus.merrorstate }))
    else (do (pure output_fault))) ) : SailM FaultRecord )
  (if ((! (← (IsExternalSyncAbort__1 output_fault))) : Bool)
  then
    (do let _ : Unit := (PendSErrorInterrupt output_fault)
        (pure { output_fault with statuscode := Fault_None }))
  else (do (pure output_fault)))

def AArch32_EncodeAsyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 2) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b00#2)
  | .ErrorState_UEU => (pure 0b01#2)
  | .ErrorState_UEO => (pure 0b10#2)
  | .ErrorState_UER => (pure 0b11#2)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 2))

def ActionRequired (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ErrorIsContained (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ErrorIsSynchronized (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUC (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUER (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def ReportErrorAsUEU (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def StateIsRecoverable (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch32_PEErrorState (fault : FaultRecord) : SailM ErrorState := do
  (if ((←((pure (! (← (ErrorIsContained ())))) <||> (do
       (pure (! (← (ErrorIsSynchronized ())))) <&&> (do
         (pure (! (← (StateIsRecoverable ())))))) <||> (do
       (ReportErrorAsUC ())))) : Bool)
  then (do (pure ErrorState_UC))
  else
    (do (if ((←((pure (! (← (StateIsRecoverable ())))) <||> (do
             (ReportErrorAsUEU ())))) : Bool)
        then (do (pure ErrorState_UEU))
        else
          (do (if ((←((ActionRequired ()) <||> (do
                   (ReportErrorAsUER ())))) : Bool)
              then (do (pure ErrorState_UER))
              else (do (pure ErrorState_UEO)))))))

def Have52BitIPAAndPASpaceExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_LPA2)

def Have56BitPAExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_D128)

def HaveMTE2Ext (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_MTE2)

/-- Type quantifiers: level : Int -/
def EncodeLDFSC (statuscode : Fault) (level : Int) : SailM (BitVec 6) := do
  let result ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
  (if ((level == (Neg.neg 2)) : Bool)
  then
    (do sail_assert (← (Have56BitPAExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13478.31-13478.32"
        match statuscode with
        | .Fault_AddressSize => (pure 0b101100#6)
        | .Fault_Translation => (pure 0b101010#6)
        | .Fault_SyncExternalOnWalk => (pure 0b010010#6)
        | .Fault_SyncParityOnWalk =>
          (do
            let result : (BitVec 6) := 0b011010#6
            sail_assert (! (← (HaveRASExt ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13491.43-13491.44"
            (pure result))
        | .Fault_GPCFOnWalk => (pure 0b100010#6)
        | _ =>
          (do
            (Unreachable ())
            (pure result)))
  else
    (do (if ((level == (Neg.neg 1)) : Bool)
        then
          (do sail_assert (← (Have52BitIPAAndPASpaceExt ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13503.42-13503.43"
              match statuscode with
              | .Fault_AddressSize => (pure 0b101001#6)
              | .Fault_Translation => (pure 0b101011#6)
              | .Fault_SyncExternalOnWalk => (pure 0b010011#6)
              | .Fault_SyncParityOnWalk =>
                (do
                  let result : (BitVec 6) := 0b011011#6
                  sail_assert (! (← (HaveRASExt ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13516.43-13516.44"
                  (pure result))
              | .Fault_GPCFOnWalk => (pure 0b100011#6)
              | _ =>
                (do
                  (Unreachable ())
                  (pure result)))
        else
          (do match statuscode with
              | .Fault_AddressSize =>
                (do
                  let result : (BitVec 6) := (0b0000#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13530.66-13530.67"
                  (pure result))
              | .Fault_AccessFlag =>
                (do
                  let result : (BitVec 6) := (0b0010#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13534.66-13534.67"
                  (pure result))
              | .Fault_Permission =>
                (do
                  let result : (BitVec 6) := (0b0011#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13538.66-13538.67"
                  (pure result))
              | .Fault_Translation =>
                (do
                  let result : (BitVec 6) := (0b0001#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13542.66-13542.67"
                  (pure result))
              | .Fault_SyncExternal => (pure 0b010000#6)
              | .Fault_SyncExternalOnWalk =>
                (do
                  let result : (BitVec 6) := (0b0101#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13549.66-13549.67"
                  (pure result))
              | .Fault_SyncParity => (pure 0b011000#6)
              | .Fault_SyncParityOnWalk =>
                (do
                  let result : (BitVec 6) := (0b0111#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13556.66-13556.67"
                  (pure result))
              | .Fault_AsyncParity => (pure 0b011001#6)
              | .Fault_AsyncExternal =>
                (do
                  let result : (BitVec 6) := 0b010001#6
                  sail_assert (← (UsingAArch32 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13563.31-13563.32"
                  (pure result))
              | .Fault_TagCheck =>
                (do
                  let result : (BitVec 6) := 0b010001#6
                  sail_assert (← (HaveMTE2Ext ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:13567.30-13567.31"
                  (pure result))
              | .Fault_Alignment => (pure 0b100001#6)
              | .Fault_Debug => (pure 0b100010#6)
              | .Fault_GPCFOnWalk =>
                (do
                  let result : (BitVec 6) := (0b1001#4 +++ (integer_subrange level 1 0))
                  sail_assert ((level == 0) || ((level == 1) || ((level == 2) || (level == 3)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:13577.66-13577.67"
                  (pure result))
              | .Fault_GPCFOnOutput => (pure 0b101000#6)
              | .Fault_TLBConflict => (pure 0b110000#6)
              | .Fault_HWUpdateAccessFlag => (pure 0b110001#6)
              | .Fault_Lockdown => (pure 0b110100#6)
              | .Fault_Exclusive => (pure 0b110101#6)
              | _ =>
                (do
                  (Unreachable ())
                  (pure result))))))

def IsAsyncAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13606.35-13606.36"
  (pure ((BEq.beq statuscode Fault_AsyncExternal) || (BEq.beq statuscode Fault_AsyncParity)))

def IsAsyncAbort__1 (fault : FaultRecord) : SailM Bool := do
  (IsAsyncAbort fault.statuscode)

def IsExternalAbort (statuscode : Fault) : SailM Bool := do
  sail_assert (bne statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13619.35-13619.36"
  (pure ((BEq.beq statuscode Fault_SyncExternal) || ((BEq.beq statuscode Fault_SyncParity) || ((BEq.beq statuscode Fault_SyncExternalOnWalk) || ((BEq.beq statuscode Fault_SyncParityOnWalk) || ((BEq.beq statuscode Fault_AsyncExternal) || (BEq.beq statuscode Fault_AsyncParity)))))))

def IsExternalAbort__1 (fault : FaultRecord) : SailM Bool := do
  (pure ((← (IsExternalAbort fault.statuscode)) || (BEq.beq fault.gpcf.gpf GPCF_EABT)))

def IsSecondStage (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13630.41-13630.42"
  (pure fault.secondstage)

def LSInstructionSyndrome (_ : Unit) : (BitVec 11) :=
  (Zeros (n := 11))

/-- Type quantifiers: k_d_side : Bool -/
def AArch32_FaultSyndrome (d_side : Bool) (fault : FaultRecord) : SailM (BitVec 25) := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13640.41-13640.42"
  let iss : (BitVec 25) := (Zeros (n := 25))
  let iss2 : (BitVec 24) := (Zeros (n := 24))
  let iss ← (( do
    (if ((←((HaveRASExt ()) <&&> (do
         (IsAsyncAbort__1 fault)))) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          (pure (Sail.BitVec.updateSubrange iss 11 10 (← (AArch32_EncodeAsyncErrorSyndrome errstate)))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss ← (( do
    (if (d_side : Bool)
    then
      (do let iss ← (( do
            (if ((←((pure ((← (IsSecondStage fault)) && (! fault.s2fs1walk))) <&&> (do
                 (pure (! (← (IsExternalSyncAbort__1 fault)))) <||> (do
                   (pure ((! (← (HaveRASExt ()))) && (BEq.beq fault.access.acctype AccessType_TTW))) <&&> (do
                     (__IMPDEF_boolean "ISV on second stage translation table walk")))))) : Bool)
            then (do (pure (Sail.BitVec.updateSubrange iss 24 14 (LSInstructionSyndrome ()))))
            else (do (pure iss))) ) : SailM (BitVec 25) )
          let iss : (BitVec 25) :=
            if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
            then (BitVec.update iss 8 (Bit 1#1))
            else iss
          (if (((BEq.beq fault.access.acctype AccessType_DC) || ((BEq.beq fault.access.acctype AccessType_IC) || (BEq.beq fault.access.acctype AccessType_AT))) : Bool)
          then (do (pure (BitVec.update iss 6 (Bit 1#1))))
          else
            (do (if (((BEq.beq fault.statuscode Fault_HWUpdateAccessFlag) || (BEq.beq fault.statuscode Fault_Exclusive)) : Bool)
                then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                else
                  (do (if ((←((pure fault.access.atomicop) <&&> (do
                           (IsExternalAbort__1 fault)))) : Bool)
                      then (do (pure (BitVec.update iss 6 (Bit (← (__UNKNOWN_bit ()))))))
                      else
                        (do (pure (BitVec.update iss 6
                                (Bit
                                  (if (fault.write : Bool)
                                  then 1#1
                                  else 0#1)))))))))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss ← (( do
    (if ((← (IsExternalAbort__1 fault)) : Bool)
    then (do (pure (BitVec.update iss 9 (Bit fault.extflag))))
    else (do (pure iss))) ) : SailM (BitVec 25) )
  let iss : (BitVec 25) :=
    (BitVec.update iss 7
      (Bit
        (if (fault.s2fs1walk : Bool)
        then 1#1
        else 0#1)))
  (pure (Sail.BitVec.updateSubrange iss 5 0 (← (EncodeLDFSC fault.statuscode fault.level))))

def IPAValid (fault : FaultRecord) : SailM Bool := do
  sail_assert (bne fault.statuscode Fault_None) "sail-arm/arm-v9.4-a/src/v8_base.sail:13675.41-13675.42"
  (if ((bne fault.gpcf.gpf GPCF_None) : Bool)
  then (do (pure fault.secondstage))
  else
    (do (if (fault.s2fs1walk : Bool)
        then (do (pure ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Permission) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_AddressSize))))))
        else
          (do (if (fault.secondstage : Bool)
              then (do (pure ((BEq.beq fault.statuscode Fault_AccessFlag) || ((BEq.beq fault.statuscode Fault_Translation) || (BEq.beq fault.statuscode Fault_AddressSize)))))
              else (do (pure false)))))))

def AArch32_AbortSyndrome (exceptype : Exception) (fault : FaultRecord) (vaddress : (BitVec 32)) (target_el : (BitVec 2)) : SailM ExceptionRecord := do
  let except ← (( do (ExceptionSyndrome exceptype) ) : SailM ExceptionRecord )
  let d_side : Bool := (BEq.beq exceptype Exception_DataAbort)
  let except ← (pure { except with syndrome := (← do (AArch32_FaultSyndrome d_side fault)) })
  let except : ExceptionRecord := { except with vaddress := (Sail.BitVec.zeroExtend vaddress 64) }
  (if ((← (IPAValid fault)) : Bool)
  then
    (do let except : ExceptionRecord := { except with ipavalid := true }
        let except : ExceptionRecord :=
          { except with NS := if ((BEq.beq fault.ipaddress.paspace PAS_NonSecure) : Bool)
            then 1#1
            else 0#1 }
        (pure { except with ipaddress := (Sail.BitVec.zeroExtend fault.ipaddress.address 56) }))
  else (do (pure { except with ipavalid := false })))

def AArch32_ExceptionClass (exceptype : Exception) : SailM (Int × (BitVec 1)) := do
  let il_is_valid : Bool := true
  let ec ← (( do (undefined_int ()) ) : SailM Int )
  let (ec, il_is_valid) ← (( do
    match exceptype with
    | .Exception_Uncategorized =>
      (let ec : Int := (BitVec.toNat 0x00#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_WFxTrap =>
      (let ec : Int := (BitVec.toNat 0x01#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP15RTTrap =>
      (let ec : Int := (BitVec.toNat 0x03#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP15RRTTrap =>
      (let ec : Int := (BitVec.toNat 0x04#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14RTTrap =>
      (let ec : Int := (BitVec.toNat 0x05#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14DTTrap =>
      (let ec : Int := (BitVec.toNat 0x06#8)
      (pure (ec, il_is_valid)))
    | .Exception_AdvSIMDFPAccessTrap =>
      (let ec : Int := (BitVec.toNat 0x07#8)
      (pure (ec, il_is_valid)))
    | .Exception_FPIDTrap =>
      (let ec : Int := (BitVec.toNat 0x08#8)
      (pure (ec, il_is_valid)))
    | .Exception_PACTrap =>
      (let ec : Int := (BitVec.toNat 0x09#8)
      (pure (ec, il_is_valid)))
    | .Exception_TSTARTAccessTrap =>
      (let ec : Int := (BitVec.toNat 0x1B#8)
      (pure (ec, il_is_valid)))
    | .Exception_GPC =>
      (let ec : Int := (BitVec.toNat 0x1E#8)
      (pure (ec, il_is_valid)))
    | .Exception_CP14RRTTrap =>
      (let ec : Int := (BitVec.toNat 0x0C#8)
      (pure (ec, il_is_valid)))
    | .Exception_BranchTarget =>
      (let ec : Int := (BitVec.toNat 0x0D#8)
      (pure (ec, il_is_valid)))
    | .Exception_IllegalState =>
      (let ec : Int := (BitVec.toNat 0x0E#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_SupervisorCall =>
      (let ec : Int := (BitVec.toNat 0x11#8)
      (pure (ec, il_is_valid)))
    | .Exception_HypervisorCall =>
      (let ec : Int := (BitVec.toNat 0x12#8)
      (pure (ec, il_is_valid)))
    | .Exception_MonitorCall =>
      (let ec : Int := (BitVec.toNat 0x13#8)
      (pure (ec, il_is_valid)))
    | .Exception_InstructionAbort =>
      (let ec : Int := (BitVec.toNat 0x20#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_PCAlignment =>
      (let ec : Int := (BitVec.toNat 0x22#8)
      let il_is_valid : Bool := false
      (pure (ec, il_is_valid)))
    | .Exception_DataAbort =>
      (let ec : Int := (BitVec.toNat 0x24#8)
      (pure (ec, il_is_valid)))
    | .Exception_NV2DataAbort =>
      (let ec : Int := (BitVec.toNat 0x25#8)
      (pure (ec, il_is_valid)))
    | .Exception_FPTrappedException =>
      (let ec : Int := (BitVec.toNat 0x28#8)
      (pure (ec, il_is_valid)))
    | _ =>
      (do
        (Unreachable ())
        (pure (ec, il_is_valid))) ) : SailM (Int × Bool) )
  let ec ← (( do
    (if ((←((pure ((ec == (BitVec.toNat 0x20#8)) || ((ec == (BitVec.toNat 0x24#8)) : Bool))) <&&> (do
         (pure ((← readReg PSTATE).EL == EL2))))) : Bool)
    then (do (pure (ec +i 1)))
    else (do (pure ec))) ) : SailM Int )
  let ec := ec
  let il ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let il ← (( do
    (if (il_is_valid : Bool)
    then
      (do (if (((← (ThisInstrLength ())) == 32) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))))
    else (do (pure 1#1))) ) : SailM (BitVec 1) )
  (pure (ec, il))

def HDFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HDFAR_Type := value_name
  writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HDFAR r

def HIFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HIFAR_Type := value_name
  writeReg FAR_EL2 (Sail.BitVec.updateSubrange (← readReg FAR_EL2) 63 32 (BitVec.slice r 0 32))
  writeReg _HIFAR r

def undefined_HPFAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HPFAR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HPFAR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HPFAR ) : SailM HPFAR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg HPFAR_EL2) 0 32)))

def HPFAR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HPFAR_Type := value_name
  writeReg HPFAR_EL2 (Sail.BitVec.updateSubrange (← readReg HPFAR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HPFAR r

def undefined_HSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def HSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : HSR_Type := value_name
  writeReg ESR_EL2 (Sail.BitVec.updateSubrange (← readReg ESR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _HSR r

def AArch32_ReportHypEntry (except : ExceptionRecord) : SailM Unit := do
  let ec ← (( do (undefined_int ()) ) : SailM Int )
  let il ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let exceptype : Exception := except.exceptype
  let (ec, il) ← (( do
    let (tup__0, tup__1) ← do (AArch32_ExceptionClass exceptype)
    let ec : Int := tup__0
    let il : (BitVec 1) := tup__1
    (pure (ec, il)) ) : SailM (Int × (BitVec 1)) )
  let ec := ec
  let iss : (BitVec 25) := except.syndrome
  let iss2 : (BitVec 24) := except.syndrome2
  let il : (BitVec 1) :=
    if ((((ec == (BitVec.toNat 0x24#8)) || ((ec == (BitVec.toNat 0x25#8)) : Bool)) && (((BitVec.access iss 24) : BitVec 1) == 0#1)) : Bool)
    then 1#1
    else il
  let il := il
  (HSR_write (Mk_HSR_Type (((integer_subrange ec 5 0) +++ il) +++ iss)))
  (if (((BEq.beq exceptype Exception_InstructionAbort) || (BEq.beq exceptype Exception_PCAlignment)) : Bool)
  then
    (do (HIFAR_write (Sail.BitVec.extractLsb except.vaddress 31 0))
        (HDFAR_write (← (__UNKNOWN_bits 32))))
  else
    (do (if ((BEq.beq exceptype Exception_DataAbort) : Bool)
        then
          (do (HIFAR_write (← (__UNKNOWN_bits 32)))
              (HDFAR_write (Sail.BitVec.extractLsb except.vaddress 31 0)))
        else (do (pure ())))))
  (if (except.ipavalid : Bool)
  then (do (HPFAR_write (Mk_HPFAR_Type (Sail.BitVec.updateSubrange (← (HPFAR_read ())) 31 4 (Sail.BitVec.extractLsb except.ipaddress 39 12)))))
  else (do (HPFAR_write (Mk_HPFAR_Type (Sail.BitVec.updateSubrange (← (HPFAR_read ())) 31 4 (← (__UNKNOWN_bits 28)))))))

def ELR_hyp_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ELR_hyp_Type := value_name
  writeReg ELR_EL2 (Sail.BitVec.updateSubrange (← readReg ELR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _ELR_hyp r


end ArmASL.Functions
