import ArmASL.Part33

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_f8ad05ef8935cee4 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILT2R_EL0_SysRegWrite_fc59638a1eed5ceb (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILT2R_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: n : Int, s : Int -/
def SPMEVFILTR_EL0_set (s : Int) (n : Int) (value_name : (BitVec 64)) : Unit :=
  ()

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_182705557e8ea81d (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 3) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_20aefd1cb9d1a5ad (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 13) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 13) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 13) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 13) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_299c129e3abe1407 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 10) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_34f238c7595c6e75 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 1) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_437d4622cabaa331 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 7) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_63ddc3864e8582ee (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 14) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_6ac937d3ce7c080c (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 15) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_7801b81c1b7fe92f (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 6) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_800cff4b7bbd47cd (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 2) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_88a821bdd88ae64a (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 11) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_c6614df2d5b55f51 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 5) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_c7152a5fedd83db1 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_d5a6ac5fd18a3308 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 12) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 12) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 12) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 12) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_e6a6baf23bbccd94 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 0) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_ecb12bf267c7f798 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 4) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: t : Int -/
def SPMEVFILTR_EL0_SysRegWrite_f1320088845e7cb6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __EDSCR_SDD ← (( do (pure (_get_EDSCR_Type_SDD (← (EDSCR_read ())))) ) : SailM (BitVec 1) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
              then
                (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((((←((EL2Enabled ()) <&&> (do
                             (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                    then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                    else
                      (do (if (((←((EL2Enabled ()) <&&> (do
                                 (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                      then
                                        (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure (((← (Halted ())) && (HaveEL EL3)) && (__EDSCR_SDD == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                          then
                            (do (if (((← (Halted ())) && (__EDSCR_SDD == 1#1)) : Bool)
                                then (do sailThrow ((Error_Undefined ())))
                                else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                          else (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVFILTR_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 8) (← (X_read t 64)))))
                    else (do (pure ())))))))))

/-- Type quantifiers: n : Int, s : Int -/
def SPMEVTYPER_EL0_set (s : Int) (n : Int) (value_name : (BitVec 64)) : Unit :=
  ()

/-- Type quantifiers: t : Int -/
def SPMEVTYPER_EL0_SysRegWrite_098b2f43a6b02fc6 (el : (BitVec 2)) (op0 : (BitVec 2)) (op1 : (BitVec 3)) (CRn : (BitVec 4)) (op2 : (BitVec 3)) (CRm : (BitVec 4)) (t : Int) : SailM Unit := do
  let __PSTATE_EL ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
  let __MDCR_EL3_EnPM2 ← (( do (pure (_get_MDCR_EL3_Type_EnPM2 (← readReg MDCR_EL3))) ) : SailM (BitVec 1) )
  let __MDSCR_EL1_EnSPM ← (( do (pure (_get_MDSCR_EL1_Type_EnSPM (← readReg MDSCR_EL1))) ) : SailM (BitVec 1) )
  let __HCR_EL2_TGE ← (( do (pure (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) ) : SailM (BitVec 1) )
  let __SCR_EL3_FGTEn2 ← (( do (pure (_get_SCR_EL3_Type_FGTEn2 (← readReg SCR_EL3))) ) : SailM (BitVec 1) )
  let __HDFGWTR2_EL2_nSPMEVTYPERn_EL0 ← (( do (pure (_get_HDFGWTR2_EL2_Type_nSPMEVTYPERn_EL0 (← readReg HDFGWTR2_EL2))) ) : SailM (BitVec 1) )
  let __MDCR_EL2_EnSPM ← (( do (pure (_get_MDCR_EL2_Type_EnSPM (← readReg MDCR_EL2))) ) : SailM (BitVec 1) )
  (if ((__PSTATE_EL == EL0) : Bool)
  then
    (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
        then (do sailThrow ((Error_Undefined ())))
        else
          (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                   (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((__MDSCR_EL1_EnSPM == 0#1) : Bool)
                    then
                      (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                    else
                      (do (if ((←((pure (! (←((EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))))) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL1_field ())) != 0b11#2))))) : Bool)
                          then
                            (do (if (((← (EL2Enabled ())) && (__HCR_EL2_TGE == 1#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else (do (AArch64_SystemAccessTrap EL1 (BitVec.toNat 0x18#8)))))
                          else
                            (do (if ((((←((EL2Enabled ()) <&&> (do
                                         (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                         (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((←((EL2Enabled ()) <&&> (do
                                             (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) != 0b11#2))) <&&> (do
                                             (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                                  then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                                  else
                                                    (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else
                                                          (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                                   (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                              then
                                                                (do (if ((←((Halted ()) <&&> (do
                                                                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                                    then (do sailThrow ((Error_Undefined ())))
                                                                    else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                              else (do (pure (SPMEVTYPER_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))))))))))))))))))
  else
    (do (if ((__PSTATE_EL == EL1) : Bool)
        then
          (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                     (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                     (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
              then (do sailThrow ((Error_Undefined ())))
              else
                (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                         (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                         (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                         (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((((←((EL2Enabled ()) <&&> (do
                                   (IsFeatureImplemented FEAT_FGT2)))) && (HaveEL EL3)) && (__SCR_EL3_FGTEn2 == 0#1)) : Bool)
                          then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                          else
                            (do (if (((←((EL2Enabled ()) <&&> (do
                                       (IsFeatureImplemented FEAT_FGT2)))) && (__HDFGWTR2_EL2_nSPMEVTYPERn_EL0 == 0#1)) : Bool)
                                then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                else
                                  (do (if (((← (EL2Enabled ())) && (__MDCR_EL2_EnSPM == 0#1)) : Bool)
                                      then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                      else
                                        (do (if ((←((EL2Enabled ()) <&&> (do
                                                 (pure ((← (__get_selected_SPMACCESSR_EL2_field ())) != 0b11#2))))) : Bool)
                                            then (do (AArch64_SystemAccessTrap EL2 (BitVec.toNat 0x18#8)))
                                            else
                                              (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                                  then
                                                    (do (if ((←((Halted ()) <&&> (do
                                                             (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                        then (do sailThrow ((Error_Undefined ())))
                                                        else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                  else
                                                    (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                                             (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                                        then
                                                          (do (if ((←((Halted ()) <&&> (do
                                                                   (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                                              then (do sailThrow ((Error_Undefined ())))
                                                              else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                                        else (do (pure (SPMEVTYPER_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))))))))))))))
        else
          (do (if ((__PSTATE_EL == EL2) : Bool)
              then
                (do (if (((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                           (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")))) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                    then (do sailThrow ((Error_Undefined ())))
                    else
                      (do (if ((←((pure ((← (Halted ())) && (HaveEL EL3))) <&&> (do
                               (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))) <&&> (do
                               (__IMPDEF_boolean "EL3 trap priority when SDD == '1'")) <&&> (do
                               (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                          then (do sailThrow ((Error_Undefined ())))
                          else
                            (do (if (((HaveEL EL3) && (__MDCR_EL3_EnPM2 == 0#1)) : Bool)
                                then
                                  (do (if ((←((Halted ()) <&&> (do
                                           (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                      then (do sailThrow ((Error_Undefined ())))
                                      else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                else
                                  (do (if ((←((pure (HaveEL EL3)) <&&> (do
                                           (pure ((← (__get_selected_SPMACCESSR_EL3_field ())) != 0b11#2))))) : Bool)
                                      then
                                        (do (if ((←((Halted ()) <&&> (do
                                                 (pure ((_get_EDSCR_Type_SDD (← (EDSCR_read ()))) == 1#1))))) : Bool)
                                            then (do sailThrow ((Error_Undefined ())))
                                            else (do (AArch64_SystemAccessTrap EL3 (BitVec.toNat 0x18#8)))))
                                      else (do (pure (SPMEVTYPER_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))))))))))
              else
                (do (if ((__PSTATE_EL == EL3) : Bool)
                    then (do (pure (SPMEVTYPER_EL0_set (BitVec.toNat (_get_SPMSELR_EL0_Type_SYSPMUSEL (← readReg SPMSELR_EL0))) (((BitVec.toNat (_get_SPMSELR_EL0_Type_BANK (← readReg SPMSELR_EL0))) *i 16) +i 9) (← (X_read t 64)))))
                    else (do (pure ())))))))))


end ArmASL.Functions
