import ArmASL.Part11

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

/-- Type quantifiers: k_cold : Bool -/
def AArch32_AutoGen_ArchitectureReset (cold : Bool) : SailM Unit := do
  (ICC_SGI1R_write (Mk_ICC_SGI1R_Type (set_slice 8 (← (ICC_SGI1R_read ())) 56 0b00000000#8)))
  (ICC_SGI1R_write (Mk_ICC_SGI1R_Type (set_slice 3 (← (ICC_SGI1R_read ())) 41 0b000#3)))
  (ICC_SGI1R_write (Mk_ICC_SGI1R_Type (set_slice 4 (← (ICC_SGI1R_read ())) 28 0b0000#4)))
  writeReg DBGDSAR (Sail.BitVec.updateSubrange (← readReg DBGDSAR) 63 2 0b00000000000000000000000000000000000000000000000000000000000000#62)
  writeReg DBGDSAR (Sail.BitVec.updateSubrange (← readReg DBGDSAR) 1 0 0b00#2)
  (ICC_SGI0R_write (Mk_ICC_SGI0R_Type (set_slice 8 (← (ICC_SGI0R_read ())) 56 0b00000000#8)))
  (ICC_SGI0R_write (Mk_ICC_SGI0R_Type (set_slice 3 (← (ICC_SGI0R_read ())) 41 0b000#3)))
  (ICC_SGI0R_write (Mk_ICC_SGI0R_Type (set_slice 4 (← (ICC_SGI0R_read ())) 28 0b0000#4)))
  (ICC_ASGI1R_write (Mk_ICC_ASGI1R_Type (set_slice 8 (← (ICC_ASGI1R_read ())) 56 0b00000000#8)))
  (ICC_ASGI1R_write (Mk_ICC_ASGI1R_Type (set_slice 3 (← (ICC_ASGI1R_read ())) 41 0b000#3)))
  (ICC_ASGI1R_write (Mk_ICC_ASGI1R_Type (set_slice 4 (← (ICC_ASGI1R_read ())) 28 0b0000#4)))
  (PAR_write (Mk_PAR_Type (set_slice 32 (← (PAR_read ())) 32 0b00000000000000000000000000000000#32)))
  (PAR_write (Mk_PAR_Type (set_slice 32 (← (PAR_read ())) 32 0b00000000000000000000000000000000#32)))
  (PAR_write (Mk_PAR_Type (set_slice 4 (← (PAR_read ())) 12 0b0000#4)))
  (PAR_write (Mk_PAR_Type (set_slice 4 (← (PAR_read ())) 7 0b0000#4)))
  (PAR_write (Mk_PAR_Type (set_slice 16 (← (PAR_read ())) 40 0b0000000000000000#16)))
  (PAR_write (Mk_PAR_Type (set_slice 6 (← (PAR_read ())) 1 0b000000#6)))
  (PAR_write (Mk_PAR_Type (set_slice 36 (← (PAR_read ())) 12 0b000000000000000000000000000000000000#36)))
  (PAR_write (Mk_PAR_Type (set_slice 1 (← (PAR_read ())) 10 0#1)))
  (PAR_write (Mk_PAR_Type (set_slice 1 (← (PAR_read ())) 7 0#1)))
  (TTBR1_write (Mk_TTBR1_Type (set_slice 32 (← (TTBR1_read ())) 32 0b00000000000000000000000000000000#32)))
  (TTBR1_write (Mk_TTBR1_Type (set_slice 8 (← (TTBR1_read ())) 56 0b00000000#8)))
  writeReg HTTBR (Sail.BitVec.updateSubrange (← readReg HTTBR) 63 48 0b0000000000000000#16)
  (TTBR0_write (Mk_TTBR0_Type (set_slice 32 (← (TTBR0_read ())) 32 0b00000000000000000000000000000000#32)))
  (TTBR0_write (Mk_TTBR0_Type (set_slice 8 (← (TTBR0_read ())) 56 0b00000000#8)))
  (DBGDRAR_write (Mk_DBGDRAR_Type (set_slice 16 (← (DBGDRAR_read ())) 48 0b0000000000000000#16)))
  (DBGDRAR_write (Mk_DBGDRAR_Type (set_slice 10 (← (DBGDRAR_read ())) 2 0b0000000000#10)))
  writeReg VTTBR (Sail.BitVec.updateSubrange (← readReg VTTBR) 63 56 0b00000000#8)
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do writeReg VTTBR (Sail.BitVec.updateSubrange (← readReg VTTBR) 55 48 0b00000000#8))
  else (do writeReg VTTBR (Sail.BitVec.updateSubrange (← readReg VTTBR) 55 48 (← (__UNKNOWN_bits 8)))))
  writeReg GITS_CREADR (Sail.BitVec.updateSubrange (← readReg GITS_CREADR) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg GITS_CREADR (Sail.BitVec.updateSubrange (← readReg GITS_CREADR) 4 1 0b0000#4)
  writeReg GICR_PENDBASER (BitVec.update (← readReg GICR_PENDBASER) 63 (Bit 0#1))
  writeReg GICR_PENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_PENDBASER) 61 59 0b000#3)
  writeReg GICR_PENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_PENDBASER) 55 52 0b0000#4)
  writeReg GICR_PENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_PENDBASER) 15 12 0b0000#4)
  writeReg GICR_PENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_PENDBASER) 6 0 0b0000000#7)
  writeReg GICR_PROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_PROPBASER) 63 59 0b00000#5)
  writeReg GICR_PROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_PROPBASER) 55 52 0b0000#4)
  writeReg GICR_PROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_PROPBASER) 6 5 0b00#2)
  writeReg GICR_VPROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPROPBASER) 63 63 0#1)
  writeReg GICR_VPROPBASER (BitVec.update (← readReg GICR_VPROPBASER) 62 (Bit 0#1))
  writeReg GICR_VPROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPROPBASER) 63 59 0b00000#5)
  writeReg GICR_VPROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPROPBASER) 55 52 0b0000#4)
  writeReg GICR_VPROPBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPROPBASER) 6 5 0b00#2)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 63 60 0b0000#4)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 59 56 0b0000#4)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 55 52 0b0000#4)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 51 48 0b0000#4)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 43 40 0b0000#4)
  writeReg EDPFR (Sail.BitVec.updateSubrange (← readReg EDPFR) 31 28 0b0000#4)
  writeReg GICR_CLRLPIR (Sail.BitVec.updateSubrange (← readReg GICR_CLRLPIR) 63 32 0b00000000000000000000000000000000#32)
  writeReg GICR_INVALLR (Sail.BitVec.updateSubrange (← readReg GICR_INVALLR) 62 48 0b000000000000000#15)
  writeReg GICR_INVALLR (Sail.BitVec.updateSubrange (← readReg GICR_INVALLR) 31 0 0b00000000000000000000000000000000#32)
  writeReg EDHSR (Sail.BitVec.updateSubrange (← readReg EDHSR) 63 41 0b00000000000000000000000#23)
  writeReg EDHSR (Sail.BitVec.updateSubrange (← readReg EDHSR) 39 24 0b0000000000000000#16)
  writeReg EDHSR (BitVec.update (← readReg EDHSR) 14 (Bit 0#1))
  writeReg EDHSR (Sail.BitVec.updateSubrange (← readReg EDHSR) 12 11 0b00#2)
  writeReg EDHSR (BitVec.update (← readReg EDHSR) 9 (Bit 0#1))
  writeReg EDHSR (BitVec.update (← readReg EDHSR) 7 (Bit 0#1))
  writeReg EDHSR (Sail.BitVec.updateSubrange (← readReg EDHSR) 5 0 0b000000#6)
  writeReg EDPCSR (Sail.BitVec.updateSubrange (← readReg EDPCSR) 60 56 0b00000#5)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 63 63 0#1)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 60 60 0#1)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 57 16 0b000000000000000000000000000000000000000000#42)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 63 63 0#1)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 61 61 0#1)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 60 60 0#1)
  writeReg GICR_VPENDBASER (BitVec.update (← readReg GICR_VPENDBASER) 59 (Bit 0#1))
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 55 52 0b0000#4)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 15 12 0b0000#4)
  writeReg GICR_VPENDBASER (Sail.BitVec.updateSubrange (← readReg GICR_VPENDBASER) 6 0 0b0000000#7)
  writeReg GITS_TYPER (Sail.BitVec.updateSubrange (← readReg GITS_TYPER) 63 47 0b00000000000000000#17)
  writeReg GITS_TYPER (Sail.BitVec.updateSubrange (← readReg GITS_TYPER) 23 20 0b0000#4)
  writeReg GITS_SGIR (Sail.BitVec.updateSubrange (← readReg GITS_SGIR) 63 48 0b0000000000000000#16)
  writeReg GITS_SGIR (Sail.BitVec.updateSubrange (← readReg GITS_SGIR) 31 4 0b0000000000000000000000000000#28)
  writeReg EDDFR1 (Sail.BitVec.updateSubrange (← readReg EDDFR1) 55 52 0b0000#4)
  writeReg GITS_CWRITER (Sail.BitVec.updateSubrange (← readReg GITS_CWRITER) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg GITS_CWRITER (Sail.BitVec.updateSubrange (← readReg GITS_CWRITER) 4 1 0b0000#4)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 63 60 0b0000#4)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 55 44 0b000000000000#12)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 39 32 0b00000000#8)
  writeReg EDDFR (Sail.BitVec.updateSubrange (← readReg EDDFR) 3 0 0b0000#4)
  writeReg GICR_INVLPIR (Sail.BitVec.updateSubrange (← readReg GICR_INVLPIR) 62 48 0b000000000000000#15)
  writeReg EDAA32PFR (Sail.BitVec.updateSubrange (← readReg EDAA32PFR) 63 20 0b00000000000000000000000000000000000000000000#44)
  writeReg GITS_CBASER (Sail.BitVec.updateSubrange (← readReg GITS_CBASER) 63 63 0#1)
  writeReg GITS_CBASER (BitVec.update (← readReg GITS_CBASER) 62 (Bit 0#1))
  writeReg GITS_CBASER (Sail.BitVec.updateSubrange (← readReg GITS_CBASER) 58 56 0b000#3)
  writeReg GITS_CBASER (BitVec.update (← readReg GITS_CBASER) 52 (Bit 0#1))
  writeReg GITS_CBASER (Sail.BitVec.updateSubrange (← readReg GITS_CBASER) 9 8 0b00#2)
  writeReg GICR_SETLPIR (Sail.BitVec.updateSubrange (← readReg GICR_SETLPIR) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 27 23 0b00000#5)
  writeReg PMCFGR (BitVec.update (← readReg PMCFGR) 20 (Bit 0#1))
  writeReg PMCFGR (Sail.BitVec.updateSubrange (← readReg PMCFGR) 27 23 0b00000#5)
  writeReg PMCFGR (BitVec.update (← readReg PMCFGR) 20 (Bit 0#1))
  (PMCNTEN_write (Mk_PMCNTEN_Type (set_slice 31 (← (PMCNTEN_read ())) 33 0b0000000000000000000000000000000#31)))
  writeReg PMIIDR (Sail.BitVec.updateSubrange (← readReg PMIIDR) 63 32 0b00000000000000000000000000000000#32)
  writeReg PMIIDR (BitVec.update (← readReg PMIIDR) 7 (Bit 0#1))
  writeReg PMIIDR (BitVec.update (← readReg PMIIDR) 7 (Bit 0#1))
  (PMINTEN_write (Mk_PMINTEN_Type (set_slice 31 (← (PMINTEN_read ())) 33 0b0000000000000000000000000000000#31)))
  (PMOVS_write (Mk_PMOVS_Type (set_slice 31 (← (PMOVS_read ())) 33 0b0000000000000000000000000000000#31)))
  writeReg PMPCSCTL (Sail.BitVec.updateSubrange (← readReg PMPCSCTL) 63 5 0b00000000000000000000000000000000000000000000000000000000000#59)
  writeReg PMPCSCTL (Sail.BitVec.updateSubrange (← readReg PMPCSCTL) 4 4 0#1)
  writeReg PMPCSCTL (Sail.BitVec.updateSubrange (← readReg PMPCSCTL) 3 2 0b00#2)
  writeReg PMPCSCTL (Sail.BitVec.updateSubrange (← readReg PMPCSCTL) 0 0 0#1)
  writeReg PMPCSR (Sail.BitVec.updateSubrange (← readReg PMPCSR) 58 56 0b000#3)
  writeReg PMVCIDSR (Sail.BitVec.updateSubrange (← readReg PMVCIDSR) 63 48 0b0000000000000000#16)
  (TTBCR_write (_update_TTBCR_Type_EAE (← (TTBCR_read ())) 0#1))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 25 (← (TTBCR_read ())) 6 0b0000000000000000000000000#25)))
  (TTBCR_write (_update_TTBCR_Type_PD1 (← (TTBCR_read ())) 0#1))
  (TTBCR_write (_update_TTBCR_Type_PD0 (← (TTBCR_read ())) 0#1))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 1 (← (TTBCR_read ())) 3 0#1)))
  (TTBCR_write (_update_TTBCR_Type_N (← (TTBCR_read ())) 0b000#3))
  (TTBCR_write (_update_TTBCR_Type_EAE (← (TTBCR_read ())) 0#1))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 1 (← (TTBCR_read ())) 30 0#1)))
  (TTBCR_write (_update_TTBCR_Type_SH1 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_ORGN1 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_IRGN1 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_EPD1 (← (TTBCR_read ())) 0#1))
  (TTBCR_write (_update_TTBCR_Type_A1 (← (TTBCR_read ())) 0#1))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 3 (← (TTBCR_read ())) 19 0b000#3)))
  (TTBCR_write (_update_TTBCR_Type_T1SZ (← (TTBCR_read ())) 0b000#3))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 2 (← (TTBCR_read ())) 14 0b00#2)))
  (TTBCR_write (_update_TTBCR_Type_SH0 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_ORGN0 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_IRGN0 (← (TTBCR_read ())) 0b00#2))
  (TTBCR_write (_update_TTBCR_Type_EPD0 (← (TTBCR_read ())) 0#1))
  (TTBCR_write (Mk_TTBCR_Type (set_slice 3 (← (TTBCR_read ())) 3 0b000#3)))
  (TTBCR_write (_update_TTBCR_Type_T0SZ (← (TTBCR_read ())) 0b000#3))
  (HCR_write (Mk_HCR_Type (set_slice 1 (← (HCR_read ())) 31 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TRVM (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TRVM (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_HCD (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_HCD (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HCR_write (Mk_HCR_Type (set_slice 1 (← (HCR_read ())) 28 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TGE (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TGE (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TVM (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TVM (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TTLB (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TTLB (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TPU (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TPU (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TPC (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TPC (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TSW (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TSW (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TAC (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TAC (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TIDCP (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TIDCP (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TSC (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TSC (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TID3 (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TID3 (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TID2 (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TID2 (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TID1 (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TID1 (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TID0 (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TID0 (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TWE (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TWE (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_TWI (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_TWI (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_DC (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_DC (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_BSU (← (HCR_read ())) 0b00#2)))
  else (do (HCR_write (_update_HCR_Type_BSU (← (HCR_read ())) (← (__UNKNOWN_bits 2))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_FB (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_FB (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_VA (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_VA (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_VI (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_VI (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_VF (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_VF (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_AMO (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_AMO (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_IMO (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_IMO (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_FMO (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_FMO (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_PTW (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_PTW (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_SWIO (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_SWIO (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR_write (_update_HCR_Type_VM (← (HCR_read ())) 0#1)))
  else (do (HCR_write (_update_HCR_Type_VM (← (HCR_read ())) (← (__UNKNOWN_bits 1))))))
  (DBGOSDLR_write (Mk_DBGOSDLR_Type (set_slice 31 (← (DBGOSDLR_read ())) 1 0b0000000000000000000000000000000#31)))
  (DBGOSDLR_write (_update_DBGOSDLR_Type_DLK (← (DBGOSDLR_read ())) 0#1))
  (ICH_ELRSR_write (Mk_ICH_ELRSR_Type (set_slice 16 (← (ICH_ELRSR_read ())) 16 0b0000000000000000#16)))
  (ICC_IAR1_write (Mk_ICC_IAR1_Type (set_slice 8 (← (ICC_IAR1_read ())) 24 0b00000000#8)))
  writeReg JOSCR (Sail.BitVec.updateSubrange (← readReg JOSCR) 31 0 0b00000000000000000000000000000000#32)
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TCPAC (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TCPAC (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TAM (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TAM (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (HCPTR_write (Mk_HCPTR_Type (set_slice 9 (← (HCPTR_read ())) 21 0b000000000#9)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TTA (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TTA (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (HCPTR_write (Mk_HCPTR_Type (set_slice 4 (← (HCPTR_read ())) 16 0b0000#4)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TASE (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TASE (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (HCPTR_write (Mk_HCPTR_Type (set_slice 1 (← (HCPTR_read ())) 14 0#1)))
  (HCPTR_write (Mk_HCPTR_Type (set_slice 2 (← (HCPTR_read ())) 12 0b11#2)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TCP11 (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TCP11 (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCPTR_write (_update_HCPTR_Type_TCP10 (← (HCPTR_read ())) 0#1)))
  else (do (HCPTR_write (_update_HCPTR_Type_TCP10 (← (HCPTR_read ())) (← (__UNKNOWN_bits 1))))))
  (HCPTR_write (Mk_HCPTR_Type (set_slice 10 (← (HCPTR_read ())) 0 0b1111111111#10)))
  (ICV_IGRPEN1_write (Mk_ICV_IGRPEN1_Type (set_slice 31 (← (ICV_IGRPEN1_read ())) 1 0b0000000000000000000000000000000#31)))
  (ICV_IGRPEN1_write (_update_ICV_IGRPEN1_Type_Enable (← (ICV_IGRPEN1_read ())) 0#1))
  (CTR_write (Mk_CTR_Type (set_slice 1 (← (CTR_read ())) 31 1#1)))
  (CTR_write (Mk_CTR_Type (set_slice 1 (← (CTR_read ())) 30 0#1)))
  (CTR_write (Mk_CTR_Type (set_slice 10 (← (CTR_read ())) 4 0b0000000000#10)))
  (PMUSERENR_write (Mk_PMUSERENR_Type (set_slice 25 (← (PMUSERENR_read ())) 7 0b0000000000000000000000000#25)))
  (PMUSERENR_write (Mk_PMUSERENR_Type (set_slice 2 (← (PMUSERENR_read ())) 4 0b00#2)))
  (CNTHPS_CTL_write (Mk_CNTHPS_CTL_Type (set_slice 29 (← (CNTHPS_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  (DBGAUTHSTATUS_write (Mk_DBGAUTHSTATUS_Type (set_slice 24 (← (DBGAUTHSTATUS_read ())) 8 0b000000000000000000000000#24)))
  (ICC_IAR0_write (Mk_ICC_IAR0_Type (set_slice 8 (← (ICC_IAR0_read ())) 24 0b00000000#8)))
  (ICV_IGRPEN0_write (Mk_ICV_IGRPEN0_Type (set_slice 31 (← (ICV_IGRPEN0_read ())) 1 0b0000000000000000000000000000000#31)))
  (ICV_IGRPEN0_write (_update_ICV_IGRPEN0_Type_Enable (← (ICV_IGRPEN0_read ())) 0#1))
  (PRRR_write (Mk_PRRR_Type (set_slice 4 (← (PRRR_read ())) 20 0b0000#4)))
  (ICV_CTLR_write (Mk_ICV_CTLR_Type (set_slice 12 (← (ICV_CTLR_read ())) 20 0b000000000000#12)))
  (ICV_CTLR_write (Mk_ICV_CTLR_Type (set_slice 2 (← (ICV_CTLR_read ())) 16 0b00#2)))
  (ICV_CTLR_write (Mk_ICV_CTLR_Type (set_slice 6 (← (ICV_CTLR_read ())) 2 0b000000#6)))
  (HPFAR_write (Mk_HPFAR_Type (set_slice 4 (← (HPFAR_read ())) 0 0b0000#4)))
  (DBGCLAIMCLR_write (Mk_DBGCLAIMCLR_Type (set_slice 24 (← (DBGCLAIMCLR_read ())) 8 0b000000000000000000000000#24)))
  (if (cold : Bool)
  then (do (DBGCLAIMCLR_write (_update_DBGCLAIMCLR_Type_CLAIM (← (DBGCLAIMCLR_read ())) 0b00000000#8)))
  else (do (pure ())))
  (ICV_HPPIR1_write (Mk_ICV_HPPIR1_Type (set_slice 8 (← (ICV_HPPIR1_read ())) 24 0b00000000#8)))
  (ID_MMFR5_write (Mk_ID_MMFR5_Type (set_slice 24 (← (ID_MMFR5_read ())) 8 0b000000000000000000000000#24)))
  (HRMR_write (Mk_HRMR_Type (set_slice 30 (← (HRMR_read ())) 2 0b000000000000000000000000000000#30)))
  (HRMR_write (_update_HRMR_Type_RR (← (HRMR_read ())) 0#1))
  (HCR2_write (Mk_HCR2_Type (set_slice 9 (← (HCR2_read ())) 23 0b000000000#9)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TTLBIS (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TTLBIS (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (HCR2_write (Mk_HCR2_Type (set_slice 1 (← (HCR2_read ())) 21 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TOCU (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TOCU (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (HCR2_write (Mk_HCR2_Type (set_slice 1 (← (HCR2_read ())) 19 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TICAB (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TICAB (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TID4 (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TID4 (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (HCR2_write (Mk_HCR2_Type (set_slice 10 (← (HCR2_read ())) 7 0b0000000000#10)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TEA (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TEA (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_TERR (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_TERR (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (HCR2_write (Mk_HCR2_Type (set_slice 2 (← (HCR2_read ())) 2 0b00#2)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_ID (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_ID (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HCR2_write (_update_HCR2_Type_CD (← (HCR2_read ())) 0#1)))
  else (do (HCR2_write (_update_HCR2_Type_CD (← (HCR2_read ())) (← (__UNKNOWN_bits 1))))))
  (ID_PFR2_write (Mk_ID_PFR2_Type (set_slice 20 (← (ID_PFR2_read ())) 12 0b00000000000000000000#20)))
  (ICV_EOIR0_write (Mk_ICV_EOIR0_Type (set_slice 8 (← (ICV_EOIR0_read ())) 24 0b00000000#8)))
  (ICH_VTR_write (Mk_ICH_VTR_Type (set_slice 14 (← (ICH_VTR_read ())) 5 0b00000000000000#14)))
  (CSSELR_write (Mk_CSSELR_Type (set_slice 28 (← (CSSELR_read ())) 4 0b0000000000000000000000000000#28)))
  writeReg JIDR (Sail.BitVec.updateSubrange (← readReg JIDR) 31 0 0b00000000000000000000000000000000#32)
  (PMCR_write (Mk_PMCR_Type (set_slice 1 (← (PMCR_read ())) 10 0#1)))
  (PMCR_write (Mk_PMCR_Type (set_slice 1 (← (PMCR_read ())) 8 0#1)))
  (PMCR_write (_update_PMCR_Type_LP (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_DP (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_X (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_D (← (PMCR_read ())) 0#1))
  (PMCR_write (_update_PMCR_Type_E (← (PMCR_read ())) 0#1))
  (ICH_VMCR_write (Mk_ICH_VMCR_Type (set_slice 8 (← (ICH_VMCR_read ())) 10 0b00000000#8)))
  (ICH_VMCR_write (Mk_ICH_VMCR_Type (set_slice 4 (← (ICH_VMCR_read ())) 5 0b0000#4)))
  writeReg DBGDEVID1 (Sail.BitVec.updateSubrange (← readReg DBGDEVID1) 31 4 0b0000000000000000000000000000#28)
  (ICC_BPR1_write (Mk_ICC_BPR1_Type (set_slice 29 (← (ICC_BPR1_read ())) 3 0b00000000000000000000000000000#29)))
  (ICV_RPR_write (Mk_ICV_RPR_Type (set_slice 24 (← (ICV_RPR_read ())) 8 0b000000000000000000000000#24)))
  (VBAR_write (set_slice 5 (← (VBAR_read__2 ())) 0 0b00000#5))
  (ID_ISAR0_write (Mk_ID_ISAR0_Type (set_slice 4 (← (ID_ISAR0_read ())) 28 0b0000#4)))
  (ICV_IAR1_write (Mk_ICV_IAR1_Type (set_slice 8 (← (ICV_IAR1_read ())) 24 0b00000000#8)))
  (DBGPRCR_write (Mk_DBGPRCR_Type (set_slice 31 (← (DBGPRCR_read ())) 1 0b0000000000000000000000000000000#31)))
  (SDER_write (Mk_SDER_Type (set_slice 30 (← (SDER_read ())) 2 0b000000000000000000000000000000#30)))
  (SDER_write (_update_SDER_Type_SUNIDEN (← (SDER_read ())) 0#1))
  (SDER_write (_update_SDER_Type_SUIDEN (← (SDER_read ())) 0#1))
  (ICC_EOIR1_write (Mk_ICC_EOIR1_Type (set_slice 8 (← (ICC_EOIR1_read ())) 24 0b00000000#8)))
  (ICC_BPR0_write (Mk_ICC_BPR0_Type (set_slice 29 (← (ICC_BPR0_read ())) 3 0b00000000000000000000000000000#29)))
  (CNTHCTL_write (Mk_CNTHCTL_Type (set_slice 14 (← (CNTHCTL_read ())) 18 0b00000000000000#14)))
  (CNTHCTL_write (Mk_CNTHCTL_Type (set_slice 9 (← (CNTHCTL_read ())) 8 0b000000000#9)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 29 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 9 (← (DBGVCR_read ())) 16 0b000000000#9)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 13 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 2 (← (DBGVCR_read ())) 8 0b00#2)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 5 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 0 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 29 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 17 (← (DBGVCR_read ())) 8 0b00000000000000000#17)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 5 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 0 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 24 (← (DBGVCR_read ())) 8 0b000000000000000000000000#24)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 5 0#1)))
  (DBGVCR_write (Mk_DBGVCR_Type (set_slice 1 (← (DBGVCR_read ())) 0 0#1)))
  (ICC_EOIR0_write (Mk_ICC_EOIR0_Type (set_slice 8 (← (ICC_EOIR0_read ())) 24 0b00000000#8)))
  (ICV_BPR1_write (Mk_ICV_BPR1_Type (set_slice 29 (← (ICV_BPR1_read ())) 3 0b00000000000000000000000000000#29)))
  (ICC_RPR_write (Mk_ICC_RPR_Type (set_slice 24 (← (ICC_RPR_read ())) 8 0b000000000000000000000000#24)))
  (MVFR2_write (Mk_MVFR2_Type (set_slice 24 (← (MVFR2_read ())) 8 0b000000000000000000000000#24)))
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 31 4 0b0000000000000000000000000000#28)
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 2 2 0#1)
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 1 1 0#1)
  writeReg ICC_MSRE (Sail.BitVec.updateSubrange (← readReg ICC_MSRE) 0 0 0#1)
  writeReg PMMIR (Sail.BitVec.updateSubrange (← readReg PMMIR) 31 28 0b0000#4)
  (VMPIDR_write (_update_VMPIDR_Type_U (← (VMPIDR_read ())) (← (__UNKNOWN_bits 1))))
  (VMPIDR_write (Mk_VMPIDR_Type (set_slice 5 (← (VMPIDR_read ())) 25 0b00000#5)))
  (VMPIDR_write (_update_VMPIDR_Type_MT (← (VMPIDR_read ())) (← (__UNKNOWN_bits 1))))
  (VMPIDR_write (_update_VMPIDR_Type_Aff2 (← (VMPIDR_read ())) (← (__UNKNOWN_bits 8))))
  (VMPIDR_write (_update_VMPIDR_Type_Aff1 (← (VMPIDR_read ())) (← (__UNKNOWN_bits 8))))
  (VMPIDR_write (_update_VMPIDR_Type_Aff0 (← (VMPIDR_read ())) (← (__UNKNOWN_bits 8))))
  (ICC_IGRPEN1_write (Mk_ICC_IGRPEN1_Type (set_slice 31 (← (ICC_IGRPEN1_read ())) 1 0b0000000000000000000000000000000#31)))
  (ICC_IGRPEN1_write (_update_ICC_IGRPEN1_Type_Enable (← (ICC_IGRPEN1_read ())) 0#1))
  (HVBAR_write (set_slice 5 (← (HVBAR_read ())) 0 0b00000#5))
  (HSTR_write (Mk_HSTR_Type (set_slice 16 (← (HSTR_read ())) 16 (BitVec.slice 0b000000000000000000#18 2 16))))
  (HSTR_write (Mk_HSTR_Type (set_slice 1 (← (HSTR_read ())) 14 (BitVec.slice 0b000000000000000000#18 1 1))))
  (HSTR_write (Mk_HSTR_Type (set_slice 1 (← (HSTR_read ())) 4 (BitVec.slice 0b000000000000000000#18 0 1))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T15 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T15 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T13 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T13 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T12 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T12 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T11 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T11 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T10 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T10 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T9 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T9 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T8 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T8 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T7 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T7 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T6 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T6 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T5 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T5 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T3 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T3 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T2 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T2 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T1 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T1 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HSTR_write (_update_HSTR_Type_T0 (← (HSTR_read ())) 0#1)))
  else (do (HSTR_write (_update_HSTR_Type_T0 (← (HSTR_read ())) (← (__UNKNOWN_bits 1))))))
  writeReg ICC_MCTLR (Sail.BitVec.updateSubrange (← readReg ICC_MCTLR) 31 20 0b000000000000#12)
  writeReg ICC_MCTLR (BitVec.update (← readReg ICC_MCTLR) 16 (Bit 0#1))
  writeReg ICC_MCTLR (BitVec.update (← readReg ICC_MCTLR) 7 (Bit 0#1))
  writeReg ICC_MCTLR (Sail.BitVec.updateSubrange (← readReg ICC_MCTLR) 6 6 0#1)
  (ICC_DIR_write (Mk_ICC_DIR_Type (set_slice 8 (← (ICC_DIR_read ())) 24 0b00000000#8)))
  (PMSELR_write (Mk_PMSELR_Type (set_slice 27 (← (PMSELR_read ())) 5 0b000000000000000000000000000#27)))
  (ID_AFR0_write (set_slice 16 (← (ID_AFR0_read ())) 16 0b0000000000000000#16))
  (DBGCLAIMSET_write (Mk_DBGCLAIMSET_Type (set_slice 24 (← (DBGCLAIMSET_read ())) 8 0b000000000000000000000000#24)))
  (if (cold : Bool)
  then (do (DBGCLAIMSET_write (_update_DBGCLAIMSET_Type_CLAIM (← (DBGCLAIMSET_read ())) 0b00000000#8)))
  else (do (pure ())))
  (ICC_IGRPEN0_write (Mk_ICC_IGRPEN0_Type (set_slice 31 (← (ICC_IGRPEN0_read ())) 1 0b0000000000000000000000000000000#31)))
  (ICC_IGRPEN0_write (_update_ICC_IGRPEN0_Type_Enable (← (ICC_IGRPEN0_read ())) 0#1))
  (ICC_CTLR_write (Mk_ICC_CTLR_Type (set_slice 12 (← (ICC_CTLR_read ())) 20 0b000000000000#12)))
  (ICC_CTLR_write (Mk_ICC_CTLR_Type (set_slice 2 (← (ICC_CTLR_read ())) 16 0b00#2)))
  (ICC_CTLR_write (Mk_ICC_CTLR_Type (set_slice 1 (← (ICC_CTLR_read ())) 7 0#1)))
  (ICC_CTLR_write (Mk_ICC_CTLR_Type (set_slice 4 (← (ICC_CTLR_read ())) 2 0b0000#4)))
  (CNTHVS_CTL_write (Mk_CNTHVS_CTL_Type (set_slice 29 (← (CNTHVS_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 31 16 0b0000000000000000#16)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 15 15 0#1)
  writeReg SCR (BitVec.update (← readReg SCR) 14 (Bit 0#1))
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 13 13 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 12 12 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 11 10 0b00#2)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 9 9 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 8 8 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 7 7 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 6 6 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 5 5 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 4 4 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 3 3 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 2 2 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 1 1 0#1)
  writeReg SCR (Sail.BitVec.updateSubrange (← readReg SCR) 0 0 0#1)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 31 21 0b00000000000#11)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 20 20 0#1)
  writeReg NSACR (BitVec.update (← readReg NSACR) 19 (Bit 0#1))
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 15 15 0#1)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 14 12 0b000#3)
  writeReg NSACR (Sail.BitVec.updateSubrange (← readReg NSACR) 9 0 0b0000000000#10)
  (ICV_BPR0_write (Mk_ICV_BPR0_Type (set_slice 29 (← (ICV_BPR0_read ())) 3 0b00000000000000000000000000000#29)))
  (ICH_EISR_write (Mk_ICH_EISR_Type (set_slice 16 (← (ICH_EISR_read ())) 16 0b0000000000000000#16)))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status15 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status14 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status13 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status12 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status11 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status10 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status9 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status8 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status7 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status6 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status5 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status4 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status3 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status2 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status1 (← (ICH_EISR_read ())) 0#1))
  (ICH_EISR_write (_update_ICH_EISR_Type_Status0 (← (ICH_EISR_read ())) 0#1))
  (HDCR_write (Mk_HDCR_Type (set_slice 2 (← (HDCR_read ())) 30 0b00#2)))
  (if ((cold && true) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_MTPME (← (HDCR_read ())) (← (__UNKNOWN_bits 1)))))
  else
    (do (if ((←((pure cold) <&&> (do
             (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
        then (do (HDCR_write (_update_HDCR_Type_MTPME (← (HDCR_read ())) 1#1)))
        else (do (pure ())))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TDCC (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TDCC (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HDCR_write (Mk_HDCR_Type (set_slice 2 (← (HDCR_read ())) 24 0b00#2)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_HCCD (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_HCCD (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HDCR_write (Mk_HDCR_Type (set_slice 3 (← (HDCR_read ())) 20 0b000#3)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TTRF (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TTRF (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HDCR_write (Mk_HDCR_Type (set_slice 1 (← (HDCR_read ())) 18 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (HaveAArch64 ()))))))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_HPMD (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_HPMD (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HDCR_write (Mk_HDCR_Type (set_slice 5 (← (HDCR_read ())) 12 0b00000#5)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TDRA (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TDRA (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TDOSA (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TDOSA (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TDA (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TDA (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TDE (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TDE (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (HaveAArch64 ()))))))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_HPME (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_HPME (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (pure (! (← (HaveAArch64 ()))))))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TPM (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TPM (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HDCR_write (_update_HDCR_Type_TPMCR (← (HDCR_read ())) 0#1)))
  else (do (HDCR_write (_update_HDCR_Type_TPMCR (← (HDCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HDCR_write (_update_HDCR_Type_HPMN (← (HDCR_read ())) (← (__UNKNOWN_bits 5))))
  (ICC_HSRE_write (Mk_ICC_HSRE_Type (set_slice 28 (← (ICC_HSRE_read ())) 4 0b0000000000000000000000000000#28)))
  (ICC_HSRE_write (_update_ICC_HSRE_Type_DIB (← (ICC_HSRE_read ())) 0#1))
  (ICC_HSRE_write (_update_ICC_HSRE_Type_DFB (← (ICC_HSRE_read ())) 0#1))
  (ICC_HSRE_write (_update_ICC_HSRE_Type_SRE (← (ICC_HSRE_read ())) 0#1))
  (PMCCFILTR_write (_update_PMCCFILTR_Type_P (← (PMCCFILTR_read ())) 0#1))
  (PMCCFILTR_write (_update_PMCCFILTR_Type_U (← (PMCCFILTR_read ())) 0#1))
  (PMCCFILTR_write (_update_PMCCFILTR_Type_NSK (← (PMCCFILTR_read ())) 0#1))
  (PMCCFILTR_write (_update_PMCCFILTR_Type_NSU (← (PMCCFILTR_read ())) 0#1))
  (PMCCFILTR_write (_update_PMCCFILTR_Type_NSH (← (PMCCFILTR_read ())) 0#1))
  (PMCCFILTR_write (Mk_PMCCFILTR_Type (set_slice 5 (← (PMCCFILTR_read ())) 22 0b00000#5)))
  (PMCCFILTR_write (Mk_PMCCFILTR_Type (set_slice 21 (← (PMCCFILTR_read ())) 0 0b000000000000000000000#21)))
  (ID_ISAR5_write (Mk_ID_ISAR5_Type (set_slice 4 (← (ID_ISAR5_read ())) 20 0b0000#4)))
  (HTCR_write (Mk_HTCR_Type (set_slice 1 (← (HTCR_read ())) 31 1#1)))
  (HTCR_write (Mk_HTCR_Type (set_slice 1 (← (HTCR_read ())) 29 0#1)))
  (HTCR_write (Mk_HTCR_Type (set_slice 1 (← (HTCR_read ())) 23 1#1)))
  (HTCR_write (Mk_HTCR_Type (set_slice 9 (← (HTCR_read ())) 14 0b000000000#9)))
  (HTCR_write (Mk_HTCR_Type (set_slice 5 (← (HTCR_read ())) 3 0b00000#5)))
  (ICC_PMR_write (Mk_ICC_PMR_Type (set_slice 24 (← (ICC_PMR_read ())) 8 0b000000000000000000000000#24)))
  (ICC_PMR_write (_update_ICC_PMR_Type_Priority (← (ICC_PMR_read ())) 0b00000000#8))
  (ICV_EOIR1_write (Mk_ICV_EOIR1_Type (set_slice 8 (← (ICV_EOIR1_read ())) 24 0b00000000#8)))
  (ICH_HCR_write (_update_ICH_HCR_Type_EOIcount (← (ICH_HCR_read ())) 0b00000#5))
  (ICH_HCR_write (Mk_ICH_HCR_Type (set_slice 12 (← (ICH_HCR_read ())) 15 0b000000000000#12)))
  (ICH_HCR_write (_update_ICH_HCR_Type_TDIR (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_TSEI (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_TALL1 (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_TALL0 (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_TC (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (Mk_ICH_HCR_Type (set_slice 1 (← (ICH_HCR_read ())) 9 0#1)))
  (ICH_HCR_write (_update_ICH_HCR_Type_vSGIEOICount (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_VGrp1DIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_VGrp1EIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_VGrp0DIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_VGrp0EIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_NPIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_LRENPIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_UIE (← (ICH_HCR_read ())) 0#1))
  (ICH_HCR_write (_update_ICH_HCR_Type_En (← (ICH_HCR_read ())) 0#1))
  (RMR_write (Mk_RMR_Type (set_slice 30 (← (RMR_read ())) 2 0b000000000000000000000000000000#30)))
  (RMR_write (_update_RMR_Type_RR (← (RMR_read ())) 0#1))
  (FPEXC_write (_update_FPEXC_Type_EN (← (FPEXC_read ())) 0#1))
  (FPEXC_write (Mk_FPEXC_Type (set_slice 15 (← (FPEXC_read ())) 11 0b000000000000000#15)))
  (FPEXC_write (Mk_FPEXC_Type (set_slice 2 (← (FPEXC_read ())) 5 0b00#2)))
  (ICC_HPPIR0_write (Mk_ICC_HPPIR0_Type (set_slice 8 (← (ICC_HPPIR0_read ())) 24 0b00000000#8)))
  (TTBCR2_write (Mk_TTBCR2_Type (set_slice 13 (← (TTBCR2_read ())) 19 0b0000000000000#13)))
  (TTBCR2_write (Mk_TTBCR2_Type (set_slice 9 (← (TTBCR2_read ())) 0 0b000000000#9)))
  writeReg FCSEIDR (Sail.BitVec.updateSubrange (← readReg FCSEIDR) 31 0 0b00000000000000000000000000000000#32)
  (ID_DFR1_write (Mk_ID_DFR1_Type (set_slice 24 (← (ID_DFR1_read ())) 8 0b000000000000000000000000#24)))
  writeReg JMCR (Sail.BitVec.updateSubrange (← readReg JMCR) 31 0 0b00000000000000000000000000000000#32)
  (CNTKCTL_write (Mk_CNTKCTL_Type (set_slice 14 (← (CNTKCTL_read__1 ())) 18 0b00000000000000#14)))
  (CNTKCTL_write (Mk_CNTKCTL_Type (set_slice 7 (← (CNTKCTL_read__1 ())) 10 0b0000000#7)))
  (ICV_PMR_write (Mk_ICV_PMR_Type (set_slice 24 (← (ICV_PMR_read ())) 8 0b000000000000000000000000#24)))
  (ICV_PMR_write (_update_ICV_PMR_Type_Priority (← (ICV_PMR_read ())) 0b00000000#8))
  (ICV_HPPIR0_write (Mk_ICV_HPPIR0_Type (set_slice 8 (← (ICV_HPPIR0_read ())) 24 0b00000000#8)))
  writeReg DBGWFAR (Sail.BitVec.updateSubrange (← readReg DBGWFAR) 31 0 0b00000000000000000000000000000000#32)
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 2 (← (HSCTLR_read ())) 28 0b11#2)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 2 (← (HSCTLR_read ())) 26 0b00#2)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 24 0#1)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 2 (← (HSCTLR_read ())) 22 0b11#2)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 2 (← (HSCTLR_read ())) 20 0b00#2)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 18 1#1)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 17 0#1)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 16 1#1)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 3 (← (HSCTLR_read ())) 13 0b000#3)))
  (HSCTLR_write (_update_HSCTLR_Type_I (← (HSCTLR_read ())) 0#1))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 11 1#1)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 2 (← (HSCTLR_read ())) 9 0b00#2)))
  (HSCTLR_write (Mk_HSCTLR_Type (set_slice 1 (← (HSCTLR_read ())) 6 0#1)))
  (HSCTLR_write (_update_HSCTLR_Type_LSMAOE (← (HSCTLR_read ())) 1#1))
  (HSCTLR_write (_update_HSCTLR_Type_nTLSMD (← (HSCTLR_read ())) 1#1))
  (HSCTLR_write (_update_HSCTLR_Type_C (← (HSCTLR_read ())) 0#1))
  (HSCTLR_write (_update_HSCTLR_Type_M (← (HSCTLR_read ())) 0#1))
  (VTCR_write (Mk_VTCR_Type (set_slice 1 (← (VTCR_read ())) 31 1#1)))
  (VTCR_write (Mk_VTCR_Type (set_slice 2 (← (VTCR_read ())) 29 0b00#2)))
  (VTCR_write (Mk_VTCR_Type (set_slice 11 (← (VTCR_read ())) 14 0b00000000000#11)))
  (VTCR_write (Mk_VTCR_Type (set_slice 1 (← (VTCR_read ())) 5 0#1)))
  writeReg ICC_MGRPEN1 (Sail.BitVec.updateSubrange (← readReg ICC_MGRPEN1) 31 2 0b000000000000000000000000000000#30)
  writeReg ICC_MGRPEN1 (Sail.BitVec.updateSubrange (← readReg ICC_MGRPEN1) 1 1 0#1)
  writeReg ICC_MGRPEN1 (Sail.BitVec.updateSubrange (← readReg ICC_MGRPEN1) 0 0 0#1)
  (DFSR_write (Mk_DFSR_Type (set_slice 15 (← (DFSR_read ())) 17 0b000000000000000#15)))
  (DFSR_write (Mk_DFSR_Type (set_slice 1 (← (DFSR_read ())) 8 0#1)))
  (DFSR_write (Mk_DFSR_Type (set_slice 15 (← (DFSR_read ())) 17 0b000000000000000#15)))
  (DFSR_write (Mk_DFSR_Type (set_slice 1 (← (DFSR_read ())) 10 0#1)))
  (DFSR_write (Mk_DFSR_Type (set_slice 3 (← (DFSR_read ())) 6 0b000#3)))
  (CCSIDR2_write (Mk_CCSIDR2_Type (set_slice 8 (← (CCSIDR2_read ())) 24 0b00000000#8)))
  (CNTHV_CTL_write (Mk_CNTHV_CTL_Type (set_slice 29 (← (CNTHV_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  (ICH_MISR_write (Mk_ICH_MISR_Type (set_slice 24 (← (ICH_MISR_read ())) 8 0b000000000000000000000000#24)))
  (ICH_MISR_write (_update_ICH_MISR_Type_VGrp1D (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_VGrp1E (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_VGrp0D (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_VGrp0E (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_NP (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_LRENP (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_U (← (ICH_MISR_read ())) 0#1))
  (ICH_MISR_write (_update_ICH_MISR_Type_EOI (← (ICH_MISR_read ())) 0#1))
  (CPACR_write (_update_CPACR_Type_ASEDIS (← (CPACR_read__1 ())) 0#1))
  (CPACR_write (Mk_CPACR_Type (set_slice 2 (← (CPACR_read__1 ())) 29 0b00#2)))
  (CPACR_write (Mk_CPACR_Type (set_slice 4 (← (CPACR_read__1 ())) 24 0b0000#4)))
  (CPACR_write (_update_CPACR_Type_cp11 (← (CPACR_read__1 ())) 0b00#2))
  (CPACR_write (_update_CPACR_Type_cp10 (← (CPACR_read__1 ())) 0b00#2))
  (CPACR_write (Mk_CPACR_Type (set_slice 20 (← (CPACR_read__1 ())) 0 0b00000000000000000000#20)))
  (ICV_IAR0_write (Mk_ICV_IAR0_Type (set_slice 8 (← (ICV_IAR0_read ())) 24 0b00000000#8)))
  (ISR_write (Mk_ISR_Type (set_slice 23 (← (ISR_read ())) 9 0b00000000000000000000000#23)))
  (ISR_write (Mk_ISR_Type (set_slice 6 (← (ISR_read ())) 0 0b000000#6)))
  (SCTLR_write (_update_SCTLR_Type_AFE (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_TRE (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 2 (← (SCTLR_read__2 ())) 26 0b00#2)))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 24 0#1)))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 22 1#1)))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 21 0#1)))
  (SCTLR_write (_update_SCTLR_Type_UWXN (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_WXN (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_nTWE (← (SCTLR_read__2 ())) 1#1))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 17 0#1)))
  (SCTLR_write (_update_SCTLR_Type_nTWI (← (SCTLR_read__2 ())) 1#1))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 2 (← (SCTLR_read__2 ())) 14 0b00#2)))
  (SCTLR_write (_update_SCTLR_Type_I (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 11 1#1)))
  (SCTLR_write (Mk_SCTLR_Type (set_slice 1 (← (SCTLR_read__2 ())) 9 0#1)))
  (SCTLR_write (_update_SCTLR_Type_SED (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_ITD (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_CP15BEN (← (SCTLR_read__2 ())) 1#1))
  (SCTLR_write (_update_SCTLR_Type_LSMAOE (← (SCTLR_read__2 ())) 1#1))
  (SCTLR_write (_update_SCTLR_Type_nTLSMD (← (SCTLR_read__2 ())) 1#1))
  (SCTLR_write (_update_SCTLR_Type_C (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_A (← (SCTLR_read__2 ())) 0#1))
  (SCTLR_write (_update_SCTLR_Type_M (← (SCTLR_read__2 ())) 0#1))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 1 (← (DBGDSCRint_read ())) 31 0#1)))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 10 (← (DBGDSCRint_read ())) 19 0b0000000000#10)))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 2 (← (DBGDSCRint_read ())) 13 0b00#2)))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 6 (← (DBGDSCRint_read ())) 6 0b000000#6)))
  (DBGDSCRint_write (Mk_DBGDSCRint_Type (set_slice 2 (← (DBGDSCRint_read ())) 0 0b00#2)))
  (DBGDCCINT_write (Mk_DBGDCCINT_Type (set_slice 1 (← (DBGDCCINT_read ())) 31 0#1)))
  (DBGDCCINT_write (_update_DBGDCCINT_Type_RX (← (DBGDCCINT_read ())) 0#1))
  (DBGDCCINT_write (_update_DBGDCCINT_Type_TX (← (DBGDCCINT_read ())) 0#1))
  (DBGDCCINT_write (Mk_DBGDCCINT_Type (set_slice 29 (← (DBGDCCINT_read ())) 0 0b00000000000000000000000000000#29)))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 1 (← (DBGDSCRext_read ())) 28 0#1)))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 2 (← (DBGDSCRext_read ())) 24 0b00#2)))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 1 (← (DBGDSCRext_read ())) 20 0#1)))
  (DBGDSCRext_write (_update_DBGDSCRext_Type_MDBGen (← (DBGDSCRext_read ())) 0#1))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 1 (← (DBGDSCRext_read ())) 13 0#1)))
  (DBGDSCRext_write (_update_DBGDSCRext_Type_UDCCdis (← (DBGDSCRext_read ())) 0#1))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 5 (← (DBGDSCRext_read ())) 7 0b00000#5)))
  (DBGDSCRext_write (Mk_DBGDSCRext_Type (set_slice 2 (← (DBGDSCRext_read ())) 0 0b00#2)))
  (IFSR_write (Mk_IFSR_Type (set_slice 15 (← (IFSR_read ())) 17 0b000000000000000#15)))
  (IFSR_write (Mk_IFSR_Type (set_slice 3 (← (IFSR_read ())) 13 0b000#3)))
  (IFSR_write (Mk_IFSR_Type (set_slice 1 (← (IFSR_read ())) 11 0#1)))
  (IFSR_write (Mk_IFSR_Type (set_slice 5 (← (IFSR_read ())) 4 0b00000#5)))
  (IFSR_write (Mk_IFSR_Type (set_slice 15 (← (IFSR_read ())) 17 0b000000000000000#15)))
  (IFSR_write (Mk_IFSR_Type (set_slice 3 (← (IFSR_read ())) 13 0b000#3)))
  (IFSR_write (Mk_IFSR_Type (set_slice 2 (← (IFSR_read ())) 10 0b00#2)))
  (IFSR_write (Mk_IFSR_Type (set_slice 3 (← (IFSR_read ())) 6 0b000#3)))
  writeReg DBGDIDR (BitVec.update (← readReg DBGDIDR) 15 (Bit 1#1))
  writeReg DBGDIDR (BitVec.update (← readReg DBGDIDR) 13 (Bit 0#1))
  writeReg DBGDIDR (Sail.BitVec.updateSubrange (← readReg DBGDIDR) 11 0 0b000000000000#12)
  (CNTP_CTL_write (Mk_CNTP_CTL_Type (set_slice 29 (← (CNTP_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  (CNTP_CTL_write (_update_CNTP_CTL_Type_ENABLE (← (CNTP_CTL_read ())) 0#1))
  (FPSCR_write (Mk_FPSCR_Type (set_slice 2 (← (FPSCR_read__1 ())) 13 0b00#2)))
  (FPSCR_write (Mk_FPSCR_Type (set_slice 2 (← (FPSCR_read__1 ())) 5 0b00#2)))
  (HTRFCR_write (Mk_HTRFCR_Type (set_slice 25 (← (HTRFCR_read ())) 7 0b0000000000000000000000000#25)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HTRFCR_write (_update_HTRFCR_Type_TS (← (HTRFCR_read ())) 0b00#2)))
  else (do (HTRFCR_write (_update_HTRFCR_Type_TS (← (HTRFCR_read ())) (← (__UNKNOWN_bits 2))))))
  (HTRFCR_write (Mk_HTRFCR_Type (set_slice 1 (← (HTRFCR_read ())) 4 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HTRFCR_write (_update_HTRFCR_Type_CX (← (HTRFCR_read ())) 0#1)))
  else (do (HTRFCR_write (_update_HTRFCR_Type_CX (← (HTRFCR_read ())) (← (__UNKNOWN_bits 1))))))
  (HTRFCR_write (Mk_HTRFCR_Type (set_slice 1 (← (HTRFCR_read ())) 2 0#1)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HTRFCR_write (_update_HTRFCR_Type_E2TRE (← (HTRFCR_read ())) 0#1)))
  else (do (HTRFCR_write (_update_HTRFCR_Type_E2TRE (← (HTRFCR_read ())) (← (__UNKNOWN_bits 1))))))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (HTRFCR_write (_update_HTRFCR_Type_E0HTRE (← (HTRFCR_read ())) 0#1)))
  else (do (HTRFCR_write (_update_HTRFCR_Type_E0HTRE (← (HTRFCR_read ())) (← (__UNKNOWN_bits 1))))))
  (VPIDR_write (_update_VPIDR_Type_Implementer (← (VPIDR_read ())) (← (__UNKNOWN_bits 8))))
  (VPIDR_write (_update_VPIDR_Type_Variant (← (VPIDR_read ())) (← (__UNKNOWN_bits 4))))
  (VPIDR_write (_update_VPIDR_Type_Architecture (← (VPIDR_read ())) (← (__UNKNOWN_bits 4))))
  (VPIDR_write (_update_VPIDR_Type_PartNum (← (VPIDR_read ())) (← (__UNKNOWN_bits 12))))
  (VPIDR_write (_update_VPIDR_Type_Revision (← (VPIDR_read ())) (← (__UNKNOWN_bits 4))))
  (PMSWINC_write (Mk_PMSWINC_Type (set_slice 1 (← (PMSWINC_read ())) 31 0#1)))
  (CNTV_CTL_write (Mk_CNTV_CTL_Type (set_slice 29 (← (CNTV_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  (CNTV_CTL_write (_update_CNTV_CTL_Type_ENABLE (← (CNTV_CTL_read ())) 0#1))
  (DBGOSLSR_write (Mk_DBGOSLSR_Type (set_slice 28 (← (DBGOSLSR_read ())) 4 0b0000000000000000000000000000#28)))
  (if (cold : Bool)
  then (do (DBGOSLSR_write (_update_DBGOSLSR_Type_OSLK (← (DBGOSLSR_read ())) 1#1)))
  else (do (pure ())))
  (TRFCR_write (Mk_TRFCR_Type (set_slice 25 (← (TRFCR_read ())) 7 0b0000000000000000000000000#25)))
  (TRFCR_write (Mk_TRFCR_Type (set_slice 3 (← (TRFCR_read ())) 2 0b000#3)))
  (TRFCR_write (_update_TRFCR_Type_E1TRE (← (TRFCR_read ())) 0#1))
  (TRFCR_write (_update_TRFCR_Type_E0TRE (← (TRFCR_read ())) 0#1))
  (CNTHP_CTL_write (Mk_CNTHP_CTL_Type (set_slice 29 (← (CNTHP_CTL_read ())) 3 0b00000000000000000000000000000#29)))
  (if ((←((pure (! cold)) <&&> (do
       (__IMPDEF_boolean "the PE resets into EL2 or EL3")))) : Bool)
  then (do (CNTHP_CTL_write (_update_CNTHP_CTL_Type_ENABLE (← (CNTHP_CTL_read ())) 0#1)))
  else (do (CNTHP_CTL_write (_update_CNTHP_CTL_Type_ENABLE (← (CNTHP_CTL_read ())) (← (__UNKNOWN_bits 1))))))
  (CCSIDR_write (Mk_CCSIDR_Type (set_slice 8 (← (CCSIDR_read ())) 24 0b00000000#8)))
  (CCSIDR_write (Mk_CCSIDR_Type (set_slice 4 (← (CCSIDR_read ())) 28 0b0000#4)))
  writeReg DBGDEVID2 (Sail.BitVec.updateSubrange (← readReg DBGDEVID2) 31 0 0b00000000000000000000000000000000#32)
  (ICV_DIR_write (Mk_ICV_DIR_Type (set_slice 8 (← (ICV_DIR_read ())) 24 0b00000000#8)))
  (MPIDR_write (Mk_MPIDR_Type (set_slice 5 (← (MPIDR_read ())) 25 0b00000#5)))
  (DSPSR2_write (Mk_DSPSR2_Type (set_slice 30 (← (DSPSR2_read ())) 2 0b000000000000000000000000000000#30)))
  (DSPSR2_write (Mk_DSPSR2_Type (set_slice 1 (← (DSPSR2_read ())) 0 0#1)))
  (ICC_HPPIR1_write (Mk_ICC_HPPIR1_Type (set_slice 8 (← (ICC_HPPIR1_read ())) 24 0b00000000#8)))
  (ICC_SRE_write (Mk_ICC_SRE_Type (set_slice 29 (← (ICC_SRE_read ())) 3 0b00000000000000000000000000000#29)))
  (ICC_SRE_write (_update_ICC_SRE_Type_DIB (← (ICC_SRE_read ())) 0#1))
  (ICC_SRE_write (_update_ICC_SRE_Type_DFB (← (ICC_SRE_read ())) 0#1))
  (ICC_SRE_write (_update_ICC_SRE_Type_SRE (← (ICC_SRE_read ())) 0#1))
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 31 29 0b000#3)
  (if (cold : Bool)
  then (do writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 28 28 1#1))
  else (do (pure ())))
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 26 24 0b000#3)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 23 23 0#1)
  writeReg SDCR (BitVec.update (← readReg SDCR) 22 (Bit 0#1))
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 21 21 0#1)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 20 20 0#1)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 19 19 0#1)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 18 18 0#1)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 17 17 0#1)
  writeReg SDCR (BitVec.update (← readReg SDCR) 16 (Bit 0#1))
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 15 14 0b00#2)
  writeReg SDCR (Sail.BitVec.updateSubrange (← readReg SDCR) 13 0 0b00000000000000#14)
  (AMUSERENR_write (Mk_AMUSERENR_Type (set_slice 31 (← (AMUSERENR_read ())) 1 0b0000000000000000000000000000000#31)))
  (AMCGCR_write (Mk_AMCGCR_Type (set_slice 16 (← (AMCGCR_read ())) 16 0b0000000000000000#16)))
  (AMCFGR_write (Mk_AMCFGR_Type (set_slice 3 (← (AMCFGR_read ())) 25 0b000#3)))
  (AMCFGR_write (Mk_AMCFGR_Type (set_slice 10 (← (AMCFGR_read ())) 14 0b0000000000#10)))
  (AMCNTENCLR1_write (Mk_AMCNTENCLR1_Type (set_slice 16 (← (AMCNTENCLR1_read ())) 16 0b0000000000000000#16)))
  (if (cold : Bool)
  then (do (AMCNTENCLR1_write (Mk_AMCNTENCLR1_Type (set_slice 16 (← (AMCNTENCLR1_read ())) 0 0b0000000000000000#16))))
  else (do (pure ())))
  (AMCNTENSET0_write (Mk_AMCNTENSET0_Type (set_slice 16 (← (AMCNTENSET0_read ())) 16 0b0000000000000000#16)))
  (AMCNTENSET0_write (Mk_AMCNTENSET0_Type (set_slice 12 (← (AMCNTENSET0_read ())) 4 0b000000000000#12)))
  (if (cold : Bool)
  then (do (AMCNTENSET0_write (Mk_AMCNTENSET0_Type (set_slice 4 (← (AMCNTENSET0_read ())) 0 0b0000#4))))
  else (do (pure ())))
  (AMCNTENCLR0_write (Mk_AMCNTENCLR0_Type (set_slice 16 (← (AMCNTENCLR0_read ())) 16 0b0000000000000000#16)))
  (AMCNTENCLR0_write (Mk_AMCNTENCLR0_Type (set_slice 12 (← (AMCNTENCLR0_read ())) 4 0b000000000000#12)))
  (if (cold : Bool)
  then (do (AMCNTENCLR0_write (Mk_AMCNTENCLR0_Type (set_slice 4 (← (AMCNTENCLR0_read ())) 0 0b0000#4))))
  else (do (pure ())))
  (AMCNTENSET1_write (Mk_AMCNTENSET1_Type (set_slice 16 (← (AMCNTENSET1_read ())) 16 0b0000000000000000#16)))
  (if (cold : Bool)
  then (do (AMCNTENSET1_write (Mk_AMCNTENSET1_Type (set_slice 16 (← (AMCNTENSET1_read ())) 0 0b0000000000000000#16))))
  else (do (pure ())))
  (AMCR_write (Mk_AMCR_Type (set_slice 14 (← (AMCR_read ())) 18 0b00000000000000#14)))
  (AMCR_write (Mk_AMCR_Type (set_slice 6 (← (AMCR_read ())) 11 0b000000#6)))
  (AMCR_write (Mk_AMCR_Type (set_slice 10 (← (AMCR_read ())) 0 0b0000000000#10)))
  (ERRIDR_write (Mk_ERRIDR_Type (set_slice 16 (← (ERRIDR_read ())) 16 0b0000000000000000#16)))
  (ERRSELR_write (Mk_ERRSELR_Type (set_slice 16 (← (ERRSELR_read ())) 16 0b0000000000000000#16)))
  (DISR_write (Mk_DISR_Type (set_slice 19 (← (DISR_read ())) 12 0b0000000000000000000#19)))
  (DISR_write (Mk_DISR_Type (set_slice 3 (← (DISR_read ())) 6 0b000#3)))
  (DISR_write (Mk_DISR_Type (set_slice 15 (← (DISR_read ())) 16 0b000000000000000#15)))
  (DISR_write (Mk_DISR_Type (set_slice 1 (← (DISR_read ())) 13 0#1)))
  (DISR_write (Mk_DISR_Type (set_slice 1 (← (DISR_read ())) 11 0#1)))
  (DISR_write (Mk_DISR_Type (set_slice 5 (← (DISR_read ())) 4 0b00000#5)))
  (DISR_write (Mk_DISR_Type (set_slice 15 (← (DISR_read ())) 16 0b000000000000000#15)))
  (DISR_write (Mk_DISR_Type (set_slice 1 (← (DISR_read ())) 13 0#1)))
  (DISR_write (Mk_DISR_Type (set_slice 2 (← (DISR_read ())) 10 0b00#2)))
  (DISR_write (Mk_DISR_Type (set_slice 3 (← (DISR_read ())) 6 0b000#3)))
  (VDFSR_write (Mk_VDFSR_Type (set_slice 16 (← (VDFSR_read ())) 16 0b0000000000000000#16)))
  (VDFSR_write (Mk_VDFSR_Type (set_slice 1 (← (VDFSR_read ())) 13 0#1)))
  (VDFSR_write (Mk_VDFSR_Type (set_slice 12 (← (VDFSR_read ())) 0 0b000000000000#12)))
  (VDISR_write (Mk_VDISR_Type (set_slice 15 (← (VDISR_read ())) 16 0b000000000000000#15)))
  (VDISR_write (Mk_VDISR_Type (set_slice 1 (← (VDISR_read ())) 13 0#1)))
  (VDISR_write (Mk_VDISR_Type (set_slice 1 (← (VDISR_read ())) 11 0#1)))
  (VDISR_write (Mk_VDISR_Type (set_slice 5 (← (VDISR_read ())) 4 0b00000#5)))
  (VDISR_write (Mk_VDISR_Type (set_slice 15 (← (VDISR_read ())) 16 0b000000000000000#15)))
  (VDISR_write (Mk_VDISR_Type (set_slice 1 (← (VDISR_read ())) 13 0#1)))
  (VDISR_write (Mk_VDISR_Type (set_slice 2 (← (VDISR_read ())) 10 0b00#2)))
  (VDISR_write (Mk_VDISR_Type (set_slice 3 (← (VDISR_read ())) 6 0b000#3)))
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 30 8 0b00000000000000000000000#23)
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 6 6 0#1)
  writeReg GICD_CTLR (BitVec.update (← readReg GICD_CTLR)
    (← do
      (if ((← (__IMPDEF_boolean "access is Secure, in a system that supports two Security states")) : Bool)
      then (do (pure 5))
      else (do (pure 4)))) (Bit 0#1))
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 4 4 0#1)
  writeReg GICD_CTLR (BitVec.update (← readReg GICD_CTLR) 3 (Bit 0#1))
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 30 5 0b00000000000000000000000000#26)
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 3 2 0b00#2)
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 30 9 0b0000000000000000000000#22)
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 8 8 0#1)
  writeReg GICD_CTLR (BitVec.update (← readReg GICD_CTLR) 5 (Bit 0#1))
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 4 4 0#1)
  writeReg GICD_CTLR (Sail.BitVec.updateSubrange (← readReg GICD_CTLR) 3 2 0b00#2)
  writeReg GICC_IAR (Sail.BitVec.updateSubrange (← readReg GICC_IAR) 31 24 0b00000000#8)
  writeReg CTILAR (Sail.BitVec.updateSubrange (← readReg CTILAR) 31 0 0b00000000000000000000000000000000#32)
  writeReg CTIPIDR2 (Sail.BitVec.updateSubrange (← readReg CTIPIDR2) 31 8 0b000000000000000000000000#24)
  writeReg CTICIDR1 (Sail.BitVec.updateSubrange (← readReg CTICIDR1) 31 8 0b000000000000000000000000#24)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 31 8 0b000000000000000000000000#24)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 7 7 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 6 6 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 5 5 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 4 4 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 3 3 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 2 2 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 1 1 0#1)
  writeReg GICH_MISR (Sail.BitVec.updateSubrange (← readReg GICH_MISR) 0 0 0#1)
  writeReg CTIDEVTYPE (Sail.BitVec.updateSubrange (← readReg CTIDEVTYPE) 31 8 0b000000000000000000000000#24)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 31 31 1#1)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 30 9 0b0000000000000000000000#22)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 8 8 0#1)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 3 2 0b00#2)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 1 1 0#1)
  writeReg GITS_CTLR (Sail.BitVec.updateSubrange (← readReg GITS_CTLR) 0 0 0#1)
  writeReg GICR_IIDR (Sail.BitVec.updateSubrange (← readReg GICR_IIDR) 23 20 0b0000#4)
  writeReg EDLSR (Sail.BitVec.updateSubrange (← readReg EDLSR) 31 3 0b00000000000000000000000000000#29)
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_DoPD)))) : Bool)
  then (do writeReg EDLSR (Sail.BitVec.updateSubrange (← readReg EDLSR) 1 1 1#1))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_DoPD))) : Bool)
  then (do writeReg EDLSR (Sail.BitVec.updateSubrange (← readReg EDLSR) 1 1 1#1))
  else (do (pure ())))
  writeReg CTIPIDR1 (Sail.BitVec.updateSubrange (← readReg CTIPIDR1) 31 8 0b000000000000000000000000#24)
  writeReg GICV_IAR (Sail.BitVec.updateSubrange (← readReg GICV_IAR) 31 25 0b0000000#7)
  writeReg CNTSR (Sail.BitVec.updateSubrange (← readReg CNTSR) 31 18 0b00000000000000#14)
  writeReg CNTSR (Sail.BitVec.updateSubrange (← readReg CNTSR) 17 8 0b0000000000#10)
  writeReg CNTSR (Sail.BitVec.updateSubrange (← readReg CNTSR) 7 2 0b000000#6)
  writeReg CNTSR (BitVec.update (← readReg CNTSR) 0 (Bit 0#1))
  writeReg EDCIDR3 (Sail.BitVec.updateSubrange (← readReg EDCIDR3) 31 8 0b000000000000000000000000#24)
  writeReg GICM_SETSPI_NSR (Sail.BitVec.updateSubrange (← readReg GICM_SETSPI_NSR) 31 13 0b0000000000000000000#19)
  writeReg GICR_WAKER (Sail.BitVec.updateSubrange (← readReg GICR_WAKER) 30 3 0b0000000000000000000000000000#28)
  writeReg GICR_WAKER (Sail.BitVec.updateSubrange (← readReg GICR_WAKER) 2 2 1#1)
  writeReg GICR_WAKER (Sail.BitVec.updateSubrange (← readReg GICR_WAKER) 1 1 1#1)
  writeReg GITS_PARTIDR (Sail.BitVec.updateSubrange (← readReg GITS_PARTIDR) 31 24 0b00000000#8)
  writeReg GITS_PARTIDR (Sail.BitVec.updateSubrange (← readReg GITS_PARTIDR) 23 16 0b00000000#8)
  writeReg GITS_PARTIDR (Sail.BitVec.updateSubrange (← readReg GITS_PARTIDR) 15 0 0b0000000000000000#16)
  writeReg GICV_HPPIR (Sail.BitVec.updateSubrange (← readReg GICV_HPPIR) 31 25 0b0000000#7)
  writeReg CTIPIDR0 (Sail.BitVec.updateSubrange (← readReg CTIPIDR0) 31 8 0b000000000000000000000000#24)
  writeReg GICM_SETSPI_SR (Sail.BitVec.updateSubrange (← readReg GICM_SETSPI_SR) 31 13 0b0000000000000000000#19)
  writeReg GICV_DIR (Sail.BitVec.updateSubrange (← readReg GICV_DIR) 31 25 0b0000000#7)
  writeReg CTIDEVID2 (Sail.BitVec.updateSubrange (← readReg CTIDEVID2) 31 0 0b00000000000000000000000000000000#32)
  writeReg EDPIDR3 (Sail.BitVec.updateSubrange (← readReg EDPIDR3) 31 8 0b000000000000000000000000#24)
  writeReg GICC_STATUSR (Sail.BitVec.updateSubrange (← readReg GICC_STATUSR) 31 5 0b000000000000000000000000000#27)
  writeReg GICM_IIDR (Sail.BitVec.updateSubrange (← readReg GICM_IIDR) 23 20 0b0000#4)
  (EDSCR2_write (Mk_EDSCR2_Type (set_slice 28 (← (EDSCR2_read ())) 4 0b0000000000000000000000000000#28)))
  (if (cold : Bool)
  then (do (EDSCR2_write (_update_EDSCR2_Type_EHBWE (← (EDSCR2_read ())) 0#1)))
  else (do (pure ())))
  (EDSCR2_write (Mk_EDSCR2_Type (set_slice 3 (← (EDSCR2_read ())) 0 0b000#3)))
  writeReg GICR_VSGIR (Sail.BitVec.updateSubrange (← readReg GICR_VSGIR) 31 16 0b0000000000000000#16)
  writeReg EDDEVTYPE (Sail.BitVec.updateSubrange (← readReg EDDEVTYPE) 31 8 0b000000000000000000000000#24)
  writeReg CTIDEVCTL (Sail.BitVec.updateSubrange (← readReg CTIDEVCTL) 31 2 0b000000000000000000000000000000#30)
  writeReg CTIDEVCTL (Sail.BitVec.updateSubrange (← readReg CTIDEVCTL) 1 1 0#1)
  writeReg CTIDEVCTL (Sail.BitVec.updateSubrange (← readReg CTIDEVCTL) 0 0 0#1)
  writeReg GICM_TYPER (Sail.BitVec.updateSubrange (← readReg GICM_TYPER) 15 11 0b00000#5)
  writeReg GICD_TYPER2 (Sail.BitVec.updateSubrange (← readReg GICD_TYPER2) 31 9 0b00000000000000000000000#23)
  writeReg GICD_TYPER2 (Sail.BitVec.updateSubrange (← readReg GICD_TYPER2) 6 5 0b00#2)
  writeReg GICH_EISR (Sail.BitVec.updateSubrange (← readReg GICH_EISR) 31 16 0b0000000000000000#16)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 31 16 0b0000000000000000#16)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 15 15 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 14 14 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 13 13 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 12 12 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 11 11 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 10 10 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 9 9 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 8 8 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 7 7 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 6 6 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 5 5 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 4 4 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 3 3 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 2 2 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 1 1 1#1)
  writeReg GICH_ELRSR (Sail.BitVec.updateSubrange (← readReg GICH_ELRSR) 0 0 1#1)
  writeReg GICM_CLRSPI_NSR (Sail.BitVec.updateSubrange (← readReg GICM_CLRSPI_NSR) 31 13 0b0000000000000000000#19)
  writeReg GICV_STATUSR (Sail.BitVec.updateSubrange (← readReg GICV_STATUSR) 31 4 0b0000000000000000000000000000#28)
  writeReg CNTCR (Sail.BitVec.updateSubrange (← readReg CNTCR) 31 18 0b00000000000000#14)
  writeReg CNTCR (Sail.BitVec.updateSubrange (← readReg CNTCR) 17 8 0b0000000000#10)
  writeReg CNTCR (Sail.BitVec.updateSubrange (← readReg CNTCR) 7 3 0b00000#5)
  writeReg CNTCR (Sail.BitVec.updateSubrange (← readReg CNTCR) 0 0 0#1)
  writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 31 4 0b0000000000000000000000000000#28)
  writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 3 3 0#1)
  (if (cold : Bool)
  then (do writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 2 2 0#1))
  else (do (pure ())))
  writeReg EDESR (Sail.BitVec.updateSubrange (← readReg EDESR) 0 0 0#1)
  writeReg EDPIDR1 (Sail.BitVec.updateSubrange (← readReg EDPIDR1) 31 8 0b000000000000000000000000#24)
  writeReg GICM_CLRSPI_SR (Sail.BitVec.updateSubrange (← readReg GICM_CLRSPI_SR) 31 13 0b0000000000000000000#19)
  writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 31 5 0b000000000000000000000000000#27)
  (if (cold : Bool)
  then (do writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 4 4 0#1))
  else (do (pure ())))
  writeReg EDECR (BitVec.update (← readReg EDECR) 3 (Bit 0#1))
  (if ((←((pure cold) <&&> (do
       (IsFeatureImplemented FEAT_DoPD)))) : Bool)
  then (do writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 2 2 0#1))
  else (do (pure ())))
  (if ((! (← (IsFeatureImplemented FEAT_DoPD))) : Bool)
  then (do writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 2 2 0#1))
  else (do (pure ())))
  writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 1 1 0#1)
  writeReg EDECR (Sail.BitVec.updateSubrange (← readReg EDECR) 0 0 0#1)
  (EDECCR_write (Mk_EDECCR_Type (set_slice 9 (← (EDECCR_read ())) 23 0b000000000#9)))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_RLR2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_RLR1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_RLR0 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (EDECCR_write (Mk_EDECCR_Type (set_slice 1 (← (EDECCR_read ())) 19 0#1)))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_RLE2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_RLE1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_NSR2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_NSR1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_NSR0 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SR3 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SR2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SR1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SR0 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_NSE2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_NSE1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SE3 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SE2 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDECCR_write (_update_EDECCR_Type_SE1 (← (EDECCR_read ())) 0#1)))
  else (do (pure ())))
  writeReg GICV_AEOIR (Sail.BitVec.updateSubrange (← readReg GICV_AEOIR) 31 25 0b0000000#7)
  writeReg GICC_PMR (Sail.BitVec.updateSubrange (← readReg GICC_PMR) 31 8 0b000000000000000000000000#24)
  writeReg GICV_ABPR (Sail.BitVec.updateSubrange (← readReg GICV_ABPR) 31 3 0b00000000000000000000000000000#29)
  writeReg GICV_ABPR (Sail.BitVec.updateSubrange (← readReg GICV_ABPR) 2 0 0b000#3)
  writeReg CTILSR (Sail.BitVec.updateSubrange (← readReg CTILSR) 31 3 0b00000000000000000000000000000#29)
  writeReg CTILSR (Sail.BitVec.updateSubrange (← readReg CTILSR) 1 1 1#1)
  writeReg GICR_MPAMIDR (Sail.BitVec.updateSubrange (← readReg GICR_MPAMIDR) 31 24 0b00000000#8)
  writeReg CTICIDR3 (Sail.BitVec.updateSubrange (← readReg CTICIDR3) 31 8 0b000000000000000000000000#24)
  writeReg EDVIDSR (Sail.BitVec.updateSubrange (← readReg EDVIDSR) 27 16 0b000000000000#12)
  writeReg GICC_RPR (Sail.BitVec.updateSubrange (← readReg GICC_RPR) 31 8 0b000000000000000000000000#24)
  writeReg GICV_AIAR (Sail.BitVec.updateSubrange (← readReg GICV_AIAR) 31 25 0b0000000#7)
  writeReg GICV_RPR (Sail.BitVec.updateSubrange (← readReg GICV_RPR) 31 8 0b000000000000000000000000#24)
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_TFO (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_RXfull (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_TXfull (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_RXO (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_TXU (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_INTdis (← (EDSCR_read ())) 0b00#2)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_TDA (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_MA (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_SC2 (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (EDSCR_write (Mk_EDSCR_Type (set_slice 1 (← (EDSCR_read ())) 17 0#1)))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_HDE (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  (if (cold : Bool)
  then (do (EDSCR_write (_update_EDSCR_Type_ERR (← (EDSCR_read ())) 0#1)))
  else (do (pure ())))
  writeReg GICV_AHPPIR (Sail.BitVec.updateSubrange (← readReg GICV_AHPPIR) 31 25 0b0000000#7)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 30 27 0b0000#4)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 26 26 0#1)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 25 25 0#1)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 24 24 0#1)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 23 4 0b00000000000000000000#20)
  writeReg GICR_CTLR (Sail.BitVec.updateSubrange (← readReg GICR_CTLR) 0 0 0#1)
  writeReg CNTEL0ACR (Sail.BitVec.updateSubrange (← readReg CNTEL0ACR) 31 10 0b0000000000000000000000#22)
  writeReg CNTEL0ACR (Sail.BitVec.updateSubrange (← readReg CNTEL0ACR) 7 2 0b000000#6)
  writeReg GICV_BPR (Sail.BitVec.updateSubrange (← readReg GICV_BPR) 31 3 0b00000000000000000000000000000#29)
  writeReg EDDEVID2 (Sail.BitVec.updateSubrange (← readReg EDDEVID2) 31 0 0b00000000000000000000000000000000#32)
  writeReg GICV_EOIR (Sail.BitVec.updateSubrange (← readReg GICV_EOIR) 31 25 0b0000000#7)
  writeReg CTICIDR0 (Sail.BitVec.updateSubrange (← readReg CTICIDR0) 31 8 0b000000000000000000000000#24)
  writeReg GICC_HPPIR (Sail.BitVec.updateSubrange (← readReg GICC_HPPIR) 31 24 0b00000000#8)
  writeReg GICD_CLRSPI_NSR (Sail.BitVec.updateSubrange (← readReg GICD_CLRSPI_NSR) 31 13 0b0000000000000000000#19)
  writeReg CTIITCTRL (Sail.BitVec.updateSubrange (← readReg CTIITCTRL) 31 1 0b0000000000000000000000000000000#31)
  writeReg GITS_STATUSR (Sail.BitVec.updateSubrange (← readReg GITS_STATUSR) 31 10 0b0000000000000000000000#22)
  writeReg GICH_VTR (Sail.BitVec.updateSubrange (← readReg GICH_VTR) 20 5 0b0000000000000000#16)
  writeReg CTIPIDR3 (Sail.BitVec.updateSubrange (← readReg CTIPIDR3) 31 8 0b000000000000000000000000#24)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 31 10 0b0000000000000000000000#22)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
      then (do (pure 10))
      else (do (pure 9)))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 8 7 0b00#2)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 8))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 8))
            else (do (pure 6)))))) (Bit 0#1))
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 7))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 7))
            else (do (pure 5)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 4 1 0b0000#4)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 1))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 1))
            else (do (pure 0)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 31 11 0b000000000000000000000#21)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
      then (do (pure 10))
      else (do (pure 9)))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 9 9 0#1)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 8))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 8))
            else (do (pure 6)))))) (Bit 0#1))
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 7))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 7))
            else (do (pure 5)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 6 6 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 5 5 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 4 4 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 3 3 0#1)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR) 2 (Bit 0#1))
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 1))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 1))
            else (do (pure 0)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 0 0 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 31 10 0b0000000000000000000000#22)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 9 9 0#1)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 8))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 8))
            else (do (pure 6)))))) (Bit 0#1))
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 7))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 7))
            else (do (pure 5)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 6 6 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 5 5 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 4 4 0#1)
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 3 3 0#1)
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR) 2 (Bit 0#1))
  writeReg GICC_CTLR (BitVec.update (← readReg GICC_CTLR)
    (← do
      (if (((_get_GICD_CTLR_Type_DS (← readReg GICD_CTLR)) == 1#1) : Bool)
      then (do (pure 1))
      else
        (do (if ((← (__IMPDEF_boolean "GICD_CTLR.DS==0, Secure access")) : Bool)
            then (do (pure 1))
            else (do (pure 0)))))) (Bit 0#1))
  writeReg GICC_CTLR (Sail.BitVec.updateSubrange (← readReg GICC_CTLR) 0 0 0#1)
  writeReg EDPIDR4 (Sail.BitVec.updateSubrange (← readReg EDPIDR4) 31 8 0b000000000000000000000000#24)
  writeReg CTICONTROL (Sail.BitVec.updateSubrange (← readReg CTICONTROL) 31 1 0b0000000000000000000000000000000#31)
  writeReg CTICONTROL (Sail.BitVec.updateSubrange (← readReg CTICONTROL) 0 0 0#1)
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 31 17 0b000000000000000#15)
  writeReg EDPRSR (BitVec.update (← readReg EDPRSR) 15 (Bit 0#1))
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 13 12 0b00#2)
  (if (cold : Bool)
  then (do writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 10 10 0#1))
  else (do (pure ())))
  (if (cold : Bool)
  then (do writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 8 8 0#1))
  else (do (pure ())))
  writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 3 3 1#1)
  (if (cold : Bool)
  then (do writeReg EDPRSR (Sail.BitVec.updateSubrange (← readReg EDPRSR) 1 1 1#1))
  else (do (pure ())))
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 31 31 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 30 30 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 29 29 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 28 28 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 27 27 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 26 26 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 25 25 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 24 24 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 23 23 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 22 22 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 21 21 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 20 20 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 19 19 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 18 18 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 17 17 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 16 16 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 15 15 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 14 14 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 13 13 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 12 12 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 11 11 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 10 10 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 9 9 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 8 8 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 7 7 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 6 6 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 5 5 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 4 4 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 3 3 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 2 2 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 1 1 0#1)
  writeReg GICR_INMIR0 (Sail.BitVec.updateSubrange (← readReg GICR_INMIR0) 0 0 0#1)
  writeReg GICD_CLRSPI_SR (Sail.BitVec.updateSubrange (← readReg GICD_CLRSPI_SR) 31 13 0b0000000000000000000#19)
  writeReg GICV_CTLR (Sail.BitVec.updateSubrange (← readReg GICV_CTLR) 31 10 0b0000000000000000000000#22)
  writeReg GICV_CTLR (Sail.BitVec.updateSubrange (← readReg GICV_CTLR) 8 5 0b0000#4)
  writeReg GICR_PARTIDR (Sail.BitVec.updateSubrange (← readReg GICR_PARTIDR) 31 24 0b00000000#8)
  writeReg GICR_PARTIDR (Sail.BitVec.updateSubrange (← readReg GICR_PARTIDR) 23 16 0b00000000#8)
  writeReg GICR_PARTIDR (Sail.BitVec.updateSubrange (← readReg GICR_PARTIDR) 15 0 0b0000000000000000#16)
  writeReg EDDEVID1 (Sail.BitVec.updateSubrange (← readReg EDDEVID1) 31 8 0b000000000000000000000000#24)
  writeReg EDPRCR (Sail.BitVec.updateSubrange (← readReg EDPRCR) 31 2 0b000000000000000000000000000000#30)
  writeReg EDPRCR (Sail.BitVec.updateSubrange (← readReg EDPRCR) 31 4 0b0000000000000000000000000000#28)
  writeReg EDPRCR (Sail.BitVec.updateSubrange (← readReg EDPRCR) 3 3 0#1)
  writeReg EDPRCR (BitVec.update (← readReg EDPRCR) 2 (Bit 0#1))
  writeReg GICR_VSGIPENDR (Sail.BitVec.updateSubrange (← readReg GICR_VSGIPENDR) 30 16 0b000000000000000#15)
  writeReg GICD_STATUSR (Sail.BitVec.updateSubrange (← readReg GICD_STATUSR) 31 4 0b0000000000000000000000000000#28)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 31 31 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 30 30 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 29 29 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 28 28 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 27 27 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 26 26 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 25 25 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 24 24 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 23 23 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 22 22 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 21 21 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 20 20 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 19 19 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 18 18 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 17 17 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 16 16 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 15 15 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 14 14 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 13 13 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 12 12 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 11 11 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 10 10 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 9 9 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 8 8 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 7 7 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 6 6 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 5 5 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 4 4 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 3 3 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 2 2 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 1 1 0#1)
  writeReg GICR_ISENABLER0 (Sail.BitVec.updateSubrange (← readReg GICR_ISENABLER0) 0 0 0#1)
  writeReg CTICIDR2 (Sail.BitVec.updateSubrange (← readReg CTICIDR2) 31 8 0b000000000000000000000000#24)
  writeReg EDRCR (Sail.BitVec.updateSubrange (← readReg EDRCR) 31 5 0b000000000000000000000000000#27)
  writeReg EDRCR (Sail.BitVec.updateSubrange (← readReg EDRCR) 1 0 0b00#2)
  writeReg GICV_PMR (Sail.BitVec.updateSubrange (← readReg GICV_PMR) 31 8 0b000000000000000000000000#24)
  writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 31 28 0b0000#4)
  writeReg EDDEVID (Sail.BitVec.updateSubrange (← readReg EDDEVID) 23 8 0b0000000000000000#16)
  writeReg GICC_DIR (Sail.BitVec.updateSubrange (← readReg GICC_DIR) 31 24 0b00000000#8)
  writeReg EDCIDR0 (Sail.BitVec.updateSubrange (← readReg EDCIDR0) 31 8 0b000000000000000000000000#24)
  writeReg GITS_MPAMIDR (Sail.BitVec.updateSubrange (← readReg GITS_MPAMIDR) 31 24 0b00000000#8)
  writeReg GICD_SGIR (Sail.BitVec.updateSubrange (← readReg GICD_SGIR) 31 26 0b000000#6)
  writeReg GICD_SGIR (Sail.BitVec.updateSubrange (← readReg GICD_SGIR) 14 4 0b00000000000#11)
  writeReg GICH_VMCR (Sail.BitVec.updateSubrange (← readReg GICH_VMCR) 17 10 0b00000000#8)
  writeReg GICH_VMCR (Sail.BitVec.updateSubrange (← readReg GICH_VMCR) 8 5 0b0000#4)
  writeReg EDLAR (Sail.BitVec.updateSubrange (← readReg EDLAR) 31 0 0b00000000000000000000000000000000#32)
  writeReg GICC_AEOIR (Sail.BitVec.updateSubrange (← readReg GICC_AEOIR) 31 24 0b00000000#8)
  writeReg GICC_AHPPIR (Sail.BitVec.updateSubrange (← readReg GICC_AHPPIR) 31 24 0b00000000#8)
  writeReg GICR_SYNCR (Sail.BitVec.updateSubrange (← readReg GICR_SYNCR) 31 1 0b0000000000000000000000000000000#31)
  writeReg GICC_ABPR (Sail.BitVec.updateSubrange (← readReg GICC_ABPR) 31 3 0b00000000000000000000000000000#29)
  writeReg CTIPIDR4 (Sail.BitVec.updateSubrange (← readReg CTIPIDR4) 31 8 0b000000000000000000000000#24)
  writeReg CTIDEVID1 (Sail.BitVec.updateSubrange (← readReg CTIDEVID1) 31 0 0b00000000000000000000000000000000#32)
  writeReg GITS_MPIDR (Sail.BitVec.updateSubrange (← readReg GITS_MPIDR) 7 0 0b00000000#8)
  writeReg EDCIDR2 (Sail.BitVec.updateSubrange (← readReg EDCIDR2) 31 8 0b000000000000000000000000#24)
  writeReg GICD_SETSPI_NSR (Sail.BitVec.updateSubrange (← readReg GICD_SETSPI_NSR) 31 13 0b0000000000000000000#19)
  writeReg CNTID (Sail.BitVec.updateSubrange (← readReg CNTID) 31 4 0b0000000000000000000000000000#28)
  writeReg GITS_IIDR (Sail.BitVec.updateSubrange (← readReg GITS_IIDR) 23 20 0b0000#4)
  writeReg EDPIDR0 (Sail.BitVec.updateSubrange (← readReg EDPIDR0) 31 8 0b000000000000000000000000#24)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 31 28 0b0000#4)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 27 24 0b0000#4)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 23 16 0b00000000#8)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 15 12 0b0000#4)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 11 8 0b0000#4)
  writeReg CTIAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg CTIAUTHSTATUS) 7 4 0b0000#4)
  writeReg GICH_HCR (Sail.BitVec.updateSubrange (← readReg GICH_HCR) 26 8 0b0000000000000000000#19)
  writeReg GICC_BPR (Sail.BitVec.updateSubrange (← readReg GICC_BPR) 31 3 0b00000000000000000000000000000#29)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 31 26 0b000000#6)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 23 22 0b00#2)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 15 14 0b00#2)
  writeReg CTIDEVID (Sail.BitVec.updateSubrange (← readReg CTIDEVID) 7 5 0b000#3)
  writeReg GICD_SETSPI_SR (Sail.BitVec.updateSubrange (← readReg GICD_SETSPI_SR) 31 13 0b0000000000000000000#19)
  writeReg GICR_STATUSR (Sail.BitVec.updateSubrange (← readReg GICR_STATUSR) 31 4 0b0000000000000000000000000000#28)
  writeReg GICC_EOIR (Sail.BitVec.updateSubrange (← readReg GICC_EOIR) 31 24 0b00000000#8)
  writeReg EDPIDR2 (Sail.BitVec.updateSubrange (← readReg EDPIDR2) 31 8 0b000000000000000000000000#24)
  writeReg CNTNSAR (Sail.BitVec.updateSubrange (← readReg CNTNSAR) 31 8 0b000000000000000000000000#24)
  writeReg EDITCTRL (Sail.BitVec.updateSubrange (← readReg EDITCTRL) 31 1 0b0000000000000000000000000000000#31)
  writeReg GICD_IIDR (Sail.BitVec.updateSubrange (← readReg GICD_IIDR) 23 20 0b0000#4)
  writeReg EDCIDR1 (Sail.BitVec.updateSubrange (← readReg EDCIDR1) 31 8 0b000000000000000000000000#24)
  writeReg GICC_AIAR (Sail.BitVec.updateSubrange (← readReg GICC_AIAR) 31 24 0b00000000#8)
  writeReg AMPIDR2 (Sail.BitVec.updateSubrange (← readReg AMPIDR2) 31 8 0b000000000000000000000000#24)
  writeReg AMPIDR4 (Sail.BitVec.updateSubrange (← readReg AMPIDR4) 31 8 0b000000000000000000000000#24)
  writeReg AMPIDR3 (Sail.BitVec.updateSubrange (← readReg AMPIDR3) 31 8 0b000000000000000000000000#24)
  writeReg AMCIDR3 (Sail.BitVec.updateSubrange (← readReg AMCIDR3) 31 8 0b000000000000000000000000#24)
  writeReg AMPIDR0 (Sail.BitVec.updateSubrange (← readReg AMPIDR0) 31 8 0b000000000000000000000000#24)
  writeReg AMCIDR2 (Sail.BitVec.updateSubrange (← readReg AMCIDR2) 31 8 0b000000000000000000000000#24)
  writeReg AMCIDR0 (Sail.BitVec.updateSubrange (← readReg AMCIDR0) 31 8 0b000000000000000000000000#24)
  writeReg AMPIDR1 (Sail.BitVec.updateSubrange (← readReg AMPIDR1) 31 8 0b000000000000000000000000#24)
  writeReg AMCIDR1 (Sail.BitVec.updateSubrange (← readReg AMCIDR1) 31 8 0b000000000000000000000000#24)
  writeReg AMDEVTYPE (Sail.BitVec.updateSubrange (← readReg AMDEVTYPE) 31 8 0b000000000000000000000000#24)
  writeReg PMAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg PMAUTHSTATUS) 31 28 0b0000#4)
  writeReg PMAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg PMAUTHSTATUS) 23 16 0b00000000#8)
  writeReg PMAUTHSTATUS (Sail.BitVec.updateSubrange (← readReg PMAUTHSTATUS) 11 8 0b0000#4)
  writeReg PMCGCR0 (Sail.BitVec.updateSubrange (← readReg PMCGCR0) 31 16 0b0000000000000000#16)
  writeReg PMCIDR0 (Sail.BitVec.updateSubrange (← readReg PMCIDR0) 31 8 0b000000000000000000000000#24)
  writeReg PMCIDR1 (Sail.BitVec.updateSubrange (← readReg PMCIDR1) 31 8 0b000000000000000000000000#24)
  writeReg PMCIDR2 (Sail.BitVec.updateSubrange (← readReg PMCIDR2) 31 8 0b000000000000000000000000#24)
  writeReg PMCIDR3 (Sail.BitVec.updateSubrange (← readReg PMCIDR3) 31 8 0b000000000000000000000000#24)
  writeReg PMDEVID (Sail.BitVec.updateSubrange (← readReg PMDEVID) 31 8 0b000000000000000000000000#24)
  writeReg PMDEVTYPE (Sail.BitVec.updateSubrange (← readReg PMDEVTYPE) 31 8 0b000000000000000000000000#24)
  writeReg PMITCTRL (Sail.BitVec.updateSubrange (← readReg PMITCTRL) 31 1 0b0000000000000000000000000000000#31)
  writeReg PMLAR (Sail.BitVec.updateSubrange (← readReg PMLAR) 31 0 0b00000000000000000000000000000000#32)
  writeReg PMLSR (Sail.BitVec.updateSubrange (← readReg PMLSR) 31 3 0b00000000000000000000000000000#29)
  writeReg PMLSR (Sail.BitVec.updateSubrange (← readReg PMLSR) 1 1 1#1)
  writeReg PMPIDR0 (Sail.BitVec.updateSubrange (← readReg PMPIDR0) 31 8 0b000000000000000000000000#24)
  writeReg PMPIDR1 (Sail.BitVec.updateSubrange (← readReg PMPIDR1) 31 8 0b000000000000000000000000#24)
  writeReg PMPIDR2 (Sail.BitVec.updateSubrange (← readReg PMPIDR2) 31 8 0b000000000000000000000000#24)
  writeReg PMPIDR3 (Sail.BitVec.updateSubrange (← readReg PMPIDR3) 31 8 0b000000000000000000000000#24)
  writeReg PMPIDR4 (Sail.BitVec.updateSubrange (← readReg PMPIDR4) 31 8 0b000000000000000000000000#24)
  writeReg PMVIDSR (Sail.BitVec.updateSubrange (← readReg PMVIDSR) 31 16 0b0000000000000000#16)

def undefined_DBGDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_FPSID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_ID_DFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_TLBTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CLIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def CLIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _CLIDR ) : SailM CLIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg CLIDR_EL1) 0 32)))

def CLIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : CLIDR_Type := value_name
  writeReg CLIDR_EL1 (Sail.BitVec.updateSubrange (← readReg CLIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _CLIDR r

def undefined_ID_DFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_DFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_DFR0 ) : SailM ID_DFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_DFR0_EL1) 0 32)))

def ID_DFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_DFR0_Type := value_name
  writeReg ID_DFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_DFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_DFR0 r

def undefined_ID_ISAR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR1 ) : SailM ID_ISAR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR1_EL1) 0 32)))

def ID_ISAR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR1_Type := value_name
  writeReg ID_ISAR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR1 r

def undefined_ID_ISAR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR2 ) : SailM ID_ISAR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR2_EL1) 0 32)))

def ID_ISAR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR2_Type := value_name
  writeReg ID_ISAR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR2 r

def undefined_ID_ISAR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR3_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR3 ) : SailM ID_ISAR3_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR3_EL1) 0 32)))

def ID_ISAR3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR3_Type := value_name
  writeReg ID_ISAR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR3_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR3 r

def undefined_ID_ISAR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR4_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR4 ) : SailM ID_ISAR4_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR4_EL1) 0 32)))

def ID_ISAR4_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR4_Type := value_name
  writeReg ID_ISAR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR4_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR4 r

def undefined_ID_ISAR6_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_ISAR6_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_ISAR6_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_ISAR6 ) : SailM ID_ISAR6_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_ISAR6_EL1) 0 32)))

def ID_ISAR6_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_ISAR6_Type := value_name
  writeReg ID_ISAR6_EL1 (Sail.BitVec.updateSubrange (← readReg ID_ISAR6_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_ISAR6 r

def undefined_ID_MMFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR0 ) : SailM ID_MMFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR0_EL1) 0 32)))

def ID_MMFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR0_Type := value_name
  writeReg ID_MMFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR0 r

def undefined_ID_MMFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR1 ) : SailM ID_MMFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR1_EL1) 0 32)))

def ID_MMFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR1_Type := value_name
  writeReg ID_MMFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR1 r

def undefined_ID_MMFR2_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR2_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR2 ) : SailM ID_MMFR2_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR2_EL1) 0 32)))

def ID_MMFR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR2_Type := value_name
  writeReg ID_MMFR2_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR2_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR2 r

def undefined_ID_MMFR3_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR3_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR3 ) : SailM ID_MMFR3_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR3_EL1) 0 32)))

def ID_MMFR3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR3_Type := value_name
  writeReg ID_MMFR3_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR3_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR3 r

def undefined_ID_MMFR4_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_MMFR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_MMFR4_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_MMFR4 ) : SailM ID_MMFR4_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_MMFR4_EL1) 0 32)))

def ID_MMFR4_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_MMFR4_Type := value_name
  writeReg ID_MMFR4_EL1 (Sail.BitVec.updateSubrange (← readReg ID_MMFR4_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_MMFR4 r

def undefined_ID_PFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR0 ) : SailM ID_PFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR0_EL1) 0 32)))

def ID_PFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR0_Type := value_name
  writeReg ID_PFR0_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR0 r

def undefined_ID_PFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_ID_PFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def ID_PFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _ID_PFR1 ) : SailM ID_PFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg ID_PFR1_EL1) 0 32)))

def ID_PFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : ID_PFR1_Type := value_name
  writeReg ID_PFR1_EL1 (Sail.BitVec.updateSubrange (← readReg ID_PFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _ID_PFR1 r

def undefined_MIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MIDR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MIDR ) : SailM MIDR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MIDR_EL1) 0 32)))

def MIDR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MIDR_Type := value_name
  writeReg MIDR_EL1 (Sail.BitVec.updateSubrange (← readReg MIDR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MIDR r

def undefined_MVFR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR0_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR0 ) : SailM MVFR0_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR0_EL1) 0 32)))

def MVFR0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR0_Type := value_name
  writeReg MVFR0_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR0_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR0 r

def undefined_MVFR1_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_MVFR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def MVFR1_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _MVFR1 ) : SailM MVFR1_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MVFR1_EL1) 0 32)))

def MVFR1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : MVFR1_Type := value_name
  writeReg MVFR1_EL1 (Sail.BitVec.updateSubrange (← readReg MVFR1_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _MVFR1 r

def Mk_CLIDR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_ID_ISAR6_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_NMRR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID0_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID1_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def Mk_PMCEID3_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_NMRR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def NMRR_NS_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _NMRR_NS ) : SailM NMRR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MAIR_EL1) 32 32)))

def NMRR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do (undefined_NMRR_Type ()) ) : SailM NMRR_Type )
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do readReg NMRR_S)
  else (do (NMRR_NS_read ())))

def NMRR_NS_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : NMRR_Type := value_name
  writeReg MAIR_EL1 (Sail.BitVec.updateSubrange (← readReg MAIR_EL1) 63 32 (BitVec.slice r 0 32))
  writeReg _NMRR_NS r

def NMRR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : NMRR_Type := value_name
  (if ((←((ELUsingAArch32 EL3) <&&> (do
       (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure))))) : Bool)
  then (do writeReg NMRR_S r)
  else (do (NMRR_NS_write r)))

def undefined_PMCEID0_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCEID0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID0_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID0_Type := value_name
  writeReg PMCEID0_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID0_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCEID0 r

def undefined_PMCEID1_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_PMCEID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID1_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID1_Type := value_name
  writeReg PMCEID1_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID1_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _PMCEID1 r

def undefined_PMCEID2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID2_Type := value_name
  writeReg PMCEID0_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID0_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _PMCEID2 r

def undefined_PMCEID3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCEID3_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : PMCEID3_Type := value_name
  writeReg PMCEID1_EL0 (Sail.BitVec.updateSubrange (← readReg PMCEID1_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _PMCEID3 r

def _get_ID_DFR0_EL1_Type_CopDbg (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _get_ID_DFR0_Type_CopDbg (v : (BitVec 32)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 3 0)

def _update_CCSIDR_Type_Associativity (v : (BitVec 32)) (x : (BitVec 21)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 3 x)

def _update_CCSIDR_Type_LineSize (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _update_ID_DFR0_Type_CopDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_DFR0_Type_CopSDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_DFR0_Type_CopTrc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_DFR0_Type_MMapDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_DFR0_Type_MMapTrc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_DFR0_Type_MProfDbg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_DFR0_Type_PerfMon (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_DFR0_Type_TraceFilt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_DFR1_Type_MTPMU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR0_Type_BitCount (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR0_Type_BitField (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR0_Type_CmpBranch (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR0_Type_Coproc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR0_Type_Debug (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR0_Type_Divide (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR0_Type_Swap (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR1_Type_Endian (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR1_Type_Except (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR1_Type_Except_AR (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR1_Type_Extend (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR1_Type_IfThen (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR1_Type_Immediate (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR1_Type_Interwork (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR1_Type_Jazelle (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR2_Type_LoadStore (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR2_Type_MemHint (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR2_Type_Mult (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR2_Type_MultS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR2_Type_MultU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR2_Type_MultiAccessInt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR2_Type_PSR_AR (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR2_Type_Reversal (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR3_Type_SIMD (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR3_Type_SVC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR3_Type_Saturate (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR3_Type_SynchPrim (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR3_Type_T32Copy (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR3_Type_T32EE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR3_Type_TabBranch (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR3_Type_TrueNOP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR4_Type_Barrier (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR4_Type_PSR_M (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR4_Type_SMC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR4_Type_SWP_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR4_Type_SynchPrim_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR4_Type_Unpriv (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR4_Type_WithShifts (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR4_Type_Writeback (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR5_Type_AES (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_ISAR5_Type_CRC32 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_ISAR5_Type_RDM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR5_Type_SEVL (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR5_Type_SHA1 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR5_Type_SHA2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_ISAR5_Type_VCMA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_ISAR6_Type_BF16 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_ISAR6_Type_FHM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_ISAR6_Type_I8MM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_ISAR6_Type_JSCVT (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_ISAR6_Type_SPECRES (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR0_Type_AuxReg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR0_Type_FCSE (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR0_Type_InnerShr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR0_Type_OuterShr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR0_Type_PMSA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR0_Type_ShareLvl (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR0_Type_TCM (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR0_Type_VMSA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR1_Type_BPred (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR1_Type_L1Hvd (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR1_Type_L1HvdSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR1_Type_L1HvdVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR1_Type_L1TstCln (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR1_Type_L1Uni (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR1_Type_L1UniSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR1_Type_L1UniVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR2_Type_HWAccFlg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR2_Type_HvdTLB (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR2_Type_L1HvdBG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR2_Type_L1HvdFG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR2_Type_L1HvdRng (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR2_Type_MemBarr (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR2_Type_UniTLB (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_MMFR2_Type_WFIStall (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_BPMaint (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_MMFR3_Type_CMaintSW (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_MMFR3_Type_CMaintVA (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_MMFR3_Type_CMemSz (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_CohWalk (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_MMFR3_Type_MaintBcst (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_MMFR3_Type_Supersec (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_MMFR4_Type_CCIDX (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR5_Type_ETS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR0_Type_AMU (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_PFR0_Type_CSV2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_PFR0_Type_RAS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_PFR0_Type_State0 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR0_Type_State1 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_PFR0_Type_State2 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_PFR0_Type_State3 (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_ID_PFR1_Type_GIC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_ID_PFR1_Type_GenTimer (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_ID_PFR1_Type_MProgMod (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_ID_PFR1_Type_ProgMod (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_ID_PFR1_Type_Sec_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_ID_PFR1_Type_Security (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_ID_PFR1_Type_Virt_frac (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_PFR1_Type_Virtualization (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MIDR_Type_Architecture (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MIDR_Type_Implementer (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 24 x)

def _update_MIDR_Type_PartNum (v : (BitVec 32)) (x : (BitVec 12)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 4 x)

def _update_MIDR_Type_Revision (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MIDR_Type_Variant (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MPIDR_Type_Aff0 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_MPIDR_Type_Aff1 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 8 x)

def _update_MPIDR_Type_Aff2 (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 16 x)

def _update_MVFR0_Type_FPDP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_MVFR0_Type_FPDivide (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MVFR0_Type_FPRound (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_MVFR0_Type_FPSP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR0_Type_FPShVec (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_MVFR0_Type_FPSqrt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MVFR0_Type_FPTrap (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MVFR0_Type_SIMDReg (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MVFR1_Type_FPDNaN (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR1_Type_FPFtZ (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_MVFR1_Type_FPHP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_MVFR1_Type_SIMDFMAC (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 28 x)

def _update_MVFR1_Type_SIMDHP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_MVFR1_Type_SIMDInt (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 12 x)

def _update_MVFR1_Type_SIMDLS (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 8 x)

def _update_MVFR1_Type_SIMDSP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_MVFR2_Type_FPMisc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_MVFR2_Type_SIMDMisc (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_PRRR_Type_DS0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _update_PRRR_Type_DS1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _update_PRRR_Type_NS0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 18 x)

def _update_PRRR_Type_NS1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)


end ArmASL.Functions
