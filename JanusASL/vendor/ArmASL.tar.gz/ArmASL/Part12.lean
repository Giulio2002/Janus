import ArmASL.Part11

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def AArch64_S2InitialTTWState (ss : SecurityState) (walkparams : S2TTWParams) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let ttbr ← (( do (pure (Sail.BitVec.zeroExtend (← (VTTBR_EL2_read ())) 128)) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    match ss with
    | .SS_NonSecure => { tablebase with paspace := PAS_NonSecure }
    | .SS_Realm => { tablebase with paspace := PAS_Realm }
    | _ => tablebase
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S2TTBaseAddress walkparams tablebase.paspace ttbr)) })
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate ← (pure { walkstate with level := (← do (AArch64_S2StartLevel walkparams)) })
  let walkstate : TTWState := { walkstate with istable := true }
  (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2ApplyOutputPerms (descriptor : (BitVec k_N)) (walkparams : S2TTWParams) : SailM Permissions := do
  let bit_index ← (( do (undefined_int ()) ) : SailM Int )
  let permissions ← (( do (undefined_Permissions ()) ) : SailM Permissions )
  let s2pi_index ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
  let permissions ← (( do
    (if ((walkparams.s2pie == 1#1) : Bool)
    then
      (do let s2pi_index ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26764.39-26764.40"
                  (pure (Sail.BitVec.extractLsb descriptor 118 115)))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26767.38-26767.39"
                  (pure ((Sail.BitVec.extractLsb descriptor 54 53) +++ (((BitVec.access descriptor 51) : BitVec 1) +++ ((BitVec.access descriptor 6) : BitVec 1)))))) ) : SailM (BitVec 4) )
          let bit_index := (4 *i (BitVec.toNat s2pi_index))
          let permissions : Permissions := { permissions with s2pi := (Sail.BitVec.extractLsb walkparams.s2pir (bit_index +i 3) bit_index) }
          sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26772.33-26772.34"
          (pure { permissions with s2dirty := ((BitVec.access descriptor 7) : BitVec 1) }))
    else
      (do sail_assert (7 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26775.33-26775.34"
          let permissions : Permissions := { permissions with s2ap := (Sail.BitVec.extractLsb descriptor 7 6) }
          let permissions ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (118 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26778.39-26778.40"
                  (pure { permissions with s2xn := ((BitVec.access descriptor 118) : BitVec 1) }))
            else
              (do sail_assert (54 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26781.38-26781.39"
                  (pure { permissions with s2xn := ((BitVec.access descriptor 54) : BitVec 1) }))) ) : SailM Permissions )
          let permissions ← (( do
            (if ((← (HaveExtendedExecuteNeverExt ())) : Bool)
            then
              (do (if ((walkparams.d128 == 1#1) : Bool)
                  then
                    (do sail_assert (117 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26786.43-26786.44"
                        (pure { permissions with s2xnx := ((BitVec.access descriptor 117) : BitVec 1) }))
                  else
                    (do sail_assert (53 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26789.42-26789.43"
                        (pure { permissions with s2xnx := ((BitVec.access descriptor 53) : BitVec 1) }))))
            else (do (pure { permissions with s2xnx := 0#1 }))) ) : SailM Permissions )
          let desc_dbm ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let desc_dbm ← (( do
            (if ((walkparams.d128 == 1#1) : Bool)
            then
              (do sail_assert (115 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26797.39-26797.40"
                  (pure ((BitVec.access descriptor 115) : BitVec 1)))
            else
              (do sail_assert (51 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26800.38-26800.39"
                  (pure ((BitVec.access descriptor 51) : BitVec 1)))) ) : SailM (BitVec 1) )
          (if ((((walkparams.ha == 1#1) && (walkparams.hd == 1#1)) && (desc_dbm == 1#1)) : Bool)
          then (do (pure { permissions with s2ap := (BitVec.update permissions.s2ap 1 (Bit 1#1)) }))
          else (do (pure permissions))))) ) : SailM Permissions )
  (if ((←((pure (walkparams.s2pie == 1#1)) <&&> (do
       (HaveS2POExt ())) <&&> (do
       (pure ((_get_VTCR_EL2_Type_S2POE (← readReg VTCR_EL2)) == 1#1))))) : Bool)
  then
    (do (if ((walkparams.d128 == 1#1) : Bool)
        then
          (do sail_assert (124 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26810.39-26810.40"
              (pure { permissions with s2po_index := (Sail.BitVec.extractLsb descriptor 124 121) }))
        else
          (do sail_assert (62 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26813.38-26813.39"
              (pure { permissions with s2po_index := (Sail.BitVec.extractLsb descriptor 62 59) }))))
  else (do (pure permissions)))

def AArch64_SS2OutputPASpace (walkparams : S2TTWParams) (ipaspace : PASpace) : PASpace :=
  if ((BEq.beq ipaspace PAS_Secure) : Bool)
  then
    (if (((walkparams.sw +++ walkparams.sa) == 0b00#2) : Bool)
    then PAS_Secure
    else PAS_NonSecure)
  else
    (if (((walkparams.sw +++ (walkparams.sa +++ (walkparams.nsw +++ walkparams.nsa))) == 0b0000#4) : Bool)
    then PAS_Secure
    else PAS_NonSecure)

/-- Type quantifiers: k_N : Nat, 52 < k_N -/
def AArch64_S2NextWalkStateLeaf (currentstate : TTWState) (ss : SecurityState) (walkparams : S2TTWParams) (ipa : AddressDescriptor) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let s2aarch64 ← (( do (undefined_bool ()) ) : SailM Bool )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let baseaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let baseaddress ← (( do
    (if ((BEq.beq ss SS_Secure) : Bool)
    then (do (pure { baseaddress with paspace := (AArch64_SS2OutputPASpace walkparams ipa.paddress.paspace) }))
    else
      (do (if ((BEq.beq ss SS_Realm) : Bool)
          then
            (do let ns ← (( do
                  (if ((walkparams.d128 == 1#1) : Bool)
                  then
                    (do sail_assert (127 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26849.39-26849.40"
                        (pure ((BitVec.access descriptor 127) : BitVec 1)))
                  else
                    (do sail_assert (55 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26852.38-26852.39"
                        (pure ((BitVec.access descriptor 55) : BitVec 1)))) ) : SailM (BitVec 1) )
                (pure { baseaddress with paspace := if ((ns == 1#1) : Bool)
                    then PAS_NonSecure
                    else PAS_Realm }))
          else (do (pure { baseaddress with paspace := PAS_NonSecure }))))) ) : SailM FullAddress )
  let baseaddress ← (pure { baseaddress with address := (← do (AArch64_LeafBase descriptor walkparams.d128 walkparams.ds walkparams.tgx currentstate.level)) })
  let nextstate : TTWState := { nextstate with istable := false }
  let nextstate : TTWState := { nextstate with level := currentstate.level }
  let nextstate : TTWState := { nextstate with baseaddress := baseaddress }
  let nextstate ← (pure { nextstate with permissions := (← do (AArch64_S2ApplyOutputPerms descriptor walkparams)) })
  let s2_attr : (BitVec 4) := (Sail.BitVec.extractLsb descriptor 5 2)
  let s2_sh ← (( do
    (if ((walkparams.ds == 1#1) : Bool)
    then (do (pure walkparams.sh))
    else
      (do sail_assert (9 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26866.33-26866.34"
          (pure (Sail.BitVec.extractLsb descriptor 9 8)))) ) : SailM (BitVec 2) )
  let s2_fnxs : (BitVec 1) := ((BitVec.access descriptor 11) : BitVec 1)
  let nextstate ← (( do
    (if ((walkparams.fwb == 1#1) : Bool)
    then
      (do let nextstate ← (pure { nextstate with memattrs := (← do (AArch64_S2ApplyFWBMemAttrs ipa.memattrs walkparams descriptor)) })
          (if (((Sail.BitVec.extractLsb s2_attr 3 1) == 0b111#3) : Bool)
          then (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 1#1 } }))
          else (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 0#1 } }))))
    else
      (do let s2aarch64 : Bool := true
          let nextstate ← (pure { nextstate with memattrs := (← do (S2DecodeMemAttrs s2_attr s2_sh s2aarch64)) })
          let nextstate : TTWState := { nextstate with memattrs := { nextstate.memattrs with xs := (Complement.complement s2_fnxs) } }
          (if ((s2_attr == 0b0100#4) : Bool)
          then (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 1#1 } }))
          else (do (pure { nextstate with permissions := { nextstate.permissions with s2tag_na := 0#1 } }))))) ) : SailM TTWState )
  let nextstate ← (pure { nextstate with contiguous := (← do (AArch64_ContiguousBit walkparams.tgx walkparams.d128 currentstate.level descriptor)) })
  (if ((walkparams.d128 == 1#1) : Bool)
  then
    (do sail_assert (114 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26889.35-26889.36"
        (pure { nextstate with s2assuredonly := ((BitVec.access descriptor 114) : BitVec 1) }))
  else
    (do (pure { nextstate with s2assuredonly := (← do
            (if ((walkparams.assuredonly == 1#1) : Bool)
            then
              (do sail_assert (58 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26893.38-26893.39"
                  (pure ((BitVec.access descriptor 58) : BitVec 1)))
            else (do (pure 0#1)))) })))

/-- Type quantifiers: k_N : Nat, k_N ≥ 0 -/
def AArch64_S2NextWalkStateTable (currentstate : TTWState) (walkparams : S2TTWParams) (descriptor : (BitVec k_N)) : SailM TTWState := do
  let skl ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let nextstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let tablebase ← (pure { tablebase with address := (← do (AArch64_NextTableBase descriptor walkparams.d128 walkparams.ds walkparams.tgx)) })
  let tablebase : FullAddress := { tablebase with paspace := currentstate.baseaddress.paspace }
  let nextstate : TTWState := { nextstate with istable := true }
  let nextstate ← (( do
    (if ((walkparams.d128 == 1#1) : Bool)
    then
      (do sail_assert (110 <b (Sail.BitVec.length descriptor)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26911.35-26911.36"
          let skl : (BitVec 2) := (Sail.BitVec.extractLsb descriptor 110 109)
          (pure { nextstate with level := ((currentstate.level +i (BitVec.toNat skl)) +i 1) }))
    else (do (pure { nextstate with level := (currentstate.level +i 1) }))) ) : SailM TTWState )
  let nextstate : TTWState := { nextstate with baseaddress := tablebase }
  (pure { nextstate with memattrs := currentstate.memattrs })

def AArch64_S2SLTTEntryAddress (walkparams : S2TTWParams) (ipa : (BitVec 56)) (tablebase : FullAddress) : SailM FullAddress := do
  let startlevel ← (( do (AArch64_S2StartLevel walkparams) ) : SailM Int )
  let iasize := (AArch64_IASize walkparams.txsz)
  let granulebits := (TGxGranuleBits walkparams.tgx)
  let descsizelog2 :=
    if ((walkparams.d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i startlevel)
  let lsb := ((levels *i stride) +i granulebits)
  let msb := (iasize -i 1)
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 56))) "sail-arm/arm-v9.4-a/src/v8_base.sail:26933.61-26933.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26934.60-26934.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ipa msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_SS2InitialTTWState (walkparams : S2TTWParams) (ipaspace : PASpace) : SailM TTWState := do
  let walkstate ← (( do (undefined_TTWState ()) ) : SailM TTWState )
  let tablebase ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let ttbr ← (( do (undefined_bitvector 128) ) : SailM (BitVec 128) )
  let ttbr ← (( do
    (if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then (do (pure (Sail.BitVec.zeroExtend (← readReg VSTTBR_EL2) 128)))
    else (do (pure (Sail.BitVec.zeroExtend (← (VTTBR_EL2_read ())) 128)))) ) : SailM (BitVec 128) )
  let tablebase : FullAddress :=
    if ((BEq.beq ipaspace PAS_Secure) : Bool)
    then
      (if ((walkparams.sw == 0#1) : Bool)
      then { tablebase with paspace := PAS_Secure }
      else { tablebase with paspace := PAS_NonSecure })
    else
      (if ((walkparams.nsw == 0#1) : Bool)
      then { tablebase with paspace := PAS_Secure }
      else { tablebase with paspace := PAS_NonSecure })
  let tablebase ← (pure { tablebase with address := (← do (AArch64_S2TTBaseAddress walkparams tablebase.paspace ttbr)) })
  let walkstate : TTWState := { walkstate with baseaddress := tablebase }
  let walkstate ← (pure { walkstate with level := (← do (AArch64_S2StartLevel walkparams)) })
  let walkstate : TTWState := { walkstate with istable := true }
  (pure { walkstate with memattrs := (← do (WalkMemAttrs walkparams.sh walkparams.irgn walkparams.orgn)) })

/-- Type quantifiers: level : Int -/
def AArch64_TTEntryAddress (level : Int) (d128 : (BitVec 1)) (skl : (BitVec 2)) (tgx : TGx) (txsz : (BitVec 6)) (ia : (BitVec 64)) (tablebase : FullAddress) : SailM FullAddress := do
  let iasize := (AArch64_IASize txsz)
  let granulebits := (TGxGranuleBits tgx)
  let descsizelog2 :=
    if ((d128 == 1#1) : Bool)
    then 4
    else 3
  let stride := (granulebits -i descsizelog2)
  let levels := (FINAL_LEVEL -i level)
  let msb ← (( do (undefined_int ()) ) : SailM Int )
  let lsb := ((levels *i stride) +i granulebits)
  let msb : Int :=
    if ((d128 == 1#1) : Bool)
    then ((lsb +i (stride *i (1 +i (BitVec.toNat skl)))) -i 1)
    else ((lsb +i stride) -i 1)
  let msb := msb
  sail_assert ((0 ≤b lsb) && ((lsb ≤b msb) && (msb <b 64))) "sail-arm/arm-v9.4-a/src/v8_base.sail:26991.61-26991.62"
  sail_assert (56 ≥b (((msb -i lsb) +i 1) +i descsizelog2)) "sail-arm/arm-v9.4-a/src/v8_base.sail:26992.60-26992.61"
  let index : (BitVec 56) := (Sail.BitVec.zeroExtend ((Sail.BitVec.extractLsb ia msb lsb) +++ (Zeros (n := descsizelog2))) 56)
  let descaddress ← (( do (undefined_FullAddress ()) ) : SailM FullAddress )
  let descaddress : FullAddress := { descaddress with address := (tablebase.address ||| index) }
  (pure { descaddress with paspace := tablebase.paspace })

def AArch64_TTWalkMECID (emec : (BitVec 1)) (regime : Regime) (ss : SecurityState) : SailM (BitVec 16) := do
  (if ((emec == 0#1) : Bool)
  then (do (pure DEFAULT_MECID))
  else
    (do (if ((bne ss SS_Realm) : Bool)
        then (do (pure DEFAULT_MECID))
        else
          (do match regime with
              | .Regime_EL2 => (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2)))
              | .Regime_EL20 =>
                (do
                  (if (((_get_TCR_EL2_Type_A1 (← readReg TCR_EL2)) == 0#1) : Bool)
                  then (do (pure (_get_MECID_P1_EL2_Type_MECID (← readReg MECID_P1_EL2))))
                  else (do (pure (_get_MECID_P0_EL2_Type_MECID (← readReg MECID_P0_EL2))))))
              | .Regime_EL10 => (pure (_get_VMECID_P_EL2_Type_MECID (← readReg VMECID_P_EL2)))
              | _ =>
                (do
                  (Unreachable ())
                  (undefined_bitvector 16))))))

def S2TLBCache (tlbrecord : TLBRecord) : Unit :=
  ()

def S2TLBLookup (tlbcontext : TLBContext) : SailM TLBLine := do
  (__UNKNOWN_TLBLine ())

/-- Type quantifiers: N : Nat, List.elem N [32, 64, 128] -/
def AArch64_S2Walk (fault_in : FaultRecord) (ipa : AddressDescriptor) (walkparams : S2TTWParams) (accdesc : AccessDescriptor) (s1level : (Option Int)) (N : Nat) : SailM (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) := SailME.run do
  let fault : FaultRecord := fault_in
  let ipa_64 : (BitVec 64) := (Sail.BitVec.zeroExtend ipa.paddress.address 64)
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBContext )
  let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
  let (fault, tlbcontext, tlbrecord) ← (( do
    (if ((← readReg __tlb_enabled) : Bool)
    then
      (do let tlbcontext ← (AArch64_GetS2TLBContext accdesc.ss ipa.paddress walkparams.tgx)
          let tlbentry ← (( do (S2TLBLookup tlbcontext) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBLine )
          let tlbrecord : TLBRecord := tlbentry.tlbrecord
          let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx tlbrecord.walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
          let (fault, tlbrecord) ← (( do
            (if (((←((pure tlbentry.valid_name) <&&> (do
                   (pure (! (← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx))))))) && (! ((((((walkparams.ha +++ walkparams.hd) == 0b11#2) && ((walkparams.s2pie == 1#1) || (((BitVec.access tlbrecord.s2descriptor 51) : BitVec 1) == 1#1))) && (((BitVec.access tlbrecord.s2descriptor 7) : BitVec 1) == 0#1)) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))))) : Bool)
            then
              (do let a__11020 ← (( do
                    let tlbrecord ← (( do
                      (if ((walkparams.fwb == 1#1) : Bool)
                      then
                        (do let tlbrecord ← (pure { tlbrecord with walkstate := (← do (pure { tlbrecord.walkstate with memattrs := (← do (AArch64_S2ApplyFWBMemAttrs ipa.memattrs walkparams tlbrecord.s2descriptor)) })) })
                            (if (((Sail.BitVec.extractLsb tlbrecord.s2descriptor 5 3) == 0b111#3) : Bool)
                            then (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 1#1 } } }))
                            else (do (pure { tlbrecord with walkstate := { tlbrecord.walkstate with permissions := { tlbrecord.walkstate.permissions with s2tag_na := 0#1 } } }))))
                      else (do (pure tlbrecord))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                    let fault : FaultRecord := { fault with level := tlbrecord.walkstate.level }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), tlbrecord.walkstate, (Sail.BitVec.extractLsb tlbrecord.s2descriptor (N -i 1) 0))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                  SailME.throw a__11020)
            else (do (pure (fault, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBRecord) )
          (pure (fault, tlbcontext, tlbrecord)))
    else (do (pure (fault, tlbcontext, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBContext × TLBRecord) )
  let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let walkstate ← (( do
    (if ((BEq.beq accdesc.ss SS_Secure) : Bool)
    then (do (AArch64_SS2InitialTTWState walkparams ipa.paddress.paspace))
    else (do (AArch64_S2InitialTTWState accdesc.ss walkparams))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
  let startlevel := walkstate.level
  let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
  let walkaccess ← (( do (CreateAccDescS2TTW accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
  let walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let skl : (BitVec 2) := 0b00#2
  let walkaddress : AddressDescriptor := { walkaddress with vaddress := ipa.vaddress }
  let walkaddress ← (pure { walkaddress with mecid := (← do (AArch64_TTWalkMECID walkparams.emec Regime_EL10 accdesc.ss)) })
  let walkaddress ← (( do
    (if (((_get_HCR_EL2_Type_CD (← readReg HCR_EL2)) == 1#1) : Bool)
    then
      (do let walkaddress ← (pure { walkaddress with memattrs := (← do (NormalNCMemAttr ())) })
          (pure { walkaddress with memattrs := { walkaddress.memattrs with xs := walkstate.memattrs.xs } }))
    else (do (pure { walkaddress with memattrs := walkstate.memattrs }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
  let walkaddress : AddressDescriptor := { walkaddress with memattrs := { walkaddress.memattrs with shareability := (EffectiveShareability walkaddress.memattrs) } }
  let walkaddress : AddressDescriptor := { walkaddress with tlbcontext := tlbcontext }
  let desctype ← (( do (undefined_DescriptorType ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) DescriptorType )
  let descaddress ← (( do (AArch64_S2SLTTEntryAddress walkparams ipa.paddress.address walkstate.baseaddress) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
  (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
        let fault : FaultRecord := { fault with level := 0 }
        (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
  else
    (do let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) ← (( do
          let mut loop_vars := (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate)
          repeat
            let (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) := loop_vars
            loop_vars ← do
              let fault : FaultRecord := { fault with level := walkstate.level }
              let walkaddress : AddressDescriptor := { walkaddress with paddress := descaddress }
              let translation_info ← (( do
                (pure { regime := Regime_EL10
                        vmid := (← do
                          (pure (some (← (VMID_read ())))))
                        asid := none
                        va := walkaddress.vaddress
                        s1level := s1level
                        s2info := (some (ipa_64, walkstate.level))
                        s1params := none
                        s2params := (some walkparams)
                        memattrs := walkaddress.memattrs }) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TranslationInfo )
              let (descriptor, fault) ← (( do
                let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee walkaddress walkaccess fault N translation_info)
                let fault : FaultRecord := tup__0
                let descriptor : (BitVec N) := tup__1
                (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
              let (descaddress, descriptor, desctype, fault, skl, walkstate) ← (( do
                (if ((bne fault.statuscode Fault_None) : Bool)
                then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                else
                  (do let new_descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                      let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) ← (( do
                        let mut loop_vars_1 := (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate)
                        repeat
                          let (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) := loop_vars_1
                          loop_vars_1 ← do
                            let new_descriptor : (BitVec N) := descriptor
                            let desctype ← (AArch64_DecodeDescriptorType descriptor walkparams.d128 walkparams.ds walkparams.tgx walkstate.level)
                            let (descaddress, fault, new_descriptor, skl, walkstate) ← (( do
                              match desctype with
                              | .DescriptorType_Table =>
                                (do
                                  let walkstate ← (AArch64_S2NextWalkStateTable walkstate walkparams descriptor)
                                  let skl ←
                                    (if ((walkparams.d128 == 1#1) : Bool)
                                    then
                                      (do sail_assert (110 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27115.49-27115.50"
                                          (pure (Sail.BitVec.extractLsb descriptor 110 109)))
                                    else (do (pure 0b00#2)))
                                  let descaddress ← (AArch64_TTEntryAddress walkstate.level walkparams.d128 skl walkparams.tgx walkparams.txsz ipa_64 walkstate.baseaddress)
                                  let (fault, new_descriptor) ← (( do
                                    (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                    then
                                      (do let a__11017 ← (( do
                                            let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
                                            (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                          SailME.throw a__11017)
                                    else
                                      (do let new_descriptor : (BitVec N) :=
                                            if ((walkparams.haft == 1#1) : Bool)
                                            then (BitVec.update new_descriptor 10 (Bit 1#1))
                                            else new_descriptor
                                          let fault ← (( do
                                            (if ((←((pure ((walkparams.d128 == 1#1) && (skl != 0b00#2))) <&&> (do
                                                 (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                                            then
                                              (do let a__11018 ← (( do
                                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                  SailME.throw a__11018)
                                            else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                                          (pure (fault, new_descriptor)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × (BitVec N)) )
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Leaf =>
                                (do
                                  sail_assert (52 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27133.44-27133.45"
                                  let walkstate ← (AArch64_S2NextWalkStateLeaf walkstate accdesc.ss walkparams ipa descriptor)
                                  (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                              | .DescriptorType_Invalid =>
                                (do
                                  let a__11019 ← (( do
                                    let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                  SailME.throw a__11019) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                            let (descriptor, fault) ← (( do
                              (if ((new_descriptor != descriptor) : Bool)
                              then
                                (do let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                                    sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27146.50-27146.51"
                                    let (descriptor, fault) ← (( do
                                      let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_descriptor walkparams.ee descaccess walkaddress translation_info)
                                      let fault : FaultRecord := tup__0
                                      let descriptor : (BitVec N) := tup__1
                                      (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                                    (if ((bne fault.statuscode Fault_None) : Bool)
                                    then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                    else (do (pure ())))
                                    (pure (descriptor, fault)))
                              else (do (pure (descriptor, fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                            (pure (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate))
                        until (λ (descaddress, descriptor, desctype, fault, new_descriptor, skl, walkstate) => (new_descriptor == descriptor)) loop_vars_1
                        (pure loop_vars_1) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                      (pure (descaddress, descriptor, desctype, fault, skl, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × TTWState) )
              (pure (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate))
          until (λ (descaddress, descriptor, desctype, fault, skl, walkaddress, walkstate) => (BEq.beq desctype DescriptorType_Leaf)) loop_vars
          (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec 2) × AddressDescriptor × TTWState) )
        let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
        let fault ← (( do
          (if ((←((pure (walkstate.contiguous == 1#1)) <&&> (do
               (AArch64_ContiguousBitFaults walkparams.d128 walkparams.txsz walkparams.tgx walkstate.level)))) : Bool)
          then (do (pure { fault with statuscode := Fault_Translation }))
          else
            (do (if ((←((pure ((BEq.beq desctype DescriptorType_Leaf) && (walkstate.level <b FINAL_LEVEL))) <&&> (do
                     (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                then (do (pure { fault with statuscode := Fault_Translation }))
                else
                  (do (if ((← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                      then (do (pure { fault with statuscode := Fault_AddressSize }))
                      else
                        (do (if ((←((pure ((((BitVec.access descriptor 10) : BitVec 1) == 0#1) && (walkparams.ha == 0#1))) <&&> (do
                                 (pure (! (←((pure ((BEq.beq accdesc.acctype AccessType_DC) || (BEq.beq accdesc.acctype AccessType_IC))) <&&> (do (pure (! (← (__IMPDEF_boolean "Generate access flag fault on IC/DC operations")))))))))))) : Bool)
                            then (do (pure { fault with statuscode := Fault_AccessFlag }))
                            else (do (pure fault))))))))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
        (if ((((← readReg __tlb_enabled) && (BEq.beq fault.statuscode Fault_None)) && (((BitVec.access descriptor 10) : BitVec 1) == 1#1)) : Bool)
        then
          (do let tlbcontext : TLBContext := { tlbcontext with xs := walkstate.memattrs.xs }
              let tlbcontext : TLBContext := { tlbcontext with level := walkstate.level }
              let tlbcontext : TLBContext := { tlbcontext with isd128 := (walkparams.d128 == 1#1) }
              let tlbrecord : TLBRecord := { tlbrecord with context := tlbcontext }
              let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
              let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
              let tlbrecord ← (( do
                (if ((walkparams.d128 == 1#1) : Bool)
                then
                  (do sail_assert (127 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27174.39-27174.40"
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.extractLsb descriptor 127 0) }))
                else
                  (do sail_assert (63 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27177.38-27177.39"
                      let tlbrecord : TLBRecord := { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 63 0 (Sail.BitVec.extractLsb descriptor 63 0)) }
                      (pure { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 127 64 (Zeros (n := 64))) }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              let tlbrecord ← (( do
                (if ((walkstate.contiguous == 1#1) : Bool)
                then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                else (do (pure { tlbrecord with contigsize := 0 }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
              (pure (S2TLBCache tlbrecord)))
        else (do (pure ())))
        (pure (fault, walkaddress, walkstate, descriptor))))

def AArch64_SettingAccessFlagPermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if (((BEq.beq fault.statuscode Fault_Alignment) || (BEq.beq fault.statuscode Fault_Permission)) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_AFUPDATE))
        else (do (pure false)))))

def AArch64_SettingDirtyStatePermitted (fault : FaultRecord) : SailM Bool := do
  (if ((BEq.beq fault.statuscode Fault_None) : Bool)
  then (do (pure true))
  else
    (do (if ((BEq.beq fault.statuscode Fault_Alignment) : Bool)
        then (do (ConstrainUnpredictableBool Unpredictable_DBUPDATE))
        else (do (pure false)))))

/-- Type quantifiers: k_aligned : Bool, k_s1aarch64 : Bool -/
def AArch64_S2Translate (fault_in : FaultRecord) (ipa : AddressDescriptor) (s1aarch64 : Bool) (s1level : (Option Int)) (aligned : Bool) (accdesc : AccessDescriptor) : SailM (FaultRecord × AddressDescriptor) := SailME.run do
  let walkparams ← (( do (AArch64_GetS2TTWParams accdesc.ss ipa.paddress.paspace s1aarch64) ) : SailME (FaultRecord × AddressDescriptor) S2TTWParams )
  let fault : FaultRecord := fault_in
  let s2fs1mro ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let fault : FaultRecord := { fault with statuscode := Fault_None }
  let fault : FaultRecord := { fault with secondstage := true }
  let fault : FaultRecord := { fault with s2fs1walk := (BEq.beq accdesc.acctype AccessType_TTW) }
  let fault : FaultRecord := { fault with ipaddress := ipa.paddress }
  (if ((walkparams.vm != 1#1) : Bool)
  then (do (pure (fault, ipa)))
  else
    (do let s2mintxsz ← (( do (AArch64_S2MinTxSZ walkparams.d128 walkparams.ds walkparams.tgx s1aarch64) ) : SailME (FaultRecord × AddressDescriptor) Int )
        let s2maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        (if ((← (AArch64_S2TxSZFaults walkparams s1aarch64)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
        else
          (do let walkparams : S2TTWParams :=
                if (((BitVec.toNat walkparams.txsz) <b s2mintxsz) : Bool)
                then { walkparams with txsz := (integer_subrange s2mintxsz 5 0) }
                else
                  (if (((BitVec.toNat walkparams.txsz) >b s2maxtxsz) : Bool)
                  then { walkparams with txsz := (integer_subrange s2maxtxsz 5 0) }
                  else walkparams)
              (if ((←((pure (walkparams.d128 == 0#1)) <&&> (do
                   (AArch64_S2InvalidSL walkparams) <||> (do
                     (AArch64_S2InconsistentSL walkparams))))) : Bool)
              then
                (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                    let fault : FaultRecord := { fault with level := 0 }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
              else
                (do (if ((AArch64_IPAIsOutOfRange ipa.paddress.address walkparams) : Bool)
                    then
                      (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                          let fault : FaultRecord := { fault with level := 0 }
                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                    else
                      (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                          let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor) TTWState )
                          let descriptor ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let new_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let mem_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                          let (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) ← (( do
                            let mut loop_vars := (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate)
                            repeat
                              let (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) := loop_vars
                              loop_vars ← do
                                let (descpaddr, descriptor, fault, walkstate) ← (( do
                                  (if ((walkparams.d128 == 1#1) : Bool)
                                  then
                                    (do let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S2Walk fault ipa walkparams accdesc s1level 128)
                                        let fault : FaultRecord := tup__0
                                        let descpaddr : AddressDescriptor := tup__1
                                        let walkstate : TTWState := tup__2
                                        let descriptor : (BitVec 128) := tup__3
                                        (pure (descpaddr, descriptor, fault, walkstate)))
                                  else
                                    (do let (descpaddr, descriptor, fault, walkstate) ← (( do
                                          let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S2Walk fault ipa walkparams accdesc s1level 64)
                                          let fault : FaultRecord := tup__0
                                          let descpaddr : AddressDescriptor := tup__1
                                          let walkstate : TTWState := tup__2
                                          let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 63 0 tup__3)
                                          (pure (descpaddr, descriptor, fault, walkstate)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                        let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 127 64 (Zeros (n := 64)))
                                        (pure (descpaddr, descriptor, fault, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                let (fault, mem_desc, new_desc, s2fs1mro) ← (( do
                                  (if ((bne fault.statuscode Fault_None) : Bool)
                                  then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                  else
                                    (do let fault ← (( do
                                          (if ((← (AArch64_S2HasAlignmentFault accdesc aligned walkstate.memattrs)) : Bool)
                                          then (do (pure { fault with statuscode := Fault_Alignment }))
                                          else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                        let (fault, s2fs1mro) ← (( do
                                          (if ((BEq.beq fault.statuscode Fault_None) : Bool)
                                          then
                                            (do let (tup__0, tup__1) ← do (AArch64_S2CheckPermissions fault walkstate walkparams ipa accdesc)
                                                let fault : FaultRecord := tup__0
                                                let s2fs1mro : Bool := tup__1
                                                (pure (fault, s2fs1mro)))
                                          else (do (pure (fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × Bool) )
                                        let new_desc : (BitVec 128) := descriptor
                                        let new_desc ← (( do
                                          (if ((←((pure (walkparams.ha == 1#1)) <&&> (do
                                               (AArch64_SettingAccessFlagPermitted fault)))) : Bool)
                                          then (do (pure (BitVec.update new_desc 10 (Bit 1#1))))
                                          else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                        let new_desc ← (( do
                                          (if (((((((← (AArch64_SettingDirtyStatePermitted fault)) && (walkparams.ha == 1#1)) && (walkparams.hd == 1#1)) && ((walkparams.s2pie == 1#1) || (((BitVec.access descriptor 51) : BitVec 1) == 1#1))) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))) : Bool)
                                          then (do (pure (BitVec.update new_desc 7 (Bit 1#1))))
                                          else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                        let (fault, mem_desc) ← (( do
                                          (if ((new_desc != descriptor) : Bool)
                                          then
                                            (do let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor) AccessDescriptor )
                                                let translation_info ← (( do
                                                  (pure { regime := Regime_EL10
                                                          vmid := (← do
                                                            (pure (some (← (VMID_read ())))))
                                                          asid := none
                                                          va := ipa.vaddress
                                                          s1level := s1level
                                                          s2info := (some ((Sail.BitVec.zeroExtend ipa.paddress.address 64), walkstate.level))
                                                          s1params := none
                                                          s2params := (some walkparams)
                                                          memattrs := walkstate.memattrs }) ) : SailME (FaultRecord × AddressDescriptor) TranslationInfo )
                                                let (fault, mem_desc) ← (( do
                                                  (if ((walkparams.d128 == 1#1) : Bool)
                                                  then
                                                    (do let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_desc walkparams.ee descaccess descpaddr translation_info)
                                                        let fault : FaultRecord := tup__0
                                                        let mem_desc : (BitVec 128) := tup__1
                                                        (pure (fault, mem_desc)))
                                                  else
                                                    (do let (fault, mem_desc) ← (( do
                                                          let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault (Sail.BitVec.extractLsb descriptor 63 0) (Sail.BitVec.extractLsb new_desc 63 0) walkparams.ee descaccess descpaddr translation_info)
                                                          let fault : FaultRecord := tup__0
                                                          let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 63 0 tup__1)
                                                          (pure (fault, mem_desc)) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                        let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 127 64 (Zeros (n := 64)))
                                                        (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                (pure (fault, mem_desc)))
                                          else (do (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                        (pure (fault, mem_desc, new_desc, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128) × (BitVec 128) × Bool) )
                                (pure (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate))
                            until (λ (descpaddr, descriptor, fault, mem_desc, new_desc, s2fs1mro, walkstate) => ((new_desc == descriptor) || (mem_desc == new_desc))) loop_vars
                            (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × TTWState) )
                          (if ((((← readReg __tlb_enabled) && (new_desc != descriptor)) && (((BitVec.access mem_desc 10) : BitVec 1) == 1#1)) : Bool)
                          then
                            (do let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                let tlbrecord ← (( do
                                  (if ((((BitVec.access descriptor 10) : BitVec 1) == 1#1) : Bool)
                                  then
                                    (do let tlbentry ← (( do (S2TLBLookup descpaddr.tlbcontext) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
                                        sail_assert tlbentry.valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:27304.38-27304.39"
                                        (pure tlbentry.tlbrecord))
                                  else
                                    (do let tlbrecord : TLBRecord := { tlbrecord with context := descpaddr.tlbcontext }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with xs := walkstate.memattrs.xs } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with level := walkstate.level } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with includes_s2_name := true } }
                                        let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with isd128 := (walkparams.d128 == 1#1) } }
                                        let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                                        let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                                        (if ((walkstate.contiguous == 1#1) : Bool)
                                        then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                                        else (do (pure { tlbrecord with contigsize := 0 }))))) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                let tlbrecord : TLBRecord :=
                                  if ((walkparams.d128 == 1#1) : Bool)
                                  then { tlbrecord with s2descriptor := mem_desc }
                                  else
                                    (let tlbrecord : TLBRecord := { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 63 0 (Sail.BitVec.extractLsb mem_desc 63 0)) }
                                    { tlbrecord with s2descriptor := (Sail.BitVec.updateSubrange tlbrecord.s2descriptor 127 64 (Zeros (n := 64))) })
                                (pure (S2TLBCache tlbrecord)))
                          else (do (pure ())))
                          (if ((bne fault.statuscode Fault_None) : Bool)
                          then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                          else
                            (do let ipa_64 : (BitVec 64) := (Sail.BitVec.zeroExtend ipa.paddress.address 64)
                                let oa ← (( do (StageOA ipa_64 walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor) FullAddress )
                                let s2_memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let s2_memattrs ← (( do
                                  (if ((←((pure (((BEq.beq accdesc.acctype AccessType_TTW) && (BEq.beq walkstate.memattrs.memtype MemType_Device)) && (walkparams.ptw == 0#1))) <||> (do
                                       (pure (BEq.beq accdesc.acctype AccessType_IFETCH)) <&&> (do
                                         (pure (BEq.beq walkstate.memattrs.memtype MemType_Device)) <||> (do
                                           (pure ((_get_HCR_EL2_Type_ID (← readReg HCR_EL2)) == 1#1))))) <||> (do
                                       (pure ((bne accdesc.acctype AccessType_IFETCH) && (BEq.beq walkstate.memattrs.memtype MemType_Normal))) <&&> (do
                                         (pure ((_get_HCR_EL2_Type_CD (← readReg HCR_EL2)) == 1#1)))))) : Bool)
                                  then
                                    (do let s2_memattrs ← (NormalNCMemAttr ())
                                        (pure { s2_memattrs with xs := walkstate.memattrs.xs }))
                                  else (do (pure walkstate.memattrs))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let fault ← (( do
                                  (if ((accdesc.ls64 && (BEq.beq s2_memattrs.memtype MemType_Normal)) : Bool)
                                  then
                                    (do (if (((s2_memattrs.inner.attrs != MemAttr_NC) || (s2_memattrs.outer.attrs != MemAttr_NC)) : Bool)
                                        then
                                          (do let a__11011 ← (( do
                                                let fault : FaultRecord := { fault with statuscode := Fault_Exclusive }
                                                (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × AddressDescriptor) )
                                              SailME.throw a__11011)
                                        else (do (pure fault))))
                                  else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                let s2aarch64 : Bool := true
                                let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let memattrs ← (( do
                                  (if ((walkparams.fwb == 0#1) : Bool)
                                  then (do (S2CombineS1MemAttrs ipa.memattrs s2_memattrs s2aarch64))
                                  else (do (pure s2_memattrs))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                let pa ← (( do (CreateAddressDescriptor ipa.vaddress oa memattrs) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                let pa : AddressDescriptor := { pa with tlbcontext := descpaddr.tlbcontext }
                                let pa : AddressDescriptor := { pa with s2fs1mro := s2fs1mro }
                                let pa ← (pure { pa with mecid := (← do (AArch64_S2OutputMECID walkparams pa.paddress.paspace descriptor)) })
                                (pure (fault, pa))))))))))))

def S1TLBCache (tlbrecord : TLBRecord) : Unit :=
  ()

def S1TLBLookup (tlbcontext : TLBContext) : SailM TLBLine := do
  (__UNKNOWN_TLBLine ())

/-- Type quantifiers: N : Nat, 10 < N -/
def AArch64_S1Walk (fault_in : FaultRecord) (walkparams : S1TTWParams) (va : (BitVec 64)) (regime : Regime) (accdesc : AccessDescriptor) (N : Nat) : SailM (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) := SailME.run do
  let fault : FaultRecord := fault_in
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) Bool )
  let aligned ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) Bool )
  let tlbcontext ← (( do (undefined_TLBContext ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBContext )
  let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
  let (fault, tlbcontext, tlbrecord) ← (( do
    (if ((← readReg __tlb_enabled) : Bool)
    then
      (do let tlbcontext ← (AArch64_GetS1TLBContext regime accdesc.ss va walkparams.tgx)
          let tlbentry ← (( do (S1TLBLookup tlbcontext) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBLine )
          let tlbrecord : TLBRecord := tlbentry.tlbrecord
          let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx tlbrecord.walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
          let fault ← (( do
            (if (((←((pure tlbentry.valid_name) <&&> (do
                   (pure (! (← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx))))))) && (! ((((((walkparams.ha +++ walkparams.hd) == 0b11#2) && ((walkparams.pie == 1#1) || (((BitVec.access tlbrecord.s1descriptor 51) : BitVec 1) == 1#1))) && (((BitVec.access tlbrecord.s1descriptor 7) : BitVec 1) == 1#1)) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))))) : Bool)
            then
              (do let a__11005 ← (( do
                    let fault : FaultRecord := { fault with level := tlbrecord.walkstate.level }
                    sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27381.59-27381.60"
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), tlbrecord.walkstate, (Sail.BitVec.extractLsb tlbrecord.s1descriptor (N -i 1) 0))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                  SailME.throw a__11005)
            else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
          (pure (fault, tlbcontext, tlbrecord)))
    else (do (pure (fault, tlbcontext, tlbrecord)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × TLBContext × TLBRecord) )
  (if ((←((pure (HasUnprivileged regime)) <&&> (do
       (pure ((← (AArch64_S1EPD regime va)) == 1#1))))) : Bool)
  then
    (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
        let fault : FaultRecord := { fault with level := 0 }
        (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
  else
    (do let walkstate ← (( do (AArch64_S1InitialTTWState walkparams va regime accdesc.ss) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TTWState )
        let startlevel := walkstate.level
        let descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
        let walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let skl : (BitVec 2) := 0b00#2
        let walkaddress : AddressDescriptor := { walkaddress with vaddress := va }
        let walkaddress ← (pure { walkaddress with mecid := (← do (AArch64_TTWalkMECID walkparams.emec regime accdesc.ss)) })
        let walkaddress ← (( do
          (if ((! (← (AArch64_S1DCacheEnabled regime))) : Bool)
          then
            (do let walkaddress ← (pure { walkaddress with memattrs := (← do (NormalNCMemAttr ())) })
                (pure { walkaddress with memattrs := { walkaddress.memattrs with xs := walkstate.memattrs.xs } }))
          else (do (pure { walkaddress with memattrs := walkstate.memattrs }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let walkaddress ← (( do
          (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))) <&&> (do
               (pure (! (← (__IMPDEF_boolean "Apply effective shareability at stage 1"))))))) : Bool)
          then (do (pure { walkaddress with memattrs := { walkaddress.memattrs with shareability := walkstate.memattrs.shareability } }))
          else (do (pure { walkaddress with memattrs := { walkaddress.memattrs with shareability := (EffectiveShareability walkaddress.memattrs) } }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
        let walkaddress : AddressDescriptor := { walkaddress with tlbcontext := tlbcontext }
        let s2fs1mro : Bool := false
        let desctype ← (( do (undefined_DescriptorType ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) DescriptorType )
        let descaddress ← (( do (AArch64_S1SLTTEntryAddress walkstate.level walkparams va walkstate.baseaddress) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
        (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
        else
          (do let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) ← (( do
                let mut loop_vars := (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate)
                repeat
                  let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) := loop_vars
                  loop_vars ← do
                    let fault : FaultRecord := { fault with level := walkstate.level }
                    let walkaddress : AddressDescriptor := { walkaddress with paddress := descaddress }
                    let toplevel : Bool := (walkstate.level == startlevel)
                    let varange : VARange := (AArch64_GetVARange va)
                    let walkaccess ← (( do (CreateAccDescS1TTW toplevel varange accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                    let translation_info : TranslationInfo :=
                      { regime := regime
                        vmid := none
                        asid := none
                        va := walkaddress.vaddress
                        s1level := (some walkstate.level)
                        s2info := none
                        s1params := (some walkparams)
                        s2params := none
                        memattrs := walkaddress.memattrs }
                    let s2fault ← (( do (undefined_FaultRecord ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                    let s2walkaddress ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
                    let (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro) ← (( do
                      (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                           (EL2Enabled ())))) : Bool)
                      then
                        (do let s1aarch64 : Bool := true
                            let aligned : Bool := true
                            let (s2fault, s2walkaddress) ← (( do
                              let (tup__0, tup__1) ← do (AArch64_S2Translate fault walkaddress s1aarch64 (some walkstate.level) aligned walkaccess)
                              let s2fault : FaultRecord := tup__0
                              let s2walkaddress : AddressDescriptor := tup__1
                              (pure (s2fault, s2walkaddress)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor) )
                            let (descriptor, fault, s2fs1mro) ← (( do
                              (if ((bne s2fault.statuscode Fault_None) : Bool)
                              then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                              else
                                (do let s2fs1mro : Bool := s2walkaddress.s2fs1mro
                                    sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27445.50-27445.51"
                                    let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee s2walkaddress walkaccess fault N translation_info)
                                    let fault : FaultRecord := tup__0
                                    let descriptor : (BitVec N) := tup__1
                                    (pure (descriptor, fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord × Bool) )
                            (pure (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro)))
                      else
                        (do sail_assert (((N == 32) || (N == 64)) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27448.50-27448.51"
                            let (tup__0, tup__1) ← do (FetchDescriptor walkparams.ee walkaddress walkaccess fault N translation_info)
                            let fault : FaultRecord := tup__0
                            let descriptor : (BitVec N) := tup__1
                            (pure (aligned, descriptor, fault, s1aarch64, s2fault, s2fs1mro)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × (BitVec N) × FaultRecord × Bool × FaultRecord × Bool) )
                    let (aligned, descaddress, descriptor, desctype, fault, s1aarch64, skl, walkstate) ← (( do
                      (if ((bne fault.statuscode Fault_None) : Bool)
                      then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                      else
                        (do let new_descriptor ← (( do (undefined_bitvector N) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                            let (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) ← (( do
                              let mut loop_vars_1 := (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate)
                              repeat
                                let (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) := loop_vars_1
                                loop_vars_1 ← do
                                  let new_descriptor : (BitVec N) := descriptor
                                  let desctype ← (AArch64_DecodeDescriptorType descriptor walkparams.d128 walkparams.ds walkparams.tgx walkstate.level)
                                  let (descaddress, fault, new_descriptor, skl, walkstate) ← (( do
                                    match desctype with
                                    | .DescriptorType_Table =>
                                      (do
                                        let walkstate ← (AArch64_S1NextWalkStateTable walkstate s2fs1mro regime walkparams descriptor)
                                        let skl ←
                                          (if ((walkparams.d128 == 1#1) : Bool)
                                          then
                                            (do sail_assert (110 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27462.49-27462.50"
                                                (pure (Sail.BitVec.extractLsb descriptor 110 109)))
                                          else (do (pure 0b00#2)))
                                        let descaddress ← (AArch64_TTEntryAddress walkstate.level walkparams.d128 skl walkparams.tgx walkparams.txsz va walkstate.baseaddress)
                                        let (fault, new_descriptor) ← (( do
                                          (if ((← (AArch64_OAOutOfRange descaddress.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                          then
                                            (do let a__11002 ← (( do
                                                  let fault : FaultRecord := { fault with statuscode := Fault_AddressSize }
                                                  (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                SailME.throw a__11002)
                                          else
                                            (do let new_descriptor ← (( do
                                                  (if ((walkparams.haft == 1#1) : Bool)
                                                  then
                                                    (do sail_assert (10 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27471.48-27471.49"
                                                        (pure (BitVec.update new_descriptor 10 (Bit 1#1))))
                                                  else (do (pure new_descriptor))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (BitVec N) )
                                                let fault ← (( do
                                                  (if ((←((pure ((walkparams.d128 == 1#1) && (skl != 0b00#2))) <&&> (do
                                                       (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                                                  then
                                                    (do let a__11003 ← (( do
                                                          let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                                        SailME.throw a__11003)
                                                  else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
                                                (pure (fault, new_descriptor)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × (BitVec N)) )
                                        (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                                    | .DescriptorType_Leaf =>
                                      (do
                                        let walkstate ← (AArch64_S1NextWalkStateLeaf walkstate s2fs1mro regime accdesc.ss walkparams descriptor)
                                        (pure (descaddress, fault, new_descriptor, skl, walkstate)))
                                    | .DescriptorType_Invalid =>
                                      (do
                                        let a__11004 ← (( do
                                          let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) )
                                        SailME.throw a__11004) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (FullAddress × FaultRecord × (BitVec N) × (BitVec 2) × TTWState) )
                                  let (aligned, descriptor, fault, s1aarch64, s2fault) ← (( do
                                    (if ((new_descriptor != descriptor) : Bool)
                                    then
                                      (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AddressDescriptor )
                                          let descaccess ← (( do (CreateAccDescTTEUpdate accdesc) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) AccessDescriptor )
                                          let (aligned, descpaddr, s1aarch64, s2fault) ← (( do
                                            (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                 (EL2Enabled ())))) : Bool)
                                            then
                                              (do let s1aarch64 : Bool := true
                                                  let aligned : Bool := true
                                                  let (descpaddr, s2fault) ← (( do
                                                    let (tup__0, tup__1) ← do (AArch64_S2Translate fault walkaddress s1aarch64 (some walkstate.level) aligned descaccess)
                                                    let s2fault : FaultRecord := tup__0
                                                    let descpaddr : AddressDescriptor := tup__1
                                                    (pure (descpaddr, s2fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (AddressDescriptor × FaultRecord) )
                                                  (if ((bne s2fault.statuscode Fault_None) : Bool)
                                                  then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                                  else (do (pure ())))
                                                  (pure (aligned, descpaddr, s1aarch64, s2fault)))
                                            else
                                              (do let descpaddr : AddressDescriptor := walkaddress
                                                  (pure (aligned, descpaddr, s1aarch64, s2fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × AddressDescriptor × Bool × FaultRecord) )
                                          sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27505.50-27505.51"
                                          let (descriptor, fault) ← (( do
                                            let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_descriptor walkparams.ee descaccess descpaddr translation_info)
                                            let fault : FaultRecord := tup__0
                                            let descriptor : (BitVec N) := tup__1
                                            (pure (descriptor, fault)) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) ((BitVec N) × FaultRecord) )
                                          (if ((bne fault.statuscode Fault_None) : Bool)
                                          then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N))))))
                                          else (do (pure ())))
                                          (pure (aligned, descriptor, fault, s1aarch64, s2fault)))
                                    else (do (pure (aligned, descriptor, fault, s1aarch64, s2fault)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × (BitVec N) × FaultRecord × Bool × FaultRecord) )
                                  (pure (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate))
                              until (λ (aligned, descaddress, descriptor, desctype, fault, new_descriptor, s1aarch64, s2fault, skl, walkstate) => (new_descriptor == descriptor)) loop_vars_1
                              (pure loop_vars_1) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × (BitVec N) × Bool × FaultRecord × (BitVec 2) × TTWState) )
                            (pure (aligned, descaddress, descriptor, desctype, fault, s1aarch64, skl, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × Bool × (BitVec 2) × TTWState) )
                    (pure (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate))
                until (λ (aligned, descaddress, descriptor, desctype, fault, s1aarch64, s2fs1mro, skl, walkaddress, walkstate) => (BEq.beq desctype DescriptorType_Leaf)) loop_vars
                (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) (Bool × FullAddress × (BitVec N) × DescriptorType × FaultRecord × Bool × Bool × (BitVec 2) × AddressDescriptor × TTWState) )
              let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FullAddress )
              let fault ← (( do
                (if ((←((pure (walkstate.contiguous == 1#1)) <&&> (do
                     (AArch64_ContiguousBitFaults walkparams.d128 walkparams.txsz walkparams.tgx walkstate.level)))) : Bool)
                then (do (pure { fault with statuscode := Fault_Translation }))
                else
                  (do (if ((←((pure ((BEq.beq desctype DescriptorType_Leaf) && (walkstate.level <b FINAL_LEVEL))) <&&> (do
                           (AArch64_BlocknTFaults walkparams.d128 descriptor)))) : Bool)
                      then (do (pure { fault with statuscode := Fault_Translation }))
                      else
                        (do sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27521.42-27521.43"
                            (if ((← (AArch64_S1AMECFault walkparams walkstate.baseaddress.paspace regime descriptor)) : Bool)
                            then (do (pure { fault with statuscode := Fault_Translation }))
                            else
                              (do (if ((← (AArch64_OAOutOfRange oa.address walkparams.d128 walkparams.ps walkparams.tgx)) : Bool)
                                  then (do (pure { fault with statuscode := Fault_AddressSize }))
                                  else
                                    (do (if ((←((pure ((((BitVec.access descriptor 10) : BitVec 1) == 0#1) && (walkparams.ha == 0#1))) <&&> (do
                                             (pure (! (←((pure ((BEq.beq accdesc.acctype AccessType_DC) || (BEq.beq accdesc.acctype AccessType_IC))) <&&> (do (pure (! (← (__IMPDEF_boolean "Generate access flag fault on IC/DC operations")))))))))))) : Bool)
                                        then (do (pure { fault with statuscode := Fault_AccessFlag }))
                                        else (do (pure fault))))))))))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) FaultRecord )
              (if ((bne fault.statuscode Fault_None) : Bool)
              then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())), (← (__UNKNOWN_TTWState ())), (← (__UNKNOWN_bits N)))))
              else
                (do (if ((((← readReg __tlb_enabled) && (BEq.beq fault.statuscode Fault_None)) && (((BitVec.access descriptor 10) : BitVec 1) == 1#1)) : Bool)
                    then
                      (do let tlbcontext : TLBContext := { tlbcontext with xs := walkstate.memattrs.xs }
                          let tlbcontext : TLBContext := { tlbcontext with level := walkstate.level }
                          let tlbcontext : TLBContext := { tlbcontext with nG := walkstate.nG }
                          let tlbcontext : TLBContext := { tlbcontext with isd128 := (walkparams.d128 == 1#1) }
                          let tlbrecord : TLBRecord := { tlbrecord with context := tlbcontext }
                          let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                          let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                          let tlbrecord ← (( do
                            (if ((walkparams.d128 == 1#1) : Bool)
                            then
                              (do sail_assert (127 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27542.39-27542.40"
                                  (pure { tlbrecord with s1descriptor := (Sail.BitVec.extractLsb descriptor 127 0) }))
                            else
                              (do sail_assert (63 <b N) "sail-arm/arm-v9.4-a/src/v8_base.sail:27545.38-27545.39"
                                  let tlbrecord : TLBRecord := { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 63 0 (Sail.BitVec.extractLsb descriptor 63 0)) }
                                  (pure { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 127 64 (Zeros (n := 64))) }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                          let tlbrecord ← (( do
                            (if ((walkstate.contiguous == 1#1) : Bool)
                            then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                            else (do (pure { tlbrecord with contigsize := 0 }))) ) : SailME (FaultRecord × AddressDescriptor × TTWState × (BitVec N)) TLBRecord )
                          (pure (S1TLBCache tlbrecord)))
                    else (do (pure ())))
                    (pure (fault, walkaddress, walkstate, descriptor))))))))

def AArch64_VAIsOutOfRange (va_in : (BitVec 64)) (acctype : AccessType) (regime : Regime) (walkparams : S1TTWParams) : Bool :=
  let va : (BitVec 64) := va_in
  let addrtop := (AArch64_AddrTop walkparams.tbid acctype walkparams.tbi)
  let va : (BitVec 64) :=
    if ((walkparams.mtx == 1#1) : Bool)
    then
      (Sail.BitVec.updateSubrange va 59 56
        (if ((BEq.beq (AArch64_GetVARange va) VARange_UPPER) : Bool)
        then 0b1111#4
        else 0b0000#4))
    else va
  let iasize := (AArch64_IASize walkparams.txsz)
  if ((addrtop <b iasize) : Bool)
  then false
  else
    (if ((HasUnprivileged regime) : Bool)
    then
      (if ((BEq.beq (AArch64_GetVARange va) VARange_LOWER) : Bool)
      then (! (is_zero_subrange va addrtop iasize))
      else (! (is_ones_subrange va addrtop iasize)))
    else (! (is_zero_subrange va addrtop iasize)))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_S1Translate (fault_in : FaultRecord) (regime : Regime) (va : (BitVec 64)) (aligned : Bool) (accdesc : AccessDescriptor) : SailM (FaultRecord × AddressDescriptor) := SailME.run do
  let descaccess ← (( do (undefined_AccessDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AccessDescriptor )
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let s2aligned ← (( do (undefined_bool ()) ) : SailME (FaultRecord × AddressDescriptor) Bool )
  let tlbentry ← (( do (undefined_TLBLine ()) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
  let fault : FaultRecord := fault_in
  let fault : FaultRecord := { fault with secondstage := false }
  let fault : FaultRecord := { fault with s2fs1walk := false }
  (if ((! (← (AArch64_S1Enabled regime accdesc.acctype))) : Bool)
  then (do (AArch64_S1DisabledOutput fault regime va accdesc aligned))
  else
    (do let walkparams ← (( do (AArch64_GetS1TTWParams regime accdesc.ss va) ) : SailME (FaultRecord × AddressDescriptor) S1TTWParams )
        let s1mintxsz ← (( do (AArch64_S1MinTxSZ regime walkparams.d128 walkparams.ds walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        let s1maxtxsz ← (( do (AArch64_MaxTxSZ walkparams.tgx) ) : SailME (FaultRecord × AddressDescriptor) Int )
        (if ((← (AArch64_S1TxSZFaults regime walkparams)) : Bool)
        then
          (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
              let fault : FaultRecord := { fault with level := 0 }
              (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
        else
          (do let walkparams : S1TTWParams :=
                if (((BitVec.toNat walkparams.txsz) <b s1mintxsz) : Bool)
                then { walkparams with txsz := (integer_subrange s1mintxsz 5 0) }
                else
                  (if (((BitVec.toNat walkparams.txsz) >b s1maxtxsz) : Bool)
                  then { walkparams with txsz := (integer_subrange s1maxtxsz 5 0) }
                  else walkparams)
              (if ((AArch64_VAIsOutOfRange va accdesc.acctype regime walkparams) : Bool)
              then
                (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                    let fault : FaultRecord := { fault with level := 0 }
                    (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
              else
                (do (if (((accdesc.el == EL0) && (walkparams.e0pd == 1#1)) : Bool)
                    then
                      (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                          let fault : FaultRecord := { fault with level := 0 }
                          (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                    else
                      (do (if (((((← (HaveTME ())) && (accdesc.el == EL0)) && (walkparams.nfd == 1#1)) && accdesc.transactional) : Bool)
                          then
                            (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                let fault : FaultRecord := { fault with level := 0 }
                                (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                          else
                            (do (if (((((← (HaveSVE ())) && (accdesc.el == EL0)) && (walkparams.nfd == 1#1)) && ((accdesc.nonfault && accdesc.contiguous) || ((accdesc.firstfault && (! accdesc.first)) && (! accdesc.contiguous)))) : Bool)
                                then
                                  (do let fault : FaultRecord := { fault with statuscode := Fault_Translation }
                                      let fault : FaultRecord := { fault with level := 0 }
                                      (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                                else
                                  (do let descipaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                      let walkstate ← (( do (undefined_TTWState ()) ) : SailME (FaultRecord × AddressDescriptor) TTWState )
                                      let descriptor ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let new_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let mem_desc ← (( do (undefined_bitvector 128) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                      let (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) ← (( do
                                        let mut loop_vars := (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate)
                                        repeat
                                          let (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) := loop_vars
                                          loop_vars ← do
                                            let (descipaddr, descriptor, fault, walkstate) ← (( do
                                              (if ((walkparams.d128 == 1#1) : Bool)
                                              then
                                                (do let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S1Walk fault walkparams va regime accdesc 128)
                                                    let fault : FaultRecord := tup__0
                                                    let descipaddr : AddressDescriptor := tup__1
                                                    let walkstate : TTWState := tup__2
                                                    let descriptor : (BitVec 128) := tup__3
                                                    (pure (descipaddr, descriptor, fault, walkstate)))
                                              else
                                                (do let (descipaddr, descriptor, fault, walkstate) ← (( do
                                                      let (tup__0, tup__1, tup__2, tup__3) ← do (AArch64_S1Walk fault walkparams va regime accdesc 64)
                                                      let fault : FaultRecord := tup__0
                                                      let descipaddr : AddressDescriptor := tup__1
                                                      let walkstate : TTWState := tup__2
                                                      let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 63 0 tup__3)
                                                      (pure (descipaddr, descriptor, fault, walkstate)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                                    let descriptor : (BitVec 128) := (Sail.BitVec.updateSubrange descriptor 127 64 (Zeros (n := 64)))
                                                    (pure (descipaddr, descriptor, fault, walkstate)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × (BitVec 128) × FaultRecord × TTWState) )
                                            let (descaccess, fault, mem_desc, new_desc, s1aarch64, s2aligned) ← (( do
                                              (if ((bne fault.statuscode Fault_None) : Bool)
                                              then (do SailME.throw (← do (pure (fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                              else
                                                (do (if ((BEq.beq accdesc.acctype AccessType_IFETCH) : Bool)
                                                    then (do (SetInGuardedPage (walkstate.guardedpage == 1#1)))
                                                    else (do (pure ())))
                                                    let fault ← (( do
                                                      (if ((← (AArch64_S1HasAlignmentFault accdesc aligned walkparams.ntlsmd walkstate.memattrs)) : Bool)
                                                      then (do (pure { fault with statuscode := Fault_Alignment }))
                                                      else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                    let fault ← (( do
                                                      (if ((BEq.beq fault.statuscode Fault_None) : Bool)
                                                      then (do (AArch64_S1CheckPermissions fault regime walkstate walkparams accdesc))
                                                      else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                    let new_desc : (BitVec 128) := descriptor
                                                    let new_desc ← (( do
                                                      (if ((←((pure (walkparams.ha == 1#1)) <&&> (do
                                                           (AArch64_SettingAccessFlagPermitted fault)))) : Bool)
                                                      then (do (pure (BitVec.update new_desc 10 (Bit 1#1))))
                                                      else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                                    let new_desc ← (( do
                                                      (if (((((((← (AArch64_SettingDirtyStatePermitted fault)) && (walkparams.ha == 1#1)) && (walkparams.hd == 1#1)) && ((walkparams.pie == 1#1) || (((BitVec.access descriptor 51) : BitVec 1) == 1#1))) && accdesc.write) && (! ((BEq.beq accdesc.acctype AccessType_AT) || ((BEq.beq accdesc.acctype AccessType_IC) || (BEq.beq accdesc.acctype AccessType_DC))))) : Bool)
                                                      then (do (pure (BitVec.update new_desc 7 (Bit 0#1))))
                                                      else (do (pure new_desc))) ) : SailME (FaultRecord × AddressDescriptor) (BitVec 128) )
                                                    let (descaccess, fault, mem_desc, s1aarch64, s2aligned) ← (( do
                                                      (if ((new_desc != descriptor) : Bool)
                                                      then
                                                        (do let descpaddr ← (( do (undefined_AddressDescriptor ()) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                                            let descaccess ← (CreateAccDescTTEUpdate accdesc)
                                                            let (descpaddr, s1aarch64, s2aligned) ← (( do
                                                              (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                                   (EL2Enabled ())))) : Bool)
                                                              then
                                                                (do let s2fault ← (( do (undefined_FaultRecord ()) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                                                    let s1aarch64 : Bool := true
                                                                    let s2aligned : Bool := true
                                                                    let (descpaddr, s2fault) ← (( do
                                                                      let (tup__0, tup__1) ← do (AArch64_S2Translate fault descipaddr s1aarch64 none s2aligned descaccess)
                                                                      let s2fault : FaultRecord := tup__0
                                                                      let descpaddr : AddressDescriptor := tup__1
                                                                      (pure (descpaddr, s2fault)) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × FaultRecord) )
                                                                    (if ((bne s2fault.statuscode Fault_None) : Bool)
                                                                    then (do SailME.throw (← do (pure (s2fault, (← (__UNKNOWN_AddressDescriptor ()))))))
                                                                    else (do (pure ())))
                                                                    (pure (descpaddr, s1aarch64, s2aligned)))
                                                              else
                                                                (do let descpaddr : AddressDescriptor := descipaddr
                                                                    (pure (descpaddr, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AddressDescriptor × Bool × Bool) )
                                                            let translation_info : TranslationInfo :=
                                                              { regime := regime
                                                                vmid := none
                                                                asid := none
                                                                va := va
                                                                s1level := (some walkstate.level)
                                                                s2info := none
                                                                s1params := (some walkparams)
                                                                s2params := none
                                                                memattrs := walkstate.memattrs }
                                                            let (fault, mem_desc) ← (( do
                                                              (if ((walkparams.d128 == 1#1) : Bool)
                                                              then
                                                                (do let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault descriptor new_desc walkparams.ee descaccess descpaddr translation_info)
                                                                    let fault : FaultRecord := tup__0
                                                                    let mem_desc : (BitVec 128) := tup__1
                                                                    (pure (fault, mem_desc)))
                                                              else
                                                                (do let (fault, mem_desc) ← (( do
                                                                      let (tup__0, tup__1) ← do (AArch64_MemSwapTableDesc fault (Sail.BitVec.extractLsb descriptor 63 0) (Sail.BitVec.extractLsb new_desc 63 0) walkparams.ee descaccess descpaddr translation_info)
                                                                      let fault : FaultRecord := tup__0
                                                                      let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 63 0 tup__1)
                                                                      (pure (fault, mem_desc)) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                                    let mem_desc : (BitVec 128) := (Sail.BitVec.updateSubrange mem_desc 127 64 (Zeros (n := 64)))
                                                                    (pure (fault, mem_desc)))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × (BitVec 128)) )
                                                            (pure (descaccess, fault, mem_desc, s1aarch64, s2aligned)))
                                                      else (do (pure (descaccess, fault, mem_desc, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × FaultRecord × (BitVec 128) × Bool × Bool) )
                                                    (pure (descaccess, fault, mem_desc, new_desc, s1aarch64, s2aligned)))) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × Bool) )
                                            (pure (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate))
                                        until (λ (descaccess, descipaddr, descriptor, fault, mem_desc, new_desc, s1aarch64, s2aligned, walkstate) => ((new_desc == descriptor) || (mem_desc == new_desc))) loop_vars
                                        (pure loop_vars) ) : SailME (FaultRecord × AddressDescriptor) (AccessDescriptor × AddressDescriptor × (BitVec 128) × FaultRecord × (BitVec 128) × (BitVec 128) × Bool × Bool × TTWState) )
                                      (if ((((← readReg __tlb_enabled) && (new_desc != descriptor)) && (((BitVec.access mem_desc 10) : BitVec 1) == 1#1)) : Bool)
                                      then
                                        (do let tlbrecord ← (( do (undefined_TLBRecord ()) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                            let tlbrecord ← (( do
                                              (if ((((BitVec.access descriptor 10) : BitVec 1) == 1#1) : Bool)
                                              then
                                                (do let tlbentry ← (( do (S1TLBLookup descipaddr.tlbcontext) ) : SailME (FaultRecord × AddressDescriptor) TLBLine )
                                                    sail_assert tlbentry.valid_name "sail-arm/arm-v9.4-a/src/v8_base.sail:27700.38-27700.39"
                                                    (pure tlbentry.tlbrecord))
                                              else
                                                (do let tlbrecord : TLBRecord := { tlbrecord with context := descipaddr.tlbcontext }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with xs := walkstate.memattrs.xs } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with level := walkstate.level } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with nG := walkstate.nG } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with context := { tlbrecord.context with isd128 := (walkparams.d128 == 1#1) } }
                                                    let tlbrecord : TLBRecord := { tlbrecord with walkstate := walkstate }
                                                    let tlbrecord : TLBRecord := { tlbrecord with blocksize := (TranslationSize walkparams.d128 walkparams.tgx walkstate.level) }
                                                    (if ((walkstate.contiguous == 1#1) : Bool)
                                                    then (do (pure { tlbrecord with contigsize := (← do (ContiguousSize walkparams.d128 walkparams.tgx walkstate.level)) }))
                                                    else (do (pure { tlbrecord with contigsize := 0 }))))) ) : SailME (FaultRecord × AddressDescriptor) TLBRecord )
                                            let tlbrecord : TLBRecord :=
                                              if ((walkparams.d128 == 1#1) : Bool)
                                              then { tlbrecord with s1descriptor := mem_desc }
                                              else
                                                (let tlbrecord : TLBRecord := { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 63 0 (Sail.BitVec.extractLsb mem_desc 63 0)) }
                                                { tlbrecord with s1descriptor := (Sail.BitVec.updateSubrange tlbrecord.s1descriptor 127 64 (Zeros (n := 64))) })
                                            (pure (S1TLBCache tlbrecord)))
                                      else (do (pure ())))
                                      (if ((bne fault.statuscode Fault_None) : Bool)
                                      then (do (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))))
                                      else
                                        (do let oa ← (( do (StageOA va walkparams.d128 walkparams.tgx walkstate) ) : SailME (FaultRecord × AddressDescriptor) FullAddress )
                                            let memattrs ← (( do (undefined_MemoryAttributes ()) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let memattrs ← (( do
                                              (if ((←((pure (BEq.beq accdesc.acctype AccessType_IFETCH)) <&&> (do
                                                   (pure (BEq.beq walkstate.memattrs.memtype MemType_Device)) <||> (do
                                                     (pure (! (← (AArch64_S1ICacheEnabled regime)))))))) : Bool)
                                              then
                                                (do let memattrs ← (NormalNCMemAttr ())
                                                    (pure { memattrs with xs := walkstate.memattrs.xs }))
                                              else
                                                (do (if (((←((pure (bne accdesc.acctype AccessType_IFETCH)) <&&> (do
                                                           (pure (! (← (AArch64_S1DCacheEnabled regime))))))) && (BEq.beq walkstate.memattrs.memtype MemType_Normal)) : Bool)
                                                    then
                                                      (do let memattrs ← (NormalNCMemAttr ())
                                                          let memattrs : MemoryAttributes := { memattrs with xs := walkstate.memattrs.xs }
                                                          (if ((←((pure ((← (HaveMTE2Ext ())) && (BEq.beq walkstate.memattrs.tags MemTag_AllocationTagged))) <&&> (do
                                                               (pure (! (← (ConstrainUnpredictableBool Unpredictable_S1CTAGGED))))))) : Bool)
                                                          then (do (pure { memattrs with tags := MemTag_Untagged }))
                                                          else (do (pure memattrs))))
                                                    else (do (pure walkstate.memattrs))))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let memattrs ← (( do
                                              (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
                                                   (EL2Enabled ())) <&&> (do
                                                   (pure ((_get_HCR_EL2_Type_VM (← readReg HCR_EL2)) == 1#1))) <&&> (do
                                                   (pure (! (← (__IMPDEF_boolean "Apply effective shareability at stage 1"))))))) : Bool)
                                              then (do (pure { memattrs with shareability := walkstate.memattrs.shareability }))
                                              else (do (pure { memattrs with shareability := (EffectiveShareability memattrs) }))) ) : SailME (FaultRecord × AddressDescriptor) MemoryAttributes )
                                            let fault ← (( do
                                              (if ((accdesc.ls64 && (BEq.beq memattrs.memtype MemType_Normal)) : Bool)
                                              then
                                                (do (if (((memattrs.inner.attrs != MemAttr_NC) || (memattrs.outer.attrs != MemAttr_NC)) : Bool)
                                                    then
                                                      (do let a__10995 ← (( do
                                                            let fault : FaultRecord := { fault with statuscode := Fault_Exclusive }
                                                            (pure (fault, (← (__UNKNOWN_AddressDescriptor ())))) ) : SailME (FaultRecord × AddressDescriptor) (FaultRecord × AddressDescriptor) )
                                                          SailME.throw a__10995)
                                                    else (do (pure fault))))
                                              else (do (pure fault))) ) : SailME (FaultRecord × AddressDescriptor) FaultRecord )
                                            let ipa ← (( do (CreateAddressDescriptor va oa memattrs) ) : SailME (FaultRecord × AddressDescriptor) AddressDescriptor )
                                            let ipa : AddressDescriptor := { ipa with tlbcontext := descipaddr.tlbcontext }
                                            let ipa : AddressDescriptor := { ipa with s1assured := walkstate.s1assured }
                                            let varange : VARange := (AArch64_GetVARange va)
                                            let ipa ← (pure { ipa with mecid := (← do (AArch64_S1OutputMECID walkparams regime varange ipa.paddress.paspace descriptor)) })
                                            (pure (fault, ipa))))))))))))))))

/-- Type quantifiers: k_aligned : Bool -/
def AArch64_FullTranslate (va : (BitVec 64)) (accdesc : AccessDescriptor) (aligned : Bool) : SailM AddressDescriptor := do
  let s1aarch64 ← (( do (undefined_bool ()) ) : SailM Bool )
  let regime ← (( do (TranslationRegime accdesc.el) ) : SailM Regime )
  let fault ← (( do (NoFault__1 accdesc) ) : SailM FaultRecord )
  let ipa ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
  let (fault, ipa) ← (( do
    let (tup__0, tup__1) ← do (AArch64_S1Translate fault regime va aligned accdesc)
    let fault : FaultRecord := tup__0
    let ipa : AddressDescriptor := tup__1
    (pure (fault, ipa)) ) : SailM (FaultRecord × AddressDescriptor) )
  (if ((bne fault.statuscode Fault_None) : Bool)
  then (do (CreateFaultyAddressDescriptor va fault))
  else
    (do sail_assert (implies (BEq.beq accdesc.ss SS_Realm) (← (EL2Enabled ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:27774.54-27774.55"
        (if ((←((pure (BEq.beq regime Regime_EL10)) <&&> (do
             (EL2Enabled ())))) : Bool)
        then
          (do let s1aarch64 : Bool := true
              let pa ← (( do (undefined_AddressDescriptor ()) ) : SailM AddressDescriptor )
              let (fault, pa) ← (( do
                let (tup__0, tup__1) ← do (AArch64_S2Translate fault ipa s1aarch64 none aligned accdesc)
                let fault : FaultRecord := tup__0
                let pa : AddressDescriptor := tup__1
                (pure (fault, pa)) ) : SailM (FaultRecord × AddressDescriptor) )
              (if ((bne fault.statuscode Fault_None) : Bool)
              then (do (CreateFaultyAddressDescriptor va fault))
              else (do (pure pa))))
        else (do (pure ipa)))))

/-- Type quantifiers: counter_index : Nat, 0 ≤ counter_index ∨ (not (counter_index < 32)) -/
def SPEStartCounter (counter_index : Nat) : SailM Unit := do
  sail_assert (counter_index <b SPEMaxCounters) "sail-arm/arm-v9.4-a/src/v8_base.sail:27796.41-27796.42"
  writeReg SPESampleCounterPending (vectorUpdate (← readReg SPESampleCounterPending) counter_index true)

/-- Type quantifiers: counter_index : Nat, 0 ≤ counter_index ∧ counter_index < 32 -/
def SPEStopCounter (counter_index : Nat) : SailM Unit := do
  writeReg SPESampleCounterValid (vectorUpdate (← readReg SPESampleCounterValid) counter_index true)
  writeReg SPESampleCounterPending (vectorUpdate (← readReg SPESampleCounterPending) counter_index false)

def end_translation (desc : AddressDescriptor) : SailM Unit := do
  (sail_translation_end desc)

def start_translation (tsi : TranslationStartInfo) : SailM Unit := do
  (sail_translation_start tsi)

/-- Type quantifiers: k_aligned : Bool, size : Int -/
def AArch64_TranslateAddress (va : (BitVec 64)) (accdesc : AccessDescriptor) (aligned : Bool) (size : Int) : SailM AddressDescriptor := do
  (if (((← readReg SPESampleInFlight) && (! ((BEq.beq accdesc.acctype AccessType_IFETCH) || (BEq.beq accdesc.acctype AccessType_SPE)))) : Bool)
  then (do (SPEStartCounter SPECounterPosTranslationLatency))
  else (do (pure ())))
  let regime ← (( do (TranslationRegime accdesc.el) ) : SailM Regime )
  let tsi ← do (AArch64_GetTranslationStartInfo regime accdesc.ss accdesc va size)
  (start_translation tsi)
  let result ← (( do (AArch64_FullTranslate va accdesc aligned) ) : SailM AddressDescriptor )
  let result ← (( do
    (if (((! (IsFault result)) && (bne accdesc.acctype AccessType_IFETCH)) : Bool)
    then (do (pure { result with fault := (← do (AArch64_CheckDebug va accdesc size)) }))
    else (do (pure result))) ) : SailM AddressDescriptor )
  let result ← (( do
    (if ((←((pure ((← (HaveRME ())) && (! (IsFault result)))) <&&> (do
         (pure (bne accdesc.acctype AccessType_DC)) <||> (do
           (__IMPDEF_boolean "GPC Fault on DC operations"))))) : Bool)
    then
      (do let result ← (pure { result with fault := (← do (pure { result.fault with gpcf := (← do (GranuleProtectionCheck result accdesc)) })) })
          (if ((bne result.fault.gpcf.gpf GPCF_None) : Bool)
          then
            (do let result : AddressDescriptor := { result with fault := { result.fault with statuscode := Fault_GPCFOnOutput } }
                (pure { result with fault := { result.fault with paddress := result.paddress } }))
          else (do (pure result))))
    else (do (pure result))) ) : SailM AddressDescriptor )
  let result ← (( do
    (if (((! (IsFault result)) && (BEq.beq accdesc.acctype AccessType_IFETCH)) : Bool)
    then (do (pure { result with fault := (← do (AArch64_CheckDebug va accdesc size)) }))
    else (do (pure result))) ) : SailM AddressDescriptor )
  (if (((← readReg SPESampleInFlight) && (! ((BEq.beq accdesc.acctype AccessType_IFETCH) || (BEq.beq accdesc.acctype AccessType_SPE)))) : Bool)
  then (do (SPEStopCounter SPECounterPosTranslationLatency))
  else (do (pure ())))
  let result : AddressDescriptor := { result with vaddress := (Sail.BitVec.zeroExtend va 64) }
  (end_translation result)
  (pure result)

def MemHasTransactionalAccess (memattrs : MemoryAttributes) : SailM Bool := do
  (if ((((((((((BEq.beq memattrs.shareability Shareability_ISH) || (BEq.beq memattrs.shareability Shareability_OSH)) && (BEq.beq memattrs.memtype MemType_Normal)) && (memattrs.inner.attrs == MemAttr_WB)) && (memattrs.inner.hints == MemHint_RWA)) && (memattrs.inner.transient == false)) && (memattrs.outer.hints == MemHint_RWA)) && (memattrs.outer.attrs == MemAttr_WB)) && (memattrs.outer.transient == false)) : Bool)
  then (do (pure true))
  else (do (__IMPDEF_boolean "Memory Region does not support Transactional access")))

def CollectPhysicalAddress (_ : Unit) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (StatisticalProfilingEnabled ()))) : Bool)
  then (do (pure false))
  else
    (do let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        (if ((←((pure (HaveEL EL2)) <&&> (do
             (pure (bne owning_ss SS_Secure)) <||> (do
               (IsSecureEL2Enabled ()))))) : Bool)
        then (do (pure ((_get_PMSCR_EL2_Type_PA (← readReg PMSCR_EL2)) == 1#1)) <&&> (do (pure (owning_el == EL2)) <||> (do (pure ((_get_PMSCR_EL1_Type_PA (← readReg PMSCR_EL1)) == 1#1)))))
        else (do (pure ((_get_PMSCR_EL1_Type_PA (← readReg PMSCR_EL1)) == 1#1))))))

def SPESetDataPhysicalAddress (addrdesc : AddressDescriptor) (accdesc : AccessDescriptor) : SailM Unit := do
  let ns ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let nse ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let (ns, nse) ← (( do
    match addrdesc.paddress.paspace with
    | .PAS_Secure =>
      (let ns : (BitVec 1) := 0#1
      let nse : (BitVec 1) := 0#1
      (pure (ns, nse)))
    | .PAS_NonSecure =>
      (let ns : (BitVec 1) := 1#1
      let nse : (BitVec 1) := 0#1
      (pure (ns, nse)))
    | .PAS_Realm =>
      (let ns : (BitVec 1) := 1#1
      let nse : (BitVec 1) := 1#1
      (pure (ns, nse)))
    | _ =>
      (do
        (Unreachable ())
        (pure (ns, nse))) ) : SailM ((BitVec 1) × (BitVec 1)) )
  (if ((← (HaveMTE2Ext ())) : Bool)
  then
    (do let pat ← (( do (undefined_bitvector 4) ) : SailM (BitVec 4) )
        let pat ← (( do
          (if (accdesc.tagchecked : Bool)
          then
            (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 62 (Bit 1#1)))
                (pure (AArch64_PhysicalTag addrdesc.vaddress)))
          else
            (do let zero_unchecked ← (( do (__IMPDEF_boolean "SPE PAT for tag unchecked access zero") ) : SailM Bool )
                (if ((! zero_unchecked) : Bool)
                then (do (pure (AArch64_PhysicalTag addrdesc.vaddress)))
                else (do (pure (Zeros (n := 4))))))) ) : SailM (BitVec 4) )
        writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 59 56 pat)))
  else (do (pure ())))
  let paddr : (BitVec 56) := addrdesc.paddress.address
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) (56 -i 1) 0 paddr))
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 63 (Bit ns)))
  writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataPhysical (BitVec.update (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataPhysical) 60 (Bit nse)))
  writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosDataPhysical true)

def SPESetDataVirtualAddress (vaddress : (BitVec 64)) : SailM Unit := do
  let tbi ← (( do (EffectiveTBI vaddress false (← readReg PSTATE).EL) ) : SailM (BitVec 1) )
  let non_tbi_is_zeros ← (( do (__IMPDEF_boolean "SPE non-tbi tag is zero") ) : SailM Bool )
  (if (((tbi == 1#1) || (! non_tbi_is_zeros)) : Bool)
  then (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 63 0 (Sail.BitVec.extractLsb vaddress 63 0))))
  else
    (do writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 63 56 (Zeros (n := 8))))
        writeReg SPESampleAddress (vectorUpdate (← readReg SPESampleAddress) SPEAddrPosDataVirtual (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg SPESampleAddress) SPEAddrPosDataVirtual) 55 0 (Sail.BitVec.extractLsb vaddress 55 0)))))
  writeReg SPESampleAddressValid (vectorUpdate (← readReg SPESampleAddressValid) SPEAddrPosDataVirtual true)

/-- Type quantifiers: k_is_load : Bool -/
def SPESampleLoadStore (is_load : Bool) (accdesc : AccessDescriptor) (addrdesc : AddressDescriptor) : SailM Unit := do
  (if (((BEq.beq accdesc.acctype AccessType_SPE) || ((BEq.beq accdesc.acctype AccessType_IFETCH) || ((BEq.beq accdesc.acctype AccessType_DC) || ((BEq.beq accdesc.acctype AccessType_TTW) || (BEq.beq accdesc.acctype AccessType_AT))))) : Bool)
  then (do (pure ()))
  else
    (do let sample_loads ← (( do (pure (((BitVec.access (← readReg SPESampleSubclass) 0) : BitVec 1) == 0#1)) <&&> (do readReg SPESampleSubclassValid) ) : SailM Bool )
        let sample_stores ← (( do (pure (((BitVec.access (← readReg SPESampleSubclass) 0) : BitVec 1) == 1#1)) <&&> (do readReg SPESampleSubclassValid) ) : SailM Bool )
        (if ((((! (← readReg SPESampleSubclassValid)) || (sample_loads && is_load)) || (sample_stores && (! is_load))) : Bool)
        then
          (do (SPESetDataVirtualAddress addrdesc.vaddress)
              (if ((← (CollectPhysicalAddress ())) : Bool)
              then (do (SPESetDataPhysicalAddress addrdesc accdesc))
              else (do (pure ()))))
        else (do (pure ())))
        (if ((! (← readReg SPESampleSubclassValid)) : Bool)
        then
          (do writeReg SPESampleClass 0b01#2
              writeReg SPESampleSubclassValid true
              writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0001000#7)
              writeReg SPESampleSubclass (BitVec.update (← readReg SPESampleSubclass) 0
                (Bit
                  (if (is_load : Bool)
                  then 0#1
                  else 1#1)))
              writeReg SPESampleOpType (if (is_load : Bool)
              then OpType_Load
              else OpType_Store)
              (if ((BEq.beq accdesc.acctype AccessType_NV2) : Bool)
              then
                (do writeReg SPESampleSubclass (Sail.BitVec.updateSubrange (← readReg SPESampleSubclass) 7 1 0b0011000#7)
                    writeReg SPESampleInstIsNV2 true)
              else (do (pure ()))))
        else (do (pure ())))))

/-- Type quantifiers: k_aligned : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_read__1 (address : (BitVec 64)) (size : Nat) (accdesc_in : AccessDescriptor) (aligned : Bool) (ispair : Bool) : SailM (BitVec (size * 8)) := do
  sail_assert ((size == 1) || ((size == 2) || ((size == 4) || ((size == 8) || (size == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:27977.69-27977.70"
  let value_name ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let accdesc : AccessDescriptor := accdesc_in
  (if ((← (HaveLSE2Ext ())) : Bool)
  then (do sail_assert (← (AllInAlignedQuantity address size 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:27981.54-27981.55")
  else (do sail_assert (IsAligned__1 address size) "sail-arm/arm-v9.4-a/src/v8_base.sail:27983.42-27983.43"))
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := true
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  let atomic ← (( do (undefined_bool ()) ) : SailM Bool )
  let atomic ← (( do
    (if ((((BEq.beq memaddrdesc.memattrs.memtype MemType_Normal) && (memaddrdesc.memattrs.inner.attrs == MemAttr_WB)) && (memaddrdesc.memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then (do (pure true))
    else
      (do (if (((((accdesc.exclusive || accdesc.atomicop) || accdesc.acqsc) || accdesc.acqpc) || accdesc.relsc) : Bool)
          then
            (do (if ((←((pure (! aligned)) <&&> (do
                     (pure (! (← (ConstrainUnpredictableBool Unpredictable_MISALIGNEDATOMIC))))))) : Bool)
                then
                  (do (AArch64_Abort address (← (AlignmentFault accdesc)))
                      (pure atomic))
                else (do (pure true))))
          else
            (do (if (aligned : Bool)
                then (do (pure (! ispair)))
                else (do (__IMPDEF_boolean "FEAT_LSE2: access is atomic"))))))) ) : SailM Bool )
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  (if (atomic : Bool)
  then
    (do let (memstatus, value_name) ← (( do
          let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc size accdesc none)
          let memstatus : PhysMemRetStatus := tup__0
          let value_name : (BitVec (size * 8)) := tup__1
          (pure (memstatus, value_name)) ) : SailM (PhysMemRetStatus × (BitVec (size * 8))) )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalReadAbort memstatus memaddrdesc size accdesc))
        else (do (pure ())))
        (pure value_name))
  else
    (do (if ((aligned && ispair) : Bool)
        then
          (do sail_assert ((size == 8) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28031.37-28031.38"
              let halfsize := (Int.ediv size 2)
              let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let (lowhalf, memstatus) ← (( do
                let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc halfsize accdesc none)
                let memstatus : PhysMemRetStatus := tup__0
                let lowhalf : (BitVec (halfsize * 8)) := tup__1
                (pure (lowhalf, memstatus)) ) : SailM ((BitVec (halfsize * 8)) × PhysMemRetStatus) )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalReadAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address halfsize) } }
              let (highhalf, memstatus) ← (( do
                let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc halfsize accdesc none)
                let memstatus : PhysMemRetStatus := tup__0
                let highhalf : (BitVec (halfsize * 8)) := tup__1
                (pure (highhalf, memstatus)) ) : SailM ((BitVec (halfsize * 8)) × PhysMemRetStatus) )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalReadAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              (pure (highhalf +++ lowhalf)))
        else
          (do let (memaddrdesc, memstatus, value_name) ← (( do
                let loop_i_lower := 0
                let loop_i_upper := (size -i 1)
                let mut loop_vars := (memaddrdesc, memstatus, value_name)
                for i in [loop_i_lower:loop_i_upper:1]i do
                  let (memaddrdesc, memstatus, value_name) := loop_vars
                  loop_vars ← do
                    let (memstatus, value_name) ← (( do
                      let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc 1 accdesc none)
                      let memstatus : PhysMemRetStatus := tup__0
                      let value_name : (BitVec (size * 8)) := (Sail.BitVec.updateSubrange value_name ((8 *i i) +i 7) (8 *i i) tup__1)
                      (pure (memstatus, value_name)) ) : SailM (PhysMemRetStatus × (BitVec (size * 8))) )
                    (if ((IsFault__2 memstatus) : Bool)
                    then (do (HandleExternalReadAbort memstatus memaddrdesc 1 accdesc))
                    else (do (pure ())))
                    let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
                    (pure (memaddrdesc, memstatus, value_name))
                (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus × (BitVec (size * 8))) )
              (pure value_name)))))

/-- Type quantifiers: k_aligned : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_read (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (aligned : Bool) : SailM (BitVec (size * 8)) := do
  let ispair : Bool := false
  (AArch64_MemSingle_read__1 address size accdesc aligned ispair)

/-- Type quantifiers: processorid : Int, size : Int -/
def ClearExclusiveByAddress (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: k_aligned : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_set__1 (address : (BitVec 64)) (size : Nat) (accdesc_in : AccessDescriptor) (aligned : Bool) (ispair : Bool) (value_name : (BitVec (size * 8))) : SailM Unit := do
  sail_assert ((size == 1) || ((size == 2) || ((size == 4) || ((size == 8) || (size == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28072.69-28072.70"
  let accdesc : AccessDescriptor := accdesc_in
  (if ((← (HaveLSE2Ext ())) : Bool)
  then (do sail_assert (← (AllInAlignedQuantity address size 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28075.54-28075.55")
  else (do sail_assert (IsAligned__1 address size) "sail-arm/arm-v9.4-a/src/v8_base.sail:28077.42-28077.43"))
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  let _ : Unit :=
    if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
    then (ClearExclusiveByAddress memaddrdesc.paddress (ProcessorID ()) size)
    else ()
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := false
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let atomic ← (( do (undefined_bool ()) ) : SailM Bool )
  let atomic ← (( do
    (if ((((BEq.beq memaddrdesc.memattrs.memtype MemType_Normal) && (memaddrdesc.memattrs.inner.attrs == MemAttr_WB)) && (memaddrdesc.memattrs.outer.attrs == MemAttr_WB)) : Bool)
    then (do (pure true))
    else
      (do (if (((((accdesc.exclusive || accdesc.atomicop) || accdesc.acqsc) || accdesc.acqpc) || accdesc.relsc) : Bool)
          then
            (do (if ((←((pure (! aligned)) <&&> (do
                     (pure (! (← (ConstrainUnpredictableBool Unpredictable_MISALIGNEDATOMIC))))))) : Bool)
                then
                  (do (AArch64_Abort address (← (AlignmentFault accdesc)))
                      (pure atomic))
                else (do (pure true))))
          else
            (do (if (aligned : Bool)
                then (do (pure (! ispair)))
                else (do (__IMPDEF_boolean "FEAT_LSE2: access is atomic"))))))) ) : SailM Bool )
  (if (atomic : Bool)
  then
    (do let memstatus ← (( do (PhysMemWrite memaddrdesc size accdesc none value_name) ) : SailM PhysMemRetStatus )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc size accdesc))
        else (do (pure ()))))
  else
    (do (if ((aligned && ispair) : Bool)
        then
          (do sail_assert ((size == 8) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28128.37-28128.38"
              let halfsize := (Int.ediv size 2)
              let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
              let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                (highhalf, lowhalf)
              let memstatus ← (( (PhysMemWrite memaddrdesc halfsize accdesc none lowhalf) ) : SailM PhysMemRetStatus )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address halfsize) } }
              let memstatus ← (( do (PhysMemWrite memaddrdesc halfsize accdesc none highhalf) ) : SailM PhysMemRetStatus )
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc halfsize accdesc))
              else (do (pure ()))))
        else
          (do let (memaddrdesc, memstatus) ← (( do
                let loop_i_lower := 0
                let loop_i_upper := (size -i 1)
                let mut loop_vars := (memaddrdesc, memstatus)
                for i in [loop_i_lower:loop_i_upper:1]i do
                  let (memaddrdesc, memstatus) := loop_vars
                  loop_vars ← do
                    let memstatus ← (PhysMemWrite memaddrdesc 1 accdesc none (Sail.BitVec.extractLsb value_name ((8 *i i) +i 7) (8 *i i)))
                    (if ((IsFault__2 memstatus) : Bool)
                    then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
                    else (do (pure ())))
                    let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
                    (pure (memaddrdesc, memstatus))
                (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
              (pure ())))))

/-- Type quantifiers: k_aligned : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def AArch64_MemSingle_set (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (aligned : Bool) (value_name : (BitVec (size * 8))) : SailM Unit := do
  let ispair : Bool := false
  (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name)

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, List.elem size [1, 2, 4, 8, 16] -/
def Mem_read__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) : SailM (BitVec (size * 8)) := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let halfsize := (Int.ediv size 2)
  let value_name ← (( do (undefined_bitvector (size *i 8)) ) : SailM (BitVec (size * 8)) )
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
    then
      (do let lowhalf ← (( do (AArch64_MemSingle_read__1 address halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          let highhalf ← (( do (AArch64_MemSingle_read__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair) ) : SailM (BitVec (halfsize * 8)) )
          (pure (highhalf +++ lowhalf)))
    else
      (do (if ((←((HaveLSE2Ext ()) <&&> (do
               (AllInAlignedQuantity address size 16)))) : Bool)
          then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
          else
            (do (if ((ispair && aligned) : Bool)
                then
                  (do sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28194.52-28194.53"
                      let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                      let (highhalf, lowhalf) ← (( do
                        (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                        then
                          (do let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))
                        else
                          (do let lowhalf ← (AArch64_MemSingle_read address halfsize accdesc aligned)
                              let highhalf ← (AArch64_MemSingle_read (BitVec.addInt address halfsize) halfsize accdesc aligned)
                              (pure (highhalf, lowhalf)))) ) : SailM ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) )
                      (pure (highhalf +++ lowhalf)))
                else
                  (do (if (aligned : Bool)
                      then (do (AArch64_MemSingle_read__1 address size accdesc aligned ispair))
                      else
                        (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28208.23-28208.24"
                            sail_assert ((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28209.52-28209.53"
                            let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                            (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                            then
                              (do let highhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_1 := highhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let highhalf := loop_vars_1
                                      loop_vars_1 ← do (pure (Sail.BitVec.updateSubrange highhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned))))
                                    (pure loop_vars_1) ) : SailM (BitVec (halfsize * 8)) )
                                  let lowhalf ← (( do
                                    let loop_i_lower := 0
                                    let loop_i_upper := (halfsize -i 1)
                                    let mut loop_vars_2 := lowhalf
                                    for i in [loop_i_lower:loop_i_upper:1]i do
                                      let lowhalf := loop_vars_2
                                      loop_vars_2 ← do (pure (Sail.BitVec.updateSubrange lowhalf ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                    (pure loop_vars_2) ) : SailM (BitVec (halfsize * 8)) )
                                  (pure (highhalf +++ lowhalf)))
                            else
                              (do let value_name ← (pure (Sail.BitVec.updateSubrange value_name 7 0 (← (AArch64_MemSingle_read address 1 accdesc aligned))))
                                  let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                  sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28223.63-28223.64"
                                  let aligned : Bool :=
                                    if ((BEq.beq c Constraint_NONE) : Bool)
                                    then true
                                    else aligned
                                  let loop_i_lower := 1
                                  let loop_i_upper := (size -i 1)
                                  let mut loop_vars := value_name
                                  for i in [loop_i_lower:loop_i_upper:1]i do
                                    let value_name := loop_vars
                                    loop_vars ← do (pure (Sail.BitVec.updateSubrange value_name ((8 *i i) +i 7) (8 *i i) (← (AArch64_MemSingle_read (BitVec.addInt address i) 1 accdesc aligned))))
                                  (pure loop_vars))))))))))) ) : SailM (BitVec (size * 8)) )
  (if ((← (BigEndian accdesc.acctype)) : Bool)
  then (do (pure (reverse_endianness value_name)))
  else (do (pure value_name)))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_read (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) : SailM (BitVec (size * 8)) := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28168.48-28168.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_read__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) : SailM (BitVec (size * 8)) := do
  let highestAddressfirst : Bool := false
  sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28174.48-28174.49"
  (Mem_read__2 address size accdesc ispair highestAddressfirst)

/-- Type quantifiers: k_highestAddressfirst : Bool, k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__2 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (highestAddressfirst : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let c ← (( do (undefined_Constraint ()) ) : SailM Constraint )
  let joinedpair ← (( do (undefined_bool ()) ) : SailM Bool )
  let halfsize := (Int.ediv size 2)
  let value_name : (BitVec (size * 8)) := value_in_name
  let alignment :=
    if (ispair : Bool)
    then halfsize
    else size
  let aligned : Bool := (IsAligned__1 address alignment)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let value_name ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then
      (do sail_assert (((size *i 8) == 8) || (((size *i 8) == 16) || (((size *i 8) == 32) || (((size *i 8) == 64) || ((size *i 8) == 128))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28271.116-28271.117"
          (pure (reverse_endianness value_name)))
    else (do (pure value_name))) ) : SailM (BitVec (size * 8)) )
  (if ((((BEq.beq accdesc.acctype AccessType_ASIMD) && (size == 16)) && (IsAligned__1 address 8)) : Bool)
  then
    (do sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28275.27-28275.28"
        let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
        let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
          let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 127 64)
          let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name 63 0)
          (highhalf, lowhalf)
        (AArch64_MemSingle_set__1 address halfsize accdesc aligned ispair lowhalf)
        (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned ispair highhalf))
  else
    (do (if ((←((HaveLSE2Ext ()) <&&> (do
             (AllInAlignedQuantity address size 16)))) : Bool)
        then
          (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28282.52-28282.53"
              (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
        else
          (do (if ((ispair && aligned) : Bool)
              then
                (do let joinedpair : Bool := false
                    sail_assert (halfsize >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28286.27-28286.28"
                    let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                    sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28289.69-28289.70"
                    let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                      let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                      let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                      (highhalf, lowhalf)
                    (if (((← (HaveLRCPC3Ext ())) && highestAddressfirst) : Bool)
                    then
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28292.60-28292.61"
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf)
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf))
                    else
                      (do sail_assert (((((halfsize == 1) || (halfsize == 2)) || (halfsize == 4)) || (halfsize == 8)) || (halfsize == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28296.60-28296.61"
                          (AArch64_MemSingle_set__1 address halfsize accdesc aligned joinedpair lowhalf)
                          (AArch64_MemSingle_set__1 (BitVec.addInt address halfsize) halfsize accdesc aligned joinedpair highhalf))))
              else
                (do (if (aligned : Bool)
                    then
                      (do sail_assert (((((size == 1) || (size == 2)) || (size == 4)) || (size == 8)) || (size == 16)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28301.52-28301.53"
                          (AArch64_MemSingle_set__1 address size accdesc aligned ispair value_name))
                    else
                      (do sail_assert (size >b 1) "sail-arm/arm-v9.4-a/src/v8_base.sail:28304.23-28304.24"
                          let highhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          let lowhalf ← (( do (undefined_bitvector (halfsize *i 8)) ) : SailM (BitVec (halfsize * 8)) )
                          (if ((((← (HaveLRCPC3Ext ())) && ispair) && highestAddressfirst) : Bool)
                          then
                            (do sail_assert ((size *i 8) == ((halfsize *i 8) +i (halfsize *i 8))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28308.73-28308.74"
                                let (highhalf, lowhalf) : ((BitVec (halfsize * 8)) × (BitVec (halfsize * 8))) :=
                                  let highhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name ((size *i 8) -i 1) ((((size *i 8) -i 1) -i (halfsize *i 8)) +i 1))
                                  let lowhalf : (BitVec (halfsize * 8)) := (Sail.BitVec.extractLsb value_name (((size *i 8) -i 1) -i (halfsize *i 8)) (((((size *i 8) -i 1) -i (halfsize *i 8)) -i (halfsize *i 8)) +i 1))
                                  (highhalf, lowhalf)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_1 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_1
                                  loop_vars_1 ← do (AArch64_MemSingle_set (BitVec.addInt (BitVec.addInt address halfsize) i) 1 accdesc aligned (Sail.BitVec.extractLsb highhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_1)
                                let loop_i_lower := 0
                                let loop_i_upper := (halfsize -i 1)
                                let mut loop_vars_2 := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars_2
                                  loop_vars_2 ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb lowhalf ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars_2))
                          else
                            (do (AArch64_MemSingle_set address 1 accdesc aligned (Sail.BitVec.extractLsb value_name 7 0))
                                let c ← (( do (ConstrainUnpredictable Unpredictable_DEVPAGE2) ) : SailM Constraint )
                                sail_assert ((BEq.beq c Constraint_FAULT) || (BEq.beq c Constraint_NONE)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28319.63-28319.64"
                                let aligned : Bool :=
                                  if ((BEq.beq c Constraint_NONE) : Bool)
                                  then true
                                  else aligned
                                let loop_i_lower := 1
                                let loop_i_upper := (size -i 1)
                                let mut loop_vars := ()
                                for i in [loop_i_lower:loop_i_upper:1]i do
                                  let () := loop_vars
                                  loop_vars ← do (AArch64_MemSingle_set (BitVec.addInt address i) 1 accdesc aligned (Sail.BitVec.extractLsb value_name ((8 *i i) +i 7) (8 *i i)))
                                (pure loop_vars)))))))))))

/-- Type quantifiers: size : Nat, (size * 8) ≥ 0 -/
def Mem_set (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let ispair : Bool := false
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_ispair : Bool, size : Nat, (size * 8) ≥ 0 -/
def Mem_set__1 (address : (BitVec 64)) (size : Nat) (accdesc : AccessDescriptor) (ispair : Bool) (value_in_name : (BitVec (size * 8))) : SailM Unit := do
  let highestAddressfirst : Bool := false
  (Mem_set__2 address size accdesc ispair highestAddressfirst value_in_name)

/-- Type quantifiers: k_size : Nat, k_size ≥ 0 -/
def MemAtomic (address : (BitVec 64)) (cmpoperand : (BitVec k_size)) (operand : (BitVec k_size)) (accdesc_in : AccessDescriptor) : SailM (BitVec k_size) := do
  sail_assert accdesc_in.atomicop "sail-arm/arm-v9.4-a/src/v8_base.sail:28335.30-28335.31"
  let bytes := (Int.ediv (Sail.BitVec.length operand) 8)
  sail_assert ((bytes == 1) || ((bytes == 2) || ((bytes == 4) || ((bytes == 8) || (bytes == 16))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:28337.74-28337.75"
  let newvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let oldvalue ← (( do (undefined_bitvector (Sail.BitVec.length operand)) ) : SailM (BitVec k_size) )
  let accdesc : AccessDescriptor := accdesc_in
  let aligned : Bool := (IsAligned__1 address bytes)
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked address accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address bytes)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned (Sail.BitVec.length operand)) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (AArch64_Abort address memaddrdesc.fault))
  else (do (pure ())))
  let _ : Unit :=
    if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
    then (ClearExclusiveByAddress memaddrdesc.paddress (ProcessorID ()) (Sail.BitVec.length operand))
    else ()
  (if ((←((pure ((← (HaveMTE2Ext ())) && accdesc.tagchecked)) <&&> (do
       (pure (! (← (HaveMTEStoreOnlyExt ())))) <||> (do
         (pure (! (← (StoreOnlyTagCheckingEnabled accdesc.el)))))))) : Bool)
  then
    (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
        (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
        then (do (AArch64_TagCheckFault address accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert ((8 *i bytes) == (Sail.BitVec.length operand)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28363.42-28363.43"
  let (memstatus, oldvalue) ← (( do
    let (tup__0, tup__1) ← do (PhysMemRead memaddrdesc bytes accdesc none)
    let memstatus : PhysMemRetStatus := tup__0
    let oldvalue : (BitVec k_size) := tup__1
    (pure (memstatus, oldvalue)) ) : SailM (PhysMemRetStatus × (BitVec k_size)) )
  (if ((IsFault__2 memstatus) : Bool)
  then (do (HandleExternalReadAbort memstatus memaddrdesc bytes accdesc))
  else (do (pure ())))
  let oldvalue ← (( do
    (if ((← (BigEndian accdesc.acctype)) : Bool)
    then (do (pure (reverse_endianness oldvalue)))
    else (do (pure oldvalue))) ) : SailM (BitVec k_size) )
  let oldvalue := oldvalue
  let cmpfail : Bool := false
  let (cmpfail, newvalue) : (Bool × (BitVec k_size)) :=
    match accdesc.modop with
    | .MemAtomicOp_ADD =>
      (let newvalue : (BitVec k_size) := (oldvalue + operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_BIC =>
      (let newvalue : (BitVec k_size) := (oldvalue &&& (Complement.complement operand))
      (cmpfail, newvalue))
    | .MemAtomicOp_EOR =>
      (let newvalue : (BitVec k_size) := (oldvalue ^^^ operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_ORR =>
      (let newvalue : (BitVec k_size) := (oldvalue ||| operand)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toInt oldvalue) (BitVec.toInt operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMAX =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Max.max (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_UMIN =>
      (let newvalue : (BitVec k_size) := (integer_subrange (Min.min (BitVec.toNat oldvalue) (BitVec.toNat operand)) ((Sail.BitVec.length operand) -i 1) 0)
      (cmpfail, newvalue))
    | .MemAtomicOp_SWP =>
      (let newvalue : (BitVec k_size) := operand
      (cmpfail, newvalue))
    | .MemAtomicOp_CAS =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
    | .MemAtomicOp_GCSSS1 =>
      (let newvalue : (BitVec k_size) := operand
      let cmpfail : Bool := (cmpoperand != oldvalue)
      (cmpfail, newvalue))
  let accdesc ← (( do
    (if ((←((HaveMTEStoreOnlyExt ()) <&&> (do
         (StoreOnlyTagCheckingEnabled accdesc.el)))) : Bool)
    then
      (do let accdesc ← (( do
            (if ((accdesc.tagchecked && cmpfail) : Bool)
            then (do (pure { accdesc with tagchecked := (← do (ConstrainUnpredictableBool Unpredictable_STOREONLYTAGCHECKEDCAS)) }))
            else (do (pure accdesc))) ) : SailM AccessDescriptor )
          (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
          then
            (do let ptag : (BitVec 4) := (AArch64_PhysicalTag address)
                (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
                then
                  (do let accdesc : AccessDescriptor := { accdesc with read := false }
                      (AArch64_TagCheckFault address accdesc)
                      (pure accdesc))
                else (do (pure accdesc))))
          else (do (pure accdesc))))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  (if ((! cmpfail) : Bool)
  then
    (do let newvalue ← (( do
          (if ((← (BigEndian accdesc.acctype)) : Bool)
          then (do (pure (reverse_endianness newvalue)))
          else (do (pure newvalue))) ) : SailM (BitVec k_size) )
        let memstatus ← (( do (PhysMemWrite memaddrdesc bytes accdesc none newvalue) ) : SailM PhysMemRetStatus )
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc bytes accdesc))
        else (do (pure ()))))
  else (do (pure ())))
  (if ((← readReg SPESampleInFlight) : Bool)
  then
    (do let is_load : Bool := false
        (SPESampleLoadStore is_load accdesc memaddrdesc))
  else (do (pure ())))
  (pure oldvalue)

def undefined_RCWMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def undefined_RCWSMASK_EL1_Type (_ : Unit) : SailM (BitVec 128) := do
  (undefined_bitvector 128)

def AArch64_AllocationTagFromAddress (tagged_address : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb tagged_address 59 56)

def PhysMemTagWrite (desc : AddressDescriptor) (accdesc : AccessDescriptor) (data : (BitVec 4)) : SailM PhysMemRetStatus := do
  (undefined_PhysMemRetStatus ())

def undefined_VNCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VNCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: N : Nat, offset : Int, List.elem N [64, 128] -/
def NVMem_set__1 (offset : Int) (N : Nat) (value_name : (BitVec N)) : SailM Unit := do
  sail_assert (offset >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28783.21-28783.22"
  sail_assert ((N == 64) || (N == 128)) "sail-arm/arm-v9.4-a/src/v8_base.sail:28784.29-28784.30"
  let address ← (( do (pure (sign_extend ((_get_VNCR_EL2_Type_BADDR (← readReg VNCR_EL2)) +++ (integer_subrange offset 11 0)) 64)) ) : SailM (BitVec 64) )
  let accdesc ← (( do (CreateAccDescNV2 MemOp_STORE) ) : SailM AccessDescriptor )
  (Mem_set address (Int.ediv N 8) accdesc value_name)

/-- Type quantifiers: offset : Int -/
def NVMem_set (offset : Int) (value_name : (BitVec 64)) : SailM Unit := do
  sail_assert (offset >b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:28776.21-28776.22"
  let size := 64
  (NVMem_set__1 offset size value_name)

/-- Type quantifiers: size : Int -/
def AArch64_DataMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  let accdesc : AccessDescriptor := accdesc_in
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagaccess) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let accdesc ← (( do
    (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
    then (do (pure { accdesc with tagchecked := (← do (AArch64_AccessIsTagChecked vaddress accdesc)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let aligned : Bool := true
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if ((← (HaveTME ())) : Bool)
  then
    (do (if ((←((pure accdesc.transactional) <&&> (do
             (pure (! (← (MemHasTransactionalAccess memaddrdesc.memattrs))))))) : Bool)
        then (do (FailTransaction TMFailure_IMP false))
        else (do (pure ()))))
  else (do (pure ())))
  let (memaddrdesc, memstatus) ← (( do
    let loop_i_lower := 0
    let loop_i_upper := (size -i 1)
    let mut loop_vars := (memaddrdesc, memstatus)
    for i in [loop_i_lower:loop_i_upper:1]i do
      let (memaddrdesc, memstatus) := loop_vars
      loop_vars ← do
        (if (((← (HaveMTE2Ext ())) && accdesc.tagchecked) : Bool)
        then
          (do let ptag : (BitVec 4) := (AArch64_PhysicalTag vaddress)
              (if ((! (← (AArch64_CheckTag memaddrdesc accdesc ptag))) : Bool)
              then
                (do (if ((← (__IMPDEF_boolean "DC_ZVA tag fault reported with lowest faulting address")) : Bool)
                    then (do (AArch64_TagCheckFault vaddress accdesc))
                    else (do (AArch64_TagCheckFault regval accdesc))))
              else (do (pure ()))))
        else (do (pure ())))
        let memstatus ← (PhysMemWrite memaddrdesc 1 accdesc none (Zeros (n := 8)))
        (if ((IsFault__2 memstatus) : Bool)
        then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
        else (do (pure ())))
        let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address 1) } }
        (pure (memaddrdesc, memstatus))
    (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
  (pure ())

/-- Type quantifiers: size : Int -/
def AArch64_TagMemZero (regval : (BitVec 64)) (vaddress : (BitVec 64)) (accdesc_in : AccessDescriptor) (size : Int) : SailM Unit := do
  let memstatus ← (( do (undefined_PhysMemRetStatus ()) ) : SailM PhysMemRetStatus )
  sail_assert (accdesc_in.tagaccess && (! accdesc_in.tagchecked)) "sail-arm/arm-v9.4-a/src/v8_base.sail:29013.65-29013.66"
  let accdesc : AccessDescriptor := accdesc_in
  let count := (Int.shiftr size LOG2_TAG_GRANULE)
  let tag : (BitVec 4) := (AArch64_AllocationTagFromAddress vaddress)
  let aligned : Bool := (IsAligned__1 vaddress TAG_GRANULE)
  (if ((! aligned) : Bool)
  then (do (AArch64_Abort vaddress (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let accdesc ← (( do
    (if ((← (HaveMTE2Ext ())) : Bool)
    then (do (pure { accdesc with tagaccess := (← do (AArch64_AllocationTagAccessIsEnabled accdesc.el)) }))
    else (do (pure accdesc))) ) : SailM AccessDescriptor )
  let memaddrdesc ← (( do (AArch64_TranslateAddress vaddress accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then
    (do (if ((← (IsDebugException memaddrdesc.fault)) : Bool)
        then (do (AArch64_Abort vaddress memaddrdesc.fault))
        else (do (AArch64_Abort regval memaddrdesc.fault))))
  else (do (pure ())))
  (if (((! accdesc.tagaccess) || (bne memaddrdesc.memattrs.tags MemTag_AllocationTagged)) : Bool)
  then (do (pure ()))
  else
    (do let (memaddrdesc, memstatus) ← (( do
          let loop_i_lower := 0
          let loop_i_upper := (count -i 1)
          let mut loop_vars := (memaddrdesc, memstatus)
          for i in [loop_i_lower:loop_i_upper:1]i do
            let (memaddrdesc, memstatus) := loop_vars
            loop_vars ← do
              let memstatus ← (PhysMemTagWrite memaddrdesc accdesc tag)
              (if ((IsFault__2 memstatus) : Bool)
              then (do (HandleExternalWriteAbort memstatus memaddrdesc 1 accdesc))
              else (do (pure ())))
              let memaddrdesc : AddressDescriptor := { memaddrdesc with paddress := { memaddrdesc.paddress with address := (BitVec.addInt memaddrdesc.paddress.address TAG_GRANULE) } }
              (pure (memaddrdesc, memstatus))
          (pure loop_vars) ) : SailM (AddressDescriptor × PhysMemRetStatus) )
        (pure ())))

/-- Type quantifiers: processorid : Int, size : Int -/
def AArch64_MarkExclusiveVA (address : (BitVec 64)) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveGlobal (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: processorid : Int, size : Int -/
def MarkExclusiveLocal (paddress : FullAddress) (processorid : Int) (size : Int) : Unit :=
  ()

/-- Type quantifiers: size : Int -/
def AArch64_SetExclusiveMonitors (address : (BitVec 64)) (size : Int) : SailM Unit := do
  writeReg __ExclusiveMonitorSet true
  let acqrel : Bool := false
  let tagchecked : Bool := false
  let accdesc ← (( do (CreateAccDescExLDST MemOp_LOAD acqrel tagchecked) ) : SailM AccessDescriptor )
  let aligned : Bool := (IsAligned__1 address size)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
  (if ((IsFault memaddrdesc) : Bool)
  then (do (pure ()))
  else
    (do let _ : Unit :=
          if ((bne memaddrdesc.memattrs.shareability Shareability_NSH) : Bool)
          then (MarkExclusiveGlobal memaddrdesc.paddress (ProcessorID ()) size)
          else ()
        let _ : Unit := (MarkExclusiveLocal memaddrdesc.paddress (ProcessorID ()) size)
        (pure (AArch64_MarkExclusiveVA address (ProcessorID ()) size))))

/-- Type quantifiers: processorid : Int, size : Int -/
def AArch64_IsExclusiveVA (address : (BitVec 64)) (processorid : Int) (size : Int) : Bool :=
  true

/-- Type quantifiers: processorid : Int, size : Int -/
def IsExclusiveGlobal (paddress : FullAddress) (processorid : Int) (size : Int) : Bool :=
  true

/-- Type quantifiers: processorid : Int, size : Int -/
def IsExclusiveLocal (paddress : FullAddress) (processorid : Int) (size : Int) : Bool :=
  true

/-- Type quantifiers: size : Int -/
def AArch64_ExclusiveMonitorsPass (address : (BitVec 64)) (size : Int) : SailM Bool := do
  let acqrel : Bool := false
  let tagchecked : Bool := false
  let accdesc ← (( do (CreateAccDescExLDST MemOp_STORE acqrel tagchecked) ) : SailM AccessDescriptor )
  let aligned : Bool := (IsAligned__1 address size)
  (if ((←((pure (! aligned)) <&&> (do
       (AArch64_UnalignedAccessFaults accdesc address size)))) : Bool)
  then (do (AArch64_Abort address (← (AlignmentFault accdesc))))
  else (do (pure ())))
  (if ((! (AArch64_IsExclusiveVA address (ProcessorID ()) size)) : Bool)
  then (do (pure false))
  else
    (do let memaddrdesc ← (( do (AArch64_TranslateAddress address accdesc aligned size) ) : SailM AddressDescriptor )
        (if ((IsFault memaddrdesc) : Bool)
        then (do (AArch64_Abort address memaddrdesc.fault))
        else (do (pure ())))
        let passed : Bool := (IsExclusiveLocal memaddrdesc.paddress (ProcessorID ()) size)
        let _ : Unit := (ClearExclusiveLocal (ProcessorID ()))
        (if ((passed && (bne memaddrdesc.memattrs.shareability Shareability_NSH)) : Bool)
        then (do (pure (IsExclusiveGlobal memaddrdesc.paddress (ProcessorID ()) size)))
        else (do (pure passed)))))

def AArch64_AdvSIMDFPAccessTrap (target_el : (BitVec 2)) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let except ← (( do (undefined_ExceptionRecord ()) ) : SailM ExceptionRecord )
  let vect_offset := (BitVec.toNat 0x0#4)
  let route_to_el2 ← (( do (pure (target_el == EL1)) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  (if (route_to_el2 : Bool)
  then
    (do let except ← (( do (ExceptionSyndrome Exception_Uncategorized) ) : SailM ExceptionRecord )
        (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else
    (do let except ← (( (ExceptionSyndrome Exception_AdvSIMDFPAccessTrap) ) : SailM ExceptionRecord )
        let except ← (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 24 20 (← (ConditionSyndrome ()))))) })
        (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def SMEAccessTrap (etype : SMEExceptionType) (target_el_in : (BitVec 2)) : SailM Unit := do
  let target_el : (BitVec 2) := target_el_in
  sail_assert ((BitVec.toNat target_el) ≥b (BitVec.toNat (← readReg PSTATE).EL)) "sail-arm/arm-v9.4-a/src/v8_base.sail:29351.45-29351.46"
  let target_el : (BitVec 2) :=
    if ((target_el == EL0) : Bool)
    then EL1
    else target_el
  let route_to_el2 ← (( do (pure (((← readReg PSTATE).EL == EL0) && (target_el == EL1))) <&&> (do (EL2Enabled ())) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let except ← (( do (ExceptionSyndrome Exception_SMEAccessTrap) ) : SailM ExceptionRecord )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except : ExceptionRecord :=
    match etype with
    | .SMEExceptionType_AccessTrap => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b000#3) }
    | .SMEExceptionType_Streaming => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b001#3) }
    | .SMEExceptionType_NotStreaming => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b010#3) }
    | .SMEExceptionType_InactiveZA => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b011#3) }
    | .SMEExceptionType_InaccessibleZT0 => { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 2 0 0b100#3) }
  (if (route_to_el2 : Bool)
  then (do (AArch64_TakeException EL2 except preferred_exception_return vect_offset))
  else (do (AArch64_TakeException target_el except preferred_exception_return vect_offset)))

def ResetSMEState (_ : Unit) : SailM Unit := do
  let vectors_name := (Int.ediv MAX_VL 8)
  let loop_n_lower := 0
  let loop_n_upper := (vectors_name -i 1)
  let mut loop_vars := ()
  for n in [loop_n_lower:loop_n_upper:1]i do
    let () := loop_vars
    loop_vars ← do writeReg _ZA (vectorUpdate (← readReg _ZA) n (Zeros (n := MAX_VL)))
  (pure loop_vars)
  writeReg _ZT0 (Zeros (n := ZT0_LEN))

def SetPSTATE_SM (value_name : (BitVec 1)) : SailM Unit := do
  (if (((← readReg PSTATE).SM != value_name) : Bool)
  then
    (do (ResetSVEState ())
        writeReg PSTATE { (← readReg PSTATE) with SM := value_name })
  else (do (pure ())))

def SetPSTATE_ZA (value_name : (BitVec 1)) : SailM Unit := do
  (if (((← readReg PSTATE).ZA != value_name) : Bool)
  then
    (do (ResetSMEState ())
        writeReg PSTATE { (← readReg PSTATE) with ZA := value_name })
  else (do (pure ())))

def SetPSTATE_SVCR (svcr : (BitVec 32)) : SailM Unit := do
  (SetPSTATE_SM ((BitVec.access svcr 0) : BitVec 1))
  (SetPSTATE_ZA ((BitVec.access svcr 1) : BitVec 1))

/-- Type quantifiers: k_ex3837967_ : Bool, k_N : Nat, esize : Nat, List.elem k_N [8, 16, 32, 64, 128, 256, 512, 1024, 2048] ∧ List.elem esize [8, 16, 32, 64] ∧ k_N ≥ esize -/
partial def Reduce__1 (op : ReduceOp) (input : (BitVec k_N)) (esize : Nat) (altfp : Bool) : SailM (BitVec esize) := do
  sail_assert ((esize == 8) || ((esize == 16) || ((esize == 32) || (esize == 64)))) "sail-arm/arm-v9.4-a/src/v8_base.sail:30829.63-30829.64"
  let result ← (( do (undefined_bitvector esize) ) : SailM (BitVec esize) )
  (if (((Sail.BitVec.length input) == esize) : Bool)
  then (do (pure (Sail.BitVec.extractLsb input (esize -i 1) 0)))
  else
    (do let half := (Int.ediv (Sail.BitVec.length input) 2)
        let hi ← (( do (Reduce__1 op (Sail.BitVec.extractLsb input ((Sail.BitVec.length input) -i 1) half) esize altfp) ) : SailM (BitVec esize) )
        let lo ← (( do (Reduce__1 op (Sail.BitVec.extractLsb input (half -i 1) 0) esize altfp) ) : SailM (BitVec esize) )
        match op with
        | .ReduceOp_FMINNUM =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30839.51-30839.52"
            (FPMinNum lo hi (← (FPCR_read ()))))
        | .ReduceOp_FMAXNUM =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30843.51-30843.52"
            (FPMaxNum lo hi (← (FPCR_read ()))))
        | .ReduceOp_FMIN =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30847.51-30847.52"
            (FPMin__1 lo hi (← (FPCR_read ())) altfp))
        | .ReduceOp_FMAX =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30851.51-30851.52"
            (FPMax__1 lo hi (← (FPCR_read ())) altfp))
        | .ReduceOp_FADD =>
          (do
            sail_assert (((esize == 16) || (esize == 32)) || (esize == 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30855.51-30855.52"
            (FPAdd lo hi (← (FPCR_read ()))))
        | .ReduceOp_ADD => (pure (lo + hi))))
termination_by (let (op, input, esize, altfp) := (op, input, esize, altfp)
(Sail.BitVec.length input)).toNat

/-- Type quantifiers: k_N : Nat, esize : Nat, List.elem k_N [8, 16, 32, 64, 128, 256, 512, 1024, 2048] ∧ List.elem esize [8, 16, 32, 64] ∧ k_N ≥ esize -/
def Reduce (op : ReduceOp) (input : (BitVec k_N)) (esize : Nat) : SailM (BitVec esize) := do
  let altfp ← (( do (HaveAltFP ()) <&&> (do (pure (! (← (UsingAArch32 ()))))) <&&> (do (pure ((_get_FPCR_Type_AH (← readReg FPCR)) == 1#1))) ) : SailM Bool )
  (Reduce__1 op input esize altfp)

/-- Type quantifiers: M : Nat, k_immediate : Bool, M ≥ 0 -/
def DecodeBitMasks (immN : (BitVec 1)) (imms : (BitVec 6)) (immr : (BitVec 6)) (immediate : Bool) (M : Nat) : SailM ((BitVec M) × (BitVec M)) := do
  let len := (HighestSetBit (immN +++ (Complement.complement imms)))
  (if ((len <b 1) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  sail_assert (M ≥b (Int.shiftl 1 len)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30900.26-30900.27"
  sail_assert (6 ≥b len) "sail-arm/arm-v9.4-a/src/v8_base.sail:30901.32-30901.33"
  let levels : (BitVec 6) := (Sail.BitVec.zeroExtend (Ones (n := len)) 6)
  (if ((immediate && ((imms &&& levels) == levels)) : Bool)
  then (do sailThrow ((Error_Undefined ())))
  else (do (pure ())))
  let s := (BitVec.toNat (imms &&& levels))
  let r := (BitVec.toNat (immr &&& levels))
  let diff := (s -i r)
  let esize := (Int.shiftl 1 len)
  let d := (BitVec.toNat (integer_subrange diff (len -i 1) 0))
  sail_assert (esize ≥b (s +i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30911.39-30911.40"
  let welem : (BitVec esize) := (Sail.BitVec.zeroExtend (Ones (n := (s +i 1))) esize)
  sail_assert (esize ≥b (d +i 1)) "sail-arm/arm-v9.4-a/src/v8_base.sail:30913.39-30913.40"
  let telem : (BitVec esize) := (Sail.BitVec.zeroExtend (Ones (n := (d +i 1))) esize)
  sail_assert ((esize *i (Int.ediv M esize)) == M) "sail-arm/arm-v9.4-a/src/v8_base.sail:30915.53-30915.54"
  let wmask : (BitVec M) := (BitVec.replicateBits (ROR welem r) (Int.ediv M esize))
  let tmask : (BitVec M) := (BitVec.replicateBits telem (Int.ediv M esize))
  (pure (wmask, tmask))

def HaveSVE2p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SVE2p1)

def HaveSME2p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SME2p1)

def GCSSynchronizationBarrier (_ : Unit) : Unit :=
  ()

def GCSPCREnabled (el : (BitVec 2)) : SailM Bool := do
  (GCSPCRSelected el) <&&> (do
    (GCSEnabled el))

def GCSReturnValueCheckEnabled (el : (BitVec 2)) : SailM Bool := do
  (if ((← (UsingAArch32 ())) : Bool)
  then (do (pure false))
  else
    (do let questionMark := el
        (if ((questionMark == EL0) : Bool)
        then (do (pure ((_get_GCSCRE0_EL1_Type_RVCHKEN (← readReg GCSCRE0_EL1)) == 1#1)))
        else
          (do (if ((questionMark == EL1) : Bool)
              then (do (pure ((_get_GCSCR_EL1_Type_RVCHKEN (← readReg GCSCR_EL1)) == 1#1)))
              else
                (do (if ((questionMark == EL2) : Bool)
                    then (do (pure ((_get_GCSCR_EL2_Type_RVCHKEN (← readReg GCSCR_EL2)) == 1#1)))
                    else
                      (do (if ((questionMark == EL3) : Bool)
                          then (do (pure ((_get_GCSCR_EL3_Type_RVCHKEN (← readReg GCSCR_EL3)) == 1#1)))
                          else (do (undefined_bool ())))))))))))

def GetCurrentGCSPointer (_ : Unit) : SailM (BitVec 64) := do
  let ptr ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then (do (pure ((_get_GCSPR_EL0_Type_PTR (← readReg GCSPR_EL0)) +++ 0b000#3)))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do (pure ((_get_GCSPR_EL1_Type_PTR (← readReg GCSPR_EL1)) +++ 0b000#3)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (pure ((_get_GCSPR_EL2_Type_PTR (← readReg GCSPR_EL2)) +++ 0b000#3)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do (pure ((_get_GCSPR_EL3_Type_PTR (← readReg GCSPR_EL3)) +++ 0b000#3)))
                    else (do (pure ptr)))))))))

def SetCurrentGCSPointer (ptr : (BitVec 64)) : SailM Unit := do
  let questionMark ← do (pure (← readReg PSTATE).EL)
  (if ((questionMark == EL0) : Bool)
  then (do writeReg GCSPR_EL0 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL0) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
  else
    (do (if ((questionMark == EL1) : Bool)
        then (do writeReg GCSPR_EL1 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL1) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do writeReg GCSPR_EL2 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL2) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
              else
                (do (if ((questionMark == EL3) : Bool)
                    then (do writeReg GCSPR_EL3 (Sail.BitVec.updateSubrange (← readReg GCSPR_EL3) 63 3 (Sail.BitVec.extractLsb ptr 63 3)))
                    else (do (pure ())))))))))

def AddGCSRecord (vaddress : (BitVec 64)) : SailM Unit := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_STORE) ) : SailM AccessDescriptor )
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  (Mem_set (BitVec.subInt ptr 8) 8 accdesc vaddress)
  let ptr : (BitVec 64) := (BitVec.subInt ptr 8)
  (SetCurrentGCSPointer ptr)

def GCSDataCheckException (gcsinst_type : GCSInstruction) : SailM Unit := do
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let rn_unknown : Bool := false
  let is_ret : Bool := false
  let target_el ← (( do
    (if (((← readReg PSTATE).EL == EL0) : Bool)
    then
      (do (if (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1) : Bool)
          then (do (pure EL1))
          else (do (pure EL2))))
    else (do (pure (← readReg PSTATE).EL))) ) : SailM (BitVec 2) )
  let except ← (( do (ExceptionSyndrome Exception_GCSFail) ) : SailM ExceptionRecord )
  let (except, is_ret, rn_unknown) : (ExceptionRecord × Bool × Bool) :=
    match gcsinst_type with
    | .GCSInstType_PRET =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00000#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPM =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00001#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_PRETAA =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00010#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_PRETAB =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00011#5) }
      let is_ret : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_SS1 =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00100#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_SS2 =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b00101#5) }
      let rn_unknown : Bool := true
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPCX =>
      (let rn_unknown : Bool := true
      let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b01000#5) }
      (except, is_ret, rn_unknown))
    | .GCSInstType_POPX =>
      (let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 4 0 0b01001#5) }
      (except, is_ret, rn_unknown))
  let except ← (( do
    (if ((rn_unknown == true) : Bool)
    then (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (← (__UNKNOWN_bits 5))))) }))
    else
      (do (if ((is_ret == true) : Bool)
          then (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 9 5)))) }))
          else (do (pure { except with syndrome := (← do (pure (Sail.BitVec.updateSubrange except.syndrome 9 5 (Sail.BitVec.extractLsb (← (ThisInstr ())) 4 0)))) }))))) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 24 10 (Zeros (n := 15))) }
  let except ← (pure { except with vaddress := (← do (__UNKNOWN_bits 64)) })
  (AArch64_TakeException target_el except preferred_exception_return vect_offset)

def LoadCheckGCSRecord (vaddress : (BitVec 64)) (gcsinst_type : GCSInstruction) : SailM (BitVec 64) := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let recorded_va ← (( do (Mem_read ptr 8 accdesc) ) : SailM (BitVec 64) )
  (if (((← (GCSReturnValueCheckEnabled (← readReg PSTATE).EL)) && (recorded_va != vaddress)) : Bool)
  then (do (GCSDataCheckException gcsinst_type))
  else (do (pure ())))
  (pure recorded_va)

def EXLOCKException (_ : Unit) : SailM Unit := do
  let preferred_exception_return ← (( do (ThisInstrAddr 64) ) : SailM (BitVec 64) )
  let vect_offset := (BitVec.toNat 0x0#4)
  let except ← (( do (ExceptionSyndrome Exception_GCSFail) ) : SailM ExceptionRecord )
  let except : ExceptionRecord := { except with syndrome := (BitVec.update except.syndrome 24 (Bit (Zeros (n := 1)))) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 23 20 0b0001#4) }
  let except : ExceptionRecord := { except with syndrome := (Sail.BitVec.updateSubrange except.syndrome 19 0 (Zeros (n := 20))) }
  (AArch64_TakeException (← readReg PSTATE).EL except preferred_exception_return vect_offset)

def GCSSS2 (_ : Unit) : SailM (BitVec 64) := do
  let outgoing_pointer ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let accdesc_ld ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  let accdesc_st ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_STORE) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let incoming_pointer_name ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let outgoing_value ← (( do (Mem_read incoming_pointer_name 8 accdesc_ld) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb outgoing_value 2 0) == 0b101#3) : Bool)
  then
    (do let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 63 3 (BitVec.subInt (Sail.BitVec.extractLsb outgoing_value 63 3) 1))
        let outgoing_pointer : (BitVec 64) := (Sail.BitVec.updateSubrange outgoing_pointer 2 0 0b000#3)
        let outgoing_value : (BitVec 64) := ((Sail.BitVec.extractLsb outgoing_pointer 63 12) +++ 0b000000000001#12)
        (Mem_set outgoing_pointer 8 accdesc_st outgoing_value)
        (SetCurrentGCSPointer (BitVec.addInt incoming_pointer_name 8))
        let _ : Unit := (GCSSynchronizationBarrier ())
        (pure outgoing_pointer))
  else
    (do (GCSDataCheckException GCSInstType_SS2)
        (pure outgoing_pointer)))

def GCSPOPM (_ : Unit) : SailM (BitVec 64) := do
  let accdesc ← (( do (CreateAccDescGCS (← readReg PSTATE).EL MemOp_LOAD) ) : SailM AccessDescriptor )
  (if ((! (← (GCSEnabled (← readReg PSTATE).EL))) : Bool)
  then (do (EndOfInstruction ()))
  else (do (pure ())))
  let ptr ← (( do (GetCurrentGCSPointer ()) ) : SailM (BitVec 64) )
  let entry ← (( do (Mem_read ptr 8 accdesc) ) : SailM (BitVec 64) )
  (if (((Sail.BitVec.extractLsb entry 1 0) != 0b00#2) : Bool)
  then (do (GCSDataCheckException GCSInstType_POPM))
  else (do (pure ())))
  let ptr : (BitVec 64) := (BitVec.addInt ptr 8)
  (SetCurrentGCSPointer ptr)
  (pure entry)

def undefined_HFGITR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_HFGITR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_HFGITR_EL2_Type_DCZVA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def GetPendingPhysicalSError (_ : Unit) : SailM FaultRecord := do
  (__UNKNOWN_FaultRecord ())

def AArch32_PhysicalSErrorSyndrome (_ : Unit) : SailM (BitVec 16) := do
  let syndrome : (BitVec 32) := (Zeros (n := 32))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let syndrome ← (( do
    (if (((← readReg PSTATE).EL == EL2) : Bool)
    then
      (do let errstate ← (( do (AArch32_PEErrorState fault) ) : SailM ErrorState )
          let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 11 10 (← (AArch32_EncodeAsyncErrorSyndrome errstate))))
          let syndrome : (BitVec 32) := (BitVec.update syndrome 9 (Bit fault.extflag))
          (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6)))
    else
      (do let long_format ← (( do (pure ((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1)) ) : SailM Bool )
          (AArch32_CommonFaultStatus fault long_format))) ) : SailM (BitVec 32) )
  (pure (Sail.BitVec.extractLsb syndrome 15 0))

def AArch64_EncodeAsyncErrorSyndrome (errorstate : ErrorState) : SailM (BitVec 3) := do
  match errorstate with
  | .ErrorState_UC => (pure 0b000#3)
  | .ErrorState_UEU => (pure 0b001#3)
  | .ErrorState_UEO => (pure 0b010#3)
  | .ErrorState_UER => (pure 0b011#3)
  | .ErrorState_CE => (pure 0b110#3)
  | _ =>
    (do
      (Unreachable ())
      (undefined_bitvector 3))

/-- Type quantifiers: k_implicit_esb : Bool -/
def AArch64_PhysicalSErrorSyndrome (implicit_esb : Bool) : SailM (BitVec 25) := do
  let syndrome : (BitVec 25) := (Zeros (n := 25))
  let fault ← (( do (GetPendingPhysicalSError ()) ) : SailM FaultRecord )
  let errorstate ← (( do (AArch64_PEErrorState fault) ) : SailM ErrorState )
  (if ((BEq.beq errorstate ErrorState_Uncategorized) : Bool)
  then (do (pure (Zeros (n := 25))))
  else
    (do (if ((BEq.beq errorstate ErrorState_IMPDEF) : Bool)
        then
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 1#1))
              (pure (Sail.BitVec.updateSubrange syndrome 23 0 (← (__IMPDEF_bits 24 "IMPDEF ErrorState")))))
        else
          (do let syndrome : (BitVec 25) := (BitVec.update syndrome 24 (Bit 0#1))
              let syndrome : (BitVec 25) :=
                (BitVec.update syndrome 13
                  (Bit
                    (if (implicit_esb : Bool)
                    then 1#1
                    else 0#1)))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 12 10 (← (AArch64_EncodeAsyncErrorSyndrome errorstate))))
              let syndrome : (BitVec 25) := (BitVec.update syndrome 9 (Bit fault.extflag))
              (pure (Sail.BitVec.updateSubrange syndrome 5 0 0b010001#6))))))

def AArch64_PhysicalSErrorTarget (_ : Unit) : SailM (Bool × (BitVec 2)) := do
  let route_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_to_el3 ← (( do
    (if (((← readReg PSTATE).EL != EL3) : Bool)
    then (do (pure (HaveEL EL3)) <&&> (do (pure ((← (EffectiveEA ())) == 1#1))))
    else (do (pure false))) ) : SailM Bool )
  let route_to_el2 ← (( do
    (if ((←((pure (! route_to_el3)) <&&> (do
         (EL2Enabled ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL1))))) : Bool)
    then (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1)))
    else
      (do (if ((←((pure (! route_to_el3)) <&&> (do
               (EL2Enabled ())) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then (do (pure (! (← (IsInHost ())))) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) != 0b00#2))))
          else (do (pure false))))) ) : SailM Bool )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let masked ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    (if ((questionMark == EL3) : Bool)
    then (do (pure ((← (EffectiveEA ())) == 0#1)) <||> (do (pure ((← readReg PSTATE).A == 1#1))))
    else
      (do (if ((questionMark == EL2) : Bool)
          then (do (pure (! route_to_el3)) <&&> (do (pure (((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_AMO (← readReg HCR_EL2))) == 0b00#2)) <||> (do (pure ((← readReg PSTATE).A == 1#1)))))
          else
            (do (if ((questionMark == EL1) : Bool)
                then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                else
                  (do (if ((questionMark == EL0) : Bool)
                      then (do (pure ((! route_to_el3) && (! route_to_el2))) <&&> (do (pure ((← readReg PSTATE).A == 1#1))))
                      else (do (pure masked))))))))) ) : SailM Bool )
  let masked ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let nmea_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let nmea_bit ← (( do
            let questionMark ← do (pure (← readReg PSTATE).EL)
            (if ((questionMark == EL3) : Bool)
            then (do (pure (_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3))))
            else
              (do (if ((questionMark == EL2) : Bool)
                  then
                    (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                        then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                        else (do (pure 0#1))))
                  else
                    (do (if ((questionMark == EL1) : Bool)
                        then
                          (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                              then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                              else (do (pure 0#1))))
                        else
                          (do (if ((questionMark == EL0) : Bool)
                              then
                                (do (if ((← (IsInHost ())) : Bool)
                                    then
                                      (do (if ((← (IsSCTLR2EL2Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL2_Type_NMEA (← readReg SCTLR2_EL2))))
                                          else (do (pure 0#1))))
                                    else
                                      (do (if ((← (IsSCTLR2EL1Enabled ())) : Bool)
                                          then (do (pure (_get_SCTLR2_EL1_Type_NMEA (← readReg SCTLR2_EL1))))
                                          else (do (pure 0#1))))))
                              else (do (pure nmea_bit))))))))) ) : SailM (BitVec 1) )
          (pure (masked && (nmea_bit == 0#1))))
    else
      (do (if ((←((HaveDoubleFaultExt ()) <&&> (do
               (pure ((← readReg PSTATE).EL == EL3))))) : Bool)
          then
            (do let nmea_bit ← (( do (pure ((_get_SCR_EL3_Type_NMEA (← readReg SCR_EL3)) &&& (← (EffectiveEA ())))) ) : SailM (BitVec 1) )
                (pure (masked && (nmea_bit == 0#1))))
          else (do (pure masked))))) ) : SailM Bool )
  let route_masked_to_el3 ← (( do (undefined_bool ()) ) : SailM Bool )
  let route_masked_to_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
  let (route_masked_to_el2, route_masked_to_el3) ← (( do
    (if ((← (HaveDoubleFault2Ext ())) : Bool)
    then
      (do let route_masked_to_el2 ← (pure ((← (EL2Enabled ())) && (! route_to_el3))) <&&> (do (IsHCRXEL2Enabled ())) <&&> (do (pure ((_get_HCRX_EL2_Type_TMEA (← readReg HCRX_EL2)) == 1#1))) <&&> (do (pure ((← readReg PSTATE).EL == EL1)) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked)) <&&> (do (pure (! (← (IsInHost ())))))))
          let route_masked_to_el3 ← (pure ((←((pure (HaveEL EL3)) <&&> (do (pure ((_get_SCR_EL3_Type_TMEA (← readReg SCR_EL3)) == 1#1))))) && (! (route_to_el2 || route_masked_to_el2)))) <&&> (do (pure ((← readReg PSTATE).EL == EL2)) <||> (do (pure ((← readReg PSTATE).EL == EL1))) <&&> (do (pure (((← readReg PSTATE).A == 1#1) || masked))) <||> (do (pure (((← readReg PSTATE).EL == EL0) && masked))))
          (pure (route_masked_to_el2, route_masked_to_el3)))
    else
      (do let route_masked_to_el2 : Bool := false
          let route_masked_to_el3 : Bool := false
          (pure (route_masked_to_el2, route_masked_to_el3)))) ) : SailM (Bool × Bool) )
  let take_in_el3 ← (( do (pure (((← readReg PSTATE).EL == EL3) && (! masked))) ) : SailM Bool )
  let take_in_el2_0 ← (( do (pure (((←((pure ((← readReg PSTATE).EL == EL2)) <||> (do (IsInHost ())))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let take_in_el1_0 ← (( do (pure ((((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do (pure ((← readReg PSTATE).EL == EL0)) <&&> (do (pure (! (← (IsInHost ())))))))) && (! (route_to_el2 || route_masked_to_el2))) && (! (route_to_el3 || route_masked_to_el3))) && (! masked))) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let (masked, target_el) ← (( do
    (if (((take_in_el3 || route_to_el3) || route_masked_to_el3) : Bool)
    then
      (do let masked : Bool := false
          let target_el : (BitVec 2) := EL3
          (pure (masked, target_el)))
    else
      (do let (masked, target_el) ← (( do
            (if (((take_in_el2_0 || route_to_el2) || route_masked_to_el2) : Bool)
            then
              (do let masked : Bool := false
                  let target_el : (BitVec 2) := EL2
                  (pure (masked, target_el)))
            else
              (do let (masked, target_el) ← (( do
                    (if (take_in_el1_0 : Bool)
                    then
                      (do let masked : Bool := false
                          let target_el : (BitVec 2) := EL1
                          (pure (masked, target_el)))
                    else
                      (do let masked : Bool := true
                          let target_el ← (__UNKNOWN_bits 2)
                          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
                  (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
          (pure (masked, target_el)))) ) : SailM (Bool × (BitVec 2)) )
  (pure (masked, target_el))

def undefined_DISR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DISR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSESR_EL2_Type_IDS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def undefined_DISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DISR_Type := value_name
  writeReg DISR_EL1 (Sail.BitVec.updateSubrange (← readReg DISR_EL1) 31 0 (BitVec.slice r 0 32))
  writeReg _DISR r

def ExternalDebugInterruptsDisabled (target : (BitVec 2)) : SailM Bool := do
  let int_dis ← (( do (undefined_bool ()) ) : SailM Bool )
  let ss ← (( do (SecurityStateAtEL target) ) : SailM SecurityState )
  (if ((← (Havev8p4Debug ())) : Bool)
  then
    (do (if ((((BitVec.access (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) 0) : BitVec 1) == 1#1) : Bool)
        then
          (do match ss with
              | .SS_NonSecure => (do (ExternalInvasiveDebugEnabled ()))
              | .SS_Secure => (do (ExternalSecureInvasiveDebugEnabled ()))
              | .SS_Realm => (do (ExternalRealmInvasiveDebugEnabled ()))
              | .SS_Root => (do (ExternalRootInvasiveDebugEnabled ())))
        else (do (pure false))))
  else
    (do let questionMark := target
        (if ((questionMark == EL3) : Bool)
        then (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) == 0b11#2)) <&&> (do (ExternalSecureInvasiveDebugEnabled ())))
        else
          (do (if ((questionMark == EL2) : Bool)
              then
                (do (do
                      let b__0 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                      (if (((Sail.BitVec.extractLsb b__0 1 1) == (1#1 : (BitVec 1))) : Bool)
                      then (do (pure true))
                      else (do (pure false)))) <&&> (do
                      (ExternalInvasiveDebugEnabled ())))
              else
                (do (if ((questionMark == EL1) : Bool)
                    then
                      (do (if ((BEq.beq ss SS_Secure) : Bool)
                          then
                            (do (do
                                  let b__1 ← do (pure (_get_EDSCR_Type_INTdis (← (EDSCR_read ()))))
                                  (if (((Sail.BitVec.extractLsb b__1 1 1) == (1#1 : (BitVec 1))) : Bool)
                                  then (do (pure true))
                                  else (do (pure false)))) <&&> (do
                                  (ExternalSecureInvasiveDebugEnabled ())))
                          else (do (pure ((_get_EDSCR_Type_INTdis (← (EDSCR_read ()))) != 0b00#2)) <&&> (do (ExternalInvasiveDebugEnabled ())))))
                    else (do (pure int_dis)))))))))

def ClearPendingPhysicalSError (_ : Unit) : Unit :=
  ()

def IsSynchronizablePhysicalSErrorPending (_ : Unit) : SailM Bool := do
  (__UNKNOWN_boolean ())

def AArch64_ESBOperation (_ : Unit) : SailM Unit := do
  let implicit_esb ← (( do (undefined_bool ()) ) : SailM Bool )
  let target_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let masked ← (( do (undefined_bool ()) ) : SailM Bool )
  let (masked, target_el) ← (( do
    let (tup__0, tup__1) ← do (AArch64_PhysicalSErrorTarget ())
    let masked : Bool := tup__0
    let target_el : (BitVec 2) := tup__1
    (pure (masked, target_el)) ) : SailM (Bool × (BitVec 2)) )
  let intdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled target_el)) ) : SailM Bool )
  let masked : Bool := (masked || intdis)
  (if ((←((pure masked) <&&> (do
       (IsSynchronizablePhysicalSErrorPending ())))) : Bool)
  then
    (do (if ((← (ELUsingAArch32 (← (S1TranslationRegime__1 ())))) : Bool)
        then
          (do let syndrome : (BitVec 32) := (Zeros (n := 32))
              let syndrome : (BitVec 32) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 15 0 (← (AArch32_PhysicalSErrorSyndrome ()))))
              (DISR_write (Mk_DISR_Type syndrome)))
        else
          (do let implicit_esb : Bool := false
              let syndrome : (BitVec 64) := (Zeros (n := 64))
              let syndrome : (BitVec 64) := (BitVec.update syndrome 31 (Bit 1#1))
              let syndrome ← (pure (Sail.BitVec.updateSubrange syndrome 24 0 (← (AArch64_PhysicalSErrorSyndrome implicit_esb))))
              writeReg DISR_EL1 (Mk_DISR_EL1_Type syndrome)))
        (pure (ClearPendingPhysicalSError ())))
  else (do (pure ())))

def undefined_VDFSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDFSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def undefined_VSESR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VSESR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def VDFSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _VDFSR ) : SailM VDFSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg VSESR_EL2) 0 32)))

def undefined_VDISR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_VDISR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_VDISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_VDISR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def VDISR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : VDISR_Type := value_name
  writeReg VDISR_EL2 (Sail.BitVec.updateSubrange (← readReg VDISR_EL2) 31 0 (BitVec.slice r 0 32))
  writeReg _VDISR r

def AArch64_vESBOperation (_ : Unit) : SailM Unit := do
  sail_assert (←((pure ((← readReg PSTATE).EL == EL0)) <||> (do
    (pure ((← readReg PSTATE).EL == EL1))) <&&> (do
    (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:33362.63-33362.64"
  let vSEI_enabled ← (( do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 0#1)) <&&> (do (pure ((_get_HCR_EL2_Type_AMO (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vSEI_pending ← (( do (pure vSEI_enabled) <&&> (do (pure ((_get_HCR_EL2_Type_VSE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
  let vintdis ← (( do (Halted ()) <||> (do (ExternalDebugInterruptsDisabled EL1)) ) : SailM Bool )
  let vmasked ← (( do (pure vintdis) <||> (do (pure ((← readReg PSTATE).A == 1#1))) ) : SailM Bool )
  (if ((vSEI_pending && vmasked) : Bool)
  then
    (do (if ((← (ELUsingAArch32 EL1)) : Bool)
        then
          (do let target : (BitVec 32) := (Zeros (n := 32))
              let target : (BitVec 32) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 15 14 (Sail.BitVec.extractLsb (← (VDFSR_read ())) 15 14)))
              let target ← (pure (BitVec.update target 12 (Bit ((BitVec.access (← (VDFSR_read ())) 12) : BitVec 1))))
              let target ← (pure (BitVec.update target 9 (Bit (_get_TTBCR_Type_EAE (← (TTBCR_read ()))))))
              let target ← (( do
                (if (((_get_TTBCR_Type_EAE (← (TTBCR_read ()))) == 1#1) : Bool)
                then (do (pure (Sail.BitVec.updateSubrange target 5 0 0b010001#6)))
                else
                  (do let target : (BitVec 32) := (Sail.BitVec.updateSubrange target 10 10 (Sail.BitVec.extractLsb 0b10110#5 4 4))
                      (pure (Sail.BitVec.updateSubrange target 3 0 (Sail.BitVec.extractLsb 0b10110#5 3 0))))) ) : SailM (BitVec 32) )
              (VDISR_write (Mk_VDISR_Type target)))
        else
          (do let target : (BitVec 64) := (Zeros (n := 64))
              let target : (BitVec 64) := (BitVec.update target 31 (Bit 1#1))
              let target ← (pure (Sail.BitVec.updateSubrange target 24 0 (Sail.BitVec.extractLsb (← readReg VSESR_EL2) 24 0)))
              writeReg VDISR_EL2 (Mk_VDISR_EL2_Type target)))
        writeReg HCR_EL2 (Sail.BitVec.updateSubrange (← readReg HCR_EL2) 8 8 0#1))
  else (do (pure ())))

def undefined_RVBAR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_RVBAR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_RVBAR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_AMCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_AMPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTEL0ACR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTNSAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CNTSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIAUTHSTATUS_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTICONTROL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVCTL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTILSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_CTIPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_DBGDIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDAA32PFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDCIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDCIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVID1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDEVTYPE_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDDFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDDFR1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDHSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDITCTRL_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDLSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPCSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPFR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_EDPIDR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR1_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR3_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPIDR4_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDPRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDRCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_EDVIDSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_ABPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AEOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AHPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_AIAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_BPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_DIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_EOIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_HPPIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_IAR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_PMR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_RPR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICC_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_SGIR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_STATUSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICD_TYPER2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_EISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_ELRSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_HCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_MISR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICH_VTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_CLRSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_NSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_SETSPI_SR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICM_TYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_CLRLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_CTLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_IIDR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INMIR0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_GICR_INVALLR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_INVLPIR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def undefined_GICR_ISENABLER0_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)


end ArmASL.Functions
