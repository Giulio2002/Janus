import ArmASL.Part01

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPType
open FPRounding
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def undefined_S2PIRType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_S2PIRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VSESR_EL2_Type_ISS (v : (BitVec 64)) : (BitVec 24) :=
  (Sail.BitVec.extractLsb v 23 0)

def Mk_FPCRType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_FPCRType_AH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_FPCR_Type_AH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_FPCRType_AHP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _get_FPCRType_DN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 25 25)

def _get_FPCRType_FIZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_FPCRType_FZ (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _get_FPCRType_FZ16 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_FPCR_Type_IDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_FPCR_Type_IOE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_FPCR_Type_IXE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_FPCRType_NEP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 2 2)

def _get_FPCR_Type_OFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_FPCRType_RMode (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _get_FPCR_Type_Stride (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 21 20)

def _get_FPCRType_UFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_FPCR_Type_UFE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_FPCR_Type_length (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def undefined_BRBSRCType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBSRCType (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBSRCINJ_EL1_Type_ADDRESS (v : (BitVec 64)) : (BitVec 64) :=
  (Sail.BitVec.extractLsb v 63 0)

def _get_BRBTGTINJ_EL1_Type_ADDRESS (v : (BitVec 64)) : (BitVec 64) :=
  (Sail.BitVec.extractLsb v 63 0)

def undefined_BRBTGTType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTGTType (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_BRBINFType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_BRBCR_EL1_Type_CC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_BRBCR_EL2_Type_CC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_BRBINFINJ_EL1_Type_CC (v : (BitVec 64)) : (BitVec 14) :=
  (Sail.BitVec.extractLsb v 45 32)

def _get_BRBINFINJ_EL1_Type_CCU (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 46 46)

def _update_EDSCR_Type_EL (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _get_BRBINFINJ_EL1_Type_EL (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 7 6)

def _get_BRBFCR_EL1_Type_LASTFAILED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_BRBINFINJ_EL1_Type_LASTFAILED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_BRBCR_EL1_Type_MPRED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_BRBCR_EL2_Type_MPRED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_BRBINFINJ_EL1_Type_MPRED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_BRBINFINJ_EL1_Type_T (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_BRBINFINJ_EL1_Type_TYPE (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 13 8)

def _get_BRBINFINJ_EL1_Type_VALID (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 1 0)

def undefined_Signal (_ : Unit) : SailM Signal := do
  (internal_pick [Signal_Low, Signal_High])

def CYCLE_COUNTER_ID : Nat := 31

def INSTRUCTION_COUNTER_ID : Nat := 32

def PMU_EVENT_SW_INCR : (BitVec 16) := 0x0000#16

def PMU_EVENT_L1D_CACHE_REFILL : (BitVec 16) := 0x0003#16

def PMU_EVENT_L1D_CACHE : (BitVec 16) := 0x0004#16

def PMU_EVENT_INST_RETIRED : (BitVec 16) := 0x0008#16

def PMU_EVENT_EXC_TAKEN : (BitVec 16) := 0x0009#16

def PMU_EVENT_BR_MIS_PRED : (BitVec 16) := 0x0010#16

def PMU_EVENT_BR_MIS_PRED_RETIRED : (BitVec 16) := 0x0022#16

def PMU_EVENT_L1D_TLB : (BitVec 16) := 0x0025#16

def PMU_EVENT_REMOTE_ACCESS : (BitVec 16) := 0x0031#16

def PMU_EVENT_LL_CACHE : (BitVec 16) := 0x0032#16

def PMU_EVENT_LL_CACHE_MISS : (BitVec 16) := 0x0033#16

def PMU_EVENT_DTLB_WALK : (BitVec 16) := 0x0034#16

def PMU_EVENT_L1D_CACHE_LMISS_RD : (BitVec 16) := 0x0039#16

def PMU_EVENT_L2D_CACHE_RD : (BitVec 16) := 0x0050#16

def PMU_EVENT_L2D_CACHE_LMISS_RD : (BitVec 16) := 0x4009#16

def PMU_EVENT_LDST_ALIGN_LAT : (BitVec 16) := 0x4020#16

def PMU_EVENT_SVE_PRED_EMPTY_SPEC : (BitVec 16) := 0x8075#16

def PMU_EVENT_SVE_PRED_PARTIAL_SPEC : (BitVec 16) := 0x8077#16

def PMU_EVENT_BRB_FILTRATE : (BitVec 16) := 0x811F#16

def PMU_EVENT_DSNP_HIT_RD : (BitVec 16) := 0x8194#16

def PMU_EVENT_L1D_CACHE_HITM_RD : (BitVec 16) := 0x8214#16

def PMU_EVENT_L2D_CACHE_HITM_RD : (BitVec 16) := 0x8215#16

def PMU_EVENT_L3D_CACHE_HITM_RD : (BitVec 16) := 0x8216#16

def PMU_EVENT_LL_CACHE_HITM_RD : (BitVec 16) := 0x8217#16

def PMU_EVENT_L1D_LFB_HIT_RD : (BitVec 16) := 0x8244#16

def PMU_EVENT_L2D_LFB_HIT_RD : (BitVec 16) := 0x8245#16

def PMU_EVENT_L3D_LFB_HIT_RD : (BitVec 16) := 0x8246#16

def PMU_EVENT_LL_LFB_HIT_RD : (BitVec 16) := 0x8247#16

def undefined_SecurityState (_ : Unit) : SailM SecurityState := do
  (internal_pick [SS_NonSecure, SS_Root, SS_Realm, SS_Secure])

def M32_User : (BitVec 5) := 0b10000#5

def M32_FIQ : (BitVec 5) := 0b10001#5

def M32_IRQ : (BitVec 5) := 0b10010#5

def M32_Svc : (BitVec 5) := 0b10011#5

def M32_Monitor : (BitVec 5) := 0b10110#5

def M32_Abort : (BitVec 5) := 0b10111#5

def M32_Hyp : (BitVec 5) := 0b11010#5

def M32_Undef : (BitVec 5) := 0b11011#5

def M32_System : (BitVec 5) := 0b11111#5

def EL3 : (BitVec 2) := 0b11#2

def EL2 : (BitVec 2) := 0b10#2

def EL1 : (BitVec 2) := 0b01#2

def EL0 : (BitVec 2) := 0b00#2

def undefined_ProcState (_ : Unit) : SailM ProcState := do
  (pure { N := (← do
            (undefined_bitvector 1))
          Z := (← do
            (undefined_bitvector 1))
          C := (← do
            (undefined_bitvector 1))
          V := (← do
            (undefined_bitvector 1))
          D := (← do
            (undefined_bitvector 1))
          A := (← do
            (undefined_bitvector 1))
          I := (← do
            (undefined_bitvector 1))
          F := (← do
            (undefined_bitvector 1))
          EXLOCK := (← do
            (undefined_bitvector 1))
          PAN := (← do
            (undefined_bitvector 1))
          UAO := (← do
            (undefined_bitvector 1))
          DIT := (← do
            (undefined_bitvector 1))
          TCO := (← do
            (undefined_bitvector 1))
          PM := (← do
            (undefined_bitvector 1))
          PPEND := (← do
            (undefined_bitvector 1))
          BTYPE := (← do
            (undefined_bitvector 2))
          ZA := (← do
            (undefined_bitvector 1))
          SM := (← do
            (undefined_bitvector 1))
          ALLINT := (← do
            (undefined_bitvector 1))
          SS := (← do
            (undefined_bitvector 1))
          IL := (← do
            (undefined_bitvector 1))
          EL := (← do
            (undefined_bitvector 2))
          nRW := (← do
            (undefined_bitvector 1))
          SP := (← do
            (undefined_bitvector 1))
          Q := (← do
            (undefined_bitvector 1))
          GE := (← do
            (undefined_bitvector 4))
          SSBS := (← do
            (undefined_bitvector 1))
          IT := (← do
            (undefined_bitvector 8))
          J := (← do
            (undefined_bitvector 1))
          T := (← do
            (undefined_bitvector 1))
          E := (← do
            (undefined_bitvector 1))
          M := (← do
            (undefined_bitvector 5)) })

def undefined_InstrSet (_ : Unit) : SailM InstrSet := do
  (internal_pick [InstrSet_A64, InstrSet_A32, InstrSet_T32])

def undefined_DSBAlias (_ : Unit) : SailM DSBAlias := do
  (internal_pick [DSBAlias_SSBB, DSBAlias_PSSBB, DSBAlias_DSB])

def __UNKNOWN_PARTIDtype (_ : Unit) : SailM (BitVec 16) := do
  (undefined_bitvector 16)

def __UNKNOWN_PMGtype (_ : Unit) : SailM (BitVec 8) := do
  (undefined_bitvector 8)

def undefined_PARTIDspaceType (_ : Unit) : SailM PARTIDspaceType := do
  (internal_pick [PIdSpace_Secure, PIdSpace_Root, PIdSpace_Realm, PIdSpace_NonSecure])

def undefined_MPAMinfo (_ : Unit) : SailM MPAMinfo := do
  (pure { mpam_sp := (← do
            (undefined_PARTIDspaceType ()))
          partid := (← do
            (undefined_bitvector 16))
          pmg := (← do
            (undefined_bitvector 8)) })

def undefined_AccessType (_ : Unit) : SailM AccessType := do
  (internal_pick [AccessType_IFETCH, AccessType_GPR, AccessType_ASIMD, AccessType_SVE, AccessType_SME, AccessType_IC, AccessType_DC, AccessType_DCZero, AccessType_AT, AccessType_NV2, AccessType_SPE, AccessType_GCS, AccessType_GPTW, AccessType_TTW])

def undefined_MemOp (_ : Unit) : SailM MemOp := do
  (internal_pick [MemOp_LOAD, MemOp_STORE, MemOp_PREFETCH])

def undefined_VARange (_ : Unit) : SailM VARange := do
  (internal_pick [VARange_LOWER, VARange_UPPER])

def undefined_MemAtomicOp (_ : Unit) : SailM MemAtomicOp := do
  (internal_pick [MemAtomicOp_GCSSS1, MemAtomicOp_ADD, MemAtomicOp_BIC, MemAtomicOp_EOR, MemAtomicOp_ORR, MemAtomicOp_SMAX, MemAtomicOp_SMIN, MemAtomicOp_UMAX, MemAtomicOp_UMIN, MemAtomicOp_SWP, MemAtomicOp_CAS])

def undefined_CacheOp (_ : Unit) : SailM CacheOp := do
  (internal_pick [CacheOp_Clean, CacheOp_Invalidate, CacheOp_CleanInvalidate])

def undefined_CacheOpScope (_ : Unit) : SailM CacheOpScope := do
  (internal_pick [CacheOpScope_SetWay, CacheOpScope_PoU, CacheOpScope_PoC, CacheOpScope_PoE, CacheOpScope_PoP, CacheOpScope_PoDP, CacheOpScope_PoPA, CacheOpScope_ALLU, CacheOpScope_ALLUIS])

def undefined_CacheType (_ : Unit) : SailM CacheType := do
  (internal_pick [CacheType_Data, CacheType_Tag, CacheType_Data_Tag, CacheType_Instruction])

def undefined_AccessDescriptor (_ : Unit) : SailM AccessDescriptor := do
  (pure { acctype := (← do
            (undefined_AccessType ()))
          el := (← do
            (undefined_bitvector 2))
          ss := (← do
            (undefined_SecurityState ()))
          acqsc := (← do
            (undefined_bool ()))
          acqpc := (← do
            (undefined_bool ()))
          relsc := (← do
            (undefined_bool ()))
          limitedordered := (← do
            (undefined_bool ()))
          exclusive := (← do
            (undefined_bool ()))
          atomicop := (← do
            (undefined_bool ()))
          modop := (← do
            (undefined_MemAtomicOp ()))
          nontemporal := (← do
            (undefined_bool ()))
          read := (← do
            (undefined_bool ()))
          write := (← do
            (undefined_bool ()))
          cacheop := (← do
            (undefined_CacheOp ()))
          opscope := (← do
            (undefined_CacheOpScope ()))
          cachetype := (← do
            (undefined_CacheType ()))
          pan := (← do
            (undefined_bool ()))
          transactional := (← do
            (undefined_bool ()))
          nonfault := (← do
            (undefined_bool ()))
          firstfault := (← do
            (undefined_bool ()))
          first := (← do
            (undefined_bool ()))
          contiguous := (← do
            (undefined_bool ()))
          streamingsve := (← do
            (undefined_bool ()))
          ls64 := (← do
            (undefined_bool ()))
          mops := (← do
            (undefined_bool ()))
          rcw := (← do
            (undefined_bool ()))
          rcws := (← do
            (undefined_bool ()))
          toplevel := (← do
            (undefined_bool ()))
          varange := (← do
            (undefined_VARange ()))
          a32lsmd := (← do
            (undefined_bool ()))
          tagchecked := (← do
            (undefined_bool ()))
          tagaccess := (← do
            (undefined_bool ()))
          mpam := (← do
            (undefined_MPAMinfo ())) })

def __UNKNOWN_AccessDescriptor (_ : Unit) : SailM AccessDescriptor := do
  (undefined_AccessDescriptor ())

def undefined_MemType (_ : Unit) : SailM MemType := do
  (internal_pick [MemType_Normal, MemType_Device])

def undefined_DeviceType (_ : Unit) : SailM DeviceType := do
  (internal_pick [DeviceType_GRE, DeviceType_nGRE, DeviceType_nGnRE, DeviceType_nGnRnE])

def undefined_MemAttrHints (_ : Unit) : SailM MemAttrHints := do
  (pure { attrs := (← do
            (undefined_bitvector 2))
          hints := (← do
            (undefined_bitvector 2))
          transient := (← do
            (undefined_bool ())) })

def LOG2_TAG_GRANULE : Nat := 4

def MemAttr_NC : (BitVec 2) := 0b00#2

def MemAttr_WT : (BitVec 2) := 0b10#2

def MemAttr_WB : (BitVec 2) := 0b11#2

def MemHint_No : (BitVec 2) := 0b00#2

def MemHint_WA : (BitVec 2) := 0b01#2

def MemHint_RA : (BitVec 2) := 0b10#2

def MemHint_RWA : (BitVec 2) := 0b11#2

def undefined_Shareability (_ : Unit) : SailM Shareability := do
  (internal_pick [Shareability_NSH, Shareability_ISH, Shareability_OSH])

def undefined_MemTagType (_ : Unit) : SailM MemTagType := do
  (internal_pick [MemTag_Untagged, MemTag_AllocationTagged, MemTag_CanonicallyTagged])

def undefined_MemoryAttributes (_ : Unit) : SailM MemoryAttributes := do
  (pure { memtype := (← do
            (undefined_MemType ()))
          device := (← do
            (undefined_DeviceType ()))
          inner := (← do
            (undefined_MemAttrHints ()))
          outer := (← do
            (undefined_MemAttrHints ()))
          shareability := (← do
            (undefined_Shareability ()))
          tags := (← do
            (undefined_MemTagType ()))
          notagaccess := (← do
            (undefined_bool ()))
          xs := (← do
            (undefined_bitvector 1)) })

def undefined_PASpace (_ : Unit) : SailM PASpace := do
  (internal_pick [PAS_NonSecure, PAS_Secure, PAS_Root, PAS_Realm])

def __UNKNOWN_PASpace (_ : Unit) : SailM PASpace := do
  (undefined_PASpace ())

def undefined_FullAddress (_ : Unit) : SailM FullAddress := do
  (pure { paspace := (← do
            (undefined_PASpace ()))
          address := (← do
            (undefined_bitvector 56)) })

def undefined_GPCF (_ : Unit) : SailM GPCF := do
  (internal_pick [GPCF_None, GPCF_AddressSize, GPCF_Walk, GPCF_EABT, GPCF_Fail])

def undefined_GPCFRecord (_ : Unit) : SailM GPCFRecord := do
  (pure { gpf := (← do
            (undefined_GPCF ()))
          level := (← do
            (undefined_int ())) })

def undefined_Fault (_ : Unit) : SailM Fault := do
  (internal_pick [Fault_None, Fault_AccessFlag, Fault_Alignment, Fault_Background, Fault_Domain, Fault_Permission, Fault_Translation, Fault_AddressSize, Fault_SyncExternal, Fault_SyncExternalOnWalk, Fault_SyncParity, Fault_SyncParityOnWalk, Fault_GPCFOnWalk, Fault_GPCFOnOutput, Fault_AsyncParity, Fault_AsyncExternal, Fault_TagCheck, Fault_Debug, Fault_TLBConflict, Fault_BranchTarget, Fault_HWUpdateAccessFlag, Fault_Lockdown, Fault_Exclusive, Fault_ICacheMaint])

def undefined_ErrorState (_ : Unit) : SailM ErrorState := do
  (internal_pick [ErrorState_UC, ErrorState_UEU, ErrorState_UEO, ErrorState_UER, ErrorState_CE, ErrorState_Uncategorized, ErrorState_IMPDEF])

def undefined_FaultRecord (_ : Unit) : SailM FaultRecord := do
  (pure { statuscode := (← do
            (undefined_Fault ()))
          access := (← do
            (undefined_AccessDescriptor ()))
          ipaddress := (← do
            (undefined_FullAddress ()))
          gpcf := (← do
            (undefined_GPCFRecord ()))
          paddress := (← do
            (undefined_FullAddress ()))
          gpcfs2walk := (← do
            (undefined_bool ()))
          s2fs1walk := (← do
            (undefined_bool ()))
          write := (← do
            (undefined_bool ()))
          s1tagnotdata := (← do
            (undefined_bool ()))
          tagaccess := (← do
            (undefined_bool ()))
          level := (← do
            (undefined_int ()))
          extflag := (← do
            (undefined_bitvector 1))
          secondstage := (← do
            (undefined_bool ()))
          assuredonly := (← do
            (undefined_bool ()))
          toplevel := (← do
            (undefined_bool ()))
          overlay := (← do
            (undefined_bool ()))
          dirtybit := (← do
            (undefined_bool ()))
          domain := (← do
            (undefined_bitvector 4))
          merrorstate := (← do
            (undefined_ErrorState ()))
          debugmoe := (← do
            (undefined_bitvector 4)) })

def __UNKNOWN_FaultRecord (_ : Unit) : SailM FaultRecord := do
  (undefined_FaultRecord ())

def undefined_PhysMemRetStatus (_ : Unit) : SailM PhysMemRetStatus := do
  (pure { statuscode := (← do
            (undefined_Fault ()))
          extflag := (← do
            (undefined_bitvector 1))
          merrorstate := (← do
            (undefined_ErrorState ()))
          store64bstatus := (← do
            (undefined_bitvector 64)) })

def undefined_Permissions (_ : Unit) : SailM Permissions := do
  (pure { ap_table := (← do
            (undefined_bitvector 2))
          xn_table := (← do
            (undefined_bitvector 1))
          pxn_table := (← do
            (undefined_bitvector 1))
          uxn_table := (← do
            (undefined_bitvector 1))
          ap := (← do
            (undefined_bitvector 3))
          xn := (← do
            (undefined_bitvector 1))
          uxn := (← do
            (undefined_bitvector 1))
          pxn := (← do
            (undefined_bitvector 1))
          ppi := (← do
            (undefined_bitvector 4))
          upi := (← do
            (undefined_bitvector 4))
          ndirty := (← do
            (undefined_bitvector 1))
          s2pi := (← do
            (undefined_bitvector 4))
          s2dirty := (← do
            (undefined_bitvector 1))
          po_index := (← do
            (undefined_bitvector 4))
          s2po_index := (← do
            (undefined_bitvector 4))
          s2ap := (← do
            (undefined_bitvector 2))
          s2tag_na := (← do
            (undefined_bitvector 1))
          s2xnx := (← do
            (undefined_bitvector 1))
          s2xn := (← do
            (undefined_bitvector 1)) })

def undefined_S1AccessControls (_ : Unit) : SailM S1AccessControls := do
  (pure { r := (← do
            (undefined_bitvector 1))
          w := (← do
            (undefined_bitvector 1))
          x := (← do
            (undefined_bitvector 1))
          gcs := (← do
            (undefined_bitvector 1))
          overlay := (← do
            (undefined_bool ()))
          or := (← do
            (undefined_bitvector 1))
          ow := (← do
            (undefined_bitvector 1))
          ox := (← do
            (undefined_bitvector 1))
          wxn := (← do
            (undefined_bitvector 1)) })

def undefined_S2AccessControls (_ : Unit) : SailM S2AccessControls := do
  (pure { r := (← do
            (undefined_bitvector 1))
          w := (← do
            (undefined_bitvector 1))
          x := (← do
            (undefined_bitvector 1))
          r_rcw := (← do
            (undefined_bitvector 1))
          w_rcw := (← do
            (undefined_bitvector 1))
          r_mmu := (← do
            (undefined_bitvector 1))
          w_mmu := (← do
            (undefined_bitvector 1))
          toplevel0 := (← do
            (undefined_bitvector 1))
          toplevel1 := (← do
            (undefined_bitvector 1))
          overlay := (← do
            (undefined_bool ()))
          or := (← do
            (undefined_bitvector 1))
          ow := (← do
            (undefined_bitvector 1))
          ox := (← do
            (undefined_bitvector 1))
          or_rcw := (← do
            (undefined_bitvector 1))
          ow_rcw := (← do
            (undefined_bitvector 1))
          or_mmu := (← do
            (undefined_bitvector 1))
          ow_mmu := (← do
            (undefined_bitvector 1)) })

def undefined_MBReqDomain (_ : Unit) : SailM MBReqDomain := do
  (internal_pick [MBReqDomain_Nonshareable, MBReqDomain_InnerShareable, MBReqDomain_OuterShareable, MBReqDomain_FullSystem])

def undefined_MBReqTypes (_ : Unit) : SailM MBReqTypes := do
  (internal_pick [MBReqTypes_Reads, MBReqTypes_Writes, MBReqTypes_All])

def undefined_PrefetchHint (_ : Unit) : SailM PrefetchHint := do
  (internal_pick [Prefetch_READ, Prefetch_WRITE, Prefetch_EXEC])

def undefined_Constraint (_ : Unit) : SailM Constraint := do
  (internal_pick [Constraint_NONE, Constraint_UNKNOWN, Constraint_UNDEF, Constraint_UNDEFEL0, Constraint_NOP, Constraint_TRUE, Constraint_FALSE, Constraint_DISABLED, Constraint_UNCOND, Constraint_COND, Constraint_ADDITIONAL_DECODE, Constraint_WBSUPPRESS, Constraint_FAULT, Constraint_LIMITED_ATOMICITY, Constraint_NVNV1_00, Constraint_NVNV1_01, Constraint_NVNV1_11, Constraint_EL1TIMESTAMP, Constraint_EL2TIMESTAMP, Constraint_OSH, Constraint_ISH, Constraint_NSH, Constraint_NC, Constraint_WT, Constraint_WB, Constraint_FORCE, Constraint_FORCENOSLCHECK, Constraint_MAPTOALLOCATED, Constraint_PMSCR_PCT_VIRT])

def __UNKNOWN_Constraint (_ : Unit) : SailM Constraint := do
  (undefined_Constraint ())

def undefined_FPRounding (_ : Unit) : SailM FPRounding := do
  (internal_pick [FPRounding_TIEEVEN, FPRounding_POSINF, FPRounding_NEGINF, FPRounding_ZERO, FPRounding_TIEAWAY, FPRounding_ODD])

def undefined_FPType (_ : Unit) : SailM FPType := do
  (internal_pick [FPType_Zero, FPType_Denormal, FPType_Nonzero, FPType_Infinity, FPType_QNaN, FPType_SNaN])

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def read_gpr (n : Nat) : SailM (BitVec 64) := do
  match n with
  | 0 => readReg R0
  | 1 => readReg R1
  | 2 => readReg R2
  | 3 => readReg R3
  | 4 => readReg R4
  | 5 => readReg R5
  | 6 => readReg R6
  | 7 => readReg R7
  | 8 => readReg R8
  | 9 => readReg R9
  | 10 => readReg R10
  | 11 => readReg R11
  | 12 => readReg R12
  | 13 => readReg R13
  | 14 => readReg R14
  | 15 => readReg R15
  | 16 => readReg R16
  | 17 => readReg R17
  | 18 => readReg R18
  | 19 => readReg R19
  | 20 => readReg R20
  | 21 => readReg R21
  | 22 => readReg R22
  | 23 => readReg R23
  | 24 => readReg R24
  | 25 => readReg R25
  | 26 => readReg R26
  | 27 => readReg R27
  | 28 => readReg R28
  | 29 => readReg R29
  | _ => readReg R30

/-- Type quantifiers: n : Nat, lo : Nat, hi : Nat, 0 ≤ n ∧ n ≤ 30 ∧ 0 ≤ lo ∧ lo ≤ hi ∧ hi ≤ 63 -/
def write_gpr_bits (n : Nat) (hi : Nat) (lo : Nat) (v : (BitVec (hi - lo + 1))) : SailM Unit := do
  match n with
  | 0 => writeReg R0 (Sail.BitVec.updateSubrange (← readReg R0) hi lo v)
  | 1 => writeReg R1 (Sail.BitVec.updateSubrange (← readReg R1) hi lo v)
  | 2 => writeReg R2 (Sail.BitVec.updateSubrange (← readReg R2) hi lo v)
  | 3 => writeReg R3 (Sail.BitVec.updateSubrange (← readReg R3) hi lo v)
  | 4 => writeReg R4 (Sail.BitVec.updateSubrange (← readReg R4) hi lo v)
  | 5 => writeReg R5 (Sail.BitVec.updateSubrange (← readReg R5) hi lo v)
  | 6 => writeReg R6 (Sail.BitVec.updateSubrange (← readReg R6) hi lo v)
  | 7 => writeReg R7 (Sail.BitVec.updateSubrange (← readReg R7) hi lo v)
  | 8 => writeReg R8 (Sail.BitVec.updateSubrange (← readReg R8) hi lo v)
  | 9 => writeReg R9 (Sail.BitVec.updateSubrange (← readReg R9) hi lo v)
  | 10 => writeReg R10 (Sail.BitVec.updateSubrange (← readReg R10) hi lo v)
  | 11 => writeReg R11 (Sail.BitVec.updateSubrange (← readReg R11) hi lo v)
  | 12 => writeReg R12 (Sail.BitVec.updateSubrange (← readReg R12) hi lo v)
  | 13 => writeReg R13 (Sail.BitVec.updateSubrange (← readReg R13) hi lo v)
  | 14 => writeReg R14 (Sail.BitVec.updateSubrange (← readReg R14) hi lo v)
  | 15 => writeReg R15 (Sail.BitVec.updateSubrange (← readReg R15) hi lo v)
  | 16 => writeReg R16 (Sail.BitVec.updateSubrange (← readReg R16) hi lo v)
  | 17 => writeReg R17 (Sail.BitVec.updateSubrange (← readReg R17) hi lo v)
  | 18 => writeReg R18 (Sail.BitVec.updateSubrange (← readReg R18) hi lo v)
  | 19 => writeReg R19 (Sail.BitVec.updateSubrange (← readReg R19) hi lo v)
  | 20 => writeReg R20 (Sail.BitVec.updateSubrange (← readReg R20) hi lo v)
  | 21 => writeReg R21 (Sail.BitVec.updateSubrange (← readReg R21) hi lo v)
  | 22 => writeReg R22 (Sail.BitVec.updateSubrange (← readReg R22) hi lo v)
  | 23 => writeReg R23 (Sail.BitVec.updateSubrange (← readReg R23) hi lo v)
  | 24 => writeReg R24 (Sail.BitVec.updateSubrange (← readReg R24) hi lo v)
  | 25 => writeReg R25 (Sail.BitVec.updateSubrange (← readReg R25) hi lo v)
  | 26 => writeReg R26 (Sail.BitVec.updateSubrange (← readReg R26) hi lo v)
  | 27 => writeReg R27 (Sail.BitVec.updateSubrange (← readReg R27) hi lo v)
  | 28 => writeReg R28 (Sail.BitVec.updateSubrange (← readReg R28) hi lo v)
  | 29 => writeReg R29 (Sail.BitVec.updateSubrange (← readReg R29) hi lo v)
  | _ => writeReg R30 (Sail.BitVec.updateSubrange (← readReg R30) hi lo v)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def write_gpr (n : Nat) (v : (BitVec 64)) : SailM Unit := do
  match n with
  | 0 => writeReg R0 v
  | 1 => writeReg R1 v
  | 2 => writeReg R2 v
  | 3 => writeReg R3 v
  | 4 => writeReg R4 v
  | 5 => writeReg R5 v
  | 6 => writeReg R6 v
  | 7 => writeReg R7 v
  | 8 => writeReg R8 v
  | 9 => writeReg R9 v
  | 10 => writeReg R10 v
  | 11 => writeReg R11 v
  | 12 => writeReg R12 v
  | 13 => writeReg R13 v
  | 14 => writeReg R14 v
  | 15 => writeReg R15 v
  | 16 => writeReg R16 v
  | 17 => writeReg R17 v
  | 18 => writeReg R18 v
  | 19 => writeReg R19 v
  | 20 => writeReg R20 v
  | 21 => writeReg R21 v
  | 22 => writeReg R22 v
  | 23 => writeReg R23 v
  | 24 => writeReg R24 v
  | 25 => writeReg R25 v
  | 26 => writeReg R26 v
  | 27 => writeReg R27 v
  | 28 => writeReg R28 v
  | 29 => writeReg R29 v
  | _ => writeReg R30 v

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def get_R (n : Nat) : SailM (BitVec 64) := do
  (read_gpr n)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n ≤ 30 -/
def set_R (n : Nat) (v : (BitVec 64)) : SailM Unit := do
  (write_gpr n v)

/-- Type quantifiers: n : Nat, lo : Nat, hi : Nat, 0 ≤ n ∧ n ≤ 30 ∧ 0 ≤ lo ∧ lo ≤ hi ∧ hi ≤ 63 -/
def set_R_bits (n : Nat) (hi : Nat) (lo : Nat) (v : (BitVec (hi - lo + 1))) : SailM Unit := do
  (write_gpr_bits n hi lo v)

def undefined_BranchType (_ : Unit) : SailM BranchType := do
  (internal_pick [BranchType_DIRCALL, BranchType_INDCALL, BranchType_ERET, BranchType_DBGEXIT, BranchType_RET, BranchType_DIR, BranchType_INDIR, BranchType_EXCEPTION, BranchType_TMFAIL, BranchType_RESET, BranchType_UNKNOWN])

def DefaultPARTID : PARTIDtype := (integer_subrange 0 15 0)

def DefaultPMG : PMGtype := (integer_subrange 0 7 0)

def undefined_Exception (_ : Unit) : SailM Exception := do
  (internal_pick [Exception_Uncategorized, Exception_WFxTrap, Exception_CP15RTTrap, Exception_CP15RRTTrap, Exception_CP14RTTrap, Exception_CP14DTTrap, Exception_CP14RRTTrap, Exception_AdvSIMDFPAccessTrap, Exception_FPIDTrap, Exception_LDST64BTrap, Exception_PACTrap, Exception_IllegalState, Exception_SupervisorCall, Exception_HypervisorCall, Exception_MonitorCall, Exception_SystemRegisterTrap, Exception_ERetTrap, Exception_InstructionAbort, Exception_PCAlignment, Exception_DataAbort, Exception_NV2DataAbort, Exception_PACFail, Exception_SPAlignment, Exception_FPTrappedException, Exception_SError, Exception_Breakpoint, Exception_SoftwareStep, Exception_Watchpoint, Exception_NV2Watchpoint, Exception_SoftwareBreakpoint, Exception_VectorCatch, Exception_IRQ, Exception_SVEAccessTrap, Exception_SMEAccessTrap, Exception_TSTARTAccessTrap, Exception_GPC, Exception_BranchTarget, Exception_MemCpyMemSet, Exception_GCSFail, Exception_SystemRegister128Trap, Exception_FIQ])

def undefined_ExceptionRecord (_ : Unit) : SailM ExceptionRecord := do
  (pure { exceptype := (← do
            (undefined_Exception ()))
          syndrome := (← do
            (undefined_bitvector 25))
          syndrome2 := (← do
            (undefined_bitvector 24))
          paddress := (← do
            (undefined_FullAddress ()))
          vaddress := (← do
            (undefined_bitvector 64))
          ipavalid := (← do
            (undefined_bool ()))
          pavalid := (← do
            (undefined_bool ()))
          NS := (← do
            (undefined_bitvector 1))
          ipaddress := (← do
            (undefined_bitvector 56))
          trappedsyscallinst := (← do
            (undefined_bool ())) })

def undefined_Regime (_ : Unit) : SailM Regime := do
  (internal_pick [Regime_EL3, Regime_EL30, Regime_EL2, Regime_EL20, Regime_EL10])

def undefined_TGx (_ : Unit) : SailM TGx := do
  (internal_pick [TGx_4KB, TGx_16KB, TGx_64KB])

def undefined_DescriptorType (_ : Unit) : SailM DescriptorType := do
  (internal_pick [DescriptorType_Table, DescriptorType_Leaf, DescriptorType_Invalid])

def undefined_SDFType (_ : Unit) : SailM SDFType := do
  (internal_pick [SDFType_Table, SDFType_Invalid, SDFType_Supersection, SDFType_Section, SDFType_LargePage, SDFType_SmallPage])

def undefined_TTWState (_ : Unit) : SailM TTWState := do
  (pure { istable := (← do
            (undefined_bool ()))
          level := (← do
            (undefined_int ()))
          baseaddress := (← do
            (undefined_FullAddress ()))
          contiguous := (← do
            (undefined_bitvector 1))
          s1assured := (← do
            (undefined_bool ()))
          s2assuredonly := (← do
            (undefined_bitvector 1))
          disch := (← do
            (undefined_bitvector 1))
          nG := (← do
            (undefined_bitvector 1))
          guardedpage := (← do
            (undefined_bitvector 1))
          sdftype := (← do
            (undefined_SDFType ()))
          domain := (← do
            (undefined_bitvector 4))
          memattrs := (← do
            (undefined_MemoryAttributes ()))
          permissions := (← do
            (undefined_Permissions ())) })

def __UNKNOWN_TTWState (_ : Unit) : SailM TTWState := do
  (undefined_TTWState ())

def undefined_S1TTWParams (_ : Unit) : SailM S1TTWParams := do
  (pure { ha := (← do
            (undefined_bitvector 1))
          hd := (← do
            (undefined_bitvector 1))
          tbi := (← do
            (undefined_bitvector 1))
          tbid := (← do
            (undefined_bitvector 1))
          nfd := (← do
            (undefined_bitvector 1))
          e0pd := (← do
            (undefined_bitvector 1))
          d128 := (← do
            (undefined_bitvector 1))
          aie := (← do
            (undefined_bitvector 1))
          mair2 := (← do
            (undefined_MAIRType ()))
          ds := (← do
            (undefined_bitvector 1))
          ps := (← do
            (undefined_bitvector 3))
          txsz := (← do
            (undefined_bitvector 6))
          epan := (← do
            (undefined_bitvector 1))
          dct := (← do
            (undefined_bitvector 1))
          nv1 := (← do
            (undefined_bitvector 1))
          cmow := (← do
            (undefined_bitvector 1))
          pnch := (← do
            (undefined_bitvector 1))
          disch := (← do
            (undefined_bitvector 1))
          haft := (← do
            (undefined_bitvector 1))
          mtx := (← do
            (undefined_bitvector 1))
          skl := (← do
            (undefined_bitvector 2))
          pie := (← do
            (undefined_bitvector 1))
          pir := (← do
            (undefined_S1PIRType ()))
          pire0 := (← do
            (undefined_S1PIRType ()))
          emec := (← do
            (undefined_bitvector 1))
          amec := (← do
            (undefined_bitvector 1))
          t0sz := (← do
            (undefined_bitvector 3))
          t1sz := (← do
            (undefined_bitvector 3))
          uwxn := (← do
            (undefined_bitvector 1))
          tgx := (← do
            (undefined_TGx ()))
          irgn := (← do
            (undefined_bitvector 2))
          orgn := (← do
            (undefined_bitvector 2))
          sh := (← do
            (undefined_bitvector 2))
          hpd := (← do
            (undefined_bitvector 1))
          ee := (← do
            (undefined_bitvector 1))
          wxn := (← do
            (undefined_bitvector 1))
          ntlsmd := (← do
            (undefined_bitvector 1))
          dc := (← do
            (undefined_bitvector 1))
          sif := (← do
            (undefined_bitvector 1))
          mair := (← do
            (undefined_MAIRType ())) })

def undefined_S2TTWParams (_ : Unit) : SailM S2TTWParams := do
  (pure { ha := (← do
            (undefined_bitvector 1))
          hd := (← do
            (undefined_bitvector 1))
          sl2 := (← do
            (undefined_bitvector 1))
          ds := (← do
            (undefined_bitvector 1))
          d128 := (← do
            (undefined_bitvector 1))
          sw := (← do
            (undefined_bitvector 1))
          nsw := (← do
            (undefined_bitvector 1))
          sa := (← do
            (undefined_bitvector 1))
          nsa := (← do
            (undefined_bitvector 1))
          ps := (← do
            (undefined_bitvector 3))
          txsz := (← do
            (undefined_bitvector 6))
          fwb := (← do
            (undefined_bitvector 1))
          cmow := (← do
            (undefined_bitvector 1))
          skl := (← do
            (undefined_bitvector 2))
          s2pie := (← do
            (undefined_bitvector 1))
          s2pir := (← do
            (undefined_S2PIRType ()))
          tl0 := (← do
            (undefined_bitvector 1))
          tl1 := (← do
            (undefined_bitvector 1))
          assuredonly := (← do
            (undefined_bitvector 1))
          haft := (← do
            (undefined_bitvector 1))
          emec := (← do
            (undefined_bitvector 1))
          s := (← do
            (undefined_bitvector 1))
          t0sz := (← do
            (undefined_bitvector 4))
          tgx := (← do
            (undefined_TGx ()))
          sl0 := (← do
            (undefined_bitvector 2))
          irgn := (← do
            (undefined_bitvector 2))
          orgn := (← do
            (undefined_bitvector 2))
          sh := (← do
            (undefined_bitvector 2))
          ee := (← do
            (undefined_bitvector 1))
          ptw := (← do
            (undefined_bitvector 1))
          vm := (← do
            (undefined_bitvector 1)) })

def undefined_TLBContext (_ : Unit) : SailM TLBContext := do
  (pure { ss := (← do
            (undefined_SecurityState ()))
          regime := (← do
            (undefined_Regime ()))
          vmid := (← do
            (undefined_bitvector 16))
          asid := (← do
            (undefined_bitvector 16))
          nG := (← do
            (undefined_bitvector 1))
          ipaspace := (← do
            (undefined_PASpace ()))
          includes_s1_name := (← do
            (undefined_bool ()))
          includes_s2_name := (← do
            (undefined_bool ()))
          includes_gpt_name := (← do
            (undefined_bool ()))
          ia := (← do
            (undefined_bitvector 64))
          tg := (← do
            (undefined_TGx ()))
          cnp := (← do
            (undefined_bitvector 1))
          level := (← do
            (undefined_int ()))
          isd128 := (← do
            (undefined_bool ()))
          xs := (← do
            (undefined_bitvector 1)) })

def undefined_TLBRecord (_ : Unit) : SailM TLBRecord := do
  (pure { context := (← do
            (undefined_TLBContext ()))
          walkstate := (← do
            (undefined_TTWState ()))
          blocksize := (← do
            (undefined_int ()))
          contigsize := (← do
            (undefined_int ()))
          s1descriptor := (← do
            (undefined_bitvector 128))
          s2descriptor := (← do
            (undefined_bitvector 128)) })

def undefined_AddressDescriptor (_ : Unit) : SailM AddressDescriptor := do
  (pure { fault := (← do
            (undefined_FaultRecord ()))
          memattrs := (← do
            (undefined_MemoryAttributes ()))
          paddress := (← do
            (undefined_FullAddress ()))
          tlbcontext := (← do
            (undefined_TLBContext ()))
          s1assured := (← do
            (undefined_bool ()))
          s2fs1mro := (← do
            (undefined_bool ()))
          mecid := (← do
            (undefined_bitvector 16))
          vaddress := (← do
            (undefined_bitvector 64)) })

def __UNKNOWN_AddressDescriptor (_ : Unit) : SailM AddressDescriptor := do
  (undefined_AddressDescriptor ())

def FINAL_LEVEL : Nat := 3

def MAX_VL : Nat := 2048

def MAX_PL : Nat := 256

def ZT0_LEN : Nat := 512

def undefined_GCSInstruction (_ : Unit) : SailM GCSInstruction := do
  (internal_pick [GCSInstType_PRET, GCSInstType_POPM, GCSInstType_PRETAA, GCSInstType_PRETAB, GCSInstType_SS1, GCSInstType_SS2, GCSInstType_POPCX, GCSInstType_POPX])

def DEFAULT_MECID : (BitVec 16) := (Zeros (n := 16))

def undefined_FPCR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPCR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_FPSR_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_FPSR_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_CTR_Type_IDC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_PMCR_Type_N (v : (BitVec 32)) (x : (BitVec 5)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 11 x)

def _update_TTBCR_Type_N (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _get_PMCR_EL0_Type_N (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 15 11)

def _get_PMCR_Type_N (v : (BitVec 32)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 15 11)

def _update_FPSCR_Type_UFC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _update_SCTLR_Type_V (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 13 x)

def _get_SCTLR_Type_V (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

def undefined_ICC_PMR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_ICC_PMR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_ICC_PMR_Type_Priority (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _update_ICV_PMR_Type_Priority (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 0 x)

def _get_ICV_PMR_EL1_Type_Priority (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def undefined_TMState (_ : Unit) : SailM TMState := do
  (pure { depth := (← do
            (undefined_int ()))
          Rt := (← do
            (undefined_int ()))
          nPC := (← do
            (undefined_bitvector 64))
          X := (← do
            (undefined_vector 31 (← (undefined_bitvector 64))))
          Z := (← do
            (undefined_vector 32 (← (undefined_bitvector 2048))))
          P := (← do
            (undefined_vector 16 (← (undefined_bitvector 256))))
          FFR := (← do
            (undefined_bitvector 256))
          SP := (← do
            (undefined_bitvector 64))
          FPCR := (← do
            (undefined_bitvector 64))
          FPSR := (← do
            (undefined_bitvector 64))
          ICC_PMR_EL1 := (← do
            (undefined_bitvector 64))
          GCSPR_ELx := (← do
            (undefined_bitvector 64))
          nzcv := (← do
            (undefined_bitvector 4))
          D := (← do
            (undefined_bitvector 1))
          A := (← do
            (undefined_bitvector 1))
          I := (← do
            (undefined_bitvector 1))
          F := (← do
            (undefined_bitvector 1)) })

def undefined_PGSe (_ : Unit) : SailM PGSe := do
  (internal_pick [PGS_4KB, PGS_16KB, PGS_64KB])

def GPT_NoAccess : (BitVec 4) := 0b0000#4

def GPT_Table : (BitVec 4) := 0b0011#4

def GPT_Block : (BitVec 4) := 0b0001#4

def GPT_Contig : (BitVec 4) := 0b0001#4

def GPT_Secure : (BitVec 4) := 0b1000#4

def GPT_NonSecure : (BitVec 4) := 0b1001#4

def GPT_Root : (BitVec 4) := 0b1010#4

def GPT_Realm : (BitVec 4) := 0b1011#4

def GPT_Any : (BitVec 4) := 0b1111#4

def GPTRange_4KB : Nat := 12

def GPTRange_16KB : Nat := 14

def GPTRange_64KB : Nat := 16

def GPTRange_2MB : Nat := 21

def GPTRange_32MB : Nat := 25

def GPTRange_512MB : Nat := 29

def GPTRange_1GB : Nat := 30

def GPTRange_16GB : Nat := 34

def GPTRange_64GB : Nat := 36

def GPTRange_512GB : Nat := 39

def undefined_GPTTable (_ : Unit) : SailM GPTTable := do
  (pure { address := (← do (undefined_bitvector 56)) })

def __UNKNOWN_GPTTable (_ : Unit) : SailM GPTTable := do
  (undefined_GPTTable ())

def undefined_GPTEntry (_ : Unit) : SailM GPTEntry := do
  (pure { gpi := (← do
            (undefined_bitvector 4))
          size := (← do
            (undefined_int ()))
          contig_size := (← do
            (undefined_int ()))
          level := (← do
            (undefined_int ()))
          pa := (← do
            (undefined_bitvector 56)) })

def __UNKNOWN_GPTEntry (_ : Unit) : SailM GPTEntry := do
  (undefined_GPTEntry ())

def SPEMaxCounters : Nat := 32

def SPEMaxRecordSize : Nat := 64

def undefined_OpType (_ : Unit) : SailM OpType := do
  (internal_pick [OpType_Load, OpType_Store, OpType_LoadAtomic, OpType_Branch, OpType_Other])

def SPEAddrPosBranchTarget : Nat := 1

def SPEAddrPosDataVirtual : Nat := 2

def SPEAddrPosDataPhysical : Nat := 3

def SPEAddrPosPrevBranchTarget : Nat := 4

def SPECounterPosTranslationLatency : Nat := 2


end ArmASL.Functions
