import ArmASL.Part02

set_option maxHeartbeats 1_000_000_000
set_option maxRecDepth 1_000_000
set_option linter.unusedVariables false
set_option match.ignoreUnusedAlts true

open Sail
open Sail.ConcurrencyInterfaceV1

namespace ArmASL

open ConcurrencyInterfaceV1

namespace Functions

open option
open exception
open arm_acc_type
open __InstrEnc
open WFxType
open VBitOp
open VARange
open Unpredictable
open TMFailure
open TGx
open SystemHintOp
open Signal
open ShiftType
open Shareability
open SecurityState
open SMEExceptionType
open SDFType
open Register
open Regime
open ReduceOp
open PrefetchHint
open PGSe
open PASpace
open PARTIDspaceType
open OpType
open MoveWideOp
open MemType
open MemTagType
open MemOp
open MemAtomicOp
open MBReqTypes
open MBReqDomain
open LogicalOp
open JanusOutcome
open InterruptID
open InstrSet
open ImmediateOp
open GPCF
open GCSInstruction
open Feature
open Fault
open FPUnaryOp
open FPType
open FPRounding
open FPMaxMinOp
open FPExc
open FPConvOp
open ExtendType
open ExceptionalOccurrenceTargetState
open Exception
open ErrorState
open DeviceType
open DescriptorType
open DSBAlias
open CrossTriggerIn
open CountOp
open Constraint
open CompareOp
open CacheType
open CacheOpScope
open CacheOp
open BranchType
open Barrier
open ArchVersion
open AccessType

def __IMPDEF_boolean (x : String) : SailM Bool := do
  (ImpDefBool x)

def IsSecureBelowEL3 (_ : Unit) : SailM Bool := do
  (if ((HaveEL EL3) : Bool)
  then (do (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 0#1)))
  else
    (do (if ((←((pure (HaveEL EL2)) <&&> (do
             (pure (! (← (HaveSecureEL2Ext ())))) <||> (do
               (pure (! (← (HaveAArch64 ())))))))) : Bool)
        then (do (pure false))
        else (do (__IMPDEF_boolean "Secure-only implementation")))))

def ELUsingAArch32 (el : (BitVec 2)) : SailM Bool := do
  (ELStateUsingAArch32 el (← (IsSecureBelowEL3 ())))

def __get_FPCR (value_name : (BitVec 64)) : SailM (BitVec 64) := do
  let tmp : FPCR_Type := value_name
  let tmp : FPCR_Type := (Mk_FPCR_Type (tmp &&& (Complement.complement 0xFFFFFFFFF80040F8#64)))
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Invalid Operation floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x100#12 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Divide by Zero floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x200#12 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Overflow floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x400#12 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Underflow floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x800#12 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Inexact floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x1000#16 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  let tmp ← (( do
    (if ((! (← (__IMPDEF_boolean "IMPLEMENTED_trapping of Input Denormal floating-point exceptions"))) : Bool)
    then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x8000#16 64))))))
    else (do (pure tmp))) ) : SailM (BitVec 64) )
  (if ((← (__IMPDEF_boolean "IMPLEMENTED_FPSCR.LEN,STRIDE as RAZ")) : Bool)
  then (do (pure (Mk_FPCR_Type (tmp &&& (Complement.complement (Sail.BitVec.zeroExtend 0x370000#24 64))))))
  else (do (pure tmp)))

def FPCR_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do (__get_FPCR (← readReg FPCR)) ) : SailM (BitVec 64) )
  (pure (Mk_FPCRType r))

def undefined_FPSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_FPSCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def FPSCR_read__1 (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _FPSCR ) : SailM FPSCR_Type )
  let r ← (pure (Sail.BitVec.updateSubrange r 31 27 (BitVec.slice (← readReg FPSR) 27 5)))
  let r ← (pure (BitVec.update r 7 (Bit (BitVec.slice (← readReg FPSR) 7 1))))
  let r ← (pure (Sail.BitVec.updateSubrange r 4 0 (BitVec.slice (← readReg FPSR) 0 5)))
  let r ← (pure (Sail.BitVec.updateSubrange r 26 15 (BitVec.slice (← readReg FPCR) 15 12)))
  (pure (Sail.BitVec.updateSubrange r 12 8 (BitVec.slice (← readReg FPCR) 8 5)))

def undefined_ERRnFR_ElemType (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_HTRFCR_Type_TS (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 5 x)

def undefined_CTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _update_CTR_Type_CWG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_CTR_Type_DIC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_CTR_EL0_Type_DminLine (v : (BitVec 64)) : (BitVec 4) :=
  (Sail.BitVec.extractLsb v 19 16)

def _update_CTR_Type_DminLine (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def _update_CTR_Type_ERG (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 20 x)

def _update_CTR_Type_IminLine (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 0 x)

def _update_CTR_Type_L1Ip (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 15 14 x)

def getNumBreakpoints (_ : Unit) : SailM Int := do
  (__UNKNOWN_integer ())

def getNumCtxBreakpoints (_ : Unit) : SailM Int := do
  (__UNKNOWN_integer ())

def getNumWatchpoints (_ : Unit) : SailM Int := do
  (__UNKNOWN_integer ())

def ImpDefInt (x : String) : SailM Int := do
  (if ((x == "Number of breakpoints") : Bool)
  then (do (getNumBreakpoints ()))
  else
    (do (if ((x == "Number of watchpoints") : Bool)
        then (do (getNumWatchpoints ()))
        else
          (do (if ((x == "Number of event counters") : Bool)
              then (do readReg NUM_PMU_COUNTERS)
              else
                (do (if ((x == "Number of context-aware breakpoints") : Bool)
                    then (do (getNumCtxBreakpoints ()))
                    else
                      (do (if ((x == "Max implemented VL") : Bool)
                          then (do readReg __max_implemented_sveveclen)
                          else
                            (do (if ((x == "Maximum bytes used in a single block of a copy") : Bool)
                                then (do (pure 1))
                                else
                                  (do (if ((x == "Number of BRB records") : Bool)
                                      then (do readReg NUM_BRBE_RECORDS)
                                      else
                                        (do (if ((x == "SPE Events packet payload size") : Bool)
                                            then (do (pure 4))
                                            else
                                              (do (if ((x == "SPE Data Source packet payload size") : Bool)
                                                  then (do (pure 2))
                                                  else
                                                    (do (if ((x == "Reserved Intermediate Physical Address size value") : Bool)
                                                        then (do (pure 52))
                                                        else
                                                          (do (if ((x == "Maximum Physical Address Size") : Bool)
                                                              then (do readReg __supported_pa_size)
                                                              else
                                                                (do (if ((x == "Block BBM support level") : Bool)
                                                                    then (do readReg __block_bbm_implemented)
                                                                    else
                                                                      (do (if ((x == "SVE Extended BFloat16 instructions are implemented") : Bool)
                                                                          then (do readReg __has_sve_extended_bf16)
                                                                          else
                                                                            (do (if ((x == "Max implemented SVL") : Bool)
                                                                                then (do readReg __max_implemented_smeveclen)
                                                                                else
                                                                                  (do (if ((x == "Data Cache Invalidate Watchpoint Size") : Bool)
                                                                                      then (do (pure (4 *i (2 ^i (BitVec.toNat (_get_CTR_EL0_Type_DminLine (← readReg CTR_EL0)))))))
                                                                                      else
                                                                                        (do (if ((x == "Instruction Cache Invalidate by VA Size") : Bool)
                                                                                            then (do (pure (4 *i (2 ^i (BitVec.toNat (_get_CTR_EL0_Type_DminLine (← readReg CTR_EL0)))))))
                                                                                            else
                                                                                              (do (if ((x == "Linesize for DC SW instructions") : Bool)
                                                                                                  then (do (pure (4 *i (2 ^i (BitVec.toNat (_get_CTR_EL0_Type_DminLine (← readReg CTR_EL0)))))))
                                                                                                  else
                                                                                                    (do (if ((x == "Associativity for DC SW instructions") : Bool)
                                                                                                        then (do (pure 2))
                                                                                                        else
                                                                                                          (do (if ((x == "Numsets for DC SW instructions") : Bool)
                                                                                                              then (do (pure 2))
                                                                                                              else
                                                                                                                (do let _ : Unit := (print_endline (String.append x " is an unrecognized Implementation defined bit."))
                                                                                                                    sail_assert false "sail-arm/arm-v9.4-a/src/impdefs.sail:746.20-746.21"
                                                                                                                    throw Error.Exit))))))))))))))))))))))))))))))))))))))

def __IMPDEF_integer (x : String) : SailM Int := do
  (ImpDefInt x)

def GetNumEventCounters (_ : Unit) : SailM Int := do
  (__IMPDEF_integer "Number of event counters")

def SecureOnlyImplementation (_ : Unit) : SailM Bool := do
  (__IMPDEF_boolean "Secure-only implementation")

def IsSecureEL2Enabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (HaveSecureEL2Ext ())))) : Bool)
  then
    (do (if ((HaveEL EL3) : Bool)
        then
          (do (if ((←((pure (! (← (ELUsingAArch32 EL3)))) <&&> (do
                   (pure ((_get_SCR_EL3_Type_EEL2 (← readReg SCR_EL3)) == 1#1))))) : Bool)
              then (do (pure true))
              else (do (pure false))))
        else (do (SecureOnlyImplementation ()))))
  else (do (pure false)))

def EL2Enabled (_ : Unit) : SailM Bool := do
  (pure (HaveEL EL2)) <&&> (do
    (pure (! (HaveEL EL3))) <||> (do
      (pure ((_get_SCRType_NS (← (SCR_GEN_read ()))) == 1#1))) <||> (do
      (IsSecureEL2Enabled ())))

def undefined_HDCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_HDCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _get_HDCR_Type_HCCD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _update_HDCR_Type_HCCD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _get_MDCR_EL2_Type_HCCD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_HDCR_Type_HPMD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _update_HDCR_Type_HPMD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 17 17 x)

def _get_MDCR_EL2_Type_HPMD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_HDCR_Type_HPME (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_HDCR_Type_HPME (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_MDCR_EL2_Type_HPME (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_HDCR_Type_HPMFZO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_MDCR_EL2_Type_HPMFZO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_HDCR_Type_HPMN (v : (BitVec 32)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _update_HDCR_Type_HPMN (v : (BitVec 32)) (x : (BitVec 5)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 0 x)

def _get_MDCR_EL2_Type_HPMN (v : (BitVec 64)) : (BitVec 5) :=
  (Sail.BitVec.extractLsb v 4 0)

def _update_HDCR_Type_MTPME (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_HDCR_Type_TDA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 9 x)

def _update_EDSCR_Type_TDA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 21 21 x)

def _get_EDSCR_Type_TDA (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_MDCR_EL2_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_MDCR_EL3_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_MDSCR_EL1_Type_TDA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _update_HDCR_Type_TDCC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _get_MDCR_EL2_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_MDCR_EL3_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _get_MDSCR_EL1_Type_TDCC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_HDCR_Type_TDE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HDCR_Type_TDE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 8 8 x)

def _get_MDCR_EL2_Type_TDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _update_HDCR_Type_TDOSA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_MDCR_EL2_Type_TDOSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _get_MDCR_EL3_Type_TDOSA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_HDCR_Type_TDRA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 11 x)

def _update_HDCR_Type_TPM (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_MDCR_EL2_Type_TPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_MDCR_EL3_Type_TPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _update_HDCR_Type_TPMCR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_MDCR_EL2_Type_TPMCR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_HDCR_Type_TTRF (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_MDCR_EL2_Type_TTRF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_MDCR_EL3_Type_TTRF (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_MDCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDCR_EL2_Type_E2PB (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_MDCR_EL2_Type_EBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_MDCR_EL3_Type_EBWE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_MDCR_EL2_Type_EnSPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_MDSCR_EL1_Type_EnSPM (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_MDCR_EL2_Type_TPMS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def HDCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _HDCR ) : SailM HDCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg MDCR_EL2) 0 32)))

def HaveFeatHPMN0 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_HPMN0)

/-- Type quantifiers: high : Int, low : Int -/
def ConstrainUnpredictableInteger (low : Int) (high : Int) (which : Unpredictable) : SailM (Constraint × Int) := do
  (pure ((← (undefined_Constraint ())), (← (undefined_int ()))))

def AArch32_GetNumEventCountersAccessible (_ : Unit) : SailM Int := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let total_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let n ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0))) <&&> (do
         (EL2Enabled ())))) : Bool)
    then
      (do let n ← ((
            (pure (BitVec.toNat
                (← do
                  (if ((! (← (ELUsingAArch32 EL2))) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HPMN (← (HDCR_read ()))))))))) ) : SailM Int )
          (if ((←((pure (n >b total_counters)) <||> (do
               (pure ((! (← (HaveFeatHPMN0 ()))) && (n == 0)))))) : Bool)
          then
            (do let (_, __tup_1) ← do (ConstrainUnpredictableInteger 0 total_counters Unpredictable_PMUEVENTCOUNTER)
                (pure __tup_1))
          else (do (pure n))))
    else (do (pure total_counters))) ) : SailM Int )
  let n := n
  (pure n)

def AArch64_GetNumEventCountersAccessible (_ : Unit) : SailM Int := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let total_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let n ← (( do
    (if ((←((pure ((← readReg PSTATE).EL == EL1)) <||> (do
         (pure ((← readReg PSTATE).EL == EL0))) <&&> (do
         (EL2Enabled ())))) : Bool)
    then
      (do let n ← (( (pure (BitVec.toNat (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2)))) ) : SailM Int )
          (if ((←((pure (n >b total_counters)) <||> (do
               (pure ((! (← (HaveFeatHPMN0 ()))) && (n == 0)))))) : Bool)
          then
            (do let (_, __tup_1) ← do (ConstrainUnpredictableInteger 0 total_counters Unpredictable_PMUEVENTCOUNTER)
                (pure __tup_1))
          else (do (pure n))))
    else (do (pure total_counters))) ) : SailM Int )
  let n := n
  (pure n)

def HavePMUv3ICNTR (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3_ICNTR)

def HaveAArch32 (_ : Unit) : Bool :=
  true

def UsingAArch32 (_ : Unit) : SailM Bool := do
  let aarch32 ← (( do (pure ((← readReg PSTATE).nRW == 1#1)) ) : SailM Bool )
  (if ((! (HaveAArch32 ())) : Bool)
  then (do sail_assert (! aarch32) "sail-arm/arm-v9.4-a/src/v8_base.sail:4029.32-4029.33")
  else (do (pure ())))
  (if ((! (← (HaveAArch64 ()))) : Bool)
  then (do sail_assert aarch32 "sail-arm/arm-v9.4-a/src/v8_base.sail:4032.22-4032.23")
  else (do (pure ())))
  (pure aarch32)

def PMUCounterMask (_ : Unit) : SailM (BitVec 64) := do
  let n ← (( do (undefined_int ()) ) : SailM Int )
  let n ← (( do
    (if ((← (UsingAArch32 ())) : Bool)
    then (do (AArch32_GetNumEventCountersAccessible ()))
    else (do (AArch64_GetNumEventCountersAccessible ()))) ) : SailM Int )
  let n := n
  sail_assert (n ≥b 0) "sail-arm/arm-v9.4-a/src/v8_base.sail:4047.30-4047.31"
  sail_assert (64 ≥b n) "sail-arm/arm-v9.4-a/src/v8_base.sail:4048.31-4048.32"
  let mask : (BitVec 64) := (Sail.BitVec.zeroExtend (Ones (n := n)) 64)
  let mask : (BitVec 64) := (BitVec.update mask CYCLE_COUNTER_ID (Bit 1#1))
  (if ((←((HaveAArch64 ()) <&&> (do
       (HavePMUv3ICNTR ())))) : Bool)
  then (do (pure (BitVec.update mask INSTRUCTION_COUNTER_ID (Bit 1#1))))
  else (do (pure mask)))

def HavePMUv3 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3)

def HaveRME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_RME)

def HaveSecureState (_ : Unit) : SailM Bool := do
  (if ((! (HaveEL EL3)) : Bool)
  then (do (SecureOnlyImplementation ()))
  else
    (do (if ((←((HaveRME ()) <&&> (do
             (pure (! (← (HaveSecureEL2Ext ()))))))) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def EffectiveSCR_EL3_NS (_ : Unit) : SailM (BitVec 1) := do
  (if ((! (← (HaveSecureState ()))) : Bool)
  then (do (pure 1#1))
  else
    (do (if ((! (HaveEL EL3)) : Bool)
        then (do (pure 0#1))
        else (do (pure (_get_SCR_EL3_Type_NS (← readReg SCR_EL3)))))))

def Unreachable (_ : Unit) : SailM Unit := do
  sail_assert false "sail-arm/arm-v9.4-a/src/v8_base.sail:4096.16-4096.17"

def SecurityStateAtEL (EL : (BitVec 2)) : SailM SecurityState := SailME.run do
  let effective_nse_ns ← (( do (undefined_bitvector 2) ) : SailME SecurityState (BitVec 2) )
  (if ((← (HaveRME ())) : Bool)
  then
    (do (if ((EL == EL3) : Bool)
        then (do SailME.throw (SS_Root : SecurityState))
        else
          (do let effective_nse_ns ← (( do (pure ((_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)) +++ (← (EffectiveSCR_EL3_NS ())))) ) : SailME SecurityState (BitVec 2) )
              match effective_nse_ns with
              | 0b00 =>
                (do
                  (if ((← (HaveSecureEL2Ext ())) : Bool)
                  then (do SailME.throw (SS_Secure : SecurityState))
                  else (do (Unreachable ()))))
              | 0b01 => SailME.throw (SS_NonSecure : SecurityState)
              | 0b11 => SailME.throw (SS_Realm : SecurityState)
              | _ => (Unreachable ()))))
  else (do (pure ())))
  (if ((! (HaveEL EL3)) : Bool)
  then
    (do (if ((← (SecureOnlyImplementation ())) : Bool)
        then (do (pure SS_Secure))
        else (do (pure SS_NonSecure))))
  else
    (do (if ((EL == EL3) : Bool)
        then (do (pure SS_Secure))
        else
          (do sail_assert (←((pure (EL != EL2)) <||> (do
                (EL2Enabled ())))) "sail-arm/arm-v9.4-a/src/v8_base.sail:4136.39-4136.40"
              (if ((! (← (ELUsingAArch32 EL3))) : Bool)
              then
                (do (if (((_get_SCR_EL3_Type_NS (← readReg SCR_EL3)) == 1#1) : Bool)
                    then (do (pure SS_NonSecure))
                    else (do (pure SS_Secure))))
              else
                (do (if (((_get_SCR_Type_NS (← readReg SCR)) == 1#1) : Bool)
                    then (do (pure SS_NonSecure))
                    else (do (pure SS_Secure)))))))))

def CurrentSecurityState (_ : Unit) : SailM SecurityState := do
  (SecurityStateAtEL (← readReg PSTATE).EL)

def ExternalInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (pure (BEq.beq (← readReg DBGEN) Signal_High))

def HaveNoninvasiveDebugAuth (_ : Unit) : SailM Bool := do
  (pure (! (← (IsFeatureImplemented FEAT_Debugv8p4))))

def ExternalNoninvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (pure (! (← (HaveNoninvasiveDebugAuth ())))) <||> (do
    (ExternalInvasiveDebugEnabled ())) <||> (do
    (pure (BEq.beq (← readReg NIDEN) Signal_High)))

def ExternalSecureInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure (! (← (SecureOnlyImplementation ()))))))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg SPIDEN) Signal_High)))))

def ExternalSecureNoninvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (! (HaveEL EL3))) <&&> (do
       (pure (! (← (SecureOnlyImplementation ()))))))) : Bool)
  then (do (pure false))
  else
    (do (if ((← (HaveNoninvasiveDebugAuth ())) : Bool)
        then (do (ExternalNoninvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg SPIDEN) Signal_High)) <||> (do (pure (BEq.beq (← readReg SPNIDEN) Signal_High)))))
        else (do (ExternalSecureInvasiveDebugEnabled ())))))

def undefined_EDSCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_EDSCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def _update_EDSCR_Type_ERR (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 6 6 x)

def _get_MDSCR_EL1_Type_ERR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_EDSCR_Type_HDE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _update_EDSCR_Type_HDE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 14 14 x)

def _get_MDSCR_EL1_Type_HDE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_EDSCR_Type_INTdis (v : (BitVec 32)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _update_EDSCR_Type_INTdis (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 22 x)

def _get_MDSCR_EL1_Type_INTdis (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 23 22)

def _update_EDSCR_Type_ITE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_EDSCR_Type_ITO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _update_EDSCR_Type_MA (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 20 20 x)

def _update_EDSCR_Type_RXO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _get_MDSCR_EL1_Type_RXO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 27 27)

def _update_EDSCR_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_DBGDSCRext_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_DBGDSCRint_Type_RXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_MDSCR_EL1_Type_RXfull (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _update_EDSCR_Type_SC2 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 19 x)

def _get_MDSCR_EL1_Type_SC2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def _get_EDSCR_Type_SDD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _update_EDSCR_Type_SDD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 16 16 x)

def _get_MDCR_EL3_Type_SDD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_EDSCR_Type_STATUS (v : (BitVec 32)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _update_EDSCR_Type_STATUS (v : (BitVec 32)) (x : (BitVec 6)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 0 x)

def _update_EDSCR_Type_TFO (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _get_MDSCR_EL1_Type_TFO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 31 31)

def _update_EDSCR_Type_TXU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _get_MDSCR_EL1_Type_TXU (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 26 26)

def _update_EDSCR_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_DBGDSCRext_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_DBGDSCRint_Type_TXfull (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _get_MDSCR_EL1_Type_TXfull (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def undefined_MDCCSR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def EDSCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _EDSCR ) : SailM EDSCR_Type )
  (pure (Sail.BitVec.updateSubrange r 30 29 (BitVec.slice (← readReg MDCCSR_EL0) 29 2)))

def Halted (_ : Unit) : SailM Bool := do
  (pure (! (←((pure ((_get_EDSCR_Type_STATUS (← (EDSCR_read ()))) == 0b000001#6)) <||> (do (pure ((_get_EDSCR_Type_STATUS (← (EDSCR_read ()))) == 0b000010#6)))))))

def HaveHPMDExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p1)

def HaveNoSecurePMUDisableOverride (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_Debugv8p2)

def HavePMUv3p5 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p5)

def HavePMUv3p7 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3p7)

def undefined_PMCNTENCLR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCNTENCLR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMCNTENSET_EL0_Type_F0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def undefined_PMCNTENCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCNTENCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCNTENCLR ) : SailM PMCNTENCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCNTENCLR_EL0) 0 32)))

def undefined_PMCR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMCR_EL0_Type_D (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _update_PMCR_Type_D (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_PMCR_EL0_Type_DP (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _update_ID_ISAR6_Type_DP (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 4 x)

def _update_PMCR_Type_DP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 5 5 x)

def _get_PMCR_Type_DP (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_PMCR_EL0_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_PMCR_Type_E (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_DBGBCR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_DBGWCR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMBLIMITR_EL1_Type_E (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMCR_Type_E (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMCR_EL0_Type_FZO (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_PMCR_Type_FZO (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_PMCR_EL0_Type_IDCODE (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 23 16)

def _update_PMCR_Type_IDCODE (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 16 x)

def _get_PMCR_EL0_Type_IMP (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def _update_PMCR_Type_IMP (v : (BitVec 32)) (x : (BitVec 8)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 24 x)

def _get_PMCR_Type_IMP (v : (BitVec 32)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 31 24)

def _update_PMCR_Type_LP (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_PMCR_EL0_Type_P (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _update_PMCCFILTR_Type_P (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 31 31 x)

def _update_PMCR_Type_P (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_PMCR_Type_X (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 4 4 x)

def undefined_PMCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_PMCR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def PMCR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCR ) : SailM PMCR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCR_EL0) 0 32)))

def undefined_PMINTENCLR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMINTENCLR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMINTENCLR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMINTENCLR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMINTENCLR ) : SailM PMINTENCLR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMINTENCLR_EL1) 0 32)))

def undefined_PMOVSCLR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMOVSCLR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMOVSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMOVSR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMOVSR ) : SailM PMOVSR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMOVSCLR_EL0) 0 32)))

def ConstrainUnpredictableBool (which : Unpredictable) : SailM Bool := do
  (__UNKNOWN_boolean ())

/-- Type quantifiers: n : Int -/
def PMUCounterIsHyp (n : Int) : SailM Bool := do
  (if ((n == INSTRUCTION_COUNTER_ID) : Bool)
  then (do (pure false))
  else
    (do (if ((n == CYCLE_COUNTER_ID) : Bool)
        then (do (pure false))
        else
          (do let resvd_for_el2 ← (( do (undefined_bool ()) ) : SailM Bool )
              (if ((HaveEL EL2) : Bool)
              then
                (do let hpmn_bits ← (( do
                      (if ((← (HaveAArch64 ())) : Bool)
                      then (do (pure (_get_MDCR_EL2_Type_HPMN (← readReg MDCR_EL2))))
                      else (do (pure (_get_HDCR_Type_HPMN (← (HDCR_read ())))))) ) : SailM (BitVec 5) )
                    let resvd_for_el2 : Bool := (n ≥b (BitVec.toNat hpmn_bits))
                    (if ((←((pure ((BitVec.toNat hpmn_bits) >b (← (GetNumEventCounters ())))) <||> (do
                         (pure ((! (← (HaveFeatHPMN0 ()))) && (IsZero hpmn_bits)))))) : Bool)
                    then (do (ConstrainUnpredictableBool Unpredictable_CounterReservedForEL2))
                    else (do (pure resvd_for_el2))))
              else (do (pure false)))))))

/-- Type quantifiers: k_check_cnten : Bool, k_check_e : Bool, k_check_inten : Bool, k_exclude_cyc : Bool, k_exclude_sync : Bool, k_include_hi_name : Bool, k_include_lo_name : Bool -/
def PMUOverflowCondition (check_e : Bool) (check_cnten : Bool) (check_inten : Bool) (include_hi_name : Bool) (include_lo_name : Bool) (exclude_cyc : Bool) (exclude_sync : Bool) : SailM Bool := do
  let counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  let ovsf ← (( do (undefined_bitvector 64) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((← (HaveAArch64 ())) : Bool)
    then
      (do let ovsf ← readReg PMOVSCLR_EL0
          let ovsf : (BitVec 64) := (Sail.BitVec.updateSubrange ovsf 63 33 (Zeros (n := 31)))
          (if ((! (← (HavePMUv3ICNTR ()))) : Bool)
          then (do (pure (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit 0#1))))
          else (do (pure ovsf))))
    else (do (pure (Sail.BitVec.zeroExtend (← (PMOVSR_read ())) 64)))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((counters <b 31) : Bool)
    then
      (do sail_assert ((0 ≤b counters) && (counters ≤b 30)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4603.61-4603.62"
          (pure (Sail.BitVec.updateSubrange ovsf 30 counters (Zeros (n := (31 -i counters))))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    let loop_idx_lower := 0
    let loop_idx_upper := (counters -i 1)
    let mut loop_vars := ovsf
    for idx in [loop_idx_lower:loop_idx_upper:1]i do
      let ovsf := loop_vars
      loop_vars ← do
        let E ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let is_hyp ← (( do (PMUCounterIsHyp idx) ) : SailM Bool )
        let E ← (( do
          (if ((← (HaveAArch64 ())) : Bool)
          then
            (do (if (is_hyp : Bool)
                then (do (pure (_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2))))
                else (do (pure (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0))))))
          else
            (do (if (is_hyp : Bool)
                then (do (pure (_get_HDCR_Type_HPME (← (HDCR_read ())))))
                else (do (pure (_get_PMCR_Type_E (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
        let ovsf ← (( do
          (if (check_e : Bool)
          then
            (do sail_assert ((0 ≤b idx) && (idx <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4615.64-4615.65"
                (pure (BitVec.update ovsf idx (Bit (((BitVec.access ovsf idx) : BitVec 1) &&& E)))))
          else (do (pure ovsf))) ) : SailM (BitVec 64) )
        (if ((((! is_hyp) && (! include_lo_name)) || (is_hyp && (! include_hi_name))) : Bool)
        then
          (do sail_assert ((0 ≤b idx) && (idx <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4619.64-4619.65"
              (pure (BitVec.update ovsf idx (Bit 0#1))))
        else (do (pure ovsf)))
    (pure loop_vars) ) : SailM (BitVec 64) )
  let ovsf : (BitVec 64) :=
    if ((exclude_cyc || (! include_lo_name)) : Bool)
    then (BitVec.update ovsf CYCLE_COUNTER_ID (Bit 0#1))
    else ovsf
  let ovsf ← (( do
    (if (check_e : Bool)
    then (do (pure (BitVec.update ovsf CYCLE_COUNTER_ID (Bit (((BitVec.access ovsf CYCLE_COUNTER_ID) : BitVec 1) &&& (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)))))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if ((←((HaveAArch64 ()) <&&> (do
         (HavePMUv3ICNTR ())))) : Bool)
    then
      (do let ovsf : (BitVec 64) :=
            if ((! include_lo_name) : Bool)
            then (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit 0#1))
            else ovsf
          (if (check_e : Bool)
          then (do (pure (BitVec.update ovsf INSTRUCTION_COUNTER_ID (Bit (((BitVec.access ovsf INSTRUCTION_COUNTER_ID) : BitVec 1) &&& (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)))))))
          else (do (pure ovsf))))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if (check_cnten : Bool)
    then
      (do let cnten ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do readReg PMCNTENCLR_EL0)
            else (do (pure (Sail.BitVec.zeroExtend (← (PMCNTENCLR_read ())) 64)))) ) : SailM (BitVec 64) )
          (pure (ovsf &&& cnten)))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  let ovsf ← (( do
    (if (check_inten : Bool)
    then
      (do let inten ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do readReg PMINTENCLR_EL1)
            else (do (pure (Sail.BitVec.zeroExtend (← (PMINTENCLR_read ())) 64)))) ) : SailM (BitVec 64) )
          (pure (ovsf &&& inten)))
    else (do (pure ovsf))) ) : SailM (BitVec 64) )
  (pure (! (IsZero ovsf)))

/-- Type quantifiers: k_resvd_for_el2 : Bool -/
def HiLoPMUOverflow (resvd_for_el2 : Bool) : SailM Bool := do
  let check_cnten : Bool := false
  let check_e : Bool := false
  let check_inten : Bool := false
  let include_lo_name : Bool := (! resvd_for_el2)
  let include_hi_name : Bool := resvd_for_el2
  let exclude_cyc : Bool := false
  let exclude_sync : Bool := false
  (PMUOverflowCondition check_e check_cnten check_inten include_hi_name include_lo_name exclude_cyc exclude_sync)

def undefined_MDCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_MDCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_MDCR_EL3_Type_E3BREC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_MDCR_EL3_Type_E3BREW (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_MDCR_EL3_Type_EnPM2 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_MDCR_EL3_Type_EnPMS3 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_MDCR_EL3_Type_EnPMSN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_MDCR_EL3_Type_EnPMSS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_MDCR_EL3_Type_MCCD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_MDCR_EL3_Type_MPMX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_MDCR_EL3_Type_NSPB (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_MDCR_EL3_Type_NSPBE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_MDCR_EL3_Type_SBRBE (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 33 32)

def _get_MDCR_EL3_Type_SCCD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_SDCR_Type_SCCD (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_MDCR_EL3_Type_SPME (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_SDCR_Type_SPME (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def undefined_PMCCFILTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCCFILTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_PMCCFILTR_Type_NSH (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _update_PMCCFILTR_Type_NSK (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 29 x)

def _update_PMCCFILTR_Type_NSU (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_GPCCR_EL3_Type_SH (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _update_ICH_MISR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _update_MPIDR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_PMCCFILTR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _update_VMPIDR_Type_U (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def undefined_PMCCFILTR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_PMCCFILTR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def PMCCFILTR_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCCFILTR ) : SailM PMCCFILTR_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCCFILTR_EL0) 0 32)))

def undefined_PMCNTENSET_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMCNTENSET_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMCNTENSET_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def PMCNTENSET_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _PMCNTENSET ) : SailM PMCNTENSET_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg PMCNTENSET_EL0) 0 32)))

def undefined_PMEVTYPER_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMEVTYPER_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_MPIDR_Type_MT (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_VMPIDR_Type_MT (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _update_ICH_HCR_Type_TC (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 10 10 x)

def _get_ICH_HCR_EL2_Type_TC (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 10 10)

def _update_SCTLR_Type_TE (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 30 30 x)

def _get_HSCTLR_Type_TE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_SCTLR_Type_TE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_PMEVTYPER_EL0_Type_evtCount (v : (BitVec 64)) : (BitVec 16) :=
  ((Sail.BitVec.extractLsb v 15 10) +++ (Sail.BitVec.extractLsb v 9 0))

def _get_PMEVTYPER_Type_evtCount (v : (BitVec 32)) : (BitVec 16) :=
  ((Sail.BitVec.extractLsb v 15 10) +++ (Sail.BitVec.extractLsb v 9 0))

def undefined_PMEVTYPER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

/-- Type quantifiers: n : Nat, 0 ≤ n ∧ n < 31 -/
def PMEVTYPER_read (n : Nat) : SailM (BitVec 32) := do
  let r ← (( do (pure (GetElem?.getElem! (← readReg _PMEVTYPER) n)) ) : SailM PMEVTYPER_Type )
  (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (GetElem?.getElem! (← readReg PMEVTYPER_EL0) n) 0 32)))

def undefined_PMICFILTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMICFILTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_SDCR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def undefined_SDER32_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SDER32_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_SDER_Type_SUIDEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 0 0 x)

def _get_SDER32_EL3_Type_SUIDEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _update_SDER_Type_SUNIDEN (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 1 1 x)

def _get_SDER32_EL3_Type_SUNIDEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_SDER_Type_SUNIDEN (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_SDER32_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_SDER32_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def SDER32_EL3_read (_ : Unit) : SailM (BitVec 64) := do
  let r ← (( do readReg _SDER32_EL3 ) : SailM SDER32_EL3_Type )
  (pure (Sail.BitVec.updateSubrange r 63 0 (BitVec.slice (← readReg SDER32_EL2) 0 64)))

def undefined_SDER_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_SDER_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def SDER_read (_ : Unit) : SailM (BitVec 32) := do
  let r ← (( do readReg _SDER ) : SailM SDER_Type )
  (if ((HaveEL EL3) : Bool)
  then (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← (SDER32_EL3_read ())) 0 32))))
  else (do (pure (Sail.BitVec.updateSubrange r 31 0 (BitVec.slice (← readReg SDER32_EL2) 0 32)))))

/-- Type quantifiers: idx : Nat, 0 ≤ idx ∧ idx ≤ 32 -/
def CountPMUEvents (idx : Nat) : SailM Bool := do
  let dp ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let hccd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let hpmd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let sccd ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let num_counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
  sail_assert (←((pure ((idx == CYCLE_COUNTER_ID) || (idx <b num_counters))) <||> (do
    (pure (idx == INSTRUCTION_COUNTER_ID)) <&&> (do
      (HavePMUv3ICNTR ()))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:4945.108-4945.109"
  let enabled ← (( do (undefined_bool ()) ) : SailM Bool )
  let filtered ← (( do (undefined_bool ()) ) : SailM Bool )
  let E ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let debug ← (( do (Halted ()) ) : SailM Bool )
  let resvd_for_el2 ← (( do (PMUCounterIsHyp idx) ) : SailM Bool )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let enabled ← (( do
    let questionMark := idx
    (if ((questionMark == INSTRUCTION_COUNTER_ID) : Bool)
    then
      (do sail_assert (← (HaveAArch64 ())) "sail-arm/arm-v9.4-a/src/v8_base.sail:4954.30-4954.31"
          (pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 1#1)) <&&> (do
            (pure ((_get_PMCNTENSET_EL0_Type_F0 (← readReg PMCNTENSET_EL0)) == 1#1))))
    else
      (do (if ((questionMark == CYCLE_COUNTER_ID) : Bool)
          then
            (do (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 1#1)) <&&> (do (pure ((_get_PMCNTENSET_EL0_Type_C (← readReg PMCNTENSET_EL0)) == 1#1))))
                else (do (pure ((_get_PMCR_Type_E (← (PMCR_read ()))) == 1#1)) <&&> (do (pure ((_get_PMCNTENSET_Type_C (← (PMCNTENSET_read ()))) == 1#1))))))
          else
            (do let E ← (( do
                  (if (resvd_for_el2 : Bool)
                  then
                    (do (if ((← (HaveAArch64 ())) : Bool)
                        then (do (pure (_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2))))
                        else (do (pure (_get_HDCR_Type_HPME (← (HDCR_read ())))))))
                  else
                    (do (if ((← (HaveAArch64 ())) : Bool)
                        then (do (pure (_get_PMCR_EL0_Type_E (← readReg PMCR_EL0))))
                        else (do (pure (_get_PMCR_Type_E (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
                (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure (E == 1#1)) <&&> (do (pure (((BitVec.access (← readReg PMCNTENSET_EL0) idx) : BitVec 1) == 1#1))))
                else
                  (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:4973.56-4973.57"
                      (pure (E == 1#1)) <&&> (do
                        (pure (((BitVec.access (← (PMCNTENSET_read ())) idx) : BitVec 1) == 1#1))))))))) ) : SailM Bool )
  let prohibited : Bool := false
  let prohibited ← (( do
    (if (((HaveEL EL3) && (BEq.beq ss SS_Secure)) : Bool)
    then
      (do let prohibited ← (( do
            (if ((! (← (ELUsingAArch32 EL3))) : Bool)
            then (do (pure ((_get_MDCR_EL3_Type_SPME (← readReg MDCR_EL3)) == 0#1)) <&&> (do (HavePMUv3p7 ())) <&&> (do (pure ((_get_MDCR_EL3_Type_MPMX (← readReg MDCR_EL3)) == 0#1))))
            else (do (pure ((_get_SDCR_Type_SPME (← readReg SDCR)) == 0#1)))) ) : SailM Bool )
          (if ((←((pure prohibited) <&&> (do
               (pure ((← readReg PSTATE).EL == EL0))))) : Bool)
          then
            (do (if ((← (ELUsingAArch32 EL3)) : Bool)
                then (do (pure ((_get_SDER_Type_SUNIDEN (← (SDER_read ()))) == 0#1)))
                else
                  (do (if ((← (ELUsingAArch32 EL1)) : Bool)
                      then (do (pure ((_get_SDER32_EL3_Type_SUNIDEN (← (SDER32_EL3_read ()))) == 0#1)))
                      else (do (pure prohibited))))))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if ((←((pure (! prohibited)) <&&> (do
         (HavePMUv3p7 ())) <&&> (do
         (pure ((← readReg PSTATE).EL == EL3))) <&&> (do
         (HaveAArch64 ())))) : Bool)
    then (do (pure ((_get_MDCR_EL3_Type_MPMX (← readReg MDCR_EL3)) == 1#1)) <&&> (do (pure (((_get_MDCR_EL3_Type_SPME (← readReg MDCR_EL3)) == 0#1) || (! resvd_for_el2)))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if (((←((pure (! prohibited)) <&&> (do
           (pure ((← readReg PSTATE).EL == EL2))) <&&> (do
           (HaveHPMDExt ())))) && (! resvd_for_el2)) : Bool)
    then
      (do let hpmd ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do (pure (_get_MDCR_EL2_Type_HPMD (← readReg MDCR_EL2))))
            else (do (pure (_get_HDCR_Type_HPMD (← (HDCR_read ())))))) ) : SailM (BitVec 1) )
          (pure (hpmd == 1#1)))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if ((←((pure prohibited) <&&> (do
         (pure (! (← (HaveNoSecurePMUDisableOverride ()))))))) : Bool)
    then (do (pure (! (← (ExternalSecureNoninvasiveDebugEnabled ())))))
    else (do (pure prohibited))) ) : SailM Bool )
  let frozen : Bool := false
  let frozen ← (( do
    (if ((← (HavePMUv3p7 ())) : Bool)
    then
      (do let FZ ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
          let FZ ← (( do
            (if (resvd_for_el2 : Bool)
            then
              (do (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HPMFZO (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HPMFZO (← (HDCR_read ())))))))
            else
              (do (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_PMCR_EL0_Type_FZO (← readReg PMCR_EL0))))
                  else (do (pure (_get_PMCR_Type_FZO (← (PMCR_read ())))))))) ) : SailM (BitVec 1) )
          (pure (FZ == 1#1)) <&&> (do
            (HiLoPMUOverflow resvd_for_el2)))
    else (do (pure frozen))) ) : SailM Bool )
  let (enabled, frozen, prohibited) ← (( do
    (if (((prohibited || frozen) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do let dp ← (( do
            (if ((← (HaveAArch64 ())) : Bool)
            then (do (pure (_get_PMCR_EL0_Type_DP (← readReg PMCR_EL0))))
            else (do (pure (_get_PMCR_Type_DP (← (PMCR_read ())))))) ) : SailM (BitVec 1) )
          let enabled : Bool := (enabled && (dp == 0#1))
          let prohibited : Bool := false
          let frozen : Bool := false
          (pure (enabled, frozen, prohibited)))
    else (do (pure (enabled, frozen, prohibited)))) ) : SailM (Bool × Bool × Bool) )
  let prohibited ← (( do
    (if (((← (HavePMUv3p5 ())) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do let prohibited ← (( do
            (if (((HaveEL EL3) && (BEq.beq ss SS_Secure)) : Bool)
            then
              (do let sccd ← (( do
                    (if ((← (HaveAArch64 ())) : Bool)
                    then (do (pure (_get_MDCR_EL3_Type_SCCD (← readReg MDCR_EL3))))
                    else (do (pure (_get_SDCR_Type_SCCD (← readReg SDCR))))) ) : SailM (BitVec 1) )
                  (if ((sccd == 1#1) : Bool)
                  then (do (pure true))
                  else (do (pure prohibited))))
            else (do (pure prohibited))) ) : SailM Bool )
          (if (((← readReg PSTATE).EL == EL2) : Bool)
          then
            (do let hccd ← (( do
                  (if ((← (HaveAArch64 ())) : Bool)
                  then (do (pure (_get_MDCR_EL2_Type_HCCD (← readReg MDCR_EL2))))
                  else (do (pure (_get_HDCR_Type_HCCD (← (HDCR_read ())))))) ) : SailM (BitVec 1) )
                (if ((hccd == 1#1) : Bool)
                then (do (pure true))
                else (do (pure prohibited))))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let prohibited ← (( do
    (if (((← (HavePMUv3p7 ())) && (idx == CYCLE_COUNTER_ID)) : Bool)
    then
      (do (if ((←((pure ((← readReg PSTATE).EL == EL3)) <&&> (do
               (HaveAArch64 ())) <&&> (do
               (pure ((_get_MDCR_EL3_Type_MCCD (← readReg MDCR_EL3)) == 1#1))))) : Bool)
          then (do (pure true))
          else (do (pure prohibited))))
    else (do (pure prohibited))) ) : SailM Bool )
  let filter ← (( do (undefined_bitvector 32) ) : SailM (BitVec 32) )
  let filter ← (( do
    let questionMark := idx
    (if ((questionMark == INSTRUCTION_COUNTER_ID) : Bool)
    then (do (pure (Sail.BitVec.extractLsb (← readReg PMICFILTR_EL0) 31 0)))
    else
      (do (if ((questionMark == CYCLE_COUNTER_ID) : Bool)
          then
            (do (if ((← (HaveAArch64 ())) : Bool)
                then (do (pure (Sail.BitVec.extractLsb (← readReg PMCCFILTR_EL0) 31 0)))
                else (do (PMCCFILTR_read ()))))
          else
            (do (if ((← (HaveAArch64 ())) : Bool)
                then
                  (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5058.56-5058.57"
                      (pure (Sail.BitVec.extractLsb (GetElem?.getElem! (← readReg PMEVTYPER_EL0) idx) 31 0)))
                else
                  (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5061.56-5061.57"
                      (PMEVTYPER_read idx))))))) ) : SailM (BitVec 32) )
  let filter := filter
  let P : (BitVec 1) := ((BitVec.access filter 31) : BitVec 1)
  let U : (BitVec 1) := ((BitVec.access filter 30) : BitVec 1)
  let NSK : (BitVec 1) :=
    if ((HaveEL EL3) : Bool)
    then ((BitVec.access filter 29) : BitVec 1)
    else 0#1
  let NSU : (BitVec 1) :=
    if ((HaveEL EL3) : Bool)
    then ((BitVec.access filter 28) : BitVec 1)
    else 0#1
  let NSH : (BitVec 1) :=
    if ((HaveEL EL2) : Bool)
    then ((BitVec.access filter 27) : BitVec 1)
    else 0#1
  let M ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (HaveAArch64 ())))) : Bool)
    then (do (pure ((BitVec.access filter 26) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let SH ← (( do
    (if ((←((pure (HaveEL EL3)) <&&> (do
         (HaveSecureEL2Ext ())))) : Bool)
    then (do (pure ((BitVec.access filter 24) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLK ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 22) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLU ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 21) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let RLH ← (( do
    (if ((← (HaveRME ())) : Bool)
    then (do (pure ((BitVec.access filter 20) : BitVec 1)))
    else (do (pure 0#1))) ) : SailM (BitVec 1) )
  let ss ← (( do (CurrentSecurityState ()) ) : SailM SecurityState )
  let filtered ← (( do
    let questionMark ← do (pure (← readReg PSTATE).EL)
    (if ((questionMark == EL0) : Bool)
    then
      (do match ss with
          | .SS_NonSecure => (pure (U != NSU))
          | .SS_Secure => (pure (U == 1#1))
          | .SS_Realm => (pure (U != RLU))
          | _ => (pure filtered))
    else
      (do (if ((questionMark == EL1) : Bool)
          then
            (do match ss with
                | .SS_NonSecure => (pure (P != NSK))
                | .SS_Secure => (pure (P == 1#1))
                | .SS_Realm => (pure (P != RLK))
                | _ => (pure filtered))
          else
            (do (if ((questionMark == EL2) : Bool)
                then
                  (do match ss with
                      | .SS_NonSecure => (pure (NSH == 0#1))
                      | .SS_Secure => (pure (NSH == SH))
                      | .SS_Realm => (pure (NSH == RLH))
                      | _ => (pure filtered))
                else
                  (do (if ((questionMark == EL3) : Bool)
                      then
                        (do (if ((← (HaveAArch64 ())) : Bool)
                            then (do (pure (M != P)))
                            else (do (pure (P == 1#1)))))
                      else (do (pure filtered))))))))) ) : SailM Bool )
  (pure (((((! debug) && enabled) && (! prohibited)) && (! filtered)) && (! frozen)))

def undefined_PMICNTR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMICNTR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMOVSSET_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMOVSSET_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

/-- Type quantifiers: increment_name : Int -/
def IncrementInstructionCounter (increment_name : Int) : SailM Unit := do
  (if ((← (CountPMUEvents INSTRUCTION_COUNTER_ID)) : Bool)
  then
    (do let old_value ← (( do (pure (BitVec.toNat (← readReg PMICNTR_EL0))) ) : SailM Int )
        let new_value := (old_value +i increment_name)
        writeReg PMICNTR_EL0 (Mk_PMICNTR_EL0_Type (integer_subrange new_value 63 0))
        (if ((((integer_access old_value 64) : BitVec 1) != ((integer_access new_value 64) : BitVec 1)) : Bool)
        then
          (do writeReg PMOVSSET_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSSET_EL0) 32 32 1#1)
              writeReg PMOVSCLR_EL0 (Sail.BitVec.updateSubrange (← readReg PMOVSCLR_EL0) 32 32 1#1))
        else (do (pure ()))))
  else (do (pure ())))

def HaveStatisticalProfilingv1p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPEv1p1)

def HaveStatisticalProfilingv1p4 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPEv1p4)

def SPEEvent (pmuevent : (BitVec 16)) : SailM Unit := SailME.run do
  let questionMark := pmuevent
  (if ((questionMark == PMU_EVENT_DSNP_HIT_RD) : Bool)
  then
    (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 23 (Bit 1#1)))
        else (do (pure ()))))
  else
    (do (if ((questionMark == PMU_EVENT_L1D_LFB_HIT_RD) : Bool)
        then
          (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
              else (do (pure ()))))
        else
          (do (if ((questionMark == PMU_EVENT_L2D_LFB_HIT_RD) : Bool)
              then
                (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                    else (do (pure ()))))
              else
                (do (if ((questionMark == PMU_EVENT_L3D_LFB_HIT_RD) : Bool)
                    then
                      (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                          else (do (pure ()))))
                    else
                      (do (if ((questionMark == PMU_EVENT_LL_LFB_HIT_RD) : Bool)
                          then
                            (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 22 (Bit 1#1)))
                                else (do (pure ()))))
                          else
                            (do (if ((questionMark == PMU_EVENT_L1D_CACHE_HITM_RD) : Bool)
                                then
                                  (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                      else (do (pure ()))))
                                else
                                  (do (if ((questionMark == PMU_EVENT_L2D_CACHE_HITM_RD) : Bool)
                                      then
                                        (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                            else (do (pure ()))))
                                      else
                                        (do (if ((questionMark == PMU_EVENT_L3D_CACHE_HITM_RD) : Bool)
                                            then
                                              (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                                  else (do (pure ()))))
                                            else
                                              (do (if ((questionMark == PMU_EVENT_LL_CACHE_HITM_RD) : Bool)
                                                  then
                                                    (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 21 (Bit 1#1)))
                                                        else (do (pure ()))))
                                                  else
                                                    (do (if ((questionMark == PMU_EVENT_L2D_CACHE_LMISS_RD) : Bool)
                                                        then
                                                          (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 20 (Bit 1#1)))
                                                              else (do (pure ()))))
                                                        else
                                                          (do (if ((questionMark == PMU_EVENT_L2D_CACHE_RD) : Bool)
                                                              then
                                                                (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 19 (Bit 1#1)))
                                                                    else (do (pure ()))))
                                                              else
                                                                (do (if ((questionMark == PMU_EVENT_SVE_PRED_EMPTY_SPEC) : Bool)
                                                                    then
                                                                      (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 18 (Bit 1#1)))
                                                                          else (do (pure ()))))
                                                                    else
                                                                      (do (if ((questionMark == PMU_EVENT_SVE_PRED_PARTIAL_SPEC) : Bool)
                                                                          then
                                                                            (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                                then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 17 (Bit 1#1)))
                                                                                else (do (pure ()))))
                                                                          else
                                                                            (do (if ((questionMark == PMU_EVENT_LDST_ALIGN_LAT) : Bool)
                                                                                then
                                                                                  (do (if ((← (HaveStatisticalProfilingv1p1 ())) : Bool)
                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 11 (Bit 1#1)))
                                                                                      else (do (pure ()))))
                                                                                else
                                                                                  (do (if ((questionMark == PMU_EVENT_REMOTE_ACCESS) : Bool)
                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 10 (Bit 1#1)))
                                                                                      else
                                                                                        (do (if ((questionMark == PMU_EVENT_LL_CACHE_MISS) : Bool)
                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 9 (Bit 1#1)))
                                                                                            else
                                                                                              (do (if ((questionMark == PMU_EVENT_LL_CACHE) : Bool)
                                                                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 8 (Bit 1#1)))
                                                                                                  else
                                                                                                    (do (if ((questionMark == PMU_EVENT_BR_MIS_PRED) : Bool)
                                                                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 7 (Bit 1#1)))
                                                                                                        else
                                                                                                          (do (if ((questionMark == PMU_EVENT_BR_MIS_PRED_RETIRED) : Bool)
                                                                                                              then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 7 (Bit 1#1)))
                                                                                                              else
                                                                                                                (do (if ((questionMark == PMU_EVENT_DTLB_WALK) : Bool)
                                                                                                                    then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 5 (Bit 1#1)))
                                                                                                                    else
                                                                                                                      (do (if ((questionMark == PMU_EVENT_L1D_TLB) : Bool)
                                                                                                                          then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 4 (Bit 1#1)))
                                                                                                                          else
                                                                                                                            (do (if ((questionMark == PMU_EVENT_L1D_CACHE_REFILL) : Bool)
                                                                                                                                then
                                                                                                                                  (do (if ((! (← (HaveStatisticalProfilingv1p4 ()))) : Bool)
                                                                                                                                      then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 3 (Bit 1#1)))
                                                                                                                                      else (do (pure ()))))
                                                                                                                                else
                                                                                                                                  (do (if ((questionMark == PMU_EVENT_L1D_CACHE_LMISS_RD) : Bool)
                                                                                                                                      then
                                                                                                                                        (do (if ((← (HaveStatisticalProfilingv1p4 ())) : Bool)
                                                                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 3 (Bit 1#1)))
                                                                                                                                            else (do (pure ()))))
                                                                                                                                      else
                                                                                                                                        (do (if ((questionMark == PMU_EVENT_L1D_CACHE) : Bool)
                                                                                                                                            then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 2 (Bit 1#1)))
                                                                                                                                            else
                                                                                                                                              (do (if ((questionMark == PMU_EVENT_INST_RETIRED) : Bool)
                                                                                                                                                  then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 1 (Bit 1#1)))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((questionMark == PMU_EVENT_EXC_TAKEN) : Bool)
                                                                                                                                                        then (do writeReg SPESampleEvents (BitVec.update (← readReg SPESampleEvents) 0 (Bit 1#1)))
                                                                                                                                                        else (do SailME.throw (() : Unit)))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- Type quantifiers: idx : Int, increment_name : Int -/
def PMUEvent__2 (pmuevent : (BitVec 16)) (increment_name : Int) (idx : Int) : SailM Unit := do
  (if ((! (← (HavePMUv3 ()))) : Bool)
  then (do (pure ()))
  else
    (do (if ((← (UsingAArch32 ())) : Bool)
        then
          (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5380.50-5380.51"
              (if (((_get_PMEVTYPER_Type_evtCount (← (PMEVTYPER_read idx))) == pmuevent) : Bool)
              then (do writeReg PMUEventAccumulator (vectorUpdate (← readReg PMUEventAccumulator) idx ((GetElem?.getElem! (← readReg PMUEventAccumulator) idx) +i increment_name)))
              else (do (pure ()))))
        else
          (do sail_assert ((0 ≤b idx) && (idx <b 32)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5386.50-5386.51"
              (if (((_get_PMEVTYPER_EL0_Type_evtCount (GetElem?.getElem! (← readReg PMEVTYPER_EL0) idx)) == pmuevent) : Bool)
              then
                (do sail_assert ((0 ≤b idx) && (idx <b 31)) "sail-arm/arm-v9.4-a/src/v8_base.sail:5388.54-5388.55"
                    writeReg PMUEventAccumulator (vectorUpdate (← readReg PMUEventAccumulator) idx ((GetElem?.getElem! (← readReg PMUEventAccumulator) idx) +i increment_name)))
              else (do (pure ())))))))

/-- Type quantifiers: increment_name : Int -/
def PMUEvent__1 (pmuevent : (BitVec 16)) (increment_name : Int) : SailM Unit := do
  (if ((← readReg SPESampleInFlight) : Bool)
  then (do (SPEEvent pmuevent))
  else (do (pure ())))
  (if ((←((pure ((_get_PMCR_EL0_Type_E (← readReg PMCR_EL0)) == 0#1)) <&&> (do
       (pure ((_get_MDCR_EL2_Type_HPME (← readReg MDCR_EL2)) == 0#1))))) : Bool)
  then (do (pure ()))
  else
    (do let counters ← (( do (GetNumEventCounters ()) ) : SailM Int )
        (if ((counters != 0) : Bool)
        then
          (do let loop_idx_lower := 0
              let loop_idx_upper := (counters -i 1)
              let mut loop_vars := ()
              for idx in [loop_idx_lower:loop_idx_upper:1]i do
                let () := loop_vars
                loop_vars ← do (PMUEvent__2 pmuevent increment_name idx)
              (pure loop_vars))
        else (do (pure ())))
        (if (((←((HaveAArch64 ()) <&&> (do
               (HavePMUv3ICNTR ())))) && (pmuevent == PMU_EVENT_INST_RETIRED)) : Bool)
        then (do (IncrementInstructionCounter increment_name))
        else (do (pure ())))))

def PMUEvent (pmuevent : (BitVec 16)) : SailM Unit := do
  (PMUEvent__1 pmuevent 1)

def HavePMUv3TH (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PMUv3_TH)

/-- Type quantifiers: width : Nat, width ≥ 0 -/
def ConstrainUnpredictableBits (which : Unpredictable) (width : Nat) : SailM (Constraint × (BitVec width)) := do
  (pure ((← (undefined_Constraint ())), (← (undefined_bitvector width))))

def undefined_BRBCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBCR_EL1_Type_E0BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_BRBCR_EL1_Type_E1BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_BRBCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBCR_EL2_Type_E0HBRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_BRBCR_EL2_Type_E2BRE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_BRBFCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBFCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_BRBFCR_EL1_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _get_MDSELR_EL1_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 5 4)

def _get_SPMSELR_EL0_Type_BANK (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 1 0)

def _get_BRBFCR_EL1_Type_CONDDIR (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_BRBFCR_EL1_Type_DIRCALL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_BRBFCR_EL1_Type_DIRECT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def _get_BRBFCR_EL1_Type_EnI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_BRBFCR_EL1_Type_INDCALL (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_BRBFCR_EL1_Type_INDIRECT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 18 18)

def _get_BRBFCR_EL1_Type_PAUSED (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_BRBFCR_EL1_Type_RTN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 19 19)

def undefined_BRBTS_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_BRBTS_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def PhysicalCountInt (_ : Unit) : SailM (BitVec 64) := do
  (pure (Sail.BitVec.extractLsb (← readReg PhysicalCount) 87 24))

def undefined_CNTHCTL_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_CNTHCTL_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_CNTHCTL_EL2_Type_ECV (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 12 12)

def _get_CNTHCTL_EL2_Type_EL0PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_CNTKCTL_EL1_Type_EL0PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 9 9)

def _get_CNTHCTL_EL2_Type_EL0VTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_CNTKCTL_EL1_Type_EL0VTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 8 8)

def _get_CNTHCTL_EL2_Type_EL1NVPCT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 15 15)

def _get_CNTHCTL_EL2_Type_EL1NVVCT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 16 16)

def _get_CNTHCTL_EL2_Type_EL1PCEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_CNTHCTL_EL2_Type_EL1PTEN (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_CNTHCTL_EL2_Type_EL1TVT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 13 13)

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def ImpDefBits (x : String) (N : Nat) : SailM (BitVec N) := do
  (if ((x == "Coresight timestamp") : Bool)
  then
    (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/impdefs.sail:759.54-759.55"
        (pure (Sail.BitVec.extractLsb (← (PhysicalCountInt ())) (N -i 1) 0)))
  else
    (do (if ((x == "Synchronous Error") : Bool)
        then
          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:762.53-762.54"
              (pure (Sail.BitVec.extractLsb 0b00#2 (N -i 1) 0)))
        else
          (do (if ((x == "Asynchronous Error") : Bool)
              then
                (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:765.53-765.54"
                    (pure (Sail.BitVec.extractLsb 0b11#2 (N -i 1) 0)))
              else
                (do (if ((x == "Virtual Asynchronous Abort ExT bit") : Bool)
                    then (do (pure (Zeros (n := N))))
                    else
                      (do (if ((x == "FPEXC.EN value when TGE==1 and RW==0") : Bool)
                          then
                            (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:770.38-770.39"
                                (pure (integer_subrange 1 (N -i 1) 0)))
                          else
                            (do (if ((x == "reset vector address") : Bool)
                                then
                                  (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 64)) "sail-arm/arm-v9.4-a/src/impdefs.sail:773.54-773.55"
                                      (pure (Sail.BitVec.extractLsb (← readReg CFG_RVBAR) (N -i 1) 0)))
                                else
                                  (do (if ((x == "TG0 encoded granule size") : Bool)
                                      then
                                        (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:776.53-776.54"
                                            (pure (Sail.BitVec.extractLsb (← readReg __impdef_TG0) (N -i 1) 0)))
                                      else
                                        (do (if ((x == "TG1 encoded granule size") : Bool)
                                            then
                                              (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 2)) "sail-arm/arm-v9.4-a/src/impdefs.sail:779.53-779.54"
                                                  (pure (Sail.BitVec.extractLsb (← readReg __impdef_TG1) (N -i 1) 0)))
                                            else
                                              (do (if ((x == "Reserved short descriptor AP encoding") : Bool)
                                                  then
                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:782.38-782.39"
                                                        (pure (integer_subrange (BitVec.toNat 0b101#3) (N -i 1) 0)))
                                                  else
                                                    (do (if ((x == "Non-Faulting PAR") : Bool)
                                                        then
                                                          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:785.53-785.54"
                                                              (pure (Sail.BitVec.extractLsb 0#1 (N -i 1) 0)))
                                                        else
                                                          (do (if ((x == "Faulting PAR") : Bool)
                                                              then (do (pure (Zeros (n := N))))
                                                              else
                                                                (do (if ((x == "SPE mask 10:8,4,2") : Bool)
                                                                    then
                                                                      (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 5)) "sail-arm/arm-v9.4-a/src/impdefs.sail:790.53-790.54"
                                                                          (pure (Sail.BitVec.extractLsb 0b11111#5 (N -i 1) 0)))
                                                                    else
                                                                      (do (if ((x == "MPAM version") : Bool)
                                                                          then
                                                                            (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:793.38-793.39"
                                                                                (pure (integer_subrange (BitVec.toNat (← readReg __mpam_major)) (N -i 1) 0)))
                                                                          else
                                                                            (do (if ((x == "MPAM maximum PARTID") : Bool)
                                                                                then
                                                                                  (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:796.38-796.39"
                                                                                      (pure (integer_subrange (BitVec.toNat (← readReg __mpam_partid_max)) (N -i 1) 0)))
                                                                                else
                                                                                  (do (if ((x == "MPAM maximum PMG") : Bool)
                                                                                      then
                                                                                        (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:799.38-799.39"
                                                                                            (pure (integer_subrange (BitVec.toNat (← readReg __mpam_pmg_max)) (N -i 1) 0)))
                                                                                      else
                                                                                        (do (if ((x == "Has MPAMHCR_EL2") : Bool)
                                                                                            then
                                                                                              (do (if ((← readReg __mpam_has_hcr) : Bool)
                                                                                                  then
                                                                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:803.42-803.43"
                                                                                                        (pure (integer_subrange 1 (N -i 1) 0)))
                                                                                                  else (do (pure (Zeros (n := N))))))
                                                                                            else
                                                                                              (do (if ((x == "MPAM maximum VPMR") : Bool)
                                                                                                  then
                                                                                                    (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:807.38-807.39"
                                                                                                        (pure (integer_subrange (BitVec.toNat (← readReg __mpam_vpmr_max)) (N -i 1) 0)))
                                                                                                  else
                                                                                                    (do (if ((x == "SPE mask 63:48") : Bool)
                                                                                                        then (do (pure (Zeros (n := N))))
                                                                                                        else
                                                                                                          (do (if ((x == "SPE mask 31:24") : Bool)
                                                                                                              then (do (pure (Zeros (n := N))))
                                                                                                              else
                                                                                                                (do (if ((x == "SPE mask 15:12") : Bool)
                                                                                                                    then (do (pure (Zeros (n := N))))
                                                                                                                    else
                                                                                                                      (do (if ((x == "SPE EVENTS 63_48") : Bool)
                                                                                                                          then (do (pure (Zeros (n := N))))
                                                                                                                          else
                                                                                                                            (do (if ((x == "SPE EVENTS 31_24") : Bool)
                                                                                                                                then (do (pure (Zeros (n := N))))
                                                                                                                                else
                                                                                                                                  (do (if ((x == "SPE EVENTS 15_12") : Bool)
                                                                                                                                      then (do (pure (Zeros (n := N))))
                                                                                                                                      else
                                                                                                                                        (do (if ((x == "Default Memory Map XNX bit") : Bool)
                                                                                                                                            then
                                                                                                                                              (do sail_assert (0 ≤b (N -i 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:822.38-822.39"
                                                                                                                                                  (pure (integer_subrange 0 (N -i 1) 0)))
                                                                                                                                            else
                                                                                                                                              (do (if ((x == "0") : Bool)
                                                                                                                                                  then
                                                                                                                                                    (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:825.53-825.54"
                                                                                                                                                        (pure (Sail.BitVec.extractLsb 0#1 (N -i 1) 0)))
                                                                                                                                                  else
                                                                                                                                                    (do (if ((x == "1") : Bool)
                                                                                                                                                        then
                                                                                                                                                          (do sail_assert ((0 ≤b (N -i 1)) && ((N -i 1) <b 1)) "sail-arm/arm-v9.4-a/src/impdefs.sail:828.53-828.54"
                                                                                                                                                              (pure (Sail.BitVec.extractLsb 1#1 (N -i 1) 0)))
                                                                                                                                                        else
                                                                                                                                                          (do (if ((x == "IMPDEF ErrorState") : Bool)
                                                                                                                                                              then (do (pure (Zeros (n := N))))
                                                                                                                                                              else
                                                                                                                                                                (do (if ((x == "Virtual External abort type") : Bool)
                                                                                                                                                                    then (do (pure (Zeros (n := N))))
                                                                                                                                                                    else
                                                                                                                                                                      (do (if ((x == "Virtual SError syndrome") : Bool)
                                                                                                                                                                          then (do (pure (Zeros (n := N))))
                                                                                                                                                                          else
                                                                                                                                                                            (do let _ : Unit := (print_endline (String.append x " is not among the strings in the above list."))
                                                                                                                                                                                sail_assert false "sail-arm/arm-v9.4-a/src/impdefs.sail:838.20-838.21"
                                                                                                                                                                                throw Error.Exit))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- Type quantifiers: N : Nat, N ≥ 0 -/
def __IMPDEF_bits (N : Nat) (x : String) : SailM (BitVec N) := do
  (ImpDefBits x N)

def undefined_EDECR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def _get_EDECR_Type_OSUCE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_CTIDEVCTL_Type_OSUCE (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSSCR_EL1_Type_SS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def DLR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DLR_Type := value_name
  writeReg DLR_EL0 (Sail.BitVec.updateSubrange (← readReg DLR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _DLR r

def undefined_DSPSR_EL0_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_DSPSR_EL0_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_ID_PFR0_Type_DIT (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 24 x)

def _update_ID_MMFR3_Type_PAN (v : (BitVec 32)) (x : (BitVec 4)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 19 16 x)

def undefined_DSPSR_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DSPSR_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DSPSR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DSPSR_Type := value_name
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 31 0 (BitVec.slice r 0 32))
  writeReg _DSPSR r

def undefined_DSPSR2_Type (_ : Unit) : SailM (BitVec 32) := do
  (undefined_bitvector 32)

def Mk_DSPSR2_Type (v : (BitVec 32)) : (BitVec 32) :=
  v

def DSPSR2_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : DSPSR2_Type := value_name
  writeReg DSPSR_EL0 (Sail.BitVec.updateSubrange (← readReg DSPSR_EL0) 63 32 (BitVec.slice r 0 32))
  writeReg _DSPSR2 r

def EDSCR_write (value_name : (BitVec 32)) : SailM Unit := do
  let r : EDSCR_Type := value_name
  writeReg MDCCSR_EL0 (Sail.BitVec.updateSubrange (← readReg MDCCSR_EL0) 30 29 (BitVec.slice r 29 2))
  writeReg _EDSCR r

def ExternalRealmInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (BEq.beq (← readReg RLPIDEN) Signal_High)))))

def ExternalRootInvasiveDebugEnabled (_ : Unit) : SailM Bool := do
  (if ((! (← (HaveRME ()))) : Bool)
  then (do (pure false))
  else (do (ExternalInvasiveDebugEnabled ()) <&&> (do (pure (! (← (HaveSecureEL2Ext ())))) <||> (do (ExternalSecureInvasiveDebugEnabled ()))) <&&> (do (ExternalRealmInvasiveDebugEnabled ())) <&&> (do (pure (BEq.beq (← readReg RTPIDEN) Signal_High)))))

def HaveBRBEv1p1 (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BRBEv1p1)

def BranchRecordAllowed (el : (BitVec 2)) : SailM Bool := do
  (if ((← (ELUsingAArch32 el)) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBFCR_EL1_Type_PAUSED (← readReg BRBFCR_EL1)) == 1#1) : Bool)
        then (do (pure false))
        else
          (do (if ((←((pure (el == EL3)) <&&> (do
                   (HaveBRBEv1p1 ())))) : Bool)
              then (do (pure ((_get_MDCR_EL3_Type_E3BREC (← readReg MDCR_EL3)) != (_get_MDCR_EL3_Type_E3BREW (← readReg MDCR_EL3)))))
              else
                (do (if ((←((pure (HaveEL EL3)) <&&> (do
                         (pure ((_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3)) == 0b00#2)) <||> (do
                           (pure (BEq.beq (← (CurrentSecurityState ())) SS_Secure)) <&&> (do
                             (pure ((_get_MDCR_EL3_Type_SBRBE (← readReg MDCR_EL3)) == 0b01#2))))))) : Bool)
                    then (do (pure false))
                    else
                      (do let questionMark := el
                          (if ((questionMark == EL3) : Bool)
                          then (do (pure false))
                          else
                            (do (if ((questionMark == EL2) : Bool)
                                then (do (pure ((_get_BRBCR_EL2_Type_E2BRE (← readReg BRBCR_EL2)) == 1#1)))
                                else
                                  (do (if ((questionMark == EL1) : Bool)
                                      then (do (pure ((_get_BRBCR_EL1_Type_E1BRE (← readReg BRBCR_EL1)) == 1#1)))
                                      else
                                        (do (if ((questionMark == EL0) : Bool)
                                            then
                                              (do (if ((←((EL2Enabled ()) <&&> (do
                                                       (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))))) : Bool)
                                                  then (do (pure ((_get_BRBCR_EL2_Type_E0HBRE (← readReg BRBCR_EL2)) == 1#1)))
                                                  else (do (pure ((_get_BRBCR_EL1_Type_E0BRE (← readReg BRBCR_EL1)) == 1#1)))))
                                            else (do (undefined_bool ())))))))))))))))))

def ELIsInHost (el : (BitVec 2)) : SailM Bool := do
  (if ((←((pure (! (← (HaveVirtHostExt ())))) <||> (do
       (ELUsingAArch32 EL2)))) : Bool)
  then (do (pure false))
  else
    (do let questionMark := el
        (if ((questionMark == EL3) : Bool)
        then (do (pure false))
        else
          (do (if ((questionMark == EL2) : Bool)
              then (do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) == 1#1))))
              else
                (do (if ((questionMark == EL1) : Bool)
                    then (do (pure false))
                    else
                      (do (if ((questionMark == EL0) : Bool)
                          then (do (EL2Enabled ()) <&&> (do (pure (((_get_HCR_EL2_Type_E2H (← readReg HCR_EL2)) +++ (_get_HCR_EL2_Type_TGE (← readReg HCR_EL2))) == 0b11#2))))
                          else
                            (do (Unreachable ())
                                (undefined_bool ())))))))))))

def HavePACExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_PAuth)

def S1TranslationRegime (el : (BitVec 2)) : SailM (BitVec 2) := do
  (if ((el != EL0) : Bool)
  then (do (pure el))
  else
    (do (if ((←((pure (HaveEL EL3)) <&&> (do
             (ELUsingAArch32 EL3)) <&&> (do
             (pure ((_get_SCR_Type_NS (← readReg SCR)) == 0#1))))) : Bool)
        then (do (pure EL3))
        else
          (do (if ((←((HaveVirtHostExt ()) <&&> (do
                   (ELIsInHost el)))) : Bool)
              then (do (pure EL2))
              else (do (pure EL1)))))))

def S1TranslationRegime__1 (_ : Unit) : SailM (BitVec 2) := do
  (S1TranslationRegime (← readReg PSTATE).EL)

def undefined_TCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL1_Type_A1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _update_TTBCR_Type_A1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 22 22 x)

def _get_TCR_EL2_Type_A1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_TCR_EL1_Type_AS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR_EL2_Type_AS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR_EL1_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 59 59)

def _get_GICD_CTLR_Type_DS (v : (BitVec 32)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 6 6)

def _get_TCR_EL3_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_VTCR_EL2_Type_DS (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 32 32)

def _get_TCR_EL1_Type_E0PD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_TCR_EL2_Type_E0PD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 55 55)

def _get_TCR_EL1_Type_E0PD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_TCR_EL2_Type_E0PD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 56 56)

def _get_TCR_EL1_Type_EPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _update_TTBCR_Type_EPD0 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 7 7 x)

def _get_TCR_EL2_Type_EPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 7 7)

def _get_TCR_EL1_Type_EPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _update_TTBCR_Type_EPD1 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 23 23 x)

def _get_TCR_EL2_Type_EPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 23 23)

def _get_TCR_EL1_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 39 39)

def _get_TCR_EL3_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_VTCR_EL2_Type_HA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 21 21)

def _get_TCR_EL1_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 40 40)

def _get_TCR_EL3_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_VTCR_EL2_Type_HD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 22 22)

def _get_TCR_EL1_Type_HPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_TCR_EL2_Type_HPD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 41 41)

def _get_TCR_EL1_Type_HPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR_EL2_Type_HPD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR_EL1_Type_IPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 34 32)

def _get_TCR_EL2_Type_IPS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 34 32)

def _get_TCR_EL1_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _update_HTCR_Type_IRGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _update_TTBCR_Type_IRGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 9 8 x)

def _get_TCR_EL2_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_TCR_EL3_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_VTCR_EL2_Type_IRGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 9 8)

def _get_TCR_EL1_Type_IRGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _update_TTBCR_Type_IRGN1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 24 x)

def _get_TCR_EL2_Type_IRGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 25 24)

def _get_TCR_EL1_Type_MTX0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_TCR_EL2_Type_MTX0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 60 60)

def _get_TCR_EL1_Type_MTX1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_TCR_EL2_Type_MTX1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 61 61)

def _get_TCR_EL1_Type_NFD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_TCR_EL2_Type_NFD0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 53 53)

def _get_TCR_EL1_Type_NFD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_TCR_EL2_Type_NFD1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 54 54)

def _get_TCR_EL1_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _update_HTCR_Type_ORGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 10 x)

def _update_TTBCR_Type_ORGN0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 11 10 x)

def _get_TCR_EL2_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_TCR_EL3_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_VTCR_EL2_Type_ORGN0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 11 10)

def _get_TCR_EL1_Type_ORGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 27 26)

def _update_TTBCR_Type_ORGN1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 26 x)

def _get_TCR_EL2_Type_ORGN1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 27 26)

def _get_TCR_EL1_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _update_HTCR_Type_SH0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 12 x)

def _update_TTBCR_Type_SH0 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 13 12 x)

def _get_TCR_EL2_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_TCR_EL3_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_VTCR_EL2_Type_SH0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 13 12)

def _get_TCR_EL1_Type_SH1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _update_TTBCR_Type_SH1 (v : (BitVec 32)) (x : (BitVec 2)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 29 28 x)

def _get_TCR_EL2_Type_SH1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 29 28)

def _get_TCR_EL1_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _update_HTCR_Type_T0SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _update_TTBCR_Type_T0SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 2 0 x)

def _get_TCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_TCR_EL3_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_VSTCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_VTCR_EL2_Type_T0SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 5 0)

def _get_TCR_EL1_Type_T1SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 21 16)

def _update_TTBCR_Type_T1SZ (v : (BitVec 32)) (x : (BitVec 3)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 18 16 x)

def _get_TCR_EL2_Type_T1SZ (v : (BitVec 64)) : (BitVec 6) :=
  (Sail.BitVec.extractLsb v 21 16)

def _get_TCR_EL1_Type_TBI0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR_EL2_Type_TBI0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR_EL1_Type_TBI1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL2_Type_TBI1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL1_Type_TBID0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_TCR_EL2_Type_TBID0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 51 51)

def _get_TCR_EL1_Type_TBID1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_TCR_EL2_Type_TBID1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 52 52)

def _get_TCR_EL1_Type_TCMA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_TCR_EL2_Type_TCMA0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 57 57)

def _get_TCR_EL1_Type_TCMA1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_TCR_EL2_Type_TCMA1 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 58 58)

def _get_TCR_EL1_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL3_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VSTCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_VTCR_EL2_Type_TG0 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 15 14)

def _get_TCR_EL1_Type_TG1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def _get_TCR_EL2_Type_TG1 (v : (BitVec 64)) : (BitVec 2) :=
  (Sail.BitVec.extractLsb v 31 30)

def undefined_TCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL2_Type_HPD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _update_HTCR_Type_HPD (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 24 24 x)

def _get_TCR_EL3_Type_HPD (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def _update_HTCR_Type_HWU59 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 25 25 x)

def _update_HTCR_Type_HWU60 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 26 26 x)

def _update_HTCR_Type_HWU61 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 27 27 x)

def _update_HTCR_Type_HWU62 (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 28 28 x)

def _get_TCR_EL2_Type_MTX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_TCR_EL3_Type_MTX (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 33 33)

def _get_TCR_EL2_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_TCR_EL3_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_VTCR_EL2_Type_PS (v : (BitVec 64)) : (BitVec 3) :=
  (Sail.BitVec.extractLsb v 18 16)

def _get_TCR_EL2_Type_TBI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_TCR_EL3_Type_TBI (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 20 20)

def _get_TCR_EL2_Type_TBID (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR_EL3_Type_TBID (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 29 29)

def _get_TCR_EL2_Type_TCMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def _get_TCR_EL3_Type_TCMA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 30 30)

def undefined_TCR_EL3_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_TCR_EL3_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_TCR_EL3_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 37 37)

def _get_TCR2_EL1_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_TCR2_EL2_Type_AIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_TCR_EL3_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR2_EL1_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_TCR2_EL2_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 5 5)

def _get_VTCR_EL2_Type_D128 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 38 38)

def _get_TCR_EL3_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 43 43)

def _get_TCR2_EL1_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_TCR2_EL2_Type_DisCH0 (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 14 14)

def _get_TCR_EL3_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 42 42)

def _get_TCR2_EL1_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_TCR2_EL2_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 11 11)

def _get_VTCR_EL2_Type_HAFT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 44 44)

def _get_TCR_EL3_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 35 35)

def _get_TCR2_EL1_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_TCR2_EL2_Type_PIE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_TCR_EL3_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 36 36)

def _get_TCR2_EL1_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_TCR2_EL2_Type_POE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 3 3)

def _get_TCR_EL3_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_TCR2_EL1_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_TCR2_EL2_Type_PnCH (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

/-- Type quantifiers: k_IsInstr : Bool -/
def EffectiveTBI (address : (BitVec 64)) (IsInstr : Bool) (el : (BitVec 2)) : SailM (BitVec 1) := do
  let tbi ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  let tbid ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:6080.21-6080.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  sail_assert (! (← (ELUsingAArch32 regime))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6082.43-6082.44"
  let (tbi, tbid) ← (( do
    let questionMark := regime
    let (tbi, tbid) ← (( do
      (if ((questionMark == EL1) : Bool)
      then
        (do let tbi ←
              (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
              then (do (pure (_get_TCR_EL1_Type_TBI1 (← readReg TCR_EL1))))
              else (do (pure (_get_TCR_EL1_Type_TBI0 (← readReg TCR_EL1)))))
            let tbid ← (( do
              (if ((← (HavePACExt ())) : Bool)
              then
                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                    then (do (pure (_get_TCR_EL1_Type_TBID1 (← readReg TCR_EL1))))
                    else (do (pure (_get_TCR_EL1_Type_TBID0 (← readReg TCR_EL1))))))
              else (do (pure tbid))) ) : SailM (BitVec 1) )
            (pure (tbi, tbid)))
      else
        (do let (tbi, tbid) ← (( do
              (if ((questionMark == EL2) : Bool)
              then
                (do let (tbi, tbid) ← (( do
                      (if ((←((HaveVirtHostExt ()) <&&> (do
                           (ELIsInHost el)))) : Bool)
                      then
                        (do let tbi ←
                              (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                              then (do (pure (_get_TCR_EL2_Type_TBI1 (← readReg TCR_EL2))))
                              else (do (pure (_get_TCR_EL2_Type_TBI0 (← readReg TCR_EL2)))))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then
                                (do (if ((((BitVec.access address 55) : BitVec 1) == 1#1) : Bool)
                                    then (do (pure (_get_TCR_EL2_Type_TBID1 (← readReg TCR_EL2))))
                                    else (do (pure (_get_TCR_EL2_Type_TBID0 (← readReg TCR_EL2))))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))
                      else
                        (do let tbi ← (pure (_get_TCR_EL2_Type_TBI (← readReg TCR_EL2)))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then (do (pure (_get_TCR_EL2_Type_TBID (← readReg TCR_EL2))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    (pure (tbi, tbid)))
              else
                (do let (tbi, tbid) ← (( do
                      (if ((questionMark == EL3) : Bool)
                      then
                        (do let tbi ← (pure (_get_TCR_EL3_Type_TBI (← readReg TCR_EL3)))
                            let tbid ← (( do
                              (if ((← (HavePACExt ())) : Bool)
                              then (do (pure (_get_TCR_EL3_Type_TBID (← readReg TCR_EL3))))
                              else (do (pure tbid))) ) : SailM (BitVec 1) )
                            (pure (tbi, tbid)))
                      else (do (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
                    (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
            (pure (tbi, tbid)))) ) : SailM ((BitVec 1) × (BitVec 1)) )
    (pure (tbi, tbid)) ) : SailM ((BitVec 1) × (BitVec 1)) )
  (if ((←((pure (tbi == 1#1)) <&&> (do
       (pure (((! (← (HavePACExt ()))) || (tbid == 0#1)) || (! IsInstr)))))) : Bool)
  then (do (pure 1#1))
  else (do (pure 0#1)))

/-- Type quantifiers: k_IsInstr : Bool -/
def AddrTop (address : (BitVec 64)) (IsInstr : Bool) (el : (BitVec 2)) : SailM Int := do
  sail_assert (HaveEL el) "sail-arm/arm-v9.4-a/src/v8_base.sail:6128.21-6128.22"
  let regime ← (( do (S1TranslationRegime el) ) : SailM (BitVec 2) )
  (if ((← (ELUsingAArch32 regime)) : Bool)
  then (do (pure 31))
  else
    (do (if (((← (EffectiveTBI address IsInstr el)) == 1#1) : Bool)
        then (do (pure 55))
        else (do (pure 63)))))

def IsInHost (_ : Unit) : SailM Bool := do
  (ELIsInHost (← readReg PSTATE).EL)

def AArch64_BranchAddr (vaddress : (BitVec 64)) (el : (BitVec 2)) : SailM (BitVec 64) := do
  sail_assert (! (← (UsingAArch32 ()))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6150.35-6150.36"
  let msbit ← (( do (AddrTop vaddress true el) ) : SailM Int )
  (if ((msbit == 63) : Bool)
  then (do (pure vaddress))
  else
    (do sail_assert ((0 ≤b msbit) && (msbit <b 64)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6155.54-6155.55"
        (if (((←((pure ((el == EL0) || (el == EL1))) <||> (do
               (IsInHost ())))) && (((BitVec.access vaddress msbit) : BitVec 1) == 1#1)) : Bool)
        then (do (pure (sign_extend (Sail.BitVec.extractLsb vaddress msbit 0) 64)))
        else (do (pure (Sail.BitVec.zeroExtend (Sail.BitVec.extractLsb vaddress msbit 0) 64))))))

def BRBEMispredictAllowed (_ : Unit) : SailM Bool := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure ((_get_BRBCR_EL2_Type_MPRED (← readReg BRBCR_EL2)) == 0#1))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBCR_EL1_Type_MPRED (← readReg BRBCR_EL1)) == 0#1) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def BRBCycleCountingEnabled (_ : Unit) : SailM Bool := do
  (if ((←((pure (HaveEL EL2)) <&&> (do
       (pure ((_get_BRBCR_EL2_Type_CC (← readReg BRBCR_EL2)) == 0#1))))) : Bool)
  then (do (pure false))
  else
    (do (if (((_get_BRBCR_EL1_Type_CC (← readReg BRBCR_EL1)) == 0#1) : Bool)
        then (do (pure false))
        else (do (pure true)))))

def BranchRawCycleCount (_ : Unit) : SailM Int := do
  let diff ← (( do (pure ((← readReg __cycle_count) -i (← readReg __last_cycle_count))) ) : SailM Int )
  writeReg __last_cycle_count (← readReg __cycle_count)
  (pure diff)

def FirstBranchAfterProhibited (_ : Unit) : SailM Bool := do
  (pure (! (← readReg __last_branch_valid)))

def BranchEncCycleCount (_ : Unit) : SailM ((BitVec 1) × (BitVec 14)) := do
  let cc ← (( do (BranchRawCycleCount ()) ) : SailM Int )
  (if ((←((pure (! (← (BRBCycleCountingEnabled ())))) <||> (do
       (FirstBranchAfterProhibited ())))) : Bool)
  then (do (pure (1#1, (Zeros (n := 14)))))
  else
    (do let E ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
        let M ← (( do (undefined_bitvector 8) ) : SailM (BitVec 8) )
        let (E, M) ← (( do
          (if ((cc <b (2 ^i 8)) : Bool)
          then
            (do let E : (BitVec 6) := (Zeros (n := 6))
                let M : (BitVec 8) := (integer_subrange cc 7 0)
                (pure (E, M)))
          else
            (do let (E, M) ← (( do
                  (if ((cc ≥b (2 ^i 20)) : Bool)
                  then
                    (do let E : (BitVec 6) := (Ones (n := 6))
                        let M : (BitVec 8) := (Ones (n := 8))
                        (pure (E, M)))
                  else
                    (do let E : (BitVec 6) := (integer_subrange 1 5 0)
                        let (E, cc) ← (( do
                          let mut loop_vars := (E, cc)
                          while (λ (E, cc) => (cc ≥b (2 ^i 9))) loop_vars do
                            let (E, cc) := loop_vars
                            loop_vars :=
                              (let E : (BitVec 6) := (BitVec.addInt E 1)
                              let cc : Int := (fdiv_int cc 2)
                              (E, cc) : ((BitVec 6) × Int))
                          (pure loop_vars) ) : SailM ((BitVec 6) × Int) )
                        let cc := cc
                        let M : (BitVec 8) := (integer_subrange cc 7 0)
                        (pure (E, M)))) ) : SailM ((BitVec 6) × (BitVec 8)) )
                (pure (E, M)))) ) : SailM ((BitVec 6) × (BitVec 8)) )
        (pure (0#1, (E +++ M)))))

def BranchMispredict (_ : Unit) : Bool :=
  false

/-- Type quantifiers: k_cond : Bool -/
def FilterBranchRecord (br : BranchType) (cond : Bool) : SailM Bool := SailME.run do
  match br with
  | .BranchType_DIRCALL => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_DIRCALL (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_INDCALL => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_INDCALL (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_RET => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_RTN (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | .BranchType_DIR =>
    SailME.throw (← do
        (if (cond : Bool)
        then (do (pure ((_get_BRBFCR_EL1_Type_CONDDIR (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
        else (do (pure ((_get_BRBFCR_EL1_Type_DIRECT (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))))
  | .BranchType_INDIR => SailME.throw (← do (pure ((_get_BRBFCR_EL1_Type_INDIRECT (← readReg BRBFCR_EL1)) != (_get_BRBFCR_EL1_Type_EnI (← readReg BRBFCR_EL1)))))
  | _ => (Unreachable ())
  (pure false)

def HaveTME (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_TME)

def CurrentInstrSet (_ : Unit) : SailM InstrSet := do
  let result ← (( do (undefined_InstrSet ()) ) : SailM InstrSet )
  (if ((← (UsingAArch32 ())) : Bool)
  then
    (do (if (((← readReg PSTATE).T == 0#1) : Bool)
        then (do (pure InstrSet_A32))
        else (do (pure InstrSet_T32))))
  else (do (pure InstrSet_A64)))

def BadMode (mode : (BitVec 5)) : SailM Bool := do
  let valid_name ← (( do (undefined_bool ()) ) : SailM Bool )
  let valid_name : Bool :=
    let questionMark := mode
    if ((questionMark == M32_Monitor) : Bool)
    then (HaveAArch32EL EL3)
    else
      (if ((questionMark == M32_Hyp) : Bool)
      then (HaveAArch32EL EL2)
      else
        (if ((questionMark == M32_FIQ) : Bool)
        then (HaveAArch32EL EL1)
        else
          (if ((questionMark == M32_IRQ) : Bool)
          then (HaveAArch32EL EL1)
          else
            (if ((questionMark == M32_Svc) : Bool)
            then (HaveAArch32EL EL1)
            else
              (if ((questionMark == M32_Abort) : Bool)
              then (HaveAArch32EL EL1)
              else
                (if ((questionMark == M32_Undef) : Bool)
                then (HaveAArch32EL EL1)
                else
                  (if ((questionMark == M32_System) : Bool)
                  then (HaveAArch32EL EL1)
                  else
                    (if ((questionMark == M32_User) : Bool)
                    then (HaveAArch32EL EL0)
                    else false))))))))
  let valid_name := valid_name
  (pure (! valid_name))

/-- Type quantifiers: usr : Int, fiq : Int, irq : Int, svc : Int, abt : Int, und : Int, hyp : Int -/
def RBankSelect (mode : (BitVec 5)) (usr : Int) (fiq : Int) (irq : Int) (svc : Int) (abt : Int) (und : Int) (hyp : Int) : SailM Int := do
  let questionMark := mode
  (if ((questionMark == M32_User) : Bool)
  then (do (pure usr))
  else
    (do (if ((questionMark == M32_FIQ) : Bool)
        then (do (pure fiq))
        else
          (do (if ((questionMark == M32_IRQ) : Bool)
              then (do (pure irq))
              else
                (do (if ((questionMark == M32_Svc) : Bool)
                    then (do (pure svc))
                    else
                      (do (if ((questionMark == M32_Abort) : Bool)
                          then (do (pure abt))
                          else
                            (do (if ((questionMark == M32_Hyp) : Bool)
                                then (do (pure hyp))
                                else
                                  (do (if ((questionMark == M32_Undef) : Bool)
                                      then (do (pure und))
                                      else
                                        (do (if ((questionMark == M32_System) : Bool)
                                            then (do (pure usr))
                                            else
                                              (do sail_assert false "Pattern match failure at sail-arm/arm-v9.4-a/src/v8_base.sail:6328.4-6337.5"
                                                  throw Error.Exit))))))))))))))))

/-- Type quantifiers: n : Nat, n ≥ 0 ∧ n ≤ 15 -/
def LookUpRIndex (n : Nat) (mode : (BitVec 5)) : SailM Int := do
  sail_assert ((n ≥b 0) && (n ≤b 14)) "sail-arm/arm-v9.4-a/src/v8_base.sail:6344.27-6344.28"
  match n with
  | 8 => (RBankSelect mode 8 24 8 8 8 8 8)
  | 9 => (RBankSelect mode 9 25 9 9 9 9 9)
  | 10 => (RBankSelect mode 10 26 10 10 10 10 10)
  | 11 => (RBankSelect mode 11 27 11 11 11 11 11)
  | 12 => (RBankSelect mode 12 28 12 12 12 12 12)
  | 13 => (RBankSelect mode 13 29 17 19 21 23 15)
  | 14 => (RBankSelect mode 14 30 16 18 20 22 14)
  | _ => (pure n)

def PC_read (_ : Unit) : SailM (BitVec 64) := do
  readReg _PC

def undefined_BRBIDR0_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_BRBIDR0_EL1_Type_NUMREC (v : (BitVec 64)) : (BitVec 8) :=
  (Sail.BitVec.extractLsb v 7 0)

def GetBRBENumRecords (_ : Unit) : SailM Int := do
  sail_assert (←((pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x08#8))) <||> (do
    (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x10#8))) <||> (do
      (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x20#8))) <||> (do
        (pure ((BitVec.toNat (_get_BRBIDR0_EL1_Type_NUMREC (← readReg BRBIDR0_EL1))) == (BitVec.toNat 0x40#8)))))))) "sail-arm/arm-v9.4-a/src/v8_base.sail:6426.176-6426.177"
  (__IMPDEF_integer "Number of BRB records")

def UpdateBranchRecordBuffer (ccu : (BitVec 1)) (cc : (BitVec 14)) (lastfailed : (BitVec 1)) (transactional : (BitVec 1)) (branch_type : (BitVec 6)) (el : (BitVec 2)) (mispredict : (BitVec 1)) (valid_name : (BitVec 2)) (source_address : (BitVec 64)) (target_address : (BitVec 64)) : SailM Unit := do
  let loop_i_lower := 1
  let loop_i_upper ← (( do (pure ((← (GetBRBENumRecords ())) -i 1)) ) : SailM Int )
  let mut loop_vars := ()
  for i in [loop_i_upper:loop_i_lower:-1]i do
    let () := loop_vars
    loop_vars ← do
      sail_assert (i <b 64) "sail-arm/arm-v9.4-a/src/v8_base.sail:6440.39-6440.40"
      writeReg Records_SRC (vectorUpdate (← readReg Records_SRC) i (GetElem?.getElem! (← readReg Records_SRC) (i -i 1)))
      writeReg Records_TGT (vectorUpdate (← readReg Records_TGT) i (GetElem?.getElem! (← readReg Records_TGT) (i -i 1)))
      writeReg Records_INF (vectorUpdate (← readReg Records_INF) i (GetElem?.getElem! (← readReg Records_INF) (i -i 1)))
  (pure loop_vars)
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 46 46 ccu))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 45 32 cc))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 7 6 el))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 1 0 valid_name))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 16 16 transactional))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 17 17 lastfailed))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 5 5 mispredict))
  writeReg Records_INF (vectorUpdate (← readReg Records_INF) 0 (Sail.BitVec.updateSubrange (GetElem?.getElem! (← readReg Records_INF) 0) 13 8 branch_type))
  writeReg Records_SRC (vectorUpdate (← readReg Records_SRC) 0 (Mk_BRBSRCType source_address))
  writeReg Records_TGT (vectorUpdate (← readReg Records_TGT) 0 (Mk_BRBTGTType target_address))

/-- Type quantifiers: k_cond : Bool -/
def BRBEBranch (br_type : BranchType) (cond : Bool) (target_address : (BitVec 64)) : SailM Unit := do
  let branch_valid ← (( do (BranchRecordAllowed (← readReg PSTATE).EL) ) : SailM Bool )
  (if ((←((pure branch_valid) <&&> (do
       (FilterBranchRecord br_type cond)))) : Bool)
  then
    (do let branch_type ← (( do (undefined_bitvector 6) ) : SailM (BitVec 6) )
        let branch_type ← (( do
          match br_type with
          | .BranchType_DIR =>
            ((if (cond : Bool)
            then (do (pure 0b001000#6))
            else (do (pure 0b000000#6))))
          | .BranchType_INDIR => (pure 0b000001#6)
          | .BranchType_DIRCALL => (pure 0b000010#6)
          | .BranchType_INDCALL => (pure 0b000011#6)
          | .BranchType_RET => (pure 0b000101#6)
          | _ =>
            (do
              (Unreachable ())
              (pure branch_type)) ) : SailM (BitVec 6) )
        let ccu ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
        let cc ← (( do (undefined_bitvector 14) ) : SailM (BitVec 14) )
        let (cc, ccu) ← (( do
          let (tup__0, tup__1) ← do (BranchEncCycleCount ())
          let ccu : (BitVec 1) := tup__0
          let cc : (BitVec 14) := tup__1
          (pure (cc, ccu)) ) : SailM ((BitVec 14) × (BitVec 1)) )
        let lastfailed ← (( do
          (if ((← (HaveTME ())) : Bool)
          then (do (pure (_get_BRBFCR_EL1_Type_LASTFAILED (← readReg BRBFCR_EL1))))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        let transactional ← (( do
          (if ((←((HaveTME ()) <&&> (do
               (pure ((← readReg TSTATE).depth >b 0))))) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        let el ← (( do (pure (← readReg PSTATE).EL) ) : SailM (BitVec 2) )
        let mispredict ← (( do
          (if (((← (BRBEMispredictAllowed ())) && (BranchMispredict ())) : Bool)
          then (do (pure 1#1))
          else (do (pure 0#1))) ) : SailM (BitVec 1) )
        (UpdateBranchRecordBuffer ccu cc lastfailed transactional branch_type el mispredict 0b11#2 (← (PC_read ())) target_address)
        writeReg BRBFCR_EL1 (Sail.BitVec.updateSubrange (← readReg BRBFCR_EL1) 6 6 0#1)
        (PMUEvent PMU_EVENT_BRB_FILTRATE))
  else (do (pure ())))
  writeReg __last_branch_valid branch_valid

def HaveBRBExt (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_BRBE)

def HaveStatisticalProfiling (_ : Unit) : SailM Bool := do
  (IsFeatureImplemented FEAT_SPE)

def undefined_PMSIDR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def _get_PMSIDR_EL1_Type_PBT (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 24 24)

def undefined_PMSCR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSCR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _update_HTRFCR_Type_CX (v : (BitVec 32)) (x : (BitVec 1)) : (BitVec 32) :=
  (Sail.BitVec.updateSubrange v 3 3 x)

def _get_PMSCR_EL1_Type_E0SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSCR_EL1_Type_E1SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def _get_PMSCR_EL1_Type_PA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def _get_PMSCR_EL2_Type_PA (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 4 4)

def undefined_PMSCR_EL2_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMSCR_EL2_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_PMSCR_EL2_Type_E0HSPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 0 0)

def _get_PMSCR_EL2_Type_E2SPE (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 1 1)

def undefined_PMBLIMITR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBLIMITR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def undefined_PMBSR_EL1_Type (_ : Unit) : SailM (BitVec 64) := do
  (undefined_bitvector 64)

def Mk_PMBSR_EL1_Type (v : (BitVec 64)) : (BitVec 64) :=
  v

def _get_VTCR_EL2_Type_AssuredOnly (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 34 34)

def _get_PMBSR_EL1_Type_S (v : (BitVec 64)) : (BitVec 1) :=
  (Sail.BitVec.extractLsb v 17 17)

def ProfilingBufferOwner (_ : Unit) : SailM (SecurityState × (BitVec 2)) := do
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  let owning_ss ← (( do
    (if ((HaveEL EL3) : Bool)
    then
      (do let state_bits ← (( do (undefined_bitvector 3) ) : SailM (BitVec 3) )
          let state_bits ← (( do
            (if ((← (HaveRME ())) : Bool)
            then
              (do let state_bits ← (pure ((_get_MDCR_EL3_Type_NSPBE (← readReg MDCR_EL3)) +++ (_get_MDCR_EL3_Type_NSPB (← readReg MDCR_EL3))))
                  (if ((←((pure (let b__0 := state_bits
                       if (((Sail.BitVec.extractLsb b__0 2 1) == (0b10#2 : (BitVec 2))) : Bool)
                       then true
                       else false : Bool)) <||> (do
                       (pure ((! (← (HaveSecureEL2Ext ()))) && (let b__1 := state_bits
                           if (((Sail.BitVec.extractLsb b__1 2 1) == (0b00#2 : (BitVec 2))) : Bool)
                           then true
                           else false : Bool)))))) : Bool)
                  then
                    (do let (_, __tup_1) ← do (ConstrainUnpredictableBits Unpredictable_RESERVEDNSxB 3)
                        (pure __tup_1))
                  else (do (pure state_bits))))
            else (do (pure (0#1 +++ (_get_MDCR_EL3_Type_NSPB (← readReg MDCR_EL3)))))) ) : SailM (BitVec 3) )
          let b__2 := state_bits
          (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b00#2 : (BitVec 2))) : Bool)
          then (do (pure SS_Secure))
          else
            (do (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b01#2 : (BitVec 2))) : Bool)
                then (do (pure SS_NonSecure))
                else
                  (do (if (((Sail.BitVec.extractLsb b__2 2 1) == (0b11#2 : (BitVec 2))) : Bool)
                      then (do (pure SS_Realm))
                      else (do (pure owning_ss))))))))
    else
      (do (if ((← (SecureOnlyImplementation ())) : Bool)
          then (do (pure SS_Secure))
          else (do (pure SS_NonSecure))))) ) : SailM SecurityState )
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_el ← (( do
    (if ((←((pure (HaveEL EL2)) <&&> (do
         (pure (bne owning_ss SS_Secure)) <||> (do
           (IsSecureEL2Enabled ()))))) : Bool)
    then
      (do (if (((_get_MDCR_EL2_Type_E2PB (← readReg MDCR_EL2)) == 0b00#2) : Bool)
          then (do (pure EL2))
          else (do (pure EL1))))
    else (do (pure EL1))) ) : SailM (BitVec 2) )
  (pure (owning_ss, owning_el))

def ProfilingBufferEnabled (_ : Unit) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((! (← (HaveStatisticalProfiling ()))) : Bool)
  then (do (pure false))
  else
    (do let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        let state_bits ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
        let state_bits ← (( do
          (if ((← (HaveRME ())) : Bool)
          then (do (pure ((_get_SCR_EL3_Type_NSE (← readReg SCR_EL3)) +++ (← (EffectiveSCR_EL3_NS ())))))
          else (do (pure (0#1 +++ (_get_SCR_EL3_Type_NS (← readReg SCR_EL3)))))) ) : SailM (BitVec 2) )
        let state_match ← (( do (undefined_bool ()) ) : SailM Bool )
        let state_match : Bool :=
          match owning_ss with
          | .SS_Secure => (state_bits == 0b00#2)
          | .SS_NonSecure => (state_bits == 0b01#2)
          | .SS_Realm => (state_bits == 0b11#2)
          | _ => state_match
        (pure ((! (← (ELUsingAArch32 owning_el))) && state_match)) <&&> (do
          (pure ((_get_PMBLIMITR_EL1_Type_E (← readReg PMBLIMITR_EL1)) == 1#1))) <&&> (do
          (pure ((_get_PMBSR_EL1_Type_S (← readReg PMBSR_EL1)) == 0#1)))))

def StatisticalProfilingEnabled__1 (el : (BitVec 2)) : SailM Bool := do
  let owning_el ← (( do (undefined_bitvector 2) ) : SailM (BitVec 2) )
  let owning_ss ← (( do (undefined_SecurityState ()) ) : SailM SecurityState )
  (if ((←((pure (! (← (HaveStatisticalProfiling ())))) <||> (do
       (UsingAArch32 ())) <||> (do
       (pure (! (← (ProfilingBufferEnabled ()))))))) : Bool)
  then (do (pure false))
  else
    (do let tge_set ← (( do (EL2Enabled ()) <&&> (do (pure ((_get_HCR_EL2_Type_TGE (← readReg HCR_EL2)) == 1#1))) ) : SailM Bool )
        let (owning_el, owning_ss) ← (( do
          let (tup__0, tup__1) ← do (ProfilingBufferOwner ())
          let owning_ss : SecurityState := tup__0
          let owning_el : (BitVec 2) := tup__1
          (pure (owning_el, owning_ss)) ) : SailM ((BitVec 2) × SecurityState) )
        (if ((←((pure (((BitVec.toNat owning_el) <b (BitVec.toNat el)) || (tge_set && (owning_el == EL1)))) <||> (do
             (pure (bne owning_ss (← (SecurityStateAtEL el))))))) : Bool)
        then (do (pure false))
        else
          (do let spe_bit ← (( do (undefined_bitvector 1) ) : SailM (BitVec 1) )
              let spe_bit ← (( do
                let questionMark := el
                (if ((questionMark == EL3) : Bool)
                then
                  (do (Unreachable ())
                      (pure spe_bit))
                else
                  (do (if ((questionMark == EL2) : Bool)
                      then (do (pure (_get_PMSCR_EL2_Type_E2SPE (← readReg PMSCR_EL2))))
                      else
                        (do (if ((questionMark == EL1) : Bool)
                            then (do (pure (_get_PMSCR_EL1_Type_E1SPE (← readReg PMSCR_EL1))))
                            else
                              (do (if ((questionMark == EL0) : Bool)
                                  then
                                    (do (if (tge_set : Bool)
                                        then (do (pure (_get_PMSCR_EL2_Type_E0HSPE (← readReg PMSCR_EL2))))
                                        else (do (pure (_get_PMSCR_EL1_Type_E0SPE (← readReg PMSCR_EL1))))))
                                  else (do (pure spe_bit))))))))) ) : SailM (BitVec 1) )
              (pure (spe_bit == 1#1))))))

def StatisticalProfilingEnabled (_ : Unit) : SailM Bool := do
  (StatisticalProfilingEnabled__1 (← readReg PSTATE).EL)


end ArmASL.Functions
